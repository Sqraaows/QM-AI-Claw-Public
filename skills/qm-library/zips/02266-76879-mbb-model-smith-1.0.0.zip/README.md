# MBB Model Smith

投委会级财务建模工具集。回答三个问题：投多少、多久回本、什么能搞死这个项目。

含中国市场参数开箱即用，输出自带叙事层翻译和Go/No-Go信号灯。

---

## 核心产出

```
输入：一组项目假设
输出：
├── 一句话总结（"投125万，21月回本，3年赚179万"）
├── Go/No-Go 信号灯（🟢🟡🔴）
├── 致命假设清单（"月营收降30%结论翻转"）
├── 概率分布（"跑1000次，78%的情况赚钱"）
└── Excel报告（McKinsey配色spreadsheet）
```

---

## 8个工具

### 投委会决策层

| 工具 | 用途 | 典型产出 |
|------|------|---------|
| **project_payback.py** | 单项目投资回收 | 回收期 + 累计回报曲线 + 信号灯 |
| **assumption_flip_test.py** | 假设翻转测试 | 致命假设识别 + 翻转阈值 |
| **monte_carlo_simulator.py** | 蒙特卡洛模拟 | NPV/IRR概率分布 + VaR |
| **excel_exporter.py** | Excel报告导出 | 格式化.xlsx文件 |

### 基础分析层

| 工具 | 用途 |
|------|------|
| **dcf_valuation.py** | DCF估值（WACC + 双终端值 + 敏感性） |
| **ratio_calculator.py** | 财务比率（5类20+指标） |
| **budget_variance_analyzer.py** | 预算差异分析 |
| **forecast_builder.py** | 滚动预测（driver-based + 场景建模） |

所有脚本使用Python标准库，零外部依赖。Excel导出可选安装openpyxl。

---

## 中国市场适配

检测到中国项目时自动应用：

| 参数 | 默认值 | 来源 |
|------|--------|------|
| 无风险利率 | 1.77% | 中国10年期国债（2026.4） |
| 股权风险溢价 | 5.0% | 沪深300 ERP中枢 |
| 企业所得税 | 25% | 一般企业 |
| Hurdle Rate | 15% | 中国投委会实际决策门槛 |

### IRR对标速查

基于上市公司真实募投公告（永辉21.57%、电声15.44%）：

```
> 30%    优秀，审视假设是否乐观
20-30%   良好，消费零售甜蜜区
15-20%   合格，需看战略协同
10-15%   偏低，考虑更好的资金去处
< 10%    不建议，除非有极强战略理由
```

---

## 叙事层

每次计算结果自动前置人话版本：

```
投125万，21个月回本，3年净赚179万。
最大风险是单台月营收——从4.5万降到3.15万结论翻转。
跑1000种情况，78%概率赚钱。
```

按受众差异化输出：

| 受众 | 重点表述 |
|------|---------|
| CEO | "3年净赚179万，值得做" |
| CFO | "21月现金流转正，最差情况亏X" |
| 运营VP | "1人管5台，前4月爬坡期" |
| 品牌VP | "品牌影响中性，设备外观需品牌部确认" |

---

## 实测案例

**场景**：星速咖啡5台无人咖啡车进商场

| 工具 | 结论 |
|------|------|
| Project Payback | 投¥125万 → 21月回本 → 36月赚¥179万 → 🟢 GREEN |
| Assumption Flip | 致命假设2个：单台月营收-30%翻转、设备台数-30%翻转 |
| Monte Carlo | 单台维度0%回本概率 → 模型依赖规模效应，5台才成立 |

**投委会建议**：先用2-3台验证月营收稳定性，确认后再扩。

---

## 安装

**直接使用**：复制 `SKILL.md` 作为system prompt，`scripts/` 和 `references/` 放在可访问路径。

**Claude Code / Cline / Cursor**：
```bash
git clone https://github.com/pennypny163/mbb-model-smith.git ~/.your-tool/skills/mbb-model-smith
```

**WorkBuddy**：
```bash
cp -r mbb-model-smith ~/.workbuddy/skills/
```

**依赖**：核心7个脚本零依赖。Excel导出需 `pip install openpyxl`。

---

## 文件结构

```
mbb-model-smith/
├── SKILL.md                              # 主指令（272行）
├── scripts/                              # 8个Python工具
│   ├── project_payback.py
│   ├── assumption_flip_test.py
│   ├── monte_carlo_simulator.py
│   ├── excel_exporter.py
│   ├── dcf_valuation.py
│   ├── ratio_calculator.py
│   ├── budget_variance_analyzer.py
│   └── forecast_builder.py
├── references/                           # 方法论+参数
│   ├── china-market-guide.md
│   ├── valuation-methodology.md
│   ├── financial-ratios-guide.md
│   ├── forecasting-best-practices.md
│   └── industry-adaptations.md
├── assets/                               # 模板+样例
└── README.md
```

---

## 协作链

```
Spark Partner（方向判断）
       ↓
Evidence Lab（验证假设来源）
       ↓
Model Smith（财务测算）  ← here
       ↓
Draft Distiller（写报告）
       ↓
Deck Builder（做PPT）
```

---

## 致谢

基础分析工具源自 [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) finance模块。本项目在其上增加了投委会决策层（项目回收、假设翻转、蒙特卡洛、Excel导出）和中国市场适配。

## License

MIT
