#!/usr/bin/env python3
"""
Excel Report Generator for Financial Analysis

Exports financial analysis results (DCF, Monte Carlo, Forecasts, Ratios)
into a structured Excel workbook (.xlsx) suitable for investment committee review.

Uses openpyxl for Excel generation. If openpyxl is not installed, falls back to
CSV export with clear instructions.

Usage:
    python excel_exporter.py results.json --output report.xlsx
    python excel_exporter.py results.json --output report.xlsx --type dcf
    python excel_exporter.py results.json --output report.xlsx --type montecarlo
    python excel_exporter.py results.json --output report.xlsx --type forecast
    python excel_exporter.py results.json --output report.csv --fallback-csv

Supported report types:
    dcf         - DCF valuation with sensitivity table
    montecarlo  - Monte Carlo simulation summary + distribution
    forecast    - Revenue forecast with scenarios
    ratios      - Financial ratio analysis
    investment  - Project investment payback analysis
"""

import argparse
import csv
import json
import sys
from typing import Any, Dict, List

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


# McKinsey-style color scheme
HEADER_FILL = PatternFill(start_color="002960", end_color="002960", fill_type="solid") if OPENPYXL_AVAILABLE else None
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11) if OPENPYXL_AVAILABLE else None
TITLE_FONT = Font(bold=True, size=14, color="002960") if OPENPYXL_AVAILABLE else None
SUBTITLE_FONT = Font(bold=True, size=11, color="002960") if OPENPYXL_AVAILABLE else None
GREEN_FONT = Font(color="006400") if OPENPYXL_AVAILABLE else None
RED_FONT = Font(color="8B0000") if OPENPYXL_AVAILABLE else None
THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
) if OPENPYXL_AVAILABLE else None


def style_header_row(ws, row: int, max_col: int):
    """Apply McKinsey header styling to a row."""
    for col in range(1, max_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")


def auto_width(ws):
    """Auto-adjust column widths."""
    for col in ws.columns:
        max_length = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max_length + 4, 30)


def export_dcf(wb: "Workbook", data: Dict[str, Any]):
    """Export DCF valuation results to Excel."""
    ws = wb.active
    ws.title = "DCF Valuation"

    # Title
    ws["A1"] = "DCF VALUATION ANALYSIS"
    ws["A1"].font = TITLE_FONT

    # WACC
    ws["A3"] = "WACC"
    ws["A3"].font = SUBTITLE_FONT
    ws["B3"] = f"{data.get('wacc', 0) * 100:.2f}%"

    # Revenue Projections
    ws["A5"] = "Revenue Projections"
    ws["A5"].font = SUBTITLE_FONT
    headers = ["Year"] + [f"Year {i+1}" for i in range(len(data.get("projected_revenue", [])))]
    for col, h in enumerate(headers, 1):
        ws.cell(row=6, column=col, value=h)
    style_header_row(ws, 6, len(headers))

    ws.cell(row=7, column=1, value="Revenue")
    for i, rev in enumerate(data.get("projected_revenue", []), 2):
        ws.cell(row=7, column=i, value=round(rev, 0))
        ws.cell(row=7, column=i).number_format = "#,##0"

    ws.cell(row=8, column=1, value="Free Cash Flow")
    for i, fcf in enumerate(data.get("projected_fcf", []), 2):
        ws.cell(row=8, column=i, value=round(fcf, 0))
        ws.cell(row=8, column=i).number_format = "#,##0"

    # Valuation Summary
    row = 10
    ws.cell(row=row, column=1, value="Valuation Summary").font = SUBTITLE_FONT
    row += 1
    ws.cell(row=row, column=1, value="Method")
    ws.cell(row=row, column=2, value="Enterprise Value")
    ws.cell(row=row, column=3, value="Equity Value")
    style_header_row(ws, row, 3)

    row += 1
    ev = data.get("enterprise_value", {})
    eq = data.get("equity_value", {})
    ws.cell(row=row, column=1, value="Perpetuity Growth")
    ws.cell(row=row, column=2, value=round(ev.get("perpetuity_growth", 0), 0))
    ws.cell(row=row, column=3, value=round(eq.get("perpetuity_growth", 0), 0))

    row += 1
    ws.cell(row=row, column=1, value="Exit Multiple")
    ws.cell(row=row, column=2, value=round(ev.get("exit_multiple", 0), 0))
    ws.cell(row=row, column=3, value=round(eq.get("exit_multiple", 0), 0))

    # Sensitivity Table
    sens = data.get("sensitivity_analysis", {})
    if sens:
        row += 2
        ws.cell(row=row, column=1, value="Sensitivity: WACC vs Terminal Growth").font = SUBTITLE_FONT
        row += 1

        growth_vals = sens.get("growth_values", [])
        wacc_vals = sens.get("wacc_values", [])
        ev_table = sens.get("enterprise_value_table", [])

        # Header row
        ws.cell(row=row, column=1, value="WACC \\ Growth")
        for j, g in enumerate(growth_vals, 2):
            ws.cell(row=row, column=j, value=f"{g*100:.1f}%")
        style_header_row(ws, row, len(growth_vals) + 1)

        for i, w in enumerate(wacc_vals):
            row += 1
            ws.cell(row=row, column=1, value=f"{w*100:.1f}%")
            for j, val in enumerate(ev_table[i], 2):
                if val != float("inf") and val is not None:
                    ws.cell(row=row, column=j, value=round(val, 0))
                    ws.cell(row=row, column=j).number_format = "#,##0"
                else:
                    ws.cell(row=row, column=j, value="N/A")

    auto_width(ws)


def export_montecarlo(wb: "Workbook", data: Dict[str, Any]):
    """Export Monte Carlo simulation results to Excel."""
    ws = wb.active
    ws.title = "Monte Carlo Summary"

    ws["A1"] = "MONTE CARLO SIMULATION RESULTS"
    ws["A1"].font = TITLE_FONT

    # Parameters
    ws["A3"] = "Parameters"
    ws["A3"].font = SUBTITLE_FONT
    params = [
        ("Iterations", data.get("iterations", 0)),
        ("Initial Investment", data.get("initial_investment", 0)),
        ("Projection Months", data.get("projection_months", 0)),
    ]
    for i, (label, val) in enumerate(params, 4):
        ws.cell(row=i, column=1, value=label)
        ws.cell(row=i, column=2, value=val)

    # NPV Distribution
    row = 8
    ws.cell(row=row, column=1, value="NPV Distribution").font = SUBTITLE_FONT
    row += 1
    headers = ["Metric", "Value"]
    ws.cell(row=row, column=1, value="Metric")
    ws.cell(row=row, column=2, value="Value")
    style_header_row(ws, row, 2)

    npv = data.get("npv", {})
    metrics = [
        ("Mean NPV", npv.get("mean", 0)),
        ("Median NPV", npv.get("median", 0)),
        ("Std Deviation", npv.get("std_dev", 0)),
        ("Minimum", npv.get("min", 0)),
        ("Maximum", npv.get("max", 0)),
        ("P(NPV > 0)", f"{npv.get('prob_positive', 0)*100:.1f}%"),
    ]
    for label, val in metrics:
        row += 1
        ws.cell(row=row, column=1, value=label)
        ws.cell(row=row, column=2, value=val if isinstance(val, str) else round(val, 0))

    # Key Probabilities
    row += 2
    ws.cell(row=row, column=1, value="Key Probabilities").font = SUBTITLE_FONT
    row += 1
    probs = [
        ("Break-even probability", f"{data.get('probability_of_break_even', 0)*100:.1f}%"),
        ("Positive NPV probability", f"{data.get('probability_of_positive_npv', 0)*100:.1f}%"),
        ("Value at Risk (5th pct)", round(data.get("value_at_risk_5pct", 0), 0)),
    ]
    for label, val in probs:
        row += 1
        ws.cell(row=row, column=1, value=label)
        ws.cell(row=row, column=2, value=val)

    # Decision Signal
    row += 2
    prob_pos = data.get("probability_of_positive_npv", 0)
    ws.cell(row=row, column=1, value="DECISION SIGNAL").font = SUBTITLE_FONT
    row += 1
    if prob_pos >= 0.80:
        ws.cell(row=row, column=1, value="GREEN — Strong case to proceed")
        ws.cell(row=row, column=1).font = GREEN_FONT
    elif prob_pos >= 0.60:
        ws.cell(row=row, column=1, value="YELLOW — Proceed with caution")
    else:
        ws.cell(row=row, column=1, value="RED — High risk, reconsider")
        ws.cell(row=row, column=1).font = RED_FONT

    auto_width(ws)


def export_forecast(wb: "Workbook", data: Dict[str, Any]):
    """Export forecast results to Excel."""
    ws = wb.active
    ws.title = "Revenue Forecast"

    ws["A1"] = "REVENUE FORECAST"
    ws["A1"].font = TITLE_FONT

    forecasts = data.get("forecasts", data.get("scenarios", {}))
    if isinstance(forecasts, dict):
        row = 3
        for scenario_name, values in forecasts.items():
            ws.cell(row=row, column=1, value=f"Scenario: {scenario_name}").font = SUBTITLE_FONT
            row += 1
            if isinstance(values, list):
                ws.cell(row=row, column=1, value="Period")
                ws.cell(row=row, column=2, value="Revenue")
                style_header_row(ws, row, 2)
                for i, val in enumerate(values, 1):
                    row += 1
                    ws.cell(row=row, column=1, value=f"Period {i}")
                    ws.cell(row=row, column=2, value=round(val, 0))
            row += 2

    auto_width(ws)


def export_to_csv(data: Dict[str, Any], output_path: str):
    """Fallback: export as CSV when openpyxl is unavailable."""
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Key", "Value"])

        def flatten(d: Dict, prefix: str = ""):
            for k, v in d.items():
                key = f"{prefix}.{k}" if prefix else k
                if isinstance(v, dict):
                    flatten(v, key)
                elif isinstance(v, list):
                    writer.writerow([key, json.dumps(v)])
                else:
                    writer.writerow([key, v])

        flatten(data)

    print(f"CSV exported to: {output_path}")
    print("Note: Install openpyxl for proper Excel formatting: pip install openpyxl")


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Excel Report Generator for Financial Analysis")
    parser.add_argument("input_file", help="Path to JSON results file")
    parser.add_argument("--output", "-o", required=True, help="Output file path (.xlsx or .csv)")
    parser.add_argument(
        "--type", "-t",
        choices=["dcf", "montecarlo", "forecast", "ratios", "investment"],
        default="dcf",
        help="Report type (default: dcf)",
    )
    parser.add_argument("--fallback-csv", action="store_true", help="Force CSV output even if openpyxl available")

    args = parser.parse_args()

    try:
        with open(args.input_file, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: File '{args.input_file}' not found.", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    if args.fallback_csv or not OPENPYXL_AVAILABLE:
        csv_path = args.output.replace(".xlsx", ".csv") if args.output.endswith(".xlsx") else args.output
        export_to_csv(data, csv_path)
        if not OPENPYXL_AVAILABLE:
            print("\nTo generate proper Excel files, install openpyxl:")
            print("  pip install openpyxl")
        return

    wb = Workbook()
    exporters = {
        "dcf": export_dcf,
        "montecarlo": export_montecarlo,
        "forecast": export_forecast,
    }

    exporter = exporters.get(args.type, export_dcf)
    exporter(wb, data)

    wb.save(args.output)
    print(f"Excel report saved to: {args.output}")
    print(f"Report type: {args.type}")


if __name__ == "__main__":
    main()
