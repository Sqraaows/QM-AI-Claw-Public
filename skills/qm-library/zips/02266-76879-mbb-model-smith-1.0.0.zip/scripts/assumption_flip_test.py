#!/usr/bin/env python3
"""
Assumption Flip Test — 假设翻转测试

逐一翻转关键假设，找到"致命假设"——改变它就能翻转整个结论的那一个。

投委会不想看WACC vs terminal growth的学术二维表。
他们想知道："如果月坪效从5万降到3万，结论还成不成立？"

Uses standard library only - NO numpy/pandas.

Usage:
    python assumption_flip_test.py project_data.json
    python assumption_flip_test.py project_data.json --format json
    python assumption_flip_test.py project_data.json --stress 0.3

Input JSON format:
{
    "project_name": "无人咖啡车",
    "initial_investment": 250000,
    "base_assumptions": {
        "monthly_revenue": 50000,
        "variable_cost_rate": 0.35,
        "fixed_monthly_cost": 18000,
        "growth_rate_monthly": 0.02,
        "units": 1
    },
    "projection_months": 36,
    "hurdle_rate_annual": 0.15,
    "stress_levels": [0.1, 0.2, 0.3, 0.4, 0.5],
    "assumption_labels": {
        "monthly_revenue": "月营收",
        "variable_cost_rate": "可变成本率",
        "fixed_monthly_cost": "月固定成本",
        "growth_rate_monthly": "月增长率",
        "units": "设备数量"
    }
}
"""

import argparse
import json
import math
import sys
from typing import Any, Dict, List, Optional, Tuple


def calculate_npv_simple(
    initial_investment: float,
    monthly_revenue: float,
    variable_cost_rate: float,
    fixed_monthly_cost: float,
    growth_rate: float,
    units: int,
    projection_months: int,
    hurdle_rate_annual: float,
) -> float:
    """Quick NPV calculation for a single scenario."""
    monthly_rate = (1 + hurdle_rate_annual) ** (1/12) - 1
    npv = -initial_investment
    current_rev = monthly_revenue

    for month in range(1, projection_months + 1):
        gross_rev = current_rev * units
        variable_costs = gross_rev * variable_cost_rate
        net_cf = gross_rev - variable_costs - fixed_monthly_cost
        npv += net_cf / ((1 + monthly_rate) ** month)
        current_rev *= (1 + growth_rate)

    return npv


def calculate_breakeven_simple(
    initial_investment: float,
    monthly_revenue: float,
    variable_cost_rate: float,
    fixed_monthly_cost: float,
    growth_rate: float,
    units: int,
    projection_months: int,
) -> Optional[int]:
    """Quick breakeven calculation."""
    cumulative = -initial_investment
    current_rev = monthly_revenue

    for month in range(1, projection_months + 1):
        gross_rev = current_rev * units
        variable_costs = gross_rev * variable_cost_rate
        net_cf = gross_rev - variable_costs - fixed_monthly_cost
        cumulative += net_cf
        if cumulative >= 0:
            return month
        current_rev *= (1 + growth_rate)

    return None


def flip_assumption(
    base_assumptions: Dict[str, float],
    assumption_key: str,
    stress_pct: float,
    initial_investment: float,
    projection_months: int,
    hurdle_rate: float,
) -> Dict[str, Any]:
    """
    Apply stress to one assumption and recalculate.
    
    For revenue/growth/units: stress means decrease (pessimistic)
    For costs: stress means increase (pessimistic)
    """
    stressed = base_assumptions.copy()

    # Determine direction: revenue-side decreases, cost-side increases
    revenue_side = ["monthly_revenue", "growth_rate_monthly", "units"]
    
    if assumption_key in revenue_side:
        stressed[assumption_key] = base_assumptions[assumption_key] * (1 - stress_pct)
    else:
        stressed[assumption_key] = base_assumptions[assumption_key] * (1 + stress_pct)

    npv = calculate_npv_simple(
        initial_investment=initial_investment,
        monthly_revenue=stressed.get("monthly_revenue", 0),
        variable_cost_rate=stressed.get("variable_cost_rate", 0),
        fixed_monthly_cost=stressed.get("fixed_monthly_cost", 0),
        growth_rate=stressed.get("growth_rate_monthly", 0),
        units=int(stressed.get("units", 1)),
        projection_months=projection_months,
        hurdle_rate_annual=hurdle_rate,
    )

    breakeven = calculate_breakeven_simple(
        initial_investment=initial_investment,
        monthly_revenue=stressed.get("monthly_revenue", 0),
        variable_cost_rate=stressed.get("variable_cost_rate", 0),
        fixed_monthly_cost=stressed.get("fixed_monthly_cost", 0),
        growth_rate=stressed.get("growth_rate_monthly", 0),
        units=int(stressed.get("units", 1)),
        projection_months=projection_months,
    )

    return {
        "stressed_value": stressed[assumption_key],
        "npv": npv,
        "breakeven_month": breakeven,
        "conclusion_flipped": npv < 0,  # If NPV was positive in base, now negative = flipped
    }


def run_flip_test(
    project_name: str,
    initial_investment: float,
    base_assumptions: Dict[str, float],
    projection_months: int,
    hurdle_rate: float,
    stress_levels: List[float],
    assumption_labels: Dict[str, str],
) -> Dict[str, Any]:
    """Run flip test on all assumptions."""

    # First calculate base case
    base_npv = calculate_npv_simple(
        initial_investment=initial_investment,
        monthly_revenue=base_assumptions.get("monthly_revenue", 0),
        variable_cost_rate=base_assumptions.get("variable_cost_rate", 0),
        fixed_monthly_cost=base_assumptions.get("fixed_monthly_cost", 0),
        growth_rate=base_assumptions.get("growth_rate_monthly", 0),
        units=int(base_assumptions.get("units", 1)),
        projection_months=projection_months,
        hurdle_rate_annual=hurdle_rate,
    )

    base_breakeven = calculate_breakeven_simple(
        initial_investment=initial_investment,
        monthly_revenue=base_assumptions.get("monthly_revenue", 0),
        variable_cost_rate=base_assumptions.get("variable_cost_rate", 0),
        fixed_monthly_cost=base_assumptions.get("fixed_monthly_cost", 0),
        growth_rate=base_assumptions.get("growth_rate_monthly", 0),
        units=int(base_assumptions.get("units", 1)),
        projection_months=projection_months,
    )

    base_positive = base_npv > 0

    # Test each assumption at each stress level
    results_by_assumption = {}
    fatal_assumptions = []

    for key, label in assumption_labels.items():
        if key not in base_assumptions:
            continue

        stress_results = []
        flip_threshold = None

        for stress in stress_levels:
            result = flip_assumption(
                base_assumptions, key, stress,
                initial_investment, projection_months, hurdle_rate
            )
            result["stress_pct"] = stress
            stress_results.append(result)

            # Find the first stress level that flips the conclusion
            if base_positive and result["conclusion_flipped"] and flip_threshold is None:
                flip_threshold = stress

        results_by_assumption[key] = {
            "label": label,
            "base_value": base_assumptions[key],
            "stress_results": stress_results,
            "flip_threshold": flip_threshold,
            "is_fatal": flip_threshold is not None and flip_threshold <= 0.3,
        }

        if results_by_assumption[key]["is_fatal"]:
            fatal_assumptions.append({
                "key": key,
                "label": label,
                "flip_at": flip_threshold,
                "base_value": base_assumptions[key],
            })

    # Sort fatal assumptions by how easily they flip (lowest threshold first)
    fatal_assumptions.sort(key=lambda x: x["flip_at"])

    return {
        "project_name": project_name,
        "base_case": {
            "npv": base_npv,
            "breakeven_month": base_breakeven,
            "conclusion": "PROCEED" if base_positive else "DO NOT PROCEED",
        },
        "results_by_assumption": results_by_assumption,
        "fatal_assumptions": fatal_assumptions,
        "total_assumptions_tested": len(assumption_labels),
        "fatal_count": len(fatal_assumptions),
    }


def format_text(results: Dict[str, Any]) -> str:
    """Format flip test results as human-readable text."""
    lines = []
    lines.append("=" * 70)
    lines.append(f"假设翻转测试：{results['project_name']}")
    lines.append("=" * 70)

    def fmt(val: float) -> str:
        if abs(val) >= 1e4:
            return f"¥{val/1e4:,.2f}万"
        return f"¥{val:,.0f}"

    # Base case
    base = results["base_case"]
    lines.append(f"\n--- 基准情景 ---")
    lines.append(f"  NPV: {fmt(base['npv'])}")
    lines.append(f"  回收期: {base['breakeven_month'] or '未回本'}个月")
    lines.append(f"  基准结论: {base['conclusion']}")

    # Fatal assumptions (MOST IMPORTANT)
    lines.append(f"\n--- ⚠️ 致命假设（恶化≤30%即翻转结论） ---")
    fatal = results["fatal_assumptions"]
    if fatal:
        for i, f_item in enumerate(fatal, 1):
            lines.append(f"\n  致命假设 #{i}: {f_item['label']}")
            lines.append(f"  基准值: {f_item['base_value']}")
            lines.append(f"  翻转阈值: 恶化 {f_item['flip_at']*100:.0f}% 即结论翻转")
            # Calculate what the flipped value is
            key = f_item["key"]
            revenue_side = ["monthly_revenue", "growth_rate_monthly", "units"]
            if key in revenue_side:
                flipped_val = f_item["base_value"] * (1 - f_item["flip_at"])
                lines.append(f"  即: {f_item['label']}从 {f_item['base_value']} 降到 {flipped_val:.2f} 就完蛋")
            else:
                flipped_val = f_item["base_value"] * (1 + f_item["flip_at"])
                lines.append(f"  即: {f_item['label']}从 {f_item['base_value']} 涨到 {flipped_val:.2f} 就完蛋")
    else:
        lines.append("  无致命假设 — 所有假设恶化30%后结论仍然成立 ✅")

    # Detailed results
    lines.append(f"\n--- 逐项压力测试详情 ---")
    for key, data in results["results_by_assumption"].items():
        fatal_tag = " ⚠️ 致命" if data["is_fatal"] else ""
        lines.append(f"\n  📊 {data['label']}{fatal_tag}（基准值: {data['base_value']}）")
        lines.append(f"  {'恶化幅度':>8s}  {'调整后值':>10s}  {'NPV':>12s}  {'回收期':>6s}  {'结论翻转':>6s}")
        lines.append(f"  {'-'*8}  {'-'*10}  {'-'*12}  {'-'*6}  {'-'*6}")
        for sr in data["stress_results"]:
            flipped_mark = "❌ 翻转" if sr["conclusion_flipped"] else "✅ 成立"
            be_str = f"{sr['breakeven_month']}月" if sr["breakeven_month"] else "未回本"
            lines.append(f"  {sr['stress_pct']*100:>6.0f}%  {sr['stressed_value']:>10.2f}  {fmt(sr['npv']):>12s}  {be_str:>6s}  {flipped_mark}")

    # Summary advice
    lines.append(f"\n--- 投委会建议 ---")
    if len(fatal) == 0:
        lines.append("  结论稳健：即使假设全部恶化30%，项目仍然值得做。")
    elif len(fatal) == 1:
        lines.append(f"  注意一个关键风险：{fatal[0]['label']}是唯一致命假设。")
        lines.append(f"  建议在POC中优先验证这个数字的可靠性。")
    else:
        lines.append(f"  ⚠️ 存在{len(fatal)}个致命假设，项目抗风险能力较弱：")
        for f_item in fatal:
            lines.append(f"    - {f_item['label']}（恶化{f_item['flip_at']*100:.0f}%即翻转）")
        lines.append(f"  建议：缩小试点规模，先用最小投入验证这些假设。")

    lines.append("\n" + "=" * 70)
    return "\n".join(lines)


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(description="假设翻转测试")
    parser.add_argument("input_file", help="JSON输入文件路径")
    parser.add_argument("--format", choices=["text", "json"], default="text")
    parser.add_argument("--stress", type=float, default=None,
                        help="单一压力测试幅度（如0.3=恶化30%），用于快速测试")

    args = parser.parse_args()

    try:
        with open(args.input_file, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: 文件 '{args.input_file}' 不存在。", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: JSON格式错误: {e}", file=sys.stderr)
        sys.exit(1)

    stress_levels = data.get("stress_levels", [0.1, 0.2, 0.3, 0.4, 0.5])
    if args.stress:
        stress_levels = [args.stress]

    results = run_flip_test(
        project_name=data.get("project_name", "未命名"),
        initial_investment=data["initial_investment"],
        base_assumptions=data["base_assumptions"],
        projection_months=data.get("projection_months", 36),
        hurdle_rate=data.get("hurdle_rate_annual", 0.15),
        stress_levels=stress_levels,
        assumption_labels=data.get("assumption_labels", {k: k for k in data["base_assumptions"]}),
    )

    if args.format == "json":
        print(json.dumps(results, indent=2, ensure_ascii=False, default=str))
    else:
        print(format_text(results))


if __name__ == "__main__":
    main()
