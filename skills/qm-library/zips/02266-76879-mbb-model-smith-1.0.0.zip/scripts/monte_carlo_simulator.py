#!/usr/bin/env python3
"""
Monte Carlo Simulation for Financial Projections

Runs N iterations (default 1000) with randomized assumptions to produce
probability distributions for key outcomes (NPV, IRR, Payback Period).

Uses standard library only (random, statistics, math, json) - NO numpy/scipy.

Usage:
    python monte_carlo_simulator.py simulation_data.json
    python monte_carlo_simulator.py simulation_data.json --iterations 5000
    python monte_carlo_simulator.py simulation_data.json --format json
    python monte_carlo_simulator.py simulation_data.json --percentiles 10,25,50,75,90

Input JSON format:
{
    "initial_investment": 2000000,
    "projection_months": 36,
    "assumptions": {
        "monthly_revenue": {"min": 30000, "base": 50000, "max": 80000},
        "monthly_cost": {"min": 15000, "base": 25000, "max": 40000},
        "growth_rate_monthly": {"min": 0.01, "base": 0.03, "max": 0.06},
        "churn_rate_monthly": {"min": 0.01, "base": 0.03, "max": 0.05}
    },
    "discount_rate_annual": 0.10
}
"""

import argparse
import json
import math
import random
import sys
from statistics import mean, median, stdev, quantiles
from typing import Any, Dict, List, Optional, Tuple


def triangular_sample(min_val: float, mode_val: float, max_val: float) -> float:
    """Sample from triangular distribution (models expert estimates with min/base/max)."""
    return random.triangular(min_val, max_val, mode_val)


def calculate_npv(cash_flows: List[float], discount_rate_monthly: float) -> float:
    """Calculate Net Present Value of a series of monthly cash flows."""
    npv = 0.0
    for t, cf in enumerate(cash_flows):
        npv += cf / ((1 + discount_rate_monthly) ** (t + 1))
    return npv


def calculate_payback_months(initial_investment: float, cash_flows: List[float]) -> Optional[int]:
    """Calculate payback period in months. Returns None if never pays back."""
    cumulative = -initial_investment
    for month, cf in enumerate(cash_flows, 1):
        cumulative += cf
        if cumulative >= 0:
            return month
    return None


def calculate_irr(initial_investment: float, cash_flows: List[float], max_iter: int = 100) -> Optional[float]:
    """Calculate IRR using bisection method. Returns annualized rate or None."""
    if not cash_flows or all(cf <= 0 for cf in cash_flows):
        return None

    all_flows = [-initial_investment] + cash_flows

    def npv_at_rate(r: float) -> float:
        return sum(cf / ((1 + r) ** t) for t, cf in enumerate(all_flows))

    low, high = -0.5, 5.0
    if npv_at_rate(low) < 0:
        return None

    for _ in range(max_iter):
        mid = (low + high) / 2
        val = npv_at_rate(mid)
        if abs(val) < 0.01:
            # Convert monthly IRR to annual
            return (1 + mid) ** 12 - 1
        if val > 0:
            low = mid
        else:
            high = mid

    return (1 + (low + high) / 2) ** 12 - 1


def run_single_simulation(
    initial_investment: float,
    projection_months: int,
    assumptions: Dict[str, Dict[str, float]],
    discount_rate_monthly: float,
) -> Dict[str, Any]:
    """Run a single Monte Carlo iteration."""
    # Sample assumptions from triangular distributions
    monthly_rev = triangular_sample(
        assumptions["monthly_revenue"]["min"],
        assumptions["monthly_revenue"]["base"],
        assumptions["monthly_revenue"]["max"],
    )
    monthly_cost = triangular_sample(
        assumptions["monthly_cost"]["min"],
        assumptions["monthly_cost"]["base"],
        assumptions["monthly_cost"]["max"],
    )
    growth_rate = triangular_sample(
        assumptions["growth_rate_monthly"]["min"],
        assumptions["growth_rate_monthly"]["base"],
        assumptions["growth_rate_monthly"]["max"],
    )
    churn_rate = triangular_sample(
        assumptions.get("churn_rate_monthly", {}).get("min", 0),
        assumptions.get("churn_rate_monthly", {}).get("base", 0),
        assumptions.get("churn_rate_monthly", {}).get("max", 0),
    )

    # Generate monthly cash flows
    cash_flows = []
    current_rev = monthly_rev
    current_cost = monthly_cost

    for month in range(projection_months):
        net_cf = current_rev - current_cost
        cash_flows.append(net_cf)
        # Apply growth and churn
        current_rev *= (1 + growth_rate - churn_rate)
        # Cost grows slower (scale economies)
        current_cost *= (1 + growth_rate * 0.4)

    npv = calculate_npv(cash_flows, discount_rate_monthly)
    payback = calculate_payback_months(initial_investment, cash_flows)
    irr = calculate_irr(initial_investment, cash_flows)
    total_profit = sum(cash_flows) - initial_investment

    return {
        "npv": npv - initial_investment,
        "irr": irr,
        "payback_months": payback,
        "total_profit": total_profit,
        "break_even": payback is not None,
    }


def run_monte_carlo(
    initial_investment: float,
    projection_months: int,
    assumptions: Dict[str, Dict[str, float]],
    discount_rate_annual: float,
    iterations: int = 1000,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Run full Monte Carlo simulation."""
    if seed is not None:
        random.seed(seed)

    discount_rate_monthly = (1 + discount_rate_annual) ** (1 / 12) - 1

    results = []
    for _ in range(iterations):
        result = run_single_simulation(
            initial_investment, projection_months, assumptions, discount_rate_monthly
        )
        results.append(result)

    # Aggregate results
    npvs = [r["npv"] for r in results]
    irrs = [r["irr"] for r in results if r["irr"] is not None]
    paybacks = [r["payback_months"] for r in results if r["payback_months"] is not None]
    profits = [r["total_profit"] for r in results]
    break_even_count = sum(1 for r in results if r["break_even"])

    def safe_percentiles(data: List[float], pcts: List[float]) -> Dict[str, float]:
        if len(data) < 2:
            return {f"p{int(p*100)}": data[0] if data else 0 for p in pcts}
        sorted_data = sorted(data)
        result = {}
        for p in pcts:
            idx = p * (len(sorted_data) - 1)
            low = int(math.floor(idx))
            high = int(math.ceil(idx))
            if low == high:
                result[f"p{int(p*100)}"] = sorted_data[low]
            else:
                weight = idx - low
                result[f"p{int(p*100)}"] = sorted_data[low] * (1 - weight) + sorted_data[high] * weight
            return result
        return result

    pcts = [0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95]

    def get_percentiles(data: List[float]) -> Dict[str, float]:
        if len(data) < 2:
            return {}
        sorted_d = sorted(data)
        n = len(sorted_d)
        result = {}
        for p in pcts:
            idx = p * (n - 1)
            low = int(math.floor(idx))
            high = min(int(math.ceil(idx)), n - 1)
            weight = idx - low
            result[f"p{int(p*100)}"] = sorted_d[low] * (1 - weight) + sorted_d[high] * weight
        return result

    summary = {
        "iterations": iterations,
        "initial_investment": initial_investment,
        "projection_months": projection_months,
        "npv": {
            "mean": mean(npvs),
            "median": median(npvs),
            "std_dev": stdev(npvs) if len(npvs) > 1 else 0,
            "min": min(npvs),
            "max": max(npvs),
            "percentiles": get_percentiles(npvs),
            "prob_positive": sum(1 for x in npvs if x > 0) / len(npvs),
        },
        "irr": {
            "mean": mean(irrs) if irrs else None,
            "median": median(irrs) if irrs else None,
            "std_dev": stdev(irrs) if len(irrs) > 1 else 0,
            "percentiles": get_percentiles(irrs) if irrs else {},
            "sample_size": len(irrs),
        },
        "payback_months": {
            "mean": mean(paybacks) if paybacks else None,
            "median": median(paybacks) if paybacks else None,
            "min": min(paybacks) if paybacks else None,
            "max": max(paybacks) if paybacks else None,
            "percentiles": get_percentiles([float(p) for p in paybacks]) if paybacks else {},
        },
        "total_profit": {
            "mean": mean(profits),
            "median": median(profits),
            "percentiles": get_percentiles(profits),
        },
        "probability_of_break_even": break_even_count / iterations,
        "probability_of_positive_npv": sum(1 for x in npvs if x > 0) / iterations,
        "value_at_risk_5pct": sorted(npvs)[int(0.05 * len(npvs))],
    }

    return summary


def format_text(summary: Dict[str, Any]) -> str:
    """Format simulation results as human-readable text."""
    lines = []
    lines.append("=" * 70)
    lines.append("MONTE CARLO SIMULATION RESULTS")
    lines.append("=" * 70)

    def fmt(val: float) -> str:
        if val is None:
            return "N/A"
        if abs(val) >= 1e6:
            return f"${val/1e6:,.2f}M"
        if abs(val) >= 1e3:
            return f"${val/1e3:,.1f}K"
        return f"${val:,.0f}"

    lines.append(f"\nSimulation Parameters:")
    lines.append(f"  Iterations: {summary['iterations']:,}")
    lines.append(f"  Initial Investment: {fmt(summary['initial_investment'])}")
    lines.append(f"  Projection Period: {summary['projection_months']} months")

    lines.append(f"\n--- NPV DISTRIBUTION ---")
    npv = summary["npv"]
    lines.append(f"  Mean:    {fmt(npv['mean'])}")
    lines.append(f"  Median:  {fmt(npv['median'])}")
    lines.append(f"  Std Dev: {fmt(npv['std_dev'])}")
    lines.append(f"  Range:   {fmt(npv['min'])} to {fmt(npv['max'])}")
    lines.append(f"  P(NPV > 0): {npv['prob_positive']*100:.1f}%")
    if npv["percentiles"]:
        lines.append(f"  P10: {fmt(npv['percentiles'].get('p10', 0))}  |  P50: {fmt(npv['percentiles'].get('p50', 0))}  |  P90: {fmt(npv['percentiles'].get('p90', 0))}")

    lines.append(f"\n--- IRR DISTRIBUTION ---")
    irr = summary["irr"]
    if irr["mean"] is not None:
        lines.append(f"  Mean:   {irr['mean']*100:.1f}% annual")
        lines.append(f"  Median: {irr['median']*100:.1f}% annual")
        lines.append(f"  (Based on {irr['sample_size']}/{summary['iterations']} converged iterations)")
    else:
        lines.append(f"  Could not calculate IRR for this scenario")

    lines.append(f"\n--- PAYBACK PERIOD ---")
    pb = summary["payback_months"]
    if pb["mean"] is not None:
        lines.append(f"  Mean:   {pb['mean']:.1f} months")
        lines.append(f"  Median: {pb['median']:.0f} months")
        lines.append(f"  Range:  {pb['min']} to {pb['max']} months")
    else:
        lines.append(f"  Project does not break even in most scenarios")

    lines.append(f"\n--- KEY PROBABILITIES ---")
    lines.append(f"  Probability of break-even:  {summary['probability_of_break_even']*100:.1f}%")
    lines.append(f"  Probability of NPV > 0:     {summary['probability_of_positive_npv']*100:.1f}%")
    lines.append(f"  Value at Risk (5th pct):    {fmt(summary['value_at_risk_5pct'])}")

    lines.append(f"\n--- DECISION SIGNAL ---")
    prob_positive = summary["probability_of_positive_npv"]
    if prob_positive >= 0.80:
        lines.append(f"  🟢 GREEN: {prob_positive*100:.0f}% probability of positive NPV — strong case to proceed")
    elif prob_positive >= 0.60:
        lines.append(f"  🟡 YELLOW: {prob_positive*100:.0f}% probability of positive NPV — proceed with caution, monitor assumptions")
    else:
        lines.append(f"  🔴 RED: {prob_positive*100:.0f}% probability of positive NPV — high risk, reconsider or de-risk")

    lines.append("\n" + "=" * 70)
    return "\n".join(lines)


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Monte Carlo Simulation for Financial Projections"
    )
    parser.add_argument("input_file", help="Path to JSON file with simulation parameters")
    parser.add_argument("--iterations", type=int, default=1000, help="Number of iterations (default: 1000)")
    parser.add_argument("--format", choices=["text", "json"], default="text", help="Output format")
    parser.add_argument("--seed", type=int, default=None, help="Random seed for reproducibility")

    args = parser.parse_args()

    try:
        with open(args.input_file, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: File '{args.input_file}' not found.", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    summary = run_monte_carlo(
        initial_investment=data["initial_investment"],
        projection_months=data["projection_months"],
        assumptions=data["assumptions"],
        discount_rate_annual=data.get("discount_rate_annual", 0.10),
        iterations=args.iterations,
        seed=args.seed,
    )

    if args.format == "json":
        print(json.dumps(summary, indent=2, default=str))
    else:
        print(format_text(summary))


if __name__ == "__main__":
    main()
