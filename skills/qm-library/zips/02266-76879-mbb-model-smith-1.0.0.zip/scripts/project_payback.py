#!/usr/bin/env python3
"""
Project Payback Model — 单项目投资回收分析

不是给公司估值，是回答投委会最关心的问题：
"投多少、多久回本、之后能赚多少"

输入：初始投资 + 月度假设 → 输出：Break-even月份 + 累计回报曲线 + 信号灯

Uses standard library only - NO numpy/pandas.

Usage:
    python project_payback.py project_data.json
    python project_payback.py project_data.json --format json
    python project_payback.py project_data.json --months 60

Input JSON format:
{
    "project_name": "无人咖啡车进商场",
    "initial_investment": 250000,
    "monthly_assumptions": {
        "revenue_per_unit": 50000,
        "units": 1,
        "variable_cost_rate": 0.35,
        "fixed_monthly_cost": 18000,
        "revenue_growth_monthly": 0.02,
        "ramp_up_months": 3,
        "ramp_up_factor": [0.4, 0.7, 0.9]
    },
    "projection_months": 36,
    "hurdle_rate_annual": 0.15,
    "useful_life_months": 60
}
"""

import argparse
import json
import math
import sys
from typing import Any, Dict, List, Optional, Tuple


def calculate_monthly_cash_flows(
    initial_investment: float,
    assumptions: Dict[str, Any],
    projection_months: int,
) -> List[Dict[str, float]]:
    """Generate monthly cash flow schedule with ramp-up."""
    revenue_per_unit = assumptions.get("revenue_per_unit", 0)
    units = assumptions.get("units", 1)
    variable_cost_rate = assumptions.get("variable_cost_rate", 0.35)
    fixed_monthly_cost = assumptions.get("fixed_monthly_cost", 0)
    growth_rate = assumptions.get("revenue_growth_monthly", 0)
    ramp_up_months = assumptions.get("ramp_up_months", 0)
    ramp_up_factor = assumptions.get("ramp_up_factor", [])

    schedule = []
    cumulative = -initial_investment
    current_revenue_per_unit = revenue_per_unit

    for month in range(1, projection_months + 1):
        # Apply ramp-up factor
        if month <= ramp_up_months and month <= len(ramp_up_factor):
            ramp = ramp_up_factor[month - 1]
        else:
            ramp = 1.0

        # Calculate monthly P&L
        gross_revenue = current_revenue_per_unit * units * ramp
        variable_costs = gross_revenue * variable_cost_rate
        gross_profit = gross_revenue - variable_costs
        net_cash_flow = gross_profit - fixed_monthly_cost
        cumulative += net_cash_flow

        schedule.append({
            "month": month,
            "revenue": round(gross_revenue, 2),
            "variable_costs": round(variable_costs, 2),
            "fixed_costs": round(fixed_monthly_cost, 2),
            "net_cash_flow": round(net_cash_flow, 2),
            "cumulative": round(cumulative, 2),
        })

        # Apply growth after ramp-up
        if month >= ramp_up_months:
            current_revenue_per_unit *= (1 + growth_rate)

    return schedule


def find_breakeven_month(schedule: List[Dict[str, float]]) -> Optional[int]:
    """Find the month where cumulative cash flow turns positive."""
    for entry in schedule:
        if entry["cumulative"] >= 0:
            return entry["month"]
    return None


def calculate_project_irr(
    initial_investment: float,
    monthly_cash_flows: List[float],
    max_iter: int = 200,
) -> Optional[float]:
    """Calculate monthly IRR, return annualized."""
    if not monthly_cash_flows or all(cf <= 0 for cf in monthly_cash_flows):
        return None

    all_flows = [-initial_investment] + monthly_cash_flows

    def npv_at_rate(r: float) -> float:
        return sum(cf / ((1 + r) ** t) for t, cf in enumerate(all_flows))

    # Bisection
    low, high = -0.1, 2.0
    try:
        if npv_at_rate(low) < 0:
            return None
    except (OverflowError, ZeroDivisionError):
        return None

    for _ in range(max_iter):
        mid = (low + high) / 2
        try:
            val = npv_at_rate(mid)
        except (OverflowError, ZeroDivisionError):
            high = mid
            continue
        if abs(val) < 1.0:
            return (1 + mid) ** 12 - 1
        if val > 0:
            low = mid
        else:
            high = mid

    return (1 + (low + high) / 2) ** 12 - 1


def calculate_project_npv(
    initial_investment: float,
    monthly_cash_flows: List[float],
    annual_discount_rate: float,
) -> float:
    """Calculate NPV using monthly discounting."""
    monthly_rate = (1 + annual_discount_rate) ** (1/12) - 1
    npv = -initial_investment
    for t, cf in enumerate(monthly_cash_flows, 1):
        npv += cf / ((1 + monthly_rate) ** t)
    return npv


def determine_signal(
    npv: float,
    irr: Optional[float],
    hurdle_rate: float,
    breakeven_month: Optional[int],
    useful_life_months: int,
    projection_months: int,
) -> Dict[str, Any]:
    """Determine Go/No-Go signal based on multiple criteria."""
    signals = []
    overall = "GREEN"

    # Check NPV
    if npv < 0:
        signals.append({"metric": "NPV", "status": "RED", "reason": f"NPV为负（{npv:,.0f}元），项目在资金成本下亏钱"})
        overall = "RED"
    else:
        signals.append({"metric": "NPV", "status": "GREEN", "reason": f"NPV为正（{npv:,.0f}元）"})

    # Check IRR vs hurdle
    if irr is not None:
        if irr < hurdle_rate * 0.5:
            signals.append({"metric": "IRR", "status": "RED", "reason": f"IRR（{irr*100:.1f}%）远低于门槛率（{hurdle_rate*100:.0f}%）"})
            overall = "RED"
        elif irr < hurdle_rate:
            signals.append({"metric": "IRR", "status": "YELLOW", "reason": f"IRR（{irr*100:.1f}%）低于门槛率（{hurdle_rate*100:.0f}%），但接近"})
            if overall != "RED":
                overall = "YELLOW"
        else:
            signals.append({"metric": "IRR", "status": "GREEN", "reason": f"IRR（{irr*100:.1f}%）高于门槛率（{hurdle_rate*100:.0f}%）"})
    else:
        signals.append({"metric": "IRR", "status": "RED", "reason": "无法计算IRR（项目在投影期内不盈利）"})
        overall = "RED"

    # Check payback vs useful life
    if breakeven_month is None:
        signals.append({"metric": "回收期", "status": "RED", "reason": f"在{projection_months}个月内无法回本"})
        overall = "RED"
    elif breakeven_month > useful_life_months * 0.8:
        signals.append({"metric": "回收期", "status": "RED", "reason": f"回收期（{breakeven_month}月）接近或超过设备寿命（{useful_life_months}月），几乎不赚钱"})
        overall = "RED"
    elif breakeven_month > useful_life_months * 0.5:
        signals.append({"metric": "回收期", "status": "YELLOW", "reason": f"回收期（{breakeven_month}月）超过设备寿命一半，留给赚钱的时间不多"})
        if overall != "RED":
            overall = "YELLOW"
    else:
        signals.append({"metric": "回收期", "status": "GREEN", "reason": f"回收期{breakeven_month}个月，之后还有{useful_life_months - breakeven_month}个月净赚期"})

    return {"overall": overall, "signals": signals}


def format_text(results: Dict[str, Any]) -> str:
    """Format project payback results as human-readable text."""
    lines = []
    lines.append("=" * 70)
    lines.append(f"项目投资回收分析：{results['project_name']}")
    lines.append("=" * 70)

    def fmt(val: float) -> str:
        if abs(val) >= 1e6:
            return f"¥{val/1e4:,.1f}万"
        if abs(val) >= 1e4:
            return f"¥{val/1e4:,.2f}万"
        return f"¥{val:,.0f}"

    # 一句话总结（叙事层）
    lines.append("")
    lines.append("【一句话版本】")
    inv = results["initial_investment"]
    be = results["breakeven_month"]
    total_profit = results["total_profit_at_end"]
    if be:
        lines.append(f"投{fmt(inv)}，{be}个月回本，{results['projection_months']}个月累计净赚{fmt(total_profit)}。")
    else:
        lines.append(f"投{fmt(inv)}，在{results['projection_months']}个月内无法回本。累计亏损{fmt(abs(total_profit))}。")
    lines.append("")

    # 信号灯
    signal = results["signal"]
    signal_icon = {"GREEN": "🟢", "YELLOW": "🟡", "RED": "🔴"}[signal["overall"]]
    lines.append(f"--- 决策信号：{signal_icon} {signal['overall']} ---")
    for s in signal["signals"]:
        icon = {"GREEN": "✅", "YELLOW": "⚠️", "RED": "❌"}[s["status"]]
        lines.append(f"  {icon} {s['metric']}：{s['reason']}")
    lines.append("")

    # 关键指标
    lines.append("--- 关键指标 ---")
    lines.append(f"  初始投资：{fmt(inv)}")
    lines.append(f"  Break-even：{be if be else '未回本'}个月")
    irr = results.get("irr")
    lines.append(f"  项目IRR：{irr*100:.1f}%（年化）" if irr else "  项目IRR：无法计算")
    lines.append(f"  项目NPV：{fmt(results['npv'])}（折现率{results['hurdle_rate']*100:.0f}%）")
    lines.append(f"  {results['projection_months']}个月累计利润：{fmt(total_profit)}")
    lines.append("")

    # 月度现金流摘要（每6个月一个点）
    lines.append("--- 累计回报曲线（每6月） ---")
    schedule = results["schedule"]
    lines.append(f"  {'月份':>4s}  {'月净现金流':>12s}  {'累计':>12s}  {'状态':>6s}")
    lines.append(f"  {'-'*4}  {'-'*12}  {'-'*12}  {'-'*6}")
    for entry in schedule:
        if entry["month"] % 6 == 0 or entry["month"] == 1 or (be and entry["month"] == be):
            status = "📍回本" if be and entry["month"] == be else ""
            lines.append(f"  {entry['month']:>4d}  {fmt(entry['net_cash_flow']):>12s}  {fmt(entry['cumulative']):>12s}  {status}")

    lines.append("")
    lines.append("=" * 70)
    return "\n".join(lines)


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(description="项目投资回收分析")
    parser.add_argument("input_file", help="JSON输入文件路径")
    parser.add_argument("--format", choices=["text", "json"], default="text")
    parser.add_argument("--months", type=int, default=None, help="投影月数（覆盖输入文件）")

    args = parser.parse_args()

    try:
        with open(args.input_file, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: 文件 '{args.input_file}' 不存在。", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: JSON格式错误: {e}", file=sys.stderr)
        sys.exit(1)

    initial_investment = data["initial_investment"]
    assumptions = data["monthly_assumptions"]
    projection_months = args.months or data.get("projection_months", 36)
    hurdle_rate = data.get("hurdle_rate_annual", 0.15)
    useful_life = data.get("useful_life_months", 60)
    project_name = data.get("project_name", "未命名项目")

    # Calculate
    schedule = calculate_monthly_cash_flows(initial_investment, assumptions, projection_months)
    breakeven = find_breakeven_month(schedule)
    monthly_cfs = [entry["net_cash_flow"] for entry in schedule]
    irr = calculate_project_irr(initial_investment, monthly_cfs)
    npv = calculate_project_npv(initial_investment, monthly_cfs, hurdle_rate)
    signal = determine_signal(npv, irr, hurdle_rate, breakeven, useful_life, projection_months)
    total_profit = schedule[-1]["cumulative"] if schedule else 0

    results = {
        "project_name": project_name,
        "initial_investment": initial_investment,
        "projection_months": projection_months,
        "hurdle_rate": hurdle_rate,
        "useful_life_months": useful_life,
        "breakeven_month": breakeven,
        "irr": irr,
        "npv": npv,
        "total_profit_at_end": total_profit,
        "signal": signal,
        "schedule": schedule,
    }

    if args.format == "json":
        print(json.dumps(results, indent=2, ensure_ascii=False, default=str))
    else:
        print(format_text(results))


if __name__ == "__main__":
    main()
