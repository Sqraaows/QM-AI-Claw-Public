## Description: <br>
DataScope helps agents read, create, and update DataScope records through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate DataScope through a connected OOMOL account, including reading answers, managing locations, and creating or updating metadata list elements. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected DataScope account and may use sensitive credentials through the OOMOL connector. <br>
Mitigation: Provide only the DataScope access needed for the requested task and review connector permissions before use. <br>
Risk: Create and update actions can change DataScope locations or metadata list elements. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>
Risk: Connector schemas and upstream service fields can change over time. <br>
Mitigation: Inspect the live action schema with the oo CLI before constructing each connector payload. <br>


## Reference(s): <br>
- [ClawHub DataScope skill](https://clawhub.ai/oomol/oo-datascope) <br>
- [DataScope homepage](https://www.mydatascope.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, JSON, configuration] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
