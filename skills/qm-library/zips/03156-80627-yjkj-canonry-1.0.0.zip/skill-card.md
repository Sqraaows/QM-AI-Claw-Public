## Description: <br>
Agent-first AEO operating platform. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[arberx](https://clawhub.ai/user/arberx) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External marketers, SEO/AEO operators, and developers use Canonry to measure AI answer-engine mentions and citations, diagnose indexing, schema, content, and traffic gaps, and operate CLI-driven fixes across analytics, server logs, WordPress, indexing, and local-business integrations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Canonry can connect to analytics accounts, business profiles, server logs, WordPress, and site-indexing services that may expose sensitive project or client data. <br>
Mitigation: Use least-privilege accounts where available, connect only approved sites and properties, and keep project data out of public issue trackers or shared logs. <br>
Risk: Local configuration may contain credentials for Canonry integrations. <br>
Mitigation: Keep ~/.canonry/config.yaml out of source control, restrict it to the local user, and back it up before making configuration edits. <br>
Risk: WordPress and indexing workflows can affect live client sites and search visibility. <br>
Mitigation: Use staging and dry-run workflows where available, require explicit approval before live WordPress changes, and review generated changes before applying them. <br>
Risk: Agent scope, webhooks, and traffic-log retention can broaden data access or persist unnecessary operational data. <br>
Mitigation: Review agent scope and webhook settings before enabling them, define retention rules for traffic logs, and avoid tight API loops that may exceed service limits. <br>


## Reference(s): <br>
- [Canonry ClawHub release](https://clawhub.ai/arberx/canonry) <br>
- [Canonry website](https://canonry.ai) <br>
- [AINYC organization](https://ainyc.ai) <br>
- [Canonry GitHub documentation](https://github.com/AINYC/canonry) <br>
- [AINYC AEO Methodology](https://ainyc.ai/aeo-methodology) <br>
- [Canonry CLI Reference](references/canonry-cli.md) <br>
- [AEO Analysis: Interpreting Canonry Results](references/aeo-analysis.md) <br>
- [Indexing Workflows for AEO](references/indexing.md) <br>
- [WordPress Integration](references/wordpress-integration.md) <br>
- [Server-side traffic (AI Visibility - Server-Side)](references/server-side-traffic.md) <br>
- [Google Business Profile Integration](references/google-business-profile.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Code, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands, JSON/configuration snippets, and concise operational recommendations.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce CLI command plans, configuration steps, diagnostic summaries, and change recommendations for Canonry-managed projects.] <br>

## Skill Version(s): <br>
4.70.0+35bd209 (source: ClawHub release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
