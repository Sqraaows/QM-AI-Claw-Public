## Description: <br>
Have I Been Pwned (haveibeenpwned.com). Use this skill for Have I Been Pwned requests that search or read breach, paste, data-class, and subscription information through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, security teams, and support analysts use this skill to query Have I Been Pwned breach and paste information through an OOMOL-connected account. It supports account exposure searches, breach lookup and listing, data-class discovery, latest-breach checks, and subscription status review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Setup guidance can run a remote installer script for the oo CLI. <br>
Mitigation: Install only when the user trusts OOMOL's CLI and prefer the documented installer or a verified package. <br>
Risk: HIBP queries can send sensitive identifiers, such as email addresses, through an external connector service. <br>
Mitigation: Confirm user intent before querying other people's email addresses or subscription details. <br>
Risk: The skill requires sensitive HIBP API access through an OOMOL-connected account. <br>
Mitigation: Use a trusted OOMOL account connection and review connector access before deployment. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-haveibeenpwned) <br>
- [Have I Been Pwned homepage](https://haveibeenpwned.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command examples and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses schema-first connector calls and returns read-only Have I Been Pwned data through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
