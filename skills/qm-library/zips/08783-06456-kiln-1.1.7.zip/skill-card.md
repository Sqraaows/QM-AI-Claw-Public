## Description: <br>
Kiln lets AI agents design, slice, queue, monitor, and recover 3D printing and fabrication jobs across supported printer backends and fulfillment services. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[codeofaxel](https://clawhub.ai/user/codeofaxel) <br>

### License/Terms of Use: <br>
AGPL-3.0 <br>


## Use Case: <br>
Developers, operators, and fabrication teams use Kiln to let MCP-capable agents control 3D printers, generate printable models, slice files, manage print queues, monitor jobs, and request third-party fabrication quotes or orders. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Kiln can control real 3D printers and fabrication workflows, including actions that affect hardware state. <br>
Mitigation: Require human approval for starting prints, queue changes, raw G-code, cancellations, temperature-affecting actions, and other hardware-impacting operations. <br>
Risk: Kiln can place paid fabrication orders or interact with fulfillment providers. <br>
Mitigation: Require explicit approval for quotes, order placement, payment-related steps, and shipping details; use account-level spend limits where available. <br>
Risk: Printer, marketplace, model-generation, and fulfillment integrations may require API keys or other sensitive credentials. <br>
Mitigation: Use least-privilege credentials, keep secrets out of prompts and logs, and prefer scoped or dedicated service keys. <br>
Risk: Generated or downloaded models and G-code may be unsafe, malformed, or unsuitable for a specific printer or material. <br>
Mitigation: Start with dry runs or noncritical hardware, review generated artifacts, run preflight checks and G-code validation, and supervise printer operation. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/codeofaxel/kiln) <br>
- [Publisher profile](https://clawhub.ai/user/codeofaxel) <br>
- [Project repository declared by server metadata](https://github.com/codeofaxel/Kiln) <br>
- [PyPI package](https://pypi.org/project/kiln3d/) <br>
- [Kiln documentation](https://kiln3d.com/docs) <br>
- [Kiln website](https://kiln3d.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, API calls, files, guidance] <br>
**Output Format:** [Markdown, JSON, shell commands, MCP tool calls, status text, generated model or print-job artifacts, and configuration snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May involve physical printer actions, external fulfillment orders, sensitive credentials, and generated fabrication files.] <br>

## Skill Version(s): <br>
1.1.7 (source: evidence.release.version and artifact/server.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
