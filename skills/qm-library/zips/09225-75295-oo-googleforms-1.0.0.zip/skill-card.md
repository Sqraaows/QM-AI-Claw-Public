## Description: <br>
Google Forms lets agents read, create, and update Google Forms through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and agents use this skill to inspect Google Form structure and responses, create forms, apply updates, and change publishing settings after confirming write actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Google Forms responses and modify forms through the connected OOMOL account. <br>
Mitigation: Install it only for accounts where this access is acceptable, and review payloads carefully before create, batch update, or publish-setting changes. <br>
Risk: Write actions can change published form state, questions, settings, or response collection behavior. <br>
Mitigation: Inspect the live connector schema and confirm the exact payload and intended effect with the user before running write actions. <br>


## Reference(s): <br>
- [Google Forms homepage](https://workspace.google.com/products/forms/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Google Forms skill page](https://clawhub.ai/oomol/oo-googleforms) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payload and response descriptions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution and returns oo CLI JSON responses with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
