## Description: <br>
NocoDB (nocodb.com) skill for reading, creating, updating, and deleting data whenever a task involves NocoDB. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and data teams use this skill to let an agent inspect and manage NocoDB bases, tables, fields, views, and records through an OOMOL-connected account. It supports read, count, create, update, upsert, and delete workflows for NocoDB data and metadata. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected NocoDB account and can access data visible to that account. <br>
Mitigation: Install only when OOMOL is trusted for the workspace and use a least-privilege NocoDB API key where possible. <br>
Risk: Create, update, upsert, and delete actions can change or remove records, tables, fields, and views. <br>
Mitigation: Review the target, payload, and intended effect before approving write actions, and require explicit confirmation before destructive actions. <br>
Risk: Connector schemas and upstream action defaults can change over time. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [NocoDB homepage](https://nocodb.com) <br>
- [ClawHub NocoDB skill page](https://clawhub.ai/oomol/oo-nocodb) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before forming action payloads; command responses are JSON when actions are run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: skill frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
