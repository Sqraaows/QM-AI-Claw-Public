## Description: <br>
Shortcut helps agents read, create, and update Shortcut workspace data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate a connected Shortcut workspace: read stories, epics, projects, workflows, and members, search stories, and create or update stories and epics. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Shortcut account and can access Shortcut workspace data. <br>
Mitigation: Install it only for intended Shortcut operations and use an account with appropriate workspace permissions. <br>
Risk: Create and update actions can change Shortcut stories or epics. <br>
Mitigation: Confirm the exact payload and intended effect before executing any write action. <br>
Risk: First-time setup includes shell installer commands for the OOMOL CLI. <br>
Mitigation: Review the installer or use the documented install guide before running pipe-to-shell setup commands. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-shortcut) <br>
- [Shortcut Homepage](https://www.shortcut.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown instructions with inline shell commands and JSON command output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read actions can run directly; write actions require payload confirmation before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
