## Description: <br>
Systeme.io lets agents read, create, update, and delete contacts, tags, webhooks, courses, enrollments, and subscriptions through an OOMOL-connected Systeme.io account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and business operators can use this skill to manage Systeme.io contacts, tags, webhooks, courses, enrollments, and subscriptions from an agent workflow. It is intended for accounts connected through OOMOL where the agent can inspect each action schema before running connector commands. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change Systeme.io account state, including creating or updating contacts, tags, enrollments, and webhooks. <br>
Mitigation: Require the agent to show the exact action, target, payload, and expected effect before approving any write action. <br>
Risk: The skill can delete records or cancel subscriptions, which may be destructive or business-impacting. <br>
Mitigation: Require explicit final approval for delete, remove, detach, enrollment, webhook, tag, and subscription actions, with special review before canceling a subscription. <br>
Risk: The skill requires a connected Systeme.io account and sensitive credentials managed through OOMOL. <br>
Mitigation: Install only when the publisher is trusted and the intended account has appropriate access scope for the agent workflow. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-systeme-io) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Systeme.io homepage](https://systeme.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are expected as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
