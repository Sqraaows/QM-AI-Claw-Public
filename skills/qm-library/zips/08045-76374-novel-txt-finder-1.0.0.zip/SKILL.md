---
name: novel-txt-finder
description: "Search and download free novel TXT files from public sources."
homepage: https://github.com/openclaw/skill-novel-txt-finder
license: MIT
allowed-tools:
  - Read
  - Write
  - Edit
  - web_fetch
  - web_search
  - browser
  - exec
user-invocable: true
metadata:
  {
    "openclaw": {
      "emoji": "📚",
      "category": "tool",
      "difficulty": "beginner",
      "language": "zh-CN"
    }
  }
---

# novel-txt-finder

Search and download free novel TXT files from public sources. Works for Chinese and English novels.

## Workflow

### Step 1: Identify the novel

Ask the user for the novel name. If they only give a partial name, search to find the exact title.

### Step 2: Search for download sources

Use `web_search` to find free TXT download sources:
```
query: "小说名 txt 下载 免费"
```

Filter results: prefer `.txt` file links or sites known for free novel downloads. Avoid paid or DRM-protected sources.

### Step 3: Evaluate candidate URLs

For each candidate URL, use `web_fetch` with `maxChars: 2000` to check:
- Is it a direct TXT file?
- Is it a directory listing with .txt files?
- Is it a search results page that might have TXT links?

### Step 4: Download the TXT file

When a direct `.txt` URL is found:

```bash
curl -L -o "/tmp/{novel-name}.txt" "URL"
```

Use the novel name (sanitized) as filename. Save to `/tmp/` first.

### Step 5: Verify the file

```bash
file "/tmp/{novel-name}.txt"
wc -c "/tmp/{novel-name}.txt"
head -5 "/tmp/{novel-name}.txt"
```

Validate:
- File size > 10KB (meaningful content)
- Contains Chinese text or novel content (not HTML error page)
- Correct encoding (try `iconv -f GBK -t UTF-8` if garbled)

### Step 6: Fix encoding if needed

Chinese novels often come in GBK/GB2312 encoding:

```bash
iconv -f GBK -t UTF-8 "/tmp/{novel-name}.txt" -o "/tmp/{novel-name}-utf8.txt" 2>/dev/null && mv "/tmp/{novel-name}-utf8.txt" "/tmp/{novel-name}.txt"
```

### Step 7: Save to target location

Ask user where to save, or default to `~/Downloads/{novel-name}.txt`.

### Step 8: Report

```
✅ 下载完成！

书名：《》
作者：未知
文件：/Users/mac/Downloads/.txt
大小：X MB
来源：URL
```

## Search strategies by source type

### Direct TXT sites
Known free novel sites:
- wocaibook.com
- quedian.org
- booktxt.net
- ia找人看书 txt org (ia.org)

### GitHub raw TXT
Many Chinese novels are archived on GitHub:
```
query: "site:github.com "小说名" txt"
```
Look for raw content at `raw.githubusercontent.com`

### Wenku8 (文库8)
For Chinese web novels:
```
query: "小说名 site:wenkub.com OR site:wenku8.net"
```

### Fallback: Google/Baidu search
```
query: ""小说名" 下载 txt"
```

## Edge cases

- **No results found**: Try alternative titles, author names, or partial names.
- **Multiple volumes**: Download the most complete volume first, report other volumes.
- **Blocked site**: Try with browser tool or report failure.
- **Suspicious redirect**: Always verify final URL with `web_fetch`.
- **Very small file** (<10KB): Likely an error page or redirect, try another source.
- **HTML instead of TXT**: Try `lynx -dump URL` or search for a cleaner source.

## Safety rules

- Only download from publicly available free sources.
- Do not use paid ebook platforms (Kindle, Douban books, etc.).
- Do not bypass paywalls or DRM.
- Do not redistribute downloaded files beyond personal use.