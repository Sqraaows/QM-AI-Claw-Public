#!/usr/bin/env python3
"""
Download novel TXT files with encoding detection and verification.
"""

import sys
import os
import urllib.request
import urllib.error
from pathlib import Path


def sanitize_filename(name: str) -> str:
    """Remove characters that are unsafe for filenames."""
    import re
    # Remove path separators and other unsafe chars
    name = re.sub(r'[\\/:*?"<>|]', '', name)
    return name.strip()


def download_txt(url: str, filename: str, timeout: int = 30) -> str:
    """
    Download a TXT file from URL.
    Returns the path to downloaded file.
    """
    output_path = f"/tmp/{sanitize_filename(filename)}.txt"

    print(f"Downloading: {url}")
    print(f"Output: {output_path}")

    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read()

            # Detect encoding
            encoding = detect_encoding(content)
            try:
                text = content.decode(encoding)
            except UnicodeDecodeError:
                text = content.decode('utf-8', errors='replace')

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(text)

            print(f"Saved: {output_path} ({len(content)} bytes)")
            return output_path

    except Exception as e:
        print(f"Error downloading: {e}")
        return None


def detect_encoding(content: bytes) -> str:
    """Detect encoding from BOM or content."""
    # BOM check
    if content.startswith(b'\xff\xfe'):
        return 'utf-16-le'
    if content.startswith(b'\xfe\xff'):
        return 'utf-16-be'
    if content.startswith(b'\xef\xbb\xbf'):
        return 'utf-8-sig'

    # Try to detect Chinese encodings
    try:
        content.decode('utf-8')
        return 'utf-8'
    except UnicodeDecodeError:
        pass

    try:
        content.decode('gbk')
        return 'gbk'
    except UnicodeDecodeError:
        pass

    try:
        content.decode('gb2312')
        return 'gb2312'
    except UnicodeDecodeError:
        pass

    return 'utf-8'  # fallback


def verify_file(filepath: str, min_size_kb: int = 10) -> bool:
    """Verify the file is a valid text file."""
    path = Path(filepath)
    if not path.exists():
        return False

    size = path.stat().st_size
    if size < min_size_kb * 1024:
        print(f"File too small: {size} bytes (min: {min_size_kb}KB)")
        return False

    # Read first 200 chars to verify text content
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        first = f.read(200)

    # Check for HTML error indicators
    html_indicators = ['<html', '<body', '<head>', '<!DOCTYPE']
    if any(tag in first.lower() for tag in html_indicators):
        print("File appears to be HTML, not TXT")
        return False

    return True


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python download_novel.py <url> <filename>")
        sys.exit(1)

    url = sys.argv[1]
    filename = sys.argv[2]

    result = download_txt(url, filename)
    if result and verify_file(result):
        print("✓ File verified successfully")
    else:
        print("✗ Verification failed")
        sys.exit(1)