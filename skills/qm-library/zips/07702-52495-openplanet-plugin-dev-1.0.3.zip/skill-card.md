## Description: <br>
Create, debug, and structure Openplanet AngelScript plugins for Trackmania and Maniaplanet. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[tomekdot](https://clawhub.ai/user/tomekdot) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers use this skill to create, debug, and maintain Openplanet plugins written in AngelScript for Trackmania and Maniaplanet. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated Openplanet plugin code may contain compile errors or incorrect API usage. <br>
Mitigation: Review proposed code before running it in Openplanet and check Openplanet.log after enabling or reloading the plugin. <br>
Risk: The inspected artifact advertises offline reference files that were not present. <br>
Mitigation: Use the online Openplanet documentation and linked reference repository when current API details are needed. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/tomekdot/openplanet-plugin-dev) <br>
- [Openplanet API documentation](https://openplanet.dev/docs) <br>
- [Openplanet plugin reference files](https://github.com/tomekdot/hermes-skills/tree/master/skills/software-development/openplanet-plugin-dev/references) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline code blocks and configuration examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May propose local Openplanet plugin file edits or code snippets for user review.] <br>

## Skill Version(s): <br>
1.0.3 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
