## Description: <br>
Operate Gumroad through an OOMOL-connected account to read catalog and sales data and run supported sales actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External operators, developers, and business teams use this skill to manage Gumroad account, product, subscriber, and sales workflows from an agent session. It supports read workflows plus state-changing sale actions such as marking shipments, resending receipts, and issuing refunds. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can issue Gumroad refunds, which may have payment and customer-impacting consequences. <br>
Mitigation: Require explicit confirmation for every refund, verify the sale, customer, amount, reason, and business authorization, and prefer the least-privileged account scope that can perform only the needed payment actions. <br>
Risk: State-changing sale actions can alter shipment or buyer communication records. <br>
Mitigation: Inspect the live action schema, construct the exact payload, and confirm the intended effect with the user before running write actions. <br>
Risk: The skill requires sensitive connected-account credentials. <br>
Mitigation: Use the OOMOL-connected account flow described by the artifact, avoid handling raw tokens directly, and keep access scoped to the workflows the user needs. <br>


## Reference(s): <br>
- [ClawHub Gumroad skill page](https://clawhub.ai/oomol/oo-gumroad) <br>
- [Gumroad homepage](https://gumroad.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown action guidance with oo CLI shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an OOMOL-connected Gumroad account and live schema inspection before building action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
