---
name: oo-gumroad
description: "Gumroad (gumroad.com). Use this skill for ANY Gumroad request — reading, creating, and updating data. Whenever a task involves Gumroad, use this skill instead of calling the API directly."
allowed-tools: [Bash(oo *)]
metadata:
  title: "Gumroad"
  author: "OOMOL"
  version: "1.0.0"
  service: "gumroad"
  categories: "Finance, Marketing"
  homepage: "https://gumroad.com"
---

# Gumroad

Operate **Gumroad** through your OOMOL-connected account. This skill calls the `gumroad` connector with the [oo CLI](https://github.com/oomol-lab/oo-cli); OOMOL injects credentials server-side, so you never handle raw tokens.

Category: Finance, Marketing. Exposes 9 action(s).

## Running an action

Assume the user has already installed the oo CLI, signed in, and connected Gumroad. **Do not run `oo auth login` or open the connection URL proactively — just run the action.** Fall back to [First-time setup](#first-time-setup) only when a command actually fails with an auth or connection error.

**1. Inspect the contract** to get the authoritative input/output schema before building a payload:

```bash
oo connector schema "gumroad" --action "<action_name>"
```

**2. Run the action** with a JSON payload that matches the input schema:

```bash
oo connector run "gumroad" --action "<action_name>" --data '<json>' --json
```

- `--data` takes a JSON object string or `@path/to/file.json`; omit it to send `{}`.
- The response is `{ "data": ..., "meta": { "executionId": "..." } }`; the execution id lives under `meta.executionId`.

Each action below links to a reference file with its purpose and exact commands. Read the linked file, then fetch the live schema with `oo connector schema` before constructing `--data`.

## Available actions

- [`get_current_user`](actions/get_current_user.md) — Retrieve the authenticated Gumroad user.
- [`get_product`](actions/get_product.md) — Retrieve one Gumroad product by ID.
- [`get_sale`](actions/get_sale.md) — Retrieve one Gumroad sale by ID.
- [`list_product_subscribers`](actions/list_product_subscribers.md) — List active subscribers for one Gumroad product.
- [`list_products`](actions/list_products.md) — List products owned by the authenticated Gumroad user.
- [`list_sales`](actions/list_sales.md) — List successful Gumroad sales with optional filters and pagination.
- [`mark_sale_as_shipped`](actions/mark_sale_as_shipped.md) — Mark a Gumroad sale as shipped, optionally including a tracking URL.
- [`refund_sale`](actions/refund_sale.md) — Refund a Gumroad sale, optionally as a partial refund in cents.
- [`resend_sale_receipt`](actions/resend_sale_receipt.md) — Resend a Gumroad sale receipt to the buyer.

## Safety

- Read actions (get / list / search) are safe to run directly.
- **Create, update, send, or post actions change Gumroad state — confirm the exact payload and effect with the user before running.**
- **Delete or remove actions are destructive — always confirm the target and get explicit approval first.**

## First-time setup

These are **one-time** steps — do not repeat them on every call. Run a step only when a command fails for the matching reason.

- **`oo: command not found`** — install the oo CLI (other platforms: <https://cli.oomol.com/install-guide.md>):

  ```bash
  curl -fsSL https://cli.oomol.com/install.sh | bash    # macOS / Linux
  ```

  ```powershell
  irm https://cli.oomol.com/install.ps1 | iex           # Windows PowerShell
  ```

- **Not signed in / authentication error** — sign in to your OOMOL account once:

  ```bash
  oo auth login
  ```

- **`scope_missing` / `credential_expired` / `app_not_ready` / `app_not_found`** — Gumroad is not connected, or the connection expired or lacks a scope. Connect once (auth type: API key) at:

  ```text
  https://console.oomol.com/app-connections?provider=gumroad
  ```

- **HTTP 402 / `OOMOL_INSUFFICIENT_CREDIT`** — billing stop. Recharge at `https://console.oomol.com/billing/token-recharge` before retrying.

## Resources

- Gumroad homepage: https://gumroad.com
