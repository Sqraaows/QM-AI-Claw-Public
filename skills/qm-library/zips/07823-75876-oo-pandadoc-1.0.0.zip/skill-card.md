## Description: <br>
PandaDoc skill for reading, creating, updating, and deleting PandaDoc data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and operators with a connected PandaDoc workspace use this skill to inspect live connector schemas and run PandaDoc actions for documents, templates, contacts, folders, attachments, and webhooks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Write, upload, and webhook actions can change PandaDoc data or send PandaDoc event data to configured webhook endpoints. <br>
Mitigation: Review the requested payload, intended effect, and webhook endpoint before approving execution. <br>
Risk: Delete actions can remove contacts or templates from the connected PandaDoc workspace. <br>
Mitigation: Confirm the exact target and get explicit user approval before running destructive actions. <br>
Risk: The skill requires access to a connected PandaDoc account. <br>
Mitigation: Use the OOMOL connection flow and avoid handling raw PandaDoc tokens directly. <br>


## Reference(s): <br>
- [ClawHub PandaDoc skill](https://clawhub.ai/oomol/oo-pandadoc) <br>
- [PandaDoc homepage](https://www.pandadoc.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, JSON, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
