## Description: <br>
Alchemy (alchemy.com). Use this skill for ANY Alchemy request - searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to query Alchemy through an OOMOL-connected account for Ethereum mainnet transfer history, NFT ownership and metadata, and ERC-20 token balances and metadata. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The fallback setup path tells the agent to install the OOMOL CLI by piping a remote script directly into a shell. <br>
Mitigation: Install only from verified official OOMOL instructions, review the installer before execution, and avoid running installation commands unless setup actually fails. <br>
Risk: The skill requires an Alchemy connection and may handle wallet addresses or sensitive API credentials through the connected account. <br>
Mitigation: Use the least access needed for read-only queries, keep credentials in the OOMOL connection flow, and confirm payloads before any non-read action is attempted. <br>


## Reference(s): <br>
- [Alchemy homepage](https://www.alchemy.com) <br>
- [ClawHub Alchemy skill page](https://clawhub.ai/oomol/oo-alchemy) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_asset_transfers action reference](actions/get_asset_transfers.md) <br>
- [get_nfts_for_owner action reference](actions/get_nfts_for_owner.md) <br>
- [get_nft_metadata action reference](actions/get_nft_metadata.md) <br>
- [get_token_balances action reference](actions/get_token_balances.md) <br>
- [get_token_metadata action reference](actions/get_token_metadata.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration guidance, JSON, Markdown] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Live action schemas should be inspected before constructing each JSON payload.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
