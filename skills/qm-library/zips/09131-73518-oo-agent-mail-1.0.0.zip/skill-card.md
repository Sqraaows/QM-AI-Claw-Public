## Description: <br>
AgentMail helps an agent manage AgentMail inboxes and messages through OOMOL's AgentMail connector and the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill when they want an agent to list AgentMail inboxes, inspect messages, create inboxes, or send messages through a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses credential-backed AgentMail access and can expose inbox or message data available to the connected account. <br>
Mitigation: Install only when the listing and files match the expected publisher and purpose, and use an OOMOL connection with the minimum appropriate AgentMail access. <br>
Risk: Create and send actions can change AgentMail state or send email. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>


## Reference(s): <br>
- [ClawHub Skill Listing](https://clawhub.ai/oomol/oo-agent-mail) <br>
- [AgentMail Homepage](https://agentmail.to) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses from connector runs are JSON objects with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
