## Description: <br>
BigDataCloud helps agents retrieve IP geolocation, network, ASN, timezone, and reverse-geocoding data through the OOMOL big_data_cloud connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and analysts use this skill to look up country-level IP geolocation, IP network and ASN details, timezone data, and timezone-aware reverse geocoding from BigDataCloud. The skill is suited to maps, security, identity, and data analysis workflows that can rely on an OOMOL-connected BigDataCloud account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses OOMOL as an intermediary for BigDataCloud and depends on server-side credential handling. <br>
Mitigation: Install only when the user trusts OOMOL, has reviewed the installer, and is comfortable connecting a BigDataCloud API key to OOMOL for server-side use. <br>
Risk: Connector schemas can change upstream, causing stale payload assumptions. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub BigDataCloud skill page](https://clawhub.ai/oomol/oo-big-data-cloud) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [BigDataCloud homepage](https://www.bigdatacloud.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses from the OOMOL connector with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
