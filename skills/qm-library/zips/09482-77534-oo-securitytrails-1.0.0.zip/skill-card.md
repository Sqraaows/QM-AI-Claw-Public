## Description: <br>
SecurityTrails helps agents query domain intelligence through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Security practitioners, developers, and agents use this skill to retrieve DNS, SSL, subdomain, and associated-domain intelligence for a hostname through an authenticated SecurityTrails connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The fallback installer pipes a remote OOMOL install script into a shell when the oo CLI is missing. <br>
Mitigation: Use the official install guide, inspect or verify the installer where possible, and run setup commands only when the CLI is missing or authentication fails. <br>
Risk: The skill requires a connected SecurityTrails account and may use sensitive credentials through the OOMOL connection. <br>
Mitigation: Install only when the publisher is trusted, keep the SecurityTrails connection scoped to the intended account, and avoid exposing raw credentials in prompts or files. <br>


## Reference(s): <br>
- [SecurityTrails get_domain action](actions/get_domain.md) <br>
- [SecurityTrails get_subdomains action](actions/get_subdomains.md) <br>
- [SecurityTrails find_associated_domains action](actions/find_associated_domains.md) <br>
- [SecurityTrails get_domain_ssl action](actions/get_domain_ssl.md) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
