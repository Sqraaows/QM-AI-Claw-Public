## Description: <br>
Access Tempo time-tracking data via MCP for Tempo worklogs, plans, teams, accounts, resource allocation, and timesheet approval workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and employees use this skill to configure and operate a Tempo MCP server so an agent can retrieve, create, update, and delete Tempo worklogs, plans, teams, accounts, and approval records through the user's Tempo API token. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can grant an agent broad authority over Tempo time-tracking, resource planning, account, team, and approval workflows under the user's token. <br>
Mitigation: Use a least-privilege token and require manual confirmation before deleting worklogs, plans, teams, or accounts, or before taking approval-related actions. <br>
Risk: The skill requires sensitive Tempo credentials. <br>
Mitigation: Store the Tempo API token outside source control, avoid sharing it in chats or logs, and rotate it if exposure is suspected. <br>
Risk: Corporate Tempo automation may be limited by employer policy even when API-based automation is technically possible. <br>
Mitigation: Confirm intended use with the relevant IT, Jira, or Tempo administrator before using the skill against a corporate Tempo instance. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/tempo-api-mcp) <br>
- [npm package: tempo-api-mcp](https://www.npmjs.com/package/tempo-api-mcp) <br>
- [Source repository: chrischall/tempo-api-mcp](https://github.com/chrischall/tempo-api-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, API Calls, Shell commands, Configuration instructions] <br>
**Output Format:** [Markdown with inline JSON and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires a Tempo API token and registered MCP server before agent tool calls can succeed.] <br>

## Skill Version(s): <br>
2.1.4 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
