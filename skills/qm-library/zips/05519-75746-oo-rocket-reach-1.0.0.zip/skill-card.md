## Description: <br>
RocketReach (rocketreach.co). Use this skill for searching and reading RocketReach data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to search RocketReach people and company data, retrieve account information, and look up company enrichment details through an OOMOL-connected RocketReach account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on an OOMOL bridge to a connected RocketReach account and may access business contact or profile data. <br>
Mitigation: Install only when that account bridge is acceptable, and review requested lookups before running them against connected RocketReach credentials. <br>
Risk: First-time setup includes optional remote installer commands for the oo CLI. <br>
Mitigation: Prefer reviewing the installer source or using a trusted manual installation path before running remote install commands. <br>


## Reference(s): <br>
- [RocketReach homepage](https://rocketreach.co) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-rocket-reach) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
