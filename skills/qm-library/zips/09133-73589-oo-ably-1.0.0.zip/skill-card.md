## Description: <br>
Ably (ably.com). Use this skill for Ably requests that read, create, publish, and delete data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect Ably channels, presence, history, statistics, service time, and push channel subscriptions, and to publish messages or manage channel subscriptions through the OOMOL connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected Ably account, including reading application data, publishing messages, activating channels, and deleting push subscriptions. <br>
Mitigation: Install only when the publisher is trusted, review Ably scopes before use, and require explicit confirmation for publishing, channel activation, or deletion. <br>
Risk: Connector schemas and accepted payloads can change upstream. <br>
Mitigation: Inspect the live connector schema before each action and construct payloads only from the current schema. <br>


## Reference(s): <br>
- [Ably homepage](https://ably.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ably) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live schema inspection before connector actions and returns command output containing data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
