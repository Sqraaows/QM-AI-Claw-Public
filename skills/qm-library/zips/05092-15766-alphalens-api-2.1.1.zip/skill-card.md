## Description: <br>
AlphaLens API helps agents use AlphaLens to find companies, discover products, research competitors, build market maps, create investor networks, run peer benchmarks, perform white-space analysis, and enrich pipeline targets. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[walidmustapha](https://clawhub.ai/user/walidmustapha) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, analysts, and developers use this skill to run AlphaLens-powered company discovery, competitive landscape research, product search, investor-network analysis, peer benchmarking, white-space analysis, and pipeline enrichment from an agent. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send proprietary documents and business research data to AlphaLens during upload or pipeline enrichment workflows. <br>
Mitigation: Confirm what data will be sent before upload or enrichment, avoid secrets or regulated documents unless approved, and verify AlphaLens retention and deletion terms. <br>
Risk: Pipeline operations can change AlphaLens pipeline data. <br>
Mitigation: Inspect existing pipeline items before making changes, add only intended organizations or documents, and poll readiness before using computed values. <br>
Risk: The skill requires a sensitive AlphaLens API key. <br>
Mitigation: Provide ALPHALENS_API_KEY through an environment variable or secret store, alias it only for the active session, and do not hard-code credentials in generated commands or files. <br>


## Reference(s): <br>
- [AlphaLens Homepage](https://alphalens.ai) <br>
- [AlphaLens API Reference](references/REFERENCE.md) <br>
- [AlphaLens API Examples](references/EXAMPLES.md) <br>
- [ClawHub Skill Page](https://clawhub.ai/walidmustapha/alphalens-api) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with bash and curl commands; workflows may generate standalone HTML reports.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires ALPHALENS_API_KEY and an active AlphaLens subscription with API access.] <br>

## Skill Version(s): <br>
2.1.1 (source: SKILL.md frontmatter, skill.yaml, evidence.release) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
