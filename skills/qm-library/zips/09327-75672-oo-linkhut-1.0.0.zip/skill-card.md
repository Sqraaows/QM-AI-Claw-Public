## Description: <br>
Linkhut (ln.ht). Use this skill for ANY Linkhut request - reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to manage Linkhut bookmarks through an OOMOL-connected account, including listing bookmarks and tags, creating or updating bookmarks, and deleting bookmarks with explicit approval. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, or delete Linkhut bookmarks when a user approves write or delete actions. <br>
Mitigation: Confirm the exact payload, target URL, and intended effect before write actions, and require explicit approval before destructive delete actions. <br>
Risk: First-time setup may involve remote installer scripts for the oo CLI. <br>
Mitigation: Review OOMOL's installer instructions before running curl-to-shell or PowerShell iex commands, and only install the CLI when it is actually missing. <br>
Risk: The skill relies on OOMOL as the connector layer for the user's Linkhut account. <br>
Mitigation: Confirm the user is comfortable using OOMOL for Linkhut access before installation or account connection. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-linkhut) <br>
- [Linkhut homepage](https://ln.ht) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill guides agents to inspect live connector schemas before sending JSON payloads through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence, frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
