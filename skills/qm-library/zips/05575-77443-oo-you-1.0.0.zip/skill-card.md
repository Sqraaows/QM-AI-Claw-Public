## Description: <br>
Operates You.com through an OOMOL-connected account for web search, cited research, finance research, webpage fetching, and account balance lookup. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to query You.com services through OOMOL's connector for search, cited research answers, finance-focused research, webpage content extraction, and account credit checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-brokered You.com connection and API-key-backed credits. <br>
Mitigation: Install and connect it only in environments where using OOMOL as the credential broker is acceptable. <br>
Risk: First-time setup can execute an external oo CLI installer or initiate account login and service connection flows. <br>
Mitigation: Use OOMOL's documented install path or review the installer source before setup in stricter supply-chain environments. <br>
Risk: Upstream action schemas and defaults can change. <br>
Mitigation: Inspect the live connector schema before constructing action payloads. <br>


## Reference(s): <br>
- [ClawHub Skill Listing](https://clawhub.ai/oomol/oo-you) <br>
- [You.com Homepage](https://you.com/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are returned as JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
