## Description: <br>
Use when the user asks to read, write, format, or manage Google Sheets, including spreadsheet data, cell formatting, tab management, named ranges, merging cells, freezing rows or columns, exporting spreadsheets, and related Sheets operations. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to connect an agent to an authenticated Google Sheets workflow through gogcli so the agent can inspect, update, format, export, and manage spreadsheet content. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can perform high-impact Google Sheets actions, including delete, copy, export, merge or unmerge, formatting, note updates, and named-range changes. <br>
Mitigation: Require explicit user confirmation with a specific spreadsheet ID and range before using high-impact operations. <br>
Risk: The skill depends on an npm package and the Google account authenticated through gogcli. <br>
Mitigation: Install only when the package source and the authenticated Google account are trusted. <br>
Risk: The security verdict is suspicious because clear confirmation and scoping safeguards are not evident. <br>
Mitigation: Review intended operations before execution and scan the skill before deployment. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp-sheets) <br>
- [gogcli project](https://github.com/openclaw/gogcli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, API calls, guidance] <br>
**Output Format:** [Markdown responses with JSON MCP configuration and Google Sheets tool-call guidance.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses an authenticated gogcli Google account and may perform high-impact spreadsheet operations such as delete, copy, export, merge, formatting, note updates, and named-range changes.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
