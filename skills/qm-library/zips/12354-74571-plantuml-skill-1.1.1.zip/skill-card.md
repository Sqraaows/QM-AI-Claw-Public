## Description: <br>
Turn natural language into uml-diagrams.org style PlantUML diagrams and render them to SVG, PNG, PDF, or text output. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[samonysh](https://clawhub.ai/user/samonysh) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to convert natural-language diagram requests into PlantUML source, then render UML diagrams such as sequence, class, activity, use case, component, and state diagrams. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Diagram source is sent to the public PlantUML server by default, which can expose confidential architecture, endpoint, credential, proprietary workflow, or customer information. <br>
Mitigation: Do not use confidential diagram content with the default public-server path; use a controlled local Docker or plantuml.jar backend for sensitive work. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/samonysh/plantuml-skill) <br>
- [uml-diagrams.org reference style](https://www.uml-diagrams.org) <br>
- [PlantUML public server](https://www.plantuml.com/plantuml) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, code, shell commands, files] <br>
**Output Format:** [Markdown guidance with PlantUML code blocks and rendered SVG, PNG, PDF, or text files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Default render path uses the PlantUML public server, with Docker and local plantuml.jar fallbacks.] <br>

## Skill Version(s): <br>
1.1.1 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
