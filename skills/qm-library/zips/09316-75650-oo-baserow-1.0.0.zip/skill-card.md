## Description: <br>
This skill lets an agent read, create, update, and delete Baserow records through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and teams with Baserow data use this skill to inspect table schemas, list or read rows, and make confirmed row changes from an installed agent environment. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate Baserow through connected credentials and may expose data available to that connection. <br>
Mitigation: Install it only for approved Baserow accounts and keep Baserow/OOMOL credentials scoped to data the agent is allowed to access. <br>
Risk: Create, update, and delete actions can change or remove Baserow rows. <br>
Mitigation: Confirm the exact target, payload, and intended effect before writes, and require explicit user approval before deletes. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live connector schema before building each action payload. <br>


## Reference(s): <br>
- [Baserow homepage](https://baserow.io) <br>
- [ClawHub Baserow skill page](https://clawhub.ai/oomol/oo-baserow) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Guidance, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Live connector schemas should be inspected before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
