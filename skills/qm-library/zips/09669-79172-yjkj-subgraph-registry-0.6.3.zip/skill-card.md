## Description: <br>
Discover and filter The Graph subgraphs by domain, network, protocol type, or natural-language goal, returning reliability-scored records with x402 and legacy query URLs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[paulieb14](https://clawhub.ai/user/paulieb14) <br>

### License/Terms of Use: <br>
MIT <br>


## Use Case: <br>
Developers and external agents use this MCP server to find suitable The Graph subgraphs before issuing GraphQL queries. It supports filtering by chain, domain, protocol type, reliability score, and query path. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Returned x402 endpoints are real-money payment targets. <br>
Mitigation: Require explicit approval, wallet allowlists, and budget limits before any agent signs USDC payments. <br>
Risk: A changed or tampered registry database could affect lookup results. <br>
Mitigation: Install only a pinned MCP server version, keep hash verification enabled, and do not set SUBGRAPH_REGISTRY_SKIP_VERIFY in normal agent use. <br>
Risk: The repository includes web dashboard and maintenance code beyond the advertised npx MCP server. <br>
Mitigation: Do not run the dashboard or maintenance scripts unless separately prepared to grant their Dune, Anthropic, DuckDB, and optional AWS/S3 access. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/paulieb14/subgraph-registry) <br>
- [Subgraph Registry Homepage](https://github.com/PaulieB14/subgraph-registry) <br>
- [The Graph](https://thegraph.com) <br>
- [The Graph Studio API Keys](https://thegraph.com/studio/apikeys/) <br>
- [@graphprotocol/client-x402](https://www.npmjs.com/package/@graphprotocol/client-x402) <br>


## Skill Output: <br>
**Output Type(s):** [Text, JSON, Guidance] <br>
**Output Format:** [JSON payloads returned as MCP text content, including query URLs, pricing manifests, reliability scores, and usage instructions.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Results may include x402 payment details and legacy The Graph API-key URLs.] <br>

## Skill Version(s): <br>
0.6.2 (source: server release evidence and package.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
