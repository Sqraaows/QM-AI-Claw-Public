## Description: <br>
RAWG is a skill for searching and reading RAWG video game database data through the OOMOL rawg connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and agents use this skill to search RAWG and retrieve game, developer, genre, platform, publisher, store, tag, media, Reddit, store-link, addition, and series data. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected OOMOL/RAWG account and may consume OOMOL credits. <br>
Mitigation: Install, sign in, connect RAWG, and run connector actions only when the user intentionally wants the integration enabled. <br>
Risk: Connector schemas and upstream RAWG fields can change. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [RAWG homepage](https://rawg.io) <br>
- [ClawHub RAWG skill page](https://clawhub.ai/oomol/oo-rawg) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before running actions; command responses include data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
