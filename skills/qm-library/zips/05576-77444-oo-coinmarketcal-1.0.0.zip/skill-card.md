## Description: <br>
CoinMarketCal. Use this skill for ANY CoinMarketCal request - searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to retrieve CoinMarketCal coins, event categories, general events, representative-confirmed events, and ranked events through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The first-time setup instructions include remote installer commands that can execute unverified code. <br>
Mitigation: Install the oo CLI manually from a trusted source after reviewing the vendor and script contents; do not let an agent run curl-to-bash or PowerShell install commands automatically. <br>
Risk: The skill requires a connected CoinMarketCal account and sensitive credentials managed through OOMOL. <br>
Mitigation: Use the OOMOL connection flow for credentials, avoid exposing raw tokens to the agent, and retry setup only when an authentication or connection error occurs. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-coinmarketcal) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses guide the agent to inspect live connector schemas before running read-only CoinMarketCal actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
