## Description: <br>
SMS Alert helps an agent operate an OOMOL-connected SMS Alert account for sending SMS messages, generating and validating OTPs, checking credit balance, and listing sender IDs or templates. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate SMS Alert through their connected account, including sending direct SMS messages, generating and validating OTPs, and reviewing account resources such as credits, sender IDs, and templates. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send SMS and OTP messages from a connected SMS Alert account, which can change account state and incur cost. <br>
Mitigation: Review recipient numbers, message bodies, OTP parameters, and intended effects before approving send or OTP-generation actions. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live SMS Alert connector schema before constructing each action payload. <br>
Risk: The skill requires access to a connected SMS Alert account and related credentials managed through OOMOL. <br>
Mitigation: Install only for users who intend to let the agent operate that connected account, and resolve authentication or connection setup only when a command fails for that reason. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-sms-alert) <br>
- [SMS Alert homepage](https://www.smsalert.co.in/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
