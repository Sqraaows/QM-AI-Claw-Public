## Description: <br>
Runpod operates Runpod Pods through an OOMOL-connected account, letting an agent inspect schemas and run pod read and lifecycle actions through the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to list, inspect, start, stop, restart, reset, and delete Runpod Pods from an agent workflow without directly handling raw Runpod API tokens. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Pod lifecycle actions can disrupt running cloud workloads, and delete actions can remove Runpod resources. <br>
Mitigation: Confirm the exact pod ID, intended effect, and user approval before stop, reset, restart, or delete actions. <br>
Risk: The first-time setup path includes remote installer commands for the oo CLI. <br>
Mitigation: Review the installer source or use a verified install path before allowing an agent to run remote installation commands. <br>
Risk: The skill requires connected Runpod credentials through OOMOL. <br>
Mitigation: Install only for trusted OOMOL accounts and scopes, and reconnect credentials only when an auth or connection error requires it. <br>


## Reference(s): <br>
- [ClawHub Runpod skill page](https://clawhub.ai/oomol/oo-runpod) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Runpod homepage](https://www.runpod.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples; connector responses are JSON.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and a connected Runpod credential. Live action schemas should be inspected before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
