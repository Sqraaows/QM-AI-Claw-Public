## Description: <br>
Guides a new user or agent through the initial setup, configuration, and capabilities of the Fulcra environment. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[fulcra](https://clawhub.ai/user/fulcra) <br>

### License/Terms of Use: <br>
MIT <br>


## Use Case: <br>
External users and agents use this skill to onboard into Fulcra, authenticate with user consent, configure custom data streams, optionally back up agent memory or activity, record an initial data point, and generate a personalized HTML dashboard from the recorded data. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can connect an agent to a Fulcra account and write onboarding data, memory backups, and agent activity logs to remote storage. <br>
Mitigation: Proceed only with explicit user consent for authentication and each optional data-writing step, and decline memory backup or Agent Visibility options unless they are needed. <br>
Risk: The onboarding flow can involve broad personal context, including health, location, calendar, and prior-chat personalization. <br>
Mitigation: Avoid enabling sensitive personalization sources until the user understands retention, deletion, and scoping controls. <br>
Risk: The workflow requires OAuth access and sensitive credentials for Fulcra API and CLI operations. <br>
Mitigation: Use short-lived authenticated commands, never expose access tokens in chat or files, and keep credential handling within the documented CLI and API flows. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/fulcra/fulcra-onboarding) <br>
- [Fulcra Onboarding Backup](references/fulcra-onboarding-backup.md) <br>
- [Fulcra Create Annotations](references/fulcra-onboarding-create-annotations.md) <br>
- [Fulcra Onboarding Demonstration](references/fulcra-onboarding-demonstration.md) <br>
- [Fulcra Onboarding Discovery](references/fulcra-onboarding-discovery.md) <br>
- [Fulcra Onboarding Handoff](references/fulcra-onboarding-handoff.md) <br>
- [Fulcra Onboarding Prerequisites](references/fulcra-onboarding-prerequisites.md) <br>
- [Fulcra Record Annotations](references/fulcra-onboarding-record-annotations.md) <br>
- [Fulcra High-Impact Use Cases](references/fulcra-onboarding-usecases.md) <br>
- [uv installation documentation](https://docs.astral.sh/uv/getting-started/installation/) <br>
- [Fulcra context endpoint](https://context.fulcradynamics.com/) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands, JSON payloads, API calls, and standalone HTML dashboard code] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May create Fulcra annotations, records, memory backups, activity logs, and local dashboard files after user consent.] <br>

## Skill Version(s): <br>
0.0.8 (source: release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
