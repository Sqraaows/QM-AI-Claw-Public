## Description: <br>
VATlayer helps agents use an OOMOL-connected VATlayer account to retrieve VAT rates, validate VAT numbers, list reduced-rate types, and calculate VAT-inclusive or VAT-exclusive prices. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and business users use this skill to query VATlayer through the oo CLI for VAT rate lookup, VAT number validation, reduced-rate type listing, and VAT-compliant price calculations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected VATlayer account and uses server-side credential injection. <br>
Mitigation: Install and use it only when the user intends to operate VATlayer through OOMOL, and avoid asking users to expose raw VATlayer API tokens. <br>
Risk: VAT numbers, IP or country inputs, and pricing data may be sent to the VATlayer connector. <br>
Mitigation: Confirm that the user expects those values to be processed by VATlayer before running connector actions. <br>
Risk: OOMOL billing or API usage limits may apply. <br>
Mitigation: Stop and surface billing or insufficient-credit errors instead of retrying repeatedly. <br>
Risk: The first-time setup path may install the oo CLI from an external install script. <br>
Mitigation: Review the install step before running it, and only use setup commands when the normal action command fails because the CLI or account connection is missing. <br>


## Reference(s): <br>
- [VATlayer homepage](https://vatlayer.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-vatlayer) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses are returned by the oo CLI as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
