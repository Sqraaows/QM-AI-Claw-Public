## Description: <br>
Manage Resy restaurant reservations via MCP, including venue search, booking, listing and canceling reservations, managing favorites, and subscribing to Priority Notify. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to manage Resy restaurant reservations through an MCP server, including searching availability, booking tables, canceling reservations, and managing favorites or Priority Notify subscriptions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires Resy login credentials and can expose account-level reservation capabilities to an agent. <br>
Mitigation: Install only when comfortable providing Resy credentials to the MCP server, and store credentials in the configured MCP environment rather than in prompts or shared files. <br>
Risk: The skill can book, cancel, or modify live reservation-related state without strong confirmation steps documented in the artifact. <br>
Mitigation: Before booking, canceling, changing favorites, or changing notifications, manually verify the restaurant, date, time, party size, and any fee or loss-of-reservation impact. <br>
Risk: The skill relies on Resy's private web-app API and reverse-engineered endpoint behavior. <br>
Mitigation: Expect endpoint behavior to change, monitor failures, and review results before relying on reservation actions. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/chrischall/resy-mcp) <br>
- [resy-mcp npm package](https://www.npmjs.com/package/resy-mcp) <br>
- [resy-mcp source repository](https://github.com/chrischall/resy-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, API Calls] <br>
**Output Format:** [Markdown with JSON and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May require Resy account credentials and may initiate live reservation actions through the MCP server.] <br>

## Skill Version(s): <br>
0.5.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
