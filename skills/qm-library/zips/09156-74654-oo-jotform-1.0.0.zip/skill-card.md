## Description: <br>
Use this skill for Jotform requests that read, create, or update data through the OOMOL Jotform connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to operate Jotform through an OOMOL-connected account, including listing forms, reading form metadata and submissions, inspecting questions, and creating form submissions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through a connected OOMOL Jotform account. <br>
Mitigation: Use the connected account intentionally, confirm the current account when needed, and avoid exposing raw credentials in prompts or files. <br>
Risk: The create_submission action changes Jotform state. <br>
Mitigation: Inspect the live schema and confirm the exact payload and intended effect with the user before running a write action. <br>
Risk: Security guidance indicates the skill should only be installed where the requested authority is acceptable. <br>
Mitigation: Review the skill, scanner verdict, and requested connector access before deployment. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/oomol/oo-jotform) <br>
- [Jotform homepage](https://www.jotform.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
