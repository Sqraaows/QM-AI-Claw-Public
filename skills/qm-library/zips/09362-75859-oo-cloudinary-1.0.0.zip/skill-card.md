## Description: <br>
Cloudinary helps agents read, upload, rename, and update Cloudinary assets through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and media operations users use this skill to inspect Cloudinary asset records, browse uploaded assets, and perform confirmed upload, rename, or update operations through the oo CLI connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates a connected Cloudinary account through OOMOL, so excessive account permissions could affect production assets. <br>
Mitigation: Install it only when OOMOL is trusted, keep Cloudinary and OOMOL permissions scoped, and review account access before use. <br>
Risk: Upload, rename, and update actions can change Cloudinary state. <br>
Mitigation: Require explicit confirmation of the payload and intended effect before running write actions against production assets. <br>
Risk: First-time setup may fetch a remote oo CLI installer. <br>
Mitigation: Verify the CLI installer and source before running installation commands. <br>


## Reference(s): <br>
- [Cloudinary homepage](https://cloudinary.com) <br>
- [Cloudinary skill on ClawHub](https://clawhub.ai/oomol/oo-cloudinary) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing payloads; write actions require explicit user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
