## Description: <br>
Use Tomba through an OOMOL-connected account to search, verify, enrich, and retrieve contact and company intelligence. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Sales, marketing, recruiting, and data operations users can use this skill to run Tomba lookups for domains, professional emails, LinkedIn profiles, company searches, technology detection, and authenticated account information. Agents use it to inspect live connector schemas, build JSON payloads, and run read-oriented Tomba actions through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Setup guidance includes remote installer commands that execute downloaded scripts. <br>
Mitigation: Review the setup path before installing and prefer verified official packages or documented manual installation steps. <br>
Risk: The skill requires connecting a Tomba account through OOMOL and may send contact, domain, company, or LinkedIn lookup inputs to that service. <br>
Mitigation: Use the skill only when the user is comfortable sharing those lookup inputs with the connected service and account. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live action schema before constructing each payload. <br>


## Reference(s): <br>
- [Tomba homepage](https://tomba.io) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-tomba) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action results are returned as JSON data from the oo CLI when commands are run.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
