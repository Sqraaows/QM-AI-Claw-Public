## Description: <br>
Recall.ai lets an agent operate Recall.ai through an OOMOL-connected account to create, list, retrieve, remove, and clean up meeting bots and media. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to manage Recall.ai meeting bots through an OOMOL-connected account, including bot creation, status lookup, filtered listing, active-call removal, and media cleanup after downstream processing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates with sensitive Recall.ai credentials through an OOMOL-connected account. <br>
Mitigation: Review the requested external service connection and use the documented schema-first workflow before running actions on private or sensitive meeting data. <br>
Risk: Create, remove, and delete actions can change Recall.ai state or remove stored media. <br>
Mitigation: Confirm the exact payload, target bot or media, and intended effect with the user before running write or destructive actions. <br>


## Reference(s): <br>
- [Recall.ai homepage](https://www.recall.ai) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-recallai) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses through the oo connector; live connector schemas should be inspected before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
