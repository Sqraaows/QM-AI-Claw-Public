## Description: <br>
Operates fal.ai through an OOMOL-connected account for model discovery, pricing, queue status, result retrieval, cancellation, and webhook key lookup. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to work with fal.ai via the OOMOL oo CLI, including discovering model endpoints, checking pricing, monitoring queued requests, retrieving results, cancelling queue requests, and obtaining webhook verification keys. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can cancel queued or in-progress fal.ai requests, while the summary emphasizes searching and reading data. <br>
Mitigation: Require explicit user confirmation before running cancel_queue_request or any other state-changing action, including the exact model ID and request ID. <br>
Risk: The skill requires sensitive fal.ai account credentials through an OOMOL connection. <br>
Mitigation: Use the server-side OOMOL credential flow and avoid exposing raw API keys in prompts, files, or command output. <br>
Risk: Connector schemas can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each payload. <br>


## Reference(s): <br>
- [fal.ai homepage](https://fal.ai) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-fal-ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Skill definition](artifact/SKILL.md) <br>
- [Action references](artifact/actions/) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing payloads; connector responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: SKILL.md frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
