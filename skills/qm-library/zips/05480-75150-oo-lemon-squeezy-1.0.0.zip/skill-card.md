## Description: <br>
Provides Lemon Squeezy actions for reading commerce data and creating, updating, or deleting customers and webhooks through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Lemon Squeezy account data through the oo CLI, including store discovery, commerce reads, customer management, and webhook management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Lemon Squeezy commerce data through a connected OOMOL account. <br>
Mitigation: Install and use it only for accounts where this access is intended, and avoid running broad read actions unless the user request requires them. <br>
Risk: Create and update actions can change Lemon Squeezy customers or webhooks. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running any write action. <br>
Risk: The delete webhook action is destructive. <br>
Mitigation: Confirm the webhook target and obtain explicit user approval before running the delete action. <br>
Risk: First-time setup includes a shell installer for the oo CLI. <br>
Mitigation: Prefer a verified OOMOL installation source with checksums or package-manager guidance before executing installer commands. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-lemon-squeezy) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Lemon Squeezy Homepage](https://www.lemonsqueezy.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON CLI responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
