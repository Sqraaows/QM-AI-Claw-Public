## Description: <br>
Postmark lets an agent operate a connected Postmark account through OOMOL, including sending transactional email, managing templates, and inspecting delivery data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, support, and marketing operations teams use this skill to send transactional messages, manage Postmark templates, and review server, bounce, and outbound message information from a connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Send and template actions can deliver real email or alter production Postmark templates. <br>
Mitigation: Confirm the exact payload, recipients, template identifiers, and intended effect before approving send, create, or update actions. <br>
Risk: The skill requires access to a connected Postmark account through OOMOL. <br>
Mitigation: Install it only when agent access to that Postmark account is intended, and manage or revoke the OOMOL connection when access is no longer needed. <br>
Risk: Read actions can return server settings, delivery status, bounce records, and outbound message details. <br>
Mitigation: Use the skill only for authorized accounts and avoid sharing retrieved delivery or message data beyond the task. <br>


## Reference(s): <br>
- [ClawHub Postmark Skill](https://clawhub.ai/oomol/oo-postmark) <br>
- [Postmark Homepage](https://postmarkapp.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, Guidance, JSON] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payloads or results] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before constructing action payloads; write and send actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
