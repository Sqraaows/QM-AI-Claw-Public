## Description: <br>
agent-bom scan helps agents check packages, agent and MCP configurations, container images, filesystems, provenance, and SBOMs for vulnerability and supply-chain risk. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
Apache-2.0 <br>


## Use Case: <br>
Developers, security engineers, and agents use this skill to assess package CVEs, container images, agent and MCP inventory, SBOMs, and provenance before installation, CI gating, or remediation planning. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may inspect local agent, MCP, and user-provided SBOM configuration paths during inventory scans. <br>
Mitigation: Invoke it only for intended package, dependency, SBOM, or agent-inventory security checks and review scan scope before broad inventory scans. <br>
Risk: Advisory lookups may send public package names and CVE IDs to OSV, NVD, EPSS, and GitHub Advisories. <br>
Mitigation: Use it in environments where those identifiers may be shared with public vulnerability databases; review redaction behavior before scanning private environments. <br>
Risk: Broad prompts such as "is this safe" may trigger a security-scanning workflow when the user intended a narrower review. <br>
Mitigation: Use precise prompts and confirm intent before running package, dependency, SBOM, or agent-inventory scans. <br>


## Reference(s): <br>
- [agent-bom homepage](https://github.com/msaad00/agent-bom) <br>
- [agent-bom on PyPI](https://pypi.org/project/agent-bom/) <br>
- [OpenSSF Scorecard for agent-bom](https://securityscorecards.dev/viewer/?uri=github.com/msaad00/agent-bom) <br>
- [Redaction logic reference](https://github.com/msaad00/agent-bom/blob/main/src/agent_bom/security.py#L159) <br>
- [OSV vulnerability API](https://api.osv.dev/v1) <br>
- [NVD CVE API](https://services.nvd.nist.gov/rest/json/cves/2.0) <br>
- [FIRST EPSS API](https://api.first.org/data/v1/epss) <br>
- [GitHub Security Advisories API](https://api.github.com/advisories) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, JSON, SARIF, SBOM files, Shell commands, Guidance] <br>
**Output Format:** [Concise text recommendations, Markdown, JSON, SARIF, HTML, and CycloneDX/SPDX SBOMs depending on the workflow.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [No file writes are declared by the skill; advisory lookups may send public package names and CVE IDs to vulnerability databases.] <br>

## Skill Version(s): <br>
0.88.5 (source: server release metadata and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
