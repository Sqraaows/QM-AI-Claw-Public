## Description: <br>
Control air conditioners via Broadlink RM devices with multi-brand IR control, weather monitoring, typhoon alerts, and scheduled automation through a zero-config agent API. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oywq00008-cell](https://clawhub.ai/user/oywq00008-cell) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and AI agents use this skill to install and operate Broadlink RM-based air conditioner control, including IR commands, persisted configuration, weather checks, weather alerts, and scheduled automation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill stores AC configuration, API keys, and location details in ~/.ac_controller/config.json. <br>
Mitigation: Review file permissions, avoid reusing sensitive API keys, and remove credentials when the skill is no longer needed. <br>
Risk: Weather and alert features may share location or lookup data with external services. <br>
Mitigation: Disable or avoid network-backed weather features when location sharing is not acceptable. <br>


## Reference(s): <br>
- [Broadlinkac ClawHub skill page](https://clawhub.ai/oywq00008-cell/broadlinkac) <br>
- [Publisher profile](https://clawhub.ai/user/oywq00008-cell) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, shell commands, configuration] <br>
**Output Format:** [Markdown with bash and Python code examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include configuration paths, API usage examples, and operational guidance for AC control and weather features.] <br>

## Skill Version(s): <br>
3.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
