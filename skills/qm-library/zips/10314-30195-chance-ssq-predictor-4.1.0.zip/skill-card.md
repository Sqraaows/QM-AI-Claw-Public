## Description: <br>
双色球彩票数据分析与号码选择辅助工具，使用统计分析和趋势分析提供号码组合参考，仅供娱乐参考。 <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[gechengling](https://clawhub.ai/user/gechengling) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users can use this skill for entertainment-oriented SSQ lottery number analysis, including missing-value, frequency, sum, AC, span, parity, size, zone, and blue-ball summaries. The output should be treated as recreational guidance only, not as improved odds, financial advice, or a guarantee of lottery results. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Security evidence says the skill understates what it includes by claiming no executable prediction code while shipping and documenting a runnable lottery recommendation script. <br>
Mitigation: Review the script and documentation before installing or running it, and clearly disclose any executable behavior to users. <br>
Risk: Users may treat generated lottery numbers as improving odds or as financial advice. <br>
Mitigation: Keep entertainment-only disclaimers visible and avoid presenting recommendations as predictive, guaranteed, or investment guidance. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/gechengling/chance-ssq-predictor) <br>
- [Methodology reference](references/methodology.md) <br>
- [README](README.md) <br>
- [Official SSQ data reference](https://www.zhcw.com/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, guidance] <br>
**Output Format:** [Markdown with optional shell command examples and structured lottery analysis tables] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include generated red-ball and blue-ball combinations, statistical summaries, and entertainment-only disclaimers.] <br>

## Skill Version(s): <br>
4.1.0 (source: server release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
