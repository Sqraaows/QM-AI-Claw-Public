## Description: <br>
Airtable (airtable.com) supports Airtable requests that read, create, update, and delete data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent inspect Airtable bases and schemas, list or retrieve records, and create, update, or delete records after appropriate confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires trusted Airtable access through OOMOL-connected credentials. <br>
Mitigation: Install only when the user trusts OOMOL with the relevant Airtable account and has reviewed the Airtable connection scopes. <br>
Risk: Create and update actions can change Airtable records. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create or update actions. <br>
Risk: Delete actions can remove Airtable records. <br>
Mitigation: Confirm the target record IDs and obtain explicit user approval before running delete actions. <br>


## Reference(s): <br>
- [Airtable homepage](https://airtable.com) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Airtable skill page](https://clawhub.ai/oomol/oo-airtable) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses may include Airtable connector results, schema inspection guidance, and confirmation prompts for write or destructive actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
