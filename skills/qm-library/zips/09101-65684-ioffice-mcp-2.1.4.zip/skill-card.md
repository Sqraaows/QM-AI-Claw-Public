## Description: <br>
Access iOffice workspace and facility data via MCP for buildings, floors, spaces, reservations, visitors, maintenance requests, moves, and mail. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Authorized employees, workplace operations staff, and developers use this skill to connect an agent to an iOffice/Eptura Workplace tenant for room reservations, visitor management, maintenance requests, moves, mail, and workspace records. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and change workplace facility data, including employee, visitor, reservation, mail, move, maintenance, floor-plan, and user-directory records. <br>
Mitigation: Install only for authorized iOffice/Eptura tenants and use a least-privilege account or token approved by the organization. <br>
Risk: Some tools can delete records or change operational status, such as reservations, visitors, moves, maintenance requests, users, spaces, floors, and buildings. <br>
Mitigation: Require explicit user confirmation before delete, check-in, checkout, approval, cancellation, archive, or other status-changing actions. <br>
Risk: Broad access to employee, visitor, mail, floor-plan, and user-directory data may expose sensitive workplace information. <br>
Mitigation: Do not enable broad directory, visitor, mail, or floor-plan access unless the employer has approved that scope and the credential is limited to the minimum needed access. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/chrischall/ioffice-mcp) <br>
- [ioffice-mcp npm package](https://www.npmjs.com/package/ioffice-mcp) <br>
- [ioffice-mcp source repository](https://github.com/chrischall/ioffice-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Can guide MCP setup and agent use of iOffice API tools for tenant-specific workplace data.] <br>

## Skill Version(s): <br>
2.1.4 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
