## Description: <br>
Browse AI helps agents operate Browse AI through an OOMOL-connected account for reading, creating, and updating Browse AI data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to list and inspect Browse AI robots and tasks, start robot tasks, and update robot cookies through the oo CLI using a connected Browse AI account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Browse AI account and can operate workspace data. <br>
Mitigation: Install only when that access is intended, keep credentials managed through OOMOL, and avoid exposing raw tokens in prompts, logs, or files. <br>
Risk: Running robot tasks or updating cookies can change Browse AI state. <br>
Mitigation: Review the live schema and confirm the exact payload and intended effect with the user before state-changing actions. <br>
Risk: First-time setup may require installing the oo CLI. <br>
Mitigation: Verify the oo CLI installer before use and run setup steps only when an auth, connection, or missing-command error requires them. <br>


## Reference(s): <br>
- [Browse AI homepage](https://www.browse.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Browse AI skill page](https://clawhub.ai/oomol/oo-browse-ai) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing JSON payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
