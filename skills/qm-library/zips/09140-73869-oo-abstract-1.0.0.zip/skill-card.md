## Description: <br>
Abstract validates email addresses through an OOMOL-connected Abstract account and returns deliverability, quality, and risk checks. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to validate email addresses with Abstract through an OOMOL-connected account before relying on an address in a workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Email addresses are sent to Abstract through the OOMOL connector for validation. <br>
Mitigation: Confirm the user trusts OOMOL and Abstract for the intended validation data before running the connector. <br>
Risk: The skill may require an OOMOL account, Abstract connection, and sensitive credentials managed outside the agent. <br>
Mitigation: Use the existing connected account and do not request or handle raw Abstract credentials in the agent session. <br>
Risk: The optional oo CLI installer runs a downloaded install script. <br>
Mitigation: Run the installer only when the CLI is missing and the user accepts the OOMOL installation source. <br>


## Reference(s): <br>
- [Abstract homepage](https://www.abstractapi.com/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill directs the agent to inspect the live connector schema before constructing a payload and returns Abstract validation data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and SKILL.md metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
