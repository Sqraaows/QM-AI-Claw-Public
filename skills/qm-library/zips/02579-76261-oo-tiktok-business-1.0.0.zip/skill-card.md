## Description: <br>
Helps an agent read TikTok Business advertiser, campaign, and GMV Max data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Marketing teams, commerce operators, and analysts use this skill to inspect TikTok Business advertisers, campaigns, GMV Max stores, sessions, creative assets, reports, and bid recommendations from an already connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill reads TikTok Business and GMV Max data from the user's connected OOMOL account. <br>
Mitigation: Install it only when the user uses OOMOL for TikTok Business and has reviewed the connected-account scopes. <br>
Risk: The setup flow may require installing or authenticating the oo CLI before connector actions can run. <br>
Mitigation: Review the oo CLI install step and only run first-time setup when an action fails because the CLI, sign-in, or connection is missing. <br>
Risk: Future create, update, post, or delete actions would change TikTok Business state. <br>
Mitigation: Require explicit user confirmation for the exact payload and expected effect before running any future mutating action. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-tiktok-business) <br>
- [TikTok Business](https://business.tiktok.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before running actions; current artifact-backed actions are read-focused.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
