## Description: <br>
Fixer (fixer.io) lets an agent retrieve latest exchange rates, historical exchange rates, and supported currency symbols through the OOMOL Fixer connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users can use this skill to answer Fixer exchange-rate questions by inspecting the live connector schema and running read-only Fixer actions through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses authenticated OOMOL and Fixer connector access, so commands may depend on sensitive account credentials and live service state. <br>
Mitigation: Run only the documented read actions, inspect the live schema before constructing payloads, and perform setup or reconnection steps only when an auth or connection error requires them. <br>


## Reference(s): <br>
- [Fixer homepage](https://fixer.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Fixer skill on ClawHub](https://clawhub.ai/oomol/oo-fixer) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, JSON, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetch the live connector schema before building action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
