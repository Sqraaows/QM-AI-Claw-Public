# Acceptance Criteria — medical-appointment-prep

## Criterion 1: Complete Submission
- [ ] SKILL.md exists in `/Users/jianghaidong/.openclaw/skills/medical-appointment-prep/`
- [ ] skill.json exists and is valid JSON
- [ ] ACCEPTANCE.md exists

## Criterion 2: Content Requirements
- [ ] SKILL.md is prompt-only (no external credentials, API calls, or network dependencies)
- [ ] All content is English, zero CJK characters
- [ ] Safety boundaries are clearly defined in SKILL.md
- [ ] skill.json contains all required fields (schema, name, version, displayName, description, categories, license, locale, promptOnly, usage)

## Criterion 3: Functional Correctness
- [ ] Produces a structured symptom log (OLD CARTS or SOCRATES format) from user input
- [ ] Generates a prioritized question list (must ask / good to ask / if time allows)
- [ ] Creates a logistics checklist (documents, pre-appointment instructions, telehealth setup)
- [ ] Provides a post-appointment note template

## Criterion 4: Safety
- [ ] Contains disclaimer that it does not provide medical advice, diagnosis, or treatment
- [ ] Detects emergency/urgent symptoms and redirects to emergency services
- [ ] Does not contradict or replace physician advice
- [ ] Does not store or share health information
- [ ] Treats all user health data as ephemeral

## Criterion 5: Edge Cases
- [ ] Handles telehealth appointments (checks camera, microphone, internet, lighting)
- [ ] Handles first-time specialist visits (prompts for referral, prior records)
- [ ] Handles follow-up visits (prompts for previous visit notes, medication changes)
- [ ] When user provides minimal info, prompts systematically for symptoms and history

## Verification
- [ ] Run `cat skill.json | python3 -m json.tool` confirms valid JSON
- [ ] No API keys, tokens, or URLs present in any file
- [ ] All 3 files are readable and non-empty
