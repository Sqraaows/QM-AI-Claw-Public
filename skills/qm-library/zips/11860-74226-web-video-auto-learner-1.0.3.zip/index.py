"""
网络视频辅助学习技能 - OpenClaw Skill 入口

提供 WebVideoAutoLearner 类作为统一 API 接口，
支持编程式调用（无 GUI）和 GUI 模式两种运行方式。

用法:
    # 编程式调用（无GUI）
    from index import WebVideoAutoLearner
    learner = WebVideoAutoLearner(mode="headless")
    learner.configure(browser_type="chrome", login_url="https://www.example.com/")
    result = learner.run()

    # GUI 模式
    learner = WebVideoAutoLearner(mode="simple")
    learner.start()
"""

import os
import sys
import threading
from typing import Optional, Dict, Any, List

# 确保模块搜索路径包含 src 目录
_skill_dir = os.path.dirname(os.path.abspath(__file__))
_src_dir = os.path.join(_skill_dir, 'src')
if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)
if _skill_dir not in sys.path:
    sys.path.insert(0, _skill_dir)

from src.logger import setup_logger
from src.config_loader import ConfigLoader
from src.browser import BrowserManager
from src.popup_handler import PopupHandler
from src.task_runner import TaskRunner
from src.media_progress_saver import MediaProgressSaver
from src.encryption import (
    encrypt_storage_state,
    decrypt_storage_state,
    save_encrypted_storage_state,
    load_encrypted_storage_state,
)


class WebVideoAutoLearner:
    """网络视频辅助学习技能 - 主控类

    封装所有核心模块，提供简洁的编程式 API。

    Args:
        mode: 运行模式
            - "all": 完整控制台 GUI
            - "simple": 简约模式 GUI
            - "list": 播放列表模式 GUI
            - "headless": 无 GUI 编程式调用
        config_path: 自定义配置文件路径（留空使用默认）
        log_level: 日志级别（DEBUG/INFO/WARNING/ERROR）
    """

    # 支持的运行模式
    VALID_MODES = {"all", "simple", "list", "headless"}

    def __init__(
        self,
        mode: str = "headless",
        config_path: Optional[str] = None,
        log_level: str = "INFO",
    ):
        if mode not in self.VALID_MODES:
            raise ValueError(f"无效模式 '{mode}'，支持: {self.VALID_MODES}")

        self.mode = mode
        self._log_level = log_level
        self._status = "initialized"  # initialized / running / paused / stopped / completed / error

        # 初始化日志
        self.logger = setup_logger(name="web_video_auto_learner")
        self.logger.setLevel(getattr(__import__('logging'), log_level, 20))

        # 初始化配置
        if config_path is None:
            config_path = os.path.join(_skill_dir, "config", "config.yaml")
        self.config_loader = ConfigLoader(config_path=config_path)

        # 核心组件（延迟初始化）
        self.browser: Optional[BrowserManager] = None
        self.popup_handler: Optional[PopupHandler] = None
        self.task_runner: Optional[TaskRunner] = None
        self.progress_saver: Optional[MediaProgressSaver] = None

        # 运行时状态
        self._result: Dict[str, Any] = {"status": "initialized", "progress": {}, "popup_events": []}
        self._control_panel = None

    # ================================================================
    #  公共 API — 配置
    # ================================================================

    @property
    def status(self) -> str:
        """当前运行状态"""
        return self._status

    @property
    def result(self) -> Dict[str, Any]:
        """执行结果"""
        return self._result

    def configure(
        self,
        browser_type: str = "chrome",
        login_url: str = "https://www.example.com/",
        navigation_steps: Optional[List[Dict]] = None,
        popup_rules: Optional[List[Dict]] = None,
        headless: bool = False,
        window_max: bool = True,
        browser_path: Optional[str] = None,
        storage_state: bool = False,
        storage_state_file: str = "storage_state.enc",
        **kwargs,
    ) -> "WebVideoAutoLearner":
        """配置自动化参数（链式调用）

        Args:
            browser_type: 浏览器类型 (chrome/msedge/360ee/360se)
            login_url: 登录页面 URL
            navigation_steps: 导航步骤列表
            popup_rules: 弹窗处理规则列表
            headless: 是否无头浏览器
            window_max: 是否最大化窗口
            browser_path: 浏览器可执行文件路径
            storage_state: 是否启用 Storage State 免登录
            storage_state_file: Storage State 加密文件名
            **kwargs: 其他配置项

        Returns:
            self（支持链式调用）
        """
        # 加载当前配置
        try:
            self.config_loader.load()
        except Exception:
            pass

        # 更新 settings
        settings = self.config_loader.get_settings()
        settings["browser_type"] = browser_type
        settings["window_max"] = window_max
        settings["headless"] = headless
        if browser_path:
            settings["browser_path"] = browser_path
        settings.update(kwargs)
        self.config_loader.set_settings(settings)

        # 更新 website
        website = self.config_loader.get_website()
        website["login_url"] = login_url
        website["storage_state"] = storage_state
        website["storage_state_file"] = storage_state_file
        self.config_loader.set_website(website)

        # 更新导航步骤
        if navigation_steps is not None:
            self.config_loader.set_navigation(navigation_steps)

        # 更新弹窗规则
        if popup_rules is not None:
            self.config_loader.set_popup_rules(popup_rules)

        # 保存配置
        self.config_loader.save()
        self.logger.info("配置已更新")
        return self

    # ================================================================
    #  播放列表 URL 管理（便捷方法）
    # ================================================================

    def _ensure_play_list_step(self) -> dict:
        """确保导航步骤中存在 play_list 类型的步骤，不存在则创建。
        
        Returns:
            导航步骤中 action=play_list 的那一项（dict）
        """
        navigation = self.config_loader.get_navigation()
        for step in navigation:
            if step.get('action') == 'play_list':
                return step
        # 不存在则创建
        step = {
            'name': '播放列表',
            'action': 'play_list',
            'url': '',
            'selector': '',
            'tab_index': -1,
            'stay_time': 3,
            'loop_infinite': True,
            'loop_count': 0,
            'media_timeout': '3600',
            'play_list': [],
            'popup_rules': [],
        }
        navigation.append(step)
        self.config_loader.set_navigation(navigation)
        self.config_loader.save()
        self.logger.info("[播放列表] 已创建 play_list 导航步骤")
        return step

    def add_play_url(self, url: str, click_play: bool = True,
                     selector: str = '', course_name: str = '') -> "WebVideoAutoLearner":
        """向播放列表添加单个视频 URL。
        
        Args:
            url: 视频页面 URL
            click_play: 是否需要自动点击播放按钮（默认 True）
            selector: 自定义视频选择器（留空则自动查找）
            course_name: 课程名称（仅用于日志标识）
            
        Returns:
            self（支持链式调用）
        
        Example:
            learner.add_play_url(
                "https://www.example.com/videoDisplay?coursewareId=xxx",
                click_play=True
            )
        """
        step = self._ensure_play_list_step()
        play_list = step.setdefault('play_list', [])
        
        # 检查是否已存在相同 URL
        for item in play_list:
            if item.get('url', '') == url:
                self.logger.info(f"[播放列表] URL 已存在，跳过: {url[:80]}")
                return self
        
        item = {
            'url': url,
            '选择器': selector,
            'click_play': click_play,
            'completed': False,
        }
        if course_name:
            item['course_name'] = course_name
        play_list.append(item)
        
        self.config_loader.set_navigation(
            self.config_loader.get_navigation()
        )
        self.config_loader.save()
        label = course_name or url[:60]
        self.logger.info(f"[播放列表] 已添加: {label} (当前共 {len(play_list)} 项)")
        return self

    def add_play_urls(self, urls: list, click_play: bool = True,
                      selector: str = '') -> "WebVideoAutoLearner":
        """批量添加多个视频 URL 到播放列表。
        
        Args:
            urls: URL 字符串列表，或 (url, course_name) 元组列表
            click_play: 是否自动点击播放按钮
            selector: 自定义选择器
            
        Returns:
            self（支持链式调用）
        
        Example:
            learner.add_play_urls([
                "https://www.example.com/videoDisplay?coursewareId=xxx",
                ("https://...", "课程A"),
            ])
        """
        for item in urls:
            if isinstance(item, (tuple, list)):
                url, name = item[0], item[1] if len(item) > 1 else ''
                self.add_play_url(url, click_play=click_play, selector=selector, course_name=name)
            else:
                self.add_play_url(item, click_play=click_play, selector=selector)
        return self

    def set_play_urls(self, urls: list, click_play: bool = True,
                      selector: str = '') -> "WebVideoAutoLearner":
        """替换播放列表中的所有 URL（清空后重新设置）。
        
        Args:
            urls: URL 字符串列表
            click_play: 是否自动点击播放按钮
            selector: 自定义选择器
            
        Returns:
            self（支持链式调用）
        """
        self.clear_play_urls()
        return self.add_play_urls(urls, click_play=click_play, selector=selector)

    def remove_play_url(self, url: str) -> "WebVideoAutoLearner":
        """从播放列表中移除指定的 URL。
        
        Args:
            url: 要移除的视频 URL
            
        Returns:
            self（支持链式调用）
        """
        step = self._ensure_play_list_step()
        play_list = step.setdefault('play_list', [])
        orig_len = len(play_list)
        step['play_list'] = [item for item in play_list if item.get('url', '') != url]
        removed = orig_len - len(step['play_list'])
        
        if removed > 0:
            self.config_loader.set_navigation(
                self.config_loader.get_navigation()
            )
            self.config_loader.save()
            self.logger.info(f"[播放列表] 已移除 {removed} 项: {url[:80]}")
        else:
            self.logger.warning(f"[播放列表] 未找到要移除的 URL: {url[:80]}")
        return self

    def clear_play_urls(self) -> "WebVideoAutoLearner":
        """清空播放列表中所有 URL。
        
        Returns:
            self（支持链式调用）
        """
        step = self._ensure_play_list_step()
        play_list = step.get('play_list', [])
        count = len(play_list)
        step['play_list'] = []
        self.config_loader.set_navigation(
            self.config_loader.get_navigation()
        )
        self.config_loader.save()
        self.logger.info(f"[播放列表] 已清空 {count} 项")
        return self

    def get_play_urls(self) -> list:
        """获取当前播放列表中的所有 URL。
        
        Returns:
            播放列表项列表，每项包含 url, click_play, completed 等字段
        """
        navigation = self.config_loader.get_navigation()
        for step in navigation:
            if step.get('action') == 'play_list':
                return step.get('play_list', [])
        return []

    def reset_play_progress(self) -> "WebVideoAutoLearner":
        """重置所有播放项的完成状态（completed → False），重现从头播放。
        
        Returns:
            self（支持链式调用）
        """
        navigation = self.config_loader.get_navigation()
        reset_count = 0
        for step in navigation:
            if step.get('action') == 'play_list':
                for item in step.get('play_list', []):
                    if item.get('completed', False):
                        item['completed'] = False
                        reset_count += 1
        if reset_count > 0:
            self.config_loader.set_navigation(navigation)
            self.config_loader.save()
            self.logger.info(f"[播放列表] 已重置 {reset_count} 项完成状态")
        return self

    # ================================================================
    #  视频录制和 AI 总结功能
    # ================================================================

    def _init_video_processor(self):
        """初始化视频处理器"""
        if not hasattr(self, '_video_processor'):
            try:
                from src.video_processor import VideoProcessor
                self._video_processor = VideoProcessor(self.config_loader.config)
                self.logger.info("[视频处理] 处理器已初始化")
            except ImportError as e:
                self.logger.error(f"[视频处理] 初始化失败: {e}")
                self._video_processor = None
        return self._video_processor

    def enable_recording(self, recording_type: str = "video") -> "WebVideoAutoLearner":
        """启用录制功能

        Args:
            recording_type: 录制类型 ("video"=视频录制, "audio"=音频录制, "all"=两者都启用)
        """
        settings = self.config_loader.get_settings()

        if recording_type in ("video", "all"):
            recording = settings.get('recording', {})
            recording['enabled'] = True
            settings['recording'] = recording
            self.logger.info("[视频录制] 已启用")

        if recording_type in ("audio", "all"):
            # 确保 recordings_dir 存在
            recordings_dir = settings.get('recordings_dir', 'recordings')
            self.logger.info(f"[音频录制] 已启用，保存目录: {recordings_dir}")

        self.config_loader.set_settings(settings)
        return self

    def disable_recording(self, recording_type: str = "video") -> "WebVideoAutoLearner":
        """禁用录制功能

        Args:
            recording_type: 录制类型 ("video"=视频录制, "audio"=音频录制, "all"=两者都禁用)
        """
        settings = self.config_loader.get_settings()

        if recording_type in ("video", "all"):
            recording = settings.get('recording', {})
            recording['enabled'] = False
            settings['recording'] = recording
            self.logger.info("[视频录制] 已禁用")

        if recording_type in ("audio", "all"):
            self.logger.info("[音频录制] 已禁用")

        self.config_loader.set_settings(settings)
        return self

    def set_audio_recording_for_playlist(self, enable: bool = True) -> "WebVideoAutoLearner":
        """设置播放列表步骤的音频录制开关

        Args:
            enable: 是否启用音频录制

        Returns:
            self（支持链式调用）
        """
        step = self._ensure_play_list_step()
        step['enable_recording'] = enable
        self.config_loader.set_navigation(
            self.config_loader.get_navigation()
        )
        self.config_loader.save()
        status = "已启用" if enable else "已禁用"
        self.logger.info(f"[播放列表音频录制] {status}")
        return self

    def get_audio_recording_status(self) -> dict:
        """获取音频录制状态

        Returns:
            dict: 包含录制状态的字典
        """
        step = self._ensure_play_list_step()
        return {
            'enable_recording': step.get('enable_recording', False),
            'recordings_dir': self.config_loader.get_settings().get('recordings_dir', 'recordings')
        }

    def enable_ai_summary(self, api_key: str = None, provider: str = "siliconflow") -> "WebVideoAutoLearner":
        """启用 AI 总结功能

        Args:
            api_key: API 密钥（可选，不提供则使用配置文件中的）
            provider: AI 提供商 (openai/siliconflow/ollama)
        """
        settings = self.config_loader.get_settings()
        ai_summary = settings.get('ai_summary', {})
        ai_summary['enabled'] = True
        if api_key:
            ai_summary['api_key'] = api_key
        if provider:
            ai_summary['provider'] = provider
        settings['ai_summary'] = ai_summary
        self.config_loader.set_settings(settings)
        self.logger.info(f"[AI总结] 已启用，使用 {provider} 提供商")
        return self

    def disable_ai_summary(self) -> "WebVideoAutoLearner":
        """禁用 AI 总结功能"""
        settings = self.config_loader.get_settings()
        ai_summary = settings.get('ai_summary', {})
        ai_summary['enabled'] = False
        settings['ai_summary'] = ai_summary
        self.config_loader.set_settings(settings)
        self.logger.info("[AI总结] 已禁用")
        return self

    def transcribe_video(self, video_path: str, use_api: bool = False) -> dict:
        """转录视频为文字

        Args:
            video_path: 视频文件路径
            use_api: 是否使用 API 转录（需要配置 API）

        Returns:
            dict: 转录结果，包含文本、段落、时间戳等
        """
        processor = self._init_video_processor()
        if not processor or not processor.transcriber:
            self.logger.error("[转录] 转录模块未就绪")
            return None

        ai_config = self.config_loader.get_settings().get('ai_summary', {})
        if use_api:
            return processor.transcriber.transcribe(video_path, use_api=True, api_config=ai_config)
        else:
            return processor.transcriber.transcribe_video(video_path, model_size='base', language='zh')

    def summarize_video(self, video_path: str, video_title: str = "",
                       use_local: bool = False) -> str:
        """生成视频 AI 总结

        Args:
            video_path: 视频文件路径
            video_title: 视频标题
            use_local: 是否使用本地 AI 模型

        Returns:
            str: 总结内容（Markdown 格式）
        """
        processor = self._init_video_processor()
        if not processor:
            self.logger.error("[总结] 处理器未初始化")
            return None

        # 转录
        self.logger.info("[总结] 正在转录视频...")
        transcription = self.transcribe_video(video_path)
        if not transcription:
            self.logger.error("[总结] 转录失败")
            return None

        # 生成总结
        summary = processor.summarizer.generate_meeting_notes(
            transcription,
            video_title,
            use_local=use_local
        )

        if summary:
            # 保存总结
            import os
            from datetime import datetime
            summary_dir = os.path.join(os.path.dirname(self.config_loader.config_path), 'summaries')
            os.makedirs(summary_dir, exist_ok=True)
            summary_file = os.path.join(summary_dir, f"summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write(summary)
            self.logger.info(f"[总结] 已保存到: {summary_file}")

        return summary

    def process_and_summarize(self, video_path: str, video_title: str = "",
                             use_local: bool = False) -> dict:
        """一站式处理：录制 -> 转录 -> 总结

        Args:
            video_path: 视频文件路径
            video_title: 视频标题
            use_local: 是否使用本地 AI

        Returns:
            dict: 包含转录和总结的完整结果
        """
        processor = self._init_video_processor()
        if not processor:
            return None

        return processor.process_video(
            video_path,
            video_title=video_title,
            auto_transcribe=True,
            auto_summarize=True,
            use_local_ai=use_local
        )

    def get_recorded_videos(self) -> list:
        """获取已录制的视频列表"""
        processor = self._init_video_processor()
        if not processor:
            return []
        return processor.get_recordings()

    def get_summaries(self) -> list:
        """获取已生成的总结列表"""
        processor = self._init_video_processor()
        if not processor:
            return []
        return processor.get_summaries()

    # ================================================================
    #  AI 模型配置和调用
    # ================================================================

    def _init_ai_model(self):
        """初始化 AI 模型模块"""
        if not hasattr(self, '_ai_model_caller'):
            try:
                from src.ai_model import AIModelCaller, AIModelConfig
                self._ai_model_config = AIModelConfig()
                self._ai_model_caller = AIModelCaller()
                self.logger.info("[AI模型] 已初始化")
            except ImportError as e:
                self.logger.error(f"[AI模型] 初始化失败: {e}")
                self._ai_model_caller = None
        return self._ai_model_caller

    def get_ai_config_status(self) -> dict:
        """获取 AI 配置状态

        Returns:
            dict: 配置状态信息
        """
        config = self._init_ai_model()
        if not config:
            return {'ready': False, 'error': '模块未加载'}

        providers = config.config.config.get('models', {})
        status = {
            'ready': config.config.is_provider_ready(),
            'default_provider': config.config.get_global('default_provider'),
            'enabled_providers': config.config.get_enabled_providers(),
            'providers': {}
        }

        for name, cfg in providers.items():
            status['providers'][name] = {
                'enabled': cfg.get('enabled', False),
                'has_api_key': bool(cfg.get('api_key', '').strip()),
                'model': cfg.get('chat_model', '')
            }

        return status

    def set_ai_api_key(self, provider: str, api_key: str) -> bool:
        """设置 AI API 密钥

        Args:
            provider: 提供商名称 (siliconflow/openai/ollama/deepseek)
            api_key: API 密钥

        Returns:
            bool: 是否设置成功
        """
        config = self._init_ai_model()
        if not config:
            return False

        success = config.config.set_api_key(provider, api_key)
        if success:
            self.logger.info(f"[AI模型] 已设置 {provider} API 密钥")
        return success

    def set_auto_answer(self, enabled: bool) -> bool:
        """设置自动答题开关

        Args:
            enabled: True=开启 / False=关闭

        Returns:
            bool: 是否设置成功
        """
        self.config_loader.set_auto_answer(enabled)
        self.config_loader.save()
        # 如果 PopupHandler 已初始化，同步更新
        if self.popup_handler:
            self.popup_handler.auto_answer_enabled = enabled
        status = "开启" if enabled else "关闭"
        self.logger.info(f"[自动答题] 已{status}")
        return True

    def is_auto_answer_enabled(self) -> bool:
        """获取自动答题开关状态

        Returns:
            bool: 是否开启
        """
        return self.config_loader.is_auto_answer_enabled()

    def call_ai(self, prompt: str, system_prompt: str = None,
                provider: str = None, **kwargs) -> str:
        """调用 AI 模型

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词（可选）
            provider: 提供商名称（可选）
            **kwargs: 其他模型参数

        Returns:
            str: AI 生成的文本
        """
        caller = self._init_ai_model()
        if not caller:
            self.logger.error("[AI模型] 未初始化")
            return None

        try:
            return caller.call(prompt, system_prompt, provider, **kwargs)
        except Exception as e:
            self.logger.error(f"[AI模型] 调用失败: {e}")
            return None

    def call_ai_with_prompt_template(self, template_name: str, prompt: str,
                                      provider: str = None, **variables) -> str:
        """使用预定义提示词模板调用 AI

        Args:
            template_name: 模板名称 (meeting_notes/summary/key_points/default)
            prompt: 用户内容
            provider: 提供商名称
            **variables: 模板变量

        Returns:
            str: AI 生成的文本
        """
        caller = self._init_ai_model()
        if not caller:
            return None

        system_prompt = caller.get_system_prompt(template_name)
        formatted_prompt = caller.format_prompt(prompt, **variables)

        return self.call_ai(formatted_prompt, system_prompt, provider)

    def add_custom_system_prompt(self, name: str, content: str,
                                  description: str = None,
                                  variables: list = None) -> bool:
        """添加自定义系统提示词

        Args:
            name: 提示词名称（唯一标识）
            content: 提示词内容
            description: 描述（可选）
            variables: 变量列表（可选）

        Returns:
            bool: 是否添加成功
        """
        config = self._init_ai_model()
        if not config:
            return False

        success = config.config.add_system_prompt(name, content, description, variables)
        if success:
            self.logger.info(f"[AI模型] 已添加提示词模板: {name}")
        return success

    def list_system_prompts(self) -> dict:
        """列出所有系统提示词

        Returns:
            dict: 提示词配置
        """
        config = self._init_ai_model()
        if not config:
            return {}
        return config.config.get_all_prompts()

    # ================================================================
    #  登录信息管理（安全存储 / 读取 / 删除）
    # ================================================================

    def _get_storage_path(self) -> str:
        """获取 storage_state 文件的完整路径。

        Returns:
            .enc 加密文件的绝对路径
        """
        website = self.config_loader.get_website()
        sfn = website.get('storage_state_file', 'storage_state.enc')
        if not sfn.endswith('.enc'):
            sfn = sfn.rsplit('.', 1)[0] + '.enc'
        path = os.path.join(
            os.path.dirname(self.config_loader.config_path), sfn
        )
        return os.path.abspath(path)

    def save_login_state(self, filepath: Optional[str] = None) -> Dict[str, Any]:
        """保存当前浏览器的登录状态到加密文件。

        加密机制基于设备特征派生密钥（PBKDF2HMAC-SHA256），仅在当前设备可解密。

        Args:
            filepath: 保存路径（可选，默认使用配置中的 storage_state_file）

        Returns:
            {'success': bool, 'filepath': str, 'error': str|None}
        """
        try:
            save_path = filepath or self._get_storage_path()
            if not save_path.endswith('.enc'):
                save_path = save_path.rsplit('.', 1)[0] + '.enc'

            # 浏览器必须已启动且有活跃上下文
            if not self.browser or not self.browser.context:
                return {
                    'success': False,
                    'filepath': save_path,
                    'error': '浏览器未启动，无法保存登录信息'
                }

            if self.browser.save_storage_state(save_path, encrypt=True):
                # 同步更新配置中的 storage_state 开关
                website = self.config_loader.get_website()
                website['storage_state'] = True
                website['storage_state_file'] = os.path.basename(save_path)
                self.config_loader.set_website(website)
                self.config_loader.save()

                self.logger.info(f"[登录信息] 已安全保存: {save_path}")
                return {
                    'success': True,
                    'filepath': save_path,
                    'error': None
                }
            else:
                return {
                    'success': False,
                    'filepath': save_path,
                    'error': '保存失败（浏览器内部错误）'
                }
        except Exception as e:
            self.logger.error(f"[登录信息] 保存异常: {e}")
            return {
                'success': False,
                'filepath': filepath or self._get_storage_path(),
                'error': str(e)
            }

    def check_login_state(self, filepath: Optional[str] = None) -> Dict[str, Any]:
        """检查是否存在有效的已保存登录状态。

        Args:
            filepath: 文件路径（可选，默认使用配置中的 storage_state_file）

        Returns:
            {
                'exists': bool,
                'valid': bool,
                'filepath': str,
                'size_bytes': int|None,
                'last_modified': str|None,        # ISO 格式
                'file_age_seconds': int|None,      # 文件已存在多少秒
                'error': str|None
            }
        """
        import datetime
        try:
            check_path = filepath or self._get_storage_path()
            info = {
                'exists': False,
                'valid': False,
                'filepath': check_path,
                'size_bytes': None,
                'last_modified': None,
                'file_age_seconds': None,
                'error': None,
            }

            if not os.path.isfile(check_path):
                info['error'] = '文件不存在'
                return info

            info['exists'] = True
            stat = os.stat(check_path)
            info['size_bytes'] = stat.st_size
            mtime = datetime.datetime.fromtimestamp(stat.st_mtime)
            info['last_modified'] = mtime.isoformat()
            info['file_age_seconds'] = int(
                (datetime.datetime.now() - mtime).total_seconds()
            )

            # 验证文件可解密（完整性校验）
            if check_path.endswith('.enc'):
                try:
                    state = load_encrypted_storage_state(check_path)
                    if state is not None:
                        info['valid'] = True
                    else:
                        info['error'] = '解密失败（文件损坏或密钥不匹配）'
                except Exception as e:
                    info['error'] = f'验证失败: {e}'
            else:
                # 明文 json 文件：验证 JSON 格式
                try:
                    import json as _json
                    with open(check_path, 'r', encoding='utf-8') as f:
                        _json.load(f)
                    info['valid'] = True
                except Exception as e:
                    info['error'] = f'JSON 格式无效: {e}'

            return info
        except Exception as e:
            self.logger.error(f"[登录信息] 检查异常: {e}")
            return {
                'exists': False,
                'valid': False,
                'filepath': filepath or '',
                'size_bytes': None,
                'last_modified': None,
                'file_age_seconds': None,
                'error': str(e)
            }

    def delete_login_state(self, filepath: Optional[str] = None) -> Dict[str, Any]:
        """删除已保存的登录状态文件。

        Args:
            filepath: 文件路径（可选，默认使用配置中的 storage_state_file）

        Returns:
            {'success': bool, 'filepath': str, 'error': str|None}
        """
        try:
            del_path = filepath or self._get_storage_path()
            if not os.path.isfile(del_path):
                return {
                    'success': True,  # 文件不存在也算"删除成功"
                    'filepath': del_path,
                    'error': None,
                    'note': '文件原本不存在'
                }

            os.remove(del_path)
            self.logger.info(f"[登录信息] 已删除: {del_path}")

            # 同步更新配置：关闭 storage_state 但保留文件名
            website = self.config_loader.get_website()
            website['storage_state'] = False
            self.config_loader.set_website(website)
            self.config_loader.save()

            return {
                'success': True,
                'filepath': del_path,
                'error': None
            }
        except Exception as e:
            return {
                'success': False,
                'filepath': filepath or '',
                'error': f'删除失败: {e}'
            }

    def load_login_state_into_browser(
        self, filepath: Optional[str] = None
    ) -> Dict[str, Any]:
        """将已保存的登录状态加载到当前浏览器会话中。

        仅在浏览器已启动但未登录时使用。正常启动时通过
        configure(storage_state=True) 自动加载。

        Args:
            filepath: 文件路径（可选，默认使用配置中的 storage_state_file）

        Returns:
            {'success': bool, 'cookies_count': int, 'error': str|None}
        """
        try:
            load_path = filepath or self._get_storage_path()
            if not os.path.isfile(load_path):
                return {
                    'success': False,
                    'cookies_count': 0,
                    'error': f'文件不存在: {load_path}'
                }
            if not self.browser or not self.browser.context:
                return {
                    'success': False,
                    'cookies_count': 0,
                    'error': '浏览器未启动，无法加载登录信息'
                }

            state = self.browser.load_storage_state(load_path)
            if not state:
                return {
                    'success': False,
                    'cookies_count': 0,
                    'error': '解密失败，文件可能已损坏'
                }

            # 将 cookies 注入当前 context
            cookies = state.get('cookies', [])
            if cookies:
                self.browser.context.add_cookies(cookies)

            self.logger.info(
                f"[登录信息] 已加载 {len(cookies)} 个 cookie: {load_path}"
            )
            return {
                'success': True,
                'cookies_count': len(cookies),
                'error': None
            }
        except Exception as e:
            self.logger.error(f"[登录信息] 加载异常: {e}")
            return {
                'success': False,
                'cookies_count': 0,
                'error': str(e)
            }

    def get_login_state_info(self) -> Dict[str, Any]:
        """获取登录状态的汇总信息。

        Returns:
            {
                'storage_enabled': bool,     # 配置中是否启用免登录
                'file_path': str,           # storage 文件路径
                'file_exists': bool,        # 文件是否存在
                'file_valid': bool,         # 文件是否有效（可解密）
                'browser_logged_in': bool,  # 当前浏览器是否有登录 cookie
                'cookies_count': int,       # 当前浏览器会话 cookie 数
            }
        """
        info = {
            'storage_enabled': False,
            'file_path': self._get_storage_path(),
            'file_exists': False,
            'file_valid': False,
            'browser_logged_in': False,
            'cookies_count': 0,
        }

        # 配置状态
        website = self.config_loader.get_website()
        info['storage_enabled'] = website.get('storage_state', False)

        # 文件状态
        check = self.check_login_state()
        info['file_exists'] = check['exists']
        info['file_valid'] = check['valid']

        # 当前浏览器会话中的 cookies
        try:
            if self.browser and self.browser.context:
                cookies = self.browser.context.cookies()
                info['cookies_count'] = len(cookies)
                info['browser_logged_in'] = len(cookies) > 0
        except Exception:
            pass

        return info

    # ================================================================
    #  运行控制
    # ================================================================

    def start(self) -> None:
        """启动自动化（GUI 模式）

        根据 mode 参数显示对应 GUI 控制面板并进入事件循环。
        此方法会阻塞直到 GUI 关闭。

        仅适用于 mode="all"/"simple"/"list"。
        """
        if self.mode == "headless":
            raise RuntimeError("headless 模式请使用 run() 方法")

        self._init_components()

        # 导入 GUI 模块
        from src.control_panel import ControlPanel

        self._control_panel = ControlPanel(
            self.config_loader, self.browser, self.task_runner,
            self.popup_handler, self.logger, mode=self.mode
        )
        self.task_runner.control_panel = self._control_panel
        self.popup_handler.set_pw_caller(self._control_panel.call_on_main_thread)

        # 注册弹窗回调
        self._register_popup_callbacks()

        # 设置控制面板回调
        self._control_panel.set_on_start(self._on_start)
        self._control_panel.set_on_pause(self._on_pause)
        self._control_panel.set_on_resume(self._on_resume)
        self._control_panel.set_on_stop(self._on_stop)

        self.logger.info("请点击控制面板的「开始自动化」按钮启动浏览器并开始自动化")
        self._status = "running"

        try:
            self._control_panel.show()
        except KeyboardInterrupt:
            self.logger.info("程序已终止")
        finally:
            self.progress_saver.stop()
            self.browser.close(force=True)
            self._status = "stopped"

    def run(self) -> Dict[str, Any]:
        """执行自动化（编程式调用，无 GUI）

        启动浏览器、执行导航步骤、处理弹窗，完成后返回结果。
        此方法会阻塞直到自动化流程结束。

        Returns:
            执行结果字典:
            {
                "status": "completed" / "error",
                "progress": {...},
                "popup_events": [...],
                "error": None / str
            }
        """
        self._init_components()
        self._status = "running"
        self._result = {"status": "running", "progress": {}, "popup_events": [], "error": None}

        try:
            # 加载配置
            settings = self.config_loader.get_settings()
            website = self.config_loader.get_website()

            # 启动浏览器
            bt = settings.get("browser_type", "chrome")
            wm = settings.get("window_max", True)
            bp = settings.get("browser_path", "") or None
            lu = website.get("login_url", "")
            hl = settings.get("headless", False)

            # Storage State 配置
            ss = website.get("storage_state", False)
            sf = None
            if ss:
                sfn = website.get("storage_state_file", "storage_state.enc")
                if not sfn.endswith(".enc"):
                    sfn = sfn.rsplit(".", 1)[0] + ".enc"
                sf = os.path.join(os.path.dirname(self.config_loader.config_path), sfn)
                sf = os.path.abspath(sf)
                if not os.path.isfile(sf):
                    sf = None

            if not self.browser.ensure_open(bt, wm, browser_path=bp, login_url=lu, storage_state_file=sf, headless=hl):
                self._result["status"] = "error"
                self._result["error"] = "浏览器启动失败"
                self._status = "error"
                return self._result

            # 更新弹窗处理器的页面引用
            self.popup_handler.page = self.browser.page
            self.popup_handler.register_dialog_handler()

            # 仅在有 mylayer 弹窗规则时注入处理脚本
            has_layer_rule = any(r.get('type') == 'layer' for r in self.popup_handler.popup_rules)
            if has_layer_rule:
                self.browser.inject_mylayer_handler()

            # 仅在有弹窗规则时启动监听
            if self.popup_handler.popup_rules:
                scan_interval = settings.get("popup_scan_interval", 2.0)
                self.popup_handler.start_listening(check_interval=scan_interval)

            # 启动进度守护
            self.progress_saver.start()
            self.task_runner.progress_saver = self.progress_saver

            # 执行导航
            self.task_runner.run_navigation()

            # 完成
            self.popup_handler.stop_listening()
            self.progress_saver.save_now()
            self.progress_saver.stop()

            self._result["status"] = "completed"
            self._status = "completed"
            self.logger.info("自动化流程已完成")

        except Exception as e:
            self._result["status"] = "error"
            self._result["error"] = str(e)
            self._status = "error"
            self.logger.error(f"自动化执行异常: {e}")

        finally:
            if self.browser:
                self.browser.close(force=True)

        return self._result

    def pause(self) -> None:
        """暂停当前自动化"""
        if self.task_runner:
            self.task_runner.pause()
            self._status = "paused"

    def resume(self) -> None:
        """恢复已暂停的自动化"""
        if self.task_runner:
            self.task_runner.resume()
            self._status = "running"

    def stop(self) -> None:
        """停止当前自动化"""
        if self.task_runner:
            self.task_runner.stop()
        if self.popup_handler:
            self.popup_handler.stop_listening()
        if self.progress_saver:
            self.progress_saver.save_now()
            self.progress_saver.stop()
        self._status = "stopped"

    def start_popup_only(self) -> Dict[str, Any]:
        """仅启动弹窗监听模式（不执行导航步骤）

        Returns:
            {"status": "listening", "popup_events": []}
        """
        self._init_components()
        settings = self.config_loader.get_settings()
        website = self.config_loader.get_website()

        bt = settings.get("browser_type", "chrome")
        wm = settings.get("window_max", True)
        bp = settings.get("browser_path", "") or None
        lu = website.get("login_url", "")

        if not self.browser.ensure_open(bt, wm, browser_path=bp, login_url=lu):
            return {"status": "error", "error": "浏览器启动失败", "popup_events": []}

        self.popup_handler.page = self.browser.page
        self.popup_handler.register_dialog_handler()

        # 仅在有 mylayer 弹窗规则时注入处理脚本
        has_layer_rule = any(r.get('type') == 'layer' for r in self.popup_handler.popup_rules)
        if has_layer_rule:
            self.browser.inject_mylayer_handler()

        # 仅在有弹窗规则时启动监听
        if self.popup_handler.popup_rules:
            scan_interval = settings.get("popup_scan_interval", 2.0)
            self.popup_handler.start_listening(check_interval=scan_interval)

        self._status = "running"
        self.logger.info("[弹窗监听] 已启动，仅监听弹窗不执行导航")
        return {"status": "listening", "popup_events": []}

    def get_progress(self) -> Dict[str, Any]:
        """获取当前播放进度信息

        Returns:
            进度信息字典（含 currentTime, duration, percent 等）
        """
        if self.progress_saver and self.progress_saver._last_collected_data:
            return self.progress_saver._last_collected_data
        return {}

    # ================================================================
    #  OpenClaw 按钮控制接口 — 面向系统级调用的完整自动化 API
    # ================================================================

    # ── 命令映射表 ──
    _COMMAND_MAP: Dict[str, str] = {
        # 生命周期
        'init': '_cmd_init',
        'launch': '_cmd_launch',
        'start': '_cmd_start',
        'run': '_cmd_run',
        'pause': '_cmd_pause',
        'resume': '_cmd_resume',
        'stop': '_cmd_stop',
        'shutdown': '_cmd_shutdown',
        # 状态查询
        'get_status': '_cmd_get_status',
        'get_full_status': '_cmd_get_status',
        'get_progress': '_cmd_get_progress',
        'get_play_status': '_cmd_get_play_status',
        'get_browser_status': '_cmd_get_browser_status',
        # 播放列表
        'add_urls': '_cmd_add_urls',
        'set_urls': '_cmd_set_urls',
        'clear_urls': '_cmd_clear_urls',
        'reset_progress': '_cmd_reset_progress',
        # 音频录制
        'set_audio_recording': '_cmd_set_audio_recording',
        'get_audio_recording_status': '_cmd_get_audio_recording_status',
        # 登录状态
        'save_login': '_cmd_save_login',
        'check_login': '_cmd_check_login',
        'delete_login': '_cmd_delete_login',
    }

    def execute_command(self, command: str, **params) -> Dict[str, Any]:
        """统一命令执行接口 — OpenClaw 系统调用的唯一入口。

        支持的生命周期命令:
            init       → 初始化组件
            launch     → 启动浏览器 + 开始自动化（headless 模式等同 run）
            start      → 启动 GUI 模式
            run        → 执行自动化并等待完成（阻塞）
            pause      → 暂停
            resume     → 恢复
            stop       → 停止
            shutdown   → 关闭浏览器 + 清理

        状态查询命令:
            get_status / get_full_status → 完整系统状态快照
            get_progress                 → 播放进度
            get_play_status              → 播放列表详情
            get_browser_status           → 浏览器状态

        播放列表命令:
            add_urls(urls=[])    → 批量添加
            set_urls(urls=[])    → 替换全部
            clear_urls           → 清空
            reset_progress       → 重置

        音频录制命令:
            set_audio_recording(enable=True) → 设置播放列表录音开关
            get_audio_recording_status       → 获取录音状态

        登录命令:
            save_login   → 保存当前登录状态
            check_login  → 检查文件有效性
            delete_login → 删除已保存状态

        Args:
            command: 命令名称
            **params: 命令参数（如 urls, timeout, click_play 等）

        Returns:
            {'success': bool, 'command': str, 'data': dict, 'error': str|None}

        Example:
            learner.execute_command('launch')
            learner.execute_command('add_urls', urls=['https://...'])
            learner.execute_command('get_status')
        """
        handler_name = self._COMMAND_MAP.get(command)
        if handler_name is None:
            return {
                'success': False,
                'command': command,
                'data': {},
                'error': f'未知命令: {command}。支持: {list(self._COMMAND_MAP.keys())}'
            }

        handler = getattr(self, handler_name, None)
        if handler is None:
            return {
                'success': False,
                'command': command,
                'data': {},
                'error': f'命令处理器缺失: {handler_name}'
            }

        try:
            result = handler(**params)
            return {
                'success': True,
                'command': command,
                'data': result,
                'error': None
            }
        except Exception as e:
            self.logger.error(f"[命令] '{command}' 执行异常: {e}")
            return {
                'success': False,
                'command': command,
                'data': {},
                'error': str(e)
            }

    # ── 安全预检 ──

    def is_safe_to(self, action: str) -> Dict[str, Any]:
        """在执行操作前检查安全性前置条件。

        Args:
            action: 要检查的操作名（launch/stop/shutdown/save_login 等）

        Returns:
            {'safe': bool, 'warnings': list[str], 'checks': dict}
        """
        checks = {}
        warnings = []

        # 通用检查
        if action in ('launch', 'start', 'run'):
            checks['config_loaded'] = True
            try:
                nav = self.config_loader.get_navigation()
                if not nav:
                    warnings.append('导航步骤为空，需要先配置')
                    checks['has_navigation'] = False
                else:
                    checks['has_navigation'] = True
            except Exception as e:
                warnings.append(f'配置检查失败: {e}')
                checks['has_navigation'] = False

            if action in ('start',) and self.mode == 'headless':
                warnings.append('start 方法不支持 headless 模式，请使用 launch 或 run')

        if action in ('save_login',):
            if not self.browser or not self.browser.context:
                warnings.append('浏览器未启动，无法保存登录状态')
                checks['browser_ready'] = False
            else:
                checks['browser_ready'] = True

        if action in ('stop', 'shutdown'):
            checks['is_running'] = self._status == 'running'

        return {
            'safe': len([w for w in warnings if '无法' in w or '不支持' in w]) == 0,
            'warnings': warnings,
            'checks': checks,
        }

    # ── 事件系统 ──

    def __init_sub_events(self):
        """初始化事件回调注册器"""
        if not hasattr(self, '_event_handlers'):
            self._event_handlers: Dict[str, list] = {}

    def register_event_handler(self, event: str, handler) -> "WebVideoAutoLearner":
        """注册事件处理器 — 支持 OpenClaw 监听自动化事件。

        事件类型:
            status_changed(old, new)  → 状态变更
            progress_updated(data)    → 进度更新
            error_occurred(error)     → 错误发生
            completed(result)         → 自动化完成
            popup_detected(info)      → 弹窗检测
            popup_handled(info)       → 弹窗处理

        Args:
            event: 事件名称
            handler: callable，接收事件数据

        Returns:
            self
        """
        self.__init_sub_events()
        self._event_handlers.setdefault(event, []).append(handler)
        return self

    def _fire_event(self, event: str, data: Any = None):
        """触发事件，通知所有注册的处理器"""
        self.__init_sub_events()
        for handler in self._event_handlers.get(event, []):
            try:
                handler(data)
            except Exception as e:
                self.logger.warning(f"[事件] {event} 处理器异常: {e}")

    def on_status_changed(self, handler) -> "WebVideoAutoLearner":
        """便捷注册：状态变更事件"""
        return self.register_event_handler('status_changed', handler)

    def on_completed(self, handler) -> "WebVideoAutoLearner":
        """便捷注册：自动化完成事件"""
        return self.register_event_handler('completed', handler)

    def on_error(self, handler) -> "WebVideoAutoLearner":
        """便捷注册：错误事件"""
        return self.register_event_handler('error_occurred', handler)

    def on_progress(self, handler) -> "WebVideoAutoLearner":
        """便捷注册：进度更新事件"""
        return self.register_event_handler('progress_updated', handler)

    # ── 状态快照 ──

    def get_full_status(self) -> Dict[str, Any]:
        """获取完整系统状态快照 — OpenClaw 轮询用。

        Returns:
            {
                'status': str,              # initialized/running/paused/stopped/completed/error
                'mode': str,                # headless/all/simple/list
                'browser': {                # 浏览器子状态
                    'alive': bool,
                    'page_url': str|None,
                    'page_title': str|None
                },
                'play': {                   # 播放子状态
                    'total': int,
                    'completed': int,
                    'pending': int,
                    'items': [...]
                },
                'login': {                  # 登录子状态
                    'storage_enabled': bool,
                    'storage_exists': bool,
                    'cookies_count': int
                },
                'progress': {...},          # 当前媒体进度
                'popup_events_count': int,  # 弹窗事件数
                'uptime_seconds': float     # 运行时长
            }
        """
        status = {
            'status': self._status,
            'mode': self.mode,
            'browser': {'alive': False, 'page_url': None, 'page_title': None},
            'play': {'total': 0, 'completed': 0, 'pending': 0, 'items': []},
            'login': {'storage_enabled': False, 'storage_exists': False, 'cookies_count': 0},
            'progress': {},
            'popup_events_count': len(self._result.get('popup_events', [])),
            'uptime_seconds': 0,
        }

        # 浏览器状态
        try:
            if self.browser and self.browser.is_alive():
                status['browser']['alive'] = True
                if hasattr(self.browser, 'page') and self.browser.page:
                    try:
                        status['browser']['page_url'] = self.browser.page.url
                        status['browser']['page_title'] = self.browser.page.title()
                    except Exception:
                        pass
        except Exception:
            pass

        # 播放列表状态
        try:
            urls = self.get_play_urls()
            status['play']['total'] = len(urls)
            status['play']['completed'] = sum(1 for u in urls if u.get('completed'))
            status['play']['pending'] = status['play']['total'] - status['play']['completed']
            status['play']['items'] = [
                {
                    'url': u.get('url', '')[:120],
                    'completed': u.get('completed', False),
                    'click_play': u.get('click_play', True),
                }
                for u in urls
            ]
        except Exception:
            pass

        # 登录信息
        try:
            login_info = self.get_login_state_info()
            status['login'] = {
                'storage_enabled': login_info['storage_enabled'],
                'storage_exists': login_info['file_exists'],
                'cookies_count': login_info['cookies_count'],
            }
        except Exception:
            pass

        # 进度
        status['progress'] = self.get_progress()

        return status

    # ── 阻塞等待 ──

    def wait_for_completion(
        self, timeout: float = 0, poll_interval: float = 1.0
    ) -> Dict[str, Any]:
        """阻塞等待自动化完成（OpenClaw 同步调用模式）。

        Args:
            timeout: 超时秒数（0 = 无限等待）
            poll_interval: 轮询间隔（秒）

        Returns:
            {
                'completed': bool,          # 是否正常完成
                'timed_out': bool,          # 是否超时
                'final_status': str,        # 最终状态
                'result': dict,             # 执行结果
                'elapsed_seconds': float    # 耗时
            }
        """
        start = __import__('time').time()
        while True:
            elapsed = __import__('time').time() - start
            if timeout > 0 and elapsed > timeout:
                return {
                    'completed': False,
                    'timed_out': True,
                    'final_status': self._status,
                    'result': self._result,
                    'elapsed_seconds': elapsed,
                }

            if self._status in ('completed', 'stopped', 'error'):
                return {
                    'completed': self._status == 'completed',
                    'timed_out': False,
                    'final_status': self._status,
                    'result': self._result,
                    'elapsed_seconds': elapsed,
                }

            __import__('time').sleep(poll_interval)

    # ── 子状态查询 ──

    def get_play_status(self) -> Dict[str, Any]:
        """获取播放列表详情（含 URL 和完成状态）。"""
        urls = self.get_play_urls()
        completed = [u for u in urls if u.get('completed')]
        pending = [u for u in urls if not u.get('completed')]
        return {
            'total': len(urls),
            'completed': len(completed),
            'pending': len(pending),
            'completed_urls': [u['url'] for u in completed],
            'pending_urls': [u['url'] for u in pending],
        }

    def get_browser_status(self) -> Dict[str, Any]:
        """获取浏览器健康状态。"""
        try:
            alive = self.browser and self.browser.is_alive()
            return {
                'alive': alive,
                'page_count': len(self.browser.context.pages) if alive and self.browser.context else 0,
                'page_url': self.browser.page.url if alive and self.browser.page else None,
                'ever_started': self.browser._ever_started if self.browser else False,
            }
        except Exception as e:
            return {'alive': False, 'error': str(e)}

    # ── 命令处理器（由 execute_command 调度）──

    def _cmd_init(self, **params) -> Dict[str, Any]:
        self._init_components()
        return {'status': self._status, 'message': '核心组件已初始化'}

    def _cmd_launch(self, **params) -> Dict[str, Any]:
        """启动自动化（headless=run，GUI=start）"""
        if self.mode == 'headless':
            return self._cmd_run(**params)
        else:
            return self._cmd_start(**params)

    def _cmd_start(self, **params) -> Dict[str, Any]:
        self.start()
        return {'status': self._status}

    def _cmd_run(self, **params) -> Dict[str, Any]:
        return self.run()

    def _cmd_pause(self, **params) -> Dict[str, Any]:
        self.pause()
        return {'status': self._status}

    def _cmd_resume(self, **params) -> Dict[str, Any]:
        self.resume()
        return {'status': self._status}

    def _cmd_stop(self, **params) -> Dict[str, Any]:
        self.stop()
        return {'status': self._status}

    def _cmd_shutdown(self, **params) -> Dict[str, Any]:
        try:
            self.stop()
        except Exception:
            pass
        try:
            if self.browser:
                self.browser.close(force=True)
        except Exception:
            pass
        self._status = 'stopped'
        return {'status': 'stopped', 'message': '已关闭浏览器并清理资源'}

    def _cmd_get_status(self, **params) -> Dict[str, Any]:
        return self.get_full_status()

    def _cmd_get_progress(self, **params) -> Dict[str, Any]:
        return self.get_progress()

    def _cmd_get_play_status(self, **params) -> Dict[str, Any]:
        return self.get_play_status()

    def _cmd_get_browser_status(self, **params) -> Dict[str, Any]:
        return self.get_browser_status()

    def _cmd_add_urls(self, **params) -> Dict[str, Any]:
        urls = params.get('urls', [])
        click_play = params.get('click_play', True)
        if urls:
            self.add_play_urls(urls, click_play=click_play)
        return self.get_play_status()

    def _cmd_set_urls(self, **params) -> Dict[str, Any]:
        urls = params.get('urls', [])
        click_play = params.get('click_play', True)
        self.set_play_urls(urls, click_play=click_play)
        return self.get_play_status()

    def _cmd_clear_urls(self, **params) -> Dict[str, Any]:
        self.clear_play_urls()
        return self.get_play_status()

    def _cmd_reset_progress(self, **params) -> Dict[str, Any]:
        self.reset_play_progress()
        return self.get_play_status()

    def _cmd_set_audio_recording(self, **params) -> Dict[str, Any]:
        """设置播放列表音频录制开关"""
        enable = params.get('enable', True)
        self.set_audio_recording_for_playlist(enable=enable)
        return self.get_audio_recording_status()

    def _cmd_get_audio_recording_status(self, **params) -> Dict[str, Any]:
        """获取音频录制状态"""
        return self.get_audio_recording_status()

    def _cmd_save_login(self, **params) -> Dict[str, Any]:
        return self.save_login_state()

    def _cmd_check_login(self, **params) -> Dict[str, Any]:
        return self.check_login_state()

    def _cmd_delete_login(self, **params) -> Dict[str, Any]:
        return self.delete_login_state()

    # ================================================================
    #  内部方法
    # ================================================================

    def _init_components(self) -> None:
        """初始化所有核心组件"""
        try:
            self.config_loader.load()
        except Exception as e:
            self.logger.error(f"配置文件加载失败: {e}")
            raise

        settings = self.config_loader.get_settings()
        navigation = self.config_loader.get_navigation()
        popup_rules = self.config_loader.get_popup_rules()
        auto_answer_enabled = self.config_loader.is_auto_answer_enabled()

        # 初始化浏览器管理器
        self.browser = BrowserManager(self.logger)

        # 初始化媒体进度守护器
        self.progress_saver = MediaProgressSaver(self.browser, self.logger)
        self.browser.progress_saver = self.progress_saver

        # 初始化弹窗处理器
        self.popup_handler = PopupHandler(None, popup_rules, self.logger, self.browser, auto_answer_enabled)

        # 初始化任务运行器
        self.task_runner = TaskRunner(
            self.browser, self.popup_handler, navigation, self.logger, settings,
            config_loader=self.config_loader
        )

        self.logger.info("核心组件初始化完成")

    def _register_popup_callbacks(self) -> None:
        """注册弹窗事件回调"""
        def on_detected(event_type, info):
            self.logger.info(f"[弹窗] 检测到: type={info.get('popup_type')}")
            self._result.setdefault("popup_events", []).append({
                "event": "detected", **info
            })

        def on_handled(event_type, info):
            self.logger.info(f"[弹窗] 已处理: type={info.get('popup_type')}")
            self._result.setdefault("popup_events", []).append({
                "event": "handled", **info
            })

        def on_error(event_type, info):
            self.logger.warning(f"[弹窗] 处理异常: {info.get('details', '')[:80]}")

        def on_cleared(event_type, info):
            self.logger.debug(f"[弹窗] 已消失: type={info.get('popup_type')}")

        self.popup_handler.on_popup_event("detected", on_detected)
        self.popup_handler.on_popup_event("handled", on_handled)
        self.popup_handler.on_popup_event("error", on_error)
        self.popup_handler.on_popup_event("cleared", on_cleared)

    def _on_start(self) -> None:
        """GUI 模式：开始自动化回调"""
        if self.browser._ever_started and not self.browser.is_alive():
            self.browser._closed = True

        settings = self.config_loader.get_settings()
        bt = settings.get("browser_type", "chrome")
        wm = settings.get("window_max", True)
        bp = settings.get("browser_path", "") or None
        lu = self.config_loader.get_website().get("login_url", "")

        # Storage State
        w = self.config_loader.get_website()
        ss = w.get("storage_state", False)
        sf = None
        if ss:
            sfn = w.get("storage_state_file", "storage_state.enc")
            if not sfn.endswith(".enc"):
                sfn = sfn.rsplit(".", 1)[0] + ".enc"
            sf = os.path.join(os.path.dirname(self.config_loader.config_path), sfn)
            sf = os.path.abspath(sf)
            if not os.path.isfile(sf):
                sf = None

        if not self.browser.ensure_open(bt, wm, browser_path=bp, login_url=lu, storage_state_file=sf):
            self.logger.error("浏览器启动失败")
            self._control_panel._set_state("stopped")
            return

        self.popup_handler.page = self.browser.page
        self.popup_handler.register_dialog_handler()
        self.popup_handler.set_pw_caller(self._control_panel.call_on_main_thread)

        self.progress_saver.set_pw_caller(self._control_panel.call_on_main_thread)
        self.task_runner.progress_saver = self.progress_saver

        # 仅在有 mylayer 弹窗规则时注入处理脚本
        has_layer_rule = any(r.get('type') == 'layer' for r in self.popup_handler.popup_rules)
        if has_layer_rule:
            self.browser.inject_mylayer_handler()
        self._control_panel.start_browser_close_monitor()

        # 仅在有弹窗规则时启动监听
        if self.popup_handler.popup_rules:
            scan_interval = settings.get("popup_scan_interval", 2.0)
            self.popup_handler.start_listening(check_interval=scan_interval)

        def _run_bg():
            try:
                self.task_runner.run_navigation()
            except Exception as e:
                self.logger.error(f"[自动化] 执行异常: {e}")
            finally:
                # 流程完成后自动停止（无论成功/失败/异常）
                try:
                    self.task_runner.stop()
                except Exception as e:
                    self.logger.error(f"[自动化] 停止任务异常: {e}")
                try:
                    self.popup_handler.stop_listening()
                except Exception as e:
                    self.logger.error(f"[自动化] 停止弹窗监听异常: {e}")
                try:
                    if self.progress_saver:
                        self.progress_saver.stop()
                except Exception as e:
                    self.logger.error(f"[自动化] 停止进度守护异常: {e}")
                try:
                    self._control_panel.stop_browser_close_monitor()
                except Exception:
                    pass
                self.logger.info("全部步骤已完成，任务已停止")

                # 在主线程中关闭浏览器（Playwright 的 close/stop 必须在创建它的 greenlet 上执行，
                # 否则会因 greenlet 线程切换问题卡住）
                def _close_browser_on_main():
                    try:
                        self.browser.close(force=True)
                        self.logger.info("浏览器已关闭")
                    except Exception as e:
                        self.logger.error(f"[自动化] 关闭浏览器异常: {e}")
                    self._control_panel._set_state("stopped")

                self._control_panel.root.after(0, _close_browser_on_main)

        threading.Thread(target=_run_bg, daemon=True).start()
        self._status = "running"

    def _on_pause(self) -> None:
        if self.task_runner:
            self.task_runner.pause()
        self._status = "paused"

    def _on_resume(self) -> None:
        if self.task_runner:
            self.task_runner.resume()
        self._status = "running"

    def _on_stop(self) -> None:
        if self.task_runner:
            self.task_runner.stop()
        if self.popup_handler:
            self.popup_handler.stop_listening()
        if self.progress_saver:
            self.progress_saver.save_now()
            self.progress_saver.stop()
        self.browser._auto_close = False
        if self._control_panel:
            self._control_panel.stop_browser_close_monitor()
        if self.browser._ever_started and not self.browser.is_alive():
            self.browser._closed = True
        self._status = "stopped"


# ================================================================
#  便捷函数
# ================================================================

def quick_start(mode: str = "simple", login_url: str = "https://www.example.com/") -> WebVideoAutoLearner:
    """快速启动（便捷函数）

    Args:
        mode: 运行模式 (all/simple/list/headless)
        login_url: 登录页面URL

    Returns:
        WebVideoAutoLearner 实例
    """
    learner = WebVideoAutoLearner(mode=mode)
    learner.configure(login_url=login_url)
    if mode == "headless":
        learner.run()
    else:
        learner.start()
    return learner


# ================================================================
#  CLI 入口
# ================================================================

def main():
    """命令行入口"""
    import argparse

    parser = argparse.ArgumentParser(description="网络视频辅助学习技能")
    parser.add_argument(
        "mode", nargs="?", default="simple",
        choices=["all", "simple", "list", "headless"],
        help="运行模式: all=完整控制台, simple=简约模式, list=播放列表, headless=无GUI"
    )
    parser.add_argument("--config", default=None, help="自定义配置文件路径")
    parser.add_argument("--log-level", default="INFO", help="日志级别")
    args = parser.parse_args()

    learner = WebVideoAutoLearner(mode=args.mode, config_path=args.config, log_level=args.log_level)

    if args.mode == "headless":
        result = learner.run()
        print(f"执行状态: {result['status']}")
        if result.get("error"):
            print(f"错误: {result['error']}")
    else:
        learner.start()


if __name__ == "__main__":
    main()
