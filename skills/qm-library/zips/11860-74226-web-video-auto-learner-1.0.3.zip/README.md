# 网络视频辅助学习技能 (web-video-auto-learner)

> OpenClaw 标准技能包 — 网络视频课程的辅助学习工具：自动播放、弹窗处理、答题、录音、AI 转录与智能总结

![技能图标](assets/icon.png)

## 功能概览

- **自动登录** — Storage State 免登录，加密存储仅本机可解密
- **视频自动播放** — 播放列表驱动，支持主流播放器懒加载
- **弹窗自动处理** — 智能检测答题弹窗，自动关闭或 AI 辅助答题
- **进度守护** — 定时保存播放进度，崩溃后自动恢复
- **音频录制** — Web Audio API 页面内录，零额外依赖
- **语音转写** — 讯飞 LFASR（云端高精度）+ Whisper（本地离线）
- **AI 智能总结** — 多提供商 + 推理增强模型，生成课程纪要
- **三种模式** — 完整控制台 / 简约模式 / 播放列表模式

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
playwright install chromium
```

> 使用本地 Chrome/Edge 可跳过 Playwright 安装，在配置中指定 `browser_type`。

### 2. 配置

```bash
# 复制配置模板并修改
cp config/config.yaml.example config/config.yaml
cp config/AImodel.yaml.example config/AImodel.yaml
```

编辑 `config/config.yaml`：
- 设置 `website.login_url` 为目标网站登录页
- 在 `navigation.play_list` 中添加视频 URL

编辑 `config/AImodel.yaml`：
- 填写 AI 提供商的 API 密钥（至少启用一个）

### 3. 运行

```bash
# 简约模式（推荐新手）
python index.py simple

# 完整控制台模式
python index.py all

# 播放列表模式
python index.py list

# 无头模式（编程调用）
python index.py headless
```

## 编程式调用

```python
from index import WebVideoAutoLearner

# 初始化
learner = WebVideoAutoLearner(mode="headless")

# 配置
learner.configure(
    browser_type="chrome",
    login_url="https://www.example.com/",
    navigation_steps=[
        {
            "name": "播放视频",
            "action": "play_list",
            "loop_infinite": True,
            "play_list": [
                {"url": "https://www.example.com/videoDisplay?coursewareId=xxx", "click_play": True}
            ]
        }
    ]
)

# 执行
result = learner.run()
print(f"状态: {result['status']}")
```

### 快捷启动

```python
from index import quick_start

learner = quick_start(mode="simple", login_url="https://www.example.com/")
```

### 完整学习闭环（播放 + 录音 + 转写 + 总结）

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner(mode="headless")

# 启用功能
learner.set_audio_recording_for_playlist(enable=True)
learner.enable_ai_summary(provider="siliconflow")

# 添加课程
learner.add_play_urls(["https://www.example.com/video?id=xxx"])

# 执行
result = learner.run()
```

## 配置说明

### config/config.yaml

| 配置项 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| `settings.browser_type` | string | chrome | 浏览器类型 (chrome/msedge/360ee/360se) |
| `settings.window_max` | bool | true | 是否最大化窗口 |
| `settings.global_timeout` | int | 60000 | 全局超时（毫秒） |
| `settings.popup_scan_interval` | float | 0.5 | 弹窗扫描间隔（秒） |
| `settings.auto_answer` | bool | false | 自动答题开关 |
| `website.login_url` | string | - | 登录页面URL |
| `website.storage_state` | bool | true | 是否启用免登录 |
| `navigation` | list | [] | 导航步骤列表 |
| `popup_rules` | list | [] | 弹窗处理规则 |

### config/AImodel.yaml

| 配置项 | 说明 |
|--------|------|
| `global.default_provider` | 默认 AI 提供商 (siliconflow/openai/ollama/deepseek) |
| `models.<provider>.api_key` | API 密钥 |
| `models.<provider>.chat_model` | 聊天模型 |
| `models.<provider>.reasoning_model` | 推理增强模型（思维链） |
| `models.xunfei_lfasr` | 讯飞录音转写凭证 |

## AI 提供商

| 提供商 | 聊天模型 | 推理模型 | 说明 |
|--------|----------|----------|------|
| **SiliconFlow** | Qwen2.5-72B-Instruct | DeepSeek-R1 | 推荐国内使用，需 API Key |
| **DeepSeek** | deepseek-chat | deepseek-v4-pro | 国产模型，支持思维链 |
| **OpenAI** | gpt-4o-mini | - | 国际用户，需 API Key |
| **Ollama** | qwen2.5:7b | - | 本地运行，无需 API Key |

## 语音转写引擎

| 引擎 | 类型 | 精度 | 说明 |
|------|------|------|------|
| **讯飞 LFASR** | 云端 | 高 | 支持中英+方言，角色分离，需 API 凭证 |
| **Whisper** | 本地 | 中 | 离线运行，需 PyTorch + transformers |

## API 文档

查看 [docs/API.md](docs/API.md) 了解完整的公共 API 参考。

## 测试

运行所有测试用例：

```bash
# 运行所有测试
python -m pytest tests/

# 或者运行测试脚本
python tests/run_tests.py

# 运行特定测试文件
python -m unittest tests.test_browser
python -m unittest tests.test_config_loader
python -m unittest tests.test_task_runner
```

## 浏览器扩展

`assets/media-progress-saver/` 是 Chrome 扩展：

- 每10秒自动保存媒体播放进度
- 页面加载时自动恢复进度
- 支持崩溃恢复（localStorage + chrome.storage 双重写入）

### 安装扩展

1. 打开 Chrome → `chrome://extensions/`
2. 开启「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择 `assets/media-progress-saver/` 目录

## 项目结构

```
skill/
├── SKILL.md                       # 技能文档（必需）
├── manifest.yaml                   # OpenClaw 技能清单
├── README.md                      # 项目说明（本文件）
├── CLAUDE.md                      # AI 编码助手指南
├── CHANGELOG.md                   # 变更日志
├── LICENSE                        # 开源协议
├── index.py                       # 技能入口（API 封装）
├── requirements.txt               # Python 依赖
├── start_playlist.py              # 快捷启动脚本（simple模式）
├── run_playlist.py                # 快捷启动脚本（headless模式）
├── src/                           # 核心模块
│   ├── __init__.py
│   ├── browser.py                 # 浏览器管理（Playwright 封装）
│   ├── config_loader.py           # 配置文件加载器
│   ├── control_panel.py           # GUI 控制面板（Tkinter）
│   ├── encryption.py              # 登录信息加密/解密
│   ├── logger.py                  # 日志工具
│   ├── media_progress_saver.py    # 媒体进度守护
│   ├── popup_handler.py           # 弹窗检测与处理
│   ├── task_runner.py             # 任务执行器（含录音控制）
│   ├── ai_model.py                # AI 模型配置和调用（多提供商 + 推理增强）
│   ├── ai_summarizer.py           # AI 总结生成器
│   ├── audio_transcriber.py       # 音频转文字（Whisper 本地）
│   ├── xunfei_transcriber.py     # 讯飞 LFASR 转写（云端）
│   ├── video_processor.py         # 视频处理集成（录制→转写→总结）
│   ├── video_recorder.py          # 视频录制（ffmpeg）
│   ├── web_audio_recorder.py      # 网页音频录制（Web Audio API）
│   └── audio_inject.js            # 音频录制注入脚本
├── config/                        # 配置文件
│   ├── config.yaml.example        # 主配置示例
│   └── AImodel.yaml.example      # AI 模型配置示例
├── assets/                        # 资源文件
│   ├── media-progress-saver/      # Chrome 扩展（媒体进度守护）
│   ├── icon.png                  # 技能图标
│   └── screenshot.png            # 截图展示
├── examples/                      # 使用示例
│   ├── ai_model_example.py
│   ├── audio_recording_example.py
│   └── video_processing_example.py
├── docs/                          # 文档
│   └── API.md                     # 公共 API 参考文档
└── tests/                         # 测试文件
    ├── __init__.py
    ├── test_browser.py
    ├── test_config_loader.py
    ├── test_task_runner.py
    ├── test_encryption.py
    ├── test_ai_model.py
    ├── test_popup_handler.py
    ├── test_media_progress_saver.py
    ├── test_web_audio_recorder.py
    ├── test_integration.py
    └── run_tests.py
```

## 依赖

### 必需

- Python >= 3.9
- playwright >= 1.40.0
- pyyaml >= 6.0
- cryptography >= 41.0
- openai >= 1.0.0

### 可选（按功能）

- **音频录制**: 无额外依赖（使用 Web Audio API）
- **本地转写 (Whisper)**: torch, transformers, ffmpeg
- **云端转写 (讯飞)**: requests
- **视频录制**: ffmpeg（需添加到 PATH）

## 注意事项

1. **首次使用**需先安装 Playwright：`playwright install chromium`
2. **配置初始化**：复制 `.example` 文件为实际配置并填写
3. **Storage State 加密**基于设备特征，仅限本机解密
4. **音频录制**时视频必须正在播放
5. **AI 功能**需配置有效的 API 密钥
6. Windows 平台可自动检测浏览器路径；其他平台需在配置中指定 `browser_path`
7. **讯飞转写**需在 `config/AImodel.yaml` 的 `xunfei_lfasr` 中配置 API 凭证
8. 播放完成后录音文件路径会自动回写到配置文件（`audio_file` / `audio_name` 字段）

## 常见问题 (FAQ)

### 首次使用需要安装什么？

需要安装 Python 依赖（`pip install -r requirements.txt`）和 Playwright 浏览器（`playwright install chromium`）。如果使用本地 Chrome/Edge，可以跳过 Playwright 安装。

### 如何配置目标网站？

复制 `config/config.yaml.example` 为 `config/config.yaml`，然后编辑 `website.login_url` 设置登录页面 URL，在 `navigation.play_list` 中添加视频 URL。

### 如何启用 AI 功能？

复制 `config/AImodel.yaml.example` 为 `config/AImodel.yaml`，然后填写 AI 提供商的 API 密钥。支持 SiliconFlow、DeepSeek、OpenAI、Ollama 等提供商。

### 音频录制功能需要什么依赖？

音频录制使用 Web Audio API，无需额外依赖。但音频转写需要：本地 Whisper（需 PyTorch + transformers）或云端讯飞 LFASR（需 requests）。

### 登录状态如何保存和恢复？

使用 `encrypt_storage_state` 功能，基于设备特征派生密钥（PBKDF2HMAC-SHA256），仅在当前设备可解密。保存后在配置中启用 `storage_state` 即可自动加载。

### 播放进度如何守护？

内置媒体进度守护器，每60秒自动保存播放进度到 localStorage。浏览器崩溃后重新打开页面会自动恢复进度。同时提供 Chrome 扩展增强功能。

## 变更日志

查看 [CHANGELOG.md](CHANGELOG.md) 了解版本变更历史。

## 许可证

MIT License - 查看 [LICENSE](LICENSE) 文件了解详情。

## 支持与反馈

- 问题反馈：[GitHub Issues](https://github.com/lobster-dev/web-video-auto-learner/issues)
- 讨论区：[GitHub Discussions](https://github.com/lobster-dev/web-video-auto-learner/discussions)
- 邮箱：lobster.dev@outlook.com

## 致谢

- Playwright - 浏览器自动化框架
- Tkinter - Python GUI 框架
- OpenAI - AI 模型 API
- 讯飞 - 语音转写 API
- Whisper - 本地语音识别模型
