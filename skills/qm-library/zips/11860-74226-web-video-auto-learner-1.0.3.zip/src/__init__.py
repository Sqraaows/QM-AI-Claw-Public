"""
网络视频辅助学习技能 - 核心模块包

模块列表:
    - ai_model: AI 模型配置和调用
    - ai_summarizer: AI 总结生成器
    - audio_inject.js: 音频录制注入脚本（JavaScript）
    - audio_transcriber: 音频转文字（Whisper）
    - browser: 浏览器管理（Playwright 封装）
    - config_loader: 配置文件加载器
    - control_panel: GUI 控制面板（Tkinter）
    - encryption: 登录信息加密/解密
    - logger: 日志工具
    - media_progress_saver: 媒体进度守护
    - popup_handler: 弹窗检测与处理
    - task_runner: 任务执行器
    - video_processor: 视频处理集成
    - video_recorder: 视频录制（ffmpeg）
    - web_audio_recorder: 网页音频录制（Web Audio API）
    - xunfei_transcriber: 讯飞 LFASR 转写
"""

from .browser import BrowserManager
from .config_loader import ConfigLoader
from .encryption import (
    encrypt_storage_state,
    decrypt_storage_state,
    save_encrypted_storage_state,
    load_encrypted_storage_state,
)
from .logger import setup_logger
from .media_progress_saver import MediaProgressSaver
from .popup_handler import PopupHandler
from .task_runner import TaskRunner
from .web_audio_recorder import WebAudioRecorder, PageAudioCapture
from .xunfei_transcriber import XunfeiLfasrTranscriber

# 可选模块（依赖可能未安装）
try:
    from .ai_model import AIModelCaller, AIModelConfig
except ImportError:
    AIModelCaller = None
    AIModelConfig = None

try:
    from .ai_credentials import AICredentialManager
except ImportError:
    AICredentialManager = None

try:
    from .ai_summarizer import AISummarizer
except ImportError:
    AISummarizer = None

try:
    from .video_processor import VideoProcessor
except ImportError:
    VideoProcessor = None

try:
    from .audio_transcriber import AudioTranscriber
except ImportError:
    AudioTranscriber = None

try:
    from .video_recorder import VideoRecorder
except ImportError:
    VideoRecorder = None

__all__ = [
    "BrowserManager",
    "ConfigLoader",
    "encrypt_storage_state",
    "decrypt_storage_state",
    "save_encrypted_storage_state",
    "load_encrypted_storage_state",
    "setup_logger",
    "MediaProgressSaver",
    "PopupHandler",
    "TaskRunner",
    "WebAudioRecorder",
    "PageAudioCapture",
    "XunfeiLfasrTranscriber",
    "AIModelCaller",
    "AIModelConfig",
    "AICredentialManager",
    "AISummarizer",
    "VideoProcessor",
    "AudioTranscriber",
    "VideoRecorder",
]
