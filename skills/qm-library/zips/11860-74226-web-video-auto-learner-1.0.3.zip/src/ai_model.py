# -*- coding: utf-8 -*-
"""
AI 模型配置和调用模块
所有配置通过 AImodel.yaml 管理，禁止硬编码
API Key 等敏感凭证加密存储于 config/ai_credentials.enc
"""
import os
import logging
from pathlib import Path
from typing import Dict, Any, List
import yaml

from .ai_credentials import AICredentialManager


class AIModelConfig:
    """AI 模型配置管理类"""

    # 默认配置文件内容
    DEFAULT_CONFIG = {
        # 全局设置
        'global': {
            'default_provider': 'siliconflow',
            'timeout': 120,
            'max_retries': 3,
            'retry_delay': 2
        },

        # 系统提示词配置
        'system_prompts': {
            'default': {
                'name': '默认提示词',
                'content': '你是一个专业的学习助手。请对提供的学习内容进行总结，生成结构化的会议纪要格式。',
                'variables': []
            },
            'meeting_notes': {
                'name': '会议纪要生成器',
                'content': '''你是一个专业的会议纪要生成助手。请根据提供的学习视频转录文本，生成一份结构化的会议纪要。

要求：
1. 提取关键主题和要点
2. 为每个要点标注开始和结束时间戳
3. 使用简洁明了的语言
4. 按逻辑顺序组织内容

输出格式：
## 基本信息
## 快速导航
## 详细内容（每个要点包含时间戳）

时间戳格式：HH:MM:SS''',
                'variables': ['video_title', 'duration']
            },
            'summary': {
                'name': '内容摘要生成器',
                'content': '''你是一个专业的内容摘要助手。请对以下文本进行摘要：

要求：
1. 提取核心观点
2. 保留关键细节
3. 语言简洁精炼
4. 控制在200字以内

请直接输出摘要内容，不要添加额外说明。''',
                'variables': []
            },
            'key_points': {
                'name': '关键要点提取器',
                'content': '''你是一个专业的知识提炼助手。请从以下文本中提取关键要点：

要求：
1. 提取5-10个最重要的要点
2. 每个要点用一句话概括
3. 标注每个要点的时间戳位置
4. 按重要性排序

输出格式：
[时间戳] 要点内容''',
                'variables': ['video_title']
            }
        },

        # 模型配置
        'models': {
            'siliconflow': {
                'enabled': False,
                'name': 'SiliconFlow API',
                'api_base': 'https://api.siliconflow.cn/v1',
                'api_key': '',  # 需要用户填写
                'chat_model': 'Qwen/Qwen2.5-72B-Instruct',
                'reasoning_model': 'Pro/deepseek-ai/DeepSeek-R1',
                'embedding_model': 'BAAI/bge-large-zh-v1.5',
                'default_params': {
                    'temperature': 0.3,
                    'max_tokens': 4000,
                    'top_p': 0.9,
                    'frequency_penalty': 0.0,
                    'presence_penalty': 0.0
                },
                'reasoning_params': {}
            },
            'openai': {
                'enabled': False,
                'name': 'OpenAI API',
                'api_base': 'https://api.openai.com/v1',
                'api_key': '',  # 需要用户填写
                'chat_model': 'gpt-4o-mini',
                'embedding_model': 'text-embedding-3-small',
                'default_params': {
                    'temperature': 0.3,
                    'max_tokens': 4000,
                    'top_p': 0.9
                }
            },
            'ollama': {
                'enabled': False,
                'name': 'Ollama 本地模型',
                'api_base': 'http://localhost:11434/v1',
                'api_key': 'ollama',  # Ollama 不需要真实密钥
                'chat_model': 'qwen2.5:7b',
                'embedding_model': '',
                'default_params': {
                    'temperature': 0.3,
                    'num_ctx': 8192
                }
            },
            'deepseek': {
                'enabled': True,
                'name': 'DeepSeek API',
                'api_base': 'https://api.deepseek.com',
                'api_key': '',  # 需要用户填写
                'chat_model': 'deepseek-chat',
                'reasoning_model': 'deepseek-v4-pro',
                'embedding_model': '',
                'default_params': {
                    'temperature': 0.3,
                    'max_tokens': 4000
                },
                'reasoning_params': {
                    'reasoning_effort': 'high',
                    'thinking': {
                        'type': 'enabled'
                    }
                }
            },
            'xunfei_lfasr': {
                'enabled': False,
                'name': '科大讯飞录音文件转写大模型',
                'app_id': '',
                'secret_key': '',
                'api_key': '',
                'api_base': 'https://office-api-ist-dx.iflyaisol.com',
                'params': {
                    'language': 'autodialect',
                    'role_type': 1,
                    'max_poll_secs': 3600,
                    'poll_interval': 5
                },
            }
        },

        # 调用日志设置
        'logging': {
            'enabled': True,
            'log_requests': True,
            'log_responses': False,
            'save_history': True,
            'history_dir': 'ai_history'
        }
    }

    def __init__(self, config_path: str = None):
        """
        初始化 AI 模型配置

        Args:
            config_path: 配置文件路径，默认为 config/AImodel.yaml
        """
        self.logger = logging.getLogger(__name__)
        self.config_path = config_path or self._get_default_path()
        self.config: Dict[str, Any] = {}
        # 初始化凭证管理器（加密文件与 config 同目录）
        cred_dir = str(Path(self.config_path).parent)
        self._credentials = AICredentialManager(
            credentials_path=str(Path(cred_dir) / "ai_credentials.enc")
        )
        self._load_or_create()

    def _get_default_path(self) -> str:
        """获取默认配置文件路径"""
        # 获取项目根目录
        current_dir = Path(__file__).parent.parent
        config_dir = current_dir / 'config'
        config_dir.mkdir(exist_ok=True)
        return str(config_dir / 'AImodel.yaml')

    def _load_or_create(self):
        """加载配置或创建默认配置"""
        if os.path.exists(self.config_path):
            self._load_config()
        else:
            self._create_default_config()

    def _load_config(self):
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config = yaml.safe_load(f) or {}

            # 验证必需的配置项
            if not self._validate_config():
                self.logger.warning(
                    f"[AI配置] 配置文件验证失败，将使用默认配置补充"
                )
                self._merge_with_defaults()
                self.save()

            # 注入加密凭证（优先于 YAML 中的明文占位符）
            self._credentials.inject_into_config(self.config.get('models', {}))

            # 自动迁移：将 YAML 中残留的明文 Key 提取到加密存储
            self.migrate_credentials()

            self.logger.info(f"[AI配置] 已加载: {self.config_path}")

        except yaml.YAMLError as e:
            self.logger.error(f"[AI配置] YAML 解析失败: {e}")
            self._create_default_config()
        except Exception as e:
            self.logger.error(f"[AI配置] 加载失败: {e}")
            self._create_default_config()

    def _validate_config(self) -> bool:
        """验证配置完整性"""
        required_sections = ['global', 'system_prompts', 'models']
        for section in required_sections:
            if section not in self.config:
                return False
        return True

    def _merge_with_defaults(self):
        """合并默认配置"""
        def deep_merge(base: Dict, override: Dict) -> Dict:
            result = base.copy()
            for key, value in override.items():
                if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] = deep_merge(result[key], value)
                else:
                    result[key] = value
            return result

        self.config = deep_merge(self.DEFAULT_CONFIG, self.config)

    def _create_default_config(self):
        """创建默认配置文件"""
        try:
            # 确保目录存在
            Path(self.config_path).parent.mkdir(parents=True, exist_ok=True)

            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(
                    self.DEFAULT_CONFIG,
                    f,
                    allow_unicode=True,
                    sort_keys=False,
                    indent=2,
                    default_flow_style=False
                )

            self.config = self.DEFAULT_CONFIG.copy()
            self.logger.info(f"[AI配置] 已创建默认配置: {self.config_path}")
            self.logger.warning("[AI配置] 请编辑配置文件填写 API 密钥")

        except Exception as e:
            self.logger.error(f"[AI配置] 创建默认配置失败: {e}")
            self.config = self.DEFAULT_CONFIG.copy()

    def save(self):
        """保存配置到文件（敏感凭据已加密存储在独立文件中）。

        保存前自动从 models 配置中剥离 api_key 等敏感字段，
        确保明文 YAML 文件不包含真实凭据。
        """
        try:
            # 创建副本，剥离敏感字段
            config_to_save = self._deep_copy_config()

            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(
                    config_to_save,
                    f,
                    allow_unicode=True,
                    sort_keys=False,
                    indent=2,
                    default_flow_style=False
                )
            self.logger.info(f"[AI配置] 已保存: {self.config_path}")
            return True
        except Exception as e:
            self.logger.error(f"[AI配置] 保存失败: {e}")
            return False

    def _deep_copy_config(self) -> Dict:
        """深拷贝配置并清除 models 中的敏感字段。"""
        import copy
        config_copy = copy.deepcopy(self.config)
        models = config_copy.get('models', {})
        for provider, prov_cfg in models.items():
            for sensitive in ('api_key', 'app_id', 'secret_key'):
                if sensitive in prov_cfg:
                    existing_val = prov_cfg.get('api_key') if sensitive == 'api_key' else prov_cfg.get(sensitive)
                    # 保留占位符但清空真实值
                    if isinstance(prov_cfg, dict) and sensitive in prov_cfg:
                        if sensitive == 'api_key' and prov_cfg.get('api_key') == 'ollama':
                            # Ollama 的 api_key 是固定值，保留
                            pass
                        else:
                            prov_cfg[sensitive] = ''
        return config_copy

    # ==================== 配置访问方法 ====================

    def get_global(self, key: str, default: Any | None = None) -> Any:
        """获取全局配置"""
        return self.config.get('global', {}).get(key, default)

    def get_provider_config(self, provider: str = None) -> Dict[str, Any]:
        """获取指定提供商的配置"""
        if not provider:
            provider = self.get_global('default_provider', 'siliconflow')
        return self.config.get('models', {}).get(provider, {})

    def get_enabled_providers(self) -> List[str]:
        """获取所有已启用的提供商"""
        providers = []
        for name, config in self.config.get('models', {}).items():
            if config.get('enabled', False):
                providers.append(name)
        return providers

    def get_system_prompt(self, prompt_name: str = 'default') -> str:
        """获取系统提示词"""
        prompts = self.config.get('system_prompts', {})
        prompt_config = prompts.get(prompt_name, prompts.get('default', {}))
        return prompt_config.get('content', '')

    def get_all_prompts(self) -> Dict:
        """获取所有系统提示词配置"""
        return self.config.get('system_prompts', {})

    def add_system_prompt(self, name: str, content: str, description: str | None = None,
                          variables: List | None = None):
        """添加自定义系统提示词"""
        if 'system_prompts' not in self.config:
            self.config['system_prompts'] = {}

        self.config['system_prompts'][name] = {
            'name': description or name,
            'content': content,
            'variables': variables or []
        }
        return self.save()

    def update_model_params(self, provider: str, params: Dict[str, Any]):
        """更新模型参数"""
        if 'models' not in self.config:
            self.config['models'] = {}

        if provider not in self.config['models']:
            self.config['models'][provider] = {}

        if 'default_params' not in self.config['models'][provider]:
            self.config['models'][provider]['default_params'] = {}

        self.config['models'][provider]['default_params'].update(params)
        return self.save()

    def set_api_key(self, provider: str, api_key: str):
        """设置 API 密钥（加密存储）。

        密钥将保存到加密凭据文件，不会写入明文 YAML。

        Args:
            provider: 提供商名称
            api_key: API 密钥
        """
        if 'models' not in self.config:
            self.config['models'] = {}

        if provider not in self.config['models']:
            self.config['models'][provider] = {'enabled': False}

        # 更新内存中的值（用于当前会话）
        self.config['models'][provider]['api_key'] = api_key

        # 加密持久化
        return self._credentials.set_credential(provider, 'api_key', api_key)

    def migrate_credentials(self):
        """将 YAML 中残留的明文凭证迁移到加密存储。

        一端次迁移后，YAML 中的 api_key 等字段将被清空，
        后续凭据管理由加密文件负责。
        """
        models = self.config.get('models', {})
        if self._credentials.extract_from_config(models):
            # 迁移后立即保存 YAML（凭据已清空）
            # 使用原始的 save 逻辑避免递归
            import copy
            config_to_save = copy.deepcopy(self.config)
            for provider, prov_cfg in config_to_save.get('models', {}).items():
                for sensitive in ('api_key', 'app_id', 'secret_key'):
                    if isinstance(prov_cfg, dict) and sensitive in prov_cfg:
                        if sensitive == 'api_key' and prov_cfg.get('api_key') == 'ollama':
                            pass
                        else:
                            prov_cfg[sensitive] = ''

            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(
                    config_to_save,
                    f,
                    allow_unicode=True,
                    sort_keys=False,
                    indent=2,
                    default_flow_style=False
                )
            self.logger.info("[AI配置] 明文凭证已迁移到加密存储")

    def is_provider_ready(self, provider: str = None) -> bool:
        """检查提供商是否已配置好"""
        config = self.get_provider_config(provider)
        if not config.get('enabled', False):
            return False
        api_key = config.get('api_key', '').strip()
        return bool(api_key)


class AIModelCaller:
    """AI 模型调用类"""

    def __init__(self, config_path: str = None):
        """
        初始化 AI 模型调用器

        Args:
            config_path: 配置文件路径
        """
        self.logger = logging.getLogger(__name__)
        self.config = AIModelConfig(config_path)
        self._client: Any = None
        self._current_provider: str | None = None
        self._current_system_prompt: str | None = None

    def _get_client(self, provider: str = None):
        """获取或创建 API 客户端"""
        if not provider:
            provider = self.config.get_global('default_provider', 'siliconflow')

        # 如果 provider 相同，复用现有客户端
        if self._current_provider == provider and self._client is not None:
            return self._client

        provider_config = self.config.get_provider_config(provider)
        if not provider_config:
            raise ValueError(f"[AI调用] 未找到提供商配置: {provider}")

        # 检查 API 密钥
        api_key = provider_config.get('api_key', '').strip()
        if not api_key:
            raise ValueError(f"[AI调用] {provider} 未配置 API 密钥")

        try:
            import openai  # type: ignore
        except ImportError:
            raise ImportError("[AI调用] 请安装 openai: pip install openai")

        api_base = provider_config.get('api_base', 'https://api.openai.com/v1')

        self._client = openai.OpenAI(
            api_key=api_key,
            base_url=api_base,
            timeout=self.config.get_global('timeout', 120)
        )
        self._current_provider = provider

        self.logger.info(f"[AI调用] 已连接到 {provider_config.get('name', provider)}")
        return self._client

    def call(self, prompt: str, system_prompt: str | None = None,
             provider: str | None = None, use_reasoning: bool = False, **kwargs) -> str:
        """
        调用 AI 模型

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词（可选）
            provider: 提供商名称（可选）
            use_reasoning: 是否使用推理增强模型（DeepSeek deepseek-v4-pro 等）
            **kwargs: 其他模型参数（temperature, max_tokens 等）

        Returns:
            str: AI 生成的文本
        """
        try:
            client = self._get_client(provider)
            current_provider = provider or self._current_provider
            provider_config = self.config.get_provider_config(current_provider)

            # 合并参数
            params = provider_config.get('default_params', {}).copy()
            params.update(kwargs)

            # 构建消息
            messages = []
            if system_prompt:
                messages.append({'role': 'system', 'content': system_prompt})
            messages.append({'role': 'user', 'content': prompt})

            # 获取模型名称
            model = params.pop('model', None)
            if not model:
                # 如果请求推理模式且提供商有推理模型配置，则使用推理模型
                if use_reasoning and provider_config.get('reasoning_model'):
                    model = provider_config['reasoning_model']
                else:
                    model = provider_config.get('chat_model', 'gpt-4o-mini')

            # DeepSeek 推理增强参数处理
            reasoning_params = provider_config.get('reasoning_params', {})
            is_reasoning_model = (
                reasoning_params
                and provider_config.get('reasoning_model')
                and model == provider_config['reasoning_model']
            )

            # 构建 extra_body（DeepSeek thinking 等非标准参数）
            extra_body = {}
            if is_reasoning_model:
                # reasoning_effort 参数
                reasoning_effort = reasoning_params.get('reasoning_effort')
                if reasoning_effort:
                    params['reasoning_effort'] = reasoning_effort

                # thinking 参数（通过 extra_body 传递）
                thinking_config = reasoning_params.get('thinking')
                if thinking_config:
                    extra_body['thinking'] = thinking_config

            # 移除不应传给 API 的自定义参数
            params.pop('num_ctx', None)

            # 调用 API
            self.logger.debug(f"[AI调用] 正在调用 {model}...")

            call_kwargs = {
                'model': model,
                'messages': messages,
                **params
            }
            if extra_body:
                call_kwargs['extra_body'] = extra_body

            response = client.chat.completions.create(**call_kwargs)

            # 提取结果（DeepSeek 推理模型可能返回 reasoning_content）
            choice = response.choices[0]
            result = choice.message.content

            # 如果有推理内容，记录到日志
            if hasattr(choice.message, 'reasoning_content') and choice.message.reasoning_content:
                self.logger.info(
                    f"[AI调用] 推理链长度={len(choice.message.reasoning_content)}"
                )

            # 保存历史记录
            if self.config.config.get('logging', {}).get('save_history', True):
                self._save_history(prompt, system_prompt, result, current_provider)

            return result

        except Exception as e:
            self.logger.error(f"[AI调用] 调用失败: {e}")
            raise

    def call_with_retry(self, prompt: str, system_prompt: str | None = None,
                        provider: str | None = None, use_reasoning: bool = False,
                        **kwargs) -> str:
        """带重试的 AI 调用"""
        max_retries = self.config.get_global('max_retries', 3)
        retry_delay = self.config.get_global('retry_delay', 2)

        last_error = None
        for attempt in range(max_retries):
            try:
                return self.call(prompt, system_prompt, provider, use_reasoning, **kwargs)
            except Exception as e:
                last_error = e
                if attempt < max_retries - 1:
                    self.logger.warning(
                        f"[AI调用] 第 {attempt + 1} 次尝试失败，{retry_delay}秒后重试..."
                    )
                    import time
                    time.sleep(retry_delay)

        raise last_error

    def chat(self, messages: List, provider: str | None = None, **kwargs) -> str:
        """
        聊天接口

        Args:
            messages: 消息列表，格式: [{'role': 'user', 'content': '...'}]
            provider: 提供商名称
            **kwargs: 其他模型参数

        Returns:
            str: AI 生成的文本
        """
        try:
            client = self._get_client(provider)
            provider_config = self.config.get_provider_config(
                provider or self._current_provider
            )

            params = provider_config.get('default_params', {}).copy()
            params.update(kwargs)

            model = params.pop('model', None)
            if not model:
                model = provider_config.get('chat_model', 'gpt-4o-mini')

            response = client.chat.completions.create(
                model=model,
                messages=messages,
                **params
            )

            return response.choices[0].message.content

        except Exception as e:
            self.logger.error(f"[AI调用] 聊天失败: {e}")
            raise

    def _save_history(self, prompt: str, system_prompt: str,
                      response: str, provider: str = None):
        """保存调用历史"""
        try:
            import json
            from datetime import datetime

            log_config = self.config.config.get('logging', {})
            if not log_config.get('save_history', True):
                return

            history_dir = Path(self.config.config_path).parent / \
                          log_config.get('history_dir', 'ai_history')
            history_dir.mkdir(parents=True, exist_ok=True)

            history_file = history_dir / f"history_{datetime.now().strftime('%Y%m%d')}.jsonl"

            record = {
                'timestamp': datetime.now().isoformat(),
                'provider': provider or self._current_provider,
                'system_prompt': system_prompt,
                'prompt': prompt,
                'response': response
            }

            with open(history_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(record, ensure_ascii=False) + '\n')

        except Exception as e:
            self.logger.warning(f"[AI调用] 保存历史失败: {e}")

    def format_prompt(self, template: str, **variables: Any) -> str:
        """格式化提示词模板"""
        result = template
        for key, value in variables.items():
            result = result.replace(f'{{{key}}}', str(value))
            result = result.replace(f'${key}', str(value))
        return result

    def set_system_prompt(self, name: str = 'default'):
        """设置当前使用的系统提示词"""
        self._current_system_prompt = self.config.get_system_prompt(name)
        return self

    def get_system_prompt(self, name: str = 'default') -> str | None:
        """获取系统提示词"""
        return self.config.get_system_prompt(name)


# ==================== 便捷函数 ====================

def create_config(config_path: str = None) -> AIModelConfig:
    """创建或加载配置"""
    return AIModelConfig(config_path)


def call_ai(prompt: str, system_prompt: str = None,
            provider: str = None, **kwargs) -> str:
    """便捷 AI 调用函数"""
    caller = AIModelCaller()
    return caller.call(prompt, system_prompt, provider, **kwargs)
