# -*- coding: utf-8 -*-
"""
AI 模型凭证加密管理器

将 API Key 等敏感凭证从明文的 AImodel.yaml 中分离，
使用 Fernet（AES-128-CBC + HMAC-SHA256）加密存储到独立文件。

设计要点：
1. 加密文件路径：config/ai_credentials.enc（与 AImodel.yaml 同级）
2. 加密算法：复用 src/encryption.py 的设备绑定密钥派生
3. 凭证结构：JSON 字典，以 provider 为顶层 key
4. 敏感字段映射：每个 provider 预定义需加密的字段列表
5. 自动迁移：首次加载时从 YAML 明文迁移到加密存储

用法：
    from src.ai_credentials import AICredentialManager

    manager = AICredentialManager()
    manager.set_credential("deepseek", "api_key", "sk-xxx")
    key = manager.get_credential("deepseek", "api_key")
"""
import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional

from .encryption import encrypt_storage_state, decrypt_storage_state


# 每个 provider 需要加密的敏感字段
_SENSITIVE_FIELDS: Dict[str, list] = {
    "siliconflow":   ["api_key"],
    "openai":        ["api_key"],
    "ollama":        [],                    # Ollama 使用本地服务，不需要加密
    "deepseek":      ["api_key"],
    "xunfei_lfasr":  ["app_id", "secret_key", "api_key"],
}


class AICredentialManager:
    """AI 模型凭证加密管理器。

    所有 API Key / Secret 存储在加密文件中，
    明文 YAML 配置文件不再携带真实凭据。
    """

    def __init__(self, credentials_path: str = None):
        """
        Args:
            credentials_path: 加密凭证文件路径，默认 config/ai_credentials.enc
        """
        self.logger = logging.getLogger(__name__)
        self._credentials_path = credentials_path or self._get_default_path()
        self._credentials: Dict[str, Dict[str, str]] = {}
        self._loaded = False

    # ── 文件路径 ──────────────────────────────────────────

    def _get_default_path(self) -> str:
        current_dir = Path(__file__).parent.parent
        config_dir = current_dir / "config"
        config_dir.mkdir(parents=True, exist_ok=True)
        return str(config_dir / "ai_credentials.enc")

    @property
    def filepath(self) -> str:
        return self._credentials_path

    # ── 加载 / 保存 ───────────────────────────────────────

    def load(self) -> Dict[str, Dict[str, str]]:
        """从加密文件加载全部凭证。

        Returns:
            { "siliconflow": {"api_key": "sk-xxx"}, ... }
        """
        if self._loaded:
            return self._credentials

        if not os.path.exists(self._credentials_path):
            self.logger.debug("[凭证] 加密文件不存在，初始化空库")
            self._credentials = {}
            self._loaded = True
            return self._credentials

        try:
            encrypted_data = self._credentials_path
            self._credentials = load_encrypted_storage_state(self._credentials_path)
            self._loaded = True
            provider_count = len(self._credentials)
            self.logger.info(f"[凭证] 已加载 {provider_count} 个提供商的加密凭证")
            return self._credentials
        except Exception as e:
            self.logger.warning(f"[凭证] 加载失败（可能文件损坏或设备变更）: {e}")
            self._credentials = {}
            self._loaded = True
            return self._credentials

    def save(self) -> bool:
        """将内存中的凭证保存到加密文件。"""
        try:
            Path(self._credentials_path).parent.mkdir(parents=True, exist_ok=True)
            save_encrypted_storage_state(self._credentials, self._credentials_path)
            self.logger.debug("[凭证] 已加密保存")
            return True
        except Exception as e:
            self.logger.error(f"[凭证] 保存失败: {e}")
            return False

    # ── CRUD ──────────────────────────────────────────────

    def get_credential(self, provider: str, field: str,
                       default: Optional[str] = None) -> str:
        """获取单个凭证字段。

        Args:
            provider: 提供商名称（如 "deepseek"）
            field: 字段名（如 "api_key"）
            default: 不存在时的默认值

        Returns:
            凭证值，或默认值
        """
        if not self._loaded:
            self.load()
        return self._credentials.get(provider, {}).get(field, default)

    def set_credential(self, provider: str, field: str, value: str) -> bool:
        """设置单个凭证字段并立即加密保存。

        Args:
            provider: 提供商名称
            field: 字段名
            value: 凭证值（传空字符串表示删除）

        Returns:
            是否保存成功
        """
        if not self._loaded:
            self.load()

        if provider not in self._credentials:
            self._credentials[provider] = {}

        if value:
            self._credentials[provider][field] = value
            self.logger.info(f"[凭证] 已设置 {provider}.{field}")
        else:
            self._credentials[provider].pop(field, None)
            # 清理空的 provider 条目
            if not self._credentials[provider]:
                del self._credentials[provider]
            self.logger.info(f"[凭证] 已删除 {provider}.{field}")

        return self.save()

    def delete_credential(self, provider: str, field: str) -> bool:
        """删除单个凭证字段。"""
        return self.set_credential(provider, field, "")

    def get_all_for_provider(self, provider: str,
                             default: Optional[Dict] = None) -> Dict[str, str]:
        """获取某个提供商的所有凭证。

        Args:
            provider: 提供商名称
            default: 不存在时的默认值

        Returns:
            {"api_key": "sk-xxx", ...} 或默认值
        """
        if not self._loaded:
            self.load()
        return self._credentials.get(provider, dict(default or {}))

    def inject_into_config(self, models_config: Dict[str, Any]):
        """将加密凭证注入到 models 配置字典中。

        修改传入的字典，补充 api_key 等敏感字段。
        调用时机：AIModelConfig._load_config() 加载 YAML 后。

        Args:
            models_config: self.config['models'] 字典（原地修改）
        """
        if not self._loaded:
            self.load()

        if not self._credentials:
            return  # 无凭证可注入

        for provider, fields in _SENSITIVE_FIELDS.items():
            if provider not in models_config:
                continue
            if provider not in self._credentials:
                continue

            prov_creds = self._credentials[provider]
            for field in fields:
                if field in prov_creds and prov_creds[field]:
                    yaml_value = models_config[provider].get(field, "").strip()
                    # 只有 YAML 中为空或为占位符时才注入
                    if not yaml_value or yaml_value.upper().startswith("YOUR_"):
                        models_config[provider][field] = prov_creds[field]

    def extract_from_config(self, models_config: Dict[str, Any]) -> bool:
        """从 models 配置中提取敏感字段，保存到加密文件。

        调用时机：首次迁移 或 用户用代码 set_api_key 后。
        修改传入的字典，将敏感字段清空。

        Args:
            models_config: self.config['models'] 字典（原地修改）

        Returns:
            是否有凭证被提取
        """
        if not self._loaded:
            self.load()

        extracted = False
        for provider, fields in _SENSITIVE_FIELDS.items():
            if provider not in models_config:
                continue

            prov_config = models_config[provider]
            for field in fields:
                value = str(prov_config.get(field, "")).strip()
                # 跳过空值、占位符、已存在的相同值
                if not value:
                    continue
                if value.upper().startswith("YOUR_"):
                    continue
                if value == "ollama":
                    continue

                existing = self._credentials.get(provider, {}).get(field, "")
                if existing == value:
                    continue  # 加密文件中已有相同值

                if provider not in self._credentials:
                    self._credentials[provider] = {}
                self._credentials[provider][field] = value
                prov_config[field] = ""  # 从明文 config 中清除
                self.logger.info(f"[凭证] 已提取 {provider}.{field} 到加密存储")
                extracted = True

        if extracted:
            self.save()
        return extracted

    def list_providers(self) -> list:
        """列出已存储凭证的所有提供商名称。"""
        if not self._loaded:
            self.load()
        return sorted(self._credentials.keys())

    def list_fields(self, provider: str) -> list:
        """列出某提供商的已存储字段。"""
        if not self._loaded:
            self.load()
        return sorted(self._credentials.get(provider, {}).keys())


# ── CLI ──────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    manager = AICredentialManager()
    manager.load()

    def _print_usage():
        print("用法:")
        print("  python -m src.ai_credentials set    <provider> <field> <value>")
        print("  python -m src.ai_credentials get    <provider> <field>")
        print("  python -m src.ai_credentials delete <provider> <field>")
        print("  python -m src.ai_credentials list   [provider]")
        print("  python -m src.ai_credentials migrate <config_yaml_path>")

    if len(sys.argv) < 2:
        _print_usage()
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == "set" and len(sys.argv) >= 5:
        ok = manager.set_credential(sys.argv[2], sys.argv[3], sys.argv[4])
        print("OK" if ok else "FAIL")

    elif cmd == "get" and len(sys.argv) >= 4:
        val = manager.get_credential(sys.argv[2], sys.argv[3])
        if val:
            print(val[:4] + "****" + val[-4:] if len(val) > 8 else "****")
        else:
            print("(未设置)")

    elif cmd == "delete" and len(sys.argv) >= 4:
        ok = manager.delete_credential(sys.argv[2], sys.argv[3])
        print("OK" if ok else "FAIL")

    elif cmd == "list":
        if len(sys.argv) >= 3:
            fields = manager.list_fields(sys.argv[2])
            print(f"{sys.argv[2]}: {fields}")
        else:
            for p in manager.list_providers():
                fields = manager.list_fields(p)
                print(f"  {p}: {fields}")

    elif cmd == "migrate":
        import yaml
        path = sys.argv[2] if len(sys.argv) >= 3 else "config/AImodel.yaml"
        with open(path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
        models = config.get("models", {})
        if manager.extract_from_config(models):
            print("迁移完成，请重新运行程序使加密凭证生效。")
        else:
            print("未发现需要迁移的明文凭证。")

    else:
        _print_usage()
