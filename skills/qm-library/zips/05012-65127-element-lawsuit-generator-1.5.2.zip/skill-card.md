## Description: <br>
Generates structured Chinese court lawsuit documents by parsing uploaded legal filings, classifying the case type, matching a template, extracting fields, and filling DOCX output. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[hugesharks](https://clawhub.ai/user/hugesharks) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Legal practitioners and document-preparation teams use this skill to convert existing Chinese litigation documents or provided facts into structured element-style court filing templates for supported case types. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill processes legal documents that may contain confidential case facts or personal data. <br>
Mitigation: Process sensitive matters locally, redact inputs when possible, and avoid using prompt-helper workflows with unredacted real case text. <br>
Risk: The skill may download blank templates from disclosed Gitee or GitHub repositories. <br>
Mitigation: For confidential or controlled environments, use a vetted local template directory or block network access during execution. <br>
Risk: Batch testing or generated outputs can leave case-derived files on shared machines. <br>
Mitigation: Run tests with non-sensitive data and review local output directories before sharing or reusing the environment. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/hugesharks/element-lawsuit-generator) <br>
- [Case type index](references/case_type_index.md) <br>
- [Blank template source (Gitee)](https://gitee.com/hugeshark/element-lawsuit-templates) <br>
- [Blank template source backup (GitHub)](https://github.com/hugesharks/element-lawsuit-templates) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions and local DOCX file generation guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Generated legal document files are saved locally by the skill runtime.] <br>

## Skill Version(s): <br>
1.5.2 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
