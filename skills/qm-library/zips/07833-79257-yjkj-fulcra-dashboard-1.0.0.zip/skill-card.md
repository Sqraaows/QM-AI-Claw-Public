## Description: <br>
Builds a highly customizable, single-file HTML dashboard using Alpine.js and modern Vanilla CSS to visualize Fulcra data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[fulcra](https://clawhub.ai/user/fulcra) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to scaffold and customize a local Fulcra data dashboard, ingest selected Fulcra records with consent, and preview the resulting web experience before optional publication. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The local dashboard can access Fulcra data and agent memory paths. <br>
Mitigation: Use it only with data the user has approved, bind the local server to 127.0.0.1, and remove or lock down the Agent Vault download endpoint before broader use. <br>
Risk: Publishing generated dashboard files can expose sensitive Fulcra records or agent annotations. <br>
Mitigation: Review and redact generated JSONL, data.json, memory links, and dashboard copy before enabling GitHub Pages or any other public hosting. <br>
Risk: Connecting the chat envoy to an agent session can broaden local backend capabilities. <br>
Mitigation: Keep the envoy local, avoid wiring it to the main agent session unless explicitly needed, and review any command-routing changes before running them. <br>


## Reference(s): <br>
- [Fulcra Dashboard on ClawHub](https://clawhub.ai/fulcra/fulcra-dashboard) <br>
- [Fulcra Publisher Profile](https://clawhub.ai/user/fulcra) <br>
- [Skill Homepage](https://github.com/fulcradynamics/agent-skills) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and scaffolded HTML, CSS, JavaScript, Python, and JSON files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces a build-less dashboard scaffold and local preview workflow; Fulcra data access should be consented to and reviewed before any public deployment.] <br>

## Skill Version(s): <br>
0.0.6 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
