## Description: <br>
Semantic Scholar uses the OOMOL Semantic Scholar connector to search and read paper and author data from agent workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Researchers, developers, and research operations teams use this skill to query Semantic Scholar for papers, authors, citations, references, snippets, matches, and related-paper recommendations from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connecting Semantic Scholar through OOMOL and may use sensitive account credentials managed by the connector. <br>
Mitigation: Install only when comfortable with the OOMOL connection model and use the documented connector workflow instead of handling raw tokens. <br>
Risk: Large searches may consume OOMOL billing credits. <br>
Mitigation: Monitor billing and credit use before running broad or bulk paper searches. <br>
Risk: The first-time CLI install command downloads and executes an installer. <br>
Mitigation: Review the installer command before running it and prefer an already installed, trusted oo CLI when available. <br>


## Reference(s): <br>
- [Semantic Scholar](https://www.semanticscholar.org/) <br>
- [Skill page](https://clawhub.ai/oomol/oo-semantic-scholar) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are returned as JSON from the oo CLI, including data and an executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
