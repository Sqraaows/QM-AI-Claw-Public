## Description: <br>
CoinMarketCap (coinmarketcap.com). Use this skill for CoinMarketCap search and read requests through the OOMOL CoinMarketCap connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and agents use this skill to retrieve CoinMarketCap cryptocurrency listings, asset identifiers, quotes, conversion pricing, global market metrics, and API key usage details through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill brokers access through OOMOL and may reveal CoinMarketCap API plan or usage details while consuming CoinMarketCap or OOMOL quota. <br>
Mitigation: Install only when OOMOL is the intended broker, inspect the live action schema before execution, and monitor account usage or billing before repeated runs. <br>
Risk: First-time setup can install the oo CLI or require account and CoinMarketCap connection steps. <br>
Mitigation: Review installer and account connection flows before first use, and run setup steps only after an auth, connection, or missing-command failure. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-coinmarketcap) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [CoinMarketCap homepage](https://coinmarketcap.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data plus meta.executionId; action schemas are fetched before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
