## Description: <br>
Capsule CRM (capsulecrm.com). Use this skill for ANY Capsule CRM request: reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Capsule CRM through an OOMOL-connected account, including reading CRM records and creating, updating, or deleting parties, opportunities, and tasks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, and delete Capsule CRM records. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write or delete actions. <br>
Risk: The skill relies on an OOMOL-connected Capsule CRM account and sensitive credentials. <br>
Mitigation: Use the connected account already configured for the user and avoid exposing or manually handling raw credentials. <br>
Risk: The optional first-time setup path includes a remote oo CLI installer script. <br>
Mitigation: Verify the installer source or use an official package-manager installation path before running setup. <br>


## Reference(s): <br>
- [Capsule CRM homepage](https://capsulecrm.com) <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-capsule-crm) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
