## Description: <br>
Veriphone connector for verifying phone numbers and checking account verification credits through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and operations teams use this skill to verify phone number validity, carrier, and region data, and to check Veriphone verification credit status from an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Phone numbers submitted for verification are sent through the OOMOL connector to Veriphone. <br>
Mitigation: Use the skill only when sharing phone numbers with OOMOL and Veriphone is acceptable for the user's workflow. <br>
Risk: First-time setup may require installing the oo CLI from OOMOL's remote installer. <br>
Mitigation: Confirm the installation source and organizational approval before running installer commands. <br>
Risk: The skill depends on an authenticated OOMOL account, an active Veriphone connection, and sufficient OOMOL credit. <br>
Mitigation: Resolve authentication, connector, or billing errors through the documented OOMOL setup and billing flows before retrying. <br>


## Reference(s): <br>
- [ClawHub Veriphone skill listing](https://clawhub.ai/oomol/oo-veriphone) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include a data object and meta.executionId when actions are run.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
