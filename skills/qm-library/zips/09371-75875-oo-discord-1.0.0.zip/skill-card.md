## Description: <br>
Discord provides OOMOL connector actions for read-oriented Discord account, guild, invite, widget, OAuth, and platform metadata lookups through the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent retrieve Discord account, guild, invite, widget, OAuth authorization, and platform metadata through an OOMOL-connected Discord account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Discord OAuth credential through OOMOL. <br>
Mitigation: Install only when the user accepts connecting Discord to OOMOL and allowing the agent to run oo CLI connector commands for Discord lookups. <br>
Risk: The skill description is broader than the artifact-backed action set. <br>
Mitigation: Treat this release as read-oriented and avoid posting, editing, deleting, moderation, or other Discord write/admin tasks unless a listed action and user confirmation support the request. <br>
Risk: Connector schemas and required scopes can change upstream. <br>
Mitigation: Inspect the live connector schema before constructing payloads, and only request the scopes required by the specific action. <br>


## Reference(s): <br>
- [Discord homepage](https://discord.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-discord) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, json] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an OOMOL account, and a connected Discord OAuth credential.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
