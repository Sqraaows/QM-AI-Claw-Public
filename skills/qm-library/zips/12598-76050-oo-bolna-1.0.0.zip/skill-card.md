## Description: <br>
Bolna (bolna.ai) helps agents inspect and read Bolna workspace, voice agent, execution, and raw log data through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and support agents use this skill to read Bolna workspace information, list or retrieve voice agents, inspect execution history, and fetch raw execution logs from an OOMOL-connected Bolna account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The security guidance requires trusting OOMOL with connected-service credentials. <br>
Mitigation: Install only for users who trust OOMOL and are authorized to connect the relevant account. <br>
Risk: The artifact can retrieve raw execution logs and workspace summaries, which may expose operational or account information. <br>
Mitigation: Use the skill only for authorized workspace review and handle returned logs and account summaries as sensitive data. <br>
Risk: Future versions could add state-changing account, write, purchase, or deletion behavior. <br>
Mitigation: Review future versions before deployment and require explicit user confirmation for any state-changing action. <br>


## Reference(s): <br>
- [Bolna homepage](https://www.bolna.ai) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Bolna ClawHub listing](https://clawhub.ai/oomol/oo-bolna) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses may include Bolna workspace data, agent records, execution details, raw logs, and OOMOL execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
