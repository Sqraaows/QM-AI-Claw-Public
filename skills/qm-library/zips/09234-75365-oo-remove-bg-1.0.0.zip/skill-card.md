## Description: <br>
Operates remove.bg through an OOMOL-connected account to check account allowance, remove image backgrounds, and submit improvement examples. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate remove.bg from an agent session through OOMOL's oo CLI, including checking account allowance, removing image backgrounds, and submitting improvement images. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires trusting OOMOL's oo CLI and connecting a remove.bg account through OOMOL. <br>
Mitigation: Install and use the skill only when the user trusts OOMOL and is comfortable with that connected-account workflow. <br>
Risk: Image inputs may contain private or sensitive content. <br>
Mitigation: Review payloads before background-removal or improvement-submission actions, and avoid submitting sensitive images unless appropriate for the account and use case. <br>
Risk: Submitting an improvement image changes remove.bg state by sending source content for future model quality improvements. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running the improvement-submission action. <br>


## Reference(s): <br>
- [remove.bg homepage](https://www.remove.bg) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-remove-bg) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, JSON, files] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Background-removed images are uploaded to connector transit storage by the service action.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
