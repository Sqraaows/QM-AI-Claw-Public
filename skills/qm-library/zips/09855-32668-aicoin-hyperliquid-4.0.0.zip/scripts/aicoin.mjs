#!/usr/bin/env node
// AiCoin Open Data v3 — one entry point for every endpoint.
//
//   node scripts/aicoin.mjs <endpoint> ['<json params>']   call any v3 endpoint
//   node scripts/aicoin.mjs catalog [group|endpoint]        list endpoints (the live API menu)
//   node scripts/aicoin.mjs key                             show API key status + access probe
//   node scripts/aicoin.mjs set-key <id> <secret>           validate & save a new key to .env
//
// Endpoint = the path after /api/v3/ , e.g.  market/ticker  ,  hyperliquid/whales/open-positions
// Every call prints the v3 envelope {ok, data, error, meta}. Check `ok` first.
import { request, resolveMethod, fetchCatalog, saveKey, KEY, USING_OWN_KEY } from '../lib/client.mjs';

const out = (o) => console.log(JSON.stringify(o, null, 2));
const groupOf = (p) => p.replace(/^\/api\/v3\//, '').split('/')[0] || '_catalog';
const rel = (p) => p.replace(/^\/api\/v3\//, '');

const HINTS = {
  401: 'HTTP 401 — 签名或鉴权失败，检查 API key 是否正确。',
  403: 'HTTP 403 — 当前 key 没有此接口权限（套餐不够或 key 无效）。不要重试；告诉用户去 https://www.aicoin.com/opendata 升级套餐。',
  404: 'HTTP 404 — 资源不存在，检查 id / 参数是否对。',
  429: 'HTTP 429 — 触发限流，等 30-60 秒再试，或把多个查询合并成一次。',
  500: 'HTTP 500 — 服务端/上游故障，可隔 1-2 分钟重试；持续失败请联系 service@aicoin.com。',
  501: 'HTTP 501 — 该接口尚未实现（数据源未接通），换其他接口。',
  502: 'HTTP 502 — 网关临时故障，隔 1-2 分钟重试。',
  503: 'HTTP 503 — 服务暂时不可用，稍后重试。',
  504: 'HTTP 504 — 网关超时，稍后重试。',
};

async function callEndpoint(endpoint, rawParams) {
  let params = {};
  if (rawParams) {
    try { params = JSON.parse(rawParams); }
    catch { return out({ ok: false, error: { code: 'bad_params', message: `参数不是合法 JSON: ${rawParams}` }, _hint: "参数要用 JSON 对象，例: '{\"coin_key\":\"bitcoin\",\"market\":\"binance\"}'" }); }
  }
  const resolved = await resolveMethod(endpoint);
  if (!resolved) {
    return out({ ok: false, error: { code: 'unknown_endpoint', message: `未知接口: ${endpoint}` }, _hint: '跑 `node scripts/aicoin.mjs catalog` 看全部接口。' });
  }
  let res;
  try { res = await request(resolved.method, endpoint, params); }
  catch (e) { return out({ ok: false, error: { code: 'network', message: e.message }, _hint: '网络/超时错误，稍后重试。' }); }
  const body = (res.body && typeof res.body === 'object') ? res.body : { raw: res.body };
  if (res.httpStatus !== 200 && HINTS[res.httpStatus]) body._hint = HINTS[res.httpStatus];
  out(body);
}

async function showCatalog(filter) {
  const { endpoints, live } = await fetchCatalog();
  endpoints.sort((a, b) => a.path.localeCompare(b.path));

  if (filter) {
    // Group match wins over a same-named bare endpoint (e.g. `indexes` is both
    // the group and the path /api/v3/indexes) — the group view is more useful.
    const inGroup = endpoints.filter((e) => groupOf(e.path) === filter);
    if (inGroup.length) {
      const lines = [`# ${filter} (${inGroup.length} 个接口)　来源: ${live ? '线上' : '本地快照'}\n`];
      for (const e of inGroup) {
        lines.push(`${e.method} ${rel(e.path)}  —  ${e.summary || ''}`);
        for (const p of e.params || []) {
          const bits = [p.in, p.required ? '必填' : '可选', p.type];
          if (p.enum) bits.push('枚举:' + p.enum.join('/'));
          if (p.example) bits.push('例:' + p.example);
          lines.push(`    ${p.name}  (${bits.filter(Boolean).join(', ')})  ${p.desc || ''}`);
        }
        lines.push('');
      }
      return console.log(lines.join('\n'));
    }
    // Not a group — treat the filter as a single endpoint path.
    const exact = endpoints.find((e) => rel(e.path) === filter || e.path === filter);
    if (exact) return out({ source: live ? 'live' : 'snapshot', endpoint: exact });
    return out({ ok: false, error: { code: 'no_match', message: `没有 "${filter}" 分组或接口` }, _hint: '不带参数跑 catalog 看全部分组。' });
  }

  // Full table of contents — grouped, paths + summaries (no params).
  const groups = {};
  for (const e of endpoints) (groups[groupOf(e.path)] ||= []).push(e);
  const lines = [
    `# AiCoin v3 接口清单 — ${endpoints.length} 个，${Object.keys(groups).length} 个分组　(来源: ${live ? '线上' : '本地快照'})`,
    `# 看某分组的参数:  node scripts/aicoin.mjs catalog <分组名>`,
    `# 调用:  node scripts/aicoin.mjs <接口> '<JSON 参数>'\n`,
  ];
  for (const [g, es] of Object.entries(groups)) {
    lines.push(`### ${g} (${es.length})`);
    for (const e of es) lines.push(`  ${e.method.padEnd(4)} ${rel(e.path).padEnd(46)} ${e.summary || ''}`);
    lines.push('');
  }
  console.log(lines.join('\n'));
}

async function showKey() {
  const probes = [
    ['coins/tickers', { coin_key: 'bitcoin' }],
    ['derivatives/funding-rates', { coin_key: 'bitcoin', market: 'binance' }],
    ['market/big-orders', { coin_key: 'bitcoin', market: 'binance' }],
    ['hyperliquid/whales/open-positions', { coin: 'BTC' }],
    ['treasuries/summary', { coin_key: 'bitcoin' }],
  ];
  const access = [];
  for (const [ep, params] of probes) {
    try {
      const { httpStatus, body } = await request('GET', ep, params);
      access.push({ endpoint: ep, http: httpStatus, ok: body?.ok === true });
    } catch (e) { access.push({ endpoint: ep, error: e.message }); }
  }
  out({
    key_id: KEY ? KEY.slice(0, 6) + '…' : null,
    source: USING_OWN_KEY ? '用户自己的 key (.env)' : '内置免费 key',
    access,
    note: '某个接口 http=403 表示当前套餐不覆盖它；要更多权限去 https://www.aicoin.com/opendata。',
  });
}

const USAGE = `AiCoin Open Data v3
  node scripts/aicoin.mjs <接口> '<JSON参数>'   调任意 v3 接口，例:
      node scripts/aicoin.mjs market/ticker '{"coin_key":"bitcoin","market":"binance"}'
      node scripts/aicoin.mjs coins/tickers '{"coin_key":"bitcoin,ethereum"}'
      node scripts/aicoin.mjs hyperliquid/whales/open-positions '{"coin":"BTC"}'
  node scripts/aicoin.mjs catalog [分组]        看接口清单（不确定接口/参数时先跑这个）
  node scripts/aicoin.mjs key                   看 key 状态 + 权限探测
  node scripts/aicoin.mjs set-key <id> <secret> 校验并保存新 key`;

const [cmd, ...rest] = process.argv.slice(2);
(async () => {
  if (!cmd || cmd === 'help' || cmd === '-h' || cmd === '--help') return console.log(USAGE);
  if (cmd === 'catalog') return showCatalog(rest[0]);
  if (cmd === 'key') return showKey();
  if (cmd === 'set-key') {
    let id, secret;
    const raw = rest.join(' ').trim();
    if (raw.startsWith('{')) {
      // JSON 模式:兼容 AiCoin 后台直接拷下来的 {"api_key","access_key"}
      // 注意 AiCoin 后台命名反直觉 —— `api_key` 是公开 ID,`access_key` 才是 SECRET。
      // 也兼容 {"access_key_id","access_secret"} 等更直白的命名。
      try {
        const j = JSON.parse(raw);
        id = j.access_key_id || j.accessKeyId || j.key_id || j.api_key || j.key;
        secret = j.access_secret || j.accessSecret || j.secret_key || j.secret || j.access_key;
      } catch {
        return out({ ok: false, error: { code: 'bad_json', message: '参数不是合法 JSON' } });
      }
    } else if (rest.length >= 2) {
      id = rest[0];
      secret = rest[1];
    }
    if (!id || !secret) {
      return out({ ok: false, error: { code: 'bad_args', message: "用法: set-key <key_id> <secret>  或  set-key '<json>'(JSON 字段名兼容 api_key/access_key、access_key_id/access_secret 等;AiCoin 后台 api_key 是 ID、access_key 是 SECRET)" } });
    }
    const r = await saveKey(id, secret);
    return out(r.ok ? { ok: true, message: `key 已保存到 ${r.file}` } : { ok: false, error: { code: 'invalid_key', message: r.error } });
  }
  return callEndpoint(cmd, rest.join(' ').trim() || null);
})().catch((e) => { out({ ok: false, error: { code: 'fatal', message: e.message } }); process.exit(1); });
