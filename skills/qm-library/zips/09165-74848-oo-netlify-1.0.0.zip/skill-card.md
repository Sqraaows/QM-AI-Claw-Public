## Description: <br>
Netlify (netlify.com). Use this skill for ANY Netlify request: reading, creating, updating, and deleting data through an OOMOL-connected Netlify account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and site operators use this skill to inspect Netlify accounts, sites, builds, deploys, forms, and submissions, and to run controlled deploy or submission-management actions through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected Netlify account using sensitive credentials. <br>
Mitigation: Install it only for intended Netlify account operation, review granted Netlify scopes, and use the one-time CLI or OAuth setup only when needed. <br>
Risk: Write, cancel, lock, unlock, upload, and delete actions can change or remove Netlify resources. <br>
Mitigation: Confirm exact site, deploy, form, submission, and payload details with the user before running state-changing or destructive actions. <br>
Risk: Deploy and function upload actions fetch public URLs before uploading content to Netlify. <br>
Mitigation: Use only trusted, intended public URLs and inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-netlify) <br>
- [Netlify Homepage](https://www.netlify.com) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action calls and returns oo CLI execution metadata when actions run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
