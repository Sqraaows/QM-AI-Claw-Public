## Description: <br>
BigPicture.io helps agents look up company profiles by domain or identify companies associated with IPv4 or IPv6 addresses through an OOMOL-connected BigPicture.io account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and go-to-market teams use this skill to search and read BigPicture.io company intelligence from an agent workflow. It supports company lookup by domain and company identification by IP address after the user has connected BigPicture.io through OOMOL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may require installing or trusting OOMOL's oo CLI before use. <br>
Mitigation: Review the official installer or installation guide before installing in sensitive environments. <br>
Risk: Lookup domains or IP addresses are sent to BigPicture.io through the connected OOMOL account. <br>
Mitigation: Avoid submitting sensitive domains or IP addresses unless the user has approved that disclosure. <br>
Risk: The skill depends on a connected BigPicture.io account and server-side credential handling. <br>
Mitigation: Use the documented OOMOL connection flow and rerun authentication or connection setup only after a command reports an auth or connection error. <br>


## Reference(s): <br>
- [BigPicture.io homepage](https://bigpicture.io) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-bigpicture-io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [find_company_by_domain action reference](actions/find_company_by_domain.md) <br>
- [find_company_by_ip action reference](actions/find_company_by_ip.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill directs agents to inspect the live connector schema before execution and to return BigPicture.io lookup results with execution metadata when available.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence.release.version and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
