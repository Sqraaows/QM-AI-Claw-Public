---
name: liteparse-doc-converter
version: "1.0"
author: "行空小马 (XINGKONIAO)"
description: >
  使用 LiteParse 本地解析文档（PDF/Word/PPT/Excel/图片）。
  支持提取纯文本、结构化 JSON（含坐标）、页面截图、批量处理。
  所有解析在本地完成，无需联网，无 API 费用。
  触发关键词：解析文档、提取PDF文字、文档转文本、lit parse、批量解析、文档解析
agent_created: true
---

# LiteParse 本地文档解析技能

> **作者：行空小马 (XINGKONIAO)**
> 基于 [LiteParse](https://github.com/run-llama/liteparse)（LlamaIndex 团队开源项目）封装

---

## 概述

LiteParse 是一款用 Rust 编写的本地文档解析工具，核心卖点：

- **纯本地运行** — 不依赖云端 API，不上传数据，完全离线
- **速度快** — Rust 内核，解析效率远超纯 Python 方案
- **零费用** — 无 API 调用费，无订阅费
- **多格式支持** — PDF、Word、Excel、PPT、图片（JPG/PNG）、RTF、ODF 等

---

## 安装（首次使用自动执行）

加载技能后，首先运行安装脚本确保依赖就绪：

**Windows 用户：**
```cmd
~\.workbuddy\skills\liteparse-doc-converter\install.bat
```

**macOS / Linux 用户：**
```bash
bash ~/.workbuddy/skills/liteparse-doc-converter/install.sh
```

> 脚本会自动检测是否已安装，未安装则执行 `pip install liteparse`，已安装则跳过。

手动检查（可选）：
```bash
pip show liteparse
lit --version
```

### 可选依赖（按需安装）

| 需求 | 安装命令 | 说明 |
|------|----------|------|
| Word / Excel / PPT 解析 | `choco install libreoffice-fresh`（Windows） | 解析 Office 格式必需 |
| 图片格式支持 | `choco install imagemagick.app`（Windows） | 图片解析必需 |
| 中文 OCR 增强 | `pip install paddlepaddle paddleocr` | 比 Tesseract 中文识别更好 |

---

## 使用方式

### 命令行（CLI）— 最常用

```bash
# 基础：提取 PDF 文本并输出到终端
lit parse 文档路径.pdf

# 提取为结构化 JSON（含坐标/边界框）
lit parse 文档路径.pdf --format json -o 输出.json

# 提取纯文本到文件
lit parse 文档路径.pdf --format text -o 输出.txt

# 生成每页截图 PNG（用于 LLM 多模态理解）
lit screenshot 文档路径.pdf -o ./截图目录

# 批量处理整个目录
lit batch-parse ./输入目录 ./输出目录

# 批量转为 JSON 格式
lit batch-parse ./输入目录 ./输出目录 --format json
```

### Python 代码调用

```python
from liteparse import LiteParse

parser = LiteParse()

# 解析 PDF
result = parser.parse("文档.pdf")
print(result.text)              # 纯文本
print(result.pages)             # 分页列表
print(result.pages[0].blocks)  # 第一页的文本块（含坐标）

# 解析 Word（需先安装 LibreOffice）
result = parser.parse("报告.docx")

# 解析图片（内置 Tesseract OCR）
result = parser.parse("扫描件.jpg")
```

---

## 典型工作流

### 场景一：提取 PDF 文章供 AI 写作参考

```bash
lit parse 竞品文章.pdf -o 竞品文章.txt
# 把提取的 txt 作为参考素材喂给写作 AI
```

### 场景二：批量提取一批 PDF 到文本

```bash
mkdir ./文本输出
lit batch-parse ./pdf素材目录 ./文本输出 --format text
```

### 场景三：解析带图表的 PDF（截图 + OCR）

```bash
# 先生成页面截图
lit screenshot 数据报告.pdf -o ./报告截图
# 对每张截图做 OCR 文字识别
lit parse ./报告截图/page_001.png
```

### 场景四：Python 批量处理

```python
import os
from liteparse import LiteParse

parser = LiteParse()
结果字典 = {}

for 文件名 in os.listdir("./pdf文件夹"):
    if 文件名.endswith(".pdf"):
        result = parser.parse(f"./pdf文件夹/{文件名}")
        结果字典[文件名] = result.text

# 保存所有提取的文本
for 文件名, 文本内容 in 结果字典.items():
    with open(f"./输出/{文件名}.txt", "w", encoding="utf-8") as f:
        f.write(文本内容)
```

---

## 注意事项

- **中文 OCR**：默认 Tesseract 对中文效果一般；如需高质量中文识别，建议安装 PaddleOCR
- **复杂版式**：密集表格、多栏布局建议用 LlamaParse 云端版（有免费额度）
- **加密 PDF**：LiteParse 无法处理密码保护的 PDF，需先解密
- **超大文件**：建议分页处理或使用批量模式，避免内存溢出
- **Python 版本**：需要 Python 3.10 及以上

---

## 故障排查

| 问题 | 解决方案 |
|------|----------|
| `lit` 命令找不到 | `pip install --upgrade liteparse` |
| Word / PPT 解析失败 | 确认 LibreOffice 已安装并在 PATH 中 |
| 英文 OCR 效果差 | `pip install pytesseract` |
| 中文识别乱码 | `pip install paddlepaddle paddleocr` |
| 安装超时 | `pip install liteparse -i https://pypi.tuna.tsinghua.edu.cn/simple`（用清华源） |

---

## 开源项目信息

- **项目地址**：https://github.com/run-llama/liteparse
- **底层引擎**：Rust（PDFium）+ Tesseract OCR
- **许可证**：MIT
