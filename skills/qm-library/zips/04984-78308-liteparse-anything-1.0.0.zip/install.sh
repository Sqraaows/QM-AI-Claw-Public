#!/bin/bash
# LiteParse 依赖安装脚本
# 作者：行空小马 (XINGKONIAO)
# 用途：首次加载技能时自动安装 liteparse Python 包
# 如果已安装则跳过

set -e

echo "[LiteParse] 检查依赖..."

# 检查 Python 是否可用
if ! command -v python &>/dev/null && ! command -v python3 &>/dev/null; then
    echo "[LiteParse] 错误：未找到 Python，请先安装 Python 3.10+"
    exit 1
fi

PYTHON_CMD="python"
if ! command -v python &>/dev/null; then
    PYTHON_CMD="python3"
fi

# 检查是否已安装 liteparse
if $PYTHON_CMD -c "import liteparse" 2>/dev/null; then
    VERSION=$($PYTHON_CMD -c "import liteparse; print(liteparse.__version__)" 2>/dev/null || echo "未知版本")
    echo "[LiteParse] 已安装（版本: $VERSION），跳过安装"
else
    echo "[LiteParse] 未安装，正在执行 pip install liteparse ..."
    $PYTHON_CMD -m pip install liteparse --quiet
    echo "[LiteParse] 安装完成"
fi

# 验证 CLI 命令
if command -v lit &>/dev/null; then
    LIT_VER=$(lit --version 2>/dev/null || echo "")
    echo "[LiteParse] CLI 'lit' 命令可用 $LIT_VER"
else
    echo "[LiteParse] 警告：lit CLI 命令不在 PATH 中，将使用 python -m 方式调用"
fi

echo "[LiteParse] 依赖检查完毕"
