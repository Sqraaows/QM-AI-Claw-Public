# Wiki Log

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（最后一批，完成）

- Source: [知乎收藏夹“推荐系统” raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- Scope: collection items 76-85.
- New: none; all items were merged into existing topic pages to avoid thin article pages.
- Updated: [[Recommender-Systems]], [[Recommendation-Sequence-Modeling]], [[Recommendation-Compute-Efficiency]], [[Recommendation-Preranking]], [[Long-Tailed-Classification]], [[Algorithm-Team-Management]], [[Recommender-System-Methodology]], [[Ads-Recommendation-Engineering]], [[CTR-Prediction]], [[Real-Time-Bidding]], [[Auto-Bidding]], [[Recommendation-Retrieval]], [[wiki/index]]
- Key insight: 最后一批把推荐系统收藏夹收束成可复用的问题地图：长序列兴趣建模、粗排候选职责、样本比例迁移边界、计算广告约束、CTR/RTB 论文资源、推荐方法论和双塔召回改造应合并理解，而不是逐回答建孤立页面。

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第二批）

- Source: [知乎收藏夹“推荐系统” raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[Recommendation-Retrieval]], [[Recommendation-AB-Testing]], [[RQ-Kmeans-Tokenizer]], [[Recommender-System-Methodology]], [[Long-Term-Value-Optimization]]
- Updated: [[Recommender-Systems]], [[Generative-Recommendation]], [[Semantic-ID]], [[OneRec]], [[Multi-Loss-Balancing]], [[wiki/index]]
- Scope: collection items 5-15. Multi-loss duplicate answers were merged into the existing page; recommendation-specific content was split into retrieval, experimentation, tokenizer, methodology, and long-term value topics.
- Key insight: 第二批把“推荐系统怎么做”从模型范式扩展到召回评估、实验治理、长期价值和可迁移方法论；生成式召回的本质要区分复杂双塔与可生成索引。

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第一批）

- Source: [知乎收藏夹“推荐系统” raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[Recommender-Systems]], [[OneRec]], [[RankMixer]], [[CTR-One-Epoch]]
- Updated: [[Generative-Recommendation]], [[Semantic-ID]], [[Scaling-Laws]], [[CTR-Prediction]], [[wiki/index]]
- Scope: first batch centered on collection items 1-4: OneRec/RankMixer route split, advertising GR design principles, and OneEpoch vs MultiEpoch CTR training.
- Key insight: 推荐系统收藏夹应按“工业范式路线 + 训练/serving 工程问题”整理；生成式主链路与判别式 scaling 会长期共存，CTR 稀疏特征训练仍是大模型化推荐落地的基础约束。

## [2026-05-24] maintenance | 防止重复空壳 wiki 页面

- Fixed: removed duplicate empty shell pages for `AI Coding Workflow.md`, `Context Engineering.md`, `LLM RL Training.md`, `LLM Knowledge Architecture.md`, and `LLM Safety Jailbreak.md`; kept canonical slug files.
- Updated: lint now detects empty pages, duplicate titles, and non-canonical wiki links; page lookup prefers canonical slug filenames over accidental space-named shells.
- Updated: normalized wiki links to target canonical file stems, using alias display where needed (for example `[[AI-Coding-Workflow|AI Coding Workflow]]`).
- Updated: dead-link lint now uses a strict subset check: all `[[...]]` targets must belong to the `wiki/*.md` file-stem set.
- Updated docs: `SKILL.md`, `CLAUDE.md`, and `AGENTS.md` now document canonical file targets and no-empty-shell-page rules.
- Verification: `agent-bridge.py lint` passed with `empty_pages=0`, `duplicate_titles=0`, and `noncanonical_links=0`.

## [2026-05-23] ingest | 知乎收藏夹：NLP x LLM（完成）

- Source: [收藏夹 offset0](sources/zhihu/2026-05-23-zhihu-collection-981189658-api-offset0.json), [收藏夹 offset20](sources/zhihu/2026-05-23-zhihu-collection-981189658-api-offset20.json), [收藏夹 offset40](sources/zhihu/2026-05-23-zhihu-collection-981189658-api-offset40.json)
- New: [[NLP x LLM]], [[LLM RL Training]], [[Agentic RL]], [[LLM Agent Engineering]], [[Context Engineering]], [[Agent Skills]], [[AI Coding Workflow]], [[Transformer Attention Mechanism]], [[Attention Optimization]], [[Domain LLM Training]], [[LLM Safety Jailbreak]], [[LLM Knowledge Architecture]]
- Updated: [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for the new topic pages and manually kept the meaningful cross-links while avoiding broad semantic-noise merges.
- Verification: API source batches contain 20 + 20 + 14 items (`offset40.is_end=true`); `agent-bridge.py lint` passed after updates.
- Key insight: “NLP x LLM”收藏夹 54 条内容被整理为 LLM 后训练、Agent 工程、上下文工程、AI Coding、Transformer/Attention、领域模型、安全与知识架构等主题；重复的 Loss NaN 和已有 GRPO/LLM Agent 内容通过链接承接，不重复造页。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第九轮，完成）

- Source: [收藏夹 offset20：特征交叉/PyTorch 中间层/Colab/pandas 条目](sources/zhihu/2026-05-23-zhihu-collection-847112870-api-offset20.json)
- New: [[Feature Crossing]], [[PyTorch Intermediate Feature Extraction]], [[Colab Workflow Tips]], [[Pandas Workflow Best Practices]]
- Updated: [[Deep Learning Tricks]], [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for all 4 final pages and confirmed links into feature engineering, PyTorch debugging, code release, data pipeline, and existing training/debugging pages.
- Verification: `agent-bridge.py lint` passed after updates.
- Key insight: 第九轮把剩余工具型条目归入特征工程、PyTorch 调试、云 notebook 和数据管道四类；至此“深度学习trick”收藏夹 35 个内容已完成主题化整理。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第八轮）

- Source: [收藏夹 offset20：训练曲线/NLP/SOTA/LLM 微调条目](sources/zhihu/2026-05-23-zhihu-collection-847112870-api-offset20.json)
- New: [[Training Curve Diagnosis]], [[NLP Model Tuning]], [[SOTA Experiment Tricks]], [[LLM Fine-Tuning Heuristics]]
- Updated: [[Deep Learning Tricks]], [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for all 4 new pages and confirmed links to training/debugging, experiment tracking, GRPO, and multi-loss pages.
- Verification: `agent-bridge.py lint` passed after updates.
- Key insight: 第八轮把“调参”拆成曲线诊断、传统 NLP baseline、刷榜 trick 消融和大模型 SFT/RL 四类不同决策问题，避免把 loss、业务指标和 reward 设计混为一谈。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第七轮）

- Source: [收藏夹 offset20：CV transforms/CV tips/代码发布](sources/zhihu/2026-05-23-zhihu-collection-847112870-api-offset20.json)
- New: [[Computer Vision Training Tricks]], [[Research Code Release]]
- Updated: [[Deep Learning Tricks]], [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for both new pages and confirmed links to training tricks, experiment tracking, and code template pages.
- Verification: `agent-bridge.py lint` passed after updates.
- Key insight: 第七轮把 CV 内容拆成训练增强/错误分析与研究代码发布两个方向，避免把图像 transforms、比赛 trick 和论文代码复现混成一页。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第六轮）

- Source: [收藏夹 offset20：PyTorch 加速/显存/数据读取条目](sources/zhihu/2026-05-23-zhihu-collection-847112870-api-offset20.json)
- New: [[PyTorch Training Acceleration]]
- Updated: [[Deep Learning Tricks]], [[PyTorch DataLoader Performance]], [[PyTorch Memory Optimization]], [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for [[PyTorch Training Acceleration]] and confirmed strongest links are existing PyTorch data/memory pages plus training template/tracking pages.
- Verification: fixed one unsupported wiki alias and `agent-bridge.py lint` passed after updates.
- Key insight: 第六轮把 PyTorch 工程优化拆成速度、数据管道和显存三层；AMP、torch.compile、DDP/DeepSpeed/FSDP、prefetch 和 checkpointing 都需要先定位瓶颈再逐项验证。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第五轮）

- Source: [Adam/LR/batch 调参](sources/zhihu/2026-05-23-zhihu-tuning-skills-adam-lr-batch-3415424048.json), [初始化调参](sources/zhihu/2026-05-23-zhihu-initialization-tuning-153674495.json), [RNN/CNN 调参经验](sources/zhihu/2026-05-23-zhihu-rnn-cnn-training-experience-94816420.json)
- New: [[Neural Network Initialization]]
- Updated: [[Deep Learning Tricks]], [[Deep Learning Training Tricks]], [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for [[Neural Network Initialization]] and kept explicit links to training/debugging pages while ignoring broad optimization false positives.
- Verification: `agent-bridge.py lint` passed after updates.
- Key insight: 第五轮把第一页剩余调参经验合并进训练流程，并把初始化单独沉淀为可复用页面；初始化、LR、batch、optimizer、scheduler 和 normalization 要作为耦合旋钮共同验证。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第四轮）

- Source: [训练可视化](sources/zhihu/2026-05-23-zhihu-pytorch-training-visualization-2016990076660360576.json), [Dropout 回归](sources/zhihu/2026-05-23-zhihu-dropout-regression-561124500.json), [正负样本比例/长尾分类](sources/zhihu/2026-05-23-zhihu-class-imbalance-3483543427.json), [残差连接替代](sources/zhihu/2026-05-23-zhihu-residual-connection-alternative-88257337188.json)
- New: [[Deep Learning Experiment Tracking]], [[Dropout in Regression]], [[Long-Tailed Classification]], [[Hyper-Connections]]
- Updated: [[Deep Learning Tricks]], [[Deep Learning Training Tricks]], [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for all 4 new pages and recorded useful broad practice links without merging every semantic neighbor.
- Verification: `agent-bridge.py lint` passed after updates.
- Key insight: 第四轮把“默认经验”拆开验证：可视化是训练反馈基础设施，Dropout 在回归中有分布偏移风险，长尾分类会造成 classifier 模长偏置，残差连接也可以被可学习连接结构挑战。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第三轮）

- Source: [代码检查](sources/zhihu/2026-05-23-zhihu-dl-code-checking-2752651116.json), [神经网络不 work](sources/zhihu/2026-05-23-zhihu-neural-network-not-working-2760206831.json), [train 函数模板](sources/zhihu/2026-05-23-zhihu-train-function-template-2701131154.json), [随机种子 3407](sources/zhihu/2026-05-23-zhihu-random-seed-3407-2555391926.json)
- New: [[Deep Learning Debugging Checklist]], [[Deep Learning Training Code Template]]
- Updated: [[Deep Learning Tricks]], [[Deep Learning Training Tricks]], [[wiki/index]]
- Relation discovery: updated OpenAI embedding index; ran `agent-bridge.py link --mode deep` for both new pages and kept the useful covered links rather than merging every broad training-practice match.
- Key insight: 第三轮把“模型不 work”拆成数据/标签/增强/模式切换/shape 的排查清单，并把 train 模板视为复现实验基础设施，而不是一段孤立循环代码。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第二轮）

- Source: [Gumbel-Softmax 原理](sources/zhihu/2026-05-23-zhihu-gumbel-softmax-intuitive-633431594.json), [Gumbel-Softmax 用法](sources/zhihu/2026-05-23-zhihu-gumbel-softmax-practical-495806343.json), [PyTorch DataLoader 性能](sources/zhihu/2026-05-23-zhihu-pytorch-dataloader-performance-1518052588.json), [PyTorch 显存优化](sources/zhihu/2026-05-23-zhihu-pytorch-memory-tips-573633662.json)
- New: [[Gumbel-Softmax]], [[PyTorch DataLoader Performance]], [[PyTorch Memory Optimization]]
- Updated: [[Deep Learning Tricks]], [[Deep Learning Training Tricks]], [[wiki/index]]
- Relation discovery: rebuilt embedding index with OpenAI provider; ran `agent-bridge.py link --mode deep` for all 3 new pages and selectively kept actionable links instead of merging every broad semantic match.
- Verification: `agent-bridge.py lint` passed after updates.
- Key insight: 第二轮补齐离散采样可微化和 PyTorch 工程优化两类 trick，把“训练效果不好”拆成可微性、吞吐和显存三个独立诊断维度。

## [2026-05-23] ingest | 知乎收藏夹：深度学习trick（第一轮）

- Source: [收藏夹第一页](sources/zhihu/2026-05-23-zhihu-collection-847112870-page1.json), [Loss NaN 排查](sources/zhihu/2026-05-23-zhihu-loss-nan-1906863812717568067.json), [多 loss 梯度平衡](sources/zhihu/2026-05-23-zhihu-multi-loss-gradient-3562750282.json), [多 loss uncertainty weighting](sources/zhihu/2026-05-23-zhihu-multi-loss-uncertainty-1272980359.json), [深度学习15条调参经验](sources/zhihu/2026-05-23-zhihu-training-tricks-630152281.json)
- New: [[Deep Learning Tricks]], [[Loss NaN Debugging]], [[Multi-Loss Balancing]], [[Deep Learning Training Tricks]]
- Relation discovery: ran `agent-bridge.py link --mode light` for all 4 new pages; high-confidence relations are covered in their Related Pages sections; `[[Multi-Loss Balancing]]` keeps a medium-confidence optimization-objective link to `[[GRPO]]`.
- Verification: `agent-bridge.py lint` passed.
- Key insight: 首轮整理不按回答逐篇建页，而是把收藏夹中的训练稳定性、多 loss 平衡和调参经验合并为可复用知识主题。

## [2026-05-23] maintenance | Legacy wiki migration to current llm-wiki template

- Updated: 23 legacy pages — rebuilt from original `sources/*.pdf` into current "知识卡片 + 来源笔记 + 相关页面 + 来源 + 变更日志" structure
- Preserved: [[LLaTTE]], [[Scaling Laws]] — already close to current template
- Updated docs: [知乎收藏夹整理方案](docs/zhihu-favorites-llm-wiki-plan.md) — clarified that future work uses Playwright MCP + current llm-wiki protocol, not a Chrome extension
- Verification: structural heading check passed; `agent-bridge.py check` passed via `uv run --with pyyaml --with pymupdf`
- Note: project `.venv` still points to an old uv-managed Python path, so uv temporary dependency injection was used for verification

## [2026-05-13] ingest | LLaTTE: Scaling Laws for Multi-Stage Sequence Modeling in Large-Scale Ads Recommendation

- Source: [arXiv:2601.20083](sources/2601.20083.pdf)
- New: [[LLaTTE]], [[Scaling Laws]]
- Updated: [[Generative-Recommendation]] (added comparison with LLaTTE as multi-stage sequence modeling route)
- Key insight: Meta 的 LLaTTE 证明大规模广告推荐序列建模也可以呈现类似 LLM 的 scaling law，但语义特征、模型宽度、长上下文和异步 upstream user model 是在生产时延约束下释放扩展收益的关键。

## [2026-05-12] ingest | 广告生成式推荐三篇论文（GPR + GR4AD + UniVA）

- Source: [广告生成式推荐应该怎么做：融合三篇的系统设计观](https://zhuanlan.zhihu.com/p/2036546189705918125)
- New: [[GPR]], [[GR4AD]], [[UniVA]], [[Semantic-ID]], [[Generative Recommendation]]
- Updated: [[Generative-AI]], [[GRPO]], [[Auto-Bidding]], [[Real-Time-Bidding]] (added bidirectional links)
- Key insight: 广告生成式推荐通过 Semantic ID + 自回归生成替代传统召回-排序级联范式，三篇论文已在亿级用户规模全量部署（GPR: GMV +5%+, GR4AD: 广告收入 +4.2%, UniVA: GMV +1.5%）
- Core design principles: 商业价值从 tokenization 阶段渗透；异构输入需 Token-Aware 架构；RL 探索但 simulator 质量是核心风险

## [2026-04-16] ingest | Bid2X: Bidding Environment Foundation Model

- New: [[Bid2X]], [[Auto-Bidding]], [[Foundation Model]], [[Real-Time Bidding]], [[Zero-Inflated Distribution]]
- Key insight: Unified sequence embedding for heterogeneous bidding data

## [2026-04-16] ingest | RTBAgent: LLM-based Real-Time Bidding Agent

- New: [[RTBAgent]], [[LLM Agent]], [[CTR Prediction]]
- Key insight: Multi-memory retrieval mechanism for adaptive bidding

## [2026-04-16] ingest | LLP: LLM-based Product Pricing in E-commerce

- New: [[LLP]], [[C2C E-commerce]], [[Generative Product Pricing]], [[GRPO]], [[RAG]]
- Key insight: Two-stage SFT+GRPO optimization for C2C pricing

## [2026-04-16] ingest | Pricing and Competition for Generative AI

- New: [[Pricing and Competition for Generative AI]], [[Generative AI]], [[Game Theory]], [[Price-Performance Ratio]], [[User Satisfaction]]
- Key insight: Sequential pricing game model for competitive generative AI markets

## [2026-04-30] lint | Protocol compliance check

- Updated: 14 stub pages — added missing `sources` frontmatter and standard sections
- Fixed: requirements.txt — added fallback PDF dependencies (pdfplumber, pdfminer.six)

## [2026-04-30] ingest | Content extraction from 4 source PDFs

- Source: sources/2510.23410.pdf (Bid2X), sources/2502.00792v1.pdf (RTBAgent), sources/2510.09347.pdf (LLP), sources/2411.02661.pdf (Pricing and Competition for Generative AI)
- Fixed: [[Bid2X]], [[RTBAgent]], [[LLP]] — corrected `sources` frontmatter to point to actual PDF files
- Updated (filled Key Insights + Detailed Explanation):
  - Bid2X paper stubs: [[Auto-Bidding]], [[Foundation Model]], [[Real-Time Bidding]], [[Zero-Inflated Distribution]]
  - RTBAgent paper stubs: [[LLM Agent]], [[CTR Prediction]]
  - LLP paper stubs: [[C2C E-commerce]], [[Generative Product Pricing]], [[GRPO]], [[RAG]]
  - Pricing paper stubs: [[Generative AI]], [[Game Theory]], [[Price-Performance Ratio]], [[User Satisfaction]]
- Enriched main pages: [[Bid2X]], [[RTBAgent]], [[LLP]], [[Pricing and Competition for Generative AI]] — added Detailed Explanation sections
- Key insight: All 18 wiki pages now have substantial content sourced from original PDFs; no more empty stub pages
## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第四批）

- Source: [知乎收藏夹：推荐系统 raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[CVR-Prediction|CVR Prediction]], [[In-Batch-Negative-Sampling|In-Batch Negative Sampling]], [[Geo-Aware-Recommendation|Geo-Aware Recommendation]], [[Repeated-Item-Recommendation|Repeated Item Recommendation]], [[Recommendation-Reranking|Recommendation Reranking]], [[Su-Jianlin-Blog-Map|Su Jianlin Blog Map]]
- Updated: [[Recommender-Systems|Recommender Systems]], [[Generative-Recommendation|Generative Recommendation]], [[OneRec]], [[Recommendation-Sequence-Modeling|Recommendation Sequence Modeling]], [[Recommendation-AB-Testing|Recommendation A/B Testing]], [[Recommender-System-Methodology|Recommender System Methodology]], [[CTR-Prediction|CTR Prediction]], [[wiki/index]]
- Key insight: 第四批把推荐系统主线进一步拆到训练样本、转化归因、列表级重排、重复 item 控制和本地生活地理约束；同时把苏剑林博客整理作为资源图谱归档，而不是混进推荐系统概念页。

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第五批）

- Source: [知乎收藏夹：推荐系统 raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[Recommender-Foundation-Model|Recommender Foundation Model]], [[Recommendation-Baselines|Recommendation Baselines]], [[Ranking-Evaluation-Metrics|Ranking Evaluation Metrics]], [[High-Dimensional-Distance|High-Dimensional Distance]], [[Streaming-Recommendation|Streaming Recommendation]]
- Updated: [[Recommender-Systems|Recommender Systems]], [[Feature-Crossing|Feature Crossing]], [[Gumbel-Softmax]], [[Generative-Recommendation|Generative Recommendation]], [[Recommendation-Retrieval|Recommendation Retrieval]], [[Recommendation-Tokenization|Recommendation Tokenization]], [[CTR-Prediction|CTR Prediction]], [[CTR-One-Epoch|CTR One-Epoch]], [[Recommendation-AB-Testing|Recommendation A/B Testing]], [[Recommendation-Sequence-Modeling|Recommendation Sequence Modeling]], [[wiki/index]]
- Subagent: read-only analysis confirmed that items 38 and 41 should stay merged into existing pages for now, and item 39 is already covered by [[Gumbel-Softmax]].
- Key insight: 第五批把推荐系统整理从模型路线扩展到强 baseline、排序指标口径、高维 embedding 几何假设、实时 ID 记忆和流式训练边界。

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第六批）

- Source: [知乎收藏夹：推荐系统 raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[Recommendation-System-Anti-Patterns|Recommendation System Anti-Patterns]], [[SORT-Gen]], [[Recommendation-Preranking|Recommendation Preranking]], [[Algorithm-Team-Management|Algorithm Team Management]]
- Updated: [[Recommender-Systems|Recommender Systems]], [[Recommendation-Sequence-Modeling|Recommendation Sequence Modeling]], [[Streaming-Recommendation|Streaming Recommendation]], [[Recommendation-Compute-Efficiency|Recommendation Compute Efficiency]], [[Recommendation-Reranking|Recommendation Reranking]], [[Multi-Objective-Recommendation|Multi-Objective Recommendation]], [[Generative-Recommendation|Generative Recommendation]], [[Recommendation-Retrieval|Recommendation Retrieval]], [[Ranking-Evaluation-Metrics|Ranking Evaluation Metrics]], [[Recommendation-AB-Testing|Recommendation A/B Testing]], [[Recommender-System-Methodology|Recommender System Methodology]], [[Feature-Crossing|Feature Crossing]], [[Long-Term-Value-Optimization|Long-Term Value Optimization]], [[SOTA-Experiment-Tricks|SOTA Experiment Tricks]], [[wiki/index]]
- Subagent: read-only analysis recommended merging ultra-long sequence, streaming, rollout diagnosis, and Kaggle practice into existing pages, while creating standalone pages for anti-patterns, SORT-Gen, preranking, and algorithm team management.
- Key insight: 第六批把推荐系统知识从模型能力继续推进到链路分工、列表级生成式重排、短期收益反模式、推全诊断和团队执行机制。

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第七批）

- Source: [知乎收藏夹：推荐系统 raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[Merchant-Ecosystem-Recommendation|Merchant Ecosystem Recommendation]], [[Ranking-Loss-for-Recommendation|Ranking Loss for Recommendation]], [[Retrieval-Contribution-Evaluation|Retrieval Contribution Evaluation]], [[xMTF]]
- Updated: [[Recommender-Systems|Recommender Systems]], [[Recommendation-Sequence-Modeling|Recommendation Sequence Modeling]], [[CTR-Prediction|CTR Prediction]], [[Recommendation-Retrieval|Recommendation Retrieval]], [[Recommendation-Preranking|Recommendation Preranking]], [[Multi-Objective-Recommendation|Multi-Objective Recommendation]], [[Long-Term-Value-Optimization|Long-Term Value Optimization]], [[Recommender-System-Methodology|Recommender System Methodology]], [[Algorithm-Team-Management|Algorithm Team Management]], [[wiki/index]]
- Key insight: 第七批补齐推荐系统中层能力：长期兴趣建模、商家生态扶持、CTR ranking loss、多路召回贡献评估、粗排工程实践和 formula-free 多任务融合。

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第八批）

- Source: [知乎收藏夹：推荐系统 raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[Short-Video-Recommendation|Short-Video Recommendation]], [[Ads-Recommendation-Engineering|Ads Recommendation Engineering]], [[GraphSAGE]], [[HSTU]], [[GNOLR]], [[HLLM]], [[Vector-Search|Vector Search]], [[Recommendation-Serving|Recommendation Serving]], [[MTGR]]
- Updated: [[Recommender-Systems|Recommender Systems]], [[Recommendation-Preranking|Recommendation Preranking]], [[Recommendation-Retrieval|Recommendation Retrieval]], [[Generative-Recommendation|Generative Recommendation]], [[Recommendation-Sequence-Modeling|Recommendation Sequence Modeling]], [[Multi-Objective-Recommendation|Multi-Objective Recommendation]], [[Recommendation-Compute-Efficiency|Recommendation Compute Efficiency]], [[Recommender-Foundation-Model|Recommender Foundation Model]], [[wiki/index]]
- Key insight: 第八批把推荐系统从模型路线继续推进到可上线系统：粗排跨阶段一致性、短视频漏斗、广告商业约束、图/向量召回、serving 架构，以及 HSTU/HLLM/MTGR/GNOLR 等工业模型路线都必须和成本、延迟、候选合法性及业务目标一起理解。

## [2026-05-24] ingest | 知乎收藏夹：推荐系统（第三批）

- Source: [知乎收藏夹：推荐系统 raw API](sources/zhihu/2026-05-24-zhihu-collection-981188948-pages.json)
- New: [[Recommendation-Sequence-Modeling|Recommendation Sequence Modeling]], [[Recommendation-Tokenization|Recommendation Tokenization]], [[Recommendation-Compute-Efficiency|Recommendation Compute Efficiency]], [[Multi-Objective-Recommendation|Multi-Objective Recommendation]]
- Updated: [[Recommender-Systems|Recommender Systems]], [[Generative-Recommendation|Generative Recommendation]], [[OneRec]], [[RankMixer]], [[Semantic-ID|Semantic ID]], [[RQ-Kmeans-Tokenizer|RQ-Kmeans Tokenizer]], [[LLaTTE]], [[Scaling-Laws|Scaling Laws]], [[CTR-One-Epoch|CTR One-Epoch]], [[wiki/index]]
- Subagent: read-only analysis confirmed the theme-merge strategy for items 16-25 and recommended avoiding thin per-paper pages for HSTU, TokenRec, Pantheon, RankGraph at this stage.
- Key insight: 第三批把“推荐大模型化”从生成式/判别式之争推进到四个更底层的问题：长序列计算复用、用户/物品 tokenization、GPU/MFU 算力效率、多目标融合治理。

## [2026-05-24] maintenance | NLP x LLM 时间感知格式补齐

- Source: [NLP x LLM Zhihu collection raw API](sources/zhihu/2026-05-23-zhihu-collection-981189658-api-offset0.json), [offset20](sources/zhihu/2026-05-23-zhihu-collection-981189658-api-offset20.json), [offset40](sources/zhihu/2026-05-23-zhihu-collection-981189658-api-offset40.json)
- Updated: [[NLP-x-LLM|NLP x LLM]], [[LLM-RL-Training|LLM RL Training]], [[LLM-Agent-Engineering|LLM Agent Engineering]], [[Context-Engineering|Context Engineering]], [[Agent-Skills|Agent Skills]], [[Agentic-RL|Agentic RL]], [[AI-Coding-Workflow|AI Coding Workflow]], [[Transformer-Attention-Mechanism|Transformer Attention Mechanism]], [[Attention-Optimization|Attention Optimization]], [[Domain-LLM-Training|Domain LLM Training]], [[LLM-Safety-Jailbreak|LLM Safety Jailbreak]], [[LLM-Knowledge-Architecture|LLM Knowledge Architecture]]
- Key insight: 将同源页面统一补充 `zhihu_collection_api`、来源时间信息、`### 时间定位` 和正文 `YYYY.MM` 可读时间标注，避免只按内容主题关联而丢失论文/帖子/工程讨论的时间先后关系。

## [2026-05-24] maintenance | 时间锚点 Markdown 原生格式

- Updated protocol: [SKILL.md](SKILL.md), [AGENTS.md](AGENTS.md), [CLAUDE.md](CLAUDE.md), [assets/ingest_rules.md](assets/ingest_rules.md)
- Updated wiki: [[NLP-x-LLM|NLP x LLM]], [[LLM-RL-Training|LLM RL Training]], [[LLM-Agent-Engineering|LLM Agent Engineering]], [[Context-Engineering|Context Engineering]], [[Agent-Skills|Agent Skills]], [[Agentic-RL|Agentic RL]], [[AI-Coding-Workflow|AI Coding Workflow]], [[Transformer-Attention-Mechanism|Transformer Attention Mechanism]], [[Attention-Optimization|Attention Optimization]], [[Domain-LLM-Training|Domain LLM Training]], [[LLM-Safety-Jailbreak|LLM Safety Jailbreak]], [[LLM-Knowledge-Architecture|LLM Knowledge Architecture]]
- Key insight: 将可读时间从散落的 `YYYY.MM` 改为 `> **时间范围**` 摘要框和 `**[YYYY.MM] 事件/工作名**` 锚点列表，使 Obsidian/Markdown 原生渲染下也能快速扫出知识演进顺序。
