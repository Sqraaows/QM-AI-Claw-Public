# Wiki Index

> Knowledge base entry point. Start here to explore or add new content.

## Recent Activity

See [log.md](../log.md) for full history.

## Quick Start

1. Add source materials to `sources/`.
2. Ask your agent: "Ingest sources/[filename] into wiki".
3. Explore and query the generated knowledge.

## Status

- Empty: waiting for first ingest.

---

*Last updated: 2026-06-05*
