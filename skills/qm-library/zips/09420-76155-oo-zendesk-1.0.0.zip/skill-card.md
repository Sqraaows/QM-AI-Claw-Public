## Description: <br>
Zendesk (zendesk.com). Use this skill for Zendesk requests that read, create, update, or reply to support data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Support teams and agents use this skill to inspect Zendesk users, organizations, and tickets, and to create, update, or reply to tickets through the OOMOL Zendesk connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses an OOMOL-connected Zendesk account and can expose data available to that connection. <br>
Mitigation: Connect only Zendesk credentials with scopes and account access appropriate for the agent's intended tasks. <br>
Risk: Create, update, and reply actions can change Zendesk ticket state or send public replies. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running any state-changing action. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live action schema before constructing each action payload. <br>


## Reference(s): <br>
- [Zendesk homepage](https://www.zendesk.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-zendesk) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the oo CLI to return connector JSON responses containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact metadata and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
