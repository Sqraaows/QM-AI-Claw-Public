## Description: <br>
Helps create, review, and package SN94 BitSota competition proposals and replayable task repository skeletons for measurable research tasks. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[alveuslabs](https://clawhub.ai/user/alveuslabs) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and competition operators use this skill to turn measurable SN94 BitSota competition ideas into proposal briefs, replay contracts, task repository skeletons, and launch checklists. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated task repositories or proposals may include incorrect, incomplete, or unsafe benchmark assumptions if published without review. <br>
Mitigation: Review generated repos and proposal fields before publishing, including patch surfaces, setup commands, benchmark commands, result paths, runtime limits, and scoring policy. <br>
Risk: Competition workflows may involve wallet material, credentials, hidden validation data, or other sensitive operational inputs. <br>
Mitigation: Keep secrets, wallets, private keys, API tokens, and production credentials out of task repositories and replay sandboxes. <br>
Risk: Generated setup or benchmark scripts may execute task-specific code supplied by a competition repository. <br>
Mitigation: Run generated benchmark and setup scripts only in an appropriate sandbox and validate them before reward-active use. <br>


## Reference(s): <br>
- [SN94 Competition Poster release page](https://clawhub.ai/alveuslabs/sn94-competition-poster) <br>
- [SN94 Replay Contract](references/replay-contract.md) <br>
- [SN94 Task Repo Spec](references/task-repo-spec.md) <br>
- [Marketplace Packaging](references/marketplace-packaging.md) <br>
- [SN94 BitSota competition proposal issue template](https://github.com/AlveusLabs/SN94-BitSota/issues/new?template=competition_proposal.md) <br>


## Skill Output: <br>
**Output Type(s):** [Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with YAML, JSON, Python, and shell snippets or generated starter repository files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May scaffold local task repository files when the bundled script is used.] <br>

## Skill Version(s): <br>
1.0.2 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
