## Description: <br>
Interzoid (interzoid.com). Use this skill for Interzoid data lookup, matching, validation, enrichment, and account credit requests through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and data teams use this skill to run Interzoid lookups through an OOMOL-connected account for company matching, organization name standardization, full-name matching, email validation, IP profile checks, and remaining-credit checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Interzoid account and may fail when the CLI is missing, authentication expires, scopes are missing, or account credits are exhausted. <br>
Mitigation: Install and sign in to the oo CLI only when needed, reconnect Interzoid when connector errors indicate missing or expired credentials, and check or recharge credits before retrying failed calls. <br>
Risk: Lookup inputs such as names, email addresses, organization names, and IP addresses are sent through the connected Interzoid service. <br>
Mitigation: Use the skill only for data the user intends to process with Interzoid, inspect the live action schema first, and avoid submitting unnecessary sensitive fields. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-interzoid) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Interzoid homepage](https://www.interzoid.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
