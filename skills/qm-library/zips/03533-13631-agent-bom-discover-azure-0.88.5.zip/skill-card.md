## Description: <br>
Discover Azure-hosted AI agent and MCP-relevant assets from the operator's environment, emit canonical agent-bom inventory JSON, and scan it without giving agent-bom long-lived Azure credentials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
Apache-2.0 <br>


## Use Case: <br>
Developers and operators use this skill to inventory Azure OpenAI, Container Apps, AKS, Functions, Azure ML, and agentic Azure infrastructure as canonical agent-bom JSON. It defaults to discovery-only behavior and only runs scans when the operator asks for findings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can inventory Azure resources when given an Azure identity. <br>
Mitigation: Use only operator-approved subscriptions and read-only Azure identities. <br>
Risk: Azure secrets or tokens could be exposed if pasted or printed during setup. <br>
Mitigation: Do not ask users to paste raw secrets, access tokens, or connection strings, and do not display credential values. <br>
Risk: Inventory output may contain environment details. <br>
Mitigation: Write inventory only to an operator-selected local path and rely on the skill's redaction and schema-validation requirements before scanning. <br>
Risk: The workflow depends on an external agent-bom package or repository. <br>
Mitigation: Verify the package source before running the referenced commands. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/msaad00/agent-bom-discover-azure) <br>
- [agent-bom repository](https://github.com/msaad00/agent-bom) <br>
- [agent-bom PyPI package](https://pypi.org/project/agent-bom/) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, JSON] <br>
**Output Format:** [Markdown guidance with bash commands and JSON inventory or findings files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Writes inventory and optional scan findings to operator-selected local output paths.] <br>

## Skill Version(s): <br>
0.88.5 (source: SKILL.md frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
