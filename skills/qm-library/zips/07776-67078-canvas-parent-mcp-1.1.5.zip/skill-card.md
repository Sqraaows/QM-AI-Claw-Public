## Description: <br>
Helps agents retrieve Canvas LMS information for a user or observed student, including courses, assignments, grades, planner items, announcements, conversations, discussions, and files. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Students, parents, and education-support agents use this skill to inspect Canvas LMS activity, grades, due work, messages, announcements, and course files through an MCP server configured with the user's Canvas credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive Canvas credentials or tokens that can grant the same access as the user account. <br>
Mitigation: Install only when the external Canvas MCP package is trusted, use the least-privileged supported authentication option, and keep credentials out of repositories. <br>
Risk: The file download tool can write Canvas files to disk. <br>
Mitigation: Confirm the destination path before allowing downloads and avoid overwriting files unless explicitly intended. <br>
Risk: Broad Canvas-related activation may expose school records or observer-linked student data in agent workflows. <br>
Mitigation: Use the skill only for authorized Canvas accounts and verify the requested student or observee context before retrieving data. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/canvas-parent-mcp) <br>
- [Publisher profile](https://clawhub.ai/user/chrischall) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include Canvas MCP tool calls and file download guidance when requested.] <br>

## Skill Version(s): <br>
1.1.5 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
