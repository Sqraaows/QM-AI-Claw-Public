## Description: <br>
SmugMug (smugmug.com). Use this skill for SmugMug requests that search and read account, profile, album, folder, node, image, metadata, and content data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and agents use this skill to inspect SmugMug content through an OOMOL-connected account. It supports read-oriented workflows for albums, folders, nodes, users, image details, image metadata, and user content search. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected SmugMug account and can read profile, album, folder, image, metadata, and search results from that account. <br>
Mitigation: Install and use it only for intended SmugMug access, keep the connection scoped to the needed account, and review live connector schemas before sending payloads. <br>
Risk: First-time setup may use remote oo CLI installer commands. <br>
Mitigation: Run installer commands only after deciding to trust OOMOL's installer and use existing authenticated setup when available. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-smugmug) <br>
- [SmugMug Homepage](https://www.smugmug.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, Guidance, JSON] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
