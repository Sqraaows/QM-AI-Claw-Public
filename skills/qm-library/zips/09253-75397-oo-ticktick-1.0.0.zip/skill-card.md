## Description: <br>
TickTick (ticktick.com). Use this skill for any TickTick request, including reading, creating, updating, and deleting data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to operate a connected TickTick account through OOMOL, including task, project, completed-task, filtered-search, habit, and habit-check-in workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, move, complete, and otherwise change TickTick tasks, projects, and habits. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>
Risk: Delete actions can remove TickTick tasks or projects. <br>
Mitigation: Require explicit user approval for the specific target before running destructive actions. <br>
Risk: The skill requires a connected OOMOL/TickTick account with sensitive credentials. <br>
Mitigation: Install it only when agent access to that TickTick account is intended, and use the documented OOMOL connection flow rather than exposing raw tokens. <br>


## Reference(s): <br>
- [ClawHub TickTick skill page](https://clawhub.ai/oomol/oo-ticktick) <br>
- [TickTick homepage](https://ticktick.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples; connector responses are JSON.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI and a connected OOMOL TickTick account; agents should fetch live connector schemas before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
