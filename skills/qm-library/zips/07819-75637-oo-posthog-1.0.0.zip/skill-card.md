## Description: <br>
Use this skill for PostHog requests that read, create, update, or delete data through an OOMOL-connected account instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage PostHog projects, dashboards, insights, annotations, cohorts, event definitions, property definitions, feature flags, and queries through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses an OOMOL-brokered PostHog connection with read, write, and delete authority over PostHog resources. <br>
Mitigation: Install only when the publisher and connection broker are trusted, and confirm every write or delete target and payload before execution. <br>
Risk: One-time setup documentation includes pipe-to-shell installer commands for the oo CLI. <br>
Mitigation: Prefer the official install guide or inspect installer scripts before running them. <br>
Risk: Incorrect action payloads can change or delete dashboards, feature flags, cohorts, insights, annotations, and definitions. <br>
Mitigation: Fetch the live action schema before building payloads and review state-changing commands with the user before execution. <br>


## Reference(s): <br>
- [ClawHub PostHog skill page](https://clawhub.ai/oomol/oo-posthog) <br>
- [PostHog homepage](https://posthog.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
