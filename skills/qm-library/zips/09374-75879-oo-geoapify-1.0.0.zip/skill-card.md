## Description: <br>
Use Geoapify through an OOMOL-connected account for address autocomplete, geocoding, routing, and route matrix requests. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Geoapify connector schemas and run Geoapify actions through the oo CLI for address search, geocoding, routing, and travel matrix workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Geoapify account access and credentials are brokered through OOMOL. <br>
Mitigation: Install only when the user is comfortable using OOMOL with their Geoapify account and relies on the OOMOL-connected account instead of exposing raw API tokens. <br>
Risk: Requests may contain sensitive addresses, coordinates, routes, or home and work locations. <br>
Mitigation: Review payloads that include location data before running connector actions. <br>
Risk: The first-time setup path includes optional shell installer commands for the oo CLI. <br>
Mitigation: Install the oo CLI from a trusted OOMOL source and inspect installer commands before execution. <br>


## Reference(s): <br>
- [ClawHub Geoapify skill page](https://clawhub.ai/oomol/oo-geoapify) <br>
- [Geoapify homepage](https://www.geoapify.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Address autocomplete action](actions/address_autocomplete.md) <br>
- [Forward geocode action](actions/forward_geocode.md) <br>
- [Route calculation action](actions/get_route.md) <br>
- [Route matrix action](actions/get_route_matrix.md) <br>
- [Reverse geocode action](actions/reverse_geocode.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the oo CLI to inspect live action schemas and run Geoapify connector actions; responses are JSON with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
