## Description: <br>
Operates AppDrag through an OOMOL-connected account by inspecting live connector schemas and running AppDrag Cloud Backend API functions through the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect AppDrag connector contracts and execute AppDrag Cloud Backend API functions through an existing OOMOL-connected account. It is suited for AppDrag data access and backend function operations where the agent must build payloads from the live action schema. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The execute_function action can call broad AppDrag Cloud Backend APIs and may change or delete AppDrag state. <br>
Mitigation: Inspect the live schema and selected HTTP method before each call; require explicit user approval for create, update, send, post, delete, or remove operations. <br>
Risk: The skill requires an OOMOL-connected AppDrag account and therefore can act with the connected account's permissions. <br>
Mitigation: Install only for accounts intended for agent use and keep AppDrag credentials managed through OOMOL rather than exposing raw API tokens to the agent. <br>


## Reference(s): <br>
- [ClawHub AppDrag skill page](https://clawhub.ai/oomol/oo-appdrag) <br>
- [AppDrag homepage](https://appdrag.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [execute_function action reference](actions/execute_function.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown with inline bash code blocks and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before action execution; command responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
