## Description: <br>
Canny (canny.io). Use this skill for ANY Canny request - reading, creating, and updating data. Whenever a task involves Canny, use this skill instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and support teams use this skill to let an agent read Canny boards, posts, comments, and users, and to create or update Canny records through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a Canny workspace through OOMOL-managed credentials. <br>
Mitigation: Install only when Canny workspace access through OOMOL is intended, and use the connected account with the minimum appropriate permissions. <br>
Risk: Read actions may expose Canny boards, posts, comments, and user records to the agent. <br>
Mitigation: Review requested reads and avoid running the skill in conversations where Canny workspace data should not be shared with the agent. <br>
Risk: Create and update actions can modify Canny state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create or update actions. <br>


## Reference(s): <br>
- [Canny homepage](https://canny.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Canny skill page](https://clawhub.ai/oomol/oo-canny) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing command payloads; connector responses are JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
