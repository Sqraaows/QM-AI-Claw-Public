# 医保审核输出格式说明

## 一、Excel 问题列表格式

文件名：`医保审核问题列表_YYYYMMDD_HHMMSS.xlsx`

### Sheet1：问题明细表

| 列号 | 字段名 | 数据类型 | 说明 |
|------|--------|---------|------|
| A | 序号 | int | 从1开始递增 |
| B | 病历号 | string | 病历唯一标识 |
| C | 入院日期 | date | YYYY-MM-DD格式 |
| D | 出院日期 | date | YYYY-MM-DD格式 |
| E | 住院天数 | int | 出院日期-入院日期+1 |
| F | 住院总费用 | decimal | 精确到分，单位：元 |
| G | 主诊断 | string | 诊断名称 |
| H | 主诊断ICD-10 | string | 如 J18.901 |
| I | DRGs分组码 | string | 如 BL19（可能为空） |
| J | 手术名称 | string | 如无则填"/" |
| K | 手术编码 | string | 如无则填"/" |
| L | 主诊医师 | string | 医师姓名 |
| M | 问题类型 | string | 如"超适应症用药" |
| N | 医嘱/项目名称 | string | 涉及的具体项目 |
| O | 医嘱类别 | string | 药品/耗材/诊疗项目 |
| P | 开始时间 | datetime | YYYY-MM-DD HH:MM |
| Q | 结束时间 | datetime | YYYY-MM-DD HH:MM |
| R | 频次 | string | 如"每日一次" |
| S | 开嘱医师 | string | 开嘱医生姓名 |
| T | 费用金额 | decimal | 该项目费用，单位：元 |
| U | 医保问题描述 | string | 具体违规内容描述 |
| V | 问题级别 | string | 严重/一般/提示 |
| W | 处理建议 | string | 整改措施建议 |
| X | 审核依据 | string | 对应规则ID和描述 |
| Y | 备注 | string | 补充说明 |

### Sheet2：汇总统计

| 统计项 | 值 |
|--------|---|
| 审核病历数 | |
| 问题总数 | |
| 涉及总金额（元） | |
| 严重问题数 | |
| 一般问题数 | |
| 提示问题数 | |
| 问题类型分布 | （饼图数据） |
| 科室分布 | （柱状图数据） |
| 审核日期 | |
| 审核人 | |

---

## 二、Word 分析报告格式

文件名：`医保审核分析报告_YYYYMMDD_HHMMSS.docx`

### 报告结构

#### 封面
- 标题：医保合规性审核分析报告
- 副标题：XXXX医院 XX年XX月审核
- 日期、密级

#### 第一章 审核基本信息
- 审核时间范围
- 审核范围（科室/病区）
- 审核病历数量
- 审核依据

#### 第二章 总体情况概览
- 问题数量汇总（表格）
- 涉及金额统计（表格）
- 科室分布（表格+柱状图）

#### 第三章 问题分类统计
- 各类型问题数量及占比（表格+饼图）
- 严重问题清单（表格）

#### 第四章 典型案例分析
- 问题最严重的前3-5份病历详细分析
- 每份病历：基本信息 + 问题列表 + 违规分析

#### 第五章 科室问题排名
- 按问题数量排名
- 按涉及金额排名

#### 第六章 整改建议
- 针对各问题类型的整改措施
- 建议优先级排序

#### 第七章 附件
- 附件1：问题明细表（与Excel同步）
- 附件2：审核规则说明

---

## 三、JSON输出格式（机器可读）

```json
{
  "audit_id": "AUD2024010100001",
  "audit_time": "2024-01-01T10:00:00",
  "summary": {
    "total_records": 100,
    "total_issues": 45,
    "total_amount": 123456.78,
    "severe_count": 5,
    "general_count": 20,
    "notice_count": 20
  },
  "records": [
    {
      "record_id": "MR001",
      "admission_date": "2024-01-01",
      "discharge_date": "2024-01-05",
      "total_fee": 12345.67,
      "diagnosis": "肺炎",
      "icd10": "J18.901",
      "drg_code": "ES35",
      "surgery": "无",
      "physician": "张三",
      "issues": [
        {
          "issue_id": "I001",
          "rule_id": "R001",
          "type": "超适应症用药",
          "order_name": "XX药品",
          "start_time": "2024-01-02 08:00",
          "end_time": "2024-01-04 08:00",
          "frequency": "每日一次",
          "prescriber": "李四",
          "amount": 123.45,
          "description": "该药品限定支付范围为XX，本病例诊断不符",
          "severity": "严重",
          "suggestion": "建议更换为同类非限制用药"
        }
      ]
    }
  ],
  "statistics": {
    "by_type": { "超适应症用药": 10, "重复收费": 5 },
    "by_department": { "内科": 15, "外科": 30 }
  }
}
```
