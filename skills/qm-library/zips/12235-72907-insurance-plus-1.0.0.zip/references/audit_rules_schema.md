# 医保审核规则 JSON Schema

## 总体结构

```json
{
  "version": "1.0",
  "updated_at": "2024-01-01",
  "rules": [
    {
      "rule_id": "R001",
      "category": "drug",
      "type": "适应症不符",
      "description": "药品使用超出医保限定支付范围",
      "severity": "严重",
      "conditions": { ... },
      "examples": [ ... ],
      "suggestion": "..."
    }
  ]
}
```

## 规则字段说明

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| rule_id | string | ✅ | 规则唯一标识，如 R001 |
| category | string | ✅ | 问题类别：drug/耗材/诊疗/drg/icd/综合 |
| type | string | ✅ | 问题类型名称 |
| description | string | ✅ | 问题描述 |
| severity | string | ✅ | 严重程度：严重/一般/提示 |
| conditions | object | ✅ | 匹配条件（见下方） |
| examples | array | ❌ | 典型案例 |
| suggestion | string | ✅ | 处理建议 |
| legal_ref | string | ❌ | 法规依据 |
| penalty | string | ❌ | 处罚标准 |

## conditions 条件字段

```json
{
  "conditions": {
    "logic": "AND | OR",
    "items": [
      {
        "field": "医嘱名称 | 诊断 | ICD编码 | 费用 | 数量 | 频次",
        "operator": "equals | contains | startsWith | endsWith | gt | lt | between | in | regex",
        "value": "具体值或列表",
        "negate": false
      }
    ]
  }
}
```

## 示例规则

### 示例1：超适应症用药
```json
{
  "rule_id": "R001",
  "category": "drug",
  "type": "超适应症用药",
  "description": "药品使用超出药品说明书的适应症范围，且不属于医保限定支付范围",
  "severity": "严重",
  "conditions": {
    "logic": "AND",
    "items": [
      {
        "field": "诊断",
        "operator": "not_contains_any",
        "value": ["适应症列表"],
        "negate": false
      },
      {
        "field": "药品类别",
        "operator": "equals",
        "value": "限制用药",
        "negate": false
      }
    ]
  },
  "suggestion": "请补充与适应症相符的诊断依据，或更换同类非限制用药",
  "legal_ref": "《基本医疗保险用药管理暂行办法》第九条"
}
```

### 示例2：重复收费
```json
{
  "rule_id": "R002",
  "category": "综合",
  "type": "重复收费",
  "description": "同一诊疗项目在同一次就诊中重复计费",
  "severity": "一般",
  "conditions": {
    "logic": "AND",
    "items": [
      {
        "field": "医嘱名称",
        "operator": "count_duplicates",
        "value": 1,
        "negate": false
      }
    ]
  },
  "suggestion": "删除重复收费项目，保留合理计费"
}
```

### 示例3：DRGs分组错误
```json
{
  "rule_id": "R003",
  "category": "drg",
  "type": "DRGs入组错误",
  "description": "主诊断与手术操作组合不符合DRGs分组规则",
  "severity": "严重",
  "conditions": {
    "logic": "OR",
    "items": [
      {
        "field": "主诊断",
        "operator": "drg_mismatch",
        "value": ["手术操作列表"],
        "negate": false
      }
    ]
  },
  "suggestion": "核对主诊断和手术操作编码，确保DRGs入组正确",
  "penalty": "DRGs权重调整/拒付"
}
```
