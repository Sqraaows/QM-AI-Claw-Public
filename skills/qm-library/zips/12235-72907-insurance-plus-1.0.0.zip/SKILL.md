---
name: medical-insurance-audit
description: |
  医保审核规则技能。当用户需要以下任一操作时触发：
  (1) 医保审核、医保合规检查、医疗费用审核
  (2) 上传医嘱/病历进行医保合规分析
  (3) 生成医保审核问题列表Excel或分析报告Word
  (4) 获取医保目录（药品、耗材、诊疗项目）
  (5) 医保审核规则创建与管理
  (6) DRGs/ICD编码合规审核
  支持上传PDF、Word、图片等附件格式，输出标准化Excel问题列表和Word分析报告。
---

# 医保审核规则技能

## 技能概述

本技能对医嘱和病历进行医保合规性审核，对接医保目录和审核规则，输出标准化的问题列表和分析报告。

## 核心工作流程（5步）

### Step 1 — 获取医保管理目录

使用联网搜索获取最新医保目录数据：

```
# 搜索国家医保药品目录
node '<SCRIPT_PATH>/scripts/prosearch.cjs' --keyword=国家医保药品目录2024 --freshness=1y

# 搜索医保耗材目录
node '<SCRIPT_PATH>/scripts/prosearch.cjs' --keyword=医保医用耗材目录最新 --freshness=1y

# 搜索诊疗项目目录
node '<SCRIPT_PATH>/scripts/prosearch.cjs' --keyword=基本医疗保险诊疗项目目录 --freshness=1y

# 搜索DRGs分组方案
node '<Sclaw_PATH>/scripts/prosearch.cjs' --keyword=DRGs分组方案2024 医保 --freshness=1y
```

目录数据存入 `references/medical_catalog.json`，包含：
- 药品目录：药品名称、编码（国家医保药品编码）、类别、甲乙类、限定支付范围
- 耗材目录：耗材名称、编码、材质、规格
- 诊疗项目目录：项目名称、项目编码、收费等级

### Step 2 — 获取/构建审核规则库

使用联网搜索获取权威医保审核规则：

```
# 医保审核规则
node '<SCRIPT_PATH>/scripts/prosearch.cjs' --keyword=医保审核规则 违规示例 --freshness=1y
node '<SCRIPT_PATH>/scripts/prosearch.cjs' --keyword=医院医保违规行为 审核要点 --freshness=1y
node '<SCRIPT_PATH>/scripts/prosearch.cjs' --keyword=DRGs付费审核规则 违规案例 --freshness=1y
```

将规则整理为标准化 JSON 格式存入 `references/audit_rules.json`，结构见 `references/audit_rules_schema.md`。

### Step 3 — 解析上传的医嘱/病历

支持以下格式的附件上传：

| 格式 | 解析方式 |
|------|---------|
| PDF | 使用 pdfplumber 或 PyMuPDF 提取文本 |
| Word (.docx) | 使用 python-docx 读取正文 |
| 图片 (jpg/png) | 使用 OCR（pytesseract）识别文字 |

上传后，提取以下结构化信息：
- 病历号、入院日期、出院日期
- 诊断（主诊断、并发症诊断）
- ICD-10 编码
- 手术/操作名称及编码
- 住院总费用
- 医嘱明细（药品/耗材/诊疗项目名称、剂量、频次、开嘱时间、开嘱医师）
- DRGs分组码（如有）
- 主管医师

解析脚本：`scripts/parse_medical_record.py`

### Step 4 — 规则匹配与问题分析

将解析的结构化数据与审核规则库逐一匹配，检测以下问题类型：

| 问题类型 | 说明 |
|---------|------|
| 超适应症用药 | 药品用于非医保限定支付范围 |
| 重复收费 | 同一项目多次计费 |
| 分解收费 | 应合并的项目分开收费 |
| 超限用药 | 超剂量、超疗程、超用量 |
| 耗材滥用 | 非必要耗材或超规格使用 |
| 不合理诊疗 | 与诊断无关的检查/治疗 |
| DRGs分组错误 | 主诊断与手术操作组合不符 |
| ICD编码错误 | 编码与实际诊断不匹配 |
| 过度医疗 | 住院天数与病情不符 |
| 挂床住院 | 无实际诊疗行为的住院 |

规则匹配脚本：`scripts/audit_engine.py`

### Step 5 — 生成标准化输出

#### 5.1 问题列表Excel（`scripts/generate_excel.py`）

输出字段：

| 字段 | 说明 |
|------|------|
| 病历号 | 病历唯一标识 |
| 入院日期 | 格式：YYYY-MM-DD |
| 出院日期 | 格式：YYYY-MM-DD |
| 住院总费用 | 单位：元 |
| 诊断 | 主诊断名称 |
| DRGs分组码 | DRG组编号（如有） |
| ICD编码 | 主诊断ICD-10 |
| 手术名称 | 如无则填空 |
| 医师 | 主诊医师姓名 |
| 问题类型 | 违规类别 |
| 医嘱名称 | 涉及的具体项目 |
| 医嘱开始时间 | 格式：YYYY-MM-DD HH:MM |
| 医嘱结束时间 | 格式：YYYY-MM-DD HH:MM |
| 频次 | 用药/执行频次 |
| 开嘱医师 | 开嘱医生姓名 |
| 医保问题描述 | 具体违规内容 |
| 问题级别 | 严重/一般/提示 |
| 处理建议 | 整改措施建议 |

#### 5.2 Word分析报告（`scripts/generate_word.py`）

报告结构：
1. 审核基本信息（审核时间、审核范围）
2. 总体情况概览（问题数量、涉及金额、科室分布）
3. 问题分类统计
4. 典型案例分析（问题最严重的前3份病历详细分析）
5. 科室问题排名
6. 整改建议
7. 附件：问题明细表

---

## 参考文件

- `references/audit_rules_schema.md` — 审核规则JSON Schema
- `references/output_schema.md` — Excel/Word输出格式说明
- `references/problem_types.md` — 各类问题详细定义与判断逻辑

---

## 脚本说明

| 脚本 | 功能 |
|------|------|
| `scripts/prosearch.cjs` | 联网搜索医保目录和规则（内置，无需安装） |
| `scripts/parse_medical_record.py` | 解析PDF/Word/图片医嘱病历 |
| `scripts/audit_engine.py` | 规则匹配与问题检测 |
| `scripts/generate_excel.py` | 生成问题列表Excel |
| `scripts/generate_word.py` | 生成Word分析报告 |

---

## 依赖说明

首次使用需安装依赖：
```powershell
pip install pdfplumber python-docx pytesseract openpyxl python-docx Pillow
```

PDF OCR（图片文字识别）需要安装 Tesseract：
```powershell
# Windows: 使用 choco 安装
choco install tesseract

# 或下载安装包：https://github.com/UB-Mannheim/tesseract/wiki
```

---

## 使用示例

**完整审核流程：**

1. 用户上传病历附件（PDF/Word/图片）
2. 技能自动解析结构化数据
3. 调用审核规则库匹配问题
4. 输出 Excel 问题列表 + Word 分析报告

**命令式触发：**
- "审核这份病历" → 上传附件 → 执行审核
- "生成医保审核报告" → 输出Excel+Word
- "更新医保目录" → 联网获取最新目录
- "添加新审核规则" → 用户提供规则文本 → 转换为JSON规则

---

## 注意事项

1. 医保目录和规则需定期联网更新（建议每月更新一次）
2. ICD编码优先使用国家标准（GB/T 14396/2016）
3. 问题级别定义：严重（涉及骗保风险）→ 一般（违规但不构成骗保）→ 提示（需关注）
4. 生成的文件保存到工作区 `outputs/` 子目录
5. 图片OCR识别准确率约85%，PDF结构化提取约95%，请人工复核关键信息
