# -*- coding: utf-8 -*-
"""
医嘱/病历解析脚本
支持 PDF、Word(.docx)、图片(jpg/png) 格式
"""

import os
import sys
import json
import argparse
from datetime import datetime

# PDF 解析
def parse_pdf(file_path):
    """使用 pdfplumber 解析 PDF 文本"""
    try:
        import pdfplumber
    except ImportError:
        return {"error": "请先安装 pdfplumber: pip install pdfplumber"}
    
    text = ""
    tables = []
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text += page_text + "\n"
                page_tables = page.extract_tables()
                tables.extend(page_tables)
    except Exception as e:
        return {"error": f"PDF解析失败: {str(e)}"}
    
    return {
        "text": text,
        "tables": tables,
        "page_count": len(tables)
    }

# Word 解析
def parse_word(file_path):
    """使用 python-docx 解析 Word 文档"""
    try:
        from docx import Document
    except ImportError:
        return {"error": "请先安装 python-docx: pip install python-docx"}
    
    text = ""
    tables = []
    try:
        doc = Document(file_path)
        # 读取段落
        for para in doc.paragraphs:
            text += para.text + "\n"
        # 读取表格
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = [cell.text.strip() for cell in row.cells]
                table_data.append(row_data)
            tables.append(table_data)
    except Exception as e:
        return {"error": f"Word解析失败: {str(e)}"}
    
    return {
        "text": text,
        "tables": tables,
        "table_count": len(tables)
    }

# 图片 OCR
def parse_image(file_path):
    """使用 pytesseract 进行 OCR 文字识别"""
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        return {"error": "请先安装 pytesseract 和 Pillow: pip install pytesseract Pillow"}
    
    try:
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image, lang='chi_sim')
        return {
            "text": text,
            "image_size": image.size,
            "format": image.format
        }
    except Exception as e:
        return {"error": f"OCR识别失败: {str(e)}"}

# 文本结构化提取（核心提取逻辑）
def extract_structured_data(raw_text, tables=None):
    """
    从解析后的文本中提取结构化病历信息
    使用规则+正则表达式匹配
    """
    import re
    
    data = {
        "record_id": "",          # 病历号
        "patient_name": "",       # 患者姓名
        "admission_date": "",     # 入院日期
        "discharge_date": "",     # 出院日期
        "total_fee": 0.0,        # 住院总费用
        "main_diagnosis": "",     # 主诊断
        "icd10": "",              # ICD-10编码
        "drg_code": "",           # DRGs分组码
        "surgery_name": "",       # 手术名称
        "surgery_code": "",       # 手术编码
        "physician": "",          # 主诊医师
        "department": "",        # 科室
        "orders": [],             # 医嘱列表
        "diagnoses": [],          # 诊断列表（含并发症）
        "raw_text": raw_text,
        "extraction_status": "partial"
    }
    
    lines = raw_text.split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # 病历号
        m = re.search(r'病历号[：:]\s*(\S+)', line)
        if m:
            data["record_id"] = m.group(1)
        
        # 入院日期
        m = re.search(r'入院日期[：:]\s*(\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?)', line)
        if m:
            date_str = m.group(1).replace('年', '-').replace('月', '-').replace('日', '')
            data["admission_date"] = date_str
        
        # 出院日期
        m = re.search(r'出院日期[：:]\s*(\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?)', line)
        if m:
            date_str = m.group(1).replace('年', '-').replace('月', '-').replace('日', '')
            data["discharge_date"] = date_str
        
        # 住院总费用
        m = re.search(r'住院总费用[：:]\s*[￥¥]?\s*([\d,]+\.?\d*)', line)
        if m:
            data["total_fee"] = float(m.group(1).replace(',', ''))
        
        # 主诊断
        m = re.search(r'(?:主诊断|主要诊断|出院诊断)[：:]\s*(.+?)(?:\s{2,}|\n|$)', line)
        if m:
            data["main_diagnosis"] = m.group(1).strip()
        
        # ICD-10
        m = re.search(r'(?:ICD[_-]?10|国际疾病分类)[：:]\s*([A-Z]\d{2}\.?\d*)', line, re.IGNORECASE)
        if m:
            data["icd10"] = m.group(1).upper()
        
        # DRGs
        m = re.search(r'(?:DRG[sd]?|分组码)[：:]\s*([A-Z]{1,2}\d{2,3})', line, re.IGNORECASE)
        if m:
            data["drg_code"] = m.group(1).upper()
        
        # 手术名称
        m = re.search(r'(?:手术名称|手术操作)[：:]\s*(.+?)(?:\s{2,}|\n|$)', line)
        if m:
            data["surgery_name"] = m.group(1).strip()
        
        # 主诊医师
        m = re.search(r'(?:主诊医师|主治医师|主管医师|负责医师)[：:]\s*(\S{2,4})', line)
        if m:
            data["physician"] = m.group(1)
        
        # 科室
        m = re.search(r'(?:科室|病区|所属科室)[：:]\s*(\S+)', line)
        if m:
            data["department"] = m.group(1)
        
        # 诊断列表（支持多行）
        m = re.search(r'其他诊断[：:]\s*(.+)', line)
        if m:
            other_diagnoses = re.findall(r'([^，,；;、\n]{4,})', m.group(1))
            data["diagnoses"].extend(other_diagnoses)
    
    # 从表格中提取医嘱
    if tables:
        for table in tables:
            for row in table:
                row_text = ' '.join(row)
                if any(kw in row_text for kw in ['药品', '医嘱', '项目', '收费']):
                    # 尝试从表格行提取医嘱信息
                    order = parse_order_row(row)
                    if order:
                        data["orders"].append(order)
    
    # 简单判断提取完整性
    filled_fields = sum([
        bool(data["record_id"]),
        bool(data["admission_date"]),
        bool(data["discharge_date"]),
        bool(data["main_diagnosis"]),
        bool(data["physician"])
    ])
    data["extraction_status"] = "complete" if filled_fields >= 4 else "partial"
    
    return data

def parse_order_row(row):
    """从表格行解析医嘱信息"""
    import re
    if len(row) < 3:
        return None
    
    row_text = ' '.join([str(c) for c in row])
    
    # 检测是否为医嘱行（包含常见关键词）
    keywords = ['注射', '口服', '片', '粒', '瓶', '支', '袋', '次', '每日', 'tid', 'bid', 'qd']
    if not any(kw in row_text for kw in keywords):
        return None
    
    order = {
        "name": row[0] if len(row) > 0 else "",
        "specification": row[1] if len(row) > 1 else "",
        "frequency": row[2] if len(row) > 2 else "",
        "prescriber": row[3] if len(row) > 3 else "",
        "start_time": row[4] if len(row) > 4 else "",
        "end_time": row[5] if len(row) > 5 else "",
        "amount": 0.0,
        "category": "药品" if any(kw in row_text for kw in ['片', '粒', '瓶', '支', '袋', '注射', '口服']) else "诊疗"
    }
    
    # 尝试提取金额
    amount_match = re.search(r'([\d,]+\.?\d*)\s*[元]?', row_text)
    if amount_match:
        order["amount"] = float(amount_match.group(1).replace(',', ''))
    
    return order

def main():
    parser = argparse.ArgumentParser(description='医嘱/病历解析工具')
    parser.add_argument('--input', '-i', required=True, help='输入文件路径')
    parser.add_argument('--output', '-o', default=None, help='输出JSON文件路径')
    parser.add_argument('--format', '-f', choices=['pdf', 'docx', 'image', 'auto'], 
                        default='auto', help='输入文件格式')
    
    args = parser.parse_args()
    file_path = args.input
    
    if not os.path.exists(file_path):
        print(json.dumps({"error": f"文件不存在: {file_path}"}))
        sys.exit(1)
    
    ext = os.path.splitext(file_path)[1].lower()
    format_map = {'.pdf': 'pdf', '.docx': 'docx', '.doc': 'docx', 
                  '.jpg': 'image', '.jpeg': 'image', '.png': 'image'}
    
    if args.format == 'auto':
        fmt = format_map.get(ext, 'image')
    else:
        fmt = args.format
    
    # 解析文件
    if fmt == 'pdf':
        raw_data = parse_pdf(file_path)
    elif fmt == 'docx':
        raw_data = parse_word(file_path)
    elif fmt == 'image':
        raw_data = parse_image(file_path)
    else:
        print(json.dumps({"error": f"不支持的格式: {ext}"}))
        sys.exit(1)
    
    if "error" in raw_data:
        print(json.dumps(raw_data, ensure_ascii=False))
        sys.exit(1)
    
    # 结构化提取
    structured = extract_structured_data(raw_data.get("text", ""), raw_data.get("tables"))
    
    result = {
        "file": file_path,
        "format": fmt,
        "parsed_at": datetime.now().isoformat(),
        "structured_data": structured
    }
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(json.dumps({"success": True, "output": args.output}))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
