# -*- coding: utf-8 -*-
"""
生成医保审核问题列表Excel
"""

import os
import sys
import json
import argparse
from datetime import datetime
from typing import List, Dict, Any

def create_excel_audit_report(audit_result: Dict, record_details: List[Dict] = None, output_path: str = None) -> str:
    """
    生成医保审核Excel报告
    
    Args:
        audit_result: 审核引擎输出的结果
        record_details: 原始病历详情列表
        output_path: 输出文件路径
    
    Returns:
        生成的文件路径
    """
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        print(json.dumps({"error": "请先安装 openpyxl: pip install openpyxl"}))
        sys.exit(1)
    
    if output_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(os.path.expanduser("~"), "Desktop", f"医保审核问题列表_{timestamp}.xlsx")
    
    wb = openpyxl.Workbook()
    
    # Sheet1: 问题明细表
    ws1 = wb.active
    ws1.title = "问题明细表"
    
    # 表头样式
    header_font = Font(name='微软雅黑', bold=True, size=11, color='FFFFFF')
    header_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
    header_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
    
    # 严重问题红色，一般问题橙色，提示问题蓝色
    severe_fill = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')  # 红色警告
    general_fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')  # 绿色
    notice_fill = PatternFill(start_color='BDD7EE', end_color='BDD7EE', fill_type='solid')  # 蓝色
    
    # 定义列
    columns = [
        "序号", "病历号", "入院日期", "出院日期", "住院天数", "住院总费用",
        "主诊断", "ICD-10编码", "DRGs分组码", "手术名称", "手术编码",
        "主诊医师", "问题类型", "医嘱/项目名称", "医嘱类别",
        "开始时间", "结束时间", "频次", "开嘱医师", "费用金额",
        "医保问题描述", "问题级别", "处理建议", "审核依据", "备注"
    ]
    
    # 写入表头
    for col_idx, col_name in enumerate(columns, 1):
        cell = ws1.cell(row=1, column=col_idx, value=col_name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
    
    # 构建记录详情映射
    record_map = {}
    if record_details:
        for rec in record_details:
            record_map[rec.get('record_id', '')] = rec
    
    # 写入数据
    row_idx = 2
    serial = 1
    
    record_issues = audit_result.get('record_issues', {})
    all_issues = audit_result.get('all_issues', [])
    
    # 构建医嘱维度的明细
    for record_id, issues in record_issues.items():
        record = record_map.get(record_id, {})
        
        # 计算住院天数
        admission = record.get('admission_date', '')
        discharge = record.get('discharge_date', '')
        los = ""
        if admission and discharge:
            try:
                d1 = datetime.strptime(admission[:10], '%Y-%m-%d')
                d2 = datetime.strptime(discharge[:10], '%Y-%m-%d')
                los = (d2 - d1).days + 1
            except:
                los = ""
        
        for issue in issues:
            severity = issue.get('severity', '一般')
            
            # 选择行背景色
            if severity == '严重':
                row_fill = severe_fill
            elif severity == '一般':
                row_fill = general_fill
            else:
                row_fill = notice_fill
            
            row_data = [
                serial,                           # 序号
                record_id,                        # 病历号
                admission[:10] if admission else '',  # 入院日期
                discharge[:10] if discharge else '',  # 出院日期
                los,                              # 住院天数
                record.get('total_fee', 0),      # 住院总费用
                record.get('main_diagnosis', ''), # 主诊断
                record.get('icd10', ''),         # ICD-10
                record.get('drg_code', ''),       # DRGs
                record.get('surgery_name', ''),   # 手术名称
                record.get('surgery_code', ''),   # 手术编码
                record.get('physician', ''),     # 主诊医师
                issue.get('type', ''),           # 问题类型
                '',                               # 医嘱名称（需从医嘱列表匹配）
                '',                               # 医嘱类别
                '',                               # 开始时间
                '',                               # 结束时间
                '',                               # 频次
                '',                               # 开嘱医师
                0,                                # 费用金额
                issue.get('description', ''),    # 医保问题描述
                severity,                         # 问题级别
                issue.get('suggestion', ''),     # 处理建议
                issue.get('rule_id', ''),        # 审核依据
                ''                                # 备注
            ]
            
            for col_idx, value in enumerate(row_data, 1):
                cell = ws1.cell(row=row_idx, column=col_idx, value=value)
                cell.fill = row_fill
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                
                # 费用列右对齐
                if col_idx in [6, 20]:
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal='right', vertical='center')
            
            serial += 1
            row_idx += 1
    
    # 自动调整列宽
    for col_idx in range(1, len(columns) + 1):
        ws1.column_dimensions[get_column_letter(col_idx)].width = 15
    
    # 设置行高
    ws1.row_dimensions[1].height = 30
    for r in range(2, row_idx):
        ws1.row_dimensions[r].height = 35
    
    # Sheet2: 汇总统计
    ws2 = wb.create_sheet(title="汇总统计")
    
    summary = audit_result.get('summary', {})
    
    # 统计信息
    stats_data = [
        ["医保审核汇总统计", ""],
        ["", ""],
        ["统计项目", "数值"],
        ["审核病历数", summary.get('total_records', 0)],
        ["问题总数", summary.get('total_issues', 0)],
        ["严重问题数", summary.get('by_severity', {}).get('严重', 0)],
        ["一般问题数", summary.get('by_severity', {}).get('一般', 0)],
        ["提示问题数", summary.get('by_severity', {}).get('提示', 0)],
        ["审核时间", audit_result.get('audit_time', '')[:19]],
    ]
    
    for row_idx, row_data in enumerate(stats_data, 1):
        for col_idx, value in enumerate(row_data, 1):
            cell = ws2.cell(row=row_idx, column=col_idx, value=value)
            if row_idx == 1:
                cell.font = Font(name='微软雅黑', bold=True, size=14)
            elif row_idx == 3:
                cell.font = Font(name='微软雅黑', bold=True)
                cell.fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
            cell.alignment = Alignment(horizontal='left', vertical='center')
    
    # 问题类型分布
    start_row = len(stats_data) + 2
    ws2.cell(row=start_row, column=1, value="问题类型分布").font = Font(name='微软雅黑', bold=True)
    ws2.cell(row=start_row + 1, column=1, value="问题类型").font = Font(bold=True)
    ws2.cell(row=start_row + 1, column=2, value="数量").font = Font(bold=True)
    
    by_type = summary.get('by_type', {})
    for i, (issue_type, count) in enumerate(sorted(by_type.items(), key=lambda x: x[1], reverse=True)):
        ws2.cell(row=start_row + 2 + i, column=1, value=issue_type)
        ws2.cell(row=start_row + 2 + i, column=2, value=count)
    
    # 调整列宽
    ws2.column_dimensions['A'].width = 20
    ws2.column_dimensions['B'].width = 15
    
    # 保存
    wb.save(output_path)
    return output_path

def main():
    parser = argparse.ArgumentParser(description='生成医保审核Excel报告')
    parser.add_argument('--input', '-i', required=True, help='审核结果JSON文件')
    parser.add_argument('--records', '-r', default=None, help='原始病历数据JSON文件（可选）')
    parser.add_argument('--output', '-o', default=None, help='输出Excel文件路径')
    
    args = parser.parse_args()
    
    # 加载审核结果
    with open(args.input, 'r', encoding='utf-8') as f:
        audit_result = json.load(f)
    
    # 加载原始病历（可选）
    record_details = None
    if args.records and os.path.exists(args.records):
        with open(args.records, 'r', encoding='utf-8') as f:
            record_details = json.load(f)
            if isinstance(record_details, dict):
                record_details = [record_details]
    
    # 生成Excel
    output_path = create_excel_audit_report(audit_result, record_details, args.output)
    print(json.dumps({"success": True, "output": output_path}))

if __name__ == "__main__":
    main()
