# -*- coding: utf-8 -*-
"""
生成医保审核分析报告 Word 文档
"""

import os
import sys
import json
import argparse
from datetime import datetime
from typing import List, Dict, Any

def create_word_audit_report(audit_result: Dict, record_details: List[Dict] = None, output_path: str = None) -> str:
    """
    生成医保审核 Word 分析报告
    
    Args:
        audit_result: 审核引擎输出结果
        record_details: 原始病历详情
        output_path: 输出文件路径
    
    Returns:
        生成的文件路径
    """
    try:
        from docx import Document
        from docx.shared import Pt, Cm, RGBColor, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.table import WD_TABLE_ALIGNMENT
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
    except ImportError:
        print(json.dumps({"error": "请先安装 python-docx: pip install python-docx"}))
        sys.exit(1)
    
    if output_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(os.path.expanduser("~"), "Desktop", f"医保审核分析报告_{timestamp}.docx")
    
    doc = Document()
    
    # 设置文档默认字体（微软雅黑）
    doc.styles['Normal'].font.name = '微软雅黑'
    doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    
    # ========== 封面 ==========
    # 添加空行撑起封面
    for _ in range(5):
        doc.add_paragraph()
    
    # 标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('医保合规性审核分析报告')
    run.font.size = Pt(28)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x2F, 0x54, 0x96)
    
    # 副标题
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run('Medical Insurance Compliance Audit Report')
    run.font.size = Pt(14)
    run.font.color.rgb = RGBColor(0x70, 0x70, 0x70)
    
    for _ in range(3):
        doc.add_paragraph()
    
    # 报告信息
    summary = audit_result.get('summary', {})
    info_para = doc.add_paragraph()
    info_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = info_para.add_run(f"审核日期：{datetime.now().strftime('%Y年%m月%d日')}\n")
    run.font.size = Pt(12)
    run = info_para.add_run(f"审核病历数：{summary.get('total_records', 0)} 份\n")
    run.font.size = Pt(12)
    run = info_para.add_run(f"问题总数：{summary.get('total_issues', 0)} 项")
    run.font.size = Pt(12)
    
    # 分页
    doc.add_page_break()
    
    # ========== 第一章 审核基本信息 ==========
    h1 = doc.add_heading('第一章 审核基本信息', level=1)
    h1.runs[0].font.color.rgb = RGBColor(0x2F, 0x54, 0x96)
    
    table1 = doc.add_table(rows=5, cols=2)
    table1.style = 'Table Grid'
    table1.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    basic_info = [
        ('审核时间', audit_result.get('audit_time', '')[:19] if audit_result.get('audit_time') else datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
        ('审核范围', '全院各科室'),
        ('审核病历数量', f"{summary.get('total_records', 0)} 份"),
        ('问题总数', f"{summary.get('total_issues', 0)} 项"),
        ('审核依据', '国家医保政策、DRGs付费规则、医院医保管理制度')
    ]
    
    for i, (key, value) in enumerate(basic_info):
        table1.rows[i].cells[0].text = key
        table1.rows[i].cells[1].text = str(value)
        table1.rows[i].cells[0].paragraphs[0].runs[0].font.bold = True
    
    # ========== 第二章 总体情况概览 ==========
    doc.add_heading('第二章 总体情况概览', level=1)
    
    # 问题数量统计
    doc.add_heading('2.1 问题数量统计', level=2)
    table2 = doc.add_table(rows=4, cols=2)
    table2.style = 'Table Grid'
    
    severity_stats = summary.get('by_severity', {})
    stats = [
        ('总问题数', f"{summary.get('total_issues', 0)} 项"),
        ('严重问题', f"{severity_stats.get('严重', 0)} 项"),
        ('一般问题', f"{severity_stats.get('一般', 0)} 项"),
        ('提示问题', f"{severity_stats.get('提示', 0)} 项")
    ]
    
    for i, (key, value) in enumerate(stats):
        table2.rows[i].cells[0].text = key
        table2.rows[i].cells[1].text = value
        table2.rows[i].cells[0].paragraphs[0].runs[0].font.bold = True
        # 严重问题标红
        if '严重' in key and severity_stats.get('严重', 0) > 0:
            table2.rows[i].cells[1].paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0x00, 0x00)
    
    # 问题类型分布
    doc.add_heading('2.2 问题类型分布', level=2)
    by_type = summary.get('by_type', {})
    if by_type:
        table3 = doc.add_table(rows=len(by_type) + 1, cols=3)
        table3.style = 'Table Grid'
        
        headers = ['序号', '问题类型', '数量']
        for j, h in enumerate(headers):
            table3.rows[0].cells[j].text = h
            table3.rows[0].cells[j].paragraphs[0].runs[0].font.bold = True
        
        for i, (issue_type, count) in enumerate(sorted(by_type.items(), key=lambda x: x[1], reverse=True), 1):
            table3.rows[i].cells[0].text = str(i)
            table3.rows[i].cells[1].text = issue_type
            table3.rows[i].cells[2].text = str(count)
    else:
        doc.add_paragraph('无问题类型分布数据')
    
    # ========== 第三章 问题分类统计 ==========
    doc.add_heading('第三章 问题分类统计', level=1)
    
    # 按严重程度分类
    doc.add_heading('3.1 按严重程度分类', level=2)
    p = doc.add_paragraph()
    p.add_run('严重问题（').font.color.rgb = RGBColor(0xFF, 0x00, 0x00)
    p.add_run(f"{severity_stats.get('严重', 0)} 项）：").font.color.rgb = RGBColor(0xFF, 0x00, 0x00)
    p.add_run('涉及骗保嫌疑或严重违规，必须立即整改。\n')
    p.add_run('一般问题（').font.color.rgb = RGBColor(0xFF, 0xA5, 0x00)
    p.add_run(f"{severity_stats.get('一般', 0)} 项）：").font.color.rgb = RGBColor(0xFF, 0xA5, 0x00)
    p.add_run('违规但不构成骗保，需限期整改。\n')
    p.add_run('提示问题（').font.color.rgb = RGBColor(0x00, 0x70, 0xC0)
    p.add_run(f"{severity_stats.get('提示', 0)} 项）：").font.color.rgb = RGBColor(0x00, 0x70, 0xC0)
    p.add_run('存在风险苗头，需持续关注。')
    
    # ========== 第四章 典型案例分析 ==========
    doc.add_heading('第四章 典型案例分析', level=1)
    
    record_issues = audit_result.get('record_issues', {})
    
    # 找出问题最多的前3份病历
    sorted_records = sorted(record_issues.items(), key=lambda x: len(x[1]), reverse=True)
    top_records = sorted_records[:3]
    
    if top_records:
        # 构建记录详情映射
        record_map = {}
        if record_details:
            for rec in record_details:
                record_map[rec.get('record_id', '')] = rec
        
        for idx, (record_id, issues) in enumerate(top_records, 1):
            doc.add_heading(f'案例 {idx}：病历号 {record_id}', level=2)
            
            record = record_map.get(record_id, {})
            
            # 基本信息
            p = doc.add_paragraph()
            p.add_run('基本信息：').font.bold = True
            p.add_run(f"入院日期 {record.get('admission_date', '未知')}，出院日期 {record.get('discharge_date', '未知')}，")
            p.add_run(f"住院总费用 {record.get('total_fee', 0):.2f} 元，主诊断 {record.get('main_diagnosis', '未知')}，")
            p.add_run(f"ICD编码 {record.get('icd10', '未知')}，主诊医师 {record.get('physician', '未知')}。")
            
            # 问题列表
            p2 = doc.add_paragraph()
            p2.add_run(f'发现问题 {len(issues)} 项：').font.bold = True
            
            for issue_idx, issue in enumerate(issues, 1):
                severity = issue.get('severity', '一般')
                severity_color = RGBColor(0xFF, 0x00, 0x00) if severity == '严重' else \
                                 RGBColor(0xFF, 0xA5, 0x00) if severity == '一般' else \
                                 RGBColor(0x00, 0x70, 0xC0)
                
                p3 = doc.add_paragraph(style='List Bullet')
                run1 = p3.add_run(f'{issue_idx}. [{severity}] {issue.get("type", "")}：')
                run1.font.bold = True
                run1.font.color.rgb = severity_color
                p3.add_run(issue.get('description', ''))
                
                p4 = doc.add_paragraph(style='List Bullet 2')
                run2 = p4.add_run('处理建议：')
                run2.font.italic = True
                p4.add_run(issue.get('suggestion', ''))
    else:
        doc.add_paragraph('本次审核未发现问题。')
    
    # ========== 第五章 整改建议 ==========
    doc.add_heading('第五章 整改建议', level=1)
    
    suggestions = [
        ('严重问题整改', '对涉及骗保嫌疑的严重问题，应立即组织核查，一经核实须在3个工作日内向医保管理部门报告，并根据相关规定接受处理。同时对相关责任科室和个人进行问责。'),
        ('一般问题整改', '对违规问题，应在5个工作日内完成整改，相关科室提交整改报告。医保管理部门应跟踪整改进度，纳入科室绩效考核。'),
        ('规范诊疗行为', '加强临床科室医保政策培训，确保医务人员熟悉医保药品限定支付范围、诊疗项目收费标准等规定，从源头减少违规行为。'),
        ('完善信息系统', '建议在His系统中嵌入医保审核规则，对超适应症用药、重复收费等常见问题进行事前提醒，从系统层面减少违规。'),
        ('定期审核机制', '建议每月开展一次医保合规性审核，对问题高发科室进行重点监控，建立问题台账并跟踪整改落实情况。')
    ]
    
    for i, (title_text, content) in enumerate(suggestions, 1):
        p = doc.add_paragraph()
        run = p.add_run(f'{i}. {title_text}：')
        run.font.bold = True
        run.font.size = Pt(12)
        p.add_run(content)
    
    # ========== 第六章 附件 ==========
    doc.add_heading('第六章 附件', level=1)
    doc.add_paragraph('附件1：医保审核问题明细表（详见Excel文件）')
    doc.add_paragraph('附件2：审核规则说明')
    
    # 规则说明
    doc.add_paragraph()
    p = doc.add_paragraph()
    p.add_run('本报告依据以下审核规则生成：').font.bold = True
    
    rules_desc = [
        'R001-超适应症用药：药品使用超出医保限定支付范围',
        'R002-重复收费：同一诊疗项目重复计费',
        'R003-超剂量用药：用药剂量超过说明书最大剂量',
        'R004-超疗程用药：用药天数超过标准疗程',
        'R005-分解收费：应合并的项目分开计费',
        'R006-DRGs入组异常：主诊断与手术操作组合导致入组错误',
        'R007-ICD编码错误：编码与诊断名称不符',
        'R008-无医嘱执行记录：计费项目无对应执行记录',
        'R009-过度医疗：住院天数与病情严重程度不符',
        'R010-挂床住院：连续3天以上无医嘱执行记录'
    ]
    
    for rule in rules_desc:
        doc.add_paragraph(rule, style='List Bullet')
    
    # 页脚
    doc.add_paragraph()
    footer = doc.add_paragraph()
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = footer.add_run(f'报告生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x80, 0x80, 0x80)
    
    # 保存
    doc.save(output_path)
    return output_path

def main():
    parser = argparse.ArgumentParser(description='生成医保审核Word报告')
    parser.add_argument('--input', '-i', required=True, help='审核结果JSON文件')
    parser.add_argument('--records', '-r', default=None, help='原始病历数据JSON文件（可选）')
    parser.add_argument('--output', '-o', default=None, help='输出Word文件路径')
    
    args = parser.parse_args()
    
    # 加载审核结果
    with open(args.input, 'r', encoding='utf-8') as f:
        audit_result = json.load(f)
    
    # 加载原始病历（可选）
    record_details = None
    if args.records and os.path.exists(args.records):
        with open(args.records, 'r', encoding='utf-8') as f:
            record_details = json.load(f)
            if isinstance(record_details, dict):
                record_details = [record_details]
    
    # 生成Word
    output_path = create_word_audit_report(audit_result, record_details, args.output)
    print(json.dumps({"success": True, "output": output_path}))

if __name__ == "__main__":
    main()
