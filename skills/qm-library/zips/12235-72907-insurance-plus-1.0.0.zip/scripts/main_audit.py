# -*- coding: utf-8 -*-
"""
医保审核主流程脚本
串联解析→审核→输出全流程
"""

import os
import sys
import json
import argparse
from datetime import datetime
from typing import List, Dict, Any

# 导入同目录下的模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from parse_medical_record import parse_pdf, parse_word, parse_image, extract_structured_data
from audit_engine import AuditEngine
from generate_excel import create_excel_audit_report
from generate_word import create_word_audit_report

def get_file_type(file_path: str) -> str:
    """根据文件扩展名判断类型"""
    ext = os.path.splitext(file_path)[1].lower()
    type_map = {
        '.pdf': 'pdf',
        '.docx': 'docx',
        '.doc': 'docx',
        '.jpg': 'image',
        '.jpeg': 'image',
        '.png': 'image'
    }
    return type_map.get(ext, 'image')

def parse_file(file_path: str) -> Dict:
    """解析单个病历文件"""
    file_type = get_file_type(file_path)
    
    if file_type == 'pdf':
        raw_data = parse_pdf(file_path)
    elif file_type == 'docx':
        raw_data = parse_word(file_path)
    else:
        raw_data = parse_image(file_path)
    
    if "error" in raw_data:
        return {"error": raw_data["error"], "file": file_path}
    
    structured = extract_structured_data(raw_data.get("text", ""), raw_data.get("tables"))
    return {
        "file": file_path,
        "file_type": file_type,
        "raw_text": raw_data.get("text", "")[:500],  # 保留前500字用于复核
        "structured_data": structured
    }

def main():
    parser = argparse.ArgumentParser(description='医保审核主流程')
    parser.add_argument('--input-dir', '-i', required=True, help='病历文件所在目录')
    parser.add_argument('--rules', '-r', default=None, help='审核规则JSON文件')
    parser.add_argument('--catalog', '-c', default=None, help='医保目录JSON文件')
    parser.add_argument('--output-dir', '-o', default=None, help='输出目录')
    parser.add_argument('--skip-parse', action='store_true', help='跳过解析步骤（已有结构化数据）')
    
    args = parser.parse_args()
    
    # 设置输出目录
    output_dir = args.output_dir
    if output_dir is None:
        output_dir = os.path.join(os.path.expanduser("~"), "Desktop", "医保审核报告")
    os.makedirs(output_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 确定规则文件路径
    skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if args.rules and os.path.exists(args.rules):
        rules_file = args.rules
    else:
        rules_file = os.path.join(skill_dir, "references", "audit_rules.json")
    
    # 确定目录文件路径
    if args.catalog and os.path.exists(args.catalog):
        catalog_file = args.catalog
    else:
        catalog_file = os.path.join(skill_dir, "references", "medical_catalog.json")
    
    print(f"规则文件: {rules_file}")
    print(f"目录文件: {catalog_file}")
    
    # ========== Step 1: 解析病历文件 ==========
    print("\n=== Step 1: 解析病历文件 ===")
    
    input_dir = args.input_dir
    if not os.path.exists(input_dir):
        print(json.dumps({"error": f"输入目录不存在: {input_dir}"}))
        sys.exit(1)
    
    # 获取所有支持的文件
    supported_exts = ['.pdf', '.docx', '.doc', '.jpg', '.jpeg', '.png']
    files = [os.path.join(input_dir, f) for f in os.listdir(input_dir) 
             if os.path.splitext(f)[1].lower() in supported_exts]
    
    if not files:
        print(json.dumps({"error": f"目录中未找到病历文件，支持格式: {', '.join(supported_exts)}"}))
        sys.exit(1)
    
    print(f"找到 {len(files)} 个病历文件")
    
    records = []
    for file_path in files:
        print(f"正在解析: {os.path.basename(file_path)}")
        result = parse_file(file_path)
        if "error" not in result:
            structured = result["structured_data"]
            # 确保有病历号
            if not structured.get("record_id"):
                structured["record_id"] = os.path.splitext(os.path.basename(file_path))[0]
            records.append(structured)
            print(f"  ✓ 病历号: {structured.get('record_id', '未知')}")
        else:
            print(f"  ✗ 解析失败: {result['error']}")
    
    if not records:
        print(json.dumps({"error": "未能成功解析任何病历文件"}))
        sys.exit(1)
    
    print(f"\n成功解析 {len(records)} 份病历")
    
    # ========== Step 2: 执行审核 ==========
    print("\n=== Step 2: 执行医保审核 ===")
    
    engine = AuditEngine(rules_file)
    if not engine.rules:
        engine.add_default_rules()
    
    audit_result = engine.audit_batch(records)
    
    print(f"审核完成，发现问题 {audit_result['summary']['total_issues']} 项")
    for severity, count in audit_result['summary']['by_severity'].items():
        print(f"  - {severity}: {count} 项")
    
    # ========== Step 3: 生成输出文件 ==========
    print("\n=== Step 3: 生成输出文件 ===")
    
    # 保存审核结果JSON
    audit_json_path = os.path.join(output_dir, f"审核结果_{timestamp}.json")
    with open(audit_json_path, 'w', encoding='utf-8') as f:
        json.dump(audit_result, f, ensure_ascii=False, indent=2)
    print(f"✓ 审核结果JSON: {audit_json_path}")
    
    # 生成Excel
    try:
        excel_path = os.path.join(output_dir, f"医保审核问题列表_{timestamp}.xlsx")
        create_excel_audit_report(audit_result, records, excel_path)
        print(f"✓ 问题列表Excel: {excel_path}")
    except Exception as e:
        print(f"✗ Excel生成失败: {str(e)}")
    
    # 生成Word
    try:
        word_path = os.path.join(output_dir, f"医保审核分析报告_{timestamp}.docx")
        create_word_audit_report(audit_result, records, word_path)
        print(f"✓ 分析报告Word: {word_path}")
    except Exception as e:
        print(f"✗ Word生成失败: {str(e)}")
    
    # ========== 完成 ==========
    print(f"\n=== 审核完成 ===")
    print(f"输入病历: {len(records)} 份")
    print(f"发现问题: {audit_result['summary']['total_issues']} 项")
    print(f"输出目录: {output_dir}")
    
    # 输出摘要
    summary = {
        "success": True,
        "total_records": len(records),
        "total_issues": audit_result['summary']['total_issues'],
        "by_severity": audit_result['summary']['by_severity'],
        "by_type": audit_result['summary']['by_type'],
        "output_files": {
            "audit_result": audit_json_path,
            "excel": excel_path if os.path.exists(excel_path) else None,
            "word": word_path if os.path.exists(word_path) else None
        }
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
