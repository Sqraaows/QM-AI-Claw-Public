# -*- coding: utf-8 -*-
"""
医保审核引擎
将结构化病历数据与审核规则库进行匹配，输出问题列表
"""

import os
import sys
import json
import re
import argparse
from datetime import datetime
from typing import List, Dict, Any

class AuditEngine:
    def __init__(self, rules_file=None):
        self.rules = []
        self.issues = []
        if rules_file and os.path.exists(rules_file):
            self.load_rules(rules_file)
    
    def load_rules(self, rules_file):
        """加载审核规则JSON"""
        with open(rules_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            self.rules = data.get('rules', [])
        print(f"已加载 {len(self.rules)} 条审核规则")
    
    def load_rules_from_text(self, text_rules: str) -> int:
        """
        从文本描述中提取并加载审核规则（AI辅助理解）
        用户提供任意格式的规则文本，此函数解析为标准JSON规则
        """
        # 这里可以接入AI模型进行规则提取
        # 简化版：使用关键词匹配提取规则
        lines = text_rules.split('\n')
        rule_id = 1
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # 识别规则关键词
            keywords = {
                'type': re.search(r'(?:问题类型|违规类型)[：:]\s*(.+)', line),
                'severity': re.search(r'(?:严重程度|级别)[：:]\s*(严重|一般|提示)', line),
                'description': re.search(r'(?:描述|说明)[：:]\s*(.+)', line),
                'suggestion': re.search(r'(?:建议|处理)[：:]\s*(.+)', line),
            }
            
            if any(keywords.values()):
                rule = {
                    'rule_id': f'R{rule_id:03d}',
                    'category': 'general',
                    'type': keywords['type'].group(1) if keywords['type'] else '未分类',
                    'description': keywords['description'].group(1) if keywords['description'] else line,
                    'severity': keywords['severity'].group(1) if keywords['severity'] else '一般',
                    'conditions': {
                        'logic': 'AND',
                        'items': [{'field': 'text', 'operator': 'contains', 'value': line, 'negate': False}]
                    },
                    'suggestion': keywords['suggestion'].group(1) if keywords['suggestion'] else '请核实处理'
                }
                self.rules.append(rule)
                rule_id += 1
        
        return len(self.rules)
    
    def add_default_rules(self):
        """加载默认医保审核规则"""
        default_rules = [
            {
                'rule_id': 'R001',
                'category': 'drug',
                'type': '超适应症用药',
                'description': '药品使用超出医保限定支付范围或适应症',
                'severity': '严重',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'order_category', 'operator': 'equals', 'value': '药品', 'negate': False},
                        {'field': 'diagnosis', 'operator': 'contains_restricted', 'value': [], 'negate': True}
                    ]
                },
                'suggestion': '核对药品适应症与临床诊断是否相符，如不符请更换同类药品或补充诊断依据',
                'legal_ref': '《基本医疗保险用药管理暂行办法》'
            },
            {
                'rule_id': 'R002',
                'category': '综合',
                'type': '重复收费',
                'description': '同一诊疗项目在同一次就诊中重复计费',
                'severity': '一般',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'order_name', 'operator': 'count_gte', 'value': 2, 'negate': False}
                    ]
                },
                'suggestion': '删除重复计费项目，保留合理计费',
                'penalty': '重复部分费用拒付'
            },
            {
                'rule_id': 'R003',
                'category': 'drug',
                'type': '超剂量用药',
                'description': '单次剂量或日剂量超过药品说明书最大剂量',
                'severity': '一般',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'dosage', 'operator': 'gt_max', 'value': 0, 'negate': False}
                    ]
                },
                'suggestion': '核对药品剂量，如超剂量使用请补充用药依据'
            },
            {
                'rule_id': 'R004',
                'category': 'drug',
                'type': '超疗程用药',
                'description': '用药天数超过疾病标准疗程',
                'severity': '一般',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'duration_days', 'operator': 'gt_standard', 'value': 0, 'negate': False}
                    ]
                },
                'suggestion': '评估是否需要继续用药，如需超疗程使用请补充说明'
            },
            {
                'rule_id': 'R005',
                'category': '综合',
                'type': '分解收费',
                'description': '应合并收费的项目分开计费',
                'severity': '一般',
                'conditions': {
                    'logic': 'OR',
                    'items': [
                        {'field': 'order_name', 'operator': 'contains_package_sub', 'value': [], 'negate': False}
                    ]
                },
                'suggestion': '按医疗服务价格规范合并计费'
            },
            {
                'rule_id': 'R006',
                'category': 'drg',
                'type': 'DRGs入组异常',
                'description': '主诊断与手术操作组合导致DRGs入组可能异常',
                'severity': '严重',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'drg_weight', 'operator': 'mismatch', 'value': {}, 'negate': False}
                    ]
                },
                'suggestion': '核对主诊断和手术操作编码，确保DRGs入组准确',
                'penalty': 'DRGs权重调整或拒付'
            },
            {
                'rule_id': 'R007',
                'category': 'icd',
                'type': 'ICD编码错误',
                'description': 'ICD编码与实际诊断名称不符',
                'severity': '一般',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'icd_name_match', 'operator': 'lt', 'value': 0.7, 'negate': False}
                    ]
                },
                'suggestion': '核对ICD编码与诊断名称是否匹配'
            },
            {
                'rule_id': 'R008',
                'category': '综合',
                'type': '无医嘱执行记录',
                'description': '计费项目无对应医嘱或执行记录',
                'severity': '严重',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'has_order', 'operator': 'equals', 'value': False, 'negate': False}
                    ]
                },
                'suggestion': '补充医嘱或执行记录，或删除该计费项目',
                'legal_ref': '《医疗保障基金使用监督管理条例》'
            },
            {
                'rule_id': 'R009',
                'category': '综合',
                'type': '过度医疗',
                'description': '住院天数或检查项目与病情严重程度不符',
                'severity': '一般',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'los_ratio', 'operator': 'gt', 'value': 2.0, 'negate': False}
                    ]
                },
                'suggestion': '评估住院必要性，合理控制住院天数'
            },
            {
                'rule_id': 'R010',
                'category': '综合',
                'type': '挂床住院',
                'description': '连续3天以上无医嘱执行记录',
                'severity': '严重',
                'conditions': {
                    'logic': 'AND',
                    'items': [
                        {'field': 'zero_action_days', 'operator': 'gte', 'value': 3, 'negate': False}
                    ]
                },
                'suggestion': '核实患者在院情况，如存在挂床请立即整改',
                'legal_ref': '《医疗保障基金使用监督管理条例》第三十八条'
            }
        ]
        self.rules.extend(default_rules)
        print(f"已加载 {len(default_rules)} 条默认审核规则")
    
    def check_rule(self, rule: Dict, record: Dict) -> List[Dict]:
        """检查单条规则是否命中"""
        issues = []
        conditions = rule.get('conditions', {})
        items = conditions.get('items', [])
        logic = conditions.get('logic', 'AND')
        
        matched = []
        for item in items:
            result = self._check_condition(item, record)
            matched.append(result)
        
        # 根据逻辑运算符判断是否命中
        if logic == 'AND' and all(matched):
            issues.append(self._create_issue(rule, record))
        elif logic == 'OR' and any(matched):
            issues.append(self._create_issue(rule, record))
        
        return issues
    
    def _check_condition(self, condition: Dict, record: Dict) -> bool:
        """检查单个条件是否满足"""
        field = condition.get('field', '')
        operator = condition.get('operator', '')
        value = condition.get('value', '')
        negate = condition.get('negate', False)
        
        # 获取字段值
        field_value = self._get_field_value(record, field)
        
        result = False
        if operator == 'equals':
            result = str(field_value).lower() == str(value).lower()
        elif operator == 'contains':
            result = str(value) in str(field_value)
        elif operator == 'count_gte':
            result = self._count_field_occurrences(record, field) >= int(value)
        elif operator == 'count_duplicates':
            result = self._count_duplicates(record, field) > 0
        elif operator == 'gt':
            result = float(field_value or 0) > float(value)
        elif operator == 'lt':
            result = float(field_value or 0) < float(value)
        elif operator == 'gte':
            result = float(field_value or 0) >= float(value)
        elif operator == 'between':
            result = float(value[0]) <= float(field_value or 0) <= float(value[1])
        elif operator == 'regex':
            result = bool(re.search(str(value), str(field_value)))
        
        return result != negate
    
    def _get_field_value(self, record: Dict, field: str):
        """从记录中获取字段值"""
        field_map = {
            'order_name': 'name',
            'order_category': 'category',
            'diagnosis': 'main_diagnosis',
            'dosage': 'dosage',
            'duration_days': 'duration_days',
            'drg_weight': 'drg_weight',
            'icd_name_match': 'icd_match_score',
            'has_order': 'has_order',
            'los_ratio': 'los_ratio',
            'zero_action_days': 'zero_action_days'
        }
        actual_field = field_map.get(field, field)
        return record.get(actual_field, '')
    
    def _count_field_occurrences(self, record: Dict, field: str) -> int:
        """统计字段出现次数"""
        orders = record.get('orders', [])
        target = self._get_field_value({'name': field}, 'name')
        return sum(1 for o in orders if target.lower() in o.get('name', '').lower())
    
    def _count_duplicates(self, record: Dict, field: str) -> int:
        """检测重复项数量"""
        orders = record.get('orders', [])
        names = [o.get('name', '') for o in orders]
        return len(names) - len(set(names))
    
    def _create_issue(self, rule: Dict, record: Dict) -> Dict:
        """创建问题记录"""
        return {
            'issue_id': f"I{datetime.now().strftime('%Y%m%d%H%M%S')}{len(self.issues)+1:03d}",
            'rule_id': rule.get('rule_id'),
            'type': rule.get('type'),
            'severity': rule.get('severity'),
            'description': rule.get('description'),
            'suggestion': rule.get('suggestion'),
            'legal_ref': rule.get('legal_ref', ''),
            'penalty': rule.get('penalty', '')
        }
    
    def audit_record(self, record: Dict) -> List[Dict]:
        """审核单份病历"""
        issues = []
        for rule in self.rules:
            matched = self.check_rule(rule, record)
            issues.extend(matched)
        return issues
    
    def audit_batch(self, records: List[Dict]) -> Dict:
        """批量审核"""
        all_issues = []
        record_issues = {}
        
        for record in records:
            record_id = record.get('record_id', f'record_{len(record_issues)+1}')
            issues = self.audit_record(record)
            record_issues[record_id] = issues
            all_issues.extend(issues)
        
        # 统计
        stats = {
            'total_records': len(records),
            'total_issues': len(all_issues),
            'by_severity': {'严重': 0, '一般': 0, '提示': 0},
            'by_type': {}
        }
        
        for issue in all_issues:
            stats['by_severity'][issue['severity']] = stats['by_severity'].get(issue['severity'], 0) + 1
            stats['by_type'][issue['type']] = stats['by_type'].get(issue['type'], 0) + 1
        
        return {
            'audit_time': datetime.now().isoformat(),
            'summary': stats,
            'record_issues': record_issues,
            'all_issues': all_issues
        }

def main():
    parser = argparse.ArgumentParser(description='医保审核引擎')
    parser.add_argument('--records', '-r', required=True, help='结构化病历数据JSON文件')
    parser.add_argument('--rules', '-g', default=None, help='审核规则JSON文件')
    parser.add_argument('--text-rules', '-t', default=None, help='文本规则文件')
    parser.add_argument('--output', '-o', default=None, help='输出JSON文件路径')
    
    args = parser.parse_args()
    
    engine = AuditEngine()
    
    # 加载规则
    if args.rules and os.path.exists(args.rules):
        engine.load_rules(args.rules)
    elif args.text_rules and os.path.exists(args.text_rules):
        with open(args.text_rules, 'r', encoding='utf-8') as f:
            text = f.read()
        count = engine.load_rules_from_text(text)
        print(f"从文本中提取了 {count} 条规则")
    else:
        engine.add_default_rules()
    
    # 加载病历数据
    with open(args.records, 'r', encoding='utf-8') as f:
        records = json.load(f)
        if isinstance(records, dict):
            records = [records]
        elif isinstance(records, list):
            pass
        else:
            records = [records]
    
    # 执行审核
    result = engine.audit_batch(records)
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(json.dumps({"success": True, "output": args.output, "summary": result['summary']}))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
