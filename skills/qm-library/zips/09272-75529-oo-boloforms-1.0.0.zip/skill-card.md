## Description: <br>
BoloForms (boloforms.com). Use this skill for BoloForms requests involving reading workspace data, retrieving form responses, checking signing participants, and sending templates for signing. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and automation builders use this skill to operate a connected BoloForms account through OOMOL, including listing documents, retrieving form responses, checking template respondents, and sending an existing template for signing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected BoloForms account and may send signing requests or otherwise change BoloForms state. <br>
Mitigation: Confirm the exact payload and intended effect before any send, update, create, post, delete, remove, or document-sharing action. <br>
Risk: The skill requires sensitive account credentials through the connected OOMOL service. <br>
Mitigation: Install only when the user intends to let the agent use the connected BoloForms account, and avoid treating casual BoloForms mentions as authorization to act. <br>


## Reference(s): <br>
- [BoloForms homepage](https://www.boloforms.com) <br>
- [BoloForms ClawHub listing](https://clawhub.ai/oomol/oo-boloforms) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
