## Description: <br>
CallerAPI (callerapi.com) lets an agent inspect schemas and run CallerAPI connector actions through an OOMOL-connected account for phone-number intelligence and account information. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to operate CallerAPI from an agent without handling raw API credentials. It supports phone-number reputation, business, complaint, optional HLR carrier lookups, and authenticated account credit checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Phone-number, HLR, and account lookups can expose sensitive personal or business-related information. <br>
Mitigation: Use the skill only for authorized, lawful CallerAPI requests and avoid unnecessary enrichment or disclosure of lookup results. <br>
Risk: The skill requires an OOMOL-connected CallerAPI account and may fail when authentication, connection scope, or billing is unavailable. <br>
Mitigation: Check the live connector schema before running actions and resolve sign-in, connection, scope, or credit issues only when command failures indicate they are needed. <br>


## Reference(s): <br>
- [CallerAPI homepage](https://callerapi.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [CallerAPI ClawHub page](https://clawhub.ai/oomol/oo-callerapi) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Runs live schema inspection before action execution; connector responses are JSON with data and metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: metadata.version and release.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
