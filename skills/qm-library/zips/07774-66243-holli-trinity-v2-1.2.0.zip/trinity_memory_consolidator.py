#!/usr/bin/env python3
"""
Trinity长期记忆固化模块
每次进化完成后自动更新
"""

import json
import os
from datetime import datetime

MEMORY_FILE = "MEMORY.json"
MEMORY_DIR = "data/trinity_log"

class MemoryConsolidator:
    """长期记忆固化器"""
    
    def __init__(self):
        self.capability_registry = {}
        self.protocol_versions = {}
        self.learning_trajectory = []
        self.user_visible_state = self._default_state()
        
    def _default_state(self):
        return {
            "current_version": "v11.0",
            "total_capabilities": 0,
            "active_capabilities": 0,
            "beta_capabilities": 0,
            "deprecated_capabilities": 0,
            "radar_scores": {
                "cognitive_science": 5.0,
                "information_computing": 5.0,
                "systems_engineering": 5.0,
                "evolutionary_decision": 5.0,
                "ethics_philosophy": 5.0,
                "cross_integration": 5.0,
                "meta_cognition": 5.0,
                "paradigm_awareness": 5.0,
                "autonomous_evolution": 4.0
            }
        }
    
    def load(self):
        """加载现有记忆"""
        path = f"{MEMORY_DIR}/{MEMORY_FILE}"
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.capability_registry = data.get('capability_registry', {})
                self.protocol_versions = data.get('protocol_versions', {})
                self.learning_trajectory = data.get('learning_trajectory', [])
                self.user_visible_state = data.get('user_visible_state', self._default_state())
        else:
            self.save()
    
    def save(self):
        """保存记忆"""
        os.makedirs(MEMORY_DIR, exist_ok=True)
        path = f"{MEMORY_DIR}/{MEMORY_FILE}"
        
        data = {
            "capability_registry": self.capability_registry,
            "protocol_versions": self.protocol_versions,
            "learning_trajectory": self.learning_trajectory,
            "user_visible_state": self.user_visible_state,
            "last_updated": datetime.now().isoformat()
        }
        
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return path
    
    def add_capability(self, cap_id, name, version, source, confidence, status):
        """添加能力"""
        self.capability_registry[cap_id] = {
            "name": name,
            "version": version,
            "acquired_date": datetime.now().strftime("%Y-%m-%d"),
            "source": source,
            "confidence": confidence,
            "status": status,  # active/beta/deprecated
            "dependencies": [],
            "test_coverage": "N/A",
            "usage_count": 0,
            "success_rate": None
        }
        
        # 更新统计
        self.user_visible_state['total_capabilities'] = len(self.capability_registry)
        self.user_visible_state['active_capabilities'] = sum(
            1 for c in self.capability_registry.values() if c['status'] == 'active'
        )
        self.user_visible_state['beta_capabilities'] = sum(
            1 for c in self.capability_registry.values() if c['status'] == 'beta'
        )
        
        self.save()
    
    def update_protocol(self, old_version, new_version, changes, issues):
        """更新协议版本"""
        # 标记旧版本为deprecated
        if old_version in self.protocol_versions:
            self.protocol_versions[old_version]['deprecation_date'] = datetime.now().strftime("%Y-%m-%d")
        
        # 添加新版本
        self.protocol_versions[new_version] = {
            "activation_date": datetime.now().strftime("%Y-%m-%d"),
            "changes": changes,
            "known_issues": issues,
            "rollback_available": True
        }
        
        # 更新当前版本
        self.user_visible_state['current_version'] = new_version
        
        self.save()
    
    def add_audit_finding(self, date, issue, issue_type):
        """添加审计发现"""
        self.learning_trajectory.append({
            "date": date,
            "top_issue": issue,
            "type": issue_type
        })
        
        # 保持最近30条
        self.learning_trajectory = self.learning_trajectory[-30:]
        
        self.save()
    
    def update_radar(self, dimension, score):
        """更新雷达图"""
        if dimension in self.user_visible_state['radar_scores']:
            old = self.user_visible_state['radar_scores'][dimension]
            self.user_visible_state['radar_scores'][dimension] = score
            return old, score
        return None, None
    
    def get_state(self):
        """获取当前状态"""
        return self.user_visible_state
    
    def get_capabilities(self, status=None):
        """获取能力列表"""
        if status:
            return {k: v for k, v in self.capability_registry.items() if v['status'] == status}
        return self.capability_registry

# 测试
def test():
    print("=== Memory Consolidator Test ===\n")
    
    mc = MemoryConsolidator()
    mc.load()
    
    # 添加能力
    mc.add_capability(
        "cap_001",
        "反事实压力测试",
        "1.0",
        "Iterator修复P0",
        0.82,
        "active"
    )
    print(f"Added capability: {mc.user_visible_state['total_capabilities']}")
    
    # 更新协议
    mc.update_protocol(
        "v11.3",
        "v11.4",
        ["新增反事实压力测试"],
        ["跨会话情绪追踪beta"]
    )
    print(f"Updated protocol: {mc.user_visible_state['current_version']}")
    
    # 添加审计发现
    mc.add_audit_finding(
        datetime.now().strftime("%Y-%m-%d"),
        "极端场景盲区",
        "knowledge_gap"
    )
    print(f"Audit findings: {len(mc.learning_trajectory)}")
    
    # 更新雷达
    old, new = mc.update_radar("cognitive_science", 8.0)
    print(f"Radar update: {old} → {new}")
    
    # 状态
    print(f"\nState: {mc.get_state()}")
    
    print("\n[Memory Consolidator OK]")

if __name__ == "__main__":
    test()