#!/usr/bin/env python3
"""
Trinity v11.0 定时启动器
每天凌晨02:00自动执行
"""

import os
import sys
import time
from datetime import datetime, timedelta
from threading import Thread

# 导入Trinity模块
sys.path.insert(0, os.path.dirname(__file__))
from trinity_scheduler import TrinityScheduler
from trinity_state_machine import StateMachine, TrinityState

class TrinityDaemon:
    """Trinity守护进程"""
    
    def __init__(self):
        self.scheduler = TrinityScheduler()
        self.state_machine = StateMachine()
        self.running = False
    
    def should_run_today(self):
        """检查今天是否应该运行"""
        now = datetime.now()
        # 如果是凌晨且是2点左右
        if now.hour == 2 and now.minute < 30:
            return True
        return False
    
    def execute_trinity_cycle(self):
        """执行完整的Trinity循环"""
        print(f"[{datetime.now()}] Trinity周期开始...")
        
        try:
            # 1. Auditor
            self.state_machine.transition(TrinityState.AUDITING)
            print("-> Auditor运行中...")
            self.scheduler.run_auditor()
            
            # 2. Iterator
            self.state_machine.transition(TrinityState.ITERATING)
            print("-> Iterator运行中...")
            self.scheduler.run_iterator()
            
            # 3. Tester
            self.state_machine.transition(TrinityState.TESTING)
            print("-> Tester运行中...")
            self.scheduler.run_tester()
            
            # 4. 整合
            self.state_machine.transition(TrinityState.INTEGRATING)
            print("-> 整合完成")
            
            # 回归IDLE
            self.state_machine.transition(TrinityState.IDLE)
            
            print(f"[{datetime.now()}] Trinity周期完成!")
            
        except Exception as e:
            print(f"错误: {e}")
            self.state_machine.transition(TrinityState.ROLLBACK)
    
    def daemon_loop(self):
        """守护进程主循环"""
        print("Trinity守护进程启动...")
        
        while self.running:
            now = datetime.now()
            
            # 每天02:00检查
            if now.hour == 2 and now.minute == 0:
                if self.state_machine.state == TrinityState.IDLE:
                    self.execute_trinity_cycle()
            
            # 每分钟检查一次
            time.sleep(60)
    
    def start_daemon(self):
        """启动守护进程"""
        self.running = True
        thread = Thread(target=self.daemon_loop, daemon=True)
        thread.start()
        print("守护进程已启动，下次02:00将自动执行")
    
    def stop_daemon(self):
        """停止守护进程"""
        self.running = False
        print("守护进程已停止")

# 命令行接口
def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Trinity v11.0')
    parser.add_argument('command', choices=['start', 'stop', 'status', 'run'])
    args = parser.parse_args()
    
    daemon = TrinityDaemon()
    
    if args.command == 'start':
        daemon.start_daemon()
    elif args.command == 'stop':
        daemon.stop_daemon()
    elif args.command == 'status':
        status = daemon.state_machine.get_status()
        print(f"当前状态: {status['current']}")
        print(f"历史记录: {status['history_count']}")
    elif args.command == 'run':
        print("手动���行Trinity周期...")
        daemon.execute_trinity_cycle()

if __name__ == "__main__":
    main()