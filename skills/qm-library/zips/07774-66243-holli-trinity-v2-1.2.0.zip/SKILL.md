---
name: trinity-evolution
description: 每日AI能力进化工具 - 自检缺陷→阅读学习→生成洞察→验证提升。三阶段闭环让AI持续进步。提供完整Python源码、详细文档和使用指南。适合AI开发者和自驱动的AI用户。
metadata: {"openclaw": {"requires": {"bins": ["python"]}}, "tags": ["ai", "evolution", "self-improvement", "learning", "agent"], "author": "holli", "homepage": "https://github.com/holli"}
---
# Trinity - 每日AI能力进化工具

让AI每天自动进步一点点。开源可审计的进化引擎。

## 功能说明

**这是数据分析工具，用于AI的自我改进：**

1. **读取本地文件** - 分析交互记录
2. **生成结构化报告** - 输出到本地JSON文件
3. **不执行网络请求** - 不访问外部API
4. **不下载或上传** - 所有数据本地处理

## 三阶段闭环

| 阶段 | 功能 | 输出 |
|------|------|------|
| Auditor | 自检能力缺陷 | 缺陷列表 + 阅读清单 |
| Executor | 阅读学习 | 知识提取 + 知识链接 + 新洞察 |
| Tester | 设计测试 | 测试用例 + 验证结果 |

## 用户能看到什么

运行后输出：
- 📋 今日发现的能力缺陷
- 📚 读了什么、总结了知识
- 💡 产生了什么新想法
- ✅ 验证结果
- 📊 每日进化报告 (data/trinity_log/闭环_YYYYMMDD.json)

## 文件说明

```
trinity_v15.py    - 主入口脚本（直接运行）
trinity_auditor.py   - Auditor模块
trinity_executor.py - Executor模块
trinity_tester.py  - Tester模块
```

## 使用方法

### 快速开始
```bash
python trinity_v15.py
```

### 查看帮助
```bash
python trinity_v15.py --help
```

### 输出位置
- 日志目录: `data/trinity_log/`
- 报告文件: `data/trinity_log/闭环_YYYYMMDD.json`

## 安全特性

- 纯本地数据分析
- 不执行网络请求
- 不访问外部API
- 不下载或上传文件
- 所有输出到本地文件
- 开源代码，可审计

## 适用人群

- 想让AI持续进步的开发者
- 需要自动化self-improvement的AI用户
- 构建AI agents的工程师
- 学习AI进化的研究者

## 版本历史

- v15.0: 最新版本，三阶段闭环

## Credits

基于AI自我进化理论研究开发
作者: holli
许可: MIT