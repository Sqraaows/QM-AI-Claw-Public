#!/usr/bin/env python3
"""
Trinity协议自动更新模块
06:45-07:00执行
"""

import os
import json
from datetime import datetime

PROTOCOL_DIR = "data"
PROTOCOL_FILE = "protocol_core.json"

class ProtocolUpdater:
    """协议自动更新器"""

    def __init__(self):
        self.current_version = "v11.3"
        self.history = []

    def load_protocol(self, version=None):
        """加载协议"""
        v = version or self.current_version
        path = f"{PROTOCOL_DIR}/protocol_core_{v}.json"

        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)

        # 默认协议
        return {
            'version': v,
            'core': {
                'confidence': True,
                'prediction': True,
                'paradigm': True,
                'trinity': True
            }
        }

    def extract_changes(self, iteration_report):
        """从迭代报告提取变更"""
        # 简化版:从文件读取
        report_path = f"data/trinity_log/iterator_{datetime.now().strftime('%Y%m%d')}.md"

        changes = []

        if os.path.exists(report_path):
            with open(report_path, 'r', encoding='utf-8') as f:
                content = f.read()
                # 简单的变更提取
                if '新协议' in content:
                    changes.append('protocol_update')
                if '新模块' in content:
                    changes.append('module_add')
                if '记忆' in content:
                    changes.append('memory_update')

        return changes

    def apply_changes(self, current_protocol, changes):
        """应用变更"""
        new_protocol = current_protocol.copy()
        new_protocol['changes'] = changes
        new_protocol['last_updated'] = datetime.now().isoformat()
        return new_protocol

    def validate_protocol(self, protocol):
        """验证协议一致性"""
        # 简单的验证
        required = ['version', 'core']

        missing = [f for f in required if f not in protocol]

        return {
            'consistent': len(missing) == 0,
            'errors': missing,
            'warnings': []
        }

    def determine_version_bump(self, changes):
        """确定版本号升级类型"""
        if not changes:
            return 'none'
        
        # 分析变更类型
        has_architecture = any('架构' in c or '重构' in c for c in changes)
        has_paradigm = any('范式' in c or '维度' in c for c in changes)
        has_capability = any('能力' in c or '新增' in c for c in changes)
        
        # 优先级：架构重构 > 范式转换 > 能力新增 > 补丁修复
        if has_architecture:
            return 'major'     # X.Y.Z → X+1.0 (架构重构)
        elif has_paradigm:
            return 'minor'    # X.Y → X.Y+1 (范式转换)
        elif has_capability:
            return 'minor'    # X.Y → X.Y+1 (能力新增)
        else:
            return 'patch'    # X.Y.Z → X.Y.Z+1 (补丁修复)

    def bump_version(self, current, bump_type):
        """版本号升级"""
        # 版本号规则：
        # 补丁修复: v11.3 → v11.3.1
        # 能力新增: v11.3 → v11.4
        # 范式转换: v11.0 → v12.0
        # 架构重构: v11.0 → v12.0
        
        if bump_type == 'none':
            return current
        
        # 解析版本号
        if current.startswith('v'):
            prefix = 'v'
            num = current[1:]
        else:
            prefix = 'v'
            num = current
        
        parts = num.split('.')
        
        if bump_type == 'patch':
            # X.Y.Z → X.Y.Z+1
            if len(parts) >= 3:
                return f"{prefix}{parts[0]}.{parts[1]}.{int(parts[2]) + 1}"
            else:
                return f"{prefix}{parts[0]}.{parts[1]}.1"
        
        elif bump_type == 'minor':
            # X.Y → X.Y+1 (能力/范式)
            return f"{prefix}{parts[0]}.{int(parts[1]) + 1}"
        
        elif bump_type == 'major':
            # X.Y → X+1.0 (架构重构)
            return f"{prefix}{int(parts[0]) + 1}.0"
        
        return current

    def save_protocol(self, version, protocol):
        """保存协议"""
        path = f"{PROTOCOL_DIR}/protocol_core_{version}.json"

        with open(path, 'w', encoding='utf-8') as f:
            json.dump(protocol, f, ensure_ascii=False, indent=2)

        return path

    def generate_changelog(self, old, new):
        """生成变更摘要"""
        old_v = old.get('version', 'unknown')
        new_v = new.get('version', 'unknown')
        changes = new.get('changes', [])

        return {
            'old_version': old_v,
            'new_version': new_v,
            'changes': changes,
            'timestamp': datetime.now().isoformat()
        }

    def update(self, audit_report=None, iteration_report=None, test_report=None):
        """自动更新协议"""
        print(f"[Protocol Updater] 开始更新...")

        # 1. 加载当前协议
        current = self.load_protocol()
        print(f"  当前版本: {current['version']}")

        # 2. 提取变更
        changes = self.extract_changes(iteration_report or '')
        print(f"  变更: {changes}")

        if not changes:
            print("  无变更,跳过")
            return {'status': 'skipped', 'reason': 'no_changes'}

        # 3. 应用变更
        new_protocol = self.apply_changes(current, changes)

        # 4. 验证
        validation = self.validate_protocol(new_protocol)

        if not validation['consistent']:
            print(f"  验证失败: {validation['errors']}")
            return {'status': 'rollback', 'errors': validation['errors']}

        # 5. 版本升级
        bump = self.determine_version_bump(changes)
        new_version = self.bump_version(current['version'], bump)

        # 6. 保存
        path = self.save_protocol(new_version, new_protocol)
        print(f"  新版本: {new_version}")

        # 7. 变更摘要
        changelog = self.generate_changelog(current, new_protocol)
        print(f"  已保存: {path}")

        return {'status': 'updated', 'info': changelog}

# 测试
def test():
    print("=== Protocol Updater Test ===\n")

    updater = ProtocolUpdater()
    result = updater.update()

    print(f"\n结果: {result}")
    print("\n[Protocol Updater OK]")

if __name__ == "__main__":
    test()