#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trinity v15.0 - Tester Agent
职责：设计测试例，测试新能力完成情况，向 Auditor 反馈
输入：Executor 的执行结果 + Auditor 的缺陷列表
输出：测试用例、验证结果、反馈给 Auditor 的建议
"""
import os
import json
from datetime import datetime

class TrinityTesterV15:
    """Tester：设计测试例，验证能力，反馈"""
    
    def __init__(self, exec_result, audit_result):
        self.exec_result = exec_result
        self.audit_result = audit_result
        self.date_str = datetime.now().strftime("%Y%m%d")
    
    def run(self):
        # 1. 设计测试用例
        test_cases = self._design_test_cases()
        
        # 2. 执行测试（模拟）
        test_results = self._run_tests(test_cases)
        
        # 3. 生成判定
        verdict, feedback = self._generate_verdict(test_results)
        
        # 4. 保存测试日志
        self._save_test_log(test_cases, test_results, verdict)
        
        return {
            "test_cases": test_cases,
            "test_results": test_results,
            "verdict": verdict,
            "feedback": feedback
        }
    
    def _design_test_cases(self):
        """根据 Executor 的执行结果设计测试用例"""
        test_cases = []
        
        executed = self.exec_result.get("executed", [])
        insights = self.exec_result.get("insights", [])
        
        # 测试已执行的动作
        for ex in executed:
            if "置信度" in ex:
                test_cases.append({
                    "id": "T-CONF-01",
                    "name": "置信度标记",
                    "description": "输出是否正确使用 A/B/C/D 级标记",
                    "expected": "不确定内容应标记 [C:XX%] 或 [D:XX%]",
                    "type": "output_check"
                })
            elif "记忆" in ex:
                test_cases.append({
                    "id": "T-MEM-01",
                    "name": "关键点复述",
                    "description": "交互结尾是否进行关键点复述",
                    "expected": "复杂交互后有复述总结",
                    "type": "behavior_check"
                })
            elif "预判" in ex:
                test_cases.append({
                    "id": "T-PRED-01",
                    "name": "预判检查点",
                    "description": "响应前是否考虑用户可能的需求",
                    "expected": "主动建议时引用 MEMORY.md",
                    "type": "behavior_check"
                })
        
        # 测试洞察应用
        for insight in insights:
            ins_type = insight.get("type", "")
            if ins_type == "confidence":
                test_cases.append({
                    "id": "T-CONF-02",
                    "name": "措辞校准",
                    "description": "不同置信度是否使用不同措辞",
                    "expected": "A级用'确定'，D级不作为决策",
                    "type": "output_check"
                })
            elif ins_type == "prediction":
                test_cases.append({
                    "id": "T-PRED-02",
                    "name": "基础率思维",
                    "description": "是否使用基础率而非个案推断",
                    "expected": "预判时考虑先验概率",
                    "type": "reasoning_check"
                })
        
        # 默认测试用例
        if not test_cases:
            test_cases = [
                {
                    "id": "T-GEN-01",
                    "name": "基本响应",
                    "description": "能否正常响应用户",
                    "expected": "响应内容合理",
                    "type": "basic"
                }
            ]
        
        return test_cases
    
    def _run_tests(self, test_cases):
        """运行测试用例（模拟）"""
        results = []
        
        for tc in test_cases:
            tc_id = tc.get("id", "")
            
            # 模拟测试结果（实际会调用真实测试）
            # 检查文件是否已更新
            passed = False
            reason = ""
            
            if tc.get("type") == "output_check":
                # 检查 SOUL.md
                if os.path.exists("SOUL.md"):
                    with open("SOUL.md", 'r', encoding='utf-8') as f:
                        content = f.read()
                    if "置信度" in content or "Brier Score" in content:
                        passed = True
                        reason = "SOUL.md 已更新置信度规则"
            
            elif tc.get("type") == "behavior_check":
                # 检查 AGENTS.md
                if os.path.exists("AGENTS.md"):
                    with open("AGENTS.md", 'r', encoding='utf-8') as f:
                        content = f.read()
                    if "复述" in content or "预判" in content:
                        passed = True
                        reason = "AGENTS.md 已更新行为规则"
            
            elif tc.get("type") == "reasoning_check":
                # 检查 MEMORY.md
                if os.path.exists("MEMORY.md"):
                    with open("MEMORY.md", 'r', encoding='utf-8') as f:
                        content = f.read()
                    if "基础率" in content or "先验" in content:
                        passed = True
                        reason = "MEMORY.md 包含相关知识"
            
            else:
                # 基本测试默认通过
                passed = True
                reason = "基础能力正常"
            
            results.append({
                "test_id": tc_id,
                "name": tc.get("name", ""),
                "passed": passed,
                "reason": reason
            })
        
        return results
    
    def _generate_verdict(self, test_results):
        """生成判定和反馈"""
        passed_count = sum(1 for r in test_results if r["passed"])
        total = len(test_results)
        
        if passed_count == total:
            verdict = "✅ PASS - 全部测试通过"
            feedback = ["能力进化完成，继续保持"]
        elif passed_count >= total * 0.5:
            verdict = "🟡 PARTIAL - 部分通过"
            failed = [r["name"] for r in test_results if not r["passed"]]
            feedback = [f"需改进: {', '.join(failed)}"]
        else:
            verdict = "❌ FAIL - 测试未通过"
            failed = [r["name"] for r in test_results if not r["passed"]]
            feedback = [
                f"测试失败: {', '.join(failed)}",
                "需要重新审视进化规划"
            ]
        
        # 生成给 Auditor 的反馈
        auditor_feedback = []
        for r in test_results:
            if not r["passed"]:
                auditor_feedback.append(f"{r['name']} 不足，需要针对性提升")
        
        return verdict, feedback
    
    def _save_test_log(self, test_cases, test_results, verdict):
        """保存测试日志"""
        log = {
            "date": self.date_str,
            "test_cases": test_cases,
            "test_results": test_results,
            "verdict": verdict
        }
        
        os.makedirs("data/trinity_log", exist_ok=True)
        with open(f"data/trinity_log/tester_{self.date_str}.json", "w", encoding="utf-8") as f:
            json.dump(log, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # 测试
    exec_result = {
        "executed": ["SOUL.md: 置信度校准增强", "AGENTS.md: 预判检查点"],
        "insights": [{"type": "confidence", "insight": "测试"}]
    }
    audit_result = {"gaps": [{"desc": "置信度"}]}
    
    tester = TrinityTesterV15(exec_result, audit_result)
    result = tester.run()
    print(json.dumps(result, ensure_ascii=False, indent=2))