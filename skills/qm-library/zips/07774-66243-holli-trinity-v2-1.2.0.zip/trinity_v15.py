#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trinity v15.0 - 闭环进化引擎
Auditor → Executor → Tester 每日迭代
"""
import os
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

os.chdir(r'C:\Users\holli\.openclaw\workspace')

from skills.trinity_auditor_v15 import TrinityAuditorV15
from skills.trinity_executor_v15 import TrinityExecutorV15  
from skills.trinity_tester_v15 import TrinityTesterV15
from datetime import datetime

def main():
    today = datetime.now()
    date_str = today.strftime("%Y%m%d")
    date_readable = today.strftime("%Y-%m-%d %H:%M")
    
    print(f"[{date_readable}] Trinity v15.0 闭环进化开始")
    print("=" * 60)
    
    # Stage 1: Auditor - 自检能力缺陷，生成阅读清单
    print("\n>>> [Auditor] 自检能力缺陷...")
    auditor = TrinityAuditorV15()
    audit_result = auditor.run()
    print(f"  识别缺陷: {len(audit_result['gaps'])} 个")
    print(f"  阅读清单: {len(audit_result['reading_list'])} 项")
    
    # Stage 2: Executor - 阅读、知识提取、知识链接、洞察、执行
    print("\n>>> [Executor] 执行阅读与知识进化...")
    executor = TrinityExecutorV15(audit_result)
    exec_result = executor.run()
    print(f"  知识提取: {len(exec_result['key_points'])} 个知识点")
    print(f"  知识链接: {len(exec_result['knowledge_links'])} 条")
    print(f"  新洞察: {len(exec_result['insights'])} 个")
    print(f"  执行动作: {len(exec_result['executed'])} 项")
    
    # Stage 3: Tester - 设计测试例，验证能力
    print("\n>>> [Tester] 测试新能力...")
    tester = TrinityTesterV15(exec_result, audit_result)
    test_result = tester.run()
    print(f"  测试用例: {len(test_result['test_cases'])} 个")
    print(f"  验证结果: {test_result['verdict']}")
    
    # 生成简洁报告
    report = {
        "date": date_str,
        "auditor": {
            "gaps": audit_result["gaps"],
            "reading_list": [r["gap"] for r in audit_result["reading_list"]]
        },
        "executor": {
            "key_points": len(exec_result["key_points"]),
            "knowledge_links": len(exec_result["knowledge_links"]),
            "insights": exec_result["insights"],
            "executed": exec_result["executed"]
        },
        "tester": {
            "verdict": test_result["verdict"],
            "feedback": test_result["feedback"]
        }
    }
    
    # 保存结果供明日 Auditor 使用
    import json
    os.makedirs("data/trinity_log", exist_ok=True)
    with open(f"data/trinity_log/闭环_{date_str}.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    
    print("\n" + "=" * 60)
    print(f"[{date_readable}] Trinity v15.0 闭环完成")
    print(f"\n>>> 今日进化总结:")
    print(f"  缺陷识别: {len(audit_result['gaps'])} 个")
    print(f"  新洞察: {len(exec_result['insights'])} 个")
    print(f"  执行动作: {len(exec_result['executed'])} 项")
    print(f"  测试判定: {test_result['verdict']}")
    print(f"\n结果已保存: data/trinity_log/闭环_{date_str}.json")

if __name__ == "__main__":
    main()