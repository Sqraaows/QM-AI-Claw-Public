#!/usr/bin/env python3
"""
Trinity状态机管理
状态转换验证与日志
"""

from datetime import datetime
import os
import json

LOG_DIR = "data/trinity_log"
os.makedirs(LOG_DIR, exist_ok=True)

class TrinityState:
    """Trinity状态常量"""
    IDLE = "idle"
    AUDITING = "auditing"
    ITERATING = "iterating"
    TESTING = "testing"
    INTEGRATING = "integrating"
    ROLLBACK = "rollback"

class StateMachine:
    """状态机管理器"""
    
    def __init__(self):
        self.state = TrinityState.IDLE
        self.history = []
        self.load_history()
    
    def load_history(self):
        """加载历史"""
        history_file = f"{LOG_DIR}/state_history.json"
        if os.path.exists(history_file):
            with open(history_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.history = data.get('history', [])
                self.state = data.get('current', TrinityState.IDLE)
    
    def save_history(self):
        """保存历史"""
        history_file = f"{LOG_DIR}/state_history.json"
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump({
                'current': self.state,
                'history': self.history
            }, f, ensure_ascii=False, indent=2)
    
    def transition(self, new_state):
        """状态转换"""
        # 合法转换表
        valid_transitions = {
            TrinityState.IDLE: [TrinityState.AUDITING],
            TrinityState.AUDITING: [TrinityState.ITERATING, TrinityState.IDLE],
            TrinityState.ITERATING: [TrinityState.TESTING, TrinityState.IDLE],
            TrinityState.TESTING: [TrinityState.INTEGRATING, TrinityState.ROLLBACK],
            TrinityState.INTEGRATING: [TrinityState.IDLE],
            TrinityState.ROLLBACK: [TrinityState.IDLE]
        }
        
        old_state = self.state
        
        # 验证合法性
        if new_state not in valid_transitions.get(self.state, []):
            raise ValueError(f"非法状态转换: {self.state} -> {new_state}")
        
        # 执行转换
        self.state = new_state
        
        # 记录
        self.history.append({
            'from': old_state,
            'to': new_state,
            'timestamp': datetime.now().isoformat()
        })
        
        self.save_history()
        
        return f"状态转换: {old_state} -> {new_state}"
    
    def get_status(self):
        return {
            'current': self.state,
            'history_count': len(self.history)
        }

# 测试
def test():
    print("=== 状态机测试 ===\n")
    
    sm = StateMachine()
    
    # IDLE -> AUDITING
    result = sm.transition(TrinityState.AUDITING)
    print(f"1. {result}")
    print(f"   状态: {sm.get_status()['current']}")
    
    # AUDITING -> ITERATING
    result = sm.transition(TrinityState.ITERATING)
    print(f"2. {result}")
    
    # ITERATING -> TESTING
    result = sm.transition(TrinityState.TESTING)
    print(f"3. {result}")
    
    # TESTING -> INTEGRATING
    result = sm.transition(TrinityState.INTEGRATING)
    print(f"4. {result}")
    
    # INTEGRATING -> IDLE
    result = sm.transition(TrinityState.IDLE)
    print(f"5. {result}")
    
    print(f"\n历史记录: {len(sm.history)} 条")
    print("\n[状态机 OK]")

if __name__ == "__main__":
    test()