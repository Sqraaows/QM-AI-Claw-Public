#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trinity v13.0 - Stage 2: Iterator 迭代智能体
输入: 审计报告
任务: 修复P0问题，优化可测量指标，准备需要验收的新假设
约束: 仅修改软偏好层，硬边界变更需标记[BLOCKED]
输出: iterate_YYYYMMDD.md
"""
import os
import re
from datetime import datetime

LOG_DIR = "data/trinity_log"


def parse_audit_report(path):
    """解析审计报告，提取关键结论"""
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    findings = {
        "gap_count": 0,
        "blindspots": [],
        "hypotheses": [],
        "p0_count": 0,
        "p1_count": 0,
        "p2_count": 0,
    }
    
    gap_match = re.findall(r'\|- \|', content)
    findings["gap_count"] = len(gap_match)
    
    blind_matches = re.findall(r'\u26a0\ufe0f (.+)', content)
    findings["blindspots"] = blind_matches
    
    findings["p1_count"] = len(re.findall(r'\| P1 \|', content))
    findings["p2_count"] = len(re.findall(r'\| P2 \|', content))
    
    return findings


def generate_action_plan(audit_findings):
    """根据审计结果生成迭代行动计划"""
    actions = []
    
    # P1 指标优化: 用户纠正率
    actions.append({
        "type": "optimize",
        "priority": "P1",
        "target": "user_correction_rate",
        "action": "在 SOUL.md 中增加【输出前自检清单】：是否核实了记忆引用？是否验证了时间/数字？是否标注了置信度？",
        "expected_gain": "降低用户纠正率从 6.7% 到 <=5%",
        "files_to_modify": ["SOUL.md"],
        "blocked": False
    })
    
    # 盲区修复
    blindspots = audit_findings.get("blindspots", [])
    for blind in blindspots:
        if "\u98fe\u4e66" in blind or "feishu" in blind.lower():
            actions.append({
                "type": "observe",
                "priority": "P2",
                "target": "feishu_interaction",
                "action": "记录：飞书交互数据不足，等待下次真实交互后再评估",
                "expected_gain": "数据积累",
                "files_to_modify": [],
                "blocked": False
            })
        elif "\u6df1\u5ea6\u7814\u7a76" in blind:
            actions.append({
                "type": "observe",
                "priority": "P2",
                "target": "deep_research",
                "action": "记录：缺少深度研究交互样本，不优化，等待真实数据",
                "expected_gain": "数据积累",
                "files_to_modify": [],
                "blocked": False
            })
        elif "\u4ee3\u7801" in blind or "code" in blind.lower():
            actions.append({
                "type": "observe",
                "priority": "P2",
                "target": "coding_tasks",
                "action": "记录：缺少代码任务样本，不优化",
                "expected_gain": "数据积累",
                "files_to_modify": [],
                "blocked": False
            })
    
    # 数据不足指标：仅记录
    actions.append({
        "type": "observe",
        "priority": "P2",
        "target": "all_data_insufficient",
        "action": "以下指标样本不足，仅记录当前值，不优化：proactive_adoption(n=3), retrieval_accuracy(n=5), new_topic_ratio(n=0)",
        "expected_gain": "数据积累",
        "files_to_modify": [],
        "blocked": False
    })
    
    # 假设验证准备
    actions.append({
        "type": "prepare_verification",
        "priority": "P1",
        "target": "H-1_assume_stable_accuracy",
        "action": "在下次 MasterExam 中验证：'用户纠正率长期<10%，表明基础准确性已稳定'",
        "expected_gain": "假设置信度提升",
        "files_to_modify": [],
        "blocked": False
    })
    
    return actions


def update_files(actions):
    """实际修改文件（软偏好层）"""
    modified = []
    
    for action in actions:
        if action["type"] == "optimize" and action["target"] == "user_correction_rate":
            soul_path = "SOUL.md"
            if os.path.exists(soul_path):
                with open(soul_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                check_item = """

### 🦞 输出前自检清单 (v13.0 新增)
- [ ] 记忆引用：是否核实了来源和准确性？
- [ ] 数字/日期：是否验证过？
- [ ] 置信度：是否对低置信度内容标注了 [C:XX%]？
- [ ] 逻辑一致性：是否与 MEMORY.md 不矛盾？
"""
                
                if "\u8f93\u51fa\u524d\u81ea\u68c0\u6e05\u5355" not in content:
                    if "## Boundaries" in content:
                        content = content.replace("## Boundaries", check_item + "\n## Boundaries")
                    else:
                        content += check_item
                    
                    with open(soul_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                    
                    modified.append(soul_path)
    
    return modified


class TrinityIterator:
    """Iterator 迭代智能体"""
    
    def __init__(self, audit_report_path):
        self.audit_report_path = audit_report_path
        self.findings = parse_audit_report(audit_report_path)
    
    def run(self):
        date_str = datetime.now().strftime("%Y%m%d")
        date_readable = datetime.now().strftime("%Y-%m-%d %H:%M")
        
        actions = generate_action_plan(self.findings)
        modified_files = update_files(actions)
        
        opt_count = sum(1 for a in actions if a["type"] == "optimize")
        obs_count = sum(1 for a in actions if a["type"] == "observe")
        prep_count = sum(1 for a in actions if a["type"] == "prepare_verification")
        
        report_lines = [
            f"# Iterator 迭代执行报告\n",
            f"**日期**: {date_readable}",
            f"**版本**: Trinity v13.0 Stage 2",
            f"**输入**: {os.path.basename(self.audit_report_path)}",
            "",
            "---",
            "",
            "## 审计解读",
            f"- 指标差距: {self.findings['gap_count']} 项",
            f"- 盲区: {len(self.findings['blindspots'])} 项",
            f"- P1问题: {self.findings['p1_count']} 个",
            f"- P2问题: {self.findings['p2_count']} 个",
            "",
            "## 执行修复",
        ]
        
        for action in actions:
            blocked_tag = "[BLOCKED]" if action.get("blocked") else ""
            report_lines.append("")
            report_lines.append(f"### {action['type']} | {action['priority']} | {action['target']} {blocked_tag}")
            report_lines.append(f"- **行动**: {action['action']}")
            report_lines.append(f"- **预期收益**: {action['expected_gain']}")
            if action["files_to_modify"]:
                report_lines.append(f"- **涉及文件**: {', '.join(action['files_to_modify'])}")
            else:
                report_lines.append(f"- **涉及文件**: (无)")
        
        report_lines.extend([
            "",
            "## 文件修改记录",
        ])
        
        if modified_files:
            for f in modified_files:
                report_lines.append(f"- [OK] 已修改: {f}")
        else:
            report_lines.append("- 无文件修改")
        
        report_lines.extend([
            "",
            "## 行动统计",
            f"- 总行动数: {len(actions)}",
            f"- 优化行动: {opt_count}",
            f"- 观察记录: {obs_count}",
            f"- 验证准备: {prep_count}",
            "",
            "## 输出状态",
            f"- 等待 Tester: [OK] 是",
            f"- 新增协议: {'SOUL.md 自检清单' if modified_files else '无'}",
            f"- [BLOCKED] 硬边界变更: 0",
        ])
        
        report_content = "\n".join(report_lines)
        
        output_file = f"{LOG_DIR}/iterator_{date_str}.md"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        print(f"[Iterator] 完成: {output_file}")
        print(f"  - 行动方案: {len(actions)} 项")
        print(f"  - 文件修改: {len(modified_files)} 项")
        
        return output_file