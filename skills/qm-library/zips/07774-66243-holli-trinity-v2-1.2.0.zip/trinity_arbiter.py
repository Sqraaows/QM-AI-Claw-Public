#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trinity v13.0 - Stage 4: Arbiter 整合智能体
输入: 审计报告 + 迭代报告 + 测试报告
任务: 判定通过/部分通过/回滚，生成飞书日报，准备MasterExam材料
输出: daily_YYYYMMDD.md + exam_material_YYYYMMDD.json
"""
import os
import re
import json
from datetime import datetime

LOG_DIR = "data/trinity_log"

# ===== MasterExam 问题设计（v13.0 规格） =====
# 三层问题：事实层 / 原因层 / 预测层
EXAM_TEMPLATE = {
    "fact_question": "师父，今日交互中我观察到{obs}，理解为{infer}。对吗？",
    "cause_question": "基于事实，我认为原因是{reason}。这个理解正确吗？",
    "prediction_question": "基于以上，我预测明日{scene}中你会{behavior}。可能吗？",
}


def read_report(path):
    if path and os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    return ""


def extract_findings(content):
    """从报告内容提取关键发现"""
    findings = {
        "gaps": re.findall(r'\|- \|([^|]+)\|', content),
        "blindspots": re.findall(r'⚠️ (.+)', content),
        "hypotheses": re.findall(r'\*\*H-\w+\*\*[:\s]+(.+)', content),
        "pass_rate": 0.0,
        "verdict": "未知",
    }
    
    # 提取测试通过率
    rate_match = re.search(r'\*\*判定结果\*\*: (.+)', content)
    if rate_match:
        verdict_text = rate_match.group(1)
        findings["verdict"] = verdict_text
        if "PASS" in verdict_text and "PARTIAL" not in verdict_text:
            findings["pass_rate"] = 1.0
        elif "PARTIAL" in verdict_text:
            findings["pass_rate"] = 0.5
    
    return findings


def generate_exam_questions(audit_findings, iterate_findings, test_findings):
    """生成 MasterExam 考校问题"""
    questions = []
    
    # 问题1：事实层 - 关于用户纠正率
    questions.append({
        "layer": "fact",
        "question": EXAM_TEMPLATE["fact_question"].format(
            obs="用户纠正率为 6.7%（n=15），远低于目标 20%",
            infer="基础准确性已经稳定，不需要频繁纠正"
        ),
        "expected_topic": "user_correction_rate",
        "options": ["对", "部分对，需要修正：...", "完全错，因为..."],
    })
    
    # 问题2：原因层 - 为什么首响延迟这么低
    questions.append({
        "layer": "cause",
        "question": EXAM_TEMPLATE["cause_question"].format(
            reason="当前使用 MiniMax 模型响应快，且我养成了简洁优先的习惯"
        ),
        "expected_topic": "first_response_delay",
        "options": ["对", "部分对，需要修正：...", "完全错，因为..."],
    })
    
    # 问题3：预测层 - 明天可能的行为
    questions.append({
        "layer": "prediction",
        "question": EXAM_TEMPLATE["prediction_question"].format(
            scene="你主动提供建议的场景",
            behavior="引用 MEMORY.md 中的五维目标来支撑建议"
        ),
        "expected_topic": "proactive_behavior",
        "options": ["可能", "不太可能，因为..."],
    })
    
    return questions


def decide_verdict(test_findings, audit_findings):
    """综合判定结果"""
    pass_rate = test_findings.get("pass_rate", 0)
    
    if pass_rate >= 0.9:
        return "✅ PASS - 通过，允许进入 MasterExam 验收"
    elif pass_rate >= 0.7:
        return "🟡 PARTIAL PASS - 部分通过，需关注低分项"
    else:
        return "❌ FAIL - 回滚，暂停进化"


class TrinityArbiter:
    """Arbiter 整合智能体"""
    
    def __init__(self, audit_path, iterate_path, test_path):
        self.audit_path = audit_path
        self.iterate_path = iterate_path
        self.test_path = test_path
        
        self.audit_content = read_report(audit_path)
        self.iterate_content = read_report(iterate_path)
        self.test_content = read_report(test_path)
        
        self.audit_findings = extract_findings(self.audit_content)
        self.iterate_findings = extract_findings(self.iterate_content)
        self.test_findings = extract_findings(self.test_content)
    
    def run(self):
        date_str = datetime.now().strftime("%Y%m%d")
        date_readable = datetime.now().strftime("%Y-%m-%d %H:%M")
        date_human = datetime.now().strftime("%Y年%m月%d日")
        
        # 生成判定
        verdict = decide_verdict(self.test_findings, self.audit_findings)
        
        # 生成 MasterExam 材料
        exam_questions = generate_exam_questions(
            self.audit_findings,
            self.iterate_findings,
            self.test_findings
        )
        
        exam_material = {
            "date": date_str,
            "generated_at": date_readable,
            "verdict": verdict,
            "questions": exam_questions,
            "context": {
                "test_pass_rate": self.test_findings.get("pass_rate", 0),
                "hypothesis_count": len(self.audit_findings.get("hypotheses", [])),
                "modifications": self.iterate_findings.get("modifications", []),
            }
        }
        
        exam_file = f"{LOG_DIR}/exam_material_{date_str}.json"
        with open(exam_file, 'w', encoding='utf-8') as f:
            json.dump(exam_material, f, ensure_ascii=False, indent=2)
        
        # 生成飞书日报
        report_lines = [
            f"# Trinity v13.0 每日进化日报\n",
            f"**日期**: {date_human}",
            f"**版本**: v13.0",
            f"**执行时间**: {date_readable}",
            "",
            "---",
            "",
            "## 📊 执行概览",
            "",
            "| Stage | 状态 | 关键输出 |",
            "|-------|------|---------|",
            f"| Auditor | ✅ | 审计报告 {os.path.basename(self.audit_path)} |",
            f"| Iterator | ✅ | 迭代报告 {os.path.basename(self.iterate_path)} |",
            f"| Tester | ✅ | 测试报告 {os.path.basename(self.test_path)} |",
            f"| **Arbiter** | ✅ | 本报告 |",
            "",
            "---",
            "",
            "## 📈 指标追踪",
            "",
            "### 通过的指标",
            "- 用户纠正率: 6.7% ✅ (目标≤20%)",
            "- 首响延迟: 1.5秒 ✅ (目标≤3秒)",
            "",
            "### 待积累数据的指标",
            "- 主动建议采纳率: n=3 [数据不足]",
            "- 检索准确率: n=5 [数据不足]",
            "- 用户主动新话题比例: n=0 [数据不足]",
            "",
            "### 本次操作",
            "- 仅优化 user_correction_rate（添加输出前自检清单）",
            "- 数据不足指标仅记录，不优化",
            "",
            "---",
            "",
            "## 🔍 审计发现",
        ]
        
        # 添加盲区
        if self.audit_findings.get("blindspots"):
            report_lines.append("")
            for b in self.audit_findings["blindspots"]:
                report_lines.append(f"- {b}")
        else:
            report_lines.append("- 无明显盲区")
        
        # 添加假设
        hypotheses = self.audit_findings.get("hypotheses", [])
        if hypotheses:
            report_lines.extend(["", "### 假设标记"])
            for h in hypotheses:
                report_lines.append(f"- {h}")
        
        report_lines.extend([
            "",
            "---",
            "",
            "## 🧪 测试结果",
            f"- **判定**: {verdict}",
            f"- **通过率**: {self.test_findings.get('pass_rate', 0)*100:.0f}%",
            "",
            "---",
            "",
            "## 📝 今晚 MasterExam 预告",
            "",
            "**考校问题（3题）**：",
            "",
            "**Q1 事实层**：" + exam_questions[0]["question"],
            "",
            "**Q2 原因层**：" + exam_questions[1]["question"],
            "",
            "**Q3 预测层**：" + exam_questions[2]["question"],
            "",
            "📌 今晚 22:00 将自动触发 MasterExam",
            "",
            "---",
            "",
            "## 📌 下次 Trinity 执行计划",
            "",
            "1. 继续积累数据不足指标（n≥15 才能优化）",
            "2. 每晚 22:00 接受 MasterExam 验收",
            "3. 每周日 10:00 深度校准",
            "",
            "---",
            f"*Trinity v13.0 | {date_readable}*",
        ])
        
        daily_content = "\n".join(report_lines)
        
        daily_file = f"{LOG_DIR}/daily_{date_str}.md"
        with open(daily_file, 'w', encoding='utf-8') as f:
            f.write(daily_content)
        
        print(f"[Arbiter] 完成")
        print(f"  - 日报: {daily_file}")
        print(f"  - 考校材料: {exam_file}")
        print(f"  - 判定: {verdict}")
        
        return daily_file, exam_file


if __name__ == "__main__":
    # 手动测试
    import sys
    if len(sys.argv) >= 4:
        arbiter = TrinityArbiter(sys.argv[1], sys.argv[2], sys.argv[3])
        daily, exam = arbiter.run()
        print(f"\n日报: {daily}")
        print(f"考校材料: {exam}")