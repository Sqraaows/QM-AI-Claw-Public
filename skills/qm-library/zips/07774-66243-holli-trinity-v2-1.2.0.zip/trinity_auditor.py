#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trinity v13.0 - Stage 1: Auditor 审计智能体
输入: 过去24小时交互 + 当前基线指标 + 昨日验收结果
任务: 对比基线，识别退化/进步/盲区，标记需要验证的假设
输出: audit_YYYYMMDD.md
"""
import os
import json
from datetime import datetime, timedelta
from glob import glob

LOG_DIR = "data/trinity_log"
os.makedirs(LOG_DIR, exist_ok=True)

# ===== 基线指标（从 MEMORY.md v1.1.1 提取） =====
BASELINE = {
    # 可信指标 (n>=15)
    "user_correction_rate": {"value": 0.067, "n": 15, "target": 0.20, "status": "可信"},
    # 初步指标 (10<=n<30)
    "one_shot_completion": {"value": 0.90, "n": 10, "target": 0.75, "status": "初步"},
    # 数据不足 (n<10)
    "proactive_adoption": {"value": None, "n": 3, "target": 0.60, "status": "数据不足"},
    "retrieval_accuracy": {"value": None, "n": 5, "target": 0.80, "status": "数据不足"},
    "new_topic_ratio": {"value": None, "n": 0, "target": 0.40, "status": "数据不足"},
    "surprise_rate": {"value": None, "n": 0, "target": 0.30, "status": "数据不足"},
    "constructive_disagreement": {"value": None, "n": 0, "target": 0.60, "status": "数据不足"},
    "first_response_delay": {"value": 1.5, "n": 0, "target": 3.0, "status": "系统监控"},
}

# PID 控制目标
PID_TARGETS = {
    "first_response_P": {"target": 3.0, "current": 1.5, "unit": "秒"},
    "cross_session_recall_I": {"target": 0.75, "current": None, "unit": "比例"},
    "prediction_hit_D": {"target": 0.65, "current": None, "unit": "比例"},
}

# MasterExam 验收结果（如果有的话）
EXAM_LOG_FILE = "data/trinity_log/exam_log_20260426.md"


def load_memory_files():
    """读取过去7天的 memory 文件"""
    memory_dir = "memory"
    files = sorted(glob(os.path.join(memory_dir, "2026-04-2*.md")))
    # 只取最近7天
    files = files[-7:]
    content = {}
    for f in files:
        with open(f, 'r', encoding='utf-8') as fp:
            name = os.path.basename(f)
            content[name] = fp.read()
    return content


def load_metrics_daily():
    """读取 metrics-daily.json 如果存在"""
    f = "data/metrics-daily.json"
    if os.path.exists(f):
        with open(f, 'r', encoding='utf-8') as fp:
            return json.load(fp)
    return {}


def load_exam_log():
    """加载昨日 MasterExam 验收结果"""
    if os.path.exists(EXAM_LOG_FILE):
        with open(EXAM_LOG_FILE, 'r', encoding='utf-8') as f:
            return f.read()
    return None


def analyze_gap(baseline, metrics):
    """对比基线与今日指标，识别退化/进步"""
    findings = []
    
    for key, info in baseline.items():
        current = info["value"]
        target = info["target"]
        status = info["status"]
        
        if current is None:
            continue
        
        # 计算达标率
        hit_rate = min(current / target, 1.0) if target > 0 else 0
        
        # 判断状态
        if status == "数据不足":
            state = "⏳ 数据不足"
        elif hit_rate >= 1.0:
            state = "✅ 达标"
        elif hit_rate >= 0.8:
            state = "🟡 接近"
        else:
            state = "🔴 差距"
        
        findings.append({
            "key": key,
            "current": current,
            "target": target,
            "hit_rate": hit_rate,
            "state": state,
            "status": status,
        })
    
    return findings


def scan_blindspots(memory_content, metrics):
    """扫描盲区：未触发知识节点、未满足需求"""
    blindspots = []
    
    # 检查是否缺少某些维度的交互记录
    has_deep_research = any("研究" in v or "分析" in v for v in memory_content.values())
    has_feishu = any("飞书" in v or "feishu" in v.lower() for v in memory_content.values())
    has_coding = any("code" in v.lower() or "代码" in v for v in memory_content.values())
    
    if not has_deep_research:
        blindspots.append("⚠️ 缺少深度研究类交互（行业研究、深度分析）")
    if not has_feishu:
        blindspots.append("⚠️ 缺少飞书相关交互（文档、知识库）")
    if not has_coding:
        blindspots.append("⚠️ 缺少代码任务交互")
    
    # 检查今日指标异常
    if metrics:
        recent = list(metrics.values())[-1] if metrics else {}
        if recent.get("corrections", 0) > 2:
            blindspots.append("⚠️ 今日纠正次数偏高，需关注质量")
    
    return blindspots


def check_exam_results(exam_log):
    """检查昨日 MasterExam 验收结果"""
    if not exam_log:
        return None
    
    findings = []
    if "验证通过" in exam_log or "✅" in exam_log:
        findings.append("昨日 MasterExam 全部通过")
    if "修正" in exam_log:
        findings.append("昨日 MasterExam 存在修正项")
    if "推翻" in exam_log:
        findings.append("昨日 MasterExam 存在推翻项，需能力回滚")
    
    return findings if findings else ["昨日 MasterExam 无异常"]


class TrinityAuditor:
    """Auditor 审计智能体"""
    
    def run(self):
        date_str = datetime.now().strftime("%Y%m%d")
        date_readable = datetime.now().strftime("%Y-%m-%d %H:%M")
        
        # Step 1: 数据收集
        memory_files = load_memory_files()
        metrics = load_metrics_daily()
        exam_log = load_exam_log()
        
        # Step 2: 差距分析
        gap_findings = analyze_gap(BASELINE, metrics)
        
        # Step 3: 盲区扫描
        blindspots = scan_blindspots(memory_files, metrics)
        
        # Step 4: MasterExam 反馈检查
        exam_findings = check_exam_results(exam_log)
        
        # Step 5: 生成假设标记
        hypotheses = []
        
        # 假设1：用户纠正率是否持续低位稳定
        corr_rate = BASELINE["user_correction_rate"]
        if corr_rate["n"] >= 15 and corr_rate["value"] < 0.10:
            hypotheses.append({
                "id": "H-1",
                "level": "P1",
                "statement": "用户纠正率长期<10%，表明基础准确性已稳定",
                "confidence": "B(80%)",
                "needs_verification": True
            })
        
        # 假设2：首响延迟
        first_resp = PID_TARGETS["first_response_P"]
        if first_resp["current"] and first_resp["current"] <= 2.0:
            hypotheses.append({
                "id": "H-2",
                "level": "P1",
                "statement": f"首响延迟 {first_resp['current']}s 已远优于目标 {first_resp['target']}s",
                "confidence": "A(95%)",
                "needs_verification": False
            })
        
        # 假设3：数据不足指标
        for key in ["proactive_adoption", "retrieval_accuracy", "new_topic_ratio"]:
            info = BASELINE[key]
            if info["n"] < 10:
                hypotheses.append({
                    "id": f"H-{key[:4]}",
                    "level": "P2",
                    "statement": f"{key} 样本不足(n={info['n']})，需积累数据后优化",
                    "confidence": "C(60%)",
                    "needs_verification": True
                })
        
        # 生成报告
        report_lines = [
            f"# Auditor 审计报告\n",
            f"**日期**: {date_readable}",
            f"**版本**: Trinity v13.0 Stage 1",
            "",
            "---",
            "",
            "## Step 1: 数据收集",
            f"- memory 文件数: {len(memory_files)}",
            f"- metrics-daily 条目: {len(metrics)}",
            f"- MasterExam 日志: {'有' if exam_log else '无'}",
            "",
            "### 读取的 memory 文件",
        ]
        for name in sorted(memory_files.keys()):
            report_lines.append(f"- {name}")
        
        report_lines.extend([
            "",
            "## Step 2: 差距分析",
            "",
            "| 指标 | 当前值 | 目标值 | 达标率 | 状态 | 样本 |",
            "|------|--------|--------|--------|------|------|",
        ])
        
        for f in gap_findings:
            hit_pct = f"{f['hit_rate']*100:.1f}%"
            report_lines.append(
                f"| {f['key']} | {f['current']} | {f['target']} | {hit_pct} | {f['state']} | n={BASELINE[f['key']]['n']} |"
            )
        
        report_lines.extend([
            "",
            "### PID 控制指标",
            "",
            "| 维度 | 当前值 | 目标 | 状态 |",
            "|------|--------|------|------|",
        ])
        
        for dim, info in PID_TARGETS.items():
            curr = info["current"] if info["current"] else "?"
            target = info["target"]
            if curr != "?" and target > 0:
                state = "✅" if curr <= target else "🔴"
            else:
                state = "⏳"
            unit = info["unit"]
            report_lines.append(f"| {dim} | {curr}{unit} | {target}{unit} | {state} |")
        
        report_lines.extend([
            "",
            "## Step 3: 盲区扫描",
        ])
        
        if blindspots:
            for b in blindspots:
                report_lines.append(f"- {b}")
        else:
            report_lines.append("- ✅ 无明显盲区")
        
        report_lines.extend([
            "",
            "## Step 4: MasterExam 反馈",
        ])
        
        if exam_findings:
            for e in exam_findings:
                report_lines.append(f"- {e}")
        else:
            report_lines.append("- 无昨日 MasterExam 记录")
        
        report_lines.extend([
            "",
            "## Step 5: 假设标记 (Hypotheses)",
            "",
            "| ID | 级别 | 声明 | 置信度 | 需验证 |",
            "|----|------|------|--------|--------|",
        ])
        
        for h in hypotheses:
            needs_v = "✅" if h["needs_verification"] else "❌"
            report_lines.append(
                f"| {h['id']} | {h['level']} | {h['statement']} | {h['confidence']} | {needs_v} |"
            )
        
        report_lines.extend([
            "",
            "## 输出状态",
            f"- 等待 Iterator: ✅ 是",
            f"- 假设数量: {len(hypotheses)}",
            f"- P0问题数: 0",
            f"- P1问题数: {sum(1 for h in hypotheses if h['level']=='P1')}",
            f"- P2问题数: {sum(1 for h in hypotheses if h['level']=='P2')}",
        ])
        
        report_content = "\n".join(report_lines)
        
        output_file = f"{LOG_DIR}/auditor_{date_str}.md"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        print(f"[Auditor] 完成: {output_file}")
        print(f"  - 指标差距分析: {len(gap_findings)} 项")
        print(f"  - 盲区: {len(blindspots)} 项")
        print(f"  - 假设: {len(hypotheses)} 条")
        
        return output_file


if __name__ == "__main__":
    auditor = TrinityAuditor()
    out = auditor.run()
    print(f"\n报告: {out}")