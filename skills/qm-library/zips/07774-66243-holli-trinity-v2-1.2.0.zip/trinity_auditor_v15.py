#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trinity v15.0 - Auditor Agent
职责：自检能力缺陷，生成阅读清单
输入：昨日测试反馈 + 当前状态
输出：能力缺陷列表 + 推荐阅读清单
"""
import os
import json
import re
from datetime import datetime
from glob import glob

class TrinityAuditorV15:
    """Auditor：自检能力缺陷"""
    
    def __init__(self):
        self.date_str = datetime.now().strftime("%Y%m%d")
        self.knowledge_graph_path = "memory/knowledge-graph.md"
        self.metrics_path = "data/metrics-daily.json"
    
    def run(self):
        # 1. 读取昨日测试反馈
        yesterday_feedback = self._load_yesterday_feedback()
        
        # 2. 自检能力缺陷
        gaps = self._identify_gaps(yesterday_feedback)
        
        # 3. 生成阅读清单
        reading_list = self._generate_reading_list(gaps)
        
        return {
            "gaps": gaps,
            "reading_list": reading_list,
            "yesterday_feedback": yesterday_feedback
        }
    
    def _load_yesterday_feedback(self):
        """加载昨日测试反馈"""
        yesterday = datetime.now()
        yesterday = yesterday.replace(day=yesterday.day - 1)
        yesterday_str = yesterday.strftime("%Y%m%d")
        
        path = f"data/trinity_log/闭环_{yesterday_str}.json"
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f).get("tester", {})
        return {}
    
    def _identify_gaps(self, yesterday_feedback):
        """自检能力缺陷"""
        gaps = []
        
        # 从昨日测试反馈识别缺陷
        if yesterday_feedback:
            verdict = yesterday_feedback.get("verdict", "")
            if "FAIL" in verdict or "部分" in verdict:
                gaps.append({
                    "type": "test_failure",
                    "desc": "昨日测试未通过，需要针对性提升",
                    "priority": "P0"
                })
            
            feedback = yesterday_feedback.get("feedback", [])
            for f in feedback:
                if "不足" in f or "缺乏" in f:
                    gaps.append({
                        "type": "feedback_based",
                        "desc": f,
                        "priority": "P1"
                    })
        
        # 检查知识图谱完整性
        if os.path.exists(self.knowledge_graph_path):
            with open(self.knowledge_graph_path, 'r', encoding='utf-8') as f:
                kg = f.read()
            
            # 检查关键知识领域
            required_domains = ["预判", "共情", "伦理", "记忆", "决策"]
            for domain in required_domains:
                if domain not in kg:
                    gaps.append({
                        "type": "knowledge_missing",
                        "desc": f"知识图谱缺少 {domain} 领域",
                        "priority": "P1"
                    })
        
        # 检查数据指标
        if os.path.exists(self.metrics_path):
            with open(self.metrics_path, 'r', encoding='utf-8') as f:
                metrics = json.load(f)
            
            # 检查样本量
            latest = list(metrics.values())[-1] if metrics else {}
            total_samples = sum([
                latest.get("corrections", 0),
                latest.get("proactive_suggestions", 0)
            ])
            
            if total_samples < 10:
                gaps.append({
                    "type": "data_insufficient",
                    "desc": f"数据样本不足 ({total_samples} < 10)",
                    "priority": "P2"
                })
        
        # 通用缺陷（如果没有昨日数据）
        if not gaps:
            gaps = [
                {"type": "general", "desc": "置信度校准能力", "priority": "P1"},
                {"type": "general", "desc": "跨会话记忆召回", "priority": "P1"},
                {"type": "general", "desc": "主动预判准确性", "priority": "P2"},
            ]
        
        # 去重
        seen = set()
        unique_gaps = []
        for g in gaps:
            key = g["desc"]
            if key not in seen:
                seen.add(key)
                unique_gaps.append(g)
        
        return unique_gaps
    
    def _generate_reading_list(self, gaps):
        """根据缺陷生成阅读清单"""
        reading_map = {
            "置信度": [
                {"book": "《思考，快与慢》", "author": "Kahneman", "topic": "系统思维与概率"},
                {"book": "《概率论与数理统计》", "author": "浙大", "topic": "贝叶斯基础"},
            ],
            "记忆": [
                {"book": "《认知心理学》", "author": "Sternberg", "topic": "工作记忆"},
                {"book": "《记忆的生物学》", "author": "Kandel", "topic": "记忆机制"},
            ],
            "预判": [
                {"book": "《预测科学》", "author": "Tetlock", "topic": "专家预测"},
                {"book": "《机器学习》", "author": "Mitchell", "topic": "监督学习"},
            ],
            "数据": [
                {"book": "《精益数据分析》", "author": "Croll", "topic": "指标体系"},
            ],
            "测试": [
                {"book": "《软件测试之道》", "author": "Myers", "topic": "测试用例"},
            ]
        }
        
        reading_list = []
        for gap in gaps:
            desc = gap["desc"]
            for key, items in reading_map.items():
                if key in desc:
                    for item in items:
                        reading_list.append({
                            "gap": desc,
                            "book": item["book"],
                            "author": item["author"],
                            "topic": item["topic"],
                            "priority": gap["priority"]
                        })
        
        # 默认添加
        if not reading_list:
            reading_list = [
                {"gap": "基础能力", "book": "《思考，快与慢》", "author": "Kahneman", "topic": "系统思维", "priority": "P1"}
            ]
        
        return reading_list


if __name__ == "__main__":
    auditor = TrinityAuditorV15()
    result = auditor.run()
    print(json.dumps(result, ensure_ascii=False, indent=2))