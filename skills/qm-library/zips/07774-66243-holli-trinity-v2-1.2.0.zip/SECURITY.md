# Trinity 安全配置文件

## 权限说明

Trinity 是一个**数据分析工具**，需要以下权限：

### 必需权限
| 权限 | 用途 | 风险 |
|------|------|------|
| 读取本地文件 | 读取交互记录、日志 | 低 |
| 写入本地文件 | 生成报告到 data/ 目录 | 低 |

### 不需要的权限
| 权限 | 状态 | 说明 |
|------|------|------|
| 网络访问 | ❌ 禁止 | 不访问外部网络 |
| 执行外部命令 | ❌ 禁止 | 不运行 shell 命令 |
| 下载文件 | ❌ 禁止 | 不下载任何内容 |
| 上传文件 | ❌ 禁止 | 不上传任何内容 |

## 运行模式

### 安全模式（默认）
```
- 只读取 ./data/ 和 ./memory/ 目录
- 只写入 ./data/trinity_log/ 目录
- 不执行任何网络请求
```

### 沙箱模式（可选）
```bash
# 在隔离目录中运行
mkdir /tmp/trinity-sandbox
cd /tmp/trinity-sandbox
python /path/to/trinity_v15.py

# 数据输出到 /tmp/trinity-sandbox/data/
```

## 目录权限

### 必需的目录结构
```
project/
├── data/
│   └── trinity_log/     # 输出报告（自动创建）
├── memory/              # 交互记录（可选）
├── SKILL.md             # 技能描述
├── SECURITY.md          # 本文件
└── requirements.txt     # 依赖
```

### 权限矩阵
| 目录 | 读 | 写 | 创建 |
|------|----|----|------|
| ./data/trinity_log/ | ✅ | ✅ | ✅ |
| ./memory/ | ✅ | ❌ | ❌ |
| ./skills/ | ✅ | ❌ | ❌ |
| 其他目录 | ❌ | ❌ | ❌ |

## 安全建议

### 1. 隔离运行
```bash
# 创建专用用户
sudo useradd -r -s /bin/false trinity

# 限制文件权限
chown -R trinity:trinity /path/to/trinity
chmod 500 /path/to/trinity/*.py
```

### 2. 审计日志
```bash
# 启用审计
echo "*.* /var/log/trinity.log" >> /etc/rsyslog.conf
systemctl rsyslog restart
```

### 3. 定期检查
```bash
# 每周检查日志
tail -100 /var/log/trinity.log

# 检查报告完整性
ls -la data/trinity_log/
```

## 漏洞报告

如发现安全问题，请联系：
- Email: [你的邮箱]
- GitHub Issue: [你的仓库]

响应时间：24小时内

## 版本历史

- v1.1.0: 添加安全配置说明
- v1.0.0: 初始版本