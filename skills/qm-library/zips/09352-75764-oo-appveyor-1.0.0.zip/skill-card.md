## Description: <br>
AppVeyor lets an agent read AppVeyor projects, deployment environments, team users, team roles, and build artifacts through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and CI/CD operators use this skill to inspect AppVeyor projects, deployment environments, team users, team roles, and build artifacts visible to an OOMOL-connected AppVeyor API token. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill reads AppVeyor data visible to the connected OOMOL account, including team users, roles, environments, projects, and build artifacts. <br>
Mitigation: Install it only for intended AppVeyor read access and review the AppVeyor token scopes before use. <br>
Risk: First-time setup may require installing the OOMOL oo CLI through a remote installer command. <br>
Mitigation: Verify OOMOL's official installation instructions before running the installer if the CLI is not already installed. <br>
Risk: Credential issues such as missing scopes, expired credentials, or disconnected apps can cause connector failures. <br>
Mitigation: Reconnect AppVeyor through OOMOL only when an action fails with the matching auth or connection error. <br>


## Reference(s): <br>
- [ClawHub AppVeyor skill page](https://clawhub.ai/oomol/oo-appveyor) <br>
- [AppVeyor homepage](https://www.appveyor.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [AppVeyor action reference: get_build_artifacts](actions/get_build_artifacts.md) <br>
- [AppVeyor action reference: get_environments](actions/get_environments.md) <br>
- [AppVeyor action reference: get_projects](actions/get_projects.md) <br>
- [AppVeyor action reference: get_role](actions/get_role.md) <br>
- [AppVeyor action reference: get_roles](actions/get_roles.md) <br>
- [AppVeyor action reference: get_users](actions/get_users.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses from the connector are JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
