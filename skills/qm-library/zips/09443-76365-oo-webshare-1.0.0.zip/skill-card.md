## Description: <br>
Webshare lets agents read connected Webshare account, proxy, proxy configuration, and hourly usage data through OOMOL's oo connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect a connected Webshare account, retrieve proxy configuration, list proxies, and review hourly proxy usage without handling raw Webshare API tokens directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected Webshare credential and can expose account, proxy, and usage data from that connection. <br>
Mitigation: Install it only for intended Webshare workflows, review connected-account permissions, and use the server-provided security guidance before deployment. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Webshare skill](https://clawhub.ai/oomol/oo-webshare) <br>
- [Webshare homepage](https://www.webshare.io/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_profile action](actions/get_profile.md) <br>
- [get_proxy_config action](actions/get_proxy_config.md) <br>
- [list_proxies action](actions/list_proxies.md) <br>
- [list_stats action](actions/list_stats.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill inspects live connector schemas before constructing payloads and returns connector responses as JSON data plus execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
