## Description: <br>
GIPHY helps agents search, retrieve, translate, and inspect GIFs, stickers, tags, categories, and trending content through the OOMOL `oo` CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate a connected GIPHY account for GIF and sticker discovery, including search, trending lists, random results, tag lookup, category lookup, and phrase-to-best-match translation. It is suited for workflows that need GIPHY metadata or media references without handling raw GIPHY API credentials directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected OOMOL/GIPHY account and can use sensitive credentials managed outside the agent. <br>
Mitigation: Install and run it only in an environment where that account access is intended; do not expose raw credentials to the agent. <br>
Risk: Connector schemas and upstream defaults can change, which may make stale payloads incorrect. <br>
Mitigation: Inspect the live action schema before constructing each action payload. <br>
Risk: Setup, connection, and billing commands can change account state or incur operational cost. <br>
Mitigation: Run setup or connection steps only after a matching auth, connection, or billing error, and confirm any state-changing action with the user. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/oomol/oo-giphy) <br>
- [GIPHY homepage](https://giphy.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Guidance, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses include connector data and an execution id when actions are run with `--json`.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
