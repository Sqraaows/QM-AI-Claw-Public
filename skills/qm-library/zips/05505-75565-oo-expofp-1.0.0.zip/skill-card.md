## Description: <br>
ExpoFP helps agents manage ExpoFP expos and exhibitors through OOMOL-connected oo CLI actions for reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operations teams, and event managers use this skill to manage ExpoFP expos and exhibitor records from an OOMOL-connected account. It supports listing expos and exhibitors, resolving and reading exhibitor details, and creating, updating, or deleting exhibitors after appropriate confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, and delete ExpoFP records when used with connected account credentials. <br>
Mitigation: Confirm exact payloads and intended effects before write actions, and require explicit user approval before destructive delete actions. <br>
Risk: The skill requires account access through an OOMOL-connected ExpoFP credential. <br>
Mitigation: Review the skill contents and future updates before granting credentials, write permissions, or authority to act on external services. <br>


## Reference(s): <br>
- [ExpoFP homepage](https://expofp.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-expofp) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Inspect live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
