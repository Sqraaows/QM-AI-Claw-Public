---
name: fundamental-analysis
description: 中国银河证券星耀数智A股基本面指标分析技能。当用户需要进行A股基本面分析、财务指标计算、盈利能力/成长性/估值/安全性等指标分析时使用此技能。支持90个基本面指标的计算，涵盖盈利能力、成长指标、营运效率、盈余质量、安全性、公司治理、估值、股东、规模共9大类。即使用户没有明确提到"基本面指标"，只要涉及A股财务分析、指标计算、ROE/PE/PB等指标分析，都应该使用此技能。
---

# A股基本面指标

## 概述

基本面指标分析，涵盖9大分类的90个基本面指标。

- **季频指标（67个）**：盈利能力(9) + 成长指标(21) + 营运效率(15) + 盈余质量(8) + 安全性(14)
- **日频指标（23个）**：公司治理(2) + 估值(12) + 股东(4) + 规模(5)


## 前置条件 - 安装库,设置 AmazingData 账号环境变量
使用本技能前，安装python运行环境(推荐python3.8/3.9/3.10/3.11/3.12/3.13环境)，并安装AmazingData依赖包。
从https://gitee.com/cgs2026/xysz/tree/master/xysz/xysz_tools下载tgw和AmazingData的安装包
```bash
pip install tgw>=1.0.8.7
pip install AmazingData>=1.1.4
```
使用本技能前，用户必须先设置以下环境变量（AmazingData 登录信息）：

```bash
# Windows CMD
set AD_USERNAME=your_username
set AD_PASSWORD=your_password
set AD_HOST=server_ip
set AD_PORT=8600

# Windows PowerShell
$env:AD_USERNAME="your_username"
$env:AD_PASSWORD="your_password"
$env:AD_HOST="server_ip"
$env:AD_PORT="8600"
```

如果用户未设置环境变量，脚本会报错提示缺少哪些变量。请引导用户先完成环境变量配置。

## 使用方法

通过 Bash 工具调用 `scripts/run_fundamental_analysis.py` 脚本（完全自包含，无外部依赖）：

```bash
# 综合分析（所有指标类别）
python scripts/run_fundamental_analysis.py 600***.SH

# 单类别分析
python scripts/run_fundamental_analysis.py 600***.SH --category profitability
python scripts/run_fundamental_analysis.py 600***.SH --category valuation

# 单指标查询
python scripts/run_fundamental_analysis.py 600***.SH --factor 净资产收益率TTM

# 指定K线日期范围（影响日频指标）
python scripts/run_fundamental_analysis.py 600***.SH --begin 20200101 --end 20260321

# 列出所有可用指标
python scripts/run_fundamental_analysis.py --list
```

### 可用的 category 参数

| category | 中文名 | 频率 | 指标数 |
|----------|--------|------|--------|
| profitability | 盈利能力 | 季频 | 9 |
| growth | 成长指标 | 季频 | 21 |
| efficiency | 营运效率 | 季频 | 15 |
| earnings_quality | 盈余质量 | 季频 | 8 |
| safety | 安全性 | 季频 | 14 |
| governance | 公司治理 | 日频 | 2 |
| valuation | 估值指标 | 日频 | 12 |
| shareholder | 股东指标 | 日频 | 4 |
| size | 规模指标 | 日频 | 5 |
| all | 全部 | 混合 | 90 |

## 分析输出格式

脚本输出 JSON 格式的结构化结果，包含：

```json
{
  "code": "600***.SH",
  "analysis_date": "2026-03-21",
  "categories": {
    "profitability": {
      "name": "盈利能力",
      "freq": "季频",
      "latest_period": "20240930",
      "latest_values": {"净资产收益率TTM": 0.25, "资产回报率TTM": 0.15},
      "history": [...]
    },
    "valuation": {
      "name": "估值指标",
      "freq": "日频",
      "latest_date": "2026-03-20",
      "latest_values": {"市盈率TTM": 25.5, "市净率": 8.2},
      "history": [...]
    }
  }
}
```

## 指标分类与公式（9大类90个指标）

### 1. 盈利能力指标（Profitability）— 9个，季频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 1 | 全部资产现金回收率TTM | 经营现金流净额TTM / 平均总资产 |
| 2 | 全部资产现金回收率变动 | 当期全部资产现金回收率TTM - 上期全部资产现金回收率TTM |
| 3 | 资产回报率TTM | 净利润TTM / 平均总资产 |
| 4 | 资产回报率变动 | 当期资产回报率TTM - 上期资产回报率TTM |
| 5 | 净资产收益率TTM | 净利润TTM / 平均净资产 |
| 6 | 净资产收益率变动 | 当期净资产收益率TTM - 上期净资产收益率TTM |
| 7 | 资本回报率TTM | 息前税后经营利润TTM / 平均投入资本（投入资本 = 股东权益 + 有息负债） |
| 8 | 资本回报率变动 | 当期资本回报率TTM - 上期资本回报率TTM |
| 9 | 税费负担占净资产比 | (当期应交税费 - 上年同期应交税费 + 缴纳税费现金流TTM) / 平均净资产 |

**关键计算细节：**
- 有息负债 = 短期借款 + 长期借款 + 应付债券 + 一年内到期非流动负债
- 息前税后经营利润 = EBIT_TTM x (1 - 有效税率)，有效税率 = 所得税TTM / 利润总额TTM，缺失时默认25%
- "变动"类指标使用安全差分，检查相邻报告期间隔是否为一个季度（75-110天）

### 2. 成长指标（Growth）— 21个，季频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 10 | 营业收入增速 | (当期营业收入 - 去年同期营业收入) / 去年同期营业收入 |
| 11 | 每股盈利 | 税后利润与股本总数的比率（优先用BASIC_EPS，fallback用净利润/总股本） |
| 12 | 每股盈利增速_单季度同比 | (本季度EPS - 去年同季度EPS) / 去年同季度EPS |
| 13 | 每股盈利增速_TTM同比 | (当期EPS_TTM - 去年同期EPS_TTM) / 去年同期EPS_TTM |
| 14 | 扣非净利润增速_TTM同比 | (当期扣非净利润TTM - 去年同期扣非净利润TTM) / 去年同期扣非净利润TTM |
| 15 | 净利润增速_单季度同比 | (本季度净利润 - 去年同季度净利润) / 去年同季度净利润 |
| 16 | 净利润增速_单季度环比 | (本季度净利润 - 上季度净利润) / 上季度净利润 |
| 17 | 净利润增速_TTM同比 | (当期净利润TTM - 去年同期净利润TTM) / 去年同期净利润TTM |
| 18 | 经营现金流增速_单季度环比 | (本季度经营现金流 - 上季度经营现金流) / 上季度经营现金流 |
| 19 | 经营现金流增速_单季度同比 | (本季度经营现金流 - 去年同季度经营现金流) / 去年同季度经营现金流 |
| 20 | 经营现金流增速_TTM同比 | (当期经营现金流TTM - 去年同期经营现金流TTM) / 去年同期经营现金流TTM |
| 21 | 营业利润增速_单季度同比 | (本季度营业利润 - 去年同季度营业利润) / 去年同季度营业利润 |
| 22 | 营业利润增速_单季度环比 | (本季度营业利润 - 上季度营业利润) / 上季度营业利润 |
| 23 | 营业利润增速_TTM同比 | (当期营业利润TTM - 去年同期营业利润TTM) / 去年同期营业利润TTM |
| 24 | 营业收入增速_单季度同比 | (本季度营业收入 - 去年同季度营业收入) / 去年同季度营业收入 |
| 25 | 营业收入增速_单季度环比 | (本季度营业收入 - 上季度营业收入) / 上季度营业收入 |
| 26 | 营业收入增速_TTM同比 | (当期营业收入TTM - 去年同期营业收入TTM) / 去年同期营业收入TTM |
| 27 | 净资产收益率增速_单季度同比 | (本季度ROE - 去年同季度ROE) / 去年同季度ROE |
| 28 | 净资产收益率增速_单季度环比 | (本季度ROE - 上季度ROE) / 上季度ROE |
| 29 | 净资产收益率增速_TTM同比 | (当期ROE_TTM - 去年同期ROE_TTM) / 去年同期ROE_TTM |
| 30 | 总资产增速 | (当期总资产 - 去年同期总资产) / 去年同期总资产 |

**关键计算细节：**
- 扣非净利润：优先使用 `NET_PRO_AFTER_DED_NR_GL`，若全NaN则用 净利润 - 营业外收入 + 营业外支出 估算
- 单季度EPS：优先用 `BASIC_EPS` 的单季度值，fallback用 单季度净利润 / 总股本
- 同比（YoY）按 `REPORTING_PERIOD` 匹配去年同期；环比（QoQ）按 `REPORTING_PERIOD` 匹配上一报告期；增长率分母使用基期值绝对值

### 3. 营运效率指标（Efficiency）— 15个，季频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 31 | 资产周转率TTM | 营业收入TTM / 平均总资产 |
| 32 | 资产周转率变动 | 当期资产周转率TTM - 上期资产周转率TTM |
| 33 | 毛利率变动 | 当期毛利率TTM - 上期毛利率TTM |
| 34 | 存货周转率TTM | 营业成本TTM / 滚动四季度存货平均余额 |
| 35 | 存货周转率变动 | 当期存货周转率TTM - 上期存货周转率TTM |
| 36 | 净利率TTM | 净利润TTM / 营业收入TTM |
| 37 | 营业利润率TTM | 营业利润TTM / 营业收入TTM |
| 38 | 营业利润率变动 | 当期营业利润率TTM - 上期营业利润率TTM |
| 39 | 营业利润比毛利润 | 营业利润TTM / 毛利润TTM |
| 40 | 应收周转率TTM | 营业收入TTM / 滚动四季度应收项目平均余额（应收项目 = 应收账款 + 应收票据） |
| 41 | 应收周转率变动 | 当期应收周转率TTM - 上期应收周转率TTM |
| 42 | 财务费用率TTM | 财务费用TTM / 营业收入TTM |
| 43 | 财务费用率变动 | 当期财务费用率TTM - 上期财务费用率TTM |
| 44 | 销售费用率TTM | 销售费用TTM / 营业收入TTM |
| 45 | 销售费用率变动 | 当期销售费用率TTM - 上期销售费用率TTM |

**关键计算细节：**
- 毛利率TTM = (营业收入TTM - 营业成本TTM) / 营业收入TTM
- 滚动四季度存货平均余额 = TTM期初及四个季末存货余额的平均值；数据不足时回退为期初期末2点平均，仍不足时回退为期末存货余额
- 滚动四季度应收项目平均余额 = TTM期初及四个季末应收项目余额的平均值；数据不足时回退为期初期末2点平均，仍不足时回退为期末应收项目余额

### 4. 盈余质量指标（Earnings Quality）— 8个，季频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 46 | 应计利润占比 | (营业利润TTM - 经营现金流TTM) / 营业利润TTM |
| 47 | 应计利润占比变动 | 当期应计利润占比 - 上期应计利润占比 |
| 48 | 现金比率 | 现金及现金等价物余额 / 流动负债 |
| 49 | 现金比率变动 | 当期现金比率 - 上期现金比率 |
| 50 | 经营现金流比营业收入 | 经营现金流TTM / 营业收入TTM |
| 51 | 经营现金流比营业收入变动 | 当期比率 - 上期比率 |
| 52 | 经营现金流比营业利润 | 经营现金流TTM / 营业利润TTM |
| 53 | 经营现金流比营业利润变动 | 当期比率 - 上期比率 |

**关键计算细节：**
- 现金比率优先使用现金流量表的 `END_BAL_CASH_CASH_EQU`，不可用时回退到资产负债表的 `CURRENCY_CAP`（货币资金）

### 5. 安全性指标（Safety）— 14个，季频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 54 | 流动负债占比 | 流动负债 / 总负债 |
| 55 | 流动负债占比变动 | 当期流动负债占比 - 上期流动负债占比 |
| 56 | 长期负债占比 | 非流动负债 / 总负债 |
| 57 | 长期负债占比变动 | 当期长期负债占比 - 上期长期负债占比 |
| 58 | 现金流动负债比率 | 经营净现金流TTM / 流动负债 |
| 59 | 现金流动负债比率变动 | 当期比率 - 上期比率 |
| 60 | 流动比率 | 流动资产 / 流动负债 |
| 61 | 流动比率变动 | 当期流动比率 - 上期流动比率 |
| 62 | 资产负债率变动 | 当期资产负债率 - 上期资产负债率 |
| 63 | 资产负债比 | 总负债 / 总资产 |
| 64 | 产权比率 | 总负债 / 归母股东权益 |
| 65 | 产权比率变动 | 当期产权比率 - 上期产权比率 |
| 66 | 速动比率 | (流动资产 - 存货 - 预付款项 - 待摊费用) / 流动负债 |
| 67 | 速动比率变动 | 当期速动比率 - 上期速动比率 |

### 6. 公司治理指标（Governance）— 2个，日频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 68 | 流通股占比 | 流通A股 / 总股本（按CHANGE_DATE前向填充到交易日） |
| 69 | 股利支付率 | 每股分红 x 基准股本 / 对应报告期净利润（按公告日pit填充到交易日） |


### 7. 估值指标（Valuation）— 12个，日频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 70 | 市净率 | 总市值 / 净资产 |
| 71 | 市现率 | 总市值 / 经营活动现金流量 |
| 72 | 市盈率 | 总市值 / 净利润 |
| 73 | 股息率 | 最近一期已实施每股分红 x 基准股本 / 总市值 |
| 74 | 市销率 | 总市值 / 营业收入 |
| 75 | 市现率TTM | 总市值 / 经营现金流TTM |
| 76 | 市盈率TTM | 总市值 / 净利润TTM |
| 77 | 股息率TTM | 过去365天已实施现金分红总额 / 总市值 |
| 78 | 市销率TTM | 总市值 / 营业收入TTM |
| 79 | 自由现金流TTM比总市值 | 自由现金流TTM / 总市值 |
| 80 | 净现金流TTM比总市值 | 现金及现金等价物净增加额TTM / 总市值 |
| 81 | 市盈率相对盈利增长率 | PE_TTM / (净利润TTM同比增长率 x 100) |

**关键计算细节：**
- 总市值 = 收盘价(不复权) x 总股本 x 10000（总股本单位万股）
- 财务数据通过 point-in-time (pit) 前向填充到每个交易日，避免未来函数
- 股息率TTM按派息日确认过去365天已实施现金分红总额
- PEG中的增长率按日历日期精确匹配去年同日TTM值计算

### 8. 股东指标（Shareholder）— 4个，日频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 82 | 股东数目时序标准分数 | (披露期股东数目 - 历史披露期expanding均值) / 历史披露期expanding标准差，再pit填充到交易日 |
| 83 | 持仓机构个数 | 先按股东性质筛选机构股东，再按HOLDER_ENDDATE统计数量（pit填充到交易日） |
| 84 | 持仓机构个数变化 | 当期机构股东个数 - 上期机构股东个数 |
| 85 | 十大股东占比分散度 | 十大股东各自持仓占比的标准差（pit填充到交易日） |

### 9. 规模指标（Size）— 5个，日频

| 编号 | 指标名称 | 计算公式 |
|------|----------|----------|
| 86 | 流通市值 | 收盘价 x 流通A股 x 10000 |
| 87 | 流通市值比总市值 | 流通市值 / 总市值 |
| 88 | 流通市值对数 | ln(流通市值) |
| 89 | 总市值对数 | ln(总市值) |
| 90 | 总市值 | 收盘价 x 总股本 x 10000 |

## 核心辅助函数说明

| 函数 | 功能 | 说明 |
|------|------|------|
| `safe_div(a, b)` | 安全除法 | 分母为0或NaN时返回NaN |
| `get_ttm(df, field)` | 计算TTM（滚动12个月累计值） | Q4直接取年报值；Q1/Q2/Q3 = 当期 + 去年年报 - 去年同期 |
| `get_single_quarter(df, field)` | 计算单季度值 | Q1直接取值；Q2=Q2累计-Q1累计；Q3=Q3累计-Q2累计；Q4=年报-Q3累计 |
| `_yoy(s)` | 同比增速 | 按 `REPORTING_PERIOD` 匹配去年同期，分母使用基期值绝对值 |
| `_qoq(s)` | 环比增速 | 按 `REPORTING_PERIOD` 匹配上一报告期，分母使用基期值绝对值 |
| `_ttm_yoy(s)` | TTM同比增速 | 按 `REPORTING_PERIOD` 匹配去年同期TTM值，分母使用基期值绝对值 |
| `_safe_diff(series, rp_index)` | 安全差分 | 检查相邻报告期间隔（75-110天），超出则返回NaN |
| `_filter_statements(df)` | 过滤财务报表 | 只保留合并报表（STATEMENT_TYPE='1'），同一报告期取最新记录 |
| `_prep(bs, inc, cf)` | 预处理三表 | 过滤、排序、去重 |
| `_safe_col(df, col, default)` | 安全获取列 | 列不存在返回默认值 |
| `_pit_fill(fin_df, field, trade_dates)` | Point-in-time前向填充 | 按ACTUAL_ANN_DATE映射季频财务数据到每个交易日，避免未来函数 |
| `_equity_pit(equity_structure, code, field, trade_dates)` | 股本结构pit填充 | 按CHANGE_DATE前向填充到交易日 |
| `_ts_pit(date_index, value_series, trade_dates)` | 通用pit填充 | 任意日期索引+值前向填充到交易日序列 |

## 数据依赖

### 必需的AmazingData API调用

| 数据 | API函数 | 用途 |
|------|---------|------|
| 资产负债表 | `info_data.get_balance_sheet(code_list)` | 盈利/成长/效率/安全性等季频指标 |
| 利润表 | `info_data.get_income(code_list)` | 盈利/成长/效率/盈余质量等季频指标 |
| 现金流量表 | `info_data.get_cash_flow(code_list)` | 盈利/成长/盈余质量/安全性等季频指标 |
| 股本结构 | `info_data.get_equity_structure(code_list)` | 估值/规模/治理指标（总股本、流通股） |
| 分红数据 | `info_data.get_dividend(code_list)` | 股息率/股利支付率 |
| 股东户数 | `info_data.get_holder_num(code_list)` | 股东数目时序标准分数 |
| 十大股东 | `info_data.get_share_holder(code_list)` | 持仓机构/十大股东分散度 |
| K线行情 | `market_data.query_kline(code_list, ...)` | 估值/规模指标（收盘价、交易日序列） |
| 交易日历 | `base_data.get_calendar(market='SZ')` | MarketData初始化 |

### 财务报表关键字段

**资产负债表（Balance Sheet）：**
`TOTAL_ASSETS`, `TOT_SHARE_EQUITY_EXCL_MIN_INT`, `TOT_SHARE_EQUITY_INCL_MIN_INT`, `ST_BORROWING`, `LT_LOAN`, `BONDS_PAYABLE`, `NONCUR_LIAB_DUE_WITHIN_1Y`, `TOTAL_CUR_LIAB`, `TOTAL_CUR_ASSETS`, `TOTAL_NONCUR_LIAB`, `TOTAL_LIAB`, `INV`, `ACCT_RECEIVABLE`, `NOTES_RECEIVABLE`, `PREPAYMENT`, `CURRENCY_CAP`, `TAX_PAYABLE`, `TOT_SHARE`, `UNAMORTIZED_EXP`

**利润表（Income Statement）：**
`NET_PRO_EXCL_MIN_INT_INC`, `NET_PRO_AFTER_DED_NR_GL`, `OPERA_REV`, `OPERA_PROFIT`, `LESS_OPERA_COST`, `LESS_FIN_EXP`, `LESS_SELLING_EXP`, `EBIT`, `INCOME_TAX`, `TOTAL_PROFIT`, `BASIC_EPS`, `NON_OPER_INCOME`, `NON_OPER_EXP`

**现金流量表（Cash Flow）：**
`NET_CASH_FLOWS_OPERA_ACT`, `PAY_ALL_TAX`, `END_BAL_CASH_CASH_EQU`, `FREE_CASH_FLOW`, `NET_INCR_CASH_AND_CASH_EQU`

## 注意事项

1. **Point-in-time原则**：日频指标严格按公告日（ACTUAL_ANN_DATE）前向填充，避免未来函数偏差
2. **合并报表过滤**：只使用STATEMENT_TYPE='1'的合并报表数据，同一报告期取最新公告日的记录
3. **安全除法**：所有除法运算使用`safe_div`，分母为0或NaN返回NaN
4. **报告期间隔检查**：变动类指标使用`_safe_diff`，相邻报告期间隔须在75-110天内
5. **数据缺失处理**：字段缺失时使用`_safe_col`返回NaN序列，不影响其他指标计算
6. **股本单位**：AmazingData中总股本单位为万股，计算市值时需乘以10000
