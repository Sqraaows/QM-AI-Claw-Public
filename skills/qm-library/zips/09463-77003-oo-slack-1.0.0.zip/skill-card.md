## Description: <br>
Operate Slack through an OOMOL-connected account for reading workspace data and creating, updating, scheduling, or deleting Slack messages. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, operators, and developers use this skill to inspect Slack channels, users, conversations, messages, and threads, and to perform approved message actions through a connected Slack bot. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The connected Slack bot can read workspace data that granted Slack scopes make visible. <br>
Mitigation: Review the requested Slack scopes during connection and install only in workspaces where that access is acceptable. <br>
Risk: Posting, updating, scheduling, or deleting messages can change Slack state or remove bot-owned content. <br>
Mitigation: Require explicit user confirmation of the target, payload, and intended effect before running write or destructive actions. <br>


## Reference(s): <br>
- [Slack Homepage](https://slack.com) <br>
- [ClawHub Slack Skill](https://clawhub.ai/oomol/oo-slack) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing Slack action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
