## Description: <br>
Operates Vapi through an OOMOL-connected account for reading, creating, updating, and deleting Vapi resources. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Vapi resources through an OOMOL-connected account, including assistants, calls, chats, sessions, phone numbers, evaluations, scorecards, files, analytics, monitoring policies, and provider resources. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, and delete Vapi resources through a connected account. <br>
Mitigation: Use it only with a Vapi account the user trusts it to manage, confirm write payloads before execution, and require explicit approval for destructive actions. <br>
Risk: The skill exposes a Vapi TypeScript code-tool test action. <br>
Mitigation: Install only when code-tool testing is needed, and require explicit user approval before running that action. <br>
Risk: The skill requires sensitive credentials through the connected Vapi account. <br>
Mitigation: Rely on the OOMOL connection flow and avoid exposing or manually handling raw credentials in prompts or command payloads. <br>


## Reference(s): <br>
- [ClawHub Vapi Skill](https://clawhub.ai/oomol/oo-vapi) <br>
- [Vapi Homepage](https://vapi.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payloads.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses depend on live Vapi connector schemas and command results.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
