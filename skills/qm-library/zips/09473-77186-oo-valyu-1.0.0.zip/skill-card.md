## Description: <br>
Valyu lets agents search and read web, academic, financial, and proprietary data sources through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to query Valyu search through the OOMOL oo CLI, including schema inspection before constructing action payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Setup guidance includes a downloaded installer script run directly in the shell. <br>
Mitigation: Install the oo CLI through a trusted, verified method and confirm setup, sign-in, and connection steps before execution. <br>
Risk: Valyu queries run through the OOMOL connector and may consume OOMOL credits. <br>
Mitigation: Use the skill only with an intended OOMOL-connected Valyu account and review searches before running them. <br>


## Reference(s): <br>
- [Valyu homepage](https://valyu.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [Search action reference](actions/search.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the live connector schema before payload construction; command output is returned as JSON by the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
