## Description: <br>
Vestaboard helps agents read the current Vestaboard message, send new messages, and manage transition settings through the OOMOL Vestaboard connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate a connected Vestaboard account, including reading displayed content, sending messages, and updating transition style or speed. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Vestaboard account through OOMOL, so commands depend on trusted account access and server-side credential handling. <br>
Mitigation: Install only if you trust OOMOL, keep the account connection scoped to the intended Vestaboard use, and retry setup steps only after an authentication or connection failure. <br>
Risk: Sending messages or changing transition settings alters what the Vestaboard displays. <br>
Mitigation: Confirm the exact payload and intended display effect with the user before running write actions such as send_message or set_transition. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each JSON payload. <br>


## Reference(s): <br>
- [ClawHub Vestaboard Skill](https://clawhub.ai/oomol/oo-vestaboard) <br>
- [Vestaboard Homepage](https://www.vestaboard.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>
- [OOMOL Vestaboard Connection](https://console.oomol.com/app-connections?provider=vestaboard) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the oo CLI to inspect connector schemas and run Vestaboard actions with JSON input.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
