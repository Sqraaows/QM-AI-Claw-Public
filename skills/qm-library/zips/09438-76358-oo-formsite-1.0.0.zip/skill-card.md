## Description: <br>
Formsite lets agents operate Formsite through an OOMOL-connected account to read forms and results and manage webhooks with the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to run Formsite connector actions through an OOMOL-connected account, including listing forms, reading item definitions and results, and managing webhooks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through a connected Formsite account. <br>
Mitigation: Use only OOMOL and Formsite credentials authorized for the task, and reconnect or refresh access only when an authentication or connection error requires it. <br>
Risk: Webhook creation, update, and deletion can change or remove Formsite configuration. <br>
Mitigation: Inspect the live action schema before constructing payloads, then confirm the exact payload, target, and intended effect before running write or delete actions. <br>
Risk: Server security evidence reports a suspicious verdict because bundled workflow helpers include a review helper that can run nested Codex with broad filesystem access and approval bypass. <br>
Mitigation: Review the helper before installing or invoking it, use --no-yolo or AUTOREVIEW_YOLO=0 unless broad filesystem access is intentional, and use only credentials appropriate for the described account and publishing actions. <br>


## Reference(s): <br>
- [Formsite homepage](https://www.formsite.com) <br>
- [ClawHub Formsite skill page](https://clawhub.ai/oomol/oo-formsite) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands call the oo CLI and return JSON connector responses containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
