---
name: go-cli-workflow
description: "Go CLI 工具从开发到发布的完整工作流。用于：(1) 从需求到交付的全流程管理，(2) 用 brainstorming 确认需求，(3) 用 cli-developer 设计架构并实现，(4) 用 gitee-cli 发布到 Gitee。前置条件：Go 工具链、gitee-cli 已安装。NOT for: 非 Go 项目、GitHub 发布。gitee-cli 安装：https://gitee.com/andershsueh/gitee-cli"
---

# Go CLI 开发工作流

## 技能调用链

```
用户提需求
  ↓
brainstorming ─── 只做需求确认
  ↓
cli-developer ─── 架构 + 实现（严格按 5 步流程）
  ↓
gitee-cli ────── 发布（仅 Gitee）
```

## 前置条件

- **Go 工具链**：`go version` 可运行
- **gitee-cli**：`gitee auth status` 已验证

## 流程

### 1. brainstorming — 需求确认

加载 `references/brainstorming/SKILL.md`，只做需求确认，不碰架构和设计。

- 锁定工具定位、目标用户、核心功能
- 锁定技术栈（强制 Go）
- 一次问一个问题，逐步收敛

输出需求文档到 `docs/requirements/YYYY-MM-DD-<name>.md`

### 2. cli-developer — 架构与实现

加载 `references/cli-developer/SKILL.md`，严格按 5 步流程执行：

1. **Analyze UX** — 分析用户工作流
2. **Design commands** — 设计子命令、标志、配置
3. **Implement** — 用 Go 实现
4. **Polish** — 补全、帮助文本、错误处理
5. **Test** — 跨平台测试

需要时加载 `references/cli-developer/references/go-cli.md`（Cobra/Viper 实现）和 `references/cli-developer/references/design-patterns.md`（架构）。

### 3. gitee-cli — 发布

加载 `references/gitee-cli/SKILL.md`。

强制三种分发方式：

| 方式 | 说明 |
|------|------|
| 管道安装 | `curl ... install.sh \| sh` |
| 源码构建 | `git clone + make build` |
| Go 安装 | `go install ...@latest` |

## 核心原则

**遇到不确定的事，问开发者。** 版本号、tag 名称、功能取舍、API 报错、权限问题 — 不擅自决定。
