## Description: <br>
Operate Alibaba Cloud OSS through the OOMOL `aliyun_oss` connector to list buckets and objects, inspect object metadata, upload objects, generate pre-signed URLs, and delete objects. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to manage Alibaba Cloud OSS resources through a connected OOMOL account. It supports common storage tasks such as browsing buckets, inspecting object metadata, uploading content, generating pre-signed URLs, and deleting objects. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Upload actions change Alibaba Cloud OSS state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: Delete actions can permanently remove OSS objects. <br>
Mitigation: Confirm the target object and get explicit user approval before running destructive actions. <br>
Risk: Pre-signed URLs can grant access to OSS objects. <br>
Mitigation: Limit the method, object, and expiration to the user's request and share generated URLs only with intended recipients. <br>
Risk: The security scan notes possible cross-session local memory behavior. <br>
Mitigation: Review local storage and MCP configuration and avoid storing sensitive information unless reuse in later sessions is acceptable. <br>


## Reference(s): <br>
- [Alibaba Cloud OSS homepage](https://www.alibabacloud.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-aliyun-oss) <br>


## Skill Output: <br>
**Output Type(s):** [Text guidance, Markdown, Shell commands, Configuration guidance] <br>
**Output Format:** [Markdown guidance with inline bash commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector actions return JSON responses when executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
