# 批量优化示例

## 场景

批量优化5个技能，目标平均85分+。

## Phase 0: 初始化

- 范围：skill-a, skill-b, skill-c, skill-d, skill-e
- 备份：每个skill创建 `{name}-backup-20260515.zip`
- 分支：`skills-optimization-pro/20260515-batch-001`

## Phase 1: 诊断

| 技能 | 评分 | 最低维度 | 反模式 | 子路由 |
|------|------|---------|--------|--------|
| skill-d | 54 | 资源整合度(2) | AP-3/AP-5/AP-11 | 强制重组(<60) |
| skill-b | 63 | 资源整合度(3) | AP-3/AP-5 | 精练优化 |
| skill-a | 71 | 资源整合度(4) | AP-5 | 精练优化 |
| skill-e | 71 | 资源整合度(4) | AP-5 | 精练优化 |
| skill-c | 80 | 检查点(6) | AP-10 | 精练优化 |

## Phase 2: 优化（按分数从低到高）

| 技能 | 路径 | 轮1 | 轮2 | 轮3 | 最终 |
|------|------|------|------|------|------|
| skill-d | 重组 | +4(Reviewer) | +4(Inversion) | +4(Reviewer) | 66(+12) |
| skill-b | 精练 | +4(Reviewer) | +4(Inversion) | +4(Reviewer) | 75(+12) |
| skill-a | 精练 | +4(Reviewer) | +4(Inversion) | +4(Reviewer) | 83(+12) |
| skill-e | 精练 | +4(Reviewer) | +4(Inversion) | +4(Reviewer) | 83(+12) |
| skill-c | 精练 | +4(Inversion) | +4(Reviewer) | +2(Reviewer) | 90(+10) |

## Phase 3: 验证

| 技能 | 前 | 后 | Δ | 模式 |
|------|----|----|----|------|
| skill-d | 54 | 66 | +12 | Reviewer, Inversion |
| skill-b | 63 | 75 | +12 | Reviewer, Inversion |
| skill-a | 71 | 83 | +12 | Reviewer, Inversion |
| skill-e | 71 | 83 | +12 | Reviewer, Inversion |
| skill-c | 80 | 90 | +10 | Reviewer, Inversion |
| **平均** | **67.8** | **79.4** | **+11.6** | |

## Phase 4: 汇总

- 优化5个技能，15轮实验，100%保留
- 跨技能发现：资源整合度是最常见短板(4/5)
- 全局建议：新建技能时优先补充资源引用和检查点
