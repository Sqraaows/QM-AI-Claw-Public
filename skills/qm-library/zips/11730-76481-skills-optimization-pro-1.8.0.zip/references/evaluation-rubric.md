# 评估标准 Checklist

## 结构维度（60分）

### 1. Frontmatter质量（8分）
- [ ] name 规范（小写+连字符，≤64字符）
- [ ] description 含做什么+何时用+触发词，≤1024字符
- [ ] version 使用语义化版本，引号包围
- [ ] tags 含中英文关键词，≤10个
- [ ] YAML 格式正确

### 2. 工作流清晰度（15分）
- [ ] 步骤有序号
- [ ] 每步有明确输入/输出
- [ ] 步骤间连接清晰
- [ ] 有 Phase/Step 结构

### 3. 边界条件覆盖（10分）
- [ ] 处理文件不存在
- [ ] 处理格式错误
- [ ] 处理网络错误
- [ ] 有 fallback 路径
- [ ] 有错误恢复机制

### 4. 检查点设计（7分）
- [ ] 关键决策前有用户确认
- [ ] 防止自主失控
- [ ] 确认方式明确

### 5. 指令具体性（15分）
- [ ] 指令明确无歧义
- [ ] 有具体参数说明
- [ ] 有格式说明
- [ ] 有操作示例
- [ ] 可直接执行

### 6. 资源整合度（5分）
- [ ] references 引用正确
- [ ] 路径可达
- [ ] 资源完整

## 效果维度（40分）

### 7. 整体架构（15分）
- [ ] 结构层次清晰
- [ ] 无冗余内容
- [ ] 无遗漏内容
- [ ] 设计模式应用合理

### 8. 实测表现（25分）
- [ ] 测试 prompt 覆盖典型场景
- [ ] with_skill 输出优于 baseline
- [ ] 无 skill 引入的负面影响
- [ ] 输出符合 skill 宣称能力

## 评分计算

总分 = Σ(维度1-10分 × 权重) / 10，满分100

## 评分原则

1. **独立性**：效果维度必须用子agent评估
2. **一致性**：保持评分尺度一致，记录理由
3. **客观性**：基于事实评分，提供具体证据
4. **可追溯性**：记录评分过程，支持复核

## 反模式关键词自动检测

| AP | 自动检测关键词/规则 |
|----|-------------------|
| AP-1 God Skill | SKILL.md行数>500 或 description含3+不相关功能词 |
| AP-2 Vague Instruction | 步骤含"处理"/"优化"/"改进"后无具体动作动词（≤5字内无细化） |
| AP-3 Missing Fallback | 全文无"如果"/"异常"/"fallback"/"错误"/"失败" |
| AP-4 Trigger Blind | frontmatter无triggers字段 或 triggers列表<3 |
| AP-5 Checkpoint Absent | 全文无"确认"/"同意"/"是否"/"选择" |
| AP-6 Copy-Paste Drift | description关键词与工作流标题重合率<30% |
| AP-7 Over-Constrained | "DO NOT"/"禁止"/"不得"出现>10次 |
| AP-8 Zombie Reference | references/路径在文件系统中不存在 |
| AP-9 Version Stale | frontmatter version与最新CHANGELOG版本不一致 |
| AP-10 Monologue Skill | 全文无"询问"/"确认"/"选择"/"用户"/"你" |
| AP-11 Silent Failure | 有异常处理但无日志/通知/恢复动作描述 |
| AP-12 Ghost Dependency | 工作流引用未在frontmatter/references声明的工具或文件 |
| AP-13 Magic Number | 出现硬编码阈值（如>500, <3）但无注释解释来源 |

检测优先级：critical > high > medium > low。AP-1/AP-11为最高优先检测项。
