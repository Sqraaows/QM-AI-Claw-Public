# 最佳实践速查

## Frontmatter
- name：小写+连字符，≤64字符
- description：做什么+何时用+触发词，≤1024字符
- version：语义化版本，引号包围（如 "1.0.0"）
- tags：中英文关键词，≤10个

## 工作流
- 使用 Phase/Step 结构，有序号
- 每步有明确输入/输出
- 标明检查点

## 边界条件
- 识别可能异常 → 设计处理方案 → 提供 fallback 路径 → 实现错误恢复
- 检查输入参数有效性，提供错误提示

## 检查点
- 关键决策前设置用户确认
- 限制自动操作范围，提供回滚机制

## 指令具体性
- 提供具体参数、格式说明、操作示例
- 确保可直接执行

## 资源整合
- 使用相对路径，路径正确可达
- 合理组织目录结构（references/ templates/ examples/）

## 版本管理
- 使用语义化版本（major.minor.patch）
- 每次优化记录 CHANGELOG
- 使用 git revert 回滚，不用 reset --hard

## 评估
- 使用独立子agent评估效果维度
- 对比 with_skill vs baseline
- 记录评分理由，支持复核
