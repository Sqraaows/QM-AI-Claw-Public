# 设计模式参考

## 模式选择决策树

```
技能需要调用外部工具/API？ → Tool Wrapper
技能生成内容（代码/文档/配置）？ → Generator
技能进行审查/检查/评估？ → Reviewer
技能需要用户输入/决策？ → Inversion
技能包含多个处理阶段？ → Pipeline
2+类型组合？ → 主模式 + 辅模式
```

## 模式详解

### Tool Wrapper（工具封装）
- 统一接口调用外部工具/API
- 标准化参数传递、统一错误处理、明确输入输出契约
- 适用：认证处理、错误重试、格式转换

### Generator（生成器）
- 模板加载 + 变量收集 → 结构化输出
- 模板加载机制、变量收集流程、输出格式规范
- 适用：代码生成、文档生成、配置生成

### Reviewer（审查者）
- severity 级别 + checklist 加载 → 评估报告
- 严重等级分类（critical/high/medium/low）、检查清单、结构化输出
- 适用：代码审查、质量评估、安全检查

### Inversion（控制反转）
- gating questions → 用户确认 → 执行
- 门控问题设计、用户偏好收集、交互式决策点
- 适用：需要用户输入、需要用户确认、收集用户偏好

### Pipeline（流水线）
- stage1 检查点 → stage2 处理 → stage3 输出 → 质量验证
- 阶段 checkpoint、进度可视化、阶段性确认
- 适用：多阶段任务、需要进度追踪

## 模式组合

| 组合 | 适用场景 |
|------|---------|
| Generator + Pipeline | 内容生成的多阶段任务 |
| Reviewer + Pipeline + Inversion | 审核检查+用户确认 |
| Tool Wrapper + Generator | 工具调用+内容生成 |

## 模式应用案例

| 模式 | 应用技能 | 场景 | 效果 |
|------|---------|------|------|
| Pipeline | api-test-automation | 设计→执行→报告三阶段 | 评分65.6→85+，+19.4分 |
| Inversion | api-test-automation | 三重门控(设计/执行/报告) | 消除AP-5/AP-10，门控0→3 |
| Tool Wrapper | api-test-automation | navigate_json_path统一封装 | 消除重复代码，错误处理统一 |
| Pipeline + Inversion | skills-optimization-pro自身 | Phase 0→1→2→3→4 + 用户确认 | SKILL.md 279→220行(-21%) |
