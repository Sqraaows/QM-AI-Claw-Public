## Description: <br>
TextCortex (textcortex.com) connector skill for reading model information and creating non-streaming chat completions through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate TextCortex through OOMOL, including listing available models, retrieving model metadata, and creating non-streaming chat completions after reviewing the live connector schema. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected TextCortex API key or account through OOMOL. <br>
Mitigation: Only connect credentials you are comfortable allowing OOMOL to use, and install the skill only when you intend to operate TextCortex through OOMOL. <br>
Risk: Chat-completion requests may send user-provided prompts or data to TextCortex through the connector. <br>
Mitigation: Review the exact payload before running chat-completion actions and avoid including sensitive data unless the user has approved that use. <br>


## Reference(s): <br>
- [TextCortex homepage](https://textcortex.com/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub TextCortex skill page](https://clawhub.ai/oomol/oo-textcortex) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
