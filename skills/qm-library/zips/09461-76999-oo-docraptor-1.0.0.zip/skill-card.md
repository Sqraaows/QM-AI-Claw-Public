## Description: <br>
DocRaptor helps agents create hosted PDF or Excel documents from raw HTML or a public URL through OOMOL-connected DocRaptor accounts. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect the DocRaptor connector schema and create hosted PDF or Excel documents through their connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Document creation can change DocRaptor state and may incur service usage or billing. <br>
Mitigation: Confirm the exact HTML or URL, output settings, and intended effect with the user before running the create_hosted_document action. <br>
Risk: The skill depends on OOMOL as an intermediary for DocRaptor credentials and on the oo CLI setup path when the CLI is missing. <br>
Mitigation: Install only when the user intends to use OOMOL for DocRaptor, and verify the oo CLI installer source before using the setup path. <br>


## Reference(s): <br>
- [DocRaptor homepage](https://docraptor.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces hosted PDF or Excel document URLs with execution metadata through the user's connected DocRaptor account.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
