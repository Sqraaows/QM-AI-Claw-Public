## Description: <br>
Toggl Track connector that lets an agent read, create, update, and delete Toggl Track data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and teams use this skill to operate Toggl Track from an agent workflow, including time entries, workspaces, projects, tasks, and tags. It supports routine time-tracking administration while requiring confirmation before write or delete actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and change Toggl Track data through a connected account. <br>
Mitigation: Install only when the agent should operate the user's Toggl Track account, and review write requests before approval. <br>
Risk: Delete actions can remove Toggl Track projects, tags, tasks, or time entries. <br>
Mitigation: Confirm the exact target and require explicit user approval before running destructive actions. <br>
Risk: The skill depends on sensitive account credentials managed through OOMOL. <br>
Mitigation: Verify the OOMOL CLI or install source during setup and reconnect credentials only through the documented OOMOL connection flow. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-toggl) <br>
- [Toggl Track homepage](https://toggl.com/track/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an authenticated OOMOL account with Toggl Track connected; write and delete actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
