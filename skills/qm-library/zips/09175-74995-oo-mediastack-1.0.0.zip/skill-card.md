## Description: <br>
Mediastack helps agents search and read Mediastack news data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to search live Mediastack news articles and discover Mediastack news sources through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a Mediastack account connection through OOMOL, so OOMOL acts as the credential broker. <br>
Mitigation: Install and use it only when that credential-broker relationship is acceptable for the target environment. <br>
Risk: The optional CLI installer executes a remote installation script. <br>
Mitigation: Verify the OOMOL CLI source and use a trusted installation method before running connector commands. <br>
Risk: Mediastack queries can return live news data that may be incomplete, outdated, or unsuitable for high-stakes decisions. <br>
Mitigation: Treat returned news results as source material to review and corroborate before relying on them. <br>


## Reference(s): <br>
- [Mediastack homepage](https://mediastack.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-mediastack) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector payloads/responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads; Mediastack responses are returned as JSON under data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
