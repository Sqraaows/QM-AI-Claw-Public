## Description: <br>
Cal.com (cal.com). Use this skill for reading, creating, updating, and deleting Cal.com data through the connected OOMOL account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent operate Cal.com workflows, including bookings, attendees, event types, schedules, calendar availability, and profile settings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and modify Cal.com bookings, schedules, event types, calendars, and profile data using OAuth-backed access. <br>
Mitigation: Install only when this access is acceptable, and limit use to accounts and workspaces where the connected permissions are appropriate. <br>
Risk: Booking-changing actions can disrupt meetings or availability if run with the wrong booking UID or payload. <br>
Mitigation: Before canceling, confirming, declining, rescheduling, reassigning, or marking absence, require the agent to show the exact booking UID, payload, and likely effect, then get explicit user approval. <br>
Risk: Some state-changing actions lack clear per-action confirmation guidance according to the security summary. <br>
Mitigation: Apply the skill-level confirmation rule to all create, update, delete, post, send, cancel, confirm, decline, reschedule, reassign, and absence-marking actions. <br>


## Reference(s): <br>
- [Cal.com homepage](https://cal.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-cal) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action execution and returns connector responses as JSON when actions are run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
