## Description: <br>
Placid lets an agent operate Placid through OOMOL's connected account to list templates, inspect template layers, create image generation requests, poll image status, and delete image requests. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Design and developer teams use this skill to automate Placid template discovery and image generation from an agent while relying on the connected OOMOL account for authentication. Confirm create payloads and delete targets before allowing state-changing actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected Placid account through OOMOL, so actions may access account-scoped templates and generated images. <br>
Mitigation: Install only when Placid access through OOMOL is intended, review the oo CLI installer before use, and rely on the connected account rather than exposing raw API tokens. <br>
Risk: Create and delete actions can change or remove Placid resources. <br>
Mitigation: Inspect the live action schema, confirm exact create payloads, and require explicit approval for delete targets before execution. <br>


## Reference(s): <br>
- [Placid homepage](https://placid.app) <br>
- [ClawHub Placid skill page](https://clawhub.ai/oomol/oo-placid) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads; responses include Placid data and an execution id when actions run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
