## Description: <br>
Convex helps agents operate Convex projects and deployments through an OOMOL-connected account, including discovery, management, and function execution. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Convex projects, deployments, custom domains, deploy keys, and to run Convex queries, mutations, actions, and functions from an agent. It is intended for users who trust OOMOL and have connected Convex credentials through their OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can perform write and delete operations against Convex resources, including projects, deployments, custom domains, and deploy keys. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before executing any state-changing operation, and require explicit approval for destructive actions. <br>
Risk: The skill operates through an OOMOL-connected account and requires trust in OOMOL-managed credential handling. <br>
Mitigation: Install and use it only when the user trusts OOMOL and has intentionally connected the relevant Convex account. <br>
Risk: Upstream connector schemas and defaults can change, which can make stale payload assumptions unsafe. <br>
Mitigation: Fetch the live action schema with the oo CLI before constructing command payloads. <br>


## Reference(s): <br>
- [Convex homepage](https://www.convex.dev) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-convex) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands use the oo CLI and may return JSON responses with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
