## Description: <br>
Operate DigitalOcean through OOMOL's connected digital_ocean connector for account and infrastructure lookup plus explicitly confirmed basic Droplet lifecycle actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect DigitalOcean account context and infrastructure resources through the OOMOL DigitalOcean connector. It can list and retrieve Droplets, apps, databases, domains, DNS records, firewalls, load balancers, and VPCs, and it can initiate basic Droplet lifecycle actions when explicitly confirmed. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connecting an OOMOL account to DigitalOcean and allowing the agent to use the oo connector. <br>
Mitigation: Install only when that account connection is acceptable, and review requested DigitalOcean scopes before use. <br>
Risk: Droplet lifecycle actions such as reboot, shutdown, and power cycle can affect production infrastructure. <br>
Mitigation: Require the exact Droplet ID, requested action, environment check, and explicit user confirmation before running lifecycle commands. <br>
Risk: The setup instructions include remote shell installer commands for the oo CLI. <br>
Mitigation: Review the installer source or use a verified installation method before executing installation commands. <br>


## Reference(s): <br>
- [DigitalOcean homepage](https://www.digitalocean.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-digital-ocean) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before action execution; connector responses are JSON with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
