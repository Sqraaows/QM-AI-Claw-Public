## Description: <br>
Dropbox lets an agent operate a connected Dropbox account through OOMOL, including file browsing, uploads, downloads, copy and move operations, deletion, account lookup, and shared-link management. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent work with files, folders, metadata, and shared links in an OOMOL-connected Dropbox account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change Dropbox data through uploads, moves, copies, folder creation, and shared-link creation. <br>
Mitigation: Review the exact requested payload and intended effect before approving write or sharing actions. <br>
Risk: The delete action can remove Dropbox files or folders. <br>
Mitigation: Require explicit approval for the target path before running destructive actions. <br>
Risk: Downloads may copy Dropbox file content into transit storage as part of the connector workflow. <br>
Mitigation: Use download actions only for content the user intends to transfer through that storage path. <br>


## Reference(s): <br>
- [ClawHub Dropbox Skill](https://clawhub.ai/oomol/oo-dropbox) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Dropbox Homepage](https://www.dropbox.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include a data object and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
