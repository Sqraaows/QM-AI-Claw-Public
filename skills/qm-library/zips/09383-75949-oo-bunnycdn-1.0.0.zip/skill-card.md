## Description: <br>
BunnyCDN helps agents operate BunnyCDN through the OOMOL `bunnycdn` connector and `oo` CLI, including Pull Zone lookup, listing, and cache purge workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage BunnyCDN Pull Zones through an OOMOL-connected account without handling raw BunnyCDN API tokens directly. It supports read workflows for Pull Zone discovery and lookup, plus confirmed cache purge operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses OOMOL as an intermediary for a BunnyCDN account and requires connected account access. <br>
Mitigation: Install only when comfortable with that intermediary path, review the oo CLI installer, and connect only the BunnyCDN access intended for the task. <br>
Risk: Cache purge actions can change BunnyCDN service state and affect cached content availability. <br>
Mitigation: Require explicit user confirmation of the Pull Zone, cache tag if used, and expected effect before running purge operations. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-bunnycdn) <br>
- [BunnyCDN Homepage](https://bunny.net/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands should inspect the live connector schema before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
