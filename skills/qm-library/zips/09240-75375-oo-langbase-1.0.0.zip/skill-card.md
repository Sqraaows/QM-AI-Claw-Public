## Description: <br>
Langbase helps an agent operate a connected Langbase account through the OOMOL `oo` CLI for reading, creating, retrieving, and deleting memory data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Langbase memories from an agent session, including listing memories, creating new memories, retrieving similar chunks, and deleting memories when explicitly approved. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected Langbase account and may read, create, retrieve, or delete Langbase memory data. <br>
Mitigation: Install only for intended Langbase account access, review payloads before create actions, and require exact user approval before delete actions. <br>
Risk: Initial setup may require installing the `oo` CLI and connecting OOMOL to Langbase credentials. <br>
Mitigation: Run the installer and account connection flow only when needed and only if the user trusts OOMOL's CLI installation and credential handling. <br>


## Reference(s): <br>
- [ClawHub Langbase skill](https://clawhub.ai/oomol/oo-langbase) <br>
- [Langbase homepage](https://langbase.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown guidance with `oo` CLI commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches live connector schemas before action execution; state-changing and destructive actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
