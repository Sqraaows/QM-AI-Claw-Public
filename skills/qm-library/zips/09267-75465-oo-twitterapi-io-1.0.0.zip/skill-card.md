## Description: <br>
TwitterAPI.io (twitterapi.io) lets an agent read, create, update, and delete TwitterAPI.io data through the OOMOL `twitterapi_io` connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill to retrieve X/Twitter profiles, tweets, replies, trends, lists, communities, Spaces, account information, and relationship data through TwitterAPI.io. It also supports monitored user and tweet filter rule management when the user confirms state-changing payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an OOMOL-connected TwitterAPI.io account. <br>
Mitigation: Install it only when the agent is intended to use that account, and rely on OOMOL-managed credential injection rather than exposing raw API tokens. <br>
Risk: Adding or updating monitored users or tweet filter rules changes TwitterAPI.io state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: Delete and remove actions can permanently change configured TwitterAPI.io monitoring or filter state. <br>
Mitigation: Confirm the target and require explicit user approval before running destructive actions. <br>


## Reference(s): <br>
- [TwitterAPI.io homepage](https://twitterapi.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-twitterapi-io) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to inspect live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
