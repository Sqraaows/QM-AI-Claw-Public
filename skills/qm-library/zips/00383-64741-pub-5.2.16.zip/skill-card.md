## Description: <br>
Create adaptive interfaces and real-time experiences via the pub CLI, with live P2P browser sessions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[xmanatee](https://clawhub.ai/user/xmanatee) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to create, update, inspect, and run live pub.blue experiences from the pub CLI. It supports publishing HTML, Markdown, and text outputs and managing browser-based live canvas or chat sessions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill documents a delete command that can remove a pub if the wrong slug is supplied. <br>
Mitigation: Verify the target slug with a list or get command and ask for confirmation before running deletion. <br>
Risk: The skill requires a Pub API key for authenticated CLI operations. <br>
Mitigation: Use environment or stdin-based configuration and avoid placing the key in generated content, logs, or shared files. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/xmanatee/pub) <br>
- [Pub homepage](https://pub.blue) <br>
- [Pub GitHub Releases](https://github.com/xmanatee/pub/releases/latest) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, Code, Markdown, Guidance] <br>
**Output Format:** [Markdown with inline shell commands, configuration values, and HTML or Markdown examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the pub CLI and a PUB_API_KEY for authenticated operations.] <br>

## Skill Version(s): <br>
5.2.16 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
