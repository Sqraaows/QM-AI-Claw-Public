## Description: <br>
CompanyEnrich helps agents search company data, enrich company profiles by domain or identifying properties, find similar companies, and inspect the authenticated user's CompanyEnrich account through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate CompanyEnrich through an OOMOL-connected account for company search, company enrichment, similar-company discovery, and account capability checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected CompanyEnrich account. <br>
Mitigation: Install and use it only when the user intends to let the agent query CompanyEnrich through that account. <br>
Risk: CompanyEnrich usage may have billing or credit implications. <br>
Mitigation: Review CompanyEnrich and OOMOL billing status before relying on the connector for repeated or large searches. <br>
Risk: Future connector actions that create, update, send, post, delete, or remove data could change external state. <br>
Mitigation: Require user confirmation for the exact payload and expected effect before running any mutating or destructive action. <br>


## Reference(s): <br>
- [CompanyEnrich homepage](https://companyenrich.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-companyenrich) <br>
- [count_companies action reference](actions/count_companies.md) <br>
- [enrich_company_by_domain action reference](actions/enrich_company_by_domain.md) <br>
- [enrich_company_by_properties action reference](actions/enrich_company_by_properties.md) <br>
- [find_similar_companies action reference](actions/find_similar_companies.md) <br>
- [get_current_user action reference](actions/get_current_user.md) <br>
- [search_companies action reference](actions/search_companies.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
