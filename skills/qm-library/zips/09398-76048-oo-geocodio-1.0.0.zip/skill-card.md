## Description: <br>
Geocodio (geocod.io) helps agents search and read geocoding data through OOMOL's connected Geocodio connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and other external users use this skill to geocode addresses or reverse geocode coordinates through a connected Geocodio account. It supports single and batch lookups while prompting the agent to inspect the live connector schema before sending payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Geocodio API key through OOMOL. <br>
Mitigation: Use it only in environments where the oo CLI is trusted and the Geocodio connection is intentionally configured. <br>
Risk: Addresses and coordinates can reveal sensitive location data. <br>
Mitigation: Confirm the user's intent before sending location data, especially for batch requests. <br>
Risk: A user may want general Geocodio discussion rather than a live lookup. <br>
Mitigation: Ask for confirmation before running connector actions when the request does not clearly require live data. <br>


## Reference(s): <br>
- [Geocodio homepage](https://www.geocod.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-geocodio) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
