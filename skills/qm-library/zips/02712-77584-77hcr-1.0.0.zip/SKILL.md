---
name: olk-outlook
description: Connect Outlook or Microsoft 365 mail through the olk CLI and Microsoft Graph API. Use when the user asks to read Outlook mail, search Outlook messages, summarize unread email, inspect attachments, or organize recent inbox activity.
homepage: https://github.com/rlrghb/olkcli
user-invocable: true
metadata:
  {
    "openclaw":
      {
        "emoji": "📬",
        "requires": { "bins": ["olk"] },
        "install":
          [
            {
              "id": "brew",
              "kind": "brew",
              "formula": "rlrghb/tap/olk",
              "bins": ["olk"],
              "label": "Install olk (Homebrew)"
            }
          ]
      }
  }
---

# olk-outlook

Use this skill when the user wants WorkBuddy to work with Outlook or Microsoft 365 email.

What this skill is for:

- Read recent Outlook mail
- Search Outlook mail by sender, subject, or keywords
- Summarize unread or recent messages in Chinese or English
- Pull full message content before summarizing when the subject line is not enough
- Avoid sending, deleting, moving, or marking messages unless the user clearly asks

## First-run setup

Before first use, check whether `olk` is ready:

- Check whether `olk` exists: `which olk`
- Check auth state: `olk auth status`

If `olk` is missing and install metadata is supported, install it through the provided Homebrew step. Otherwise install manually with:

- `brew install rlrghb/tap/olk`

If the user has not logged in yet:

- Personal Outlook/Hotmail/Live account: `olk auth login`
- Work or school Microsoft 365 account: `olk auth login --enterprise`

If the default public client is blocked by the organization, tell the user they need their own Microsoft Entra app registration and then use:

- `olk auth login --client-id YOUR_CLIENT_ID --tenant-id YOUR_TENANT_ID`

After successful login, confirm with:

- `olk auth status`

## Default workflow

For read-only inbox work, prefer this sequence:

1. List candidate messages with JSON output
2. Select the most relevant message IDs
3. Fetch full content for those IDs
4. Summarize or answer the user's question

Always prefer `--json --results-only` when you need structured data.

## Common commands

Recent inbox:

- `olk mail list -n 10 --json --results-only`

Recent unread inbox:

- `olk mail list -n 10 -u --json --results-only`

Messages from a sender:

- `olk mail list -n 20 --from someone@example.com --json --results-only`

Search by keyword or subject:

- `olk mail search "subject:invoice"`
- `olk mail search "from:boss@company.com project alpha"`
- `olk mail search "hasAttachment:true"`

Read one message:

- `olk mail get <MESSAGE_ID> --format text`
- `olk mail get <MESSAGE_ID> --format full --json --results-only`

List attachments:

- `olk mail attachments <MESSAGE_ID>`

Download attachments only when the user asks:

- `olk mail attachments <MESSAGE_ID> --save --out ./downloads`

## Summary workflow

When the user asks for an inbox summary, use this approach:

1. Start with `olk mail list -n 10 -u --json --results-only`
2. If there are too many results, group by sender and topic
3. Fetch full bodies for the top relevant messages with `olk mail get <ID> --format text`
4. Produce a concise summary with:
   - sender
   - subject
   - date/time
   - action needed
   - urgency

If the user asks things like "帮我总结今天 Outlook 里重要的邮件", prioritize:

- unread mail
- high-importance mail
- recent mail from frequent or named contacts
- mail mentioning deadlines, meetings, approvals, invoices, contracts, or action requests

## User-facing prompt examples

- `帮我总结最近 5 封 Outlook 未读邮件`
- `搜索 Outlook 里主题包含 invoice 的邮件并总结`
- `看一下今天收到的重要邮件，并告诉我哪些需要我处理`
- `把来自某个发件人的最近邮件按时间顺序整理出来`
- `读取这封 Outlook 邮件的正文并给我中文摘要`

## Time filters

Prefer ISO dates:

- `olk mail list --after 2026-05-22 --json --results-only`
- `olk mail list --after 2026-05-21 --before 2026-05-23 --json --results-only`

## Safety rules

- Do not send mail unless the user clearly confirms recipients and content.
- Do not delete, move, forward, or mark messages read without explicit user intent.
- Never guess a message ID; always obtain it from `list` or `search` first.
- If auth fails, run `olk auth status` and explain the exact issue.
- If the mailbox appears empty, verify account selection and try `olk auth list`.

## Helpful defaults

- Use `olk mail list -n 10 -u --json --results-only` for a quick unread pass.
- Use `olk mail search "<query>" --json --results-only` for targeted retrieval.
- Use `olk mail get <ID> --format text` before writing summaries that depend on message body details.
- When multiple accounts are configured, use `--account EMAIL` to avoid ambiguity.
