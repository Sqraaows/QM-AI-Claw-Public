---
name: Superpowers AI 开发助手
slug: superpowers-wrap
description: Superpowers AI 开发助手 — 集成多种 AI 能力的编程辅助工具，提供代码生成、代码审查、Bug 修复、技术方案建议等功能。支持主流编程语言和 IDE，可作为 VSCode、JetBrains 等编辑器的插件使用。适用于各水平开发者，可将日常编码效率提升 40% 以上。 | 来源：https://github.com/q15004040209-creator/superpowers-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/superpowers-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
