# Superpowers Wrapper

> An agentic skills framework & software development methodology that works

[English](#english) | [中文](#中文)

---

## English

### What is Superpowers?

**Superpowers** is a complete software development methodology for AI coding agents, built on composable skills and intelligent instructions. It transforms your AI agent from a passive code generator into an active development partner that thinks before it writes.

### Core Philosophy

- **TDD First** — Write tests before code, always
- **Think Before Build** — Agent steps back to clarify requirements before coding
- **Systematic over Ad-hoc** — Process over guessing, evidence over claims
- **Complexity Reduction** — Simplicity as the primary goal

### The 7-Stage Development Workflow

| Stage | Skill | What It Does |
|-------|-------|-------------|
| 1 | `brainstorming` | Socratic design refinement — asks questions, explores alternatives |
| 2 | `using-git-worktrees` | Creates isolated workspace on new branch with clean test baseline |
| 3 | `writing-plans` | Breaks work into bite-sized tasks (2-5 min each) with exact file paths |
| 4 | `subagent-driven-development` | Dispatches fresh subagent per task with two-stage review |
| 5 | `test-driven-development` | Enforces RED-GREEN-REFACTOR cycle strictly |
| 6 | `requesting-code-review` | Reviews against plan, reports issues by severity |
| 7 | `finishing-a-development-branch` | Verifies tests, presents merge/PR/keep/discard options |

### Skills Library

**Testing**
- `test-driven-development` — RED-GREEN-REFACTOR cycle

**Debugging**
- `systematic-debugging` — 4-phase root cause process
- `verification-before-completion` — Ensure it's actually fixed

**Collaboration**
- `brainstorming`, `writing-plans`, `executing-plans`
- `dispatching-parallel-agents` — Concurrent subagent workflows
- `requesting-code-review`, `receiving-code-review`
- `using-git-worktrees`, `finishing-a-development-branch`
- `subagent-driven-development` — Fast iteration with two-stage review

**Meta**
- `writing-skills` — Create new skills following best practices
- `using-superpowers` — Introduction to the skills system

### Quick Start

```bash
# Clone the wrapper
git clone https://github.com/q15004040209-creator/superpowers-wrap.git
cd superpowers-wrap

# Install for Claude Code
/plugin install superpowers@claude-plugins-official

# Or install for Codex CLI
# /plugins → search "superpowers" → Install Plugin

# Or install for Gemini CLI
gemini extensions install https://github.com/obra/superpowers
```

### Supported AI Agents

- Claude Code (official marketplace)
- Codex CLI / Codex App
- Factory Droid
- Gemini CLI
- OpenCode
- Cursor
- GitHub Copilot CLI

### Project Structure

```
superpowers-wrap/
├── README.md              # This file
├── demo/
│   ├── demo_basic.py      # Basic TDD cycle demo
│   ├── demo_debug.py      # Systematic debugging demo
│   └── demo_workflow.py   # Full workflow demo
├── skills/
│   ├── tdd_cycle.sh       # Shell-based TDD skill
│   └── workflow.sh         # Workflow orchestration skill
└── docs/
    ├── QUICKSTART.md       # Quick start guide
    └── SKILLS.md           # Skills reference
```

### License

MIT License — see [original repo](https://github.com/obra/superpowers) for details.

---

## 中文

### 什么是 Superpowers？

**Superpowers** 是一套完整的 AI 编码智能体软件开发方法论，基于可组合的技能库和智能指令集。它将你的 AI 助手从被动的代码生成器转变为主动的开发伙伴——先思考，后动手。

### 核心思想

- **TDD 优先** — 先写测试，再写代码
- **动手前先思考** — AI 先澄清需求，再开始编码
- **系统化优于随机化** — 流程优先，证据优先
- **复杂度简化** — 简洁是最终目标

### 七阶段开发流程

| 阶段 | 技能 | 说明 |
|------|------|------|
| 1 | `brainstorming` | 苏格拉底式设计澄清 — 提问、探索备选方案 |
| 2 | `using-git-worktrees` | 在新分支创建隔离工作空间，验证干净测试基准 |
| 3 | `writing-plans` | 将工作拆分为小块任务（每个 2-5 分钟），含精确文件路径 |
| 4 | `subagent-driven-development` | 每个任务分发新的子智能体，两阶段审查 |
| 5 | `test-driven-development` | 严格执行 RED-GREEN-REFACTOR 循环 |
| 6 | `requesting-code-review` | 对照计划审查，按严重程度报告问题 |
| 7 | `finishing-a-development-branch` | 验证测试，提供合并/PR/保留/放弃选项 |

### 技能库

**测试**
- `test-driven-development` — RED-GREEN-REFACTOR 循环

**调试**
- `systematic-debugging` — 四阶段根本原因分析
- `verification-before-completion` — 确认问题真正修复

**协作**
- `brainstorming`、`writing-plans`、`executing-plans`
- `dispatching-parallel-agents` — 并发子智能体工作流
- `requesting-code-review`、`receiving-code-review`
- `using-git-worktrees`、`finishing-a-development-branch`
- `subagent-driven-development` — 两阶段审查快速迭代

**元技能**
- `writing-skills` — 按最佳实践创建新技能
- `using-superpowers` — 技能系统入门

### 快速上手

```bash
# 克隆本仓库
git clone https://github.com/q15004040209-creator/superpowers-wrap.git
cd superpowers-wrap

# Claude Code 安装
/plugin install superpowers@claude-plugins-official

# 或 Gemini CLI 安装
gemini extensions install https://github.com/obra/superpowers
```

### 支持的 AI 智能体

- Claude Code（官方市场）
- Codex CLI / Codex App
- Factory Droid
- Gemini CLI
- OpenCode
- Cursor
- GitHub Copilot CLI

### 项目结构

```
superpowers-wrap/
├── README.md              # 本文件
├── demo/
│   ├── demo_basic.py      # 基础 TDD 循环演示
│   ├── demo_debug.py      # 系统调试演示
│   └── demo_workflow.py   # 完整工作流演示
├── skills/
│   ├── tdd_cycle.sh       # Shell 版 TDD 技能
│   └── workflow.sh         # 工作流编排技能
└── docs/
    ├── QUICKSTART.md       # 快速入门
    └── SKILLS.md           # 技能参考
```

### 许可证

MIT License — 详情见 [原始仓库](https://github.com/obra/superpowers)。

---

*This is a wrapper/distribution of [obra/superpowers](https://github.com/obra/superpowers).*