## Description: <br>
ZenRows helps an agent use an OOMOL-connected ZenRows account to fetch HTML, extract page text, extract CSS-selected values, and retrieve usage details. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill when they need ZenRows-backed web retrieval or extraction through an OOMOL connector. It supports public URL HTML fetching, plain-text extraction, CSS selector extraction, and usage-plan checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill relies on an external OOMOL CLI and connected ZenRows credentials. <br>
Mitigation: Install only if comfortable using OOMOL as the connector for the ZenRows API key, and review the oo CLI installation path before running installer commands. <br>
Risk: URLs, page content, and usage data requested through the skill are sent through ZenRows and OOMOL-connected services. <br>
Mitigation: Use the skill only for URLs and usage information intended to be processed by ZenRows and OOMOL. <br>
Risk: Live connector schemas and upstream defaults can change. <br>
Mitigation: Inspect the authoritative action schema with the oo CLI before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-zenrows) <br>
- [ZenRows homepage](https://www.zenrows.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [OOMOL ZenRows app connection](https://console.oomol.com/app-connections?provider=zenrows) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an OOMOL account connection, and ZenRows API key access; action schemas are fetched live before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
