## Description: <br>
This skill operates a connected Userflow account through the oo CLI for reading, creating, updating, deleting, and tracking Userflow data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and customer-facing teams use this skill to manage Userflow users and groups, list or fetch records, track events, and perform approved create, update, or delete operations through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through the connected OOMOL account. <br>
Mitigation: Use the skill only with the intended Userflow account and rely on the documented OOMOL connection flow rather than handling raw tokens directly. <br>
Risk: Create, update, event-tracking, and delete actions can change or remove Userflow data. <br>
Mitigation: Inspect the live action schema, confirm the exact payload and target with the user, and require explicit approval before write or delete operations. <br>
Risk: Connector schemas and service behavior can change upstream. <br>
Mitigation: Fetch the authoritative action schema with the oo CLI before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-userflow) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Userflow Homepage](https://userflow.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands inspect live connector schemas and run Userflow actions through the oo CLI; action responses are JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
