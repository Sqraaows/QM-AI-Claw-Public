## Description: <br>
Ticketmaster skill for searching and reading events, venues, attractions, classifications, images, suggestions, and supported season ticketing data through an OOMOL-connected Ticketmaster account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to search Ticketmaster event, venue, attraction, and classification data, retrieve related images and suggestions, and run supported Ticketmaster connector actions through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an OOMOL-connected Ticketmaster account. <br>
Mitigation: Install it only for agents authorized to use that Ticketmaster connection and keep credentials managed through OOMOL. <br>
Risk: Broad Ticketmaster trigger wording may route unintended Ticketmaster requests through the connector. <br>
Mitigation: Review whether the request actually requires Ticketmaster connector access and narrow trigger wording during publication review. <br>
Risk: The season ticketing command action may change Ticketmaster season ticketing or account state. <br>
Mitigation: Require explicit user confirmation of the exact action payload and expected effect before running that command. <br>


## Reference(s): <br>
- [Ticketmaster homepage](https://www.ticketmaster.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ticketmaster) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
