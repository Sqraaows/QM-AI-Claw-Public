## Description: <br>
Operate HeyGen through an OOMOL-connected account to generate avatar and template videos, manage media assets, inspect account context, and retrieve video status or share URLs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, creative operators, and agents use this skill to run HeyGen workflows from a connected account: generating videos, checking job status, listing reusable avatars, voices, templates, folders, videos, and assets, and managing obsolete media. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create HeyGen videos, upload assets, and delete HeyGen assets or videos. <br>
Mitigation: Confirm the exact payload and target before running write or delete actions, and require explicit user approval for destructive operations. <br>
Risk: The skill requires connected HeyGen credentials through an OOMOL account. <br>
Mitigation: Use the intended connected account, review account context or remaining quota when needed, and avoid exposing raw credentials in prompts or files. <br>
Risk: Generated videos, uploaded media, and shareable URLs may expose user-provided content. <br>
Mitigation: Review content and sharing intent before retrieving, distributing, or storing public video URLs. <br>


## Reference(s): <br>
- [HeyGen homepage](https://www.heygen.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-heygen) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON request or response payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires a signed-in OOMOL account with HeyGen connected; write and delete actions require explicit user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
