---
name: Harness AI 测试助手
slug: harness-wrap
description: Harness AI 测试助手 — 利用大语言模型自动生成测试用例、执行测试验证、识别代码缺陷的智能化测试工具。支持单元测试、集成测试、端到端测试等多种测试类型。基于开源测试框架封装，深度集成 CI/CD 流水线，可自动分析代码变更影响范围并生成针对性测试用例。适用于追求高质量代码的开发和测试团队，可将测试覆盖率提升至 95% 以上。 | 来源：https://github.com/q15004040209-creator/harness-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/harness-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
