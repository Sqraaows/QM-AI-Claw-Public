## Description: <br>
Generate visually unified image-based PPT/PPTX decks from articles, reports, papers, notes, or outlines. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[ningzimu](https://clawhub.ai/user/ningzimu) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, researchers, and presentation authors use this skill to turn articles, reports, papers, notes, or outlines into visually unified image-based PowerPoint decks with optional speaker notes. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: CLI/API fallback may send prompts, source images, and API key configuration to OpenAI or a configured compatible proxy; the key may persist locally in ~/.codex-ppt-skill/.env. <br>
Mitigation: Use the built-in image backend when available, configure fallback only for trusted endpoints, keep API keys scoped and rotated, and avoid sending sensitive source material unless the selected backend is approved for it. <br>
Risk: Final slides are full-slide generated images, so individual text boxes, charts, and shapes are not separately editable in the PPTX. <br>
Mitigation: Use this skill only when image-based slides are acceptable; choose a different workflow when editable slide objects are required. <br>
Risk: Generated slides can misrepresent supplied figures, logos, or other required assets if the asset mapping or image backend input path is wrong. <br>
Mitigation: Confirm slide-to-asset mapping before generation, pass required assets through the selected backend as strict inputs, and inspect each generated slide before assembly. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/ningzimu/codex-ppt) <br>
- [Publisher Profile](https://clawhub.ai/user/ningzimu) <br>
- [Project Homepage](https://github.com/ningzimu/codex-ppt-skill) <br>
- [Workflow Gates And Progress](docs/workflow-gates-and-progress.md) <br>
- [Backend Selection](docs/backend-selection.md) <br>
- [CLI/API Fallback](docs/cli-api-fallback.md) <br>
- [Project Assembly And Reporting](docs/project-assembly-and-reporting.md) <br>
- [Style Library](docs/style-library.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance, files] <br>
**Output Format:** [Markdown guidance, JSON slide job files, PNG slide images, speaker-note Markdown, and PPTX files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Creates one generated 16:9 image per slide, records slide job state, and assembles final images into a PPTX deck.] <br>

## Skill Version(s): <br>
0.4.3 (source: server release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
