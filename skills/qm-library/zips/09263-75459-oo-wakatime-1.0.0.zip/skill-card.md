## Description: <br>
This skill handles WakaTime requests that search and read coding activity data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineering teams use this skill to let an agent retrieve WakaTime account, project, and coding activity summaries through the OOMOL WakaTime connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access WakaTime data for the connected account through OOMOL-managed credentials. <br>
Mitigation: Install it only for accounts where agent access to WakaTime coding activity is intended, and keep the WakaTime connection scoped to the required account. <br>
Risk: First-time setup may require installing or authenticating the oo CLI. <br>
Mitigation: Review the oo CLI installer source before running setup commands, and run authentication only after a connector command fails for an auth or connection reason. <br>
Risk: Connector schemas can change upstream, which may alter accepted inputs or available behavior. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>
Risk: Future connector actions could expose write or delete behavior even though the current release is described as read-only. <br>
Mitigation: Confirm the exact payload and effect with the user before running any create, update, send, post, delete, or remove action. <br>


## Reference(s): <br>
- [ClawHub WakaTime Skill](https://clawhub.ai/oomol/oo-wakatime) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [WakaTime Homepage](https://wakatime.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
