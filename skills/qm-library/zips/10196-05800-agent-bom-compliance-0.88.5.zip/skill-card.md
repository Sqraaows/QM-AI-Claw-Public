## Description: <br>
AI compliance and policy engine that evaluates scan results against OWASP, NIST, SOC 2, ISO 27001, CMMC, EU AI Act, AISVS v1.0, and related frameworks, and generates SBOMs and compliance reports. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, security engineers, and compliance teams use this skill to run compliance checks, policy checks, SBOM generation, AISVS benchmarks, and optional CIS cloud benchmarks for AI infrastructure and agent supply-chain workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Optional CIS benchmark checks can query AWS, Azure, GCP, or Snowflake account metadata using locally configured credentials. <br>
Mitigation: Run CIS checks only when intended, use least-privilege read-only cloud credentials, and rely on operator-configured SDK credentials instead of pasted secrets. <br>
Risk: Compliance reports, policy checks, and SBOM outputs depend on the accuracy of the user-provided scan data, SBOM files, and policy files. <br>
Mitigation: Review source inputs and generated findings before using results for audit, governance, or release decisions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/msaad00/agent-bom-compliance) <br>
- [Project homepage](https://github.com/msaad00/agent-bom) <br>
- [PyPI package](https://pypi.org/project/agent-bom/) <br>
- [OpenSSF Scorecard](https://securityscorecards.dev/viewer/?uri=github.com/msaad00/agent-bom) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown or text guidance with command examples; tool workflows may produce JSON reports and CycloneDX or SPDX SBOM files.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs can include compliance summaries, policy-check results, AISVS and CIS benchmark summaries, and SBOM artifacts.] <br>

## Skill Version(s): <br>
0.88.5 (source: server release metadata and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
