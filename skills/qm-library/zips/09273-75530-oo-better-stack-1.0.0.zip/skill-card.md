## Description: <br>
Better Stack helps agents read, create, and update Better Stack incident and metadata data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to inspect Better Stack incidents, review comments and metadata, and create, acknowledge, or escalate incidents through the OOMOL oo connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The connected account can read and modify Better Stack incident data. <br>
Mitigation: Install only for trusted Better Stack and OOMOL accounts, and grant the connected account only the access needed for the intended workflows. <br>
Risk: Creating, acknowledging, or escalating incidents changes Better Stack state and may notify responders. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running any state-changing incident action. <br>
Risk: First-time setup may require running an external oo CLI install command. <br>
Mitigation: Review the OOMOL CLI install command and source before execution, then authenticate and connect Better Stack only when a command fails for that reason. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-better-stack) <br>
- [Better Stack Homepage](https://betterstack.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Better Stack Connection](https://console.oomol.com/app-connections?provider=better_stack) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [State-changing incident actions require user confirmation; Better Stack credentials are handled through the connected OOMOL account.] <br>

## Skill Version(s): <br>
1.0.0 (source: SKILL.md frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
