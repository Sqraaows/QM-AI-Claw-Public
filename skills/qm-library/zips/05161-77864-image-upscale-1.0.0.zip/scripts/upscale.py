import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from PIL import Image
import os

# Real-ESRGAN pure PyTorch implementation

class ResidualDenseBlock(nn.Module):
    """Residual Dense Block"""
    def __init__(self, num_feat=64, num_grow_ch=32):
        super().__init__()
        self.conv1 = nn.Conv2d(num_feat, num_grow_ch, 3, 1, 1)
        self.conv2 = nn.Conv2d(num_feat + num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv3 = nn.Conv2d(num_feat + 2 * num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv4 = nn.Conv2d(num_feat + 3 * num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv5 = nn.Conv2d(num_feat + 4 * num_grow_ch, num_feat, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, a=0.2, mode='fan_in')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat([x, x1], 1)))
        x3 = self.lrelu(self.conv3(torch.cat([x, x1, x2], 1)))
        x4 = self.lrelu(self.conv4(torch.cat([x, x1, x2, x3], 1)))
        x5 = self.conv5(torch.cat([x, x1, x2, x3, x4], 1))
        return x5 * 0.2 + x


class RRDB(nn.Module):
    """Residual in Residual Dense Block"""
    def __init__(self, num_feat, num_grow_ch=32):
        super().__init__()
        self.rdb1 = ResidualDenseBlock(num_feat, num_grow_ch)
        self.rdb2 = ResidualDenseBlock(num_feat, num_grow_ch)
        self.rdb3 = ResidualDenseBlock(num_feat, num_grow_ch)

    def forward(self, x):
        out = self.rdb1(x)
        out = self.rdb2(out)
        out = self.rdb3(out)
        return out * 0.2 + x


class RRDBNet(nn.Module):
    """Real-ESRGAN network architecture"""
    def __init__(self, num_in_ch=3, num_out_ch=3, scale=4, num_feat=64, num_block=23, num_grow_ch=32):
        super().__init__()
        self.scale = scale

        self.conv_first = nn.Conv2d(num_in_ch, num_feat, 3, 1, 1)
        self.body = nn.ModuleList()
        for _ in range(num_block):
            self.body.append(RRDB(num_feat, num_grow_ch))
        self.conv_body = nn.Conv2d(num_feat, num_feat, 3, 1, 1)

        self.conv_up1 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_up2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)

        self.conv_hr = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_last = nn.Conv2d(num_feat, num_out_ch, 3, 1, 1)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, a=0.2, mode='fan_in')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        feat = self.conv_first(x)
        body_feat = feat
        for block in self.body:
            body_feat = block(body_feat)
        body_feat = self.conv_body(body_feat)
        feat = feat + body_feat

        feat = self.lrelu(self.conv_up1(F.interpolate(feat, scale_factor=2, mode='nearest')))
        feat = self.lrelu(self.conv_up2(F.interpolate(feat, scale_factor=2, mode='nearest')))

        out = self.conv_last(self.lrelu(self.conv_hr(feat)))
        return out


def load_realesrgan_model(model_path, device='cuda'):
    """Load Real-ESRGAN model weights"""
    model = RRDBNet(num_in_ch=3, num_out_ch=3, scale=4, num_feat=64, num_block=23, num_grow_ch=32)

    state_dict = torch.load(model_path, map_location=device, weights_only=False)

    if 'params_ema' in state_dict:
        state_dict = state_dict['params_ema']
    elif 'params' in state_dict:
        state_dict = state_dict['params']

    model.load_state_dict(state_dict, strict=True)
    model.eval()
    model.to(device)

    return model


def tile_process(model, img, tile_size=512, tile_pad=10):
    """Process large images in tiles"""
    batch, channel, height, width = img.shape
    output_height = height * 4
    output_width = width * 4
    output_shape = (batch, channel, output_height, output_width)

    output = img.new_zeros(output_shape)

    tiles_x = (width + tile_size - 1) // tile_size
    tiles_y = (height + tile_size - 1) // tile_size

    for y in range(tiles_y):
        for x in range(tiles_x):
            ofs_y = y * tile_size
            ofs_x = x * tile_size

            input_start_y = max(ofs_y - tile_pad, 0)
            input_end_y = min(ofs_y + tile_size + tile_pad, height)
            input_start_x = max(ofs_x - tile_pad, 0)
            input_end_x = min(ofs_x + tile_size + tile_pad, width)

            input_tile = img[:, :, input_start_y:input_end_y, input_start_x:input_end_x]

            with torch.no_grad():
                output_tile = model(input_tile)

            output_start_y = ofs_y * 4
            output_end_y = min((ofs_y + tile_size) * 4, output_height)
            output_start_x = ofs_x * 4
            output_end_x = min((ofs_x + tile_size) * 4, output_width)

            eff_start_y = (ofs_y - input_start_y) * 4
            eff_end_y = eff_start_y + (output_end_y - output_start_y)
            eff_start_x = (ofs_x - input_start_x) * 4
            eff_end_x = eff_start_x + (output_end_x - output_start_x)

            output[:, :, output_start_y:output_end_y, output_start_x:output_end_x] = \
                output_tile[:, :, eff_start_y:eff_end_y, eff_start_x:eff_end_x]

    return output


def process_image(model, img, device='cuda', tile_size=512, tile_pad=10):
    """Process image through Real-ESRGAN"""
    img = img.astype(np.float32) / 255.0
    img = torch.from_numpy(np.transpose(img[:, :, [2, 1, 0]], (2, 0, 1))).float()
    img = img.unsqueeze(0).to(device)

    with torch.no_grad():
        _, _, h, w = img.size()
        if h <= tile_size and w <= tile_size:
            output = model(img)
        else:
            output = tile_process(model, img, tile_size, tile_pad)

    output = output.squeeze().float().cpu().clamp_(0, 1).numpy()
    output = np.transpose(output[[2, 1, 0], :, :], (1, 2, 0))
    output = (output * 255.0).round().astype(np.uint8)

    return output


def download_model(model_path, progress_callback=None):
    """Download RealESRGAN_x4plus.pth if not present"""
    if os.path.exists(model_path) and os.path.getsize(model_path) > 60 * 1024 * 1024:
        return True

    import requests
    url = 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth'
    total = 67040989

    if os.path.exists(model_path):
        existing = os.path.getsize(model_path)
    else:
        existing = 0

    headers = {'Range': f'bytes={existing}-'} if existing > 0 else {}

    try:
        r = requests.get(url, headers=headers, stream=True, timeout=60)
        if r.status_code in (200, 206):
            mode = 'ab' if existing > 0 else 'wb'
            downloaded = existing
            with open(model_path, mode) as f:
                for chunk in r.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if progress_callback:
                            progress_callback(downloaded, total)
            return os.path.getsize(model_path) >= total * 0.99
    except Exception:
        pass

    return False


def upscale_image(input_path, output_path, model_path=None,
                  target_scale=10, target_dpi=300,
                  device='cuda', tile_size=512):
    """
    Full upscale pipeline:
    1. Load image (PSD/JPG/PNG)
    2. Real-ESRGAN 4x (AI detail generation)
    3. LANCZOS to target scale
    4. Save PNG with DPI metadata
    """
    # Determine model path
    if model_path is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(script_dir, 'RealESRGAN_x4plus.pth')

    # Download model if needed
    if not os.path.exists(model_path) or os.path.getsize(model_path) < 60 * 1024 * 1024:
        print('Downloading RealESRGAN model...')
        if not download_model(model_path):
            raise RuntimeError('Failed to download model. Please download manually:\n'
                               'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth')

    # Load model
    print('Loading Real-ESRGAN model...')
    model = load_realesrgan_model(model_path, device)
    print(f'Model ready on {device}')

    # Load image
    print(f'Loading image: {input_path}')
    if input_path.lower().endswith('.psd'):
        img = Image.open(input_path)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        img_np = np.array(img)
    else:
        img = Image.open(input_path).convert('RGB')
        img_np = np.array(img)

    orig_h, orig_w = img_np.shape[:2]
    print(f'Original: {orig_w}x{orig_h}')

    # Step 1: Real-ESRGAN 4x
    print('Step 1: Real-ESRGAN 4x upscaling...')
    sr_img = process_image(model, img_np, device=device, tile_size=tile_size)
    sr_h, sr_w = sr_img.shape[:2]
    print(f'  SR output: {sr_w}x{sr_h}')

    # Step 2: LANCZOS to target scale
    target_w = orig_w * target_scale
    target_h = orig_h * target_scale
    print(f'Step 2: LANCZOS to {target_scale}x ({target_w}x{target_h})...')
    sr_pil = Image.fromarray(sr_img)
    final_img = sr_pil.resize((target_w, target_h), Image.LANCZOS)

    # Step 3: Save with DPI
    print(f'Step 3: Saving PNG ({target_dpi} DPI)...')
    final_img.save(output_path, format='PNG', dpi=(target_dpi, target_dpi))

    file_size = os.path.getsize(output_path) / (1024 * 1024)
    print(f'Done: {file_size:.1f} MB')

    return {
        'orig_size': (orig_w, orig_h),
        'sr_size': (sr_w, sr_h),
        'final_size': (target_w, target_h),
        'output_path': output_path,
        'file_size_mb': file_size
    }


def batch_upscale(input_dir, output_dir=None, model_path=None,
                  target_scale=10, target_dpi=300,
                  device='cuda', extensions=('.psd', '.png', '.jpg', '.jpeg')):
    """Batch process all images in a directory"""
    if output_dir is None:
        output_dir = input_dir

    os.makedirs(output_dir, exist_ok=True)

    files = [f for f in os.listdir(input_dir)
             if f.lower().endswith(extensions) and os.path.isfile(os.path.join(input_dir, f))]
    files.sort()

    print(f'Found {len(files)} images in {input_dir}')

    # Determine model path
    if model_path is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(script_dir, 'RealESRGAN_x4plus.pth')

    # Download model if needed
    if not os.path.exists(model_path) or os.path.getsize(model_path) < 60 * 1024 * 1024:
        print('Downloading RealESRGAN model...')
        if not download_model(model_path):
            raise RuntimeError('Failed to download model')

    # Load model once
    print('Loading model...')
    model = load_realesrgan_model(model_path, device)
    print(f'Model ready on {device}\n')

    results = []
    for idx, filename in enumerate(files, 1):
        input_path = os.path.join(input_dir, filename)
        basename = os.path.splitext(filename)[0]
        output_path = os.path.join(output_dir, f'{basename}_{target_scale}x_{target_dpi}DPI_realesrgan.png')

        if os.path.exists(output_path):
            print(f'[{idx}/{len(files)}] Skip (exists): {filename}')
            results.append({'file': filename, 'status': 'skipped', 'output': output_path})
            continue

        print(f'\n[{idx}/{len(files)}] Processing: {filename}')

        try:
            # Determine tile size based on image dimensions
            img = Image.open(input_path)
            w, h = img.size
            max_dim = max(w, h)
            if max_dim <= 512:
                ts = 1024
            elif max_dim <= 1024:
                ts = 512
            elif max_dim <= 2000:
                ts = 512
            else:
                ts = 256

            result = process_single(model, input_path, output_path, target_scale, target_dpi, device, ts)
            result['file'] = filename
            result['status'] = 'success'
            results.append(result)

            torch.cuda.empty_cache()

        except Exception as e:
            print(f'  Failed: {e}')
            import traceback
            traceback.print_exc()
            results.append({'file': filename, 'status': 'failed', 'error': str(e)})

    # Summary
    print(f'\n{"="*50}')
    success = sum(1 for r in results if r.get('status') == 'success')
    skipped = sum(1 for r in results if r.get('status') == 'skipped')
    failed = sum(1 for r in results if r.get('status') == 'failed')
    total_mb = sum(r.get('file_size_mb', 0) for r in results)
    print(f'Success: {success} | Skipped: {skipped} | Failed: {failed}')
    print(f'Total output: {total_mb:.1f} MB')

    return results


def process_single(model, input_path, output_path, target_scale, target_dpi, device, tile_size):
    """Process a single image (model already loaded)"""
    if input_path.lower().endswith('.psd'):
        img = Image.open(input_path)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        img_np = np.array(img)
    else:
        img = Image.open(input_path).convert('RGB')
        img_np = np.array(img)

    orig_h, orig_w = img_np.shape[:2]
    print(f'  Original: {orig_w}x{orig_h}')

    # Real-ESRGAN 4x
    print(f'  Real-ESRGAN 4x...', end='', flush=True)
    sr_img = process_image(model, img_np, device=device, tile_size=tile_size)
    sr_h, sr_w = sr_img.shape[:2]
    print(f' -> {sr_w}x{sr_h}')

    # LANCZOS to target
    target_w = orig_w * target_scale
    target_h = orig_h * target_scale
    print(f'  LANCZOS {target_scale}x...', end='', flush=True)
    sr_pil = Image.fromarray(sr_img)
    final_img = sr_pil.resize((target_w, target_h), Image.LANCZOS)
    print(f' -> {target_w}x{target_h}')

    # Save
    final_img.save(output_path, format='PNG', dpi=(target_dpi, target_dpi))
    file_size = os.path.getsize(output_path) / (1024 * 1024)
    print(f'  Done: {file_size:.1f}MB')

    return {
        'orig_size': (orig_w, orig_h),
        'sr_size': (sr_w, sr_h),
        'final_size': (target_w, target_h),
        'output_path': output_path,
        'file_size_mb': file_size
    }


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Real-ESRGAN Image Upscaler')
    parser.add_argument('input', help='Input image or directory')
    parser.add_argument('-o', '--output', help='Output path or directory')
    parser.add_argument('-s', '--scale', type=int, default=10, help='Target scale factor (default: 10)')
    parser.add_argument('-d', '--dpi', type=int, default=300, help='Output DPI (default: 300)')
    parser.add_argument('--device', default='cuda', help='Device: cuda or cpu')
    parser.add_argument('--model', help='Path to RealESRGAN_x4plus.pth')
    parser.add_argument('--batch', action='store_true', help='Batch process directory')
    args = parser.parse_args()

    if args.batch or os.path.isdir(args.input):
        batch_upscale(args.input, args.output, args.model, args.scale, args.dpi, args.device)
    else:
        if not args.output:
            basename = os.path.splitext(args.input)[0]
            args.output = f'{basename}_{args.scale}x_{args.dpi}DPI_realesrgan.png'
        upscale_image(args.input, args.output, args.model, args.scale, args.dpi, args.device)
