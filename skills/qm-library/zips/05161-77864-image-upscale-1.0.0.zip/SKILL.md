---
name: image-upscale
description: AI-powered image upscaling using Real-ESRGAN + LANCZOS. Supports PSD/PNG/JPG input, generates high-resolution PNG with configurable DPI. Use when the user asks to upscale, enlarge, magnify, or increase resolution of images; when working with print-ready images requiring high DPI; when converting PSD to high-resolution PNG; or when image quality enhancement with AI-generated detail is needed.
---

# Image Upscale

AI图像放大技能，基于 Real-ESRGAN 神经网络 + LANCZOS 插值。

## Workflow

### Phase 0: 交互确认

向用户确认两个参数：
1. **放大倍数或目标尺寸** — 默认 10x（即最终尺寸 = 原图 ×10）
2. **目标 DPI** — 默认 300（打印级）

如果用户提供的是目标长宽像素，计算所需倍数：`scale = ceil(target / original)`。

### Phase 1: 读取原图

- 支持 PSD、PNG、JPG、JPEG
- PSD 自动合并图层转 RGB
- 记录原始尺寸

### Phase 2: Real-ESRGAN 4x 放大

- 使用 RealESRGAN_x4plus.pth（63.9MB）
- AI 生成细节（羽毛、纹理、边缘重建）
- 支持分块处理大图（tile-based，避免显存溢出）
- 自动下载模型（如果本地不存在）

### Phase 3: LANCZOS 放大到目标尺寸

- Real-ESRGAN 输出为 4x
- 用 LANCZOS 插值从 4x 放大到目标倍数（如 10x）
- 保持图像质量，无锯齿

### Phase 4: 设置 DPI 元数据

- PNG 文件写入 `(dpi, dpi)` 元数据
- 默认 300 DPI，用户可指定

### Phase 5: 输出 PNG

- 文件名格式：`{basename}_{scale}x_{dpi}DPI_realesrgan.png`
- 单文件处理或批量目录处理

## Scripts

### `scripts/upscale.py`

主脚本，包含完整推理代码：
- `upscale_image()` — 单图处理
- `batch_upscale()` — 批量处理
- `download_model()` — 自动下载模型
- 纯 PyTorch 实现，无需额外依赖（只需 torch + Pillow + numpy + requests）

### CLI 用法

```bash
# 单图
python scripts/upscale.py input.png -o output.png -s 10 -d 300

# 批量
python scripts/upscale.py ./images/ --batch -s 10 -d 300

# CPU 模式
python scripts/upscale.py input.png --device cpu
```

### Python API

```python
from scripts.upscale import upscale_image, batch_upscale

# 单图
result = upscale_image('input.psd', 'output.png', target_scale=10, target_dpi=300)

# 批量
results = batch_upscale('./images/', target_scale=10, target_dpi=300)
```

## Model

- 名称：RealESRGAN_x4plus.pth
- 来源：https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth
- 大小：63.9 MB
- 自动下载：脚本首次运行时会自动下载到 `scripts/` 目录
- 手动放置：也可手动下载放到 `scripts/RealESRGAN_x4plus.pth`

## Requirements

- PyTorch（支持 CUDA 则自动使用 GPU）
- Pillow
- numpy
- requests（用于自动下载模型）

## Notes

- 4x 放大用 Real-ESRGAN（AI 生成细节），大于 4x 的倍数用 LANCZOS（数学插值）
- 分块处理大图，tile_size 根据图像尺寸自动调整（小图 512-1024，大图 256）
- 批量处理时自动清理显存，避免 OOM
- 已存在输出文件自动跳过
