## Description: <br>
Operates Seqera through an OOMOL-connected account to inspect users, workspaces, pipelines, workflow runs, and launch workflows with schema-checked oo CLI commands. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and data teams use this skill to operate Seqera through an OOMOL-connected account, including discovery of users, workspaces, pipelines, and workflow runs. It can also prepare and run workflow launches after schema inspection and user confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate Seqera through sensitive OOMOL-connected credentials, including launching workflows. <br>
Mitigation: Install it only when that account-level access is intended, and review every workflow launch payload, expected cost, and resource impact before approval. <br>
Risk: The skill description emphasizes reading data while the artifact also includes workflow-launch authority. <br>
Mitigation: Treat launch_workflow as state-changing and require explicit confirmation of the exact payload and effect before running it. <br>
Risk: The setup guidance includes pipe-to-shell CLI installation commands. <br>
Mitigation: Prefer installing the oo CLI through a verified release or package-manager path instead of running pipe-to-shell commands directly. <br>


## Reference(s): <br>
- [ClawHub Seqera skill page](https://clawhub.ai/oomol/oo-seqera) <br>
- [Seqera homepage](https://seqera.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before action payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: release metadata and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
