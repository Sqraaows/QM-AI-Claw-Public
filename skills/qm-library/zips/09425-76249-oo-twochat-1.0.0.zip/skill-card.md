## Description: <br>
2Chat helps an agent operate a connected 2Chat account through OOMOL connector actions for contacts, webhooks, API usage, and API key validation. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent inspect and manage a connected 2Chat account through OOMOL, including listing contacts and webhooks, checking API usage, validating the API key, and creating contacts after payload confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access sensitive 2Chat account information such as contact lists, webhook lists, API usage, and account details. <br>
Mitigation: Install only when the agent should operate the connected 2Chat account, and treat returned account, contact, webhook, and usage data as sensitive. <br>
Risk: The create_contact action changes 2Chat state. <br>
Mitigation: Review the exact payload and intended effect with the user before running create or future state-changing actions. <br>
Risk: Connector input and output fields may change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-twochat) <br>
- [2Chat homepage](https://2chat.co) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [create_contact action reference](artifact/actions/create_contact.md) <br>
- [list_contacts action reference](artifact/actions/list_contacts.md) <br>
- [list_webhooks action reference](artifact/actions/list_webhooks.md) <br>
- [get_api_usage_info action reference](artifact/actions/get_api_usage_info.md) <br>
- [test_api_key action reference](artifact/actions/test_api_key.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
