## Description: <br>
Analyze and improve existing documentation using Diataxis principles. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[anderskev](https://clawhub.ai/user/anderskev) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and technical writers use this skill to audit markdown documentation against Diataxis categories and iteratively improve sections after explicit review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can overwrite the markdown file provided by the user. <br>
Mitigation: Use version control or a backup, and proceed only after the skill's review gates and explicit user choices are complete. <br>
Risk: Accepted documentation edits could introduce incorrect or misleading guidance. <br>
Mitigation: Review each proposed change before accepting it and check the final document for accuracy. <br>


## Reference(s): <br>
- [Improve Doc on ClawHub](https://clawhub.ai/anderskev/improve-doc) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, guidance, files] <br>
**Output Format:** [Markdown analysis, proposed edits, and accepted updates written to the target markdown file] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires a user-supplied markdown file path and interactive yes/skip/modify review choices before writing.] <br>

## Skill Version(s): <br>
1.0.2 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
