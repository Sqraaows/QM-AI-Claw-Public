## Description: <br>
Orchestrator for GitHub Spec-Kit SDD workflow in OpenClaw. Use when starting a new project with spec-driven development, setting up spec-kit toolchain, or running through the full SDD pipeline. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[staok](https://clawhub.ai/user/staok) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineering teams use this skill to initialize and run a Spec-Kit spec-driven development workflow, including project documentation, feature specification, planning, task breakdown, implementation orchestration, review, testing, and delivery checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup workflow can install Spec-Kit tooling and download auxiliary skills from GitHub, which may be unsuitable for strict offline or reproducible environments. <br>
Mitigation: Review setup.sh before use, prefer --check-only for assessment, and approve network downloads or dependency installation only in environments where current upstream content is acceptable. <br>
Risk: The workflow can create or edit project documentation, specification files, source code, tests, and git commits. <br>
Mitigation: Use the skill in low-risk development scenarios, keep user approval gates for setup and git management, and review generated plans, code, tests, and commits before relying on them. <br>
Risk: The artifact warns against using agents in critical-path, legacy, or security-sensitive code. <br>
Mitigation: Limit use to prototyping, search, documentation, and other low-risk workflows unless a human reviewer explicitly approves a broader scope. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/staok/spec-kit-coding) <br>
- [Source repository declared by artifact](https://github.com/Staok/spec-kit-coding-skill) <br>
- [GitHub Spec-Kit](https://github.com/github/spec-kit) <br>
- [Top-level coding guidance](CodingGuidance/TopLevelCodingGuidance.md) <br>
- [C++ coding style guidance](CodingGuidance/CppCodingStyle.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, shell commands, configuration] <br>
**Output Format:** [Markdown with inline shell commands, generated or edited project files, and structured status summaries] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce project specifications, plans, task lists, README and DEVLOG updates, review findings, test guidance, commits when git management is enabled, and setup commands that require user approval.] <br>

## Skill Version(s): <br>
1.0.4 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
