## Description: <br>
Use this skill for Serpdog requests, including searching and reading data through an OOMOL-connected Serpdog account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect live Serpdog connector schemas, run Google Search, Google News, Google Videos, Google Autocomplete, and account quota actions, and return Serpdog data through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Serpdog API key and OOMOL account session. <br>
Mitigation: Install only if you trust OOMOL's CLI distribution path and are comfortable connecting Serpdog through OOMOL. <br>
Risk: The first-time setup path includes curl or PowerShell installer one-liners. <br>
Mitigation: Review OOMOL's install guide or installer contents before running the installer. <br>
Risk: Connector action schemas can change upstream. <br>
Mitigation: Inspect the live Serpdog action schema before constructing each payload. <br>


## Reference(s): <br>
- [Serpdog homepage](https://serpdog.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution; Serpdog credentials are handled through the user's OOMOL connection.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
