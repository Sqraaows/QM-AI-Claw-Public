## Description: <br>
Use this skill when a spreadsheet is the primary input or output, including reading, editing, creating, cleaning, formatting, charting, or converting .xlsx, .xlsm, .csv, and .tsv files. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[yinfeihaaaaaaaaaaa](https://clawhub.ai/user/yinfeihaaaaaaaaaaa) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and spreadsheet-focused agents use this skill to create, inspect, modify, format, recalculate, and validate Excel and tabular files while preserving formulas and workbook conventions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The security review reports that the skill can write a persistent LibreOffice macro into the user's application profile. <br>
Mitigation: Install and run it only in environments where that profile change is acceptable; prefer an updated version that uses a temporary LibreOffice profile or asks for explicit confirmation before macro setup. <br>
Risk: The security review reports that recalculation can save and overwrite workbooks. <br>
Mitigation: Run the skill on copies of important spreadsheets and avoid sensitive or untrusted files unless the execution environment is isolated. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/yinfeihaaaaaaaaaaa/xlsx-localized) <br>
- [LibreOffice download](https://www.libreoffice.org/download/download-libreoffice/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with Python and shell command examples; generated spreadsheet files may be created or modified by the agent.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The recalculation helper returns JSON status, formula counts, and spreadsheet error locations.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
