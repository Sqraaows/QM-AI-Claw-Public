## Description: <br>
New Relic (newrelic.com) skill for reading, creating, updating, and deleting New Relic data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, DevOps engineers, and operators use this skill to inspect and manage New Relic alerts, dashboards, NRQL conditions, synthetics monitors, secure credentials, entities, deployment markers, and current-user validation through the oo CLI connector workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update New Relic resources such as alert policies, dashboards, NRQL conditions, synthetics monitors, secure credentials, and deployment markers. <br>
Mitigation: Inspect the live connector schema, confirm the exact payload and intended effect with the user, and run only actions that match the requested change. <br>
Risk: The skill includes destructive delete actions for New Relic dashboards, alert policies, NRQL conditions, synthetics monitors, and secure credentials. <br>
Mitigation: Confirm the target identifier and obtain explicit user approval before running any delete action. <br>
Risk: The skill requires a connected New Relic account and sensitive credentials managed through OOMOL. <br>
Mitigation: Review displayed permissions, rely on the server-side credential connection, and avoid running authentication or connection setup unless a command fails with a matching error. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-new-relic) <br>
- [New Relic homepage](https://newrelic.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, API calls] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
