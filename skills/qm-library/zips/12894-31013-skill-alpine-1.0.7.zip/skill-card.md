## Description: <br>
Fetches Alpine Linux latest-stable minirootfs release metadata and aggregates available architectures by version. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[lentiancn](https://clawhub.ai/user/lentiancn) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to find current Alpine Linux minirootfs download URLs and summarize which architectures are available for latest-stable Alpine releases. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill runs bundled shell scripts that contact Alpine release sources over the network. <br>
Mitigation: Review the scripts before use in locked-down environments and allow network execution only where that behavior is expected. <br>
Risk: The skill depends on external release indexes and local command-line tools, so output can be incomplete if requests fail or required tools are unavailable. <br>
Mitigation: Confirm required tools are installed and validate returned JSON before relying on it in automation. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/lentiancn/skill-alpine) <br>
- [Alpine Linux Latest Stable Releases](https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON] <br>
**Output Format:** [JSON arrays emitted on stdout by bash scripts] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires bash, curl, grep, sed, yq, jq, and network access to Alpine release sources.] <br>

## Skill Version(s): <br>
1.0.7 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
