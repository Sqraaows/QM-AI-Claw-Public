## Description: <br>
IPQualityScore supports IP, URL, email, and phone reputation or validation checks through an OOMOL-connected IPQualityScore account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and security operators use this skill to run user-directed IPQualityScore checks through an OOMOL-connected account. It supports IP reputation checks, URL and domain scans, email validation, and phone validation for fraud, abuse, deliverability, and activity signals. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected IPQualityScore account. <br>
Mitigation: Use only the server-side OOMOL credential flow and avoid handling raw IPQualityScore tokens in prompts, files, or shell history. <br>
Risk: Lookup inputs can include IP addresses, URLs, email addresses, and phone numbers that are sent to IPQualityScore. <br>
Mitigation: Run checks only when user-directed and appropriate for the applicable privacy and data-handling requirements. <br>
Risk: First-time setup may require installing the oo CLI from a shell installer command. <br>
Mitigation: Review the installer command before running it and use the documented setup path only when the CLI is missing. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ipqualityscore) <br>
- [IPQualityScore homepage](https://www.ipqualityscore.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
