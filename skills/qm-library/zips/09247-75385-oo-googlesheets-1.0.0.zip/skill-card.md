## Description: <br>
Google Sheets (workspace.google.com). Use this skill for reading, creating, updating, and deleting Google Sheets data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, operators, and developers use this skill to let an agent inspect, search, create, update, format, and clear Google Sheets content after the user has connected an OOMOL/Google Sheets account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The connected OOMOL/Google Sheets account can be used by the agent to read or modify spreadsheets. <br>
Mitigation: Install only when that account access is acceptable, and confirm the target spreadsheet, range, and payload before actions that append, update, or create data. <br>
Risk: Clear, delete, and overwrite actions can remove or replace spreadsheet data. <br>
Mitigation: Require explicit approval for destructive actions and verify the exact target before execution. <br>
Risk: Authentication and OAuth connection steps affect account setup. <br>
Mitigation: Treat CLI sign-in and Google Sheets connection as one-time setup steps, not routine action execution. <br>


## Reference(s): <br>
- [ClawHub Google Sheets skill](https://clawhub.ai/oomol/oo-googlesheets) <br>
- [Google Sheets homepage](https://workspace.google.com/products/sheets/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions with bash command snippets and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to inspect the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
