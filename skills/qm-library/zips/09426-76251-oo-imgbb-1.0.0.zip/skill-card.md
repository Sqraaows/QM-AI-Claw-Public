## Description: <br>
Use this skill for ImgBB requests that read, create, or update data through the ImgBB service. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to upload images to ImgBB through an OOMOL-connected account and receive hosted image metadata. It is intended for agent workflows that need schema-checked ImgBB upload commands while keeping raw credentials out of the prompt. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The upload action changes ImgBB state by publishing an image from a public URL or Base64 content. <br>
Mitigation: Confirm the exact payload and intended upload effect with the user before running the action. <br>
Risk: The skill requires a connected ImgBB account and sensitive credentials managed through OOMOL. <br>
Mitigation: Use the OOMOL connector flow so credentials are injected server-side, and install the skill only when ImgBB uploads through OOMOL are intended. <br>


## Reference(s): <br>
- [ImgBB homepage](https://imgbb.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-imgbb) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The upload action returns connector data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
