## Description: <br>
Builds a storyboard video generation pipeline from storyboard details, dialogue, prompts, aspect ratio, and resolution, then draws the pipeline onto a canvas. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[dlazyai](https://clawhub.ai/user/dlazyai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative agents use this skill to translate storyboard context into a structured audio, image, and video generation pipeline. It is intended for workflows that prepare canvas elements and dLazy CLI generation steps for storyboard-based video creation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a dLazy API key that may be saved in local CLI configuration. <br>
Mitigation: Use the DLAZY_API_KEY environment variable for per-run credentials when a long-lived saved key is not desired, and rotate or revoke keys from the dLazy dashboard when needed. <br>
Risk: Prompts and selected local image, video, or audio files may be sent to dLazy-hosted services. <br>
Mitigation: Review prompts and file paths before approving CLI execution, and avoid submitting sensitive media unless the deployment permits that data flow. <br>
Risk: Global CLI installation increases local persistence compared with one-off execution. <br>
Mitigation: Prefer npx @dlazy/cli@latest for temporary use when a persistent global installation is unnecessary. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/dlazyai/video-storyboard-generate) <br>
- [dLazy CLI repository](https://github.com/dlazyai/cli) <br>
- [dLazy CLI npm package](https://www.npmjs.com/package/@dlazy/cli) <br>
- [dLazy homepage](https://dlazy.com) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, json, shell commands, configuration] <br>
**Output Format:** [Markdown guidance with JSON pipeline snippets and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires npm or npx, a dLazy API key, and optional local media files for upload through the dLazy CLI.] <br>

## Skill Version(s): <br>
1.2.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
