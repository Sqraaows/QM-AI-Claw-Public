---
name: Stop-Slop 内容审核工具
slug: stop-slop-wrap
description: Stop-Slop 内容审核工具 — 利用 AI 模型检测和过滤垃圾内容、恶意评论、敏感信息的自动化审核工具。支持文本和图片内容分析，提供实时审核接口和批量审核模式。基于自研过滤规则和开源模型结合的方式，准确率高、误报率低。适用于社区运营者、内容平台、企业等需要对用户生成内容进行审核的场景。 | 来源：https://github.com/q15004040209-creator/stop-slop-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/stop-slop-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
