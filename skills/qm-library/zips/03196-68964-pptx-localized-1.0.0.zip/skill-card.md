## Description: <br>
Helps agents create, read, edit, split, combine, and quality-check local PowerPoint (.pptx) presentations. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[yinfeihaaaaaaaaaaa](https://clawhub.ai/user/yinfeihaaaaaaaaaaa) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, developers, and presentation authors use this skill when an agent needs to inspect, generate, modify, or validate .pptx decks in a local workspace. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Broad presentation-related triggers may cause an agent to begin local PPTX work when the user did not intend file operations. <br>
Mitigation: Use the skill only for explicit PPTX tasks and confirm the target files and output paths before editing, packing, cleanup, or conversion. <br>
Risk: Presentation editing and cleanup commands can alter local files or remove unpacked presentation assets. <br>
Mitigation: Work on copies of presentations, keep originals available, and review generated or modified decks before relying on them. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/yinfeihaaaaaaaaaaa/pptx-localized) <br>
- [Publisher profile](https://clawhub.ai/user/yinfeihaaaaaaaaaaa) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline code and shell commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce or modify local .pptx files and related extracted XML, image, PDF, or thumbnail artifacts when the agent follows the workflow.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence release.version and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
