## Description: <br>
Provides an MCP server for reading SignUpGenius profiles, groups, sign-ups, and slot reports, with limited write actions for adding group members and RSVPing to public sign-up slots. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to connect an agent to their own SignUpGenius account, inspect sign-ups and group data, and perform small account actions such as group-member adds or RSVPs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can use SignUpGenius session cookies, direct-login credentials, or a Pro API key. <br>
Mitigation: Review the npm package and fetchproxy extension before installing, and prefer project-level MCP configuration unless broad availability is intended. <br>
Risk: The add-group-member and RSVP tools make live changes to SignUpGenius data. <br>
Mitigation: Confirm write requests before execution and use the skill only with accounts and sign-ups the user is authorized to manage. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/signupgenius-mcp) <br>
- [SignUpGenius MCP npm package](https://www.npmjs.com/package/signupgenius-mcp) <br>
- [SignUpGenius MCP source](https://github.com/chrischall/signupgenius-mcp) <br>
- [Fetchproxy extension](https://github.com/chrischall/fetchproxy) <br>
- [SignUpGenius](https://www.signupgenius.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, configuration, shell commands, guidance] <br>
**Output Format:** [Markdown with JSON configuration examples and inline tool guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs may include account, group, sign-up, slot, and report data returned by the configured SignUpGenius MCP server.] <br>

## Skill Version(s): <br>
1.1.2 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
