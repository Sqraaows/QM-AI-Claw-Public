## Description: <br>
Webtoon Adapter guides Chinese-language web novel adaptation into webtoon plot breakdowns, episode tags, and per-episode scripts. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[dlazyai](https://clawhub.ai/user/dlazyai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External creators and agent users can use this skill to structure Chinese web novel material into webtoon-ready plot breakdowns, episode tags, and per-episode script text. It also guides optional dLazy CLI-backed image generation when the user intentionally wants hosted media generation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may execute dLazy CLI commands that use hosted APIs and require an API key. <br>
Mitigation: Install and run it only when dLazy-backed generation is intended, and prefer npx @dlazy/cli@1.2.0 or the DLAZY_API_KEY environment variable for less persistent setup. <br>
Risk: Prompts and uploaded media can be sent to dLazy services at api.dlazy.com and files.dlazy.com. <br>
Mitigation: Do not submit sensitive novel text, private media, or confidential assets unless the user accepts sending them to the hosted service. <br>
Risk: Stored dLazy credentials can persist in local CLI configuration. <br>
Mitigation: Use organization key rotation or revocation when access changes, and review local credential storage before deploying on shared systems. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/dlazyai/webtoon-adapter) <br>
- [dLazy CLI source](https://github.com/dlazyai/cli) <br>
- [dLazy CLI npm package](https://www.npmjs.com/package/@dlazy/cli) <br>
- [dLazy homepage](https://dlazy.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, guidance] <br>
**Output Format:** [Markdown conversation output with optional inline shell commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Chinese-language adaptation workflow; optional hosted dLazy CLI generation may return media URLs.] <br>

## Skill Version(s): <br>
1.2.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
