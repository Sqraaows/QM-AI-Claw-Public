## Description: <br>
Google Photos connector for reading, creating, updating, uploading, downloading, and deleting Google Photos albums, media items, and picker sessions through the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate a connected Google Photos account from an agent, including album workflows, media upload and retrieval, metadata updates, and Picker-based selection flows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access sensitive Google Photos data and perform read, write, upload, and download actions through a connected account. <br>
Mitigation: Install only if the user trusts oomol, review requested Google Photos scopes, and use it only when account actions are needed. <br>
Risk: Create, update, upload, and album organization actions can change Google Photos state. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write actions. <br>
Risk: Deleting a Picker session is destructive for that session workflow. <br>
Mitigation: Require explicit user approval for the specific session before running delete_picker_session. <br>
Risk: Connector schemas can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-googlephotos) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Google Photos Homepage](https://www.google.com/photos/about/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses from the oo connector runtime.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
