## Description: <br>
ShortPixel helps an agent read, create, update, and delete ShortPixel domain data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and site operators use this skill to manage ShortPixel-associated domains, inspect CDN usage, and run cache or storage purge operations after confirming the target and effect. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change ShortPixel domain associations or purge cache and stored optimized variants. <br>
Mitigation: Confirm the exact domain, payload, and intended effect before allowing add, set, revoke, cache purge, or storage purge actions. <br>
Risk: The skill requires a connected ShortPixel account and sensitive credentials managed through OOMOL. <br>
Mitigation: Install it only for users who intend to manage ShortPixel through an OOMOL-connected account, and avoid exposing raw credentials. <br>
Risk: First-time setup may require installing or reviewing the oo CLI before connector actions can run. <br>
Mitigation: Review the oo CLI installer before running setup commands, and only run setup after an authentication or connection error requires it. <br>


## Reference(s): <br>
- [ClawHub ShortPixel skill listing](https://clawhub.ai/oomol/oo-shortpixel) <br>
- [ShortPixel homepage](https://shortpixel.com) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include a data object and meta.executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
