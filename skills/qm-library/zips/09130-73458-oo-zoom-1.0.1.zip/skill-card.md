## Description: <br>
Zoom connector for reading, creating, listing, and updating Zoom meetings and users through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external collaborators, and developers use this skill to retrieve Zoom user and meeting information and to create or update Zoom meetings through an OOMOL-connected Zoom account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connecting Zoom through OOMOL and granting Zoom scopes for user and meeting access. <br>
Mitigation: Install only after reviewing the requested Zoom scopes and confirming the OOMOL account connection is appropriate for the workspace. <br>
Risk: Create and update actions can change Zoom meeting state. <br>
Mitigation: Review the live schema and confirm the exact payload and intended effect with the user before running state-changing actions. <br>
Risk: First-time setup may involve running a remote oo CLI installer. <br>
Mitigation: Treat the installer like any third-party remote installation script and review or approve it according to local security policy before execution. <br>


## Reference(s): <br>
- [Zoom Homepage](https://www.zoom.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-zoom) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Instructs the agent to inspect live connector schemas before building payloads and to confirm state-changing meeting actions before execution.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
