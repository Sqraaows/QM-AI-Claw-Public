## Description: <br>
SearchApi (searchapi.io). Use this skill for ANY SearchApi request - searching and reading data. Whenever a task involves SearchApi, use this skill instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to run SearchApi searches, retrieve cached search results, look up canonical locations, and check account usage through an OOMOL-connected SearchApi account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates through OOMOL as an intermediary for the user's SearchApi account. <br>
Mitigation: Install only when that intermediary is acceptable, and connect SearchApi through the documented OOMOL account flow. <br>
Risk: First-time setup may require running a remote oo CLI installer. <br>
Mitigation: Review OOMOL's installer source or use a trusted installation method before running the installer. <br>
Risk: Search schemas and defaults can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each payload. <br>


## Reference(s): <br>
- [SearchApi homepage](https://www.searchapi.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [SearchApi skill on ClawHub](https://clawhub.ai/oomol/oo-search-api) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action results are returned by the oo CLI as JSON with data and meta.executionId; cached result actions may return JSON or HTML content.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
