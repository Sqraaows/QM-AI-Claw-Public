## Description: <br>
Coordinator Agent monitors OpenClaw agent workspaces, sends change-only fleet briefings, prioritizes actionable issues, detects trends, and can retrigger missed cron jobs when configured. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[waltspence](https://clawhub.ai/user/waltspence) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and OpenClaw operators use this skill to monitor multiple agent workspaces, receive concise fleet-health briefings, and surface errors, handoffs, trend anomalies, or missed cron jobs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The coordinator reads configured agent workspaces and may include sensitive workspace information in external briefings. <br>
Mitigation: Restrict the workspace list to monitored projects only, exclude workspaces containing secrets, and review briefing content before enabling external delivery. <br>
Risk: The skill requires credentials for workspace access and messaging integrations. <br>
Mitigation: Use dedicated scoped credentials with read access to monitored workspaces and write access only to approved messaging channels; avoid copying broad auth profiles. <br>
Risk: Self-healing can retrigger missed cron jobs and may cause duplicate execution. <br>
Mitigation: Leave self-healing disabled unless the affected cron jobs are idempotent and safe to run more than once. <br>


## Reference(s): <br>
- [Coordinator Agent on ClawHub](https://clawhub.ai/waltspence/coordinator-agent) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown briefings and setup snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Silent mode suppresses routine messages; delivery can target Telegram, Discord, or Slack; self-healing is optional.] <br>

## Skill Version(s): <br>
1.2.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
