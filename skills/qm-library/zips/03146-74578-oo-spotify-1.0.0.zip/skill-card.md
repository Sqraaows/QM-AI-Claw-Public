## Description: <br>
Spotify (spotify.com). Use this skill for Spotify requests that read, create, update, or delete Spotify data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Spotify through OOMOL, including catalog lookup, search, recommendations, library management, playlist management, and playback control. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change Spotify account state through saves, follows, playlist edits, removals, and playback controls. <br>
Mitigation: Confirm the exact target, payload, and intended effect before any state-changing or destructive action. <br>
Risk: The skill depends on an OOMOL-connected Spotify account and the permissions granted during connection. <br>
Mitigation: Review OOMOL and Spotify permissions during connection and reconnect only when needed for missing or expired scopes. <br>


## Reference(s): <br>
- [Spotify homepage](https://spotify.com) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-spotify) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON from the OOMOL Spotify connector when executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
