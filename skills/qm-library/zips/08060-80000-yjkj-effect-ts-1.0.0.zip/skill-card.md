## Description: <br>
Effect-TS is a development guide that helps agents build, debug, review, and migrate TypeScript code using Effect v3 and v4 patterns for typed errors, dependency injection, concurrency, streams, schema validation, observability, HTTP, SQL, CLI, RPC, and Effect AI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[tenequm](https://clawhub.ai/user/tenequm) <br>

### License/Terms of Use: <br>
Apache 2.0 <br>


## Use Case: <br>
Developers and engineers use this skill to build, debug, review, and migrate Effect-TS code across stable v3 and beta v4 APIs. It helps agents choose correct Effect patterns for typed errors, dependency injection, concurrency, streams, schema validation, observability, HTTP, SQL, CLI, RPC, and AI-provider examples. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated Effect-TS code may be incorrect or unsafe to run without review, especially for HTTP, SQL, observability, and AI-provider examples. <br>
Mitigation: Review generated code before execution and verify APIs against the referenced Effect documentation for the detected Effect version. <br>
Risk: The skill documents optional OpenAI and Anthropic API-key examples. <br>
Mitigation: Provide API keys only when the task requires those providers, and avoid pasting secrets into prompts or generated source files. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/tenequm/effect-ts) <br>
- [Publisher profile](https://clawhub.ai/user/tenequm) <br>
- [Homepage](https://github.com/tenequm/skills/tree/main/skills/effect-ts) <br>
- [Effect documentation](https://effect.website/docs) <br>
- [Effect LLM topic index](https://effect.website/llms.txt) <br>
- [Effect full LLM documentation](https://effect.website/llms-full.txt) <br>
- [Effect concise API list](https://tim-smart.github.io/effect-io-ai/) <br>
- [Effect v4 source and migration guides](https://github.com/Effect-TS/effect-smol) <br>
- [Effect v4 LLM guide](https://github.com/Effect-TS/effect-smol/blob/main/LLMS.md) <br>
- [LLM corrections reference](references/llm-corrections.md) <br>
- [Migration to v4 reference](references/migration-v4.md) <br>
- [Core patterns reference](references/core-patterns.md) <br>
- [Configuration reference](references/configuration.md) <br>
- [Effect AI reference](references/effect-ai.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with TypeScript and shell code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include generated Effect-TS examples, review findings, migration notes, and configuration guidance.] <br>

## Skill Version(s): <br>
0.4.0 (source: frontmatter, changelog, release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
