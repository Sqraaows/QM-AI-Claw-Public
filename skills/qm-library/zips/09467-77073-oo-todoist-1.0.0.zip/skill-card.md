## Description: <br>
Todoist (todoist.com). Use this skill for Todoist requests involving reading, creating, and updating tasks, projects, sections, comments, labels, and user profile data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent operate a connected Todoist account through OOMOL, including listing, retrieving, creating, updating, and completing Todoist workspace items. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through a connected Todoist account. <br>
Mitigation: Use it only in ClawHub accounts and repositories where granting the documented CLI abilities is acceptable, and verify account connection state before use. <br>
Risk: Create, update, close, and comment actions can change Todoist state. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write actions. <br>
Risk: Connector schemas and upstream field behavior can change. <br>
Mitigation: Inspect the live action schema with the oo CLI before constructing each payload. <br>


## Reference(s): <br>
- [Todoist homepage](https://www.todoist.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-todoist) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses from the oo CLI when executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
