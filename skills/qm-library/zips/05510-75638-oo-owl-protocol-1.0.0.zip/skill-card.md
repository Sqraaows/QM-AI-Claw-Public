## Description: <br>
Guides agents in using the OOMOL Owl Protocol connector to read project information, read token metadata, and update token metadata. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to operate Owl Protocol through an OOMOL-connected account. It supports reading connected project information, reading a specific token metadata record, and patching one token metadata JSON object after user confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup flow can require installing the oo CLI with a pipe-to-shell command. <br>
Mitigation: Review the oo CLI installer before running it and install only when Owl Protocol access through OOMOL is intended. <br>
Risk: The skill uses an OOMOL-connected Owl Protocol account and may require sensitive credentials or scopes. <br>
Mitigation: Connect only the Owl Protocol account and scopes needed for the task, and reconnect only when an auth or scope error requires it. <br>
Risk: The patch_project_token action changes Owl Protocol token metadata. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running token metadata updates. <br>


## Reference(s): <br>
- [Owl Protocol homepage](https://owlprotocol.xyz) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-owl-protocol) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, text, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [None] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
