## Description: <br>
Troubleshooting guide for vx issues. Use when encountering installation failures, version conflicts, PATH issues, or other vx problems. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[loonghao](https://clawhub.ai/user/loonghao) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, engineers, and coding agents use this skill to diagnose vx installation, version, PATH, runtime, configuration, CI, and cache issues and choose appropriate recovery commands. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may direct an agent to run remote installer scripts directly. <br>
Mitigation: Confirm the source is trusted and prefer downloading, inspecting, and verifying installers before execution. <br>
Risk: The skill includes reset steps that can delete vx-managed local state. <br>
Mitigation: Back up important vx configuration and cached state before reset steps, and use destructive deletion only as a last-resort recovery action. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/loonghao/vx-troubleshooting) <br>
- [vx documentation](https://github.com/loonghao/vx#readme) <br>
- [vx issue tracker](https://github.com/loonghao/vx/issues) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell command blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Includes troubleshooting decision trees, diagnostics, and recovery steps; some commands can modify local vx state.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
