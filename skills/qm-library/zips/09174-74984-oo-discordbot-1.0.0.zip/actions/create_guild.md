# Discord Bot · `create_guild`

Create a guild with the platform bot token.

- **Service**: `discordbot`
- **Action**: `create_guild`
- **Action id**: `discordbot.create_guild`
- **Required scopes**: discordbot.install

## Inspect the schema

Always fetch the authoritative input/output schema before building a payload — fields and defaults can change upstream:

```bash
oo connector schema "discordbot" --action "create_guild"
```

## Run

```bash
oo connector run "discordbot" --action "create_guild" --data '{}' --json
```

Replace `{}` with a JSON object that matches the input schema. The response is `{ "data": ..., "meta": { "executionId": "..." } }`.

> **Write action.** This changes Discord Bot state. Confirm the exact payload and intended effect with the user before running.
