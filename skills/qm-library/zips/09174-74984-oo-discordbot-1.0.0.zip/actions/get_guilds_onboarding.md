# Discord Bot · `get_guilds_onboarding`

Get guild onboarding configuration.

- **Service**: `discordbot`
- **Action**: `get_guilds_onboarding`
- **Action id**: `discordbot.get_guilds_onboarding`
- **Required scopes**: discordbot.install

## Inspect the schema

Always fetch the authoritative input/output schema before building a payload — fields and defaults can change upstream:

```bash
oo connector schema "discordbot" --action "get_guilds_onboarding"
```

## Run

```bash
oo connector run "discordbot" --action "get_guilds_onboarding" --data '{}' --json
```

Replace `{}` with a JSON object that matches the input schema. The response is `{ "data": ..., "meta": { "executionId": "..." } }`.
