## Description: <br>
Enables agents to operate Discord Bot resources through OOMOL's discordbot connector for reading, creating, updating, and deleting Discord data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Discord bot workflows through an OOMOL-connected account, including guild, channel, message, role, thread, invite, scheduled event, emoji, sticker, onboarding, widget, and application command operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can perform high-impact Discord moderation and deletion actions. <br>
Mitigation: Require explicit user confirmation for bans, pruning, deletes, message posting, role changes, channel changes, and command changes before execution. <br>
Risk: Broad bot permissions or OAuth scopes could affect Discord guilds beyond the intended target. <br>
Mitigation: Verify bot permissions and OAuth scopes before use, and limit access to trusted guilds. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-discordbot) <br>
- [Discord developer applications](https://discord.com/developers/applications) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance, Configuration] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an OOMOL-connected Discord Bot account and live action schema lookup before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and SKILL.md metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
