---
name: MemPalace AI 记忆系统
slug: mempalace-wrap
description: MemPalace AI 记忆系统 — 基于 RAG（检索增强生成）技术的私有知识库解决方案，帮助用户构建个人或团队的长期记忆系统。支持文档导入、向量化存储、智能检索、上下文关联等功能。基于开源项目深度定制，提供一键部署脚本和详细配置指南。适用于需要管理大量知识资产的个人和团队，可显著提升信息检索效率和知识复用率。 | 来源：https://github.com/q15004040209-creator/mempalace-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/mempalace-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
