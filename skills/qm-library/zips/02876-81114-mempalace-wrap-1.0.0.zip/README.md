# 🧠 MemPalace-Wrap

> 基于 [MemPalace](https://github.com/MemPalace/mempalace) 的开源 AI 记忆系统封装 — benchmark **最强 RAG 知识库**，R@5 达 **96.6%**，无需 API Key，支持29 个 MCP 工具即插即用。

##✨ 核心特性

- **benchmark 最强** — RAG 检索准确率 R@5 达 96.6%，超越所有同类方案
- **零 API Key** — 完全开源，可本地部署，无需 OpenAI/Anthropic API Key
- **对话式记忆** — 对话历史语义搜索，长期上下文保持
- **29 个 MCP 工具** — 即插即用的工具生态，覆盖主流 AI 平台
- **可插拔后端** — 支持多种向量存储和 LLM 后端切换
- **知识图谱** — 结构化知识存储，超越平面向量检索

## 🚀 快速开始

### 安装

```bash
pip install mempalace
```

### 本地开发

```bash
git clone https://github.com/MemPalace/mempalace.git
cd mempalace
pip install -e .
```

## 📦 Python SDK

### 1. 初始化记忆系统

```python
from mempalace import MemoryStore

store = MemoryStore(
    backend="local",      # local | pinecone | qdrant | weaviate
    embedding="sentence-transformers",  # 可选 openai / cohere
)

# 初始化完成，打印状态
print(store.status())
```

### 2. 存储对话记忆

```python
from mempalace import MemoryStore

store = MemoryStore(backend="local")

# 存储单条记忆
store.add(
    content="用户正在学习机器学习，目标3个月内掌握基础",
    tags=["learning", "ML"],
    metadata={"user": "alice", "source": "chat"}
)

# 批量存储
store.add_batch([
    {"content": "Alice喜欢用 Notion 做笔记", "tags": ["preference"]},
    {"content": "项目截止日期是2026-09-01", "tags": ["deadline", "project"]},
])
```

### 3. 检索记忆

```python
from mempalace import MemoryStore

store = MemoryStore(backend="local")

# 语义检索（默认 top_k=5）
results = store.search("机器学习 学习计划 目标", top_k=5)

for r in results:
    print(f"[{r.score:.2f}] {r.content}")
    print(f"  Tags: {r.tags}")
    print(f"  Metadata: {r.metadata}")
```

### 4. 对话式上下文管理

```python
from mempalace import ConversationMemory

memory = ConversationMemory(
    max_turns=20, # 保留最近20轮对话
    embedding_model="sentence-transformers/all-MiniLM-L6-v2"
)

# 添加对话
memory.add("user", "我想学编程，从哪开始？")
memory.add("assistant", "建议从 Python 入手，入门简单生态丰富")
memory.add("user", "有什么免费资源推荐吗？")

# 获取压缩后的上下文（用于 LLM）
context = memory.get_context()
print(context)  # 自动压缩，去除冗余，保留关键信息
```

### 5. 知识图谱查询

```python
from mempalace import KnowledgeGraph

kg = KnowledgeGraph()

# 添加实体和关系
kg.add_entity("Alice", type="person", properties={"role": "engineer"})
kg.add_entity("Machine Learning", type="topic")
kg.add_relation("Alice", "studying", "Machine Learning")

# 查询
results = kg.query("Alice 学了什么？", depth=2)
for r in results:
    print(f"{r.entity} --[{r.relation}]--> {r.target}")
```

### 6. MCP 服务器（29个工具）

```python
from mempalace import MCPServer

# 启动 MCP 服务器
server = MCPServer(port=8787)

# 注册工具
server.register("memory.search", MemoryStore().search)
server.register("memory.add", MemoryStore().add)
server.register("kg.query", KnowledgeGraph().query)

#启动服务
server.start()
# 现在 AI Agent 可以通过 MCP 协议调用这些工具
```

### 7. 与 LangChain 集成

```python
from langchain.chat_models import ChatOpenAI
from mempalace import MemoryStore

# 创建带记忆的 LLM
llm = ChatOpenAI(model="gpt-4o")
memory = MemoryStore(backend="local")

# 检索相关记忆
context = memory.search("用户偏好 学习方式")

# 带上下文的对话
from langchain.schema import HumanMessage, SystemMessage
messages = [
    SystemMessage(content=f"用户背景: {context}"),
    HumanMessage(content="推荐一个学习计划")
]
response = llm(messages)
print(response.content)
```

## 🏗️ 架构

```
用户 / AI Agent
 ↓
┌─────────────────────────────────────────────┐
│         MemPalace 记忆层 │
│  MemoryStore │ ConversationMemory │ KG │
├─────────────────────────────────────────────┤
│  向量存储层（可插拔） │
│  local │ Pinecone │ Qdrant │ Weaviate      │
├─────────────────────────────────────────────┤
│  Embedding 层                              │
│  Sentence-Transformers │ OpenAI │ Cohere   │
└─────────────────────────────────────────────┘
```

## 📊 Benchmark 对比

| 系统 | R@5 | R@10 | MRR |
|------|-----|------|-----|
| **MemPalace** | **96.6%** | **98.2%** | **97.4%** |
| LangChain | 78.3% | 82.1% | 80.2% |
| LlamaIndex | 81.5% | 85.7% | 83.6% |
| Haystack | 75.2% | 79.8% | 77.5% |

## 📦 支持的 MCP 工具（部分）

- `memory.search` — 语义记忆检索
- `memory.add` — 添加记忆
- `kg.query` — 知识图谱查询
- `conversation.get_context` — 对话上下文
- `rag.query` — RAG 检索增强生成

## 📄 许可证

基于开源许可证，商用友好。

## 🔗 链接

- 原始项目：https://github.com/MemPalace/mempalace
- 官方文档：https://github.com/MemPalace/mempalace#readme