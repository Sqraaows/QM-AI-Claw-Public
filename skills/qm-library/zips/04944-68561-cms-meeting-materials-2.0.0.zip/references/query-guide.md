# 列表查询详解

## 两个维度的区别

| 维度 | 接口 | 口径 | 适用场景 |
|---|---|---|---|
| **归属维度** | 4.1 chatListByPage | 查「我的」慧记（归属当前用户名下的记录） | 浏览自己的纪要、搜索、筛选 |
| **会议维度** | 4.11 listHuiJiIdsByMeetingNumber | 按「我参加的视频会议」查（他人录制也可查到） | 已知会议号、查找特定会议的纪要 |

## 路由规则（严格遵守）

```
用户提供了会议号？
  ├─ 是 → 4.11（按会议号精确查）
  └─ 否 → 4.1（走归属维度查询）
```

用户说"我的进行中会议"但上下文记有会议号 → 仍走 4.1，不自动取上下文会议号。

## 常用命令

```bash
# 归属维度：我的慧记
python3 scripts/huiji/list-my-meetings.py 0 20

# 归属维度：只看进行中
python3 scripts/huiji/list-my-meetings.py 0 20 --state 0

# 归属维度：只看已完成
python3 scripts/huiji/list-my-meetings.py 0 20 --state 2

# 归属维度：按名称搜索
python3 scripts/huiji/list-my-meetings.py 0 20 --name-blur "Q2目标"

# 会议维度：按会议号查
python3 scripts/huiji/list-by-meeting-number.py <meeting-number>
```

## 无结果引导

4.1 查无结果时主动提醒用户："归属维度没有找到记录。如果你参加的是他人录制的会议，请提供会议号，我用会议维度帮你查。"

## 会议状态（combineState）

| 值 | 含义 | 说明 |
|---|---|---|
| 0 | 进行中 | 会议尚未结束，持续拉取新片段 |
| 1 | 处理中 | 会议已结束，二次转写处理中 |
| 2 | 已完成 | 会议已结束，可全量拉取 |
| 3 | 失败 | 会议转写失败 |

## _id 透明处理

4.1 返回的 `_id` 可能有 `__数字` 后缀（如 `abc123__45678`）：
- 优先使用 `originChatId`
- 若无 `originChatId` 且 `_id` 含 `__`，截取前缀作为 `meetingChatId`
- `list-my-meetings.py --json` 已透明输出 `normalizedMeetingChatId` 字段
