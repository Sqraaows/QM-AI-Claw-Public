# 原文获取 & 存储格式

## 统一入口

```bash
python3 scripts/huiji/get-transcript.py <meetingChatId> [--name "会议名称"]
```

## 自动处理流程

```
用户请求原文
  ├─ 会议已结束（state=completed）？
  │    ├─ 二次转写已就绪（state=2）→ 全量拉取二次改写分片
  │    └─ 二次转写未就绪（state=1/3）→ 全量拉取一转分片
  └─ 会议进行中（state=active）？
       → 增量拉取（追加新片段，不覆盖已有内容）
```

## 存储格式

每场会议的素材存放在独立目录：
```
{CMS_MEETING_MATERIALS_ROOT}/{gateway}/{meeting_chat_id}/
├── manifest.json       # 元数据
├── checkpoint.json      # 断点（last_start_time）
├── fragments.ndjson     # 分片内容
└── transcript.txt      # 纯文本拼接
```

### fragments.ndjson

一行一条 JSON，记录一个分片：
```json
{"startTime": 0, "text": "各位好，今天我们来说说Q2的目标"}
{"startTime": 5000, "text": "我觉得可以先看看上个季度的数据"}
{"startTime": 12000, "text": "对，我这里有一些数字想分享"}
```

**字段说明：**
- `startTime`：毫秒级时间戳，标识这段话在录音中的位置
- `text`：转写文本
- `_segment_id`、`_version`、`_appended_at`：内部管理字段

**幂等追加：** 同一 `startTime` 不会重复写入。二次改写（version=2）会覆盖一转（version=1）。

### transcript.txt

纯文本拼接，方便直接 `cat` 查看：
```
[00:00:00] 各位好，今天我们来说说Q2的目标
[00:00:05] 我觉得可以先看看上个季度的数据
[00:00:12] 对，我这里有一些数字想分享
```

**注意：** 每次调用 `trigger-pull.py` 或 `get-transcript.py` 都会重建此文件。

### manifest.json

```json
{
  "meeting_chat_id": "huijiXgMt_xxx",
  "name": "Q2目标对齐会议",
  "status": "active",
  "is_fully_pulled": false,
  "fragment_count": 42,
  "last_sync": "2026-04-01T22:00:00+08:00",
  "created_at": "2026-04-01T21:00:00+08:00",
  "started_at": "2026-04-01T21:00:00+08:00"
}
```

**status 含义：**
- `active`：会议进行中
- `completed`：会议已结束
- `pending`：会议已结束，二次转写处理中

### checkpoint.json

记录增量拉取的断点：
```json
{
  "last_start_time": 1234567,
  "updated_at": "2026-04-01T22:00:00+08:00"
}
```

`last_start_time` 是 `startTime` 的最大值，下次增量拉取时传给 API。

## 时间戳规范

所有接口返回时间字段均为 **13 位毫秒级 Unix 时间戳（UTC+8）**。

**向用户展示时必须转换，禁止展示原始数字：**
- 日期时间 → `2026-03-29 13:59:10`
- `startTime`（录音内偏移量）→ `00:12:34`
- `realTime`（现实时间戳）→ 绝对时间 `13:45:02`
