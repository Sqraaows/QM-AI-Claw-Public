---
name: cms-meeting-materials
description: 从 CMS AI慧记 拉取会议内容（转写原文）。用于查询会议列表、拉取已结束会议的全量内容、持续拉取进行中会议的新片段。不做 AI 分析——分析由上层应用决定。
metadata:
  requires:
    env: [XG_BIZ_API_KEY]
homepage: https://github.com/evan-zhang/agent-factory/issues
---

# CMS AI慧记 — 会议内容获取

**版本**: 2.0.0

**核心定位**：把会议内容完整、可信赖地拉下来，存到本地文件。上层应用（AI 问答、写纪要、互动讨论）基于拉取到的内容自行处理，skill 本身不负责分析。

---

## 能力边界（2.0 精简版）

| 能力 | 说明 |
|------|------|
| 📋 **会议列表查询** | 归属维度 / 会议号维度 |
| 📄 **原文获取** | 全量拉取 + 增量追加，统一入口 |
| 🔄 **增量拉取** | 进行中会议持续追加新片段 |
| 🛑 **停止监控** | 手动停止对某场会议的持续拉取 |

**不做的事**：
- AI 总结 / 纪要生成（上层应用的事）
- 实时流展示（上层应用的事）
- 滚动摘要 / 决策提取（上层应用的事）

---

## When to Use

- 查询"我的慧记"或指定会议号下的会议列表
- 拉取已结束会议的完整转写原文
- 会议进行中持续拉取最新片段（由 OpenClaw Cron Job 驱动）
- 获取某场会议的 transcript.txt 或 fragments.ndjson 供上层应用使用

---

## 接口索引（仅保留实际使用的）

| 接口 | 路径 | 用途 |
|------|------|------|
| chatListByPage | POST /ai-huiji/meetingChat/chatListByPage | 归属维度分页查询 |
| listHuiJiIdsByMeetingNumber | POST /ai-huiji/meetingChat/listHuiJiIdsByMeetingNumber | 会议号维度查询 |
| splitRecordList | POST /ai-huiji/meetingChat/splitRecordList | 全量拉取（已结束会议） |
| splitRecordListV2 | POST /ai-huiji/meetingChat/splitRecordListV2 | 增量拉取（进行中会议） |
| checkSecondSttV2 | POST /ai-huiji/meetingChat/checkSecondSttV2 | 二次改写（质量更高） |

Base URL：`sg-al-ai-voice-assistant.mediportal.com.cn/api`
鉴权：仅需 `XG_BIZ_API_KEY`（Header），无需 access-token。

---

## 快速开始

```bash
# 1. 设置 API Key
export XG_BIZ_API_KEY='你的 appKey'

# 2. 查询我的会议（最近 20 条）
python3 scripts/huiji/list-my-meetings.py 0 20

# 3. 按会议号查
python3 scripts/huiji/list-by-meeting-number.py <meeting-number>

# 4. 获取会议原文（全量，含二次改写）
python3 scripts/huiji/get-transcript.py <meetingChatId>

# 5. 触发一次增量拉取（进行中会议追加新片段）
python3 scripts/huiji/trigger-pull.py <meetingChatId>

# 6. 停止持续拉取
python3 scripts/huiji/stop-pull.py <meetingChatId>
```

---

## 意图路由

| 用户意图 | 调用的脚本 |
|---------|-----------|
| "我的慧记" / "最近会议" | `list-my-meetings.py` |
| "会议号 xxx 的会议" | `list-by-meeting-number.py` |
| "会议内容" / "原文" / "转写" | `get-transcript.py` |
| "开始监控" / "持续拉取" | `trigger-pull.py`（配合 OpenClaw Cron Job 使用） |
| "停止监控" | `stop-pull.py` |

---

## 持续拉取机制（OpenClaw Cron 驱动）

**Skill 内部不维护轮询线程**，由 OpenClaw Cron Job 外部驱动：

```
OpenClaw Cron Job（每 60s）
  → trigger-pull.py <meetingChatId>
  → pull_core.py（单次增量拉取）
  → 追加写入 fragments.ndjson + transcript.txt
```

建议的 Cron Job 配置：
```bash
# 每 60s 检查进行中会议并增量拉取
cron job: python3 scripts/huiji/trigger-pull.py {meeting_chat_id}
```

---

## 存储格式

```
{OPENCLAW_STATE_DIR}/cms-meeting-materials/{gateway}/{meeting_chat_id}/
├── manifest.json       # 元数据（状态、片段数、拉取时间）
├── fragments.ndjson    # 结构化分片（startTime + text，一行一条）
└── transcript.txt     # 纯文本拼接（方便直接 cat 查看）
```

**fragments.ndjson 格式**：
```json
{"startTime": 0, "text": "各位好，今天我们来说说Q2的目标"}
{"startTime": 5000, "text": "我觉得可以先看看上个季度的数据"}
```

---

## Core Rules

1. **纯拉取，不分析**：skill 只负责把内容存好，不调用 LLM 做总结/提取
2. **时间戳必须转换**：向用户展示时转为 `YYYY-MM-DD HH:MM:SS`，不暴露原始毫秒时间戳
3. **隐藏技术细节**：不向用户暴露接口名、JSON 字段名、缓存路径等技术过程
4. **业务错误停止**：resultCode≠1 时停止执行并告知用户，不重试
5. **幂等追加**：增量拉取只追加新片段，不覆盖已有内容

---

## 环境变量

| 变量 | 必须 | 说明 |
|------|------|------|
| `XG_BIZ_API_KEY` | 是 | API 鉴权 appKey |
| `CMS_MEETING_MATERIALS_ROOT` | 否 | 自定义存储根目录 |
| `OPENCLAW_GATEWAY` | 否 | 多 gateway 场景隔离 |

---

## References

- `references/query-guide.md` — 列表查询详解（路由规则 / 状态过滤 / ID 归一化）
- `references/openapi/` — 5个 API 的接口文档
