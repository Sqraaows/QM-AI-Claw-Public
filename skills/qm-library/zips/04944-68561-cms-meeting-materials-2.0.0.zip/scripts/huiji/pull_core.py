#!/usr/bin/env python3
"""
pull_core.py — 会议内容拉取核心逻辑（v2.0）

职责：
  - 调用 splitRecordList（全量）或 splitRecordListV2（增量）拉取分片
  - 追加写入 fragments.ndjson（幂等，按 startTime 去重）
  - 重建 transcript.txt（方便直接查看）
  - 更新 manifest.json（元数据）

外部驱动方式：
  - OpenClaw Cron Job 定期调用 trigger-pull.py
  - trigger-pull.py 调用 run_pull_once()
  - skill 本身不维护轮询线程
"""

import json
import os
import time
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

TZ = timezone(timedelta(hours=8))

API_BASE = "https://sg-al-ai-voice-assistant.mediportal.com.cn/api"
URL_INCREMENTAL = f"{API_BASE}/open-api/ai-huiji/meetingChat/splitRecordListV2"
URL_FULL = f"{API_BASE}/open-api/ai-huiji/meetingChat/splitRecordList"
URL_SECOND_STT = f"{API_BASE}/open-api/ai-huiji/meetingChat/checkSecondSttV2"
URL_BY_MEETING_NUMBER = f"{API_BASE}/open-api/ai-huiji/meetingChat/listHuiJiIdsByMeetingNumber"

LOCK_TTL_SECONDS = 150


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------
class ApiCallError(RuntimeError):
    def __init__(self, message: str, http_status=None):
        super().__init__(message)
        self.http_status = http_status


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------
def now_iso() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def now_epoch() -> int:
    return int(time.time())


def resolve_gateway_name(gateway=None) -> str:
    if gateway:
        return str(gateway).strip()
    for key in ("OPENCLAW_GATEWAY", "OPENCLAW_GATEWAY_NAME", "GATEWAY", "GATEWAY_NAME"):
        val = os.environ.get(key)
        if val:
            return str(val).strip()
    return "default"


def resolve_materials_root(gateway=None) -> Path:
    explicit = os.environ.get("CMS_MEETING_MATERIALS_ROOT")
    if explicit:
        base = Path(explicit).expanduser().resolve()
    else:
        base = (Path.home() / ".openclaw" / "cms-meeting-materials").resolve()
    root = base / resolve_gateway_name(gateway)
    root.mkdir(parents=True, exist_ok=True)
    return root


def build_headers() -> dict:
    app_key = os.environ.get("XG_BIZ_API_KEY")
    if not app_key:
        raise RuntimeError("请设置环境变量 XG_BIZ_API_KEY")
    return {"Content-Type": "application/json", "appKey": app_key}


def _call_api(url: str, body: dict, timeout: int = 60) -> dict:
    headers = build_headers()
    try:
        resp = requests.post(url, json=body, headers=headers, timeout=timeout, verify=False)
        if resp.status_code >= 400:
            msg = resp.text[:300]
            raise ApiCallError(f"HTTP {resp.status_code}: {msg}", http_status=resp.status_code)
        return resp.json()
    except requests.exceptions.RequestException as e:
        status = getattr(getattr(e, "response", None), "status_code", None)
        raise ApiCallError(f"network_error: {e}", http_status=status)


# ---------------------------------------------------------------------------
# API 调用
# ---------------------------------------------------------------------------
def fetch_incremental(meeting_chat_id: str, last_start_time=None) -> list:
    """调用 splitRecordListV2，增量拉取新分片。"""
    body = {"meetingChatId": meeting_chat_id}
    if last_start_time is not None:
        body["lastStartTime"] = last_start_time
    result = _call_api(URL_INCREMENTAL, body)
    if result.get("resultCode") != 1:
        raise RuntimeError(f"splitRecordListV2 失败: {result.get('resultMsg')}")
    return [f for f in (result.get("data") or []) if f.get("startTime") is not None]


def fetch_full(meeting_chat_id: str) -> list:
    """调用 splitRecordList，全量拉取（用于已结束会议）。"""
    result = _call_api(URL_FULL, {"meetingChatId": meeting_chat_id})
    if result.get("resultCode") != 1:
        raise RuntimeError(f"splitRecordList 失败: {result.get('resultMsg')}")
    return [f for f in (result.get("data") or []) if f.get("startTime") is not None]


def fetch_second_stt(meeting_chat_id: str) -> dict:
    """
    调用 checkSecondSttV2，返回二次改写分片。
    state=2 时返回 sttPartList（质量更高的版本）。
    """
    result = _call_api(URL_SECOND_STT, {"meetingChatId": meeting_chat_id}, timeout=30)
    if result.get("resultCode") != 1:
        return {"state": None, "fragments": []}
    state = result.get("state")
    if state == 2:
        frags = [f for f in (result.get("sttPartList") or []) if f.get("startTime") is not None]
        return {"state": state, "fragments": frags}
    return {"state": state, "fragments": []}


def detect_meeting_status(meeting_chat_id: str) -> str:
    """
    检测会议状态：
    - active   ：会议进行中（state=0）
    - completed：会议已结束且二次转写完成（state=2）
    - pending  ：会议已结束但二次转写未完成（state=1/3）
    - unknown  ：无法判断
    """
    result = fetch_second_stt(meeting_chat_id)
    state = result.get("state")
    if state == 2:
        return "completed"
    if state == 0:
        return "active"
    if state in (1, 3):
        return "pending"
    return "unknown"


def resolve_meeting_chat_id_by_number(meeting_number: str, last_ts=None) -> dict:
    """通过会议号解析 meetingChatId。"""
    if not meeting_number:
        raise RuntimeError("meeting_number 不能为空")
    if last_ts is None:
        last_ts = int((time.time() - 10 * 24 * 3600) * 1000)

    result = _call_api(URL_BY_MEETING_NUMBER, {
        "meetingNumber": str(meeting_number),
        "lastTs": int(last_ts),
    }, timeout=30)
    if result.get("resultCode") != 1:
        raise RuntimeError(f"listHuiJiIdsByMeetingNumber 失败: {result.get('resultMsg')}")

    data = result.get("data") or []
    if not data:
        raise RuntimeError(f"meetingNumber={meeting_number} 未查询到 meetingChatId")

    picked = sorted(data, key=lambda x: x.get("createTime") or 0, reverse=True)[0]
    chat_id = picked.get("meetingChatId")
    if not chat_id:
        raise RuntimeError("返回结果缺少 meetingChatId")

    return {
        "meetingNumber": str(meeting_number),
        "meetingChatId": str(chat_id),
        "open": bool(picked.get("open")),
    }


# ---------------------------------------------------------------------------
# MeetingStore — 内容存储管理
# ---------------------------------------------------------------------------
class MeetingStore:
    """
    管理单场会议的素材文件：
    - manifest.json   ：元数据（状态、片段数、拉取时间）
    - checkpoint.json  ：断点（last_start_time）
    - fragments.ndjson ：分片内容（一行一条 JSON）
    - transcript.txt   ：纯文本拼接（方便 cat 查看）
    - .stop            ：停止标记文件
    - .pull.lock       ：分布式锁
    """

    def __init__(self, meeting_chat_id: str, gateway=None):
        self.gateway = resolve_gateway_name(gateway)
        self.meeting_chat_id = meeting_chat_id
        self.dir = resolve_materials_root(self.gateway) / meeting_chat_id
        self.dir.mkdir(parents=True, exist_ok=True)

        self.manifest_path = self.dir / "manifest.json"
        self.checkpoint_path = self.dir / "checkpoint.json"
        self.fragments_path = self.dir / "fragments.ndjson"
        self.transcript_path = self.dir / "transcript.txt"
        self.stop_path = self.dir / ".stop"
        self.lock_path = self.dir / ".pull.lock"

    # ---- manifest ----
    def load_manifest(self) -> dict:
        if self.manifest_path.exists():
            try:
                return json.loads(self.manifest_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {
            "meeting_chat_id": self.meeting_chat_id,
            "name": "",
            "status": "unknown",
            "is_fully_pulled": False,
            "fragment_count": 0,
            "last_sync": None,
            "created_at": now_iso(),
            "started_at": now_iso(),
        }

    def save_manifest(self, manifest: dict):
        manifest["last_sync"] = now_iso()
        tmp = self.manifest_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.manifest_path)

    # ---- checkpoint ----
    def load_checkpoint(self) -> dict:
        if self.checkpoint_path.exists():
            try:
                return json.loads(self.checkpoint_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {"last_start_time": None, "updated_at": None}

    def save_checkpoint(self, last_start_time):
        tmp = self.checkpoint_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({
            "last_start_time": last_start_time,
            "updated_at": now_iso()
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.checkpoint_path)

    # ---- fragments.ndjson ----
    def load_existing_segment_keys(self) -> set:
        """加载已有片段的 startTime 集合（用于幂等去重）。"""
        if not self.fragments_path.exists():
            return set()
        keys = set()
        try:
            with open(self.fragments_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    obj = json.loads(line)
                    keys.add(obj.get("_segment_id"))
        except Exception:
            pass
        return keys

    def append_fragments(self, frags: list, version: int = 1) -> int:
        """
        追加分片到 fragments.ndjson（幂等，按 _segment_id 去重）。
        version=1：一转分片；version=2：二次改写分片（会覆盖一转）。
        """
        existing = self.load_existing_segment_keys()
        new_count = 0
        with open(self.fragments_path, "a", encoding="utf-8") as f:
            for frag in frags:
                seg_id = str(frag.get("startTime"))
                if seg_id in existing and version == 1:
                    continue  # 一转已存在，跳过（允许二次改写覆盖）
                record = {
                    "_meeting_chat_id": self.meeting_chat_id,
                    "_segment_id": seg_id,
                    "_version": version,
                    "_appended_at": now_iso(),
                    **frag,
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
                existing.add(seg_id)
                new_count += 1
        return new_count

    # ---- transcript.txt ----
    def rebuild_transcript(self) -> int:
        """从 fragments.ndjson 重建 transcript.txt。"""
        if not self.fragments_path.exists():
            return 0
        seen = {}
        with open(self.fragments_path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                obj = json.loads(line)
                seg_id = obj.get("_segment_id")
                ver = obj.get("_version", 1)
                # 同一 startTime 保留版本号更高的（2=二次改写 > 1=一转）
                if seg_id not in seen or ver > seen[seg_id].get("_version", 1):
                    seen[seg_id] = obj

        sorted_frags = sorted(seen.values(), key=lambda x: x.get("startTime") or 0)
        lines = []
        for frag in sorted_frags:
            text = frag.get("text") or ""
            start_ms = frag.get("startTime")
            if start_ms is not None:
                total_secs = start_ms // 1000
                hrs, rem = divmod(total_secs, 3600)
                mins, secs = divmod(rem, 60)
                ts_str = f"{hrs:02d}:{mins:02d}:{secs:02d}"
            else:
                ts_str = "??"
            lines.append(f"[{ts_str}] {text}")

        tmp = self.transcript_path.with_suffix(".txt.tmp")
        tmp.write_text("\n".join(lines), encoding="utf-8")
        tmp.replace(self.transcript_path)
        return len(lines)

    # ---- stop ----
    def should_stop(self) -> bool:
        return self.stop_path.exists()

    def write_stop(self):
        self.stop_path.write_text(now_iso(), encoding="utf-8")

    def clear_stop(self):
        try:
            self.stop_path.unlink(missing_ok=True)
        except Exception:
            pass

    # ---- lock ----
    def acquire_lock(self, ttl_seconds: int = LOCK_TTL_SECONDS) -> bool:
        """原子创建锁文件，TTL 防止僵尸锁。"""
        now = now_epoch()
        payload = {
            "gateway": self.gateway,
            "meeting_chat_id": self.meeting_chat_id,
            "pid": os.getpid(),
            "acquired_at": now,
            "expires_at": now + ttl_seconds,
        }
        for _ in range(2):
            try:
                fd = os.open(self.lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False)
                return True
            except FileExistsError:
                try:
                    existing = json.loads(self.lock_path.read_text(encoding="utf-8"))
                    exp = int(existing.get("expires_at") or 0)
                except Exception:
                    exp = 0
                if exp <= now:
                    try:
                        self.lock_path.unlink(missing_ok=True)
                    except Exception:
                        pass
                    continue
                return False
        return False

    def release_lock(self):
        try:
            self.lock_path.unlink(missing_ok=True)
        except Exception:
            pass

    def is_locked(self) -> bool:
        if not self.lock_path.exists():
            return False
        try:
            existing = json.loads(self.lock_path.read_text(encoding="utf-8"))
            exp = int(existing.get("expires_at") or 0)
            return exp > now_epoch()
        except Exception:
            return False


# ---------------------------------------------------------------------------
# 核心拉取函数（供外部调用）
# ---------------------------------------------------------------------------
@dataclass
class PullResult:
    status: str           # "ok" | "completed" | "stopped" | "skipped_locked" | "failed"
    meeting_chat_id: str
    new_fragments: int = 0
    total_fragments: int = 0
    runtime_status: str = "unknown"  # "active" | "completed" | "pending" | "unknown"
    checkpoint: int = None
    stopped_reason: str = ""
    error: str = ""
    materials_dir: str = ""


def run_pull_once(
    meeting_chat_id: str,
    gateway=None,
    name: str = "",
    force: bool = False,
) -> PullResult:
    """
    执行一次拉取（增量追加或全量覆盖）。

    逻辑：
    1. 加锁，防止多进程并发拉同一会议
    2. 检测会议状态（active / completed / pending）
    3. 增量追加新片段（active）或全量拉取（completed）
    4. 更新 checkpoint 和 manifest
    5. 解锁

    由 OpenClaw Cron Job 定期调用，或用户手动 trigger-pull.py 调用。
    """
    store = MeetingStore(meeting_chat_id=meeting_chat_id, gateway=gateway)

    # 加锁
    if not store.acquire_lock():
        return PullResult(
            status="skipped_locked",
            meeting_chat_id=meeting_chat_id,
            materials_dir=str(store.dir),
        )

    try:
        # 检查停止标记
        if store.should_stop():
            store.clear_stop()
            manifest = store.load_manifest()
            manifest["status"] = "stopped"
            manifest["stopped_reason"] = "manual_stop"
            manifest["stopped_at"] = now_iso()
            store.save_manifest(manifest)
            return PullResult(
                status="stopped",
                meeting_chat_id=meeting_chat_id,
                stopped_reason="manual_stop",
                materials_dir=str(store.dir),
            )

        manifest = store.load_manifest()
        if name and not manifest.get("name"):
            manifest["name"] = name
        if not manifest.get("started_at"):
            manifest["started_at"] = now_iso()

        # 检测会议状态
        try:
            runtime_status = detect_meeting_status(meeting_chat_id)
        except Exception as e:
            return PullResult(
                status="failed",
                meeting_chat_id=meeting_chat_id,
                error=str(e),
                materials_dir=str(store.dir),
            )

        # 增量拉取
        checkpoint = store.load_checkpoint()
        last_start_time = checkpoint.get("last_start_time")

        try:
            if runtime_status == "completed":
                # 已结束 → 全量拉取（重新拉完整内容）
                frags = fetch_full(meeting_chat_id)
                store.append_fragments(frags, version=1)
            else:
                # 进行中 / pending → 增量追加
                frags = fetch_incremental(meeting_chat_id, last_start_time)
                store.append_fragments(frags, version=1)
        except Exception as e:
            return PullResult(
                status="failed",
                meeting_chat_id=meeting_chat_id,
                error=str(e),
                materials_dir=str(store.dir),
            )

        # 更新 checkpoint
        if frags:
            max_start = max(f.get("startTime") or 0 for f in frags)
            store.save_checkpoint(max_start)

        # 重建 transcript.txt
        total = store.rebuild_transcript()

        # 更新 manifest
        manifest["status"] = runtime_status
        manifest["fragment_count"] = total
        manifest["is_fully_pulled"] = (runtime_status == "completed")
        store.save_manifest(manifest)

        new_count = len(frags)

        if runtime_status == "completed":
            return PullResult(
                status="completed",
                meeting_chat_id=meeting_chat_id,
                new_fragments=new_count,
                total_fragments=total,
                runtime_status=runtime_status,
                checkpoint=checkpoint.get("last_start_time"),
                materials_dir=str(store.dir),
            )

        return PullResult(
            status="ok",
            meeting_chat_id=meeting_chat_id,
            new_fragments=new_count,
            total_fragments=total,
            runtime_status=runtime_status,
            checkpoint=checkpoint.get("last_start_time"),
            materials_dir=str(store.dir),
        )

    finally:
        store.release_lock()
