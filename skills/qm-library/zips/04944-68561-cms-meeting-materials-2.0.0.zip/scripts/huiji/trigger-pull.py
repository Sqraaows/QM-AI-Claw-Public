#!/usr/bin/env python3
"""
trigger-pull.py — 触发一次会议内容拉取

直接调用 pull_core.run_pull_once()，不启动子进程。

用法：
    python3 trigger-pull.py <meetingChatId> [--gateway <name>]

由 OpenClaw Cron Job 定期调用，或用户手动触发。
"""

import argparse
import json
import sys
from datetime import datetime, timezone, timedelta

TZ = timezone(timedelta(hours=8))

from pull_core import run_pull_once


def main():
    parser = argparse.ArgumentParser(description="触发一次会议内容拉取（增量追加）")
    parser.add_argument("meeting_chat_id", help="慧记会议 ID（meetingChatId）")
    parser.add_argument("--gateway", default="", help="可选 gateway 名称")
    parser.add_argument("--name", default="", help="可选，会议名称（写入 manifest）")
    parser.add_argument("--force", action="store_true", help="强制执行（忽略已全量拉取标记）")
    args = parser.parse_args()

    result = run_pull_once(
        meeting_chat_id=args.meeting_chat_id,
        gateway=args.gateway or None,
        name=args.name,
        force=args.force,
    )

    # human-readable output
    ts = datetime.now(TZ).isoformat(timespec="seconds")

    if result.status == "skipped_locked":
        print(f"[{ts}] ⚠️  拉取被跳过：另一进程正在拉取此会议（{args.meeting_chat_id}）")
        print(f"    目录：{result.materials_dir}")
        sys.exit(0)

    if result.status == "stopped":
        print(f"[{ts}] ⏹  拉取已停止：{result.stopped_reason}")
        sys.exit(0)

    if result.status == "failed":
        print(f"[{ts}] ❌ 拉取失败：{result.error}")
        sys.exit(1)

    if result.status == "ok":
        print(f"[{ts}] ✅ 增量拉取完成")
        print(f"    会议：{result.meeting_chat_id}")
        print(f"    状态：{result.runtime_status}")
        print(f"    新增片段：{result.new_fragments}")
        print(f"    累计片段：{result.total_fragments}")
        print(f"    目录：{result.materials_dir}")
        sys.exit(0)

    if result.status == "completed":
        print(f"[{ts}] ✅ 全量拉取完成（会议已结束）")
        print(f"    会议：{result.meeting_chat_id}")
        print(f"    累计片段：{result.total_fragments}")
        print(f"    目录：{result.materials_dir}")
        sys.exit(0)

    # fallback
    print(json.dumps({
        "meeting_chat_id": result.meeting_chat_id,
        "status": result.status,
        "runtime_status": result.runtime_status,
        "new_fragments": result.new_fragments,
        "total_fragments": result.total_fragments,
        "materials_dir": result.materials_dir,
        "timestamp": ts,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
