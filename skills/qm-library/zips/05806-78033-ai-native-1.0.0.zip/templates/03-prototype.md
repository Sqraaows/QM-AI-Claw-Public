# Stage 3 ｜ Prototype 原型

> 详细规范见 [workflow-spec](https://github.com/znlm1229/vibe-coding-lab/blob/main/workflow-spec/specification.md#阶段-3--prototype-原型)
>
> **要点**：解决最大不确定性；最小可运行；用完即弃；**当无真正不确定性时直接跳过**。

## 决定

- [ ] **跳过本阶段** — 理由：<...>
- [ ] **构建原型** — 解决的不确定性：<...>

## 原型位置

<!-- 代码 / 截图 / spike 分支 / Artifact 路径 -->

## 验证 / 证伪了什么

<!-- 一段话说明：原型证明了什么、推翻了什么、导出了什么结论 -->

## 对 SPEC 的影响

<!-- 原型让哪些 SPEC 字段更确定？哪些可以删掉？哪些新增了？ -->
