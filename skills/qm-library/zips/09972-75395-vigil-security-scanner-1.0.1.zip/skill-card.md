## Description: <br>
Onchain security scanner on Base — scan token approvals, detect honeypots, analyze contracts for rugpull indicators, and score contract safety. Keyless read-only scanning via VIGIL API. Revoke actions require Bankr auth and are gated separately. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[vigilcodes](https://clawhub.ai/user/vigilcodes) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External DeFi traders, wallet operators, and developers use this skill to inspect Base wallet approvals and token contracts before trading or managing onchain exposure. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The security evidence marks the release suspicious because the skill presents mostly read-only scanning while shipping write-capable crypto and reporting scripts. <br>
Mitigation: Inspect commands before running them, and avoid revoke or report scripts unless you intentionally want to submit reports or initiate Bankr transactions. <br>
Risk: BANKR_API_KEY is a sensitive credential for write-capable revocation flows. <br>
Mitigation: Treat BANKR_API_KEY as read-write secret material and expose it only in the environment used for intentional revocation actions. <br>
Risk: Wallet and token addresses may be sent to external VIGIL or Bankr services. <br>
Mitigation: Use the skill only when sharing those addresses with the external services named in the artifact is acceptable. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/vigilcodes/vigil-security-scanner) <br>
- [VIGIL API Reference](references/api-reference.md) <br>
- [VIGIL Bankr Integration Guide](references/bankr-integration.md) <br>
- [VIGIL Contract Addresses](references/contracts.md) <br>
- [VIGIL public endpoint](https://mcp.vigil.codes) <br>
- [Bankr VIGIL API](https://api.bankr.bot/vigil) <br>


## Skill Output: <br>
**Output Type(s):** [text, JSON, shell commands, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON API results] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs include wallet approval findings, token safety scores, honeypot indicators, rugpull indicators, market context, and recommendations.] <br>

## Skill Version(s): <br>
1.0.1 (source: ClawHub release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
