## Description: <br>
UptimeRobot (uptimerobot.com). Use this skill for reading, creating, updating, and deleting UptimeRobot data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to inspect UptimeRobot account data and manage monitors from an agent session. It supports listing and reading monitors, discovering alert contacts, and performing confirmed create, update, and delete operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to credentials through an OOMOL-connected UptimeRobot account. <br>
Mitigation: Use the intended OOMOL account connection only, avoid exposing raw tokens, and reconnect only when an auth or connection error requires it. <br>
Risk: Create and update actions change UptimeRobot monitor state. <br>
Mitigation: Inspect the live connector schema first and confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: Delete actions can remove monitor data. <br>
Mitigation: Confirm the target monitor and obtain explicit user approval before running destructive actions. <br>
Risk: Security evidence flags a bundled review helper pattern that may bypass normal approval and sandbox controls. <br>
Mitigation: Review the helper before installation or invocation and prefer --no-yolo or AUTOREVIEW_YOLO=0 unless bypass behavior is intentionally required. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-uptimerobot) <br>
- [UptimeRobot homepage](https://uptimerobot.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [OOMOL UptimeRobot connection](https://console.oomol.com/app-connections?provider=uptimerobot) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema checks before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
