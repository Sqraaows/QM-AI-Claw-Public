## Description: <br>
ScrapingAnt helps agents scrape web pages, convert pages to Markdown, extract structured JSON data with AI, and check ScrapingAnt API credit usage through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to operate ScrapingAnt from an OOMOL-connected account for web scraping, Markdown conversion, AI-assisted data extraction, and API credit checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected ScrapingAnt account and can use sensitive service credentials through the connector. <br>
Mitigation: Use the OOMOL connector flow so credentials remain server-side, inspect the live connector schema before each action, and reconnect only when an authentication or scope error requires it. <br>
Risk: Scraping actions can return page content and response details such as HTML, text, cookies, headers, XHRs, and iframes from user-selected URLs. <br>
Mitigation: Review target URLs and returned data before reusing, storing, or sharing outputs, especially when scraped pages may contain private or sensitive information. <br>
Risk: Connector schemas and upstream ScrapingAnt behavior can change over time. <br>
Mitigation: Fetch the authoritative action schema with `oo connector schema` before constructing each payload and send JSON that matches the current schema. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-scrapingant) <br>
- [ScrapingAnt Homepage](https://scrapingant.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses may include scraped HTML, text, cookies, headers, XHR data, iframes, Markdown content, extracted JSON fields, execution metadata, or API credit status depending on the selected action.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
