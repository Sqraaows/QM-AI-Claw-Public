## Description: <br>
Hunter (hunter.io) lets an agent search, verify, and enrich professional contact and company data through an OOMOL-connected Hunter account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Sales, marketing, recruiting, and operations users can use this skill to discover company contacts, find or verify professional email addresses, enrich people or company records, and inspect Hunter account information through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected Hunter account and may expose account or enrichment data through connector responses. <br>
Mitigation: Use it only with an intended OOMOL-connected Hunter account and avoid sharing returned contact or account data beyond the user's authorized workflow. <br>
Risk: Connector input schemas and defaults can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>
Risk: Actions that create, update, send, post, delete, or remove data can change external service state if such actions are added later. <br>
Mitigation: Confirm the exact payload and expected effect with the user before state-changing actions, and require explicit approval for destructive actions. <br>
Risk: Authentication, connection scope, expired credentials, or billing issues can block execution. <br>
Mitigation: Run setup, reconnection, or billing steps only after the matching command failure appears. <br>


## Reference(s): <br>
- [Hunter homepage](https://hunter.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Hunter skill](https://clawhub.ai/oomol/oo-hunter) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action results are returned by the connector as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
