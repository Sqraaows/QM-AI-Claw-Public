## Description: <br>
Operates Nasdaq Data Link through an OOMOL-connected account for searching and reading finance datasets. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and analysts use this skill to inspect Nasdaq Data Link action schemas and run OOMOL connector commands for analyst ratings, dividend history, end-of-day quotes, datatable metadata, datatable exports, and normalized table-row lookups. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The get_real_time_quote action name can be mistaken for live market data. <br>
Mitigation: Treat it as end-of-day QuoteMedia data and avoid using it for live trading, alerts, or time-critical market decisions. <br>
Risk: The skill requires an OOMOL-connected Nasdaq Data Link account and sensitive credentials. <br>
Mitigation: Use the documented OOMOL account connection flow and keep raw Nasdaq Data Link credentials out of local prompts, files, and command payloads. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing or running each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-nasdaq) <br>
- [Nasdaq Data Link homepage](https://data.nasdaq.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing request payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
