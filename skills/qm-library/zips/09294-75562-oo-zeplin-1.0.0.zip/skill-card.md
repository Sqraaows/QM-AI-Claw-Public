## Description: <br>
Helps an agent read Zeplin user, project, screen-version, color-token, and text-style data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Design, product, and engineering teams use this skill to let an agent inspect Zeplin projects and design-token data without handling raw Zeplin credentials directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Zeplin project, user, screen-version, color, or text-style data returned by the connector may be exposed in the agent conversation or logs. <br>
Mitigation: Install only when the agent is allowed to read Zeplin data from the user's OOMOL-connected account, and avoid requesting sensitive projects unless needed. <br>
Risk: The skill depends on the local oo CLI and an active OOMOL OAuth connection to Zeplin. <br>
Mitigation: Review the oo CLI setup and connection status before use, and reconnect only when commands fail with authentication, scope, or credential-expiration errors. <br>


## Reference(s): <br>
- [ClawHub Zeplin skill page](https://clawhub.ai/oomol/oo-zeplin) <br>
- [Zeplin homepage](https://zeplin.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON command output from connector actions.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only Zeplin connector actions return data and execution metadata through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
