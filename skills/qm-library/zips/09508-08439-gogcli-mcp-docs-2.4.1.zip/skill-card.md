## Description: <br>
Provides an MCP-backed Google Docs workflow for reading, writing, editing, exporting, managing tabs, and working with comments through gogcli. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to connect an authenticated Google account to Google Docs workflows for document edits, exports, find-replace operations, tab inspection, and comment management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can let an agent read, modify, delete, trash, export, and comment on documents in the selected Google account. <br>
Mitigation: Install it only for an account whose Docs the agent is allowed to access, and require explicit confirmation for delete, trash, sed-like replacement, bulk edit, export, and comment deletion actions. <br>
Risk: Bulk replacements and markdown table appends can produce unintended document changes. <br>
Mitigation: Read or export the document before bulk edits, scope replacements narrowly, and split markdown table appends around the documented gogcli markdown conversion limitations. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp-docs) <br>
- [gogcli project](https://github.com/openclaw/gogcli) <br>
- [gogcli markdown table limitation: three or more tables](https://github.com/openclaw/gogcli/issues/607) <br>
- [gogcli markdown table limitation: inline formatting in cells](https://github.com/openclaw/gogcli/issues/608) <br>
- [gogcli markdown table limitation: empty header tables](https://github.com/openclaw/gogcli/issues/609) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON configuration examples and inline tool names] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May guide MCP-backed Google Docs reads, edits, exports, trash/delete actions, and comment operations when the required gogcli server is installed and authenticated.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
