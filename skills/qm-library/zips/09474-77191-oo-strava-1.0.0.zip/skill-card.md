## Description: <br>
Use Strava through an OOMOL-connected account to read, create, upload, and update athlete, activity, route, segment, club, gear, zone, stream, comment, lap, and statistics data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Strava through the OOMOL connector with the oo CLI, including reading fitness and route data and performing supported Strava write actions after review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read fitness, route, and profile-related Strava data through an OOMOL-connected account. <br>
Mitigation: Install and use it only when the user is comfortable connecting Strava through OOMOL and sharing those data categories with the agent. <br>
Risk: Write actions can create activities, upload files, edit activities, update athlete weight, or star and unstar segments. <br>
Mitigation: Review the exact action payload and intended effect with the user before approving any write action. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Strava skill](https://clawhub.ai/oomol/oo-strava) <br>
- [Strava homepage](https://www.strava.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Strava connection page](https://console.oomol.com/app-connections?provider=strava) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action payloads should be checked against the live connector schema before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
