## Description: <br>
Discovers Snowflake Cortex, Snowpark, notebooks, Streamlit, MCP, and AI observability assets from the operator's environment, emits canonical agent-bom inventory JSON, and scans it without giving agent-bom long-lived Snowflake credentials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
Apache-2.0 <br>


## Use Case: <br>
Developers and engineers use this skill to discover Snowflake AI and workload assets with operator-approved read-only credentials, write schema-valid agent-bom inventory JSON, and optionally scan that inventory for findings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Snowflake credentials or tokens could be exposed or over-scoped during discovery. <br>
Mitigation: Use a least-privilege read-only role, prefer SSO/OAuth/key-pair authentication, and do not paste passwords, private keys, passphrases, or OAuth tokens into chat. <br>
Risk: Generated inventory may contain sensitive Snowflake asset or permission metadata. <br>
Mitigation: Write inventory only to an operator-selected local path and review the generated JSON before sharing or pushing it anywhere. <br>
Risk: Discovery against the wrong Snowflake account, warehouse, database, or role could collect unintended information. <br>
Mitigation: Use only operator-approved Snowflake accounts, warehouses, databases, and read-only roles before running discovery. <br>


## Reference(s): <br>
- [agent-bom GitHub repository](https://github.com/msaad00/agent-bom) <br>
- [agent-bom PyPI package](https://pypi.org/project/agent-bom/) <br>
- [ClawHub skill page](https://clawhub.ai/msaad00/agent-bom-discover-snowflake) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, json, guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON file outputs] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces canonical Snowflake inventory JSON and optional agent-bom findings JSON; credential-like values are redacted before persistence or export.] <br>

## Skill Version(s): <br>
0.88.5 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
