## Description: <br>
Formbricks (formbricks.com). Use this skill for Formbricks requests that read, create, update, or delete data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Formbricks contacts and contact attribute keys from an agent workflow through the oo CLI. It supports workspace context lookup plus create, list, get, update, and delete actions with schema-first payload construction. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update Formbricks records through an OOMOL-connected account. <br>
Mitigation: Review the live schema, exact JSON payload, and intended effect before approving write actions. <br>
Risk: The skill can delete Formbricks contact attribute keys. <br>
Mitigation: Confirm the exact target identifier and obtain explicit user approval before running delete actions. <br>
Risk: The skill requires sensitive account connectivity through the oo CLI. <br>
Mitigation: Install and use it only when the OOMOL publisher and connected Formbricks account are trusted. <br>


## Reference(s): <br>
- [Formbricks homepage](https://formbricks.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Formbricks skill page](https://clawhub.ai/oomol/oo-formbricks) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads; connector responses are JSON with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
