## Description: <br>
Currents API (currentsapi.services) helps agents search and read news data through the OOMOL connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to retrieve latest Currents news, search articles by keyword or taxonomy, and list supported categories, languages, and regions through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL account for Currents API access and may rely on sensitive service credentials managed outside the agent. <br>
Mitigation: Install only for trusted OOMOL/Currents API workflows, keep credentials in the managed connector, and inspect the live connector schema before sending payloads. <br>
Risk: Authentication, connection, and billing setup commands can affect the user's account or service availability if run unnecessarily. <br>
Mitigation: Run setup only after an auth, connection, or billing error, and use explicit user targets for account-related steps. <br>
Risk: Server security evidence marks the release suspicious despite no listed risk findings. <br>
Mitigation: Review the publisher, ClawHub page, and commands before deployment, and use constrained execution where available. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-currents-api) <br>
- [Currents API homepage](https://currentsapi.services) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON API responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution; responses include data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
