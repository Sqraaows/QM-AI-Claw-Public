## Description: <br>
Breeze helps an agent search and read Breeze church management data through an OOMOL-connected Breeze account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Teams that manage church member data in Breeze can use this skill to let an agent retrieve people, profile fields, tag folders, and tags after the user has connected Breeze through OOMOL. The skill is read-focused and delegates credential handling to the OOMOL connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Review before execution as proposals could introduce incorrect or misleading guidance into skills. <br>
Mitigation: Review and scan skill before deployment. <br>

## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-breeze) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Breeze homepage](https://www.breezechms.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces read-oriented Breeze connector guidance and command payloads; command results may include Breeze people, profile-field, tag-folder, and tag data returned as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: server-resolved release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
