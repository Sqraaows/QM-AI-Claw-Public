## Description: <br>
TinyPNG helps agents compress images and transform TinyPNG output images through an OOMOL-connected TinyPNG account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, creators, and automation agents use this skill to compress image resources from public URLs or base64 image bytes and return transformed image outputs through TinyPNG. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill sends image URLs or image bytes through the OOMOL TinyPNG connector. <br>
Mitigation: Use it only for images that are appropriate to process through OOMOL and TinyPNG, and avoid submitting sensitive image data unless that handling is approved. <br>
Risk: The skill requires a connected TinyPNG account or API key through OOMOL. <br>
Mitigation: Connect only the intended TinyPNG credential, keep credentials managed through OOMOL, and reauthorize only when an auth or connection error requires it. <br>
Risk: Optional first-time setup can run external CLI installer commands. <br>
Mitigation: Verify the OOMOL installer URL before running installation commands and do not repeat setup steps unless the command failure matches the documented reason. <br>


## Reference(s): <br>
- [TinyPNG homepage](https://tinypng.com) <br>
- [ClawHub TinyPNG skill page](https://clawhub.ai/oomol/oo-tinypng) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Guidance includes schema inspection before action execution; action results can include TinyPNG data and transit URLs.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
