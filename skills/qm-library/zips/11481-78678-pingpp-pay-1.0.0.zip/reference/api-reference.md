# API 参考

完整字段说明见官方文档：https://www.pingxx.com/api/

---

## Charge（付款单）

### 创建 Charge

```java
Map<String, Object> params = new HashMap<>();
params.put("amount", 100);           // 金额，单位：分
params.put("currency", "cny");
params.put("subject", "商品名称");
params.put("body", "商品描述");
params.put("order_no", orderNo);     // 商户订单号，8-20 位字母数字
params.put("channel", "wx_pub");     // 支付渠道，见渠道列表
params.put("client_ip", "127.0.0.1");
Map<String, String> app = new HashMap<>();
app.put("id", appId);
params.put("app", app);
params.put("extra", extraMap);       // 渠道专属参数，见下方渠道表

try {
    Charge charge = Charge.create(params);
    // charge.toString() 返回 JSON，直接透传给客户端
} catch (PingppException e) {
    e.printStackTrace();
}
```

### 查询 / 列表 / 撤销

```java
Charge charge = Charge.retrieve(chargeId);
ChargeCollection list = Charge.list(params);  // params 须含 app[id]
Charge reversed = Charge.reverse(chargeId);   // 仅线下渠道
```

### 渠道与 extra 参数

| 渠道                 | 说明         | 必填 extra                                  |
|--------------------|------------|-------------------------------------------|
| `alipay`           | 支付宝 PC/APP | —                                         |
| `alipay_wap`       | 支付宝 H5     | `success_url`, `cancel_url`               |
| `alipay_pc_direct` | 支付宝 PC 直连  | `success_url`                             |
| `alipay_scan`      | 支付宝扫码      | `scan_code`, `terminal_id`                |
| `wx`               | 微信 App     | —                                         |
| `wx_pub`           | 微信公众号      | `open_id`                                 |
| `wx_pub_qr`        | 微信公众号二维码   | `product_id`                              |
| `wx_pub_scan`      | 微信扫码       | `scan_code`                               |
| `wx_lite`          | 微信小程序      | `open_id`                                 |
| `wx_wap`           | 微信 H5      | `result_url`                              |
| `upacp`            | 银联 App     | —                                         |
| `upacp_wap`        | 银联 H5      | `result_url`                              |
| `upacp_pc`         | 银联 PC      | `result_url`                              |
| `qpay`             | QQ 钱包      | `device`（ios/android）                     |
| `isv_scan`         | ISV 扫码     | `terminal_id`, `scan_code`, `pay_channel` |
| `cb_alipay`        | 跨境支付宝      | —                                         |
| `cb_wx_pub`        | 跨境微信公众号    | `open_id`, `goods_list`                   |

---

## Refund（退款）

```java
// 创建退款
Map<String, Object> params = new HashMap<>();
params.put("description", "退款原因");
params.put("amount", 100);  // 可选，默认全额退款
Refund refund = Refund.create(chargeId, params);

// 查询退款
Refund refund = Refund.retrieve(chargeId, refundId);
ChargeRefundCollection list = Refund.list(chargeId, params);
```

---

## Transfer（企业付款）

```java
Map<String, Object> params = new HashMap<>();
params.put("channel", "wx_pub");   // alipay / wx_pub / unionpay / jdpay / allinpay
params.put("order_no", orderNo);
params.put("amount", 200);
params.put("type", "b2c");         // b2c 或 b2b
params.put("currency", "cny");
params.put("recipient", openId);   // wx_pub 时为 open_id，alipay 时为账号
params.put("description", "转账备注");
params.put("extra", extraMap);
Map<String, String> app = new HashMap<>();
app.put("id", appId);
params.put("app", app);

Transfer transfer = Transfer.create(params);
Transfer transfer = Transfer.retrieve(id, params);
TransferCollection list = Transfer.list(params);
```

---

## BatchTransfer（批量付款）

```java
Map<String, Object> params = new HashMap<>();
params.put("app", appId);
params.put("channel", "alipay");
params.put("batch_no", batchNo);
params.put("currency", "cny");
params.put("type", "b2c");
params.put("amount", 1000);
params.put("description", "批量转账");

List<Map<String, Object>> recipients = new ArrayList<>();
Map<String, Object> recipient = new HashMap<>();
recipient.put("account", "user@example.com");
recipient.put("name", "张三");
recipient.put("amount", 1000);
recipient.put("description", "单条备注");
recipients.add(recipient);
params.put("recipients", recipients);

BatchTransfer bt = BatchTransfer.create(params);
```

---

## RedEnvelope（红包）

```java
Map<String, Object> params = new HashMap<>();
params.put("app", appId);
params.put("channel", "wx_pub");
params.put("order_no", orderNo);
params.put("amount", 100);
params.put("currency", "cny");
params.put("subject", "红包");
params.put("body", "恭喜发财");
params.put("recipient", openId);
params.put("extra", extraMap);

RedEnvelope re = RedEnvelope.create(params);
```

---

## Order（订单，账户系统）

```java
// 需设置 Pingpp.appId
Map<String, Object> params = new HashMap<>();
params.put("uid", userId);
params.put("amount", 100);
params.put("currency", "cny");
params.put("subject", "商品");
params.put("body", "描述");
params.put("client_ip", ip);
params.put("order_no", orderNo);
// 支付渠道参数
Map<String, Object> charge = new HashMap<>();
charge.put("channel", "wx_pub");
charge.put("extra", extraMap);
params.put("charge", charge);

Order order = Order.create(params);
Order order = Order.retrieve(id, params);
```

---

## Event（异步通知对象）

```java
// 解析 Webhooks 推送体
Event event = Webhooks.eventParse(rawPostBody);
String eventType = event.getType();   // 如 "charge.succeeded"
PingppObject obj = event.getData().getObject();
if (obj instanceof Charge) {
    Charge charge = (Charge) obj;
    // 处理业务逻辑
}
```

---

## 异常处理

| 异常类                       | 含义                |
|---------------------------|-------------------|
| `PingppException`         | 所有 Ping++ 异常的基类   |
| `APIConnectionException`  | 网络连接失败            |
| `APIException`            | Ping++ 服务端错误（5xx） |
| `AuthenticationException` | API Key 无效或权限不足   |
| `InvalidRequestException` | 请求参数错误（4xx）       |
| `ChannelException`        | 渠道返回错误            |
| `RateLimitException`      | 请求频率超限            |

```java
try {
    Charge charge = Charge.create(params);
} catch (InvalidRequestException e) {
    // 参数错误，e.getMessage() 含具体字段说明
} catch (AuthenticationException e) {
    // API Key 错误
} catch (APIConnectionException e) {
    // 网络问题，可重试
} catch (PingppException e) {
    // 其他异常
}
```
