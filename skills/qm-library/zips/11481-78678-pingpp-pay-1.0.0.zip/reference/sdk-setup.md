# SDK 安装与初始化

## 安装

### Maven

```xml
<dependency>
    <groupId>com.pingxx</groupId>
    <artifactId>pingpp-java</artifactId>
    <version>2.5.6</version>
</dependency>
```

### Gradle

```groovy
implementation 'com.pingxx:pingpp-java:2.5.6'
```

### 手动安装

从 [mvnrepository](https://mvnrepository.com/artifact/com.pingxx/pingpp-java) 下载 JAR，需同时引入依赖：

- `com.google.code.gson:gson`
- `commons-codec:commons-codec`

---

## 初始化

### 全局配置（推荐在 Spring Boot 的 `@Configuration` 中完成）

```java
import com.pingplusplus.Pingpp;

@Configuration
public class PingppConfig {

    @Value("${pingpp.api-key}")
    private String apiKey;

    @Value("${pingpp.app-id}")
    private String appId;

    @Value("${pingpp.private-key}")
    private String privateKey;

    @Value("${pingpp.verify-public-key-path}")
    private String verifyPublicKeyPath;

    @PostConstruct
    public void init() throws IOException {
        Pingpp.apiKey = apiKey;
        Pingpp.appId = appId;
        Pingpp.privateKey = privateKey;
        Pingpp.setVerifyPublicKeyPath(verifyPublicKeyPath);
    }
}
```

### application.yml 配置示例

```yaml
pingpp:
  api-key: sk_test_xxxxxxxxxxxx         # 管理平台 Secret Key
  app-id: app_xxxxxxxxxxxx              # 应用 ID
  private-key: |                        # PKCS8 格式私钥内容（或 private-key-path 指向文件）
    MIIEvQIBADANBgkqhkiG9w0BAQEF...
  verify-public-key-path: classpath:pingpp_public_key.pem
```

### 生成密钥对

```bash
# 生成 PKCS1 私钥
openssl genrsa -out pkcs1.pem 2048
# 转换为 PKCS8（推荐）
openssl pkcs8 -topk8 -inform PEM -in pkcs1.pem -outform PEM -nocrypt -out pkcs8.pem
# 提取公钥
openssl rsa -in pkcs1.pem -pubout -out public_key.pem
```

将公钥内容填入 [Dashboard](https://dashboard.pingxx.com) →【公司设置】→【开发设置】→【商户公钥】。

Ping++ 的验签公钥（`pingpp_public_key.pem`）从 Dashboard →【开发设置】→【Ping++ 公钥】下载，放到 `src/main/resources/`。

---

## 关键配置项

| 配置项               | 说明                    | 获取方式                          |
|-------------------|-----------------------|-------------------------------|
| `apiKey`          | Secret Key，以 `sk_` 开头 | Dashboard →【开发设置】→ Secret Key |
| `appId`           | 应用 ID，以 `app_` 开头     | Dashboard → 应用首页              |
| `privateKey`      | PKCS8 私钥，用于请求签名       | 自行生成并将公钥上传                    |
| `verifyPublicKey` | Ping++ 公钥，用于响应验签      | Dashboard 下载                  |

TestKey（`sk_test_`）不产生真实交易，上线前切换为 LiveKey（`sk_live_`）。

---

## 按请求设置（多 App 场景）

```java
import com.pingplusplus.net.RequestOptions;

RequestOptions options = RequestOptions.builder()
    .setApiKey("sk_test_xxxx")
    .setAppId("app_yyyy")
    .setPrivateKey("...")
    .build();

Charge charge = Charge.create(params, options);
```
