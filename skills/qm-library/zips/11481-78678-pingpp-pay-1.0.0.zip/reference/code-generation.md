# 代码生成指南

在现有 Java Spring Boot 项目中生成 Ping++ 集成模块。

---

## 模块结构

在项目现有包结构下生成以下代码，遵循已有包命名规范：

```text
com.yourcompany.yourproject
└── payment/pingpp/
    ├── config/
    │   └── PingppConfig.java          # SDK 初始化配置
    ├── service/
    │   ├── ChargeService.java         # 付款单服务
    │   ├── RefundService.java         # 退款服务
    │   └── TransferService.java       # 企业付款服务（按需）
    ├── webhook/
    │   └── PingppWebhookController.java  # Webhook 处理器
    └── exception/
        └── PingppPaymentException.java   # 业务异常包装
```

---

## 生成规则

### 1. 分析项目结构

扫描工作目录，确认：

- 构建工具（Maven/Gradle）→ 选择正确依赖格式
- 根包路径 → 确定生成代码的包前缀
- 现有配置格式（yml/properties）→ 生成对应配置示例
- 是否已有支付模块 → 避免覆盖现有代码

### 2. PingppConfig.java

参考 [sdk-setup.md](sdk-setup.md) 生成 Spring Boot 配置类。

### 3. ChargeService.java 模板

```java
package com.example.payment.pingpp.service;  // 根据项目实际包结构调整

import com.example.payment.pingpp.exception.PingppPaymentException;
import com.pingplusplus.exception.InvalidRequestException;
import com.pingplusplus.exception.PingppException;
import com.pingplusplus.model.Charge;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ChargeService {

    @Value("${pingpp.app-id}")
    private String appId;

    /**
     * 创建付款单
     * @param orderNo 商户订单号（8-20 位字母数字）
     * @param amount  金额（单位：分）
     * @param channel 支付渠道
     * @param subject 商品名称
     * @param body    商品描述
     * @param clientIp 客户端 IP
     * @param extra   渠道专属参数（如 wx_pub 需要 open_id）
     * @return Charge JSON 字符串，直接返回给客户端
     */
    public String createCharge(String orderNo, int amount, String channel,
            String subject, String body, String clientIp,
            Map<String, Object> extra) {
        Map<String, Object> params = new HashMap<>();
        params.put("order_no", orderNo);
        params.put("amount", amount);
        params.put("channel", channel);
        params.put("subject", subject);
        params.put("body", body);
        params.put("client_ip", clientIp);
        params.put("currency", "cny");
        if (extra != null && !extra.isEmpty()) {
            params.put("extra", extra);
        }
        Map<String, String> app = new HashMap<>();
        app.put("id", appId);
        params.put("app", app);

        try {
            Charge charge = Charge.create(params);
            return charge.toString();
        } catch (InvalidRequestException e) {
            throw new PingppPaymentException("创建付款单参数错误: " + e.getMessage(), e);
        } catch (PingppException e) {
            throw new PingppPaymentException("创建付款单失败: " + e.getMessage(), e);
        }
    }

    public Charge retrieve(String chargeId) {
        try {
            return Charge.retrieve(chargeId);
        } catch (PingppException e) {
            throw new PingppPaymentException("查询付款单失败: " + e.getMessage(), e);
        }
    }
}
```

### 4. 渠道 extra 参数生成

根据用户需要接入的渠道，在 Service 或 DTO 中生成 extra 构建方法。

常见渠道 extra（详见 [api-reference.md](api-reference.md)）：

- `wx_pub`：`open_id`（必填）
- `alipay_wap`：`success_url`（必填），`cancel_url`（必填）
- `alipay_pc_direct`：`success_url`（必填）
- `wx_wap`：`result_url`（可选）
- `wx_lite`：`open_id`（必填）

### 5. 异常类模板

```java
package com.example.payment.pingpp.exception;  // 根据项目实际包结构调整

public class PingppPaymentException extends RuntimeException {
    public PingppPaymentException(String message, Throwable cause) {
        super(message, cause);
    }
}
```

---

## 代码生成后检查清单

- [ ] `PingppConfig` 中 `@PostConstruct` 已正确调用初始化
- [ ] `application.yml` 中已添加 `pingpp.*` 配置项（含注释说明）
- [ ] Webhook Controller 已从 Header 读取签名并完成验签
- [ ] 所有 `PingppException` 均被捕获（不能让其传播到 HTTP 层）
- [ ] 业务处理做了幂等控制
- [ ] 已添加 Maven/Gradle 依赖

---

## 单元测试模板

```java
package com.example.payment.pingpp.service;  // 根据项目实际包结构调整

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class ChargeServiceTest {

    @Autowired
    private ChargeService chargeService;

    @Test
    void testCreateCharge_WxPub() {
        Map<String, Object> extra = new HashMap<>();
        extra.put("open_id", "test_open_id");

        // 使用 TestKey 不产生真实交易
        String chargeJson = chargeService.createCharge(
            "TEST" + System.currentTimeMillis(), 100,
            "wx_pub", "测试商品", "测试描述",
            "127.0.0.1", extra);

        assertNotNull(chargeJson);
        assertTrue(chargeJson.contains("\"object\":\"charge\""));
    }
}
```
