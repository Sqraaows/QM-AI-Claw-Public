# Webhooks 异步通知

Ping++ 在支付、退款、转账等状态变更时，会向商户配置的 URL 发送 POST 请求。

文档：https://www.pingxx.com/docs/webhooks/webhooks

---

## 验签

从 HTTP Header 获取签名（`X-Pingplusplus-Signature`，不区分大小写），从 Body 获取原始 JSON。

```java
import com.pingplusplus.util.PingppSignature;
import com.pingplusplus.net.APIResource;

boolean valid = PingppSignature.verify(
    signature,          // HTTP Header: X-Pingplusplus-Signature
    rawPostBody,        // HTTP Body 原始字节（勿经过 JSON 重序列化）
    Pingpp.verifyPublicKey,
    APIResource.CHARSET.name()   // "UTF-8"
);
if (!valid) {
    // 返回 400，拒绝处理
}
```

**注意**：`verifyPublicKey` 为 Ping++ 平台公钥（非商户自己的公钥），从 Dashboard 下载。

---

## Spring Boot Webhook Controller 示例

```java
@RestController
@RequestMapping("/webhooks")
public class PingppWebhookController {

    @PostMapping("/pingpp")
    public ResponseEntity<String> handle(
            HttpServletRequest request,
            @RequestBody String rawBody) throws Exception {

        // 1. 获取签名
        String signature = request.getHeader("X-Pingplusplus-Signature");

        // 2. 验签
        boolean valid = PingppSignature.verify(
            signature, rawBody, Pingpp.verifyPublicKey, "UTF-8");
        if (!valid) {
            return ResponseEntity.badRequest().body("invalid signature");
        }

        // 3. 解析事件
        Event event = Webhooks.eventParse(rawBody);
        String type = event.getType();
        PingppObject obj = event.getData().getObject();

        switch (type) {
            case "charge.succeeded":
                handleChargeSucceeded((Charge) obj);
                break;
            case "refund.succeeded":
                handleRefundSucceeded((Refund) obj);
                break;
            case "transfer.succeeded":
                handleTransferSucceeded((Transfer) obj);
                break;
            // 更多事件类型见下方列表
        }

        // 4. 返回 200 告知 Ping++ 已接收
        return ResponseEntity.ok("success");
    }
}
```

---

## 事件类型列表

| 事件类型                     | 说明       | 对应对象            |
|--------------------------|----------|-----------------|
| `charge.succeeded`       | 付款成功     | `Charge`        |
| `charge.failed`          | 付款失败     | `Charge`        |
| `refund.succeeded`       | 退款成功     | `Refund`        |
| `refund.failed`          | 退款失败     | `Refund`        |
| `transfer.succeeded`     | 企业付款成功   | `Transfer`      |
| `transfer.failed`        | 企业付款失败   | `Transfer`      |
| `batch_transfer.updated` | 批量付款状态更新 | `BatchTransfer` |
| `red_envelope.sent`      | 红包发送成功   | `RedEnvelope`   |
| `order.paid`             | 订单支付成功   | `Order`         |
| `order.refunded`         | 订单退款成功   | `Order`         |

---

## 幂等处理

Ping++ 在超时或未收到 200 响应时会重发通知，须做幂等处理：

```java
private void handleChargeSucceeded(Charge charge) {
    String chargeId = charge.getId();
    // 根据 charge.id 查询本地订单，避免重复处理
    Order localOrder = orderRepo.findByChargeId(chargeId);
    if (localOrder == null || localOrder.isPaid()) {
        return;  // 已处理，直接忽略
    }
    // 更新订单状态
    localOrder.markPaid(charge.getTimePaid());
    orderRepo.save(localOrder);
}
```

---

## 主动查询兜底

Webhooks 可能因网络问题延迟或丢失，关键业务需结合主动查询：

```java
// 定时任务：查询待确认支付状态
Charge charge = Charge.retrieve(chargeId);
if (Boolean.TRUE.equals(charge.getPaid())) {
    // 同步订单状态
}
```
