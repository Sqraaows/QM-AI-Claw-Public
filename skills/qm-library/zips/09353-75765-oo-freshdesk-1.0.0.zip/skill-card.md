## Description: <br>
Freshdesk connector skill for reading Freshdesk account details, tickets, and ticket conversation history through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Support operators, developers, and agents use this skill to inspect Freshdesk account information, list tickets, fetch a ticket by identifier, and read ticket conversation history. It is intended for read-only Freshdesk workflows through an existing OOMOL connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Freshdesk account through OOMOL and can read account, ticket, and conversation data. <br>
Mitigation: Install and use it only for users authorized to access the connected Freshdesk tenant, and treat retrieved support data as sensitive. <br>
Risk: Future Freshdesk actions that create, update, post, send, delete, or remove data could change Freshdesk state. <br>
Mitigation: Require explicit user confirmation before running any future write or destructive Freshdesk action; the current release evidence describes the available actions as read-only. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Freshdesk Skill](https://clawhub.ai/oomol/oo-freshdesk) <br>
- [Freshdesk Homepage](https://www.freshworks.com/freshdesk/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill directs agents to fetch live connector schemas before constructing JSON payloads and returns Freshdesk connector responses as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
