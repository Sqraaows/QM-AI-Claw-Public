## Description: <br>
DeepSeek (platform.deepseek.com). Use this skill for DeepSeek tasks through an OOMOL-connected account instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to list DeepSeek models, check account balance, and create DeepSeek chat or message completions through OOMOL connector workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connected DeepSeek credentials through OOMOL. <br>
Mitigation: Connect only the intended DeepSeek account and review the OOMOL CLI installation step before use. <br>
Risk: Chat and message creation sends user-provided content to DeepSeek and can consume account credit. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create actions. <br>
Risk: Connector schemas and upstream defaults can change over time. <br>
Mitigation: Fetch the live action schema before constructing each request payload. <br>


## Reference(s): <br>
- [DeepSeek homepage](https://platform.deepseek.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-deepseek) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return JSON responses from OOMOL connector runs, including action data and an execution id.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
