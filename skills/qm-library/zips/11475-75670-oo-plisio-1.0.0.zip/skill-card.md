## Description: <br>
Plisio lets an agent read balances and operations, list invoices, and create hosted Plisio invoices through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Plisio payment workflows from an agent session, including checking balances, reviewing operations, listing invoices, and creating hosted invoices after confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Plisio balances and operation or invoice data through a connected account. <br>
Mitigation: Install only when Plisio account access is intended, and review connection status and requested action before execution. <br>
Risk: The create_invoice action changes payment workflow state by creating a hosted Plisio invoice. <br>
Mitigation: Inspect the live action schema and confirm the exact invoice payload and intended effect with the user before running it. <br>
Risk: First-time setup may require installing or authenticating the oo CLI. <br>
Mitigation: Run setup only after an auth or connection failure, and verify OOMOL's install source before using the installer. <br>


## Reference(s): <br>
- [ClawHub Plisio Skill](https://clawhub.ai/oomol/oo-plisio) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Plisio Homepage](https://plisio.net) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before actions; invoice creation changes Plisio state and requires user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
