---
name: oo-plisio
description: "Plisio (plisio.net). Use this skill for ANY Plisio request — reading, creating, and updating data. Whenever a task involves Plisio, use this skill instead of calling the API directly."
allowed-tools: [Bash(oo *)]
metadata:
  title: "Plisio"
  author: "OOMOL"
  version: "1.0.0"
  service: "plisio"
  categories: "Finance"
  homepage: "https://plisio.net"
  icon: "https://static.oomol.com/logo/third-party/plisio.png"
---

# Plisio

Operate **Plisio** through your OOMOL-connected account. This skill calls the `plisio` connector with the [oo CLI](https://github.com/oomol-lab/oo-cli); OOMOL injects credentials server-side, so you never handle raw tokens.

Category: Finance. Exposes 4 action(s).

## Running an action

Assume the user has already installed the oo CLI, signed in, and connected Plisio. **Do not run `oo auth login` or open the connection URL proactively — just run the action.** Fall back to [First-time setup](#first-time-setup) only when a command actually fails with an auth or connection error.

**1. Inspect the contract** to get the authoritative input/output schema before building a payload:

```bash
oo connector schema "plisio" --action "<action_name>"
```

**2. Run the action** with a JSON payload that matches the input schema:

```bash
oo connector run "plisio" --action "<action_name>" --data '<json>' --json
```

- `--data` takes a JSON object string or `@path/to/file.json`; omit it to send `{}`.
- The response is `{ "data": ..., "meta": { "executionId": "..." } }`; the execution id lives under `meta.executionId`.

Each action below links to a reference file with its purpose and exact commands. Read the linked file, then fetch the live schema with `oo connector schema` before constructing `--data`.

## Available actions

- [`create_invoice`](actions/create_invoice.md) — Create a hosted Plisio invoice for one merchant order using either a crypto amount or a fiat amount that Plisio converts.
- [`get_balance`](actions/get_balance.md) — Fetch the current Plisio balance for one supported cryptocurrency identifier.
- [`get_operation`](actions/get_operation.md) — Fetch one Plisio operation or invoice by its official operation identifier.
- [`list_operations`](actions/list_operations.md) — List Plisio operations and invoices with official pagination, type, status, currency, and search filters.

## Safety

- Read actions (get / list / search) are safe to run directly.
- **Create, update, send, or post actions change Plisio state — confirm the exact payload and effect with the user before running.**
- **Delete or remove actions are destructive — always confirm the target and get explicit approval first.**

## First-time setup

These are **one-time** steps — do not repeat them on every call. Run a step only when a command fails for the matching reason.

- **`oo: command not found`** — install the oo CLI (other platforms: <https://cli.oomol.com/install-guide.md>):

  ```bash
  curl -fsSL https://cli.oomol.com/install.sh | bash    # macOS / Linux
  ```

  ```powershell
  irm https://cli.oomol.com/install.ps1 | iex           # Windows PowerShell
  ```

- **Not signed in / authentication error** — sign in to your OOMOL account once:

  ```bash
  oo auth login
  ```

- **`scope_missing` / `credential_expired` / `app_not_ready` / `app_not_found`** — Plisio is not connected, or the connection expired or lacks a scope. Connect once (auth type: API key) at:

  ```text
  https://console.oomol.com/app-connections?provider=plisio
  ```

- **HTTP 402 / `OOMOL_INSUFFICIENT_CREDIT`** — billing stop. Recharge at `https://console.oomol.com/billing/token-recharge` before retrying.

## Resources

- Plisio homepage: https://plisio.net
