## Description: <br>
Operates Mem0 through an OOMOL-connected account using the oo CLI to read, search, create, update, and delete memories and inspect related users and events. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Mem0 through an OOMOL-connected account, including memory lookup, semantic search, creation, updates, deletion, event inspection, and user listing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and search Mem0 data that may contain sensitive personal or business information. <br>
Mitigation: Install only when the user intends to connect Mem0 through OOMOL, and review returned data handling with the user. <br>
Risk: Create and update actions change Mem0 state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: Delete actions are destructive. <br>
Mitigation: Confirm the target memory ID and get explicit user approval before deletion. <br>


## Reference(s): <br>
- [Mem0 homepage](https://mem0.ai) <br>
- [ClawHub Mem0 skill page](https://clawhub.ai/oomol/oo-mem0) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo CLI connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
