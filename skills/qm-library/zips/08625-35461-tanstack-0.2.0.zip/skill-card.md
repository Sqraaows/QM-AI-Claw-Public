## Description: <br>
Build type-safe React apps with TanStack Query, Router, and Start guidance for data fetching, caching, mutations, file-based routing, search params, loaders, SSR, server functions, and middleware. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[tenequm](https://clawhub.ai/user/tenequm) <br>

### License/Terms of Use: <br>
Apache 2.0 <br>


## Use Case: <br>
Developers and engineers use this skill to get implementation guidance, code examples, and configuration patterns for TanStack Query, TanStack Router, and TanStack Start in React applications. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The security scan verdict is suspicious because review-helper behavior in the bundle may run nested reviewer commands with broad authority. <br>
Mitigation: Install only in a trusted maintainer environment and review moderation or publishing commands before running them with authenticated GitHub or ClawHub credentials. <br>
Risk: The skill provides code and configuration guidance that may be outdated or mismatched with a target project's TanStack versions. <br>
Mitigation: Verify generated guidance against the project's installed package versions and the linked TanStack documentation before applying changes. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/tenequm/tanstack) <br>
- [TanStack Query documentation](https://tanstack.com/query/latest/docs/framework/react/overview) <br>
- [TanStack Router documentation](https://tanstack.com/router/latest/docs/framework/react/overview) <br>
- [TanStack Start documentation](https://tanstack.com/start/latest/docs/framework/react/overview) <br>
- [TanStack Query GitHub repository](https://github.com/TanStack/query) <br>
- [TanStack Router GitHub repository](https://github.com/TanStack/router) <br>
- [Query guide](artifact/references/query-guide.md) <br>
- [Router guide](artifact/references/router-guide.md) <br>
- [Start guide](artifact/references/start-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with TypeScript, TSX, and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs are advisory and should be checked against the target application's TanStack package versions and security requirements.] <br>

## Skill Version(s): <br>
0.2.0 (source: SKILL.md frontmatter and CHANGELOG.md, released 2026-06-04) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
