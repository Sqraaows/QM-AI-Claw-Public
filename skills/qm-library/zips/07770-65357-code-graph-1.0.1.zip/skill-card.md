## Description: <br>
一键安装 GitNexus 并为当前项目构建代码知识图谱。当用户说「安装GitNexus」「设置GitNexus」「初始化GitNexus」「配置GitNexus」「用GitNexus建图」「GitNexus一键配置」时使用。 <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[babywhale](https://clawhub.ai/user/babywhale) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to install GitNexus, configure its MCP integration, and build a project-level code knowledge graph for code search, context lookup, impact analysis, and coordinated refactoring workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can install GitNexus or run it through npx, changing the user's local tooling environment. <br>
Mitigation: Review the proposed npm or npx command before execution and prefer npx when avoiding a global installation. <br>
Risk: The skill can update MCP/editor configuration and write project index files. <br>
Mitigation: Inspect configuration changes and generated .gitnexus files before committing or sharing the repository. <br>
Risk: The troubleshooting flow includes git add . for initializing repositories, which can stage unintended files. <br>
Mitigation: Check .gitignore and run git status before staging files; avoid git add . unless all files are safe to include. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/babywhale/code-graph) <br>
- [Node.js](https://nodejs.org/) <br>
- [nvm](https://github.com/nvm-sh/nvm) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, Markdown] <br>
**Output Format:** [Markdown with inline bash code blocks and stepwise instructions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces command guidance for GitNexus installation, MCP setup, indexing, and verification; it may also guide creation of local GitNexus index files.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
