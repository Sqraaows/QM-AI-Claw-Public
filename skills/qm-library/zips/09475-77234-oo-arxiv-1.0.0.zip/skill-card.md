## Description: <br>
arXiv (arxiv.org) helps agents search and read arXiv paper data through the OOMOL arxiv connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and researchers use this skill to search arXiv, retrieve one or more papers by identifier, list recent papers by category, and query title, author, abstract, or combined fields through the oo CLI connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Search terms and arXiv identifiers are processed through the OOMOL connector service. <br>
Mitigation: Use queries appropriate to share with that connector service and avoid entering sensitive unpublished research details when that is not intended. <br>
Risk: Optional setup steps can install the oo CLI or start an OOMOL login flow. <br>
Mitigation: Run setup only when the connector command fails for the matching reason and the user intentionally wants to configure that tool. <br>


## Reference(s): <br>
- [arXiv homepage](https://arxiv.org/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-arxiv) <br>
- [get_paper action](actions/get_paper.md) <br>
- [get_papers action](actions/get_papers.md) <br>
- [list_recent_papers action](actions/list_recent_papers.md) <br>
- [search_by_abstract action](actions/search_by_abstract.md) <br>
- [search_by_all_fields action](actions/search_by_all_fields.md) <br>
- [search_by_author action](actions/search_by_author.md) <br>
- [search_by_title action](actions/search_by_title.md) <br>
- [search_papers action](actions/search_papers.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schema inspection before execution; read-oriented get, list, and search actions return data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
