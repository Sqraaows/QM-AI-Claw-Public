# Cesium JS API 摘要

本文档提供 Cesium JS 核心 API 的快速参考。

## 包结构

Cesium JS 分为两个主要包：
- **Engine** (`Cesium.*`) - 引擎核心，包含所有底层能力
- **Widgets** (`Cesium.Viewer`, `Cesium.CesiumWidget`) - UI 组件

## 核心类速查表

### 坐标与数学

| 类 | 用途 |
|----|------|
| `Cesium.Cartesian2` | 2D 笛卡尔坐标 (x, y) - 屏幕坐标 |
| `Cesium.Cartesian3` | 3D 笛卡尔坐标 (x, y, z) - 世界坐标 |
| `Cesium.Cartesian4` | 4D 笛卡尔坐标 (x, y, z, w) |
| `Cesium.Cartographic` | 经纬度坐标 (longitude, latitude, height) |
| `Cesium.Matrix2/3/4` | 2x2/3x3/4x4 矩阵 |
| `Cesium.Quaternion` | 四元数（旋转） |
| `Cesium.BoundingSphere` | 包围球 |
| `Cesium.Rectangle` | 经纬度矩形范围 |
| `Cesium.Math` | 数学工具方法 |

### 场景与视图

| 类 | 用途 |
|----|------|
| `Cesium.Viewer` | 完整视图容器（含所有控件） |
| `Cesium.CesiumWidget` | 轻量视图容器（无默认控件） |
| `Cesium.Scene` | 场景对象 |
| `Cesium.Camera` | 相机控制 |
| `Cesium.Globe` | 地球对象 |

### 数据加载

| 类 | 用途 |
|----|------|
| `Cesium.IonImageryProvider` | Cesium Ion 影像 |
| `Cesium.ArcGisMapServerImageryProvider` | ArcGIS MapServer |
| `Cesium.WebMapServiceImageryProvider` | WMS 服务 |
| `Cesium.WebMapTileServiceImageryProvider` | WMTS 服务 |
| `Cesium.UrlTemplateImageryProvider` | XYZ/TMS 瓦片 |
| `Cesium.TileMapServiceImageryProvider` | TMS 服务 |
| `Cesium.SingleTileImageryProvider` | 单张图片 |
| `Cesium.TerrainProvider` | 地形提供者（基类） |
| `Cesium.CesiumTerrainProvider` | Cesium 地形 |
| `Cesium.Cesium3DTileset` | 3D Tiles 数据集 |

### 数据源

| 类 | 用途 |
|----|------|
| `Cesium.GeoJsonDataSource` | GeoJSON 数据 |
| `Cesium.KmlDataSource` | KML 数据 |
| `Cesium.CzmlDataSource` | CZML 数据（支持时序） |
| `Cesium.DataSourceCollection` | 数据源集合 |

### Entity 可视化

| 类 | 用途 |
|----|------|
| `Cesium.Entity` | 实体对象 |
| `Cesium.PointGraphics` | 点样式 |
| `Cesium.LabelGraphics` | 标签样式 |
| `Cesium.PolylineGraphics` | 折线样式 |
| `Cesium.PolygonGraphics` | 多边形样式 |
| `Cesium.ModelGraphics` | 3D 模型样式 |
| `Cesium.BillboardGraphics` | 广告牌（图标）样式 |

### Primitive 绘制

| 类 | 用途 |
|----|------|
| `Cesium.Primitive` | 基础图元 |
| `Cesium.GroundPrimitive` | 贴地图元 |
| `Cesium.PointPrimitive` | 点图元 |
| `Cesium.LabelCollection` | 标签集合 |
| `Cesium.BillboardCollection` | 广告牌集合 |

### 几何类型

| 类 | 用途 |
|----|------|
| `Cesium.BoxGeometry` | 盒子几何 |
| `Cesium.SphereGeometry` | 球体几何 |
| `Cesium.CircleGeometry` | 圆形几何 |
| `Cesium.PolygonGeometry` | 多边形几何 |
| `Cesium.PolylineGeometry` | 折线几何 |
| `Cesium.RectangleGeometry` | 矩形几何 |

### 后处理

| 类 | 用途 |
|----|------|
| `Cesium.PostProcessStage` | 后处理阶段 |
| `Cesium.PostProcessStageComposite` | 后处理组合 |
| `Cesium.PostProcessStageLibrary` | 后处理库（预置效果） |

### 粒子系统

| 类 | 用途 |
|----|------|
| `Cesium.ParticleSystem` | 粒子系统 |
| `Cesium.Particle` | 粒子 |
| `Cesium.BoxEmitter` | 盒子发射器 |
| `Cesium.CircleEmitter` | 圆形发射器 |
| `Cesium.ConeEmitter` | 圆锥发射器 |

### 时间动态

| 类 | 用途 |
|----|------|
| `Cesium.JulianDate` | 儒略日期 |
| `Cesium.Clock` | 时钟 |
| `Cesium.TimeInterval` | 时间间隔 |
| `Cesium.SampledPositionProperty` | 采样位置属性 |
| `Cesium.ConstantProperty` | 常量属性 |
| `Cesium.TimeIntervalCollectionProperty` | 时间间隔集合属性 |

### 工具与辅助

| 类 | 用途 |
|----|------|
| `Cesium.Event` | 事件系统 |
| `Cesium.Knockout` | MVVM 框架 |
| `Cesium.loadJson` | 加载 JSON |
| `Cesium.loadXml` | 加载 XML |
| `Cesium.loadImage` | 加载图片 |
| `Cesium.Resource` | 资源加载 |

## 常用命名空间

### `Cesium.defined(value)`
检查值是否已定义（非 null 和 undefined）

### `Cesium.defaultValue(a, b)`
如果 a 已定义则返回 a，否则返回 b

### `Cesium.Math`
- `toRadians(degrees)` - 角度转弧度
- `toDegrees(radians)` - 弧度转角度
- `clamp(value, min, max)` - 限制值在范围内
- `lerp(p, q, time)` - 线性插值

### `Cesium.Color`
预定义颜色常量：
- `Cesium.Color.RED` / `GREEN` / `BLUE` / `WHITE` / `BLACK`
- `withAlpha(alpha)` - 设置透明度

### `Cesium.ScreenSpaceEventType`
- `LEFT_CLICK` - 左键点击
- `RIGHT_CLICK` - 右键点击
- `MOUSE_MOVE` - 鼠标移动
- `WHEEL` - 鼠标滚轮

### `Cesium.ClockRange`
- `CLAMPED` - 到达终点后停止
- `LOOP_STOP` - 到达终点后循环
- `UNBOUNDED` - 无限制

### `Cesium.ClockStep`
- `TICK_DEPENDENT` - 依赖 tick
- `SYSTEM_CLOCK` - 系统时钟
- `SYSTEM_CLOCK_MULTIPLIER` - 系统时钟倍数

## Viewer 配置选项

```javascript
const viewer = new Cesium.Viewer('container', {
    // 动画控件
    animation: true,
    // 底图选择器
    baseLayerPicker: true,
    // 全屏按钮
    fullscreenButton: true,
    // VR 按钮
    vrButton: false,
    // 地理编码搜索
    geocoder: true,
    // 主页按钮
    homeButton: true,
    // 信息框
    infoBox: true,
    // 场景模式选择器
    sceneModePicker: true,
    // 时间轴
    timeline: true,
    // 导航帮助
    navigationHelpButton: true,
    // 场景模式
    sceneMode: Cesium.SceneMode.SCENE3D,
    // 底图
    imageryProvider: ...,
    // 地形
    terrain: ...,
    // 自动渲染
    useDefaultRenderLoop: true,
    // 投影类型
    mapProjection: ...,
    // 天空盒
    skyBox: ...,
    // 天空大气
    skyAtmosphere: ...,
    // 阴影
    shadows: false,
    // 软阴影
    softShadows: false,
    // 环境光遮蔽
    ambientOcclusion: false
});
```

## 常用异步加载方法

Cesium 中许多资源加载使用异步方法，通常以 `fromUrl` 或 `load` 结尾：

```javascript
// 加载 3D Tileset
const tileset = await Cesium.Cesium3DTileset.fromUrl(url);

// 加载 GeoJSON
const dataSource = await Cesium.GeoJsonDataSource.load(url, options);

// 加载 KML
const dataSource = await Cesium.KmlDataSource.load(url, options);

// 创建地形
const terrain = await Cesium.createWorldTerrainAsync();

// 创建影像
const imagery = await Cesium.ImageryProvider.fromUrl(url);
```

## 完整 API 文档

完整的 API 文档请访问：https://cesium.com/learn/cesiumjs/ref-doc/
