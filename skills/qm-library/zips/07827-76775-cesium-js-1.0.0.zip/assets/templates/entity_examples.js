/**
 * Cesium Entity 示例代码集合
 * 包含各种 Entity 的创建和配置示例
 */

// ============================================
// 1. 点 (Point)
// ============================================
function createPointExample(viewer) {
    return viewer.entities.add({
        name: '点示例',
        position: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 0),
        point: {
            pixelSize: 20,                      // 像素大小
            color: Cesium.Color.RED,            // 颜色
            outlineColor: Cesium.Color.WHITE,   // 边框颜色
            outlineWidth: 2,                    // 边框宽度
            disableDepthTestDistance: Number.POSITIVE_INFINITY  // 禁用深度测试
        }
    });
}

// ============================================
// 2. 标签 (Label)
// ============================================
function createLabelExample(viewer) {
    return viewer.entities.add({
        name: '标签示例',
        position: Cesium.Cartesian3.fromDegrees(116.40, 39.91, 0),
        label: {
            text: '北京市',
            font: '16pt sans-serif',
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
            pixelOffset: new Cesium.Cartesian2(0, -20),
            disableDepthTestDistance: Number.POSITIVE_INFINITY
        }
    });
}

// ============================================
// 3. 折线 (Polyline)
// ============================================
function createPolylineExample(viewer) {
    return viewer.entities.add({
        name: '折线示例',
        polyline: {
            positions: Cesium.Cartesian3.fromDegreesArray([
                116.39, 39.9,
                121.47, 31.23,
                113.26, 23.13
            ]),
            width: 5,
            material: new Cesium.PolylineGlowMaterialProperty({
                glowPower: 0.2,
                color: Cesium.Color.BLUE
            }),
            clampToGround: true  // 贴地
        }
    });
}

// ============================================
// 4. 多边形 (Polygon)
// ============================================
function createPolygonExample(viewer) {
    return viewer.entities.add({
        name: '多边形示例',
        polygon: {
            hierarchy: Cesium.Cartesian3.fromDegreesArray([
                116.0, 39.5,
                117.0, 39.5,
                117.0, 40.0,
                116.0, 40.0
            ]),
            material: Cesium.Color.RED.withAlpha(0.5),
            outline: true,
            outlineColor: Cesium.Color.RED,
            outlineWidth: 2,
            perPositionHeight: false
        }
    });
}

// ============================================
// 5. 矩形 (Rectangle)
// ============================================
function createRectangleExample(viewer) {
    return viewer.entities.add({
        name: '矩形示例',
        rectangle: {
            coordinates: Cesium.Rectangle.fromDegrees(116.0, 39.5, 117.0, 40.0),
            material: Cesium.Color.BLUE.withAlpha(0.3),
            outline: true,
            outlineColor: Cesium.Color.BLUE
        }
    });
}

// ============================================
// 6. 圆形 (Ellipse/Circle)
// ============================================
function createCircleExample(viewer) {
    return viewer.entities.add({
        name: '圆形示例',
        position: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 0),
        ellipse: {
            semiMajorAxis: 50000.0,   // 长半轴（米）
            semiMinorAxis: 50000.0,   // 短半轴（米）
            material: Cesium.Color.GREEN.withAlpha(0.5),
            outline: true,
            outlineColor: Cesium.Color.GREEN
        }
    });
}

// ============================================
// 7. 广告牌/图标 (Billboard)
// ============================================
function createBillboardExample(viewer) {
    return viewer.entities.add({
        name: '图标示例',
        position: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 0),
        billboard: {
            image: 'data:image/svg+xml;base64,' + btoa(`
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">
                    <circle cx="16" cy="16" r="14" fill="red" stroke="white" stroke-width="2"/>
                </svg>
            `),
            width: 32,
            height: 32,
            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
            disableDepthTestDistance: Number.POSITIVE_INFINITY
        }
    });
}

// ============================================
// 8. 3D 模型 (Model)
// ============================================
function createModelExample(viewer) {
    return viewer.entities.add({
        name: '3D模型示例',
        position: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 0),
        model: {
            uri: './models/model.glb',  // 模型路径
            scale: 1.0,                   // 缩放比例
            minimumPixelSize: 128,         // 最小像素大小
            maximumScale: 20000,           // 最大缩放
            runAnimations: true,            // 运行动画
            clampAnimations: false,         // 钳制动画
            shadows: Cesium.ShadowMode.ENABLED  // 阴影
        }
    });
}

// ============================================
// 9. 盒子 (Box)
// ============================================
function createBoxExample(viewer) {
    return viewer.entities.add({
        name: '盒子示例',
        position: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 50000),
        box: {
            dimensions: new Cesium.Cartesian3(100000, 100000, 100000),  // 长、宽、高（米）
            material: Cesium.Color.ORANGE.withAlpha(0.7),
            outline: true,
            outlineColor: Cesium.Color.BLACK
        }
    });
}

// ============================================
// 10. 椭圆体/球体 (Ellipsoid)
// ============================================
function createEllipsoidExample(viewer) {
    return viewer.entities.add({
        name: '球体示例',
        position: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 100000),
        ellipsoid: {
            radii: new Cesium.Cartesian3(100000, 100000, 100000),  // 半径（米）
            material: Cesium.Color.YELLOW.withAlpha(0.3),
            outline: true,
            outlineColor: Cesium.Color.YELLOW
        }
    });
}

// ============================================
// 11. 走廊 (Corridor)
// ============================================
function createCorridorExample(viewer) {
    return viewer.entities.add({
        name: '走廊示例',
        corridor: {
            positions: Cesium.Cartesian3.fromDegreesArray([
                116.0, 39.5,
                116.5, 39.75,
                117.0, 40.0
            ]),
            width: 20000.0,  // 宽度（米）
            material: Cesium.Color.PURPLE.withAlpha(0.5),
            outline: true,
            outlineColor: Cesium.Color.PURPLE
        }
    });
}

// ============================================
// 12. 圆柱/圆锥 (Cylinder)
// ============================================
function createCylinderExample(viewer) {
    return viewer.entities.add({
        name: '圆柱示例',
        position: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 50000),
        cylinder: {
            length: 100000.0,        // 长度（米）
            topRadius: 50000.0,      // 顶部半径
            bottomRadius: 50000.0,   // 底部半径
            material: Cesium.Color.CYAN.withAlpha(0.7),
            outline: true,
            outlineColor: Cesium.Color.CYAN
        }
    });
}

// ============================================
// 使用示例
// ============================================
// const viewer = new Cesium.Viewer('cesiumContainer');
// createPointExample(viewer);
// createLabelExample(viewer);
// 等等...
