/**
 * Cesium 相机控制和交互示例
 * 包含相机操作、鼠标交互、绘制工具等
 */

// ============================================
// 1. 相机控制
// ============================================

// 1.1 设置相机视角
function setCameraView(viewer) {
    viewer.camera.setView({
        destination: Cesium.Cartesian3.fromDegrees(116.39, 39.9, 100000),
        orientation: {
            heading: Cesium.Math.toRadians(0),      // 朝向（弧度）
            pitch: Cesium.Math.toRadians(-45),       // 俯仰角
            roll: 0.0                                // 翻滚角
        }
    });
}

// 1.2 飞行到位置
function flyTo(viewer, longitude, latitude, height) {
    viewer.camera.flyTo({
        destination: Cesium.Cartesian3.fromDegrees(longitude, latitude, height),
        orientation: {
            heading: Cesium.Math.toRadians(0),
            pitch: Cesium.Math.toRadians(-45),
            roll: 0.0
        },
        duration: 3.0,  // 飞行时间（秒）
        complete: function() {
            console.log('飞行完成');
        },
        cancel: function() {
            console.log('飞行取消');
        }
    });
}

// 1.3 缩放到实体
function zoomToEntity(viewer, entity) {
    viewer.zoomTo(entity, new Cesium.HeadingPitchRange(
        Cesium.Math.toRadians(0),
        Cesium.Math.toRadians(-45),
        1000
    ));
}

// 1.4 跟随实体
function trackEntity(viewer, entity) {
    viewer.trackedEntity = entity;
}

// 1.5 取消跟随
function cancelTrackEntity(viewer) {
    viewer.trackedEntity = undefined;
}

// 1.6 相机视角约束
function constrainCamera(viewer) {
    // 限制相机最低高度
    viewer.scene.screenSpaceCameraController.minimumZoomDistance = 1000;
    
    // 限制相机最高高度
    viewer.scene.screenSpaceCameraController.maximumZoomDistance = 10000000;
    
    // 禁止进入地下
    viewer.scene.screenSpaceCameraController.enableCollisionDetection = true;
}

// ============================================
// 2. 鼠标交互
// ============================================

// 2.1 左键点击事件
function setupLeftClick(viewer) {
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    
    handler.setInputAction(function(movement) {
        // 获取点击位置的笛卡尔坐标
        const ray = viewer.camera.getPickRay(movement.position);
        const position = viewer.scene.globe.pick(ray, viewer.scene);
        
        if (Cesium.defined(position)) {
            // 转换为经纬度
            const cartographic = Cesium.Cartographic.fromCartesian(position);
            const longitude = Cesium.Math.toDegrees(cartographic.longitude);
            const latitude = Cesium.Math.toDegrees(cartographic.latitude);
            const height = cartographic.height;
            
            console.log(`点击位置: 经度=${longitude}, 纬度=${latitude}, 高度=${height}`);
        }
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
    
    return handler;
}

// 2.2 鼠标移动事件
function setupMouseMove(viewer) {
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    
    handler.setInputAction(function(movement) {
        const entity = viewer.scene.pick(movement.endPosition);
        
        if (Cesium.defined(entity)) {
            viewer.scene.canvas.style.cursor = 'pointer';
        } else {
            viewer.scene.canvas.style.cursor = 'default';
        }
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE);
    
    return handler;
}

// 2.3 右键点击事件
function setupRightClick(viewer) {
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    
    handler.setInputAction(function(movement) {
        console.log('右键点击:', movement.position);
    }, Cesium.ScreenSpaceEventType.RIGHT_CLICK);
    
    return handler;
}

// 2.4 中键/滚轮事件
function setupMiddleClick(viewer) {
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    
    handler.setInputAction(function(movement) {
        console.log('中键点击:', movement.position);
    }, Cesium.ScreenSpaceEventType.MIDDLE_CLICK);
    
    return handler;
}

// ============================================
// 3. 屏幕空间事件处理
// ============================================

// 3.1 销毁事件处理器
function destroyEventHandler(handler) {
    if (Cesium.defined(handler)) {
        handler.destroy();
    }
}

// 3.2 移除特定事件
function removeInputAction(handler, type) {
    if (Cesium.defined(handler)) {
        handler.removeInputAction(type);
    }
}

// ============================================
// 4. 绘制工具
// ============================================

// 4.1 绘制点
function enableDrawPoint(viewer) {
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    
    handler.setInputAction(function(movement) {
        const ray = viewer.camera.getPickRay(movement.position);
        const position = viewer.scene.globe.pick(ray, viewer.scene);
        
        if (Cesium.defined(position)) {
            viewer.entities.add({
                position: position,
                point: {
                    pixelSize: 10,
                    color: Cesium.Color.RED,
                    outlineColor: Cesium.Color.WHITE,
                    outlineWidth: 2
                }
            });
        }
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
    
    return handler;
}

// 4.2 绘制线
function enableDrawPolyline(viewer) {
    let positions = [];
    
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    
    handler.setInputAction(function(movement) {
        const ray = viewer.camera.getPickRay(movement.position);
        const position = viewer.scene.globe.pick(ray, viewer.scene);
        
        if (Cesium.defined(position)) {
            positions.push(position);
            
            if (positions.length >= 2) {
                viewer.entities.add({
                    polyline: {
                        positions: positions,
                        width: 3,
                        material: Cesium.Color.BLUE,
                        clampToGround: true
                    }
                });
            }
        }
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
    
    return handler;
}

// 4.3 绘制多边形
function enableDrawPolygon(viewer) {
    let positions = [];
    
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    
    handler.setInputAction(function(movement) {
        const ray = viewer.camera.getPickRay(movement.position);
        const position = viewer.scene.globe.pick(ray, viewer.scene);
        
        if (Cesium.defined(position)) {
            positions.push(position);
            
            if (positions.length >= 3) {
                viewer.entities.add({
                    polygon: {
                        hierarchy: positions,
                        material: Cesium.Color.RED.withAlpha(0.5),
                        outline: true,
                        outlineColor: Cesium.Color.RED
                    }
                });
            }
        }
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
    
    return handler;
}

// ============================================
// 5. 测量工具
// ============================================

// 5.1 距离测量
function measureDistance(viewer, startPosition, endPosition) {
    const distance = Cesium.Cartesian3.distance(startPosition, endPosition);
    console.log(`距离: ${(distance / 1000).toFixed(2)} 公里`);
    return distance;
}

// 5.2 面积测量
function measureArea(positions) {
    // 使用 Cesium 的几何计算
    const polygon = new Cesium.PolygonGeometry({
        polygonHierarchy: new Cesium.PolygonHierarchy(positions)
    });
    
    const geom = Cesium.PolygonGeometry.createGeometry(polygon);
    console.log(`面积: ${(geom.area / 1000000).toFixed(2)} 平方公里`);
    return geom.area;
}

// 5.3 高度测量
function measureHeight(viewer, position) {
    const cartographic = Cesium.Cartographic.fromCartesian(position);
    const height = cartographic.height;
    console.log(`高度: ${height.toFixed(2)} 米`);
    return height;
}

// ============================================
// 6. 场景控件
// ============================================

// 6.1 切换场景模式
function switchSceneMode(viewer, mode) {
    switch(mode) {
        case '3D':
            viewer.scene.mode = Cesium.SceneMode.SCENE3D;
            break;
        case '2D':
            viewer.scene.mode = Cesium.SceneMode.SCENE2D;
            break;
        case 'Columbus':
            viewer.scene.mode = Cesium.SceneMode.COLUMBUS_VIEW;
            break;
    }
}

// 6.2 开启/关闭光照
function toggleLighting(viewer, enabled) {
    viewer.scene.globe.enableLighting = enabled;
}

// 6.3 开启/关闭阴影
function toggleShadows(viewer, enabled) {
    viewer.shadows = enabled;
    viewer.scene.shadowMap.enabled = enabled;
}

// 6.4 开启/关闭雾化效果
function toggleFog(viewer, enabled) {
    viewer.scene.fog.enabled = enabled;
}

// ============================================
// 使用示例
// ============================================
/*
const viewer = new Cesium.Viewer('cesiumContainer');

// 相机飞行到北京
flyTo(viewer, 116.39, 39.9, 100000);

// 设置鼠标点击效果
const handler = setupLeftClick(viewer);

// 启用绘制点
enableDrawPoint(viewer);
*/
