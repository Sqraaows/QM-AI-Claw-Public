/**
 * Cesium 特效和后处理示例
 * 包含粒子系统、后处理效果、天气模拟等
 */

// ============================================
// 1. 粒子系统
// ============================================

// 1.1 创建火焰效果
function createFireEffect(viewer, position) {
    const particleSystem = new Cesium.ParticleSystem({
        image: createFireImage(),
        emissionRate: 50.0,
        emitter: new Cesium.BoxEmitter(new Cesium.Cartesian3(10.0, 10.0, 10.0)),
        startScale: 1.0,
        endScale: 4.0,
        startColor: Cesium.Color.RED.withAlpha(0.7),
        endColor: Cesium.Color.YELLOW.withAlpha(0.0),
        minLife: 0.5,
        maxLife: 1.0,
        minSpeed: 10.0,
        maxSpeed: 20.0,
        minWidth: 10.0,
        maxWidth: 20.0,
        minHeight: 10.0,
        maxHeight: 20.0
    });
    
    particleSystem.modelMatrix = Cesium.Matrix4.fromTranslation(position);
    viewer.scene.primitives.add(particleSystem);
    
    return particleSystem;
}

// 1.2 创建下雨效果
function createRainEffect(viewer) {
    const rainParticleSystem = new Cesium.ParticleSystem({
        image: createCircleImage('#FFFFFF'),
        emissionRate: 500.0,
        emitter: new Cesium.BoxEmitter(new Cesium.Cartesian3(100000.0, 100000.0, 100000.0)),
        startScale: 1.0,
        endScale: 1.0,
        startColor: Cesium.Color.WHITE.withAlpha(0.8),
        endColor: Cesium.Color.WHITE.withAlpha(0.0),
        minLife: 1.0,
        maxLife: 2.0,
        minSpeed: 500.0,
        maxSpeed: 1000.0,
        updateCallback: function(particle) {
            particle.position = Cesium.Cartesian3.add(
                particle.position,
                new Cesium.Cartesian3(
                    Cesium.Math.randomBetween(-10, 10),
                    Cesium.Math.randomBetween(-10, 10),
                    0
                ),
                particle.position
            );
        }
    });
    
    viewer.scene.primitives.add(rainParticleSystem);
    return rainParticleSystem;
}

// 1.3 创建下雪效果
function createSnowEffect(viewer) {
    const snowParticleSystem = new Cesium.ParticleSystem({
        image: createCircleImage('#FFFFFF'),
        emissionRate: 300.0,
        emitter: new Cesium.BoxEmitter(new Cesium.Cartesian3(100000.0, 100000.0, 100000.0)),
        startScale: 1.0,
        endScale: 1.0,
        startColor: Cesium.Color.WHITE.withAlpha(0.8),
        endColor: Cesium.Color.WHITE.withAlpha(0.0),
        minLife: 2.0,
        maxLife: 4.0,
        minSpeed: 50.0,
        maxSpeed: 100.0,
        updateCallback: function(particle) {
            particle.position = Cesium.Cartesian3.add(
                particle.position,
                new Cesium.Cartesian3(
                    Cesium.Math.randomBetween(-20, 20),
                    Cesium.Math.randomBetween(-20, 20),
                    0
                ),
                particle.position
            );
        }
    });
    
    viewer.scene.primitives.add(snowParticleSystem);
    return snowParticleSystem;
}

// 1.4 创建爆炸效果
function createExplosionEffect(viewer, position) {
    const explosion = new Cesium.ParticleSystem({
        image: createExplosionImage(),
        emissionRate: 0,
        emitter: new Cesium.BoxEmitter(new Cesium.Cartesian3(1.0, 1.0, 1.0)),
        startScale: 1.0,
        endScale: 10.0,
        startColor: Cesium.Color.YELLOW.withAlpha(0.8),
        endColor: Cesium.Color.RED.withAlpha(0.0),
        minLife: 0.5,
        maxLife: 1.0,
        minSpeed: 100.0,
        maxSpeed: 200.0,
        burst: [
            new Cesium.ParticleBurst({ time: 0.0, minimum: 50, maximum: 100 })
        ]
    });
    
    explosion.modelMatrix = Cesium.Matrix4.fromTranslation(position);
    viewer.scene.primitives.add(explosion);
    
    return explosion;
}

// ============================================
// 2. 后处理效果
// ============================================

// 2.1 添加泛光效果（Bloom）
function addBloomEffect(viewer) {
    const bloom = Cesium.PostProcessStageLibrary.createBloomStage();
    viewer.scene.postProcessStages.add(bloom);
    return bloom;
}

// 2.2 添加景深效果（Depth of Field）
function addDepthOfFieldEffect(viewer) {
    const depthOfField = Cesium.PostProcessStageLibrary.createDepthOfFieldStage();
    viewer.scene.postProcessStages.add(depthOfField);
    return depthOfField;
}

// 2.3 添加黑白效果
function addBlackAndWhiteEffect(viewer) {
    const blackAndWhite = new Cesium.PostProcessStage({
        fragmentShader: `
            uniform sampler2D colorTexture;
            varying vec2 v_textureCoordinates;
            void main() {
                vec4 color = texture2D(colorTexture, v_textureCoordinates);
                float luminance = dot(color.rgb, vec3(0.299, 0.587, 0.114));
                gl_FragColor = vec4(luminance, luminance, luminance, color.a);
            }
        `
    });
    viewer.scene.postProcessStages.add(blackAndWhite);
    return blackAndWhite;
}

// 2.4 添加夜视效果
function addNightVisionEffect(viewer) {
    const nightVision = new Cesium.PostProcessStage({
        fragmentShader: `
            uniform sampler2D colorTexture;
            varying vec2 v_textureCoordinates;
            void main() {
                vec4 color = texture2D(colorTexture, v_textureCoordinates);
                float luminance = dot(color.rgb, vec3(0.299, 0.587, 0.114));
                vec3 nightVision = vec3(0.0, luminance, 0.0);
                gl_FragColor = vec4(nightVision, color.a);
            }
        `
    });
    viewer.scene.postProcessStages.add(nightVision);
    return nightVision;
}

// 2.5 添加自定以后处理效果
function addCustomPostProcess(viewer, fragmentShader) {
    const customStage = new Cesium.PostProcessStage({
        fragmentShader: fragmentShader
    });
    viewer.scene.postProcessStages.add(customStage);
    return customStage;
}

// ============================================
// 3. 天气和环境效果
// ============================================

// 3.1 设置雾效果
function setFogEffect(viewer, density, color) {
    viewer.scene.fog.enabled = true;
    viewer.scene.fog.density = density || 0.0001;
    viewer.scene.fog.minimumBrightness = 0.03;
}

// 3.2 设置天空盒
function setSkyBox(viewer) {
    viewer.scene.skyBox = new Cesium.SkyBox({
        sources: {
            positiveX: 'skybox/px.jpg',
            negativeX: 'skybox/nx.jpg',
            positiveY: 'skybox/py.jpg',
            negativeY: 'skybox/ny.jpg',
            positiveZ: 'skybox/pz.jpg',
            negativeZ: 'skybox/nz.jpg'
        }
    });
}

// 3.3 设置环境光
function setAmbientLight(viewer, intensity) {
    viewer.scene.light = new Cesium.DirectionalLight({
        direction: new Cesium.Cartesian3(1.0, 1.0, 1.0),
        intensity: intensity || 1.0
    });
}

// ============================================
// 4. 雷达扫描效果
// ============================================

// 4.1 创建雷达扫描效果（使用 Entity）
function createRadarScan(viewer, centerPosition, radius) {
    let angle = 0;
    
    const radarEntity = viewer.entities.add({
        position: centerPosition,
        ellipse: {
            semiMajorAxis: radius,
            semiMinorAxis: radius,
            material: new Cesium.ImageMaterialProperty({
                image: createRadarImage(),
                transparent: true
            })
        }
    });
    
    // 旋转动画
    viewer.clock.onTick.addEventListener(function(clock) {
        angle += 1;
        if (angle >= 360) angle = 0;
        
        radarEntity.orientation = new Cesium.Quaternion(
            0, 0, Math.sin(Cesium.Math.toRadians(angle / 2)),
            Math.cos(Cesium.Math.toRadians(angle / 2))
        );
    });
    
    return radarEntity;
}

// 4.2 创建雷达扫描效果（使用 CustomShader）
function createRadarScanWithShader(viewer, centerPosition, radius) {
    const radarEntity = viewer.entities.add({
        position: centerPosition,
        ellipse: {
            semiMajorAxis: radius,
            semiMinorAxis: radius,
            material: new Cesium.ColorMaterialProperty(Cesium.Color.RED.withAlpha(0.5)),
            stRotation: new Cesium.CallbackProperty(function() {
                return Cesium.Math.toRadians(Date.now() / 10 % 360);
            }, false)
        }
    });
    
    return radarEntity;
}

// ============================================
// 5. 流动线效果
// ============================================

// 5.1 创建流动线
function createFlowingLine(viewer, positions) {
    const flowingLine = viewer.entities.add({
        polyline: {
            positions: positions,
            width: 5,
            material: new Cesium.PolylineFlowMaterialProperty({
                color: Cesium.Color.CYAN,
                speed: 5.0,
                percent: 0.1,
                gradient: 0.01
            })
        }
    });
    
    return flowingLine;
}

// ============================================
// 辅助函数：创建图像
// ============================================

// 创建火焰图像
function createFireImage() {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const context = canvas.getContext('2d');
    
    const gradient = context.createRadialGradient(32, 32, 0, 32, 32, 32);
    gradient.addColorStop(0, 'rgba(255, 255, 0, 1)');
    gradient.addColorStop(0.5, 'rgba(255, 100, 0, 0.7)');
    gradient.addColorStop(1, 'rgba(255, 0, 0, 0)');
    
    context.fillStyle = gradient;
    context.fillRect(0, 0, 64, 64);
    
    return canvas.toDataURL();
}

// 创建圆形图像
function createCircleImage(color) {
    const canvas = document.createElement('canvas');
    canvas.width = 16;
    canvas.height = 16;
    const context = canvas.getContext('2d');
    
    context.beginPath();
    context.arc(8, 8, 7, 0, 2 * Math.PI);
    context.fillStyle = color || '#FFFFFF';
    context.fill();
    
    return canvas.toDataURL();
}

// 创建爆炸图像
function createExplosionImage() {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const context = canvas.getContext('2d');
    
    const gradient = context.createRadialGradient(32, 32, 0, 32, 32, 32);
    gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
    gradient.addColorStop(0.3, 'rgba(255, 255, 0, 0.8)');
    gradient.addColorStop(0.6, 'rgba(255, 100, 0, 0.4)');
    gradient.addColorStop(1, 'rgba(255, 0, 0, 0)');
    
    context.fillStyle = gradient;
    context.fillRect(0, 0, 64, 64);
    
    return canvas.toDataURL();
}

// 创建雷达扫描图像
function createRadarImage() {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const context = canvas.getContext('2d');
    
    // 绘制雷达扇形
    context.beginPath();
    context.moveTo(128, 128);
    context.arc(128, 128, 128, -Math.PI / 4, Math.PI / 4);
    context.closePath();
    
    const gradient = context.createRadialGradient(128, 128, 0, 128, 128, 128);
    gradient.addColorStop(0, 'rgba(0, 255, 0, 0.8)');
    gradient.addColorStop(1, 'rgba(0, 255, 0, 0)');
    
    context.fillStyle = gradient;
    context.fill();
    
    return canvas.toDataURL();
}

// ============================================
// 使用示例
// ============================================
/*
const viewer = new Cesium.Viewer('cesiumContainer');

// 创建火焰效果
const firePosition = Cesium.Cartesian3.fromDegrees(116.39, 39.9, 0);
createFireEffect(viewer, firePosition);

// 添加泛光效果
addBloomEffect(viewer);

// 设置雾效果
setFogEffect(viewer, 0.0001);
*/
