/**
 * Cesium 数据加载示例代码集合
 * 包含影像、地形、3D Tiles、矢量数据等加载示例
 */

// ============================================
// 1. 影像图层加载
// ============================================

// 1.1 加载 ArcGIS 影像服务
function loadArcGISImagery(viewer) {
    const arcgis = new Cesium.ArcGisMapServerImageryProvider({
        url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer'
    });
    viewer.imageryLayers.addImageryProvider(arcgis);
}

// 1.2 加载 WMS 服务
function loadWMSImagery(viewer) {
    const wms = new Cesium.WebMapServiceImageryProvider({
        url: 'http://localhost:8080/geoserver/wms',
        layers: 'namespace:layername',
        parameters: {
            transparent: true,
            format: 'image/png'
        }
    });
    viewer.imageryLayers.addImageryProvider(wms);
}

// 1.3 加载 WMTS 服务
function loadWMTSImagery(viewer) {
    const wmts = new Cesium.WebMapTileServiceImageryProvider({
        url: 'http://localhost:8080/geoserver/gwc/service/wmts',
        layer: 'layername',
        style: 'default',
        format: 'image/png',
        tileMatrixSetID: 'EPSG:4326'
    });
    viewer.imageryLayers.addImageryProvider(wmts);
}

// 1.4 加载 XYZ 瓦片（如 OSM、天地图等）
function loadXYZImagery(viewer) {
    const xyz = new Cesium.UrlTemplateImageryProvider({
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        subdomains: ['a', 'b', 'c'],
        maximumLevel: 18
    });
    viewer.imageryLayers.addImageryProvider(xyz);
}

// 1.5 加载天地图（需要 token）
function loadTiandituImagery(viewer, token) {
    const tianditu = new Cesium.WebMapTileServiceImageryProvider({
        url: `http://t0.tianditu.gov.cn/img_w/wmts?tk=${token}`,
        layer: 'img',
        style: 'default',
        format: 'tiles',
        tileMatrixSetID: 'w',
        maximumLevel: 18
    });
    viewer.imageryLayers.addImageryProvider(tianditu);
}

// 1.6 加载单张图片
function loadSingleImage(viewer) {
    const singleTile = new Cesium.SingleTileImageryProvider({
        url: './images/overlay.png',
        rectangle: Cesium.Rectangle.fromDegrees(73, 18, 135, 53)  // 中国范围
    });
    viewer.imageryLayers.addImageryProvider(singleTile);
}

// 1.7 移除所有影像图层（保留底图）
function removeAllImageryLayers(viewer) {
    const layers = viewer.imageryLayers;
    while (layers.length > 1) {
        layers.remove(layers.get(layers.length - 1));
    }
}

// ============================================
// 2. 地形加载
// ============================================

// 2.1 加载 Cesium World Terrain
async function loadWorldTerrain(viewer) {
    try {
        const terrain = await Cesium.createWorldTerrainAsync({
            requestWaterMask: true,      // 请求水面遮罩
            requestVertexNormals: true   // 请求顶点法线
        });
        viewer.terrainProvider = terrain;
        console.log('地形加载成功');
    } catch (error) {
        console.error('地形加载失败:', error);
    }
}

// 2.2 加载自定义地形服务
function loadCustomTerrain(viewer) {
    const terrain = new Cesium.CesiumTerrainProvider({
        url: 'http://localhost:8000/terrain',
        requestWaterMask: true
    });
    viewer.terrainProvider = terrain;
}

// 2.3 不使用地形（纯椭球体）
function useEllipsoidTerrain(viewer) {
    viewer.terrainProvider = new Cesium.EllipsoidTerrainProvider();
}

// ============================================
// 3. 3D Tiles 加载
// ============================================

// 3.1 加载 3D Tileset（倾斜摄影）
async function load3DTileset(viewer, url) {
    try {
        const tileset = await Cesium.Cesium3DTileset.fromUrl(url, {
            maximumScreenSpaceError: 16,  // 屏幕空间误差
            maximumNumberOfLoadedTiles: 1000,
            cullWithChildrenBounds: true
        });
        
        viewer.scene.primitives.add(tileset);
        
        // 定位到 tileset
        await viewer.zoomTo(tileset);
        
        console.log('3D Tiles 加载成功');
        return tileset;
    } catch (error) {
        console.error('3D Tiles 加载失败:', error);
    }
}

// 3.2 3D Tiles 样式设置
function setTilesetStyle(tileset) {
    tileset.style = new Cesium.Cesium3DTileStyle({
        color: {
            conditions: [
                ['${Height} >= 100', 'rgba(45, 0, 75, 0.5)'],
                ['${Height} >= 50', 'rgba(170, 162, 204, 0.5)'],
                ['true', 'rgba(127, 59, 8, 0.5)']
            ]
        },
        show: '${Height} > 0'
    });
}

// 3.3 3D Tiles 点击查询
function setupTilesetPick(viewer, tileset) {
    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    handler.setInputAction(function(movement) {
        const ray = viewer.camera.getPickRay(movement.position);
        const feature = viewer.scene.pickPosition(ray);
        const picked = viewer.scene.pick(movement.position);
        
        if (Cesium.defined(picked) && picked.primitive === tileset) {
            console.log('选中要素:', picked);
            const properties = picked.getPropertyNames();
            properties.forEach(name => {
                console.log(`${name}: ${picked.getProperty(name)}`);
            });
        }
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
}

// ============================================
// 4. 矢量数据加载
// ============================================

// 4.1 加载 GeoJSON
async function loadGeoJSON(viewer, url) {
    try {
        const dataSource = await Cesium.GeoJsonDataSource.load(url, {
            stroke: Cesium.Color.RED,
            fill: Cesium.Color.RED.withAlpha(0.5),
            strokeWidth: 3,
            markerSymbol: '?'
        });
        
        viewer.dataSources.add(dataSource);
        await viewer.zoomTo(dataSource);
        
        console.log('GeoJSON 加载成功');
        return dataSource;
    } catch (error) {
        console.error('GeoJSON 加载失败:', error);
    }
}

// 4.2 加载 KML
async function loadKML(viewer, url) {
    try {
        const dataSource = await Cesium.KmlDataSource.load(url, {
            camera: viewer.camera,
            canvas: viewer.scene.canvas
        });
        
        viewer.dataSources.add(dataSource);
        await viewer.zoomTo(dataSource);
        
        console.log('KML 加载成功');
        return dataSource;
    } catch (error) {
        console.error('KML 加载失败:', error);
    }
}

// 4.3 加载 CZML（支持时序动画）
async function loadCZML(viewer, url) {
    try {
        const dataSource = await Cesium.CzmlDataSource.load(url);
        viewer.dataSources.add(dataSource);
        
        console.log('CZML 加载成功');
        return dataSource;
    } catch (error) {
        console.error('CZML 加载失败:', error);
    }
}

// ============================================
// 5. 离线数据部署示例
// ============================================

// 5.1 离线影像瓦片
function loadOfflineImagery(viewer) {
    const offlineImagery = new Cesium.UrlTemplateImageryProvider({
        url: 'http://localhost:8080/tiles/{z}/{x}/{y}.png',
        minimumLevel: 0,
        maximumLevel: 18
    });
    viewer.imageryLayers.addImageryProvider(offlineImagery);
}

// 5.2 离线地形
function loadOfflineTerrain(viewer) {
    const terrain = new Cesium.CesiumTerrainProvider({
        url: 'http://localhost:8080/terrain'
    });
    viewer.terrainProvider = terrain;
}

// ============================================
// 使用示例
// ============================================
/*
const viewer = new Cesium.Viewer('cesiumContainer');

// 加载影像
loadArcGISImagery(viewer);

// 加载地形
await loadWorldTerrain(viewer);

// 加载 3D Tiles
const tileset = await load3DTileset(viewer, './tiles/tileset.json');

// 加载 GeoJSON
await loadGeoJSON(viewer, './data.geojson');
*/
