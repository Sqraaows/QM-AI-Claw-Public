## Description: <br>
flomo lets an agent read, create, update, search, and organize flomo memos through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate a connected flomo workspace from an agent, including memo creation and updates, note search and retrieval, daily reviews, memory context, and tag management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access private flomo note content, generated memory context, and user profile data through a connected account. <br>
Mitigation: Install only when agent access to the flomo account is intended, and treat read results as private user data. <br>
Risk: Memo creation, memo updates, and tag renames can change flomo state. <br>
Mitigation: Review the exact payload and expected effect before approving any state-changing action. <br>


## Reference(s): <br>
- [flomo homepage](https://flomoapp.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-flomo) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action schemas are fetched before execution; write actions require reviewing the exact payload and intended effect.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
