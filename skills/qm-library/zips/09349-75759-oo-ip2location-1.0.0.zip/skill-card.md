## Description: <br>
IP2Location.io helps agents look up IP geolocation, domain WHOIS, and hosted-domain data through an OOMOL-connected IP2Location.io account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to inspect IP2Location.io connector schemas and run read-only lookups for IP geolocation, domain WHOIS, and hosted domains through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses OOMOL as an intermediary for IP2Location.io lookups and account credentials. <br>
Mitigation: Install it only when you intend to use OOMOL for IP2Location.io, and connect only credentials you are comfortable using through that account. <br>
Risk: The optional setup path can install the oo CLI from OOMOL's installer. <br>
Mitigation: Review OOMOL's official installation instructions before installing, and run setup only when an auth, connection, or missing-command error requires it. <br>
Risk: Connector action schemas and upstream defaults can change. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [IP2Location.io homepage](https://www.ip2location.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_domain_whois action](actions/get_domain_whois.md) <br>
- [get_ip_geolocation action](actions/get_ip_geolocation.md) <br>
- [list_hosted_domains action](actions/list_hosted_domains.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON. The skill requires an installed oo CLI, an OOMOL sign-in, and a connected IP2Location.io account.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
