## Description: <br>
Alpha Vantage helps agents search symbols and retrieve read-only market data through OOMOL's Alpha Vantage connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Alpha Vantage action schemas, search supported securities, retrieve quote snapshots, check market status, and fetch daily, weekly, or monthly OHLCV time series. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill makes network calls through OOMOL and Alpha Vantage and may depend on persistent account connection state. <br>
Mitigation: Install and use it only when an OOMOL oo CLI connection to Alpha Vantage is intended; review the oo CLI installer and connection state before first-time setup. <br>
Risk: Market-data requests can send finance symbols or search terms to the connected services. <br>
Mitigation: Review each payload against the live connector schema and use only symbols or searches appropriate for the user's environment. <br>
Risk: Authentication, expired credential, missing scope, or billing errors can block connector execution. <br>
Mitigation: Treat those failures as setup issues and run login, connection, or billing steps only after the matching command failure. <br>


## Reference(s): <br>
- [Alpha Vantage homepage](https://www.alphavantage.co) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-alpha-vantage) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an authenticated OOMOL oo CLI connection to Alpha Vantage and inspects live connector schemas before running actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
