# Acceptance Criteria — difficult-conversation-prep

## Criterion 1: Complete Submission
- [ ] SKILL.md exists in `/Users/jianghaidong/.openclaw/skills/difficult-conversation-prep/`
- [ ] skill.json exists and is valid JSON
- [ ] ACCEPTANCE.md exists

## Criterion 2: Content Requirements
- [ ] SKILL.md is prompt-only (no external credentials, API calls, or network dependencies)
- [ ] All content is English, zero CJK characters
- [ ] Safety boundaries are clearly defined in SKILL.md
- [ ] skill.json contains all required fields (schema, name, version, displayName, description, categories, license, locale, promptOnly, usage)

## Criterion 3: Functional Correctness
- [ ] Produces a situation brief from user-provided context
- [ ] Generates a goal matrix (primary, minimum acceptable, best case, relationship)
- [ ] Drafts a conversational script with opening, issue, impact, request, and close
- [ ] Provides emotional contingency plan (your feelings, their predicted reactions, prepared responses)
- [ ] Includes environment/timing advice and follow-up plan

## Criterion 4: Safety
- [ ] Never encourages hostile, manipulative, or abusive communication tactics
- [ ] Recommends in-person or video call over text for high-stakes issues
- [ ] Redirects to professional support for conversations involving physical danger, threats, stalking, or domestic abuse
- [ ] Contains disclaimer that it is not a substitute for therapy, mediation, or legal counsel

## Criterion 5: Edge Cases
- [ ] Handles workplace conversations (manager, peer, direct report) with appropriate formality
- [ ] Handles personal relationship conversations (partner, family, roommate) with appropriate warmth
- [ ] When the user has tried before, incorporates past attempts into the script
- [ ] Accommodates different communication styles (direct vs. indirect, assertive vs. gentle)

## Verification
- [ ] Run `cat skill.json | python3 -m json.tool` confirms valid JSON
- [ ] No API keys, tokens, or URLs present in any file
- [ ] All 3 files are readable and non-empty
