## Description: <br>
Linux DO helps agents search and read public Linux DO forum data through the OOMOL linux_do connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to inspect Linux DO categories, tags, latest topics, latest posts, and top topics. It is intended for read-only discovery and retrieval of public forum data. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Installing the OOMOL CLI runs a remote installer command. <br>
Mitigation: Only run the CLI installer after deciding that OOMOL's installer is trusted. <br>
Risk: OOMOL CLI sign-in may be required even though the Linux DO actions are public and read-only. <br>
Mitigation: Use sign-in only when the CLI reports an authentication failure, and avoid handling raw credentials in the skill. <br>


## Reference(s): <br>
- [Linux DO homepage](https://linux.do) <br>
- [Linux DO ClawHub listing](https://clawhub.ai/oomol/oo-linux-do) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [list_categories action](actions/list_categories.md) <br>
- [list_latest_posts action](actions/list_latest_posts.md) <br>
- [list_latest_topics action](actions/list_latest_topics.md) <br>
- [list_tags action](actions/list_tags.md) <br>
- [list_top_topics action](actions/list_top_topics.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only public Linux DO data retrieval; connector responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
