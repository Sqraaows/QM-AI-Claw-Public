## Description: <br>
Analyzes short-form Chinese web fiction by decomposing story core, structure, emotional arc, reversals, writing techniques, character functions, and reusable patterns into local reports. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Writers, editors, and story-development agents use this skill to analyze short popular-fiction source text and produce a reusable deconstruction library for later short-story drafting. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The workflow stores original source text and derived analysis under `拆文库/{书名}/`, which may retain sensitive, private, or copyrighted material locally. <br>
Mitigation: Use only text you are allowed to store and analyze, and avoid providing private or sensitive content unless local retention is acceptable. <br>
Risk: Story deconstruction can preserve enough source structure, examples, or voice cues to influence later derivative writing. <br>
Mitigation: Review generated reports and downstream drafts for rights, originality, and attribution concerns before reuse or publication. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/worldwonderer/story-short-analyze) <br>
- [OpenClaw Source Metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [Output Contract](references/output-contract.md) <br>
- [Output Templates](references/output-templates.md) <br>
- [Material Decomposition](references/material-decomposition.md) <br>
- [Quality Checklist](references/quality-checklist.md) <br>
- [Anti-AI Writing](references/anti-ai-writing.md) <br>
- [Banned Words](references/banned-words.md) <br>
- [Genre Catalog](references/genre-catalog.md) <br>


## Skill Output: <br>
**Output Type(s):** [Analysis, Markdown, JSON, Files, Guidance] <br>
**Output Format:** [Markdown reports and JSON metadata saved to local files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Writes a local deconstruction directory under `拆文库/{书名}/`, including source-text backup, analysis reports, writing-technique notes, plot-node notes, and `_meta.json`.] <br>

## Skill Version(s): <br>
1.1.3 (source: ClawHub release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
