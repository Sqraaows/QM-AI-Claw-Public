## Description: <br>
Build, secure, and optimize production MCP servers with the TypeScript SDK (spec 2025-11-25, SDK v1.29 / v2 alpha). Use when building or reviewing MCP servers or tools - covering transports, tool and schema design, error handling, security and OAuth, performance, known SDK bugs, content vs structuredContent delivery, v2 migration, MCP Apps, extensions, and the Registry. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[tenequm](https://clawhub.ai/user/tenequm) <br>

### License/Terms of Use: <br>
Apache 2.0 <br>


## Use Case: <br>
Developers and engineers use this skill as a decision reference when building or reviewing production MCP servers, especially for TypeScript SDK transport choices, tool schemas, error handling, OAuth security, performance, extensions, and migration to v2. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Cloudflared or remote-server examples can expose a local MCP server through a public tunnel. <br>
Mitigation: Use those examples only in controlled testing or with proper authentication, non-sensitive test data, least-privilege scopes, and teardown after use. <br>
Risk: Reference guidance can become stale as MCP specifications, SDK versions, and client behavior evolve. <br>
Mitigation: Check the cited MCP specification, SDK, registry, and issue references before applying guidance to production systems. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/tenequm/mcp-best-practices) <br>
- [Model Context Protocol specification](https://spec.modelcontextprotocol.io) <br>
- [MCP Registry](https://modelcontextprotocol.io/registry/about) <br>
- [Tool schema guide](references/tool-schema-guide.md) <br>
- [Transport patterns](references/transport-patterns.md) <br>
- [Security and auth](references/security-auth.md) <br>
- [Error handling](references/error-handling.md) <br>
- [MCP Apps](references/mcp-apps.md) <br>
- [Extensions and registry](references/extensions-registry.md) <br>
- [v2 migration](references/v2-migration.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, shell commands, configuration] <br>
**Output Format:** [Markdown guidance with TypeScript examples, command snippets, decision tables, and configuration notes] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only reference skill; does not execute tools or produce files by itself.] <br>

## Skill Version(s): <br>
0.5.0 (source: frontmatter, CHANGELOG, server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
