# Draw.io Skill — 交互式图表生成
> **Powered by Boo哥AI智写** — 专业级图表生成技能

Claude Code skill for generating native `.drawio` diagram files and exporting to PNG/SVG/PDF/JPG/WebP using the draw.io desktop CLI. No MCP server required.

## Key Files

| File | Purpose |
|------|---------|
| `SKILL.md` | 主技能文件 — 10环节交互式流程 + 非交互模式 |
| `references/diagram-types.md` | 7类图表详细规范、节点样式、复杂度映射 |
| `references/org-chart-rules.md` | 组织架构图完整规则（标准树形 + 工程项目三层结构） |
| `references/color-themes.md` | 6套配色主题完整色板（商务蓝/科技紫/森林绿/暖橙/灰度/暗夜） |
| `references/chinese-styles.md` | 中文字体选择、排版规范、惯用布局、标准用语 |
| `references/interop.md` | 技能联动 JSON 参数接口规范 |
| `references/xml-reference.md` | Draw.io mxGraphModel XML 完整参考（内联，WebFetch 不可用时回退） |
| `references/templates/*.drawio` | 14个预置模板（流程图/泳道/组织/看板/思维导图/ER/架构） |
| `scripts/check_env.sh` | 跨平台环境检测与自动安装脚本 |
| `scripts/calc_orgchart_coords.py` | 组织架构图坐标自动计算引擎 |

## How It Works

### 交互模式（用户直接调用）

1. 检测环境 + 安装 draw.io（如需要）
2. 确认图表类型（流程图/泳道图/组织架构图/看板/思维导图/ER图/架构图）
3. 确认复杂度（精简3-5项 / 标准6-12项 / 详细12+项）
4. 确认配色主题（6套可选，默认商务蓝）
5. 确认画布尺寸（A4/16:9/自适应/自定义）
6. 确认输出格式（PNG/SVG/PDF/JPG/WebP/.drawio）
7. 收集内容描述
8. 生成 XML + 应用到模板/配色/中文字体
9. 导出到指定格式
10. 打开结果 + 反馈修改循环

### 非交互模式（其他技能调用）

接收结构化 JSON 参数（见 `references/interop.md`），跳过提问直接生成：

```json
{
  "type": "flowchart",
  "complexity": "standard",
  "theme": "business-blue",
  "size": "16:9",
  "format": "png",
  "content": { "nodes": [...], "edges": [...] },
  "output_path": "path/to/output.drawio.png"
}
```

## draw.io CLI Locations

| 环境 | 路径 | 检测方式 |
|------|------|---------|
| Git Bash / MSYS2 | `/c/Program Files/draw.io/draw.io.exe` | `$MSYSTEM` is set |
| WSL2 | `` `/mnt/c/Program Files/draw.io/draw.io.exe` `` | `/proc/version` contains `microsoft` |
| macOS | `/Applications/draw.io.app/Contents/MacOS/draw.io` | `uname -s` = `Darwin` |
| Linux | `drawio` (on PATH) | `uname -s` = `Linux`, not WSL2 |
| Windows cmd | `C:\Program Files\draw.io\draw.io.exe` | `COMSPEC` set, no Unix shell |

未安装时自动通过 winget/brew/snap 安装。

## Export Formats

| Format | Embed XML | Notes |
|--------|-----------|-------|
| `.drawio` | N/A | Native XML, 可编辑 |
| `.drawio.png` | Yes | 通用查看 + 嵌入 XML 可恢复编辑 |
| `.drawio.svg` | Yes | 矢量可缩放 + 嵌入 XML 可恢复编辑 |
| `.drawio.pdf` | Yes | 可打印 + 嵌入 XML 可恢复编辑 |
| `.drawio.jpg` | No | 有损压缩，较轻量 |
| `.drawio.webp` | No | 现代网页格式 |

## Supported Diagram Types

| 类型 | 变体 | 模板文件 |
|------|------|---------|
| 流程图 | 决策流程 | `flowchart-decision.drawio` |
| 泳道图 | 水平 / 垂直 | `swimlane-horizontal.drawio`, `swimlane-vertical.drawio` |
| 组织架构图 | 自上而下 / 左右展开 / 工程项目自上而下 / 工程项目左右展开 | `org-chart-topdown.drawio`, `org-chart-leftright.drawio`, `org-chart-construction.drawio`, `org-chart-construction-leftright.drawio` |
| 看板 | 标准三栏 / Scrum Sprint | `kanban-standard.drawio`, `kanban-sprint.drawio` |
| 思维导图 | 放射状 / 树状 | `mindmap-radial.drawio`, `mindmap-tree.drawio` |
| ER 图 | 标准 | `er-diagram.drawio` |
| 架构图 | 分层 / 微服务 | `arch-layered.drawio`, `arch-microservices.drawio` |

## Chinese Typography

- 字体：Windows → Microsoft YaHei, macOS → PingFang SC, Linux → Noto Sans CJK SC
- 决策标签：是/否、通过/驳回、成功/失败
- 中文流程图惯用布局参考 `references/chinese-styles.md`

## XML Reference

`references/xml-reference.md` 内联了完整的 mxGraphModel XML 参考。原先的在线 URL (`https://raw.githubusercontent.com/jgraph/drawio-mcp/main/shared/xml-reference.md`) 在企业防火墙环境可能不可用，此时使用内联版本或 `curl` 回退。
