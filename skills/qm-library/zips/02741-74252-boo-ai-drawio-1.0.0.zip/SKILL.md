---
name: drawio
description: |
  交互式图表生成技能。Always use when user asks to create, generate, draw, or design a
  diagram, flowchart, architecture diagram, ER diagram, sequence diagram, class diagram,
  network diagram, mockup, wireframe, or UI sketch, or mentions draw.io, drawio,
  .drawio files, or diagram export to PNG/SVG/PDF/JPG/WebP.
  
  新特性：支持流程图、泳道图、组织架构图、看板、思维导图、ER图、架构图，6套配色主题，
  精简/标准/详细三档复杂度，中文字体自动适配，可被其他技能通过 JSON 参数调用。
  
  📌 **Boo哥AI智写** — 专业级图表生成技能，让AI绘图更简单！
---

# Draw.io 交互式图表生成技能

## 调用模式

本技能支持两种模式：

**交互模式（用户直接调用）**：按环节逐一确认图表类型、复杂度、配色、尺寸、格式，再收集内容描述，生成后允许用户反馈修改。

**非交互模式（其他技能调用）**：接收结构化 JSON 参数，跳过提问直接生成。
参数规范见 `references/interop.md`。

---

## 环节一：检测环境与安装 draw.io

### 1.1 自动设置配置文件
首先检查并自动转换特殊命名的文件（用于Skill Hub兼容性）：

```bash
# 自动设置 .gitignore
if [ -f "gitignore.md" ] && [ ! -f ".gitignore" ]; then
    mv gitignore.md .gitignore
    echo "✅ 已自动设置 .gitignore (Powered by Boo哥AI智写)"
fi

# 自动设置 LICENSE
if [ -f "LICENSE.md" ] && [ ! -f "LICENSE" ]; then
    mv LICENSE.md LICENSE
    echo "✅ 已自动设置 LICENSE (Powered by Boo哥AI智写)"
fi

# 自动设置所有 .drawio 模板文件
TEMPLATES_DIR="references/templates"
if [ -d "$TEMPLATES_DIR" ]; then
    for template_md in "$TEMPLATES_DIR"/*.drawio.md; do
        if [ -f "$template_md" ]; then
            template=$(echo "$template_md" | sed 's/\.md$//')
            if [ ! -f "$template" ]; then
                mv "$template_md" "$template"
                echo "✅ 已恢复模板: $(basename "$template")"
            fi
        fi
    done
fi

# Windows PowerShell/cmd 下的回退逻辑 (如果需要)
# if exist gitignore.md if not exist .gitignore ren gitignore.md .gitignore
# if exist LICENSE.md if not exist LICENSE ren LICENSE.md LICENSE
# (模板文件需要类似的批量处理)
```

### 1.2 环境检测与安装
在进入交互之前，先完成环境检测。按 `scripts/check_env.sh` 的逻辑执行：

```bash
# 1. 检测环境类型
uname -s 2>/dev/null
grep -qi microsoft /proc/version 2>/dev/null && echo "WSL2"
echo "$MSYSTEM" 2>/dev/null
echo "$BASH_VERSION" 2>/dev/null
```

| 条件 | 环境 |
|------|------|
| `/proc/version` 含 `microsoft` | WSL2 |
| `$MSYSTEM` 已设置 (MINGW64/MSYS) | Git Bash / MSYS2 |
| `uname -s` = `Darwin` | macOS |
| `uname -s` = `Linux` 且非 WSL2 | Linux |
| 以上皆非，`COMSPEC` 已设置 | Windows cmd |

### 检查安装

```bash
# Git Bash / MSYS2
ls "/c/Program Files/draw.io/draw.io.exe" 2>/dev/null && echo "OK"
ls "$LOCALAPPDATA/Programs/draw.io/draw.io.exe" 2>/dev/null && echo "OK"

# 通用
drawio --version 2>/dev/null || which drawio 2>/dev/null || where drawio 2>/dev/null
```

### 未安装则安装

```bash
# Windows
winget install --id JGraph.Draw --accept-source-agreements --accept-package-agreements

# macOS
brew install --cask drawio

# Linux
sudo snap install drawio
```

安装后重新检查路径。若安装失败，继续生成 `.drawio` 文件，告知用户手动安装后导出。

---

## 环节二：确认图表类型

用 `AskUserQuestion` 工具询问用户选择图表类型：

| 选项 | 说明 | 适用场景 |
|------|------|---------|
| 流程图 (flowchart) | 标准流程、决策分支、循环 | 业务流程、审批流、算法 |
| 泳道图 (swimlane) | 跨角色/部门流程 | 跨部门协作、RACI |
| 组织架构图 (orgchart) | 层级关系、汇报线 | 公司架构、团队结构 |
| 看板 (kanban) | 任务状态列 | 项目进度、需求管理 |
| 思维导图 (mindmap) | 放射状/树状脑图 | 知识梳理、头脑风暴 |
| ER 图 (er) | 实体关系、表结构 | 数据库设计 |
| 架构图 (arch) | 系统分层、组件拓扑 | 技术方案、系统设计 |

详细说明见 `references/diagram-types.md`。

---

## 环节三：确认复杂度

用 `AskUserQuestion` 工具询问复杂度：

| 级别 | 节点/元素数 | 特点 |
|------|------------|------|
| 精简 (simple) | 3-5 个 | 核心主干，适合高层概览 |
| 标准 (standard) | 6-12 个 | 主要分支展开，适合常规文档 |
| 详细 (detailed) | 12+ 个 | 完整流程，含子步骤和异常分支 |

复杂度影响节点数量、嵌套深度和标注详细程度。对于看板，复杂度影响列数和卡片数；对于组织架构图，影响层级深度；对于思维导图，影响分支层数。

---

## 环节四：确认配色主题

用 `AskUserQuestion` 工具询问配色主题。完整色板见 `references/color-themes.md`。

| 主题 | 色调 | 适用场景 |
|------|------|---------|
| 商务蓝 (business-blue) | 蓝色系 + 绿色辅助 + 黄色决策 | 正式汇报、企业架构、对外文档 |
| 科技紫 (tech-purple) | 紫色系 + 蓝色辅助 + 红色强调 | 技术方案、产品架构、研发文档 |
| 森林绿 (forest-green) | 绿色系 + 蓝色辅助 + 橙色强调 | 项目管理、流程图、培训材料 |
| 暖橙 (warm-orange) | 橙色系 + 绿色辅助 + 红色强调 | 创意设计、头脑风暴、内部讨论 |
| 灰度 (grayscale) | 灰色阶 + 黑色边框 | 学术论文、黑白打印、极简风格 |
| 暗夜 (dark) | 深色背景 + 亮色元素 | 深色演示、终端风格、深夜工作 |

若用户未选择，默认使用「商务蓝」。

---

## 环节五：确认画布尺寸

用 `AskUserQuestion` 工具询问：

| 选项 | 尺寸 (px) | 适用场景 |
|------|-----------|---------|
| A4 竖版 | 827 × 1169 | 打印文档、PDF 报告 |
| 16:9 宽屏 | 1280 × 720 | 幻灯片、屏幕演示 |
| 自适应内容 | 自动计算 | 嵌入网页、内容尺寸不确定 |
| 自定义 | 用户指定 | 特殊布局需求 |

---

## 环节六：确认输出格式

用 `AskUserQuestion` 工具询问：

| 格式 | 嵌入 XML | 说明 |
|------|---------|------|
| PNG | 是 (-e) | 通用查看，可在 draw.io 中编辑 |
| SVG | 是 (-e) | 矢量可缩放，可在 draw.io 中编辑 |
| PDF | 是 (-e) | 可打印，可在 draw.io 中编辑 |
| JPG | 否 | 有损压缩，文件较小 |
| WebP | 否 | 现代网页格式 |
| .drawio | N/A | 仅源文件，不导出图片 |

PNG/SVG/PDF 含嵌入 XML，其他人可用 draw.io 打开继续编辑。

---

## 环节七：收集内容描述

用 `AskUserQuestion` 工具询问用户描述想要绘制的内容。

引导用户提供：
- 流程图：有哪些步骤？哪些判断分支？起点和终点是什么？
- 泳道图：有哪些角色/部门？每个角色负责哪些步骤？
- 组织架构图：有哪些层级？每个职位/部门名称？
- 看板：有哪些列？每列有哪些典型任务？
- 思维导图：中心主题是什么？主要分支有哪些？
- ER 图：有哪些实体/表？它们之间的关系？
- 架构图：有哪些系统/组件？它们之间如何连接？

---

## 环节八：生成图表 XML

基于用户选择的所有参数和内容描述，生成 mxGraphModel XML。

### 中文字体与样式

按 `references/chinese-styles.md` 的规范应用样式：

- 字体选择：Windows 用 Microsoft YaHei，macOS 用 PingFang SC，Linux 用 Noto Sans CJK SC
- 在 XML 的 style 属性中设置：`fontFamily=Microsoft YaHei;`
- 决策节点菱形：`rhombus;whiteSpace=wrap;html=1;`
- 流程节点圆角矩形：`rounded=1;whiteSpace=wrap;html=1;`
- 开始/结束椭圆：`ellipse;whiteSpace=wrap;html=1;`
- 是/通过分支：`fontColor=#009900;fontStyle=1;`
- 否/驳回分支：`fontColor=#CC0000;`

### XML 基本结构

```xml
<mxGraphModel adaptiveColors="auto" dx="900" dy="1300" grid="1" gridSize="10">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <!-- 所有元素 parent="1" -->
  </root>
</mxGraphModel>
```

### 配色主题映射

从 `references/color-themes.md` 读取选中主题的填充色和描边色，应用到各类节点。

### 复杂度映射

- 精简：生成 3-5 个核心节点，单条主线无分支
- 标准：生成 6-12 个节点，含主要决策分支和回退路径
- 详细：生成 12+ 个节点，含子步骤、异常处理、图例

### 模板加载

如果内容描述与某个模板匹配度高，读取 `references/templates/` 下对应模板作为起点，在此基础上修改。模板文件名格式：`{type}-{variant}.drawio`。

### 组织架构图连线铁律

组织架构图分为两种模式：

**标准模式（简单树形）**：CEO→下属→员工，正交汇合路由。所有边显式指定 exit/entry。

**工程项目模式（三层结构）**：决策层→管理层→执行层（含可视化分组容器），
适用于建筑工程项目部组织架构。完整规则见 `references/org-chart-rules.md`。
坐标计算可使用 `scripts/calc_orgchart_coords.py` 自动生成。

两种模式共通的铁律：
1. 所有边：`rounded=0` + 显式 `exitX/exitY/entryX/entryY`
2. 垂直对齐的边**不添加** waypoints；非对齐的边使用 2 个 waypoints + 统一 y_hub
3. 分组容器是**视觉边界**，内部节点 `parent="1"`（不能 parent="容器id"）
4. 禁止上级直接连接到分组内部子节点
5. 禁止不同分组边使用不同 y_hub

---

## 环节九：导出

按 `环节一` 检测到的环境构造导出命令：

```bash
# Git Bash / MSYS2
"/c/Program Files/draw.io/draw.io.exe" -x -f {format} -e -b 10 -o "/c/Users/$USER/output.{format}" "/c/Users/$USER/input.drawio"

# WSL2
`/mnt/c/Program Files/draw.io/draw.io.exe` -x -f {format} -e -b 10 -o output.{format} input.drawio

# macOS
/Applications/draw.io.app/Contents/MacOS/draw.io -x -f {format} -e -b 10 -o output.{format} input.drawio

# Linux
drawio -x -f {format} -e -b 10 -o output.{format} input.drawio

# Windows cmd
"C:\Program Files\draw.io\draw.io.exe" -x -f {format} -e -b 10 -o output.{format} input.drawio
```

**注意**：JPG 和 WebP 不支持 `-e`（嵌入 XML）标志，省略该参数。
**注意**：`.drawio` 仅输出不导出，跳过此步骤。

导出完成后，保留 `.drawio` 源文件——用户可能后续编辑。

---

## 环节十：打开结果与反馈修改

按环境打开结果文件：

| 环境 | 打开命令 |
|------|---------|
| macOS | `open <file>` |
| Linux | `xdg-open <file>` |
| Git Bash / MSYS2 | `cmd //c start "" "<Windows路径>"` |
| WSL2 | `cmd.exe /c start "" "$(wslpath -w <file>)"` |
| Windows cmd | `start <file>` |

打开后，用 `AskUserQuestion` 询问用户是否需要修改：

- 需要修改 → 收集修改意见 → 回到环节八重新生成
- 满意 → 完成

---

## 非交互模式（被其他技能调用）

当检测到调用来源是其他技能（通过上下文或传入的 JSON 参数判断），按 `references/interop.md` 规范处理：

1. 解析传入的 JSON 参数
2. 用参数中的 type/theme/size/format/content 直接生成
3. 不弹出 `AskUserQuestion`
4. 将输出路径返回给调用方

---

## 参考文件索引

| 文件 | 用途 | 何时读取 |
|------|------|---------|
| `references/diagram-types.md` | 图表类型详细说明、节点样式规范 | 选择图表类型时 |
| `references/org-chart-rules.md` | 组织架构图完整规则（含工程项目三层结构） | 生成组织架构图时 |
| `references/color-themes.md` | 6套主题完整色板、对每个节点类型的颜色映射 | 应用配色时 |
| `references/chinese-styles.md` | 中文字体、排版、惯用布局规范 | 生成中文图表时 |
| `references/interop.md` | 技能联动 JSON 参数规范 | 非交互模式时 |
| `references/xml-reference.md` | Draw.io XML 完整参考 | 生成 XML 结构时 |
| `references/templates/*.drawio` | 预置模板文件 | 匹配到对应图表类型时加载 |
| `scripts/check_env.sh` | 环境检测与自动安装 | 环节一 |
| `scripts/calc_orgchart_coords.py` | 组织架构图坐标自动计算 | 生成复杂组织架构图前 |

---

## 文件命名

- 描述性命名，英文小写 + 连字符：`login-flow`、`database-schema`
- 导出文件双扩展名：`name.drawio.png`、`name.drawio.svg`
- 保留 `.drawio` 源文件，导出文件可独立查看和编辑

## XML 红线

- 绝对禁止 XML 注释 `<!-- -->`
- 特殊字符转义：`&amp;` `&lt;` `&gt;` `&quot;`
- 每个 mxCell id 必须唯一
- 每条边必须有 `<mxGeometry relative="1" as="geometry"/>` 子元素
- 组织架构图：边 `rounded=0`（禁止圆角走线），必须显式指定 exit/entry，垂直边不加 waypoints
- 组织架构图：分组容器仅作视觉边界，内节点 `parent="1"`

## 常见问题

| 问题 | 原因 | 解决 |
|------|------|------|
| CLI 找不到 | 未安装或不在 PATH | winget/brew/snap 安装，见环节一 |
| 导出文件为空 | XML 格式错误 | 检查 XML 红线，验证结构完整 |
| 图表空白 | 缺少 id="0"/id="1" 根单元格 | 确保 mxGraphModel 结构完整 |
| 边不渲染 | Edge 缺 mxGeometry 子元素 | 每条边加 `<mxGeometry relative="1" as="geometry"/>` |
| Git Bash 找不到 | 目录名是 draw.io 不是 drawio | 用 `/c/Program Files/draw.io/draw.io.exe` |
| `cmd //c` 无反应 | MSYS2 路径转换吞掉 /c | 用双斜杠 `//c` 转义 |
| WebFetch 被拦截 | 企业防火墙 | 用 `curl` 回退获取 XML 参考 |
| 组织架构图连线混乱 | 1:1 直接连线，缺少 waypoints 汇合 | 使用正交汇合路由模式：计算 y_hub，每条边 2 个 waypoints，同目标边在子节点中心x重合 |

---

<p align="center">
  <strong>📌 Boo哥AI智写</strong> — 让AI绘图更简单<br>
  <em>Claude Code 技能包 · 开源免费 · 持续更新</em>
</p>
