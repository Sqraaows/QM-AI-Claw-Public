# 🎨 Draw.io Skill for Claude Code
> **Powered by Boo哥AI智写** — 专业级图表生成技能

A Claude Code skill that generates native `.drawio` diagram files with optional export to PNG, SVG, PDF, JPG, or WebP. Interactive mode with 7 diagram types, 6 color themes, 3 complexity levels, and full Chinese typography support.

## Features

- **7 diagram types**: flowchart, swimlane (horizontal/vertical), org chart (top-down/left-right), kanban (standard/sprint), mind map (radial/tree), ER diagram, architecture (layered/microservices)
- **3 complexity levels**: simple (3-5 nodes), standard (6-12 nodes), detailed (12+ nodes)
- **6 color themes**: business blue, tech purple, forest green, warm orange, grayscale, dark mode
- **6 output formats**: `.drawio`, PNG, SVG, PDF, JPG, WebP
- **Chinese typography**: font auto-detection, conventional layouts, standard terminology
- **Interactive mode**: step-by-step guidance from type selection to final export
- **Non-interactive mode**: JSON-driven generation for use by other skills
- **Auto-install**: detects missing draw.io and installs via winget/brew/snap
- **Cross-platform**: Windows (cmd + Git Bash), WSL2, macOS, Linux

## Prerequisites

- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) installed
- [draw.io Desktop](https://github.com/jgraph/drawio-desktop/releases) — auto-installed if missing

## Installation

Copy the entire `drawio/` directory to your Claude Code skills directory:

**Global (all projects):**

```bash
cp -r drawio ~/.claude/skills/drawio
```

**Per-project:**

```bash
cp -r drawio <project>/.claude/skills/drawio
```

The skill references its own `references/` and `scripts/` bundled files at runtime — copy the full directory, not just SKILL.md.

## Usage

### Interactive Mode (default)

Just type what you need — the skill walks you through each choice:

```
/drawio create a flowchart for user login
/drawio png swimlane diagram for order processing
/drawio org chart for my engineering team
/drawio kanban board for sprint planning
/drawio mind map for project brainstorming
/drawio ER diagram for e-commerce database
/drawio architecture overview of our microservices
```

You'll be asked: diagram type → complexity → color theme → size → output format → content description.

### Format Shorthand

Mention a format to skip the format question:

```
/drawio png flowchart for user login        → login-flow.drawio.png
/drawio svg architecture overview           → architecture-overview.drawio.svg
/drawio pdf ER diagram for e-commerce       → er-diagram.drawio.pdf
/drawio webp mind map for brainstorming      → mind-map.drawio.webp
```

### Non-Interactive Mode (for other skills)

Other skills can call drawio with a JSON specification:

```json
{
  "type": "flowchart",
  "complexity": "standard",
  "theme": "business-blue",
  "size": "16:9",
  "format": "png",
  "content": {
    "title": "用户登录流程",
    "nodes": [
      {"id": "start", "label": "开始", "shape": "start"},
      {"id": "login", "label": "用户登录", "shape": "process"},
      {"id": "check", "label": "验证?", "shape": "decision"},
      {"id": "end", "label": "完成", "shape": "end"}
    ],
    "edges": [
      {"from": "start", "to": "login"},
      {"from": "login", "to": "check"},
      {"from": "check", "to": "end", "label": "是"}
    ]
  },
  "output_path": "C:/Users/Administrator/login-flow.drawio.png"
}
```

See `references/interop.md` for the complete API specification.

## Export Formats

| Format | Extension | Embed XML | Notes |
|--------|-----------|-----------|-------|
| (default) | `.drawio` | N/A | Native XML, editable in draw.io, no CLI needed |
| PNG | `.drawio.png` | Yes | Viewable everywhere, editable in draw.io |
| SVG | `.drawio.svg` | Yes | Scalable, editable in draw.io |
| PDF | `.drawio.pdf` | Yes | Printable, editable in draw.io |
| JPG | `.drawio.jpg` | No | Lossy, smaller file size |
| WebP | `.drawio.webp` | No | Modern web format |

The `.drawio.*` double extension signals that the file contains (or can contain) embedded diagram XML. Open PNG/SVG/PDF exports in draw.io to recover and edit the full diagram.

## Color Themes

| Theme | Style | Best For |
|-------|-------|----------|
| `business-blue` | Blue process, green start/end, yellow decision | Formal reports, enterprise docs |
| `tech-purple` | Purple process, blue accent, yellow decision | Tech specs, product architecture |
| `forest-green` | Green process, blue accent, orange highlight | Project management, training |
| `warm-orange` | Orange process, green accent, red highlight | Brainstorming, creative design |
| `grayscale` | Gray tints with black borders | Academic papers, print-ready |
| `dark` | Dark backgrounds, light elements | Dark presentations, terminal style |

## Complexity Levels

| Level | Nodes | Branches | When to Use |
|-------|-------|----------|-------------|
| `simple` | 3-5 | 0-1 | High-level overview, executive summary |
| `standard` | 6-12 | 1-2 | Regular documentation, standard processes |
| `detailed` | 12+ | 3+ | Full workflow, audit trails, onboarding docs |

## Project Structure

```
drawio/
├── SKILL.md                    # Main skill — 10-step interactive flow
├── CLAUDE.md                   # AI context — key files and how it works
├── README.md                   # This file — installation and usage
├── references/
│   ├── diagram-types.md        # Diagram type specs, node styles, complexity mapping
│   ├── color-themes.md         # 6 color theme palettes with color codes
│   ├── chinese-styles.md       # Chinese font, layout, typography conventions
│   ├── interop.md              # JSON API for skill-to-skill integration
│   ├── xml-reference.md        # Complete mxGraphModel XML reference (inline)
│   └── templates/              # 12 pre-built .drawio templates
└── scripts/
    └── check_env.sh            # Cross-platform environment detection + auto-install
```

## Why XML Only?

A `.drawio` file is mxGraphModel XML. Mermaid and CSV require draw.io server-side conversion and can't be saved as native files. Claude generates XML directly, which means:

- No server dependency
- No conversion step
- Files are immediately editable in draw.io
- Output files (PNG/SVG/PDF) embed the source XML for round-trip editing

---

<p align="center">
  <strong>🎯 Boo哥AI智写</strong> — 让AI绘图更简单<br>
  <em>Claude Code 技能包 · 开源免费 · 持续更新</em>
</p>
