# Gitignore for Draw.io Skill (will be auto-renamed to .gitignore)
# Boo哥AI智写 - 专业级图表生成技能

# Build outputs
*.drawio.png
*.drawio.svg
*.drawio.pdf
*.drawio.jpg
*.drawio.webp
output/
dist/
build/

# Editor directories
.vscode/
.idea/
*.swp
*.swo
*~
.DS_Store

# Temporary files
*.tmp
*.temp
.cache/

# Logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Environment files
.env
.env.local
.env.*.local

# Node modules (if any)
node_modules/
