# 中文排版与样式规范

## 字体选择

按操作系统自动选择中文字体，在 mxCell style 中设置 `fontFamily`：

| 平台 | fontFamily |
|------|-----------|
| Windows | `Microsoft YaHei` |
| macOS | `PingFang SC` |
| Linux | `Noto Sans CJK SC` |

如果不能确定平台，使用 `Microsoft YaHei,PingFang SC,Noto Sans CJK SC,sans-serif` 作为回退链。

## 字号规范

| 元素 | fontSize | fontStyle |
|------|----------|-----------|
| 图表标题（如有） | 18 | 1 (bold) |
| 开始/结束节点 | 14 | 1 (bold) |
| 流程节点 | 13 | 0 (normal) |
| 决策节点 | 13 | 1 (bold) |
| 泳道标题 | 14 | 1 (bold) |
| 边标签 | 11 | 0 (normal) |
| 图例文字 | 10 | 0 (normal) |
| 标注/注释 | 11 | 0 (normal) |

## 中文惯用布局

### 流程图

- 主流程垂直居中，从上到下
- 成功/通过/是的分支向右或向下
- 失败/驳回/否的分支向左或向上回退
- 异常处理流程放在主流程左侧
- 回退边用红色标签 `fontColor=#CC0000`

### 决策标签

| 场景 | 正向标签 | 负向标签 |
|------|---------|---------|
| 测试 | 通过 | 未通过 |
| 审查 | 通过 | 驳回 |
| 审批 | 同意 | 拒绝 |
| 判断 | 是 | 否 |
| 结果 | 成功 | 失败 |
| 状态 | 正常 | 异常 |

### 组织架构图

- 顶部为最高层级，逐层向下
- 同一层级的节点水平对齐，间距均匀
- 节点宽度根据职位名称长度自适应（中文约 2-4 字符）
- 建议节点内有职位 + 姓名两行，用 `&lt;br&gt;` 换行

#### 工程项目三层结构

用于建筑工程项目部组织架构图（决策层→管理层→执行层）。

| 层级 | 节点类型 | width×height | fontSize | fontStyle | fillColor | strokeColor |
|------|---------|-------------|----------|-----------|-----------|-------------|
| 决策层 | 第一责任人 | 210×55 | 14 | bold (1) | #d5e8d4 | #82b366 |
| 管理层 | 管理岗位 | 150×50 | 13 | bold (1) | #dae8fc | #6c8ebf |
| 执行层-部门 | 部门节点 | 130×40 | 13 | bold (1) | #e1d5e7 | #9673a6 |
| 执行层-岗位 | 岗位节点 | 130×35 | 12 | normal (0) | #e1d5e7 | #9673a6 |
| 分组容器 | 虚线框 | auto | 13 | bold (1) | none / #f0e6f6 | #9673a6 |

- 容器样式：`dashed=1;verticalAlign=top;spacingTop=5;`
- 容器仅作视觉边界，内部节点 `parent="1"`（非 `parent="容器id"`）
- 节点标签支持双行：`职位&lt;br&gt;姓名`
- 完整规则见 `references/org-chart-rules.md`

### 看板

- 列标题用 14px bold
- 卡片文字用 12px
- 优先级标签用颜色小圆点或 `#color` 文字
- 列宽根据内容自适应，标准列宽 180-220px

### 思维导图

- 中心主题用 16px bold
- 一级分支用 14px bold
- 二级分支用 13px
- 三级及以上用 11px
- 每层缩进 40-60px

## 常见中文图表用语

### 流程图节点命名

| 英文 | 中文 |
|------|------|
| Start | 开始 |
| End | 结束 |
| Process | 处理 |
| Decision | 判断 |
| Input/Output | 输入/输出 |
| Document | 文档 |
| Database | 数据库 |
| Subprocess | 子流程 |
| Wait/Delay | 等待 |
| Loop | 循环 |

### 架构图节点命名

| 英文 | 中文 |
|------|------|
| Frontend / Client | 前端 / 客户端 |
| API Gateway | API 网关 |
| Microservice | 微服务 |
| Database | 数据库 |
| Cache | 缓存 |
| Message Queue | 消息队列 |
| Load Balancer | 负载均衡 |
| CDN | 内容分发 |
| Object Storage | 对象存储 |
| Monitoring | 监控告警 |

## 连线标签

- 标签放在连线的中间位置
- 正向标签（是/通过）用绿色：`fontColor=#009900`
- 负向标签（否/驳回）用红色：`fontColor=#CC0000`
- 标签字号 11px，不加粗
- 标签文字简洁，1-3 个中文字符为佳
