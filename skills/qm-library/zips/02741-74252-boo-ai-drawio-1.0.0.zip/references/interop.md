# 技能联动接口规范

当其他技能需要调用 drawio 生成图表时，使用此 JSON 参数规范。

## 调用方式

其他技能在上下文中提供以下 JSON 结构，drawio 技能检测到后跳过交互式提问，直接生成。

## JSON 参数

```json
{
  "type": "flowchart",
  "complexity": "standard",
  "theme": "business-blue",
  "size": "16:9",
  "format": "png",
  "output_path": "C:/Users/Administrator/output.drawio.png",
  "content": {
    "title": "用户登录流程",
    "nodes": [
      {"id": "start", "label": "开始", "shape": "start"},
      {"id": "login", "label": "用户输入账号密码", "shape": "process"},
      {"id": "check", "label": "验证账号密码", "shape": "decision"},
      {"id": "success", "label": "登录成功", "shape": "end"},
      {"id": "fail", "label": "提示错误", "shape": "process"}
    ],
    "edges": [
      {"from": "start", "to": "login"},
      {"from": "login", "to": "check"},
      {"from": "check", "to": "success", "label": "通过"},
      {"from": "check", "to": "fail", "label": "未通过"},
      {"from": "fail", "to": "login"}
    ]
  }
}
```

## 参数说明

### 顶层参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `type` | string | 是 | 图表类型：`flowchart` / `swimlane` / `orgchart` / `kanban` / `mindmap` / `er` / `arch` |
| `complexity` | string | 否 | 复杂度：`simple` / `standard` / `detailed`。默认 `standard` |
| `theme` | string | 否 | 配色主题：`business-blue` / `tech-purple` / `forest-green` / `warm-orange` / `grayscale` / `dark`。默认 `business-blue` |
| `size` | string | 否 | 画布尺寸：`A4-portrait` / `16:9` / `auto` / `{width}x{height}`。默认 `auto` |
| `format` | string | 否 | 输出格式：`png` / `svg` / `pdf` / `jpg` / `webp` / `drawio`。默认 `png` |
| `output_path` | string | 是 | 输出文件的绝对路径 |
| `content` | object | 是 | 图表内容，格式取决于 type |

### content 通用结构

```json
{
  "title": "图表标题（可选）",
  "nodes": [
    {
      "id": "唯一标识",
      "label": "显示文本（支持 &lt;br&gt; 换行）",
      "shape": "process | decision | start | end | subprocess | data | database | note | delay",
      "lane": "泳道名（仅 swimlane 类型需要）"
    }
  ],
  "edges": [
    {
      "from": "源节点ID",
      "to": "目标节点ID",
      "label": "边标签（可选，如 '是' / '否'）"
    }
  ]
}
```

### 按图表类型的 content 扩展

**泳道图 (swimlane)**：
```json
{
  "orientation": "horizontal | vertical",
  "lanes": ["角色A", "角色B", "角色C"],
  "nodes": [...],
  "edges": [...]
}
```

**组织架构图 (orgchart)**：

标准树形模式：
```json
{
  "orientation": "topdown | leftright",
  "root": {"id": "ceo", "label": "CEO 姓名", "title": "首席执行官"},
  "children": [
    {"id": "cto", "label": "CTO", "parent": "ceo", "title": "技术总监"},
    {"id": "cfo", "label": "CFO", "parent": "ceo", "title": "财务总监"}
  ]
}
```

工程项目三层模式（mode: construction）：
```json
{
  "mode": "construction",
  "orientation": "topdown | leftright",
  "complexity": "standard",
  "canvas_width": 1050,
  "tier1": {"id": "pm", "label": "组长：项目经理", "title": "第一责任人"},
  "tier2": [
    {"id": "deputy1", "label": "项目副经理"},
    {"id": "deputy2", "label": "技术负责人"},
    {"id": "deputy3", "label": "安全总监"}
  ],
  "tier3": [
    {
      "id": "group-func", "label": "职能管理部门",
      "departments": [
        {"id": "dept-safety", "label": "安全管理部"},
        {"id": "dept-quality", "label": "质量管理部"}
      ],
      "positions": [
        {"id": "pos-safety", "label": "专职安全员"},
        {"id": "pos-quality", "label": "质检员"}
      ]
    },
    {
      "id": "group-ops", "label": "作业执行层",
      "departments": [
        {"id": "dept-construct", "label": "施工组"},
        {"id": "dept-material", "label": "材料组"}
      ],
      "positions": [
        {"id": "pos-worker", "label": "施工员"},
        {"id": "pos-matkeeper", "label": "材料员"}
      ]
    }
  ]
}
```

两种模式通过 `mode` 字段区分，无 `mode` 或 `mode: "simple"` 时使用标准树形模式。

**看板 (kanban)**：
```json
{
  "columns": [
    {"name": "待办", "cards": ["任务1", "任务2"]},
    {"name": "进行中", "cards": ["任务3"]},
    {"name": "已完成", "cards": ["任务4", "任务5"]}
  ]
}
```

**思维导图 (mindmap)**：
```json
{
  "orientation": "radial | tree",
  "root": "中心主题",
  "branches": [
    {"label": "分支1", "children": ["子项1-1", "子项1-2"]},
    {"label": "分支2", "children": ["子项2-1"]}
  ]
}
```

**ER 图 (er)**：
```json
{
  "entities": [
    {
      "name": "users",
      "columns": [
        {"name": "id", "type": "INT", "key": "PK"},
        {"name": "name", "type": "VARCHAR(100)"},
        {"name": "dept_id", "type": "INT", "key": "FK"}
      ]
    }
  ],
  "relations": [
    {"from": "users.dept_id", "to": "departments.id", "type": "N:1"}
  ]
}
```

**架构图 (arch)**：
```json
{
  "style": "layered | microservices",
  "components": [
    {"id": "web", "label": "Web前端", "layer": "presentation", "type": "frontend"},
    {"id": "api", "label": "API网关", "layer": "gateway", "type": "gateway"},
    {"id": "svc", "label": "用户服务", "layer": "business", "type": "service"},
    {"id": "db", "label": "MySQL", "layer": "data", "type": "database"}
  ],
  "connections": [
    {"from": "web", "to": "api"},
    {"from": "api", "to": "svc"},
    {"from": "svc", "to": "db"}
  ]
}
```

## 返回值

drawio 技能完成生成后返回：

```json
{
  "success": true,
  "output_path": "C:/Users/Administrator/output.drawio.png",
  "drawio_path": "C:/Users/Administrator/output.drawio",
  "width": 1280,
  "height": 720,
  "format": "png"
}
```

若生成失败：

```json
{
  "success": false,
  "error": "错误描述",
  "output_path": null
}
```
