# 图表类型参考

## 流程图 (flowchart)

最通用的图表类型，描述步骤、决策和流程走向。

### 节点类型

| 节点 | XML 样式 | 用途 |
|------|---------|------|
| 开始/结束 | `ellipse;whiteSpace=wrap;html=1;` | 流程起点和终点 |
| 流程步骤 | `rounded=1;whiteSpace=wrap;html=1;` | 普通操作步骤 |
| 子流程 | `rounded=1;whiteSpace=wrap;html=1;dashed=1;` | 可展开的复合步骤（虚线边框） |
| 判断/决策 | `rhombus;whiteSpace=wrap;html=1;` | 条件分支 |
| 数据/文档 | `shape=parallelogram;perimeter=parallelogramPerimeter;whiteSpace=wrap;html=1;` | 数据输入输出 |
| 数据库 | `shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;` | 数据库读写 |
| 等待 | `shape=delay;whiteSpace=wrap;html=1;` | 延迟/等待 |
| 标注 | `shape=note;whiteSpace=wrap;html=1;size=14;` | 注释说明 |

### 边样式

| 类型 | XML 样式 |
|------|---------|
| 标准连线 | `edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;` |
| 是/通过 | 同上 + `fontColor=#009900;fontStyle=1;` value="是" |
| 否/驳回 | 同上 + `fontColor=#CC0000;` value="否" |
| 虚线（可选流程） | 同上 + `dashed=1;` |
| 回退边 | 同上 + `exitX=0.5;exitY=0;entryX=0;entryY=0.5;` + waypoints |

### 复杂度对应

| 级别 | 节点数 | 分支数 | 典型结构 |
|------|--------|--------|---------|
| 精简 | 3-5 | 0-1 | 线性主干：开始 → 2-3步 → 结束 |
| 标准 | 6-12 | 1-2 | 含1-2个判断节点和回退路径 |
| 详细 | 12+ | 3+ | 含子流程、异常处理、图例 |

---

## 泳道图 (swimlane)

在流程图基础上增加角色/部门维度，用泳道分隔不同参与者。

### 结构

```xml
<mxCell id="lane1" value="角色A" style="swimlane;startSize=30;fillColor=#dae8fc;strokeColor=#6c8ebf;" parent="1">
  <mxGeometry x="40" y="40" width="200" height="600" as="geometry"/>
  <!-- 泳道内的节点 parent="lane1" -->
</mxCell>
```

### 方向

- **水平泳道**：泳道横向排列，流程从左到右
- **垂直泳道**：泳道纵向排列，流程从上到下

### 复杂度对应

| 级别 | 泳道数 | 节点数 |
|------|--------|--------|
| 精简 | 2 | 4-6 |
| 标准 | 3-4 | 8-15 |
| 详细 | 5+ | 15+ |

---

## 组织架构图 (orgchart)

展示层级汇报关系。支持标准树形和工程项目三层结构两种模式。

### 模式选择

| 模式 | 适用场景 | 文档 |
|------|---------|------|
| 标准树形 | 公司架构、团队层级 | 本节下文 |
| 工程项目三层 | 建筑工程项目部（决策层→管理层→执行层） | `references/org-chart-rules.md` |

### 标准树形模式

使用圆角矩形 + 垂直/水平连线。每层节点水平排列，父节点居中于子节点之上。

**方向：** 自上而下 / 左右展开

**连线规则：** 所有边统一使用 `exitX=0.5;exitY=1;entryX=0.5;entryY=0;`，非垂直对齐的边使用 2 个 waypoints 在统一 y_hub 处汇合。垂直对齐的边忽略 waypoints。

### 工程项目三层模式

适用于建筑工程项目组织架构图，严格的三层结构 + 视觉分组容器。

**层级结构：**
```
Tier 1 (决策层):   项目经理（单节点居中）
Tier 2 (管理层):   项目副经理/技术负责人等（3-5节点水平均布）
Tier 3 (执行层):   视觉分组容器（职能管理部门/作业执行层）
                    ├── 部门节点 (parent="1")
                    └── 岗位节点 (parent="1")
```

**核心规则概览：**
- 所有边 `rounded=0`，统一公共样式
- 垂直对齐的边：指定 exit/entry，无 waypoints
- 分组连接边：指定 exit/entry + 2 waypoints，同一层级共享 y_hub
- 分组容器仅作视觉边界，内节点 `parent="1"`
- 边 ID 命名：`ed-{src}-{tgt}` (直连) / `el-{src}-{tgt}` (连分组)

完整规范（节点尺寸、颜色、边样式、禁止模式、坐标计算公式）见 `references/org-chart-rules.md`。
自动坐标计算脚本：`scripts/calc_orgchart_coords.py`。

### 复杂度对应

| 级别 | 层级深度 | 节点数 |
|------|---------|--------|
| 精简 | 2 | 4-8 |
| 标准 | 3-4 | 10-20 |
| 详细 | 5+ | 25+ |

### 组织架构图连线铁律

1. 所有边：`edgeStyle=orthogonalEdgeStyle;rounded=0;`（禁止圆角走线）
2. 边必须显式指定 `exitX/exitY/exitDx/exitDy/entryX/entryY/entryDx/entryDy`
3. 垂直对齐节点间的边**不准添加 waypoints**
4. 非垂直对齐的边：计算统一 y_hub，每条边 2 个 waypoints
5. 分组容器仅是视觉边界，**不是逻辑父容器**
6. 禁止上级直接连接到分组内部子节点

---

## 看板 (kanban)

任务管理的列状视图。

### 结构

使用背景矩形作为列，列内放置卡片形状。

### 预设布局

| 模板 | 列 |
|------|-----|
| 标准三栏 | 待办 / 进行中 / 已完成 |
| Scrum Sprint | Backlog / To Do / In Progress / Review / Done |
| 自定义 | 用户指定列名 |

### 复杂度对应

| 级别 | 列数 | 卡片数 |
|------|------|--------|
| 精简 | 3 | 3-6 |
| 标准 | 4-5 | 8-15 |
| 详细 | 6+ | 15+ |

---

## 思维导图 (mindmap)

以中心主题为根，向外辐射分支。

### 结构

使用 `ellipse` 或 `rounded=1` 作为节点，从中心向四周用直线/曲线连接。

### 方向

- **放射状**：中心主题在中间，分支向四周展开
- **树状**：中心在顶部或左侧，分支向右/向下展开

### 复杂度对应

| 级别 | 深度 | 节点数 |
|------|------|--------|
| 精简 | 2 | 5-10 |
| 标准 | 3 | 15-30 |
| 详细 | 4+ | 35+ |

---

## ER 图 (er)

实体关系图，用于数据库设计。

### 结构

使用矩形（表头 + 字段列表），连线表示关系（1:1, 1:N, M:N）。

### 表节点结构
```
┌──────────────┐
│   表名       │  ← 表头
├──────────────┤
│ PK  id       │  ← 主键
│     name     │
│ FK  dept_id  │  ← 外键
└──────────────┘
```

使用 `shape=table;whiteSpace=wrap;html=1;` 的简化样式，或手动构建分组节点。

### 复杂度对应

| 级别 | 表数 | 关系数 |
|------|------|--------|
| 精简 | 2-3 | 1-2 |
| 标准 | 4-8 | 5-12 |
| 详细 | 9+ | 15+ |

---

## 架构图 (arch)

系统架构拓扑图。

### 变体

- **分层架构**：展现层 → 业务层 → 数据层（自上而下）
- **微服务拓扑**：服务节点 + 通信关系（网络图布局）

### 节点类型

| 节点 | 样式关键词 |
|------|-----------|
| 前端/客户端 | `rounded=1;` 浅蓝色 |
| API 网关 | `shape=parallelogram;` 紫色 |
| 微服务 | `rounded=1;` 蓝色 |
| 数据库 | `shape=cylinder3;` 绿色 |
| 消息队列 | `shape=process;` 橙色 |
| 缓存 | `shape=cylinder3;` 红色 |
| 外部服务 | `dashed=1;rounded=1;` 灰色虚线 |

### 复杂度对应

| 级别 | 组件数 | 关系数 |
|------|--------|--------|
| 精简 | 3-5 | 2-4 |
| 标准 | 6-12 | 8-16 |
| 详细 | 12+ | 20+ |
