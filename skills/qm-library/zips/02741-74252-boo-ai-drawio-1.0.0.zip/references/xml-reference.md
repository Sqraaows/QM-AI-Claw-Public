# Draw.io XML 完整参考

内联版本，用于在 WebFetch 不可用时的回退。

## 基本结构

```xml
<mxGraphModel dx="900" dy="1300" grid="1" gridSize="10" guides="1" tooltips="1"
              connect="1" arrows="1" fold="1" page="1" pageScale="1"
              pageWidth="827" pageHeight="1300" math="0" shadow="0"
              adaptiveColors="auto" background="#ffffff">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
  </root>
</mxGraphModel>
```

## mxGraphModel 属性

| 属性 | 默认值 | 说明 |
|------|--------|------|
| `dx` / `dy` | — | 画布右下角坐标 |
| `grid` | 1 | 是否显示网格 |
| `gridSize` | 10 | 网格间距 (px) |
| `guides` | 1 | 吸附辅助线 |
| `page` | 0/1 | 是否显示页面边界 |
| `pageWidth` / `pageHeight` | — | 页面尺寸 (px) |
| `background` | `#ffffff` | 画布背景色 |
| `adaptiveColors` | `auto` | 自适应颜色模式 |

## mxCell 通用属性

```xml
<mxCell id="unique-id" value="显示文本" style="样式字符串"
        vertex="1" parent="1">
  <mxGeometry x="100" y="100" width="160" height="50" as="geometry"/>
</mxCell>
```

| 属性 | 说明 |
|------|------|
| `id` | 唯一标识符 |
| `value` | 显示文本 |
| `style` | 样式字符串（分号分隔） |
| `vertex` | 1=节点, 0=非节点 |
| `edge` | 1=边, 0=非边 |
| `parent` | 父容器 id |
| `source` / `target` | 边的起止节点 id |

## 节点样式速查

### 基础形状

| 形状 | style 关键属性 |
|------|---------------|
| 矩形 | `whiteSpace=wrap;html=1;` |
| 圆角矩形 | `rounded=1;whiteSpace=wrap;html=1;` |
| 椭圆 | `ellipse;whiteSpace=wrap;html=1;` |
| 菱形（决策） | `rhombus;whiteSpace=wrap;html=1;` |
| 平行四边形 | `shape=parallelogram;perimeter=parallelogramPerimeter;` |
| 圆柱（数据库） | `shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;` |
| 文档 | `shape=document;whiteSpace=wrap;html=1;boundedLbl=1;` |
| 注释 | `shape=note;whiteSpace=wrap;html=1;size=14;` |
| 延迟 | `shape=delay;whiteSpace=wrap;html=1;` |
| 文字 | `text;html=1;strokeColor=none;fillColor=none;align=left;` |
| 泳道 | `swimlane;startSize=30;` |

### 通用样式属性

| 属性 | 说明 | 示例 |
|------|------|------|
| `fillColor` | 填充色 | `#dae8fc` |
| `strokeColor` | 边框色 | `#6c8ebf` |
| `fontColor` | 文字色 | `#333333` |
| `fontSize` | 字号 | `13` |
| `fontStyle` | 0=n, 1=bold, 2=italic, 4=underline | `1` |
| `fontFamily` | 字体 | `Microsoft YaHei` |
| `dashed` | 虚线边框 | `1` |
| `align` | 水平对齐 | `center` / `left` / `right` |
| `verticalAlign` | 垂直对齐 | `middle` / `top` / `bottom` |
| `opacity` | 透明度 | `50` |

## 边样式速查

每条边必须是 **非自闭合** 元素，包含 `mxGeometry` 子元素：

```xml
<mxCell id="e1" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;"
        edge="1" parent="1" source="nodeA" target="nodeB">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### 常用边样式

| style 属性 | 说明 |
|------------|------|
| `edgeStyle=orthogonalEdgeStyle` | 正交走线 |
| `rounded=0/1` | 走线圆角 |
| `orthogonalLoop=1` | 正交环回 |
| `jettySize=auto` | 自动转折 |
| `dashed=1` | 虚线 |
| `exitX=0/0.5/1` | 出口水平位置 |
| `exitY=0/0.5/1` | 出口垂直位置 |
| `entryX=0/0.5/1` | 入口水平位置 |
| `entryY=0/0.5/1` | 入口垂直位置 |
| `startArrow=classic` | 起始箭头 |
| `endArrow=classic` | 结束箭头 |

### 带标签的边

```xml
<mxCell id="e1" value="是"
        style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;fontColor=#009900;fontStyle=1;"
        edge="1" parent="1" source="check" target="next">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

### 带回退路径的边（需 waypoints）

```xml
<mxCell id="e1" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;"
        edge="1" parent="1" source="fix" target="dev">
  <mxGeometry relative="1" as="geometry">
    <Array as="points">
      <mxPoint x="160" y="470"/>
      <mxPoint x="160" y="337"/>
    </Array>
  </mxGeometry>
</mxCell>
```

### 组织架构图 / 层级图边路由（关键）

组织架构图中的边分为两种类型：**垂直边**和**分组连接边**。两种类型的边必须严格区分。

#### 公共边样式（所有边统一使用）

```
edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;
```

注意：左右展开布局使用 `exitX=1;exitY=0.5;entryX=0;entryY=0.5;`

#### 垂直边（源和目标垂直对齐）

适用于上下对齐的同级节点（如部门→岗位）。

**特征：** 源节点和目标节点中心 x 相同 → 不加 waypoints。

```xml
<mxCell id="ed-dept-pos" edge="1" parent="1" source="dept1" target="pos1"
  style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
         exitX=0.5;exitY=1;exitDx=0;exitDy=0;
         entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
  <mxGeometry relative="1" as="geometry" />
</mxCell>
```

#### 分组连接边（上层节点→分组容器）

适用于管理层节点连接到执行层分组容器。

**特征：** 必须包含 2 个 waypoints，同一层级所有边共享同一个 y_hub。

```xml
<mxCell id="el-deputy1-group-func" edge="1" parent="1" source="deputy1" target="group-func"
  style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
         exitX=0.5;exitY=1;exitDx=0;exitDy=0;
         entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
  <mxGeometry relative="1" as="geometry">
    <Array as="points">
      <mxPoint x="{source_centerX}" y="{y_hub}"/>
      <mxPoint x="{target_centerX}" y="{y_hub}"/>
    </Array>
  </mxGeometry>
</mxCell>
```

#### 边 ID 命名规范

| 边类型 | ID 格式 | 示例 |
|--------|---------|------|
| 节点→节点（垂直） | `ed-{source}-{target}` | `ed-pm-deputy1` |
| 节点→分组容器 | `el-{source}-{target}` | `el-deputy1-group-func` |

#### 计算中心 x

```
x_center = mxGeometry.x + mxGeometry.width / 2
```

#### 计算汇合高度 y_hub

```
父层底部 = max(同层父节点 y + height)
子层顶部 = min(同层子节点 y)
y_hub = (父层底部 + 子层顶部) / 2
```

#### 禁止模式（组织架构图专用）

| # | 禁止项 | 说明 |
|---|--------|------|
| 1 | `rounded=1` 在边上 | 组织架构图必须直角走线 |
| 2 | 省略 exit/entry 属性 | 所有边必须显式指定出入口 |
| 3 | 垂直边包含 waypoints | 对齐节点间不需要拐点 |
| 4 | 不同分组边使用不同 y_hub | 同层必须共享统一水平线 |
| 5 | 连线到分组侧面/底部 | 只能从顶部中点进入 |
| 6 | 分组容器作为逻辑父容器 | 内节点 parent="1" 不是 parent="分组id" |
| 7 | 边使用随机 ID | 必须遵循 ed-/el- 命名 |

## 容器

### 泳道

```xml
<mxCell id="lane-1" value="角色A" style="swimlane;startSize=30;fillColor=#f5f5f5;strokeColor=#cccccc;"
        vertex="1" parent="1">
  <mxGeometry x="40" y="40" width="720" height="200" as="geometry"/>
</mxCell>
<!-- 泳道内节点 parent="lane-1" -->
```

### 分组框

```xml
<mxCell id="group-1" value="分组标签" style="rounded=0;whiteSpace=wrap;html=1;dashed=1;fillColor=none;"
        vertex="1" parent="1">
  <mxGeometry x="100" y="100" width="300" height="200" as="geometry"/>
</mxCell>
```

## 图例

```xml
<mxCell id="legend-box" value="" style="rounded=0;whiteSpace=wrap;html=1;fillColor=none;strokeColor=#999999;dashed=1;"
        vertex="1" parent="1">
  <mxGeometry x="590" y="30" width="180" height="130" as="geometry"/>
</mxCell>
<mxCell id="legend-title" value="图例" style="text;html=1;strokeColor=none;fillColor=none;fontStyle=1;"
        vertex="1" parent="1">
  <mxGeometry x="650" y="35" width="60" height="20" as="geometry"/>
</mxCell>
```

## 暗色模式

对于暗色主题，在 mxGraphModel 上设置：

```
background=#121212
```

所有节点使用暗色 fillColor，fontColor 设为 `#e0e0e0`。

## 多页（仅 PDF）

使用 `<diagram>` 标签（draw.io 特定扩展）。使用 `-a` 导出所有页，或 `-p N` 导出第 N 页。

## 红线

1. 绝对禁止 XML 注释 `<!-- -->`
2. 所有 `&` 转义为 `&amp;`
3. 所有 `<` (非标签) 转义为 `&lt;`，`>` 转义为 `&gt;`
4. 属性值中的 `"` 转义为 `&quot;`
5. 每个 mxCell id 必须唯一
6. 边元素不能自闭合，必须有 `<mxGeometry relative="1" as="geometry"/>` 子元素
