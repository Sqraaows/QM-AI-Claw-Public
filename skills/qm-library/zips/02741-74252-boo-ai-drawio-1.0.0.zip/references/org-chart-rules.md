# 组织架构图完整规则

当生成组织架构图（org chart）时，必须遵循本文档的规则。本规则覆盖两种模式：**标准树形**和**工程项目三层结构**。

---

## 一、模式选择

| 模式 | 适用场景 | 特征 |
|------|---------|------|
| 标准树形 | 公司架构、团队层级 | CEO→下属→员工，无分组容器 |
| 工程项目三层 | 建筑工程项目部组织架构 | 决策层→管理层→执行层，含视觉分组容器 |

当用户描述中出现"工程项目"、"项目部"、"施工"、"建筑"、"总包"等关键词，或明确提到"决策层/管理层/执行层"三层结构时，使用工程项目模式。

---

## 二、工程项目三层结构

### 2.1 层级定义

```
Tier 1 (决策层):   项目经理 / 项目总工（1个节点，居中）
Tier 2 (管理层):   项目副经理 / 技术负责人 / 安全总监 等（3-5个节点，水平均分）
Tier 3 (执行层):   职能管理部门 / 作业执行层（2-3个视觉分组容器）
                    └── 部门节点 (3-5个/组)
                        └── 岗位节点 (2-4个/部门)
```

### 2.2 节点视觉标准

| 层级 | 节点类型 | width | height | fillColor | strokeColor | fontSize | fontStyle |
|------|---------|-------|--------|-----------|-------------|----------|-----------|
| 决策层 | 第一责任人 | 210 | 55 | #d5e8d4 | #82b366 | 14 | 1 (bold) |
| 管理层 | 管理岗位 | 150 | 50 | #dae8fc | #6c8ebf | 13 | 1 (bold) |
| 执行层-部门 | 部门/团队 | 130 | 40 | #e1d5e7 | #9673a6 | 13 | 1 (bold) |
| 执行层-职位 | 岗位/人员 | 130 | 35 | #e1d5e7 | #9673a6 | 12 | 0 (normal) |
| 分组容器 | 虚线框 | auto | auto | none / #f0e6f6 | #9673a6 | 13 | 1 (bold) |

### 2.3 分组容器规则

分组容器仅作**视觉边界**，不是逻辑父容器。容器内节点的 `parent="1"`（根节点），不是 `parent="容器id"`。

```xml
<!-- 分组容器 -->
<mxCell id="group-func" value="职能管理部门" 
  style="rounded=0;whiteSpace=wrap;html=1;dashed=1;
         fillColor=#f0e6f6;strokeColor=#9673a6;
         verticalAlign=top;spacingTop=5;
         fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;" 
  vertex="1" parent="1">
  <mxGeometry x="50" y="255" width="450" height="195" as="geometry" />
</mxCell>

<!-- 容器内节点：parent="1"，不是 parent="group-func" -->
<mxCell id="dept-safety" value="安全管理部" parent="1" ...>
  <mxGeometry x="75" y="275" width="130" height="40" as="geometry" />
</mxCell>
```

容器高度计算公式：
```
group_height = top_padding(30) + max(dept_count, pos_count) * (node_height + spacing) + bottom_padding(20)
```

---

## 三、边规则（所有连线必须遵守）

### 3.1 公共边样式（所有边统一使用，不得修改）

```
edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
```

`rounded=0` 是强制要求——组织架构图不允许圆角走线。

### 3.2 垂直边（同列上下对齐的节点之间）

适用于：部门→岗位、岗位→子岗位，以及标准树形模式中的所有上层→下层连线。

**强制要求：**
- 必须指定 `exitX=0.5;exitY=1;exitDx=0;exitDy=0`（从源节点底部中点出发）
- 必须指定 `entryX=0.5;entryY=0;entryDx=0;entryDy=0`（从目标节点顶部中点进入）
- **禁止添加 `<Array as="points">` 拐点**——垂直对齐的节点不需要拐点

**标准模板：**
```xml
<mxCell id="ed-{source}-{target}" edge="1" parent="1" 
  source="{source}" target="{target}"
  style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
         exitX=0.5;exitY=1;exitDx=0;exitDy=0;
         entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
  <mxGeometry relative="1" as="geometry" />
</mxCell>
```

### 3.3 分组连接边（上层节点→分组容器）

适用于：管理层节点（项目副经理等）连接到执行层分组容器。

**强制要求：**
- 同上 exit/entry 位置
- **必须包含 2 个 waypoints**，形成"┬"型拐点路由
- 同一层级的所有分组连接边**共享同一个 y_hub**

**标准模板：**
```xml
<mxCell id="el-{source}-{group}" edge="1" parent="1" 
  source="{source}" target="{group}"
  style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
         exitX=0.5;exitY=1;exitDx=0;exitDy=0;
         entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
  <mxGeometry relative="1" as="geometry">
    <Array as="points">
      <mxPoint x="{source_centerX}" y="{y_hub}" />
      <mxPoint x="{group_centerX}" y="{y_hub}" />
    </Array>
  </mxGeometry>
</mxCell>
```

### 3.4 边 ID 命名规范

| 边类型 | ID 格式 | 示例 |
|--------|---------|------|
| 节点→节点（垂直） | `ed-{source}-{target}` | `ed-pm-deputy1` |
| 节点→分组容器 | `el-{source}-{target}` | `el-deputy1-group-func` |

`ed` = edge direct（直连），`el` = edge to layer（到分组层）。

---

## 四、坐标计算公式

### 4.1 节点水平居中

```
centerX = x + width / 2
```

### 4.2 层级 Y 坐标

```
tier1.y = margin
tier2.y = tier1.y + tier1.height + tier_spacing
tier3.y = tier2.y + tier2.height + tier_spacing
```

tier_spacing 默认 60px（精简）/ 70px（标准）/ 80px（详细）。

### 4.3 水平均匀分布

N 个同级节点在总宽 total_width 内均匀分布：

```
spacing = (total_width - sum(node_widths)) / (N + 1)
node[i].x = margin + spacing + i * (node_width + spacing)
```

### 4.4 汇合高度 y_hub

```
tier_bottom = max(该层各节点 y + height)
next_tier_top = min(下一层各节点 y)
y_hub = (tier_bottom + next_tier_top) / 2
```

同一层级所有分组连接边使用同一个 y_hub，保证水平线完全对齐。

---

## 五、禁止模式清单

| # | 禁止项 | 说明 |
|---|--------|------|
| 1 | `rounded=1` 在边上 | 组织架构图必须正交直角走线 |
| 2 | 斜线连线 | 必须使用正交连线，所有折角为 90° |
| 3 | 省略 exitX/exitY/entryX/entryY | 垂直边和分组边都必须显式指定出入口 |
| 4 | 垂直边添加 waypoints | 上下对齐的节点间不需要拐点 |
| 5 | 不同分组边使用不同 y_hub | 同一层级的所有分组边必须共享同一个 y_hub |
| 6 | 连线到分组侧面/底部 | 只能从分组顶部中点进入 |
| 7 | 上级直接连到分组内子节点 | 必须连接到分组容器本身 |
| 8 | 容器内节点的 parent 指向容器 | 容器仅作视觉边界，内节点 parent="1" |
| 9 | 边使用随机 ID | 必须遵循 ed-/el- 命名规范 |
| 10 | XML 注释 `<!-- -->` | draw.io XML 不允许注释 |

---

## 六、完整 XML 示例

```xml
<!-- Tier 1: 决策层 -->
<mxCell id="pm" value="组长：项目经理&lt;br&gt;（第一责任人）" 
  style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;
         fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;" 
  vertex="1" parent="1">
  <mxGeometry x="420" y="30" width="210" height="55" as="geometry" />
</mxCell>

<!-- Tier 2: 管理层 -->
<mxCell id="deputy1" value="项目副经理" 
  style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;
         fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;" 
  vertex="1" parent="1">
  <mxGeometry x="130" y="145" width="150" height="50" as="geometry" />
</mxCell>

<!-- Tier 3: 分组容器 (parent="1", 非逻辑父容器) -->
<mxCell id="group-func" value="职能管理部门"
  style="rounded=0;whiteSpace=wrap;html=1;dashed=1;
         fillColor=#f0e6f6;strokeColor=#9673a6;
         verticalAlign=top;spacingTop=5;
         fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
  vertex="1" parent="1">
  <mxGeometry x="50" y="255" width="450" height="195" as="geometry" />
</mxCell>

<!-- 容器内部门节点 -->
<mxCell id="dept-safety" value="安全管理部"
  style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;
         fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
  vertex="1" parent="1">
  <mxGeometry x="65" y="278" width="130" height="40" as="geometry" />
</mxCell>

<!-- 容器内岗位节点 -->
<mxCell id="dept-safety-1" value="专职安全员"
  style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;
         fontSize=12;fontFamily=Microsoft YaHei;"
  vertex="1" parent="1">
  <mxGeometry x="65" y="335" width="130" height="35" as="geometry" />
</mxCell>

<!-- 垂直边：部门→岗位 -->
<mxCell id="ed-dept-safety-dept-safety-1" edge="1" parent="1" 
  source="dept-safety" target="dept-safety-1"
  style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
         exitX=0.5;exitY=1;exitDx=0;exitDy=0;
         entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
  <mxGeometry relative="1" as="geometry" />
</mxCell>

<!-- 垂直边：Tier1→Tier2 -->
<mxCell id="ed-pm-deputy1" edge="1" parent="1" source="pm" target="deputy1"
  style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
         exitX=0.5;exitY=1;exitDx=0;exitDy=0;
         entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
  <mxGeometry relative="1" as="geometry" />
</mxCell>

<!-- 分组边：管理层→分组容器，含 2 个 waypoints -->
<mxCell id="el-deputy1-group-func" edge="1" parent="1" 
  source="deputy1" target="group-func"
  style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;
         exitX=0.5;exitY=1;exitDx=0;exitDy=0;
         entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
  <mxGeometry relative="1" as="geometry">
    <Array as="points">
      <mxPoint x="205" y="225" />
      <mxPoint x="275" y="225" />
    </Array>
  </mxGeometry>
</mxCell>
```
