<mxGraphModel dx="900" dy="500" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1169" pageHeight="827" adaptiveColors="auto">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="col1-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="30" y="30" width="250" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col1-title" value="待办 To Do" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="55" y="40" width="200" height="30" as="geometry"/>
    </mxCell>
    <mxCell id="card1a" value="任务卡片 1" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="50" y="80" width="210" height="40" as="geometry"/>
    </mxCell>
    <mxCell id="card1b" value="任务卡片 2" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="50" y="130" width="210" height="40" as="geometry"/>
    </mxCell>
    <mxCell id="col2-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="300" y="30" width="250" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col2-title" value="进行中 In Progress" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="325" y="40" width="200" height="30" as="geometry"/>
    </mxCell>
    <mxCell id="card2a" value="任务卡片 3" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="320" y="80" width="210" height="40" as="geometry"/>
    </mxCell>
    <mxCell id="col3-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="570" y="30" width="250" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col3-title" value="已完成 Done" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="595" y="40" width="200" height="30" as="geometry"/>
    </mxCell>
    <mxCell id="card3a" value="任务卡片 4" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="590" y="80" width="210" height="40" as="geometry"/>
    </mxCell>
    <mxCell id="card3b" value="任务卡片 5" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="590" y="130" width="210" height="40" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>