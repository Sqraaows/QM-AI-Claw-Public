<mxGraphModel dx="1050" dy="500" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1050" pageHeight="500" adaptiveColors="auto">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>

    <!-- ===== Tier 1: 决策层 ===== -->
    <mxCell id="pm" value="组长：项目经理&lt;br&gt;（第一责任人）"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="420" y="30" width="210" height="55" as="geometry" />
    </mxCell>

    <!-- ===== Tier 2: 管理层 ===== -->
    <mxCell id="deputy1" value="项目副经理"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="170" y="155" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="deputy2" value="技术负责人"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="450" y="155" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="deputy3" value="安全总监"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="730" y="155" width="150" height="50" as="geometry" />
    </mxCell>

    <!-- ===== Tier 3: 职能管理部门（分组容器 — 仅视觉边界，非逻辑父容器） ===== -->
    <mxCell id="group-func" value="职能管理部门"
      style="rounded=0;whiteSpace=wrap;html=1;dashed=1;fillColor=#f0e6f6;strokeColor=#9673a6;verticalAlign=top;spacingTop=5;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="110" y="275" width="380" height="150" as="geometry" />
    </mxCell>

    <!-- 职能部门节点 (parent="1"，不隶属于分组容器) -->
    <mxCell id="dept-safety" value="安全管理部"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="125" y="305" width="130" height="40" as="geometry" />
    </mxCell>
    <mxCell id="dept-quality" value="质量管理部"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="345" y="305" width="130" height="40" as="geometry" />
    </mxCell>

    <!-- 职能岗位节点 -->
    <mxCell id="pos-safety" value="专职安全员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="125" y="370" width="130" height="35" as="geometry" />
    </mxCell>
    <mxCell id="pos-quality" value="质检员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="345" y="370" width="130" height="35" as="geometry" />
    </mxCell>

    <!-- ===== Tier 3: 作业执行层（分组容器） ===== -->
    <mxCell id="group-ops" value="作业执行层"
      style="rounded=0;whiteSpace=wrap;html=1;dashed=1;fillColor=#f0f6f0;strokeColor=#82b366;verticalAlign=top;spacingTop=5;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="560" y="275" width="380" height="150" as="geometry" />
    </mxCell>

    <mxCell id="dept-construct" value="施工组"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="575" y="305" width="130" height="40" as="geometry" />
    </mxCell>
    <mxCell id="dept-material" value="材料组"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="795" y="305" width="130" height="40" as="geometry" />
    </mxCell>

    <mxCell id="pos-worker" value="施工员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="575" y="370" width="130" height="35" as="geometry" />
    </mxCell>
    <mxCell id="pos-matkeeper" value="材料员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="795" y="370" width="130" height="35" as="geometry" />
    </mxCell>

    <!-- ===== 边：Tier1→Tier2 ===== -->
    <!-- PM→deputy1: 非垂直对齐，需 waypoints; y_hub=(95+155)/2=125 -->
    <mxCell id="ed-pm-deputy1" edge="1" parent="1" source="pm" target="deputy1"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="525" y="120"/>
          <mxPoint x="245" y="120"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <!-- PM→deputy2: 垂直对齐 (centerX=525)，无 waypoints -->
    <mxCell id="ed-pm-deputy2" edge="1" parent="1" source="pm" target="deputy2"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>

    <!-- PM→deputy3: 非垂直对齐，需 waypoints -->
    <mxCell id="ed-pm-deputy3" edge="1" parent="1" source="pm" target="deputy3"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="525" y="120"/>
          <mxPoint x="805" y="120"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <!-- ===== 边：Tier2→Tier3 分组容器（全连接）y_hub=(205+275)/2=240 ===== -->
    <mxCell id="el-deputy1-group-func" edge="1" parent="1" source="deputy1" target="group-func"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="245" y="240"/>
          <mxPoint x="300" y="240"/>
        </Array>
      </mxGeometry>
    </mxCell>
    <mxCell id="el-deputy1-group-ops" edge="1" parent="1" source="deputy1" target="group-ops"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="245" y="240"/>
          <mxPoint x="750" y="240"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <mxCell id="el-deputy2-group-func" edge="1" parent="1" source="deputy2" target="group-func"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="525" y="240"/>
          <mxPoint x="300" y="240"/>
        </Array>
      </mxGeometry>
    </mxCell>
    <mxCell id="el-deputy2-group-ops" edge="1" parent="1" source="deputy2" target="group-ops"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="525" y="240"/>
          <mxPoint x="750" y="240"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <mxCell id="el-deputy3-group-func" edge="1" parent="1" source="deputy3" target="group-func"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="805" y="240"/>
          <mxPoint x="300" y="240"/>
        </Array>
      </mxGeometry>
    </mxCell>
    <mxCell id="el-deputy3-group-ops" edge="1" parent="1" source="deputy3" target="group-ops"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="805" y="240"/>
          <mxPoint x="750" y="240"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <!-- ===== 边：部门→岗位（垂直对齐，无 waypoints） ===== -->
    <mxCell id="ed-dept-safety-pos-safety" edge="1" parent="1" source="dept-safety" target="pos-safety"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="ed-dept-quality-pos-quality" edge="1" parent="1" source="dept-quality" target="pos-quality"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="ed-dept-construct-pos-worker" edge="1" parent="1" source="dept-construct" target="pos-worker"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="ed-dept-material-pos-matkeeper" edge="1" parent="1" source="dept-material" target="pos-matkeeper"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
  </root>
</mxGraphModel>