<mxGraphModel dx="800" dy="800" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="827" pageHeight="1169" adaptiveColors="auto">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="layer-presentation" value="展现层" style="rounded=0;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;verticalAlign=top;spacingTop=5;" vertex="1" parent="1">
      <mxGeometry x="80" y="60" width="600" height="120" as="geometry"/>
    </mxCell>
    <mxCell id="web" value="Web前端&lt;br&gt;React/Vue" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="120" y="90" width="130" height="55" as="geometry"/>
    </mxCell>
    <mxCell id="mobile" value="移动端&lt;br&gt;iOS/Android" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="500" y="90" width="130" height="55" as="geometry"/>
    </mxCell>
    <mxCell id="layer-business" value="业务层" style="rounded=0;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;verticalAlign=top;spacingTop=5;" vertex="1" parent="1">
      <mxGeometry x="80" y="220" width="600" height="120" as="geometry"/>
    </mxCell>
    <mxCell id="api" value="API 网关" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="120" y="250" width="130" height="45" as="geometry"/>
    </mxCell>
    <mxCell id="svc1" value="用户服务" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="310" y="250" width="110" height="45" as="geometry"/>
    </mxCell>
    <mxCell id="svc2" value="订单服务" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="480" y="250" width="110" height="45" as="geometry"/>
    </mxCell>
    <mxCell id="layer-data" value="数据层" style="rounded=0;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;verticalAlign=top;spacingTop=5;" vertex="1" parent="1">
      <mxGeometry x="80" y="380" width="600" height="120" as="geometry"/>
    </mxCell>
    <mxCell id="db1" value="MySQL" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="120" y="410" width="100" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="cache" value="Redis" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;fillColor=#f8cecc;strokeColor=#b85450;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="330" y="410" width="100" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="mq" value="消息队列" style="shape=process;whiteSpace=wrap;html=1;fillColor=#ffe6cc;strokeColor=#d79b00;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="500" y="410" width="100" height="45" as="geometry"/>
    </mxCell>
    <mxCell id="e-web-api" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;" edge="1" parent="1" source="web" target="api">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e-mobile-api" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;" edge="1" parent="1" source="mobile" target="api">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e-api-svc1" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;" edge="1" parent="1" source="api" target="svc1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e-api-svc2" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;" edge="1" parent="1" source="api" target="svc2">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e-svc1-db" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;" edge="1" parent="1" source="svc1" target="db1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e-svc1-cache" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;dashed=1;" edge="1" parent="1" source="svc1" target="cache">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e-svc2-mq" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;" edge="1" parent="1" source="svc2" target="mq">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>