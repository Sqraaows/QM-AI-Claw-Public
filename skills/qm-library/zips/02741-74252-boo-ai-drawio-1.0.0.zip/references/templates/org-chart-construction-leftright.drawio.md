<mxGraphModel dx="1100" dy="650" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1169" pageHeight="827" adaptiveColors="auto">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>

    <!-- ===== Tier 1: 决策层 (左侧) ===== -->
    <mxCell id="pm" value="组长：项目经理&lt;br&gt;（第一责任人）"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="40" y="240" width="210" height="55" as="geometry" />
    </mxCell>

    <!-- ===== Tier 2: 管理层 (中间) ===== -->
    <mxCell id="deputy1" value="项目副经理"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="360" y="80" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="deputy2" value="技术负责人"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="360" y="240" width="150" height="50" as="geometry" />
    </mxCell>
    <mxCell id="deputy3" value="安全总监"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="360" y="400" width="150" height="50" as="geometry" />
    </mxCell>

    <!-- ===== Tier 3: 执行层分组容器 (右侧) ===== -->
    <mxCell id="group-func" value="职能管理部门"
      style="rounded=0;whiteSpace=wrap;html=1;dashed=1;fillColor=#f0e6f6;strokeColor=#9673a6;verticalAlign=top;spacingTop=5;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="620" y="30" width="420" height="220" as="geometry" />
    </mxCell>

    <mxCell id="dept-safety" value="安全管理部"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="640" y="60" width="130" height="40" as="geometry" />
    </mxCell>
    <mxCell id="dept-quality" value="质量管理部"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="850" y="60" width="130" height="40" as="geometry" />
    </mxCell>
    <mxCell id="pos-safety" value="专职安全员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="640" y="170" width="130" height="35" as="geometry" />
    </mxCell>
    <mxCell id="pos-quality" value="质检员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="850" y="170" width="130" height="35" as="geometry" />
    </mxCell>

    <mxCell id="group-ops" value="作业执行层"
      style="rounded=0;whiteSpace=wrap;html=1;dashed=1;fillColor=#f0f6f0;strokeColor=#82b366;verticalAlign=top;spacingTop=5;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="620" y="290" width="420" height="220" as="geometry" />
    </mxCell>

    <mxCell id="dept-construct" value="施工组"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="640" y="320" width="130" height="40" as="geometry" />
    </mxCell>
    <mxCell id="dept-material" value="材料组"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="850" y="320" width="130" height="40" as="geometry" />
    </mxCell>
    <mxCell id="pos-worker" value="施工员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="640" y="430" width="130" height="35" as="geometry" />
    </mxCell>
    <mxCell id="pos-matkeeper" value="材料员"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=12;fontFamily=Microsoft YaHei;"
      vertex="1" parent="1">
      <mxGeometry x="850" y="430" width="130" height="35" as="geometry" />
    </mxCell>

    <!-- ===== 边：Tier1→Tier2 (left-right: exit from right, enter from left) ===== -->
    <mxCell id="ed-pm-deputy1" edge="1" parent="1" source="pm" target="deputy1"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="300" y="268"/>
          <mxPoint x="300" y="105"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <!-- PM→deputy2: 水平对齐 (centerY=268≈265), 无 waypoints -->
    <mxCell id="ed-pm-deputy2" edge="1" parent="1" source="pm" target="deputy2"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>

    <mxCell id="ed-pm-deputy3" edge="1" parent="1" source="pm" target="deputy3"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="300" y="268"/>
          <mxPoint x="300" y="425"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <!-- ===== 边：Tier2→Tier3 分组容器 x_hub=(510+620)/2=565 ===== -->
    <mxCell id="el-deputy1-group-func" edge="1" parent="1" source="deputy1" target="group-func"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="565" y="105"/>
          <mxPoint x="565" y="140"/>
        </Array>
      </mxGeometry>
    </mxCell>
    <mxCell id="el-deputy1-group-ops" edge="1" parent="1" source="deputy1" target="group-ops"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="565" y="105"/>
          <mxPoint x="565" y="400"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <mxCell id="el-deputy2-group-func" edge="1" parent="1" source="deputy2" target="group-func"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="565" y="265"/>
          <mxPoint x="565" y="140"/>
        </Array>
      </mxGeometry>
    </mxCell>
    <mxCell id="el-deputy2-group-ops" edge="1" parent="1" source="deputy2" target="group-ops"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="565" y="265"/>
          <mxPoint x="565" y="400"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <mxCell id="el-deputy3-group-func" edge="1" parent="1" source="deputy3" target="group-func"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="565" y="425"/>
          <mxPoint x="565" y="140"/>
        </Array>
      </mxGeometry>
    </mxCell>
    <mxCell id="el-deputy3-group-ops" edge="1" parent="1" source="deputy3" target="group-ops"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry">
        <Array as="points">
          <mxPoint x="565" y="425"/>
          <mxPoint x="565" y="400"/>
        </Array>
      </mxGeometry>
    </mxCell>

    <!-- ===== 边：部门→岗位（水平对齐，无 waypoints） ===== -->
    <mxCell id="ed-dept-safety-pos-safety" edge="1" parent="1" source="dept-safety" target="pos-safety"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="ed-dept-quality-pos-quality" edge="1" parent="1" source="dept-quality" target="pos-quality"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="ed-dept-construct-pos-worker" edge="1" parent="1" source="dept-construct" target="pos-worker"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
    <mxCell id="ed-dept-material-pos-matkeeper" edge="1" parent="1" source="dept-material" target="pos-matkeeper"
      style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
  </root>
</mxGraphModel>