<mxGraphModel dx="800" dy="500" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1169" pageHeight="827" adaptiveColors="auto">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="user-header" value="users" style="rounded=0;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="40" y="60" width="150" height="30" as="geometry"/>
    </mxCell>
    <mxCell id="user-body" value="PK  id&lt;br&gt;    name&lt;br&gt;    email&lt;br&gt;FK  dept_id" style="rounded=0;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#6c8ebf;fontSize=12;fontFamily=Consolas,Microsoft YaHei;align=left;spacingLeft=8;" vertex="1" parent="1">
      <mxGeometry x="40" y="90" width="150" height="75" as="geometry"/>
    </mxCell>
    <mxCell id="dept-header" value="departments" style="rounded=0;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="360" y="60" width="150" height="30" as="geometry"/>
    </mxCell>
    <mxCell id="dept-body" value="PK  id&lt;br&gt;    name&lt;br&gt;    manager_id" style="rounded=0;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#82b366;fontSize=12;fontFamily=Consolas,Microsoft YaHei;align=left;spacingLeft=8;" vertex="1" parent="1">
      <mxGeometry x="360" y="90" width="150" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="e-fk" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;startArrow=classic;endArrow=classic;" edge="1" parent="1" source="user-body" target="dept-body">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="rel-label" value="N:1" style="text;html=1;strokeColor=none;fillColor=none;fontSize=11;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="200" y="105" width="40" height="20" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>