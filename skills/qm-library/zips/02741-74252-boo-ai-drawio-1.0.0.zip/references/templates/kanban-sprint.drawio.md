<mxGraphModel dx="1200" dy="500" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1400" pageHeight="827" adaptiveColors="auto">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="col0-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="20" y="30" width="200" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col0-title" value="Backlog" style="text;html=1;strokeColor=none;fillColor=none;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="40" y="38" width="160" height="25" as="geometry"/>
    </mxCell>
    <mxCell id="card0a" value="PBI-001 需求描述" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;fontSize=11;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="35" y="75" width="170" height="35" as="geometry"/>
    </mxCell>
    <mxCell id="col1-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="235" y="30" width="200" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col1-title" value="To Do" style="text;html=1;strokeColor=none;fillColor=none;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="255" y="38" width="160" height="25" as="geometry"/>
    </mxCell>
    <mxCell id="card1a" value="TASK-101 开发功能A" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=11;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="250" y="75" width="170" height="35" as="geometry"/>
    </mxCell>
    <mxCell id="col2-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="450" y="30" width="200" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col2-title" value="In Progress" style="text;html=1;strokeColor=none;fillColor=none;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="470" y="38" width="160" height="25" as="geometry"/>
    </mxCell>
    <mxCell id="card2a" value="TASK-102 修复Bug B" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;fontSize=11;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="465" y="75" width="170" height="35" as="geometry"/>
    </mxCell>
    <mxCell id="col3-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="665" y="30" width="200" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col3-title" value="Review" style="text;html=1;strokeColor=none;fillColor=none;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="685" y="38" width="160" height="25" as="geometry"/>
    </mxCell>
    <mxCell id="card3a" value="TASK-098 代码审查" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#ffe6cc;strokeColor=#d79b00;fontSize=11;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="680" y="75" width="170" height="35" as="geometry"/>
    </mxCell>
    <mxCell id="col4-bg" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#cccccc;" vertex="1" parent="1">
      <mxGeometry x="880" y="30" width="200" height="400" as="geometry"/>
    </mxCell>
    <mxCell id="col4-title" value="Done" style="text;html=1;strokeColor=none;fillColor=none;fontSize=14;fontStyle=1;fontFamily=Microsoft YaHei;align=center;" vertex="1" parent="1">
      <mxGeometry x="900" y="38" width="160" height="25" as="geometry"/>
    </mxCell>
    <mxCell id="card4a" value="TASK-095 已上线功能" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=11;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="895" y="75" width="170" height="35" as="geometry"/>
    </mxCell>
    <mxCell id="card4b" value="TASK-096 文档更新" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=11;fontFamily=Microsoft YaHei;" vertex="1" parent="1">
      <mxGeometry x="895" y="120" width="170" height="35" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>