<mxGraphModel dx="800" dy="1100" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="827" pageHeight="1169" adaptiveColors="auto">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="lane-a" value="角色 A" style="swimlane;startSize=30;fillColor=#f5f5f5;strokeColor=#cccccc;fontFamily=Microsoft YaHei;fontSize=13;fontStyle=1;horizontal=0;" vertex="1" parent="1">
      <mxGeometry x="40" y="60" width="220" height="700" as="geometry"/>
    </mxCell>
    <mxCell id="lane-b" value="角色 B" style="swimlane;startSize=30;fillColor=#f5f5f5;strokeColor=#cccccc;fontFamily=Microsoft YaHei;fontSize=13;fontStyle=1;horizontal=0;" vertex="1" parent="1">
      <mxGeometry x="260" y="60" width="220" height="700" as="geometry"/>
    </mxCell>
    <mxCell id="lane-c" value="角色 C" style="swimlane;startSize=30;fillColor=#f5f5f5;strokeColor=#cccccc;fontFamily=Microsoft YaHei;fontSize=13;fontStyle=1;horizontal=0;" vertex="1" parent="1">
      <mxGeometry x="480" y="60" width="220" height="700" as="geometry"/>
    </mxCell>
    <mxCell id="start" value="开始" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=13;fontFamily=Microsoft YaHei;" vertex="1" parent="lane-a">
      <mxGeometry x="65" y="40" width="90" height="40" as="geometry"/>
    </mxCell>
    <mxCell id="a1" value="角色A步骤" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="lane-a">
      <mxGeometry x="50" y="130" width="120" height="45" as="geometry"/>
    </mxCell>
    <mxCell id="b1" value="角色B步骤" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="lane-b">
      <mxGeometry x="50" y="230" width="120" height="45" as="geometry"/>
    </mxCell>
    <mxCell id="c1" value="角色C步骤" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=12;fontFamily=Microsoft YaHei;" vertex="1" parent="lane-c">
      <mxGeometry x="50" y="330" width="120" height="45" as="geometry"/>
    </mxCell>
    <mxCell id="end" value="结束" style="ellipse;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;fontSize=13;fontFamily=Microsoft YaHei;" vertex="1" parent="lane-c">
      <mxGeometry x="65" y="430" width="90" height="40" as="geometry"/>
    </mxCell>
    <mxCell id="e1" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;" edge="1" parent="1" source="start" target="a1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e2" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;" edge="1" parent="1" source="a1" target="b1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e3" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;" edge="1" parent="1" source="b1" target="c1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="e4" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;" edge="1" parent="1" source="c1" target="end">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>