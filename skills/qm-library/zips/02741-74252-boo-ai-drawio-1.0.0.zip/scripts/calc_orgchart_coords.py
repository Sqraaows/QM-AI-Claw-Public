#!/usr/bin/env python3
"""
Org chart coordinate calculator for draw.io mxGraphModel XML generation.

Two modes:
  simple       - Traditional tree org chart (no group containers)
  construction - 3-tier construction project org chart with visual group containers

Usage:
  echo '<json_spec>' | python calc_orgchart_coords.py --mode construction
  python calc_orgchart_coords.py --mode simple --file spec.json

Output: JSON with computed (x, y, width, height) for every node, group, and edge.
"""

import argparse
import json
import sys
from math import ceil


# ---------------------------------------------------------------------------
# Visual presets
# ---------------------------------------------------------------------------

PRESETS = {
    "construction": {
        "tier1": {"width": 210, "height": 55, "fill": "#d5e8d4", "stroke": "#82b366", "fontSize": 14, "fontStyle": 1},
        "tier2": {"width": 150, "height": 50, "fill": "#dae8fc", "stroke": "#6c8ebf", "fontSize": 13, "fontStyle": 1},
        "dept":  {"width": 130, "height": 40, "fill": "#e1d5e7", "stroke": "#9673a6", "fontSize": 13, "fontStyle": 1},
        "pos":   {"width": 130, "height": 35, "fill": "#e1d5e7", "stroke": "#9673a6", "fontSize": 12, "fontStyle": 0},
    },
    "simple": {
        "root": {"width": 120, "height": 55, "fill": "#d5e8d4", "stroke": "#82b366", "fontSize": 13, "fontStyle": 1},
        "child": {"width": 120, "height": 55, "fill": "#dae8fc", "stroke": "#6c8ebf", "fontSize": 12, "fontStyle": 0},
        "leaf": {"width": 100, "height": 45, "fill": "#d5e8d4", "stroke": "#82b366", "fontSize": 12, "fontStyle": 0},
    },
}


def center_x(node):
    """Return the horizontal center x of a node."""
    return node["x"] + node["width"] / 2


def calc_y_hub(tier_bottom, next_tier_top):
    """Calculate the horizontal routing line between two tiers."""
    return (tier_bottom + next_tier_top) / 2


def distribute_horizontally(node_widths, total_width, margin=40):
    """Distribute N nodes evenly across total_width.

    Returns list of x positions.
    """
    n = len(node_widths)
    total_node_width = sum(node_widths)
    spacing = (total_width - 2 * margin - total_node_width) / (n + 1)
    positions = []
    x_cursor = margin + spacing
    for w in node_widths:
        positions.append(round(x_cursor))
        x_cursor += w + spacing
    return positions


def calc_construction_layout(spec):
    """Compute full 3-tier construction project org chart layout."""
    margin = spec.get("margin", 40)
    tier_spacing = {"simple": 60, "standard": 70, "detailed": 80}.get(
        spec.get("complexity", "standard"), 70
    )
    canvas_width = spec.get("canvas_width", 1050)

    nodes = {}
    edges = []
    groups = []

    # --- Tier 1: single node, centered ---
    t1 = dict(PRESETS["construction"]["tier1"])
    t1["x"] = round((canvas_width - t1["width"]) / 2)
    t1["y"] = margin
    t1["id"] = spec.get("tier1", {}).get("id", "pm")
    t1["label"] = spec.get("tier1", {}).get("label", "项目经理")
    t1["title"] = spec.get("tier1", {}).get("title", "第一责任人")
    nodes[t1["id"]] = t1

    # --- Tier 2: multiple deputy/manager nodes ---
    t2_specs = spec.get("tier2", [
        {"id": "deputy1", "label": "项目副经理"},
        {"id": "deputy2", "label": "技术负责人"},
        {"id": "deputy3", "label": "安全总监"},
    ])
    t2_widths = [PRESETS["construction"]["tier2"]["width"]] * len(t2_specs)
    t2_xs = distribute_horizontally(t2_widths, canvas_width, margin)

    t2_nodes = []
    for i, ts in enumerate(t2_specs):
        node = dict(PRESETS["construction"]["tier2"])
        node["id"] = ts["id"]
        node["label"] = ts["label"]
        node["x"] = t2_xs[i]
        node["y"] = t1["y"] + t1["height"] + tier_spacing
        nodes[node["id"]] = node
        t2_nodes.append(node)

    # Tier1→Tier2 edges (vertical, no waypoints)
    tier1_bottom = t1["y"] + t1["height"]
    tier2_top = t2_nodes[0]["y"]

    for tn in t2_nodes:
        edges.append({
            "id": f'ed-{t1["id"]}-{tn["id"]}',
            "type": "vertical",
            "source": t1["id"],
            "target": tn["id"],
            "style": _edge_style(),
        })

    # --- Tier 3: group containers with departments and positions ---
    t3_specs = spec.get("tier3", [
        {
            "id": "group-eng", "label": "工程技术部",
            "departments": [
                {"id": "dept-tech", "label": "技术组"},
                {"id": "dept-quality", "label": "质量组"},
            ],
            "positions": [
                {"id": "pos-eng", "label": "工程师"},
                {"id": "pos-tech", "label": "技术员"},
            ],
        },
        {
            "id": "group-ops", "label": "作业执行层",
            "departments": [
                {"id": "dept-construct", "label": "施工组"},
                {"id": "dept-material", "label": "材料组"},
            ],
            "positions": [
                {"id": "pos-worker", "label": "施工员"},
                {"id": "pos-matkeeper", "label": "材料员"},
            ],
        },
    ])

    group_padding = {"top": 30, "bottom": 15, "left": 15, "right": 15,
                     "dept_spacing": 17, "pos_spacing": 10, "inter_col_spacing": 30}
    group_config = spec.get("group_padding", group_padding)

    t3_y = t2_nodes[0]["y"] + PRESETS["construction"]["tier2"]["height"] + tier_spacing

    t3_groups = []
    for gs in t3_specs:
        group = _build_group(gs, t3_y, group_config)
        t3_groups.append(group)
        nodes[group["id"]] = group
        groups.append(group)

        for dept in group["departments"]:
            nodes[dept["id"]] = dept
        for pos in group["positions"]:
            nodes[pos["id"]] = pos

    # Distribute groups horizontally
    group_widths = [g["width"] for g in t3_groups]
    g_xs = distribute_horizontally(group_widths, canvas_width, margin)
    for i, g in enumerate(t3_groups):
        dx = g_xs[i] - g["x"]
        g["x"] = g_xs[i]
        for d in g["departments"]:
            d["x"] += dx
            d["y"] = g["y"] + group_config["top"]
        for p in g["positions"]:
            p["x"] += dx
            p["y"] = d["y"] + PRESETS["construction"]["dept"]["height"] + group_config.get("dept_spacing", 17)

    # Tier2→Tier3 edges: management→group (with waypoints)
    tier2_bottom = t2_nodes[0]["y"] + PRESETS["construction"]["tier2"]["height"]
    tier3_top = t3_y
    y_hub = calc_y_hub(tier2_bottom, tier3_top)

    for tn in t2_nodes:
        for g in t3_groups:
            edges.append({
                "id": f'el-{tn["id"]}-{g["id"]}',
                "type": "group",
                "source": tn["id"],
                "target": g["id"],
                "style": _edge_style(),
                "waypoints": [
                    {"x": round(center_x(tn)), "y": round(y_hub)},
                    {"x": round(center_x(g)), "y": round(y_hub)},
                ],
                "y_hub": round(y_hub),
            })

    # --- Department→position edges (vertical, no waypoints) ---
    for gs in t3_specs:
        group_id = gs["id"]
        group_data = next(g for g in t3_groups if g["id"] == group_id)
        depts = group_data["departments"]
        positions = group_data["positions"]
        if len(positions) > 0 and len(depts) > 0:
            for di, dept in enumerate(depts):
                target_pos = positions[min(di, len(positions) - 1)]
                edges.append({
                    "id": f'ed-{dept["id"]}-{target_pos["id"]}',
                    "type": "vertical",
                    "source": dept["id"],
                    "target": target_pos["id"],
                    "style": _edge_style(),
                })

    # Compute canvas bounds
    canvas_height = max(
        nodes[nid]["y"] + nodes[nid].get("height", 0)
        for nid in nodes
        if isinstance(nodes[nid], dict) and "y" in nodes[nid] and "height" in nodes[nid]
    ) + margin

    return {
        "mode": "construction",
        "canvas": {"width": canvas_width, "height": canvas_height},
        "nodes": nodes,
        "edges": edges,
        "groups": groups,
        "tier2_bottom": tier2_bottom,
        "tier3_top": tier3_top,
        "y_hub_t2_t3": round(y_hub),
    }


def calc_simple_layout(spec):
    """Compute traditional tree org chart layout."""
    margin = spec.get("margin", 40)
    tier_spacing = {"simple": 60, "standard": 70, "detailed": 80}.get(
        spec.get("complexity", "standard"), 70
    )
    canvas_width = spec.get("canvas_width", 800)

    nodes = {}
    edges = []

    root_spec = spec.get("root", {"id": "ceo", "label": "CEO"})
    root = dict(PRESETS["simple"]["root"])
    root["id"] = root_spec["id"]
    root["label"] = root_spec.get("label", root_spec["id"])
    root["x"] = round((canvas_width - root["width"]) / 2)
    root["y"] = margin
    nodes[root["id"]] = root

    children_spec = spec.get("children", [
        {"id": "cto", "label": "CTO", "parent": "ceo"},
        {"id": "cfo", "label": "CFO", "parent": "ceo"},
    ])
    child_widths = []
    for ch in children_spec:
        cw = ch.get("width", PRESETS["simple"]["child"]["width"])
        child_widths.append(cw)

    child_xs = distribute_horizontally(child_widths, canvas_width, margin)
    child_y = root["y"] + root["height"] + tier_spacing

    for i, ch in enumerate(children_spec):
        node = dict(PRESETS["simple"]["child"])
        node["id"] = ch["id"]
        node["label"] = ch.get("label", ch["id"])
        node["width"] = ch.get("width", PRESETS["simple"]["child"]["width"])
        node["x"] = child_xs[i]
        node["y"] = child_y
        nodes[node["id"]] = node

        # Edge from root or parent
        parent_id = ch.get("parent", root["id"])
        edges.append({
            "id": f'ed-{parent_id}-{node["id"]}',
            "type": "vertical",
            "source": parent_id,
            "target": node["id"],
            "style": _edge_style(),
        })

    # Optional leaves
    leaves_spec = spec.get("leaves", [])
    if leaves_spec:
        leaf_y = child_y + PRESETS["simple"]["child"]["height"] + tier_spacing
        for li, leaf in enumerate(leaves_spec):
            node = dict(PRESETS["simple"]["leaf"])
            node["id"] = leaf["id"]
            node["label"] = leaf.get("label", leaf["id"])
            leaf_x = child_xs[li % len(child_xs)] if child_xs else margin + li * 140
            node["x"] = leaf_x
            node["y"] = leaf_y
            nodes[node["id"]] = node
            edges.append({
                "id": f'ed-{leaf.get("parent", children_spec[0]["id"])}-{node["id"]}',
                "type": "vertical",
                "source": leaf.get("parent", children_spec[0]["id"]),
                "target": node["id"],
                "style": _edge_style(),
            })

    canvas_height = max(n["y"] + n["height"] for n in nodes.values()) + margin

    return {
        "mode": "simple",
        "canvas": {"width": canvas_width, "height": canvas_height},
        "nodes": nodes,
        "edges": edges,
    }


def _edge_style():
    """Standard org chart edge style."""
    return ("edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;"
            "exitX=0.5;exitY=1;exitDx=0;exitDy=0;"
            "entryX=0.5;entryY=0;entryDx=0;entryDy=0;")


def _build_group(gs, t3_y, pad):
    """Build a single group container with its child nodes."""
    dept_w = PRESETS["construction"]["dept"]["width"]
    dept_h = PRESETS["construction"]["dept"]["height"]
    pos_w = PRESETS["construction"]["pos"]["width"]
    pos_h = PRESETS["construction"]["pos"]["height"]

    depts = gs.get("departments", [])
    positions = gs.get("positions", [])

    # Group width: accommodate max(dept columns, pos columns)
    max_cols = max(len(depts), len(positions))
    group_width = (pad["left"] + max_cols * dept_w +
                   max(0, max_cols - 1) * pad.get("inter_col_spacing", 30) +
                   pad["right"])

    group_height = (pad["top"] + dept_h +
                    pad.get("dept_spacing", 17) + pos_h +
                    pad["bottom"])

    group = {
        "id": gs["id"],
        "label": gs["label"],
        "x": 0,  # placeholder, will be distributed horizontally later
        "y": t3_y,
        "width": group_width,
        "height": group_height,
        "style": ("rounded=0;whiteSpace=wrap;html=1;dashed=1;"
                  "fillColor=#f0e6f6;strokeColor=#9673a6;"
                  "verticalAlign=top;spacingTop=5;"
                  "fontSize=13;fontStyle=1;fontFamily=Microsoft YaHei;"),
        "departments": [],
        "positions": [],
    }

    # Department nodes inside group
    for di, dspec in enumerate(depts):
        dept = dict(PRESETS["construction"]["dept"])
        dept["id"] = dspec["id"]
        dept["label"] = dspec.get("label", dspec["id"])
        dept["x"] = pad["left"] + di * (dept_w + pad.get("inter_col_spacing", 30))
        dept["y"] = 0  # relative; will be offset to group position
        group["departments"].append(dept)

    # Position nodes inside group
    for pi, pspec in enumerate(positions):
        pos = dict(PRESETS["construction"]["pos"])
        pos["id"] = pspec["id"]
        pos["label"] = pspec.get("label", pspec["id"])
        pos["x"] = pad["left"] + pi * (pos_w + pad.get("inter_col_spacing", 30))
        pos["y"] = 0  # relative; will be offset
        group["positions"].append(pos)

    return group


def validate(result):
    """Validate output against forbidden patterns."""
    issues = []
    for edge in result.get("edges", []):
        style = edge.get("style", "")
        if "rounded=1" in style:
            issues.append(f'{edge["id"]}: rounded=1 forbidden on org chart edges')

    # All group edges must share same y_hub
    group_edges = [e for e in result.get("edges", []) if e.get("type") == "group"]
    if group_edges:
        y_hubs = {e.get("y_hub") for e in group_edges if e.get("y_hub") is not None}
        if len(y_hubs) > 1:
            issues.append(f'Group edges have mismatched y_hub values: {y_hubs}')

    # Vertical edges must not have waypoints
    for e in result.get("edges", []):
        if e.get("type") == "vertical" and e.get("waypoints"):
            issues.append(f'{e["id"]}: vertical edge should not have waypoints')

    return issues


def main():
    parser = argparse.ArgumentParser(description="Org chart coordinate calculator")
    parser.add_argument("--mode", choices=["simple", "construction"], default="simple",
                        help="Layout mode (default: simple)")
    parser.add_argument("--file", type=str, default=None,
                        help="Read spec from JSON file instead of stdin")
    args = parser.parse_args()

    # Read input
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            spec = json.load(f)
    else:
        spec = json.load(sys.stdin)

    # Compute
    if args.mode == "construction":
        result = calc_construction_layout(spec)
    else:
        result = calc_simple_layout(spec)

    # Validate
    issues = validate(result)
    if issues:
        result["validation_warnings"] = issues

    # Output
    json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
    print()  # trailing newline


if __name__ == "__main__":
    main()
