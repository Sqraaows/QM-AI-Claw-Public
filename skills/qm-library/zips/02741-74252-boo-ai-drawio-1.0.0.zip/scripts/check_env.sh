#!/usr/bin/env bash
# draw.io 环境检测与安装脚本
# 用法: bash check_env.sh [--install]
#
# 检测当前运行环境（WSL2 / Git Bash / macOS / Linux / Windows），
# 检查 draw.io 是否已安装，可选自动安装。

set -euo pipefail

INSTALL_MODE=false
if [[ "${1:-}" == "--install" ]]; then
  INSTALL_MODE=true
fi

echo "=== draw.io 环境检测 ==="
echo ""

# ---- 检测环境类型 ----
detect_environment() {
  local ENV="unknown"

  # 检查 WSL2
  if grep -qi microsoft /proc/version 2>/dev/null; then
    ENV="wsl2"
  fi

  # 检查 MSYS2 / Git Bash
  if [[ -n "${MSYSTEM:-}" ]]; then
    ENV="gitbash"
  fi

  # 检查 macOS
  if [[ "$(uname -s)" == "Darwin" ]]; then
    ENV="macos"
  fi

  # 检查 Linux
  if [[ "$(uname -s)" == "Linux" && "$ENV" != "wsl2" ]]; then
    ENV="linux"
  fi

  # Windows (非 Unix shell)
  if [[ -n "${COMSPEC:-}" && "$ENV" == "unknown" ]]; then
    ENV="windows"
  fi

  echo "$ENV"
}

ENV=$(detect_environment)
echo "检测到环境: $ENV"
echo "BASH_VERSION: ${BASH_VERSION:-N/A}"
echo "MSYSTEM: ${MSYSTEM:-N/A}"
echo ""

# ---- 查找 draw.io 可执行文件 ----
find_drawio() {
  case "$ENV" in
    gitbash)
      if ls "/c/Program Files/draw.io/draw.io.exe" 2>/dev/null; then
        echo "/c/Program Files/draw.io/draw.io.exe"
      elif ls "$LOCALAPPDATA/Programs/draw.io/draw.io.exe" 2>/dev/null; then
        echo "$LOCALAPPDATA/Programs/draw.io/draw.io.exe"
      fi
      ;;
    wsl2)
      if ls "/mnt/c/Program Files/draw.io/draw.io.exe" 2>/dev/null; then
        echo "/mnt/c/Program Files/draw.io/draw.io.exe"
      fi
      ;;
    macos)
      if ls /Applications/draw.io.app/Contents/MacOS/draw.io 2>/dev/null; then
        echo "/Applications/draw.io.app/Contents/MacOS/draw.io"
      fi
      ;;
    linux)
      command -v drawio 2>/dev/null || echo ""
      ;;
    windows)
      if [[ -f "C:\\Program Files\\draw.io\\draw.io.exe" ]]; then
        echo "C:\\Program Files\\draw.io\\draw.io.exe"
      fi
      ;;
  esac
}

DRAWIO_PATH=$(find_drawio || echo "")

if [[ -n "$DRAWIO_PATH" ]]; then
  echo "draw.io 可执行文件: $DRAWIO_PATH"
else
  echo "draw.io: 未安装"
fi
echo ""

# ---- 安装 ----
if [[ "$INSTALL_MODE" == "true" && -z "$DRAWIO_PATH" ]]; then
  echo "=== 尝试安装 draw.io ==="
  case "$ENV" in
    gitbash|wsl2|windows)
      echo "使用 winget 安装..."
      winget install --id JGraph.Draw --accept-source-agreements --accept-package-agreements
      ;;
    macos)
      echo "使用 Homebrew 安装..."
      brew install --cask drawio
      ;;
    linux)
      echo "使用 snap 安装..."
      sudo snap install drawio
      ;;
    *)
      echo "未知环境，请手动安装 draw.io"
      echo "下载: https://www.drawio.com/"
      ;;
  esac

  echo ""
  echo "重新检测..."
  DRAWIO_PATH=$(find_drawio || echo "")
  if [[ -n "$DRAWIO_PATH" ]]; then
    echo "安装成功: $DRAWIO_PATH"
  else
    echo "安装可能未完成，请手动验证。"
  fi
fi

# ---- 输出结果 ----
echo "=== 检测结果 ==="
echo "环境: $ENV"
echo "draw.io: ${DRAWIO_PATH:-未找到}"
echo ""
echo "如需安装，运行: bash check_env.sh --install"
