# Jimeng AI · `submit_marketing_video_agent`

Submit a Lilinque Marketing Video Agent async task.

- **Service**: `jimeng_ai`
- **Action**: `submit_marketing_video_agent`
- **Action id**: `jimeng_ai.submit_marketing_video_agent`

## Inspect the schema

Always fetch the authoritative input/output schema before building a payload — fields and defaults can change upstream:

```bash
oo connector schema "jimeng_ai" --action "submit_marketing_video_agent"
```

## Run

```bash
oo connector run "jimeng_ai" --action "submit_marketing_video_agent" --data '{}' --json
```

Replace `{}` with a JSON object that matches the input schema. The response is `{ "data": ..., "meta": { "executionId": "..." } }`.

> **Write action.** This changes Jimeng AI state. Confirm the exact payload and intended effect with the user before running.
