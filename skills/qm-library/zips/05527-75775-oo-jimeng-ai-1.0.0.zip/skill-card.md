## Description: <br>
Jimeng AI helps an agent operate Jimeng AI through an OOMOL-connected account, including async image generation, text-to-image, video generation, image-to-video, Smart Upscale, Smart Video Agent, and Marketing Video Agent workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Use this skill when a user wants an agent to submit Jimeng AI media-generation or enhancement jobs, retrieve async job results, or prepare connector payloads from the live OOMOL connector schema. <br>

### Deployment Geography for Use: <br>
Global use where ClawHub, OOMOL, and Jimeng AI or Volcengine services are available, subject to the user's account, connection, billing, and local compliance requirements. <br>

## Known Risks and Mitigations: <br>
Risk: Submission actions can change Jimeng AI state and may consume account credits. <br>
Mitigation: Review the selected action, JSON payload, and expected effect with the user before running write actions. <br>
Risk: The skill relies on the OOMOL oo CLI and the user's connected Jimeng AI account. <br>
Mitigation: Install and use it only when the publisher, CLI, account connection, and required billing status are trusted. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-jimeng-ai) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Jimeng AI homepage](https://www.volcengine.com/product/jimeng) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions, oo connector CLI commands, JSON payload guidance, and JSON connector responses for async task submission and result retrieval.] <br>
**Output Parameters:** [Connector action name, live schema-derived JSON data, and task identifiers or execution IDs for result polling.] <br>
**Other Properties Related to Output:** [Supports 28 Jimeng AI connector actions across image generation, text-to-image, video generation, image-to-video, Smart Upscale, and video-agent workflows.] <br>

## Skill Version(s): <br>
1.0.0 <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
