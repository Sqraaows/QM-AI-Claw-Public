## Description: <br>
IP2Proxy helps agents check whether an IPv4 or IPv6 address is associated with proxy usage through an OOMOL-connected IP2Proxy account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect a single IP address for proxy association using the IP2Proxy service without handling raw API keys directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected IP2Proxy API key and account context. <br>
Mitigation: Confirm trust in OOMOL and approve first-time CLI installation, login, or connection setup before use. <br>
Risk: Lookup commands may submit IP addresses to the connected IP2Proxy service. <br>
Mitigation: Run lookups only for IP addresses the user intends to check. <br>
Risk: Billing or account status can stop lookups from completing. <br>
Mitigation: If the service reports insufficient credit or expired credentials, resolve account billing or reconnection before retrying. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ip2proxy) <br>
- [IP2Proxy web service](https://www.ip2location.com/web-service/ip2proxy) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [IP2Proxy connection setup](https://console.oomol.com/app-connections?provider=ip2proxy) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON API responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The action returns the official IP2Proxy lookup payload with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
