## Description: <br>
Agenty lets an agent operate an OOMOL-connected Agenty account to read, create, update, delete, download, and run Agenty resources. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Agenty agents, jobs, job outputs, list data, web capture utilities, and structured extraction through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate an Agenty account through OOMOL using sensitive connected credentials. <br>
Mitigation: Install only for agents that should access Agenty, and use an Agenty API key with the minimum scopes needed for the intended work. <br>
Risk: Write, delete, download, and job-start actions can change account state, remove data, export data, or consume service resources. <br>
Mitigation: Review the exact action, target, and payload before approval, and require explicit confirmation for destructive operations. <br>


## Reference(s): <br>
- [Agenty homepage](https://agenty.com) <br>
- [Agenty skill on ClawHub](https://clawhub.ai/oomol/oo-agenty) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Files, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON responses from the connector] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return downloadable job files, raw text exports, screenshots, PDFs, rendered page content, redirects, structured metadata, logs, and paginated result rows.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
