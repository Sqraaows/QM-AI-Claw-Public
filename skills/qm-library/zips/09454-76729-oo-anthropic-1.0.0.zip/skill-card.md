## Description: <br>
Use Anthropic through an OOMOL-connected account to list models, inspect model metadata, count message tokens, and create non-streaming messages. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill when they need account-backed Anthropic API actions through OOMOL, including model discovery, token counting, and non-streaming message creation. It is intended for users who have installed the oo CLI, signed in, and connected Anthropic. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill routes Anthropic actions through a connected OOMOL account, which may be inappropriate for general Anthropic questions or direct API use. <br>
Mitigation: Install and invoke it only when the user intends to use OOMOL as the intermediary for account-backed Anthropic API actions. <br>
Risk: The create_message action sends a non-streaming Anthropic message and can consume account resources or produce unintended outputs. <br>
Mitigation: Review the exact payload and intended effect with the user before running create_message. <br>
Risk: The first-time setup instructions include a remote installer command. <br>
Mitigation: Prefer a verified or manually inspected oo CLI installation path instead of piping a remote installer directly into the shell. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-anthropic) <br>
- [Anthropic homepage](https://www.anthropic.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses oo CLI connector actions; responses are JSON with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
