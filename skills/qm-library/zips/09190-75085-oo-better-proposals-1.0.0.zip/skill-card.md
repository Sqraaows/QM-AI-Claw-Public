## Description: <br>
Operates Better Proposals through an OOMOL-connected account so an agent can read proposal, quote, company, template, currency, settings, and brand data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external operators, and developers use this skill to inspect Better Proposals business data through an OOMOL-connected account. It supports proposal, quote, company, template, currency, document type, merge tag, account settings, and brand settings lookup workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to Better Proposals business data through a connected OOMOL account. <br>
Mitigation: Install only when that account access is intended, and review requested action payloads before execution. <br>
Risk: Future create, update, send, post, delete, or remove actions could change or destroy Better Proposals data. <br>
Mitigation: Require explicit user confirmation for any state-changing or destructive action before running it. <br>


## Reference(s): <br>
- [Better Proposals homepage](https://betterproposals.io) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-better-proposals) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, JSON, Configuration guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Reads data through the connected OOMOL account and returns connector responses under data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: SKILL.md frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
