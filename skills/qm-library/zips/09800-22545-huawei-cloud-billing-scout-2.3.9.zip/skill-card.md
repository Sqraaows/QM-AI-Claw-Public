## Description: <br>
Guides agents through read-only Huawei Cloud BSS billing checks for balances, spend, charge attribution, reconciliation, coupons, stored-value cards, and enterprise or partner billing using hcloud. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[agenticweb4](https://clawhub.ai/user/agenticweb4) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to investigate Huawei Cloud billing questions in a read-only posture, including current balances, monthly spend, charge causes, reconciliation gaps, coupons, stored-value cards, and enterprise or partner billing scope. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Huawei Cloud AK/SK credentials or account identifiers could be exposed in chat, logs, or generated output. <br>
Mitigation: Use a local hcloud profile or environment variables outside chat, avoid pasting AK/SK into conversations, and redact long account, customer, resource, order, transaction, coupon, card, and partner identifiers. <br>
Risk: Billing conclusions could be overstated when based on paginated, sampled, partial, or locally scoped BSS evidence. <br>
Mitigation: State the scope, billing period, money basis, and evidence gaps explicitly; do not generalize partial results to whole-account, full-month, or final-settlement conclusions. <br>
Risk: A user could grant broader Huawei Cloud permissions than needed for billing review. <br>
Mitigation: Use a least-privilege IAM user with BSS read-only permissions and refuse payment, renewal, refund, deletion, recovery, creation, update, verification-code, balance-change, or resource-changing actions. <br>
Risk: Manual KooCLI installation commands could be run without reviewing the downloaded installer or package source. <br>
Mitigation: Only perform lightweight readiness checks such as hcloud version and hcloud configure list automatically; users should review install commands and downloaded scripts before running them. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/agenticweb4/huawei-cloud-billing-scout) <br>
- [Skill homepage](https://github.com/ontology-of-everything/SemanticSkills/tree/main/skills/huawei-cloud-billing-scout) <br>
- [KooCLI installation guide](references/cli-installation.md) <br>
- [IAM least-privilege guidance](references/iam-policies.md) <br>
- [BSS command contracts](references/related-commands.md) <br>
- [Billing route catalog](references/semantic/catalog.yml) <br>
- [Billing ontology](references/semantic/billing-ontology.yml) <br>
- [Huawei Cloud KooCLI quick installation](https://support.huaweicloud.com/qs-hcli/hcli_02_003.html) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Concise Markdown briefing with scoped findings, evidence gaps, and occasional inline shell command or configuration guidance.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only billing evidence only; avoids raw responses, full identifiers, credentials, profile, and region in user-facing output.] <br>

## Skill Version(s): <br>
2.3.9 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
