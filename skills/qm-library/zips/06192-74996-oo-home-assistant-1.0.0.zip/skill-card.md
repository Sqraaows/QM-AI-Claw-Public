## Description: <br>
Connects an agent to Home Assistant through OOMOL's home_assistant connector to inspect configuration, states, events, and services, render templates, and run confirmed control actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to inspect a connected Home Assistant instance and operate its entities through the OOMOL home_assistant connector. It supports configuration, state, event, service, template, and controlled state-changing workflows when the user has connected an appropriate Home Assistant account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can control Home Assistant devices and fire events, even though its summary emphasizes read and search tasks. <br>
Mitigation: Require explicit user confirmation before service calls, event firing, or any other state-changing action. <br>
Risk: A connected Home Assistant account may have access to sensitive devices such as locks, alarms, doors, or appliances. <br>
Mitigation: Use an OOMOL/Home Assistant account with permissions the user is comfortable granting, and review the target entity, service, and payload before execution. <br>


## Reference(s): <br>
- [Home Assistant homepage](https://www.home-assistant.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-home-assistant) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands call the OOMOL oo CLI and return JSON responses from the connected Home Assistant instance.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
