## Description: <br>
IPinfo lets an agent query IPinfo through an OOMOL-connected account for IP lookup, geolocation, enrichment, batch lookup, mapping, and token metadata workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and support operators use this skill to retrieve IPinfo data through OOMOL, including current or specified IP details, geolocation, ASN and organization data, privacy and carrier enrichment, abuse contacts, token metadata, and batch or map outputs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Actions that use the caller's current IP can expose location-related IP metadata. <br>
Mitigation: Confirm the user intends to run current-IP actions before executing them. <br>
Risk: The token metadata action may reveal account or usage information for the connected IPinfo token. <br>
Mitigation: Run token metadata lookups only when the user asks for account or usage details. <br>
Risk: The mapping action can upload large IP lists to generate a report URL. <br>
Mitigation: Confirm the exact IP list and purpose before running mapping actions. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-ipinfo-io) <br>
- [IPinfo Homepage](https://ipinfo.io) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON-oriented command outputs] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses OOMOL-connected IPinfo credentials and returns data according to the live connector action schema.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
