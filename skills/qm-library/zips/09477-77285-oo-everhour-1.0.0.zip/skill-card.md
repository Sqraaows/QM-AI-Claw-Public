## Description: <br>
Operate Everhour through an OOMOL-connected account to read, create, and update time-tracking data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external teams, and agents use this skill to read Everhour users, projects, tasks, timers, and time records, and to create or change time-tracking entries through an OOMOL-connected Everhour account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Everhour account and OOMOL-brokered credential access. <br>
Mitigation: Install only when the user trusts OOMOL to broker access and has reviewed the Everhour scopes on the OOMOL connection. <br>
Risk: Write actions can change time-tracking records or timer state. <br>
Mitigation: Confirm the exact create_time_record, start_timer, or stop_timer payload and intended effect with the user before execution. <br>


## Reference(s): <br>
- [Everhour homepage](https://everhour.com) <br>
- [Everhour skill on ClawHub](https://clawhub.ai/oomol/oo-everhour) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs agents to inspect each live connector schema before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
