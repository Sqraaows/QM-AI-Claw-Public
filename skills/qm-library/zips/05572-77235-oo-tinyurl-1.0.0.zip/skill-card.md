## Description: <br>
TinyURL lets an agent list existing TinyURLs and create new short links through an OOMOL-connected TinyURL account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents use this skill to operate TinyURL for marketing and link-management workflows, including listing account URLs and creating a short link for a destination URL. It is intended for users who have connected TinyURL through OOMOL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive account credentials through the OOMOL connector layer. <br>
Mitigation: Use only the TinyURL permissions needed for the workflow and review the OOMOL CLI installer before running it. <br>
Risk: Creating a short link changes TinyURL account state and could publish an unintended destination. <br>
Mitigation: Confirm the exact destination URL and intended effect before running create_short_url. <br>


## Reference(s): <br>
- [ClawHub TinyURL skill page](https://clawhub.ai/oomol/oo-tinyurl) <br>
- [TinyURL homepage](https://tinyurl.com) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI session and a connected TinyURL account before actions can run.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
