## Description: <br>
This skill helps agents read, create, and update Google Slides presentations through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to retrieve Google Slides presentation data, create presentations, copy templates, generate page thumbnails, and apply structured batch updates through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Write actions can create or modify Google Slides presentations. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create, copy, or batch update actions. <br>
Risk: The skill depends on an authenticated OOMOL-connected Google Slides account. <br>
Mitigation: Use the existing connection when available and avoid requesting raw credentials or granting write access unless the user has approved the action. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-googleslides) <br>
- [Google Slides homepage](https://workspace.google.com/products/slides/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Shell commands, Guidance, Configuration] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses from the googleslides connector when run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
