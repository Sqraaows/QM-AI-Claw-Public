## Description: <br>
Kit connector skill for reading, creating, and updating Kit account data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Kit marketing and subscriber workflows through the oo CLI, including account lookup, subscriber reads, form and tag lists, and subscriber create or update actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a Kit account through OOMOL and can read subscriber and account data. <br>
Mitigation: Install it only when agent access to the connected Kit account is intended, and keep credentials managed through the OOMOL connection rather than exposing raw tokens. <br>
Risk: The create_subscriber and update_subscriber actions can change Kit subscriber records. <br>
Mitigation: Inspect the live connector schema and confirm the exact payload and expected effect with the user before running write actions. <br>
Risk: First-time setup may require installing or logging into the oo CLI. <br>
Mitigation: Run install, login, or connection steps only after a matching setup or authentication failure, and use trusted OOMOL sources. <br>


## Reference(s): <br>
- [ClawHub Kit skill](https://clawhub.ai/oomol/oo-kit) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Kit homepage](https://kit.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, JSON, guidance] <br>
**Output Format:** [Markdown instructions with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
