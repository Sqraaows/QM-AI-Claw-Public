## Description: <br>
Operate OpenAI through an OOMOL-connected account using the oo CLI for reading, creating, and updating OpenAI resources without handling raw tokens locally. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect OpenAI connector schemas and run OpenAI actions for responses, embeddings, image generation, moderation, audio, batches, models, stored responses, input items, and token counting through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected OpenAI account and may run actions that create or change OpenAI resources. <br>
Mitigation: Confirm trust in the publisher, inspect the live connector schema, and review the exact payload and effect before running write actions. <br>
Risk: Some OpenAI actions may create billable usage or depend on account scopes, active credentials, and billing status. <br>
Mitigation: Use the documented setup and troubleshooting flow only when commands fail for authentication, connection scope, credential, or billing reasons. <br>


## Reference(s): <br>
- [OpenAI API](https://openai.com/api/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-openai) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action execution; command responses are JSON from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
