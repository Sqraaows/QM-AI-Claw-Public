## Description: <br>
RenderForm lets an agent inspect templates, render images or PDFs, capture website screenshots, list generated results, and check credit usage through an OOMOL-connected RenderForm account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users can use this skill to operate RenderForm from an agent session after the oo CLI is installed, the user is signed in, and RenderForm is connected. It supports template discovery, image or PDF rendering, website screenshot capture, generated-result lookup, and credit-usage checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create rendered outputs or website screenshots, which may consume credits or produce files from user-provided content. <br>
Mitigation: Confirm the intended payload and effect with the user before billable rendering or screenshot capture. <br>
Risk: Screenshots or generated outputs may include private or sensitive information from pages, templates, or payload data. <br>
Mitigation: Avoid using the skill on sensitive pages or data unless the user explicitly approves the content and destination. <br>
Risk: The skill requires a connected RenderForm account and may fail when credentials, scopes, or account credits are missing. <br>
Mitigation: Run setup or billing steps only after the relevant command fails with an authentication, scope, connection, or credit error. <br>


## Reference(s): <br>
- [RenderForm homepage](https://renderform.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [RenderForm ClawHub listing](https://clawhub.ai/oomol/oo-renderform) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Files, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs may include RenderForm request identifiers, file URLs, echoed requests, template details, result listings, and credit-usage summaries.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
