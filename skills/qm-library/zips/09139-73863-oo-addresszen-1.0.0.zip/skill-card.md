## Description: <br>
AddressZen helps agents search address suggestions and retrieve AddressZen address data through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to operate AddressZen through an OOMOL-connected account for address autocomplete, key availability checks, and USA address retrieval. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected AddressZen account. <br>
Mitigation: Use the OOMOL connection flow and avoid handling raw tokens; run sign-in or connection setup only when an auth or connection error requires it. <br>
Risk: The oo CLI installer may be invoked with curl-to-bash during first-time setup. <br>
Mitigation: Inspect the installer first or install the CLI from a trusted package/source before running connector commands. <br>
Risk: The skill may activate on broad AddressZen-related requests. <br>
Mitigation: Confirm the user's intent is AddressZen automation before running connector actions, and fetch the live action schema before constructing payloads. <br>


## Reference(s): <br>
- [ClawHub AddressZen release](https://clawhub.ai/oomol/oo-addresszen) <br>
- [AddressZen homepage](https://addresszen.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [find_address action](actions/find_address.md) <br>
- [get_key_availability action](actions/get_key_availability.md) <br>
- [retrieve_address_usa action](actions/retrieve_address_usa.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before building JSON payloads and returns AddressZen response data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact metadata and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
