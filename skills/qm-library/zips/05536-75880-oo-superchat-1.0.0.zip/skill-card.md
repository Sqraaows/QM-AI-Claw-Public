## Description: <br>
Superchat (superchat.com) lets an agent read, create, and update Superchat data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and business teams use this skill to let an agent manage Superchat workspace contacts, channels, authenticated user lookup, and outbound email, text, or WhatsApp template messages through the OOMOL connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected Superchat workspace through OOMOL. <br>
Mitigation: Install and use it only when the user intends to grant an agent access to that workspace, and only run CLI setup or login steps when connector commands fail for authentication or connection reasons. <br>
Risk: Create, update, and message-sending actions can change Superchat state or send outbound communications. <br>
Mitigation: Review and confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: Live connector schemas and upstream defaults can change. <br>
Mitigation: Inspect the authoritative connector schema before constructing action payloads. <br>


## Reference(s): <br>
- [Superchat homepage](https://www.superchat.com) <br>
- [ClawHub Superchat skill](https://clawhub.ai/oomol/oo-superchat) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads for oo CLI connector actions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to inspect live connector schemas before building payloads and to return connector responses as JSON when actions are run.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
