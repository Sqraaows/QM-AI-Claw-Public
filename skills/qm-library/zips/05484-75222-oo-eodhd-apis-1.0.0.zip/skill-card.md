## Description: <br>
EODHD APIs (eodhd.com). Use this skill for EODHD API requests involving search and read access to financial market data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to query EODHD financial market data through an OOMOL-connected account, including end-of-day prices, delayed quotes, instrument search, exchange discovery, identifier mapping, macro indicators, US Treasury yield rates, and authenticated account usage details. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected EODHD/OOMOL account and requires sensitive credentials handled by the connector. <br>
Mitigation: Connect only the intended account, rely on the connector credential flow, and avoid exposing raw API tokens in prompts, files, or logs. <br>
Risk: Connector calls may consume paid EODHD or OOMOL API credits. <br>
Mitigation: Inspect schemas before running actions, keep payloads targeted, and monitor account or API-usage details when cost matters. <br>
Risk: The account information action can retrieve authenticated account and API-usage details. <br>
Mitigation: Treat returned account details as sensitive and share or persist them only when necessary for the user task. <br>
Risk: Installing or running an untrusted oo CLI could expose connector workflows to local tooling risk. <br>
Mitigation: Install the oo CLI only from trusted OOMOL sources and keep the local toolchain under normal endpoint security controls. <br>


## Reference(s): <br>
- [EODHD APIs homepage](https://eodhd.com) <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-eodhd-apis) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Runs read-oriented connector actions that return JSON data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
