## Description: <br>
Buy and sell NFTs on OpenSea's Seaport marketplace, including listing fulfillment, offer acceptance, new order creation, cross-chain purchases, and listing sweeps. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[opensea](https://clawhub.ai/user/opensea) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to prepare and execute OpenSea marketplace workflows that buy, sell, create, or fulfill NFT orders. It is intended for tasks that require OpenSea API access plus wallet-signing authority, with read-only discovery delegated to opensea-api. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Marketplace and swaps workflows can grant an agent wallet-signing authority and purchase capability. <br>
Mitigation: Prefer managed wallet providers with spending caps and allowlists, avoid raw private keys, and verify fulfillment data before signing. <br>
Risk: The bundled API sub-skill includes transaction-building and arbitrary POST capability, so it is not strictly read-only in every path. <br>
Mitigation: Limit the active sub-skill to the task at hand and review POST requests, order data, recipient addresses, values, and calldata before execution. <br>
Risk: OpenSea API keys may be cached locally for reuse. <br>
Mitigation: Check or remove ~/.opensea/api_key when local persistence is not desired, and avoid logging API keys or wallet credentials. <br>


## Reference(s): <br>
- [OpenSea Marketplace Skill](artifact/opensea-marketplace/SKILL.md) <br>
- [Marketplace API Reference](artifact/opensea-marketplace/references/marketplace-api.md) <br>
- [Seaport Protocol Reference](artifact/opensea-marketplace/references/seaport.md) <br>
- [OpenSea Developer Docs](https://docs.opensea.io/) <br>
- [OpenSea Skill Homepage](https://github.com/ProjectOpenSea/opensea-skill) <br>
- [ClawHub Skill Listing](https://clawhub.ai/opensea/opensea-marketplace) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands, API request examples, configuration steps, and transaction-handling code snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce transaction data or signing instructions that require user review before wallet execution.] <br>

## Skill Version(s): <br>
2.14.0 (source: server release metadata, CHANGELOG, package.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
