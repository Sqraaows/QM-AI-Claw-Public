## Description: <br>
Elasticsearch (elastic.co). Use this skill for Elasticsearch requests that search, list, inspect, or check reachable Elasticsearch data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and data teams use this skill to let an agent inspect Elasticsearch connectivity, list accessible indices, retrieve index schema details, and run searches through the OOMOL connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and search Elasticsearch data visible to the connected OOMOL account. <br>
Mitigation: Install only for intended Elasticsearch access and connect credentials with the least privileges needed for the expected queries. <br>
Risk: First-time setup may require installing the oo CLI and authenticating an OOMOL account. <br>
Mitigation: Approve CLI installation and login deliberately, verify the OOMOL installer source, and run setup only after an auth or connection failure. <br>
Risk: Broad searches or incorrect payloads may return more Elasticsearch data than intended. <br>
Mitigation: Inspect the live connector schema before each action payload and use scoped indices, filters, pagination, and sorting where appropriate. <br>


## Reference(s): <br>
- [Elasticsearch homepage](https://www.elastic.co/elasticsearch) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-elasticsearch) <br>
- [get_index_schema action reference](actions/get_index_schema.md) <br>
- [list_indices action reference](actions/list_indices.md) <br>
- [ping_cluster action reference](actions/ping_cluster.md) <br>
- [query_index action reference](actions/query_index.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration guidance, JSON, Markdown] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to fetch live action schemas before constructing JSON payloads.] <br>

## Skill Version(s): <br>
1.0.1 (source: artifact metadata and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
