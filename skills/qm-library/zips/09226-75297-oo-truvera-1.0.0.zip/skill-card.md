## Description: <br>
Truvera helps an agent operate a user's Truvera account through OOMOL connector actions for DID, credential schema, account profile, and background job workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Truvera connector schemas, run read actions, and manage Truvera DIDs and credential schemas through an authenticated OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or delete Truvera DIDs and credential schemas, and those changes may be persistent or difficult to undo. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running create or delete actions. <br>
Risk: The skill operates through an authenticated Truvera account and requires sensitive credentials managed by the OOMOL connection. <br>
Mitigation: Install and use it only when the user intends to let an agent operate that Truvera account through OOMOL. <br>


## Reference(s): <br>
- [Truvera homepage](https://truvera.io) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-truvera) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId fields when actions are run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
