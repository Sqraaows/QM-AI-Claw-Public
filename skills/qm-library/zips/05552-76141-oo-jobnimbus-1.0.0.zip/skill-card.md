## Description: <br>
JobNimbus (jobnimbus.com). Use this skill for ANY JobNimbus request - reading, creating, and updating data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees and developers use this skill to operate JobNimbus through an OOMOL-connected account, including reading, listing, creating, and updating contacts and jobs. It is intended for workflows where an agent should use the oo CLI connector instead of calling the JobNimbus API directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access business and customer data in JobNimbus through an OOMOL-connected account. <br>
Mitigation: Install and connect it only for accounts where the agent is allowed to read that data. <br>
Risk: Create and update actions can change JobNimbus contacts and jobs. <br>
Mitigation: Review the exact action payload and intended effect with the user before approving any write action. <br>
Risk: Connector schemas and field defaults can change upstream. <br>
Mitigation: Fetch the live connector schema before building each payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-jobnimbus) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [JobNimbus Homepage](https://www.jobnimbus.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, JSON, guidance] <br>
**Output Format:** [Markdown instructions with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions should fetch the live connector schema before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
