## Description: <br>
This skill helps agents browse, quote, purchase, and manage Snaplii-funded gift cards and bill payments through the Snaplii CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[snapliiai](https://clawhub.ai/user/snapliiai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and their agents use this skill to browse gift card options, check Snaplii Cash balance, preview prices, buy gift cards, view owned gift cards, and make supported bill payments with explicit confirmation. <br>

### Deployment Geography for Use: <br>
Canada and United States <br>

## Known Risks and Mitigations: <br>
Risk: The skill handles a reusable Snaplii API key and can initiate real gift-card purchases and bill payments from the user's Snaplii Cash balance. <br>
Mitigation: Enter API keys only through the trusted CLI prompt, confirm merchant, biller, account, amount, province or state, and final cost before payment, and avoid automatic retries after payment failures. <br>
Risk: The security review found that bill-payment authority is broader than the headline gift-card description. <br>
Mitigation: Treat bill payment as a financial action requiring current-turn confirmation and verify biller, account, amount, quote, and available Snaplii Cash before running payment commands. <br>
Risk: Gift-card codes, PINs, barcode URLs, API keys, and access tokens can expose payment value or account access. <br>
Mitigation: Keep sensitive CLI output confidential, default to list-only gift-card views, and reveal redemption details only after the user explicitly asks for a specific card. <br>


## Reference(s): <br>
- [Snaplii AI Agent Cashback Payment on ClawHub](https://clawhub.ai/snapliiai/snaplii-a2m-payment) <br>
- [snaplii-cli on PyPI](https://pypi.org/project/snaplii-cli/) <br>
- [Snaplii App for iOS](https://apps.apple.com/app/snaplii/id1596924498) <br>
- [Snaplii App for Android](https://play.google.com/store/apps/details?id=com.snaplii.app) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and concise payment or card summaries] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include masked identifiers, balance and quote summaries, confirmation prompts, and sensitive redemption details only when explicitly requested.] <br>

## Skill Version(s): <br>
1.9.0 (source: server-resolved release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
