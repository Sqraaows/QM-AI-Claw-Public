## Description: <br>
Use this skill for Needle (needle.app) requests that read, create, and update data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Needle through an OOMOL-connected account, including collection discovery, collection creation, URL-backed file imports, collection file listing, statistics, and semantic search. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can use sensitive OOMOL-connected Needle credentials. <br>
Mitigation: Install and run it only when the agent should access the user's connected Needle account. <br>
Risk: Collection creation and file-import actions change Needle state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: First-time setup can invoke the oo CLI installer. <br>
Mitigation: Run the installer only after reviewing and trusting OOMOL's installer source and setup path. <br>


## Reference(s): <br>
- [Needle homepage](https://needle.app) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-needle) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands call the OOMOL oo CLI and return connector JSON responses when executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
