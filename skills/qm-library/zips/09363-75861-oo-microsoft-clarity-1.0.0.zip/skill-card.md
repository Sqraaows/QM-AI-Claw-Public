## Description: <br>
Microsoft Clarity connector skill for searching and reading Clarity data through an OOMOL-connected account instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents use this skill to inspect Microsoft Clarity connector schemas and export live Clarity insights from an OOMOL-connected account. It supports analytics requests that need recent live insights for the last 1 to 3 days, with optional breakdown dimensions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Microsoft Clarity account and may access sensitive analytics data. <br>
Mitigation: Install it only for intended Clarity use, connect only the intended account, and treat returned analytics as sensitive business data. <br>
Risk: First-time setup may require installing or authenticating the oo CLI. <br>
Mitigation: Review the oo CLI installer before setup and run authentication or connection steps only when command failures show they are needed. <br>
Risk: Connector action schemas can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each payload. <br>


## Reference(s): <br>
- [Microsoft Clarity homepage](https://clarity.microsoft.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-microsoft-clarity) <br>
- [export_live_insights action reference](actions/export_live_insights.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before execution so requests match the current action contract.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
