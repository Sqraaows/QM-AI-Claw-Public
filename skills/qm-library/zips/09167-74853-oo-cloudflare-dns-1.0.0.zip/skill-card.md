## Description: <br>
Cloudflare DNS helps agents read, create, update, and delete Cloudflare DNS zones and records through an OOMOL-connected Cloudflare account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to inspect Cloudflare zones and DNS records, then create, patch, or delete records through the OOMOL `cloudflare_dns` connector when DNS changes are needed. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The first-time setup path may execute a remote shell installer with local user privileges. <br>
Mitigation: Review the installer source before use and prefer a package manager, signed release, or checksum-verified download when available. <br>
Risk: Create and update actions can change live DNS records and affect service routing. <br>
Mitigation: Inspect the live connector schema, confirm the exact payload and intended effect with the user, and use least-privilege Cloudflare credentials. <br>
Risk: Delete actions can remove DNS records. <br>
Mitigation: Confirm the destructive target explicitly with the user before execution. <br>
Risk: The skill requires sensitive Cloudflare account access through an OOMOL connection. <br>
Mitigation: Keep credentials in the connected account flow, avoid exposing raw tokens in prompts or files, and rotate or revoke credentials if access is no longer needed. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-cloudflare-dns) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Cloudflare DNS Homepage](https://www.cloudflare.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing JSON payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
