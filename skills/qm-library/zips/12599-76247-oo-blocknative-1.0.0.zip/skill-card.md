## Description: <br>
Blocknative helps agents access Blocknative gas-price data through the OOMOL blocknative connector and oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to query Blocknative gas-price estimates, Ethereum mainnet gas-price distributions, gas-oracle metadata, and supported chains through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill documentation includes a curl-to-bash installer command for the oo CLI. <br>
Mitigation: Prefer the official install guide, inspect the installer, verify the source, and run it only if OOMOL is trusted and the oo CLI is needed. <br>
Risk: The skill requires a connected Blocknative account and sensitive credentials managed through OOMOL. <br>
Mitigation: Use the server-side OOMOL connection flow, avoid handling raw tokens directly, and reconnect only when commands report authentication or scope errors. <br>


## Reference(s): <br>
- [ClawHub Blocknative skill page](https://clawhub.ai/oomol/oo-blocknative) <br>
- [Blocknative homepage](https://www.blocknative.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command output from the oo CLI.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are described as JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release.version and SKILL.md metadata.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
