## Description: <br>
Use ngrok through an OOMOL-connected account to read endpoints, tunnels, tunnel sessions, and reserved domains with the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect ngrok account resources through the OOMOL ngrok connector. It helps an agent retrieve active endpoints, online tunnels, tunnel sessions, and reserved domains after checking the live connector schema. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill reads resources from the connected ngrok account. <br>
Mitigation: Install and invoke it only when the agent should access ngrok resources through the OOMOL-connected account, and confirm ambiguous ngrok requests before running connector actions. <br>
Risk: Future connector actions could add mutation capability beyond the current read-only action set. <br>
Mitigation: Review the available action list and require explicit user approval before any create, update, post, send, delete, or remove action is run. <br>
Risk: Connector schemas and upstream fields can change. <br>
Mitigation: Fetch the live oo connector schema before constructing a payload for each action. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ngrok) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [ngrok homepage](https://ngrok.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector calls return JSON with data and meta.executionId when run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
