## Description: <br>
Monday (monday.com). Use this skill for ANY Monday request: reading, creating, updating, and deleting Monday data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, operators, and developers use this skill to let an agent read and manage Monday boards, items, subitems, groups, columns, workspaces, users, teams, departments, dashboards, docs, forms, updates, assets, activity logs, and audit logs through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, archive, delete, move, and otherwise change Monday account data. <br>
Mitigation: Confirm the exact target, action, and payload with the user before running any state-changing action. <br>
Risk: Destructive actions can remove or overwrite boards, items, docs, dashboards, departments, groups, columns, updates, subscribers, or teams. <br>
Mitigation: Require explicit approval for destructive actions and restate the affected Monday object before execution. <br>
Risk: Read-only actions may expose private business data, including account-level audit logs on enterprise accounts. <br>
Mitigation: Run read actions only for the user's stated task and avoid exposing unnecessary returned data. <br>
Risk: The skill requires sensitive account access through the oo CLI and OOMOL-connected Monday credentials. <br>
Mitigation: Install and use it only when the user trusts OOMOL and has intentionally connected the relevant Monday account. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-monday) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [Monday homepage](https://monday.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action results are returned by the oo CLI as JSON with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
