---
name: fund-correlation-tool
description: 基金相关性分析工具 - 计算多只国内基金之间的皮尔逊相关系数，支持3/6/12个月时间跨度，输出CSV和HTML可视化报告
version: 1.0.0
metadata:
  openclaw:
    requires:
      bins:
        - python
    envVars:
      - name: PYTHONIOENCODING
        required: false
        description: Python输出编码，建议设置为utf-8
    emoji: "📊"
    homepage: https://github.com/workbuddy/fund-correlation-tool
---

# 基金相关性分析工具 (Fund Correlation Tool)

基于 AkShare 双接口方案，支持计算国内所有类型基金的历史相关性分析。

## 功能特性

- **双接口数据源**：结合天天基金网基金名称接口 + AkShare历史净值接口
- **全类型支持**：ETF、开放式基金、LOF、QDII、货币基金、债券基金等
- **灵活时间跨度**：3个月 / 6个月 / 12个月
- **多格式输出**：表格(默认) / CSV / JSON / HTML可视化
- **颜色编码矩阵**：HTML报告中用颜色直观展示相关性强度

## 使用方法

### 命令行参数

```bash
# 基础用法
python fund_correlation_v3.py <基金代码1> <基金代码2> ...

# 指定时间跨度
python fund_correlation_v3.py 510050 510300 159919 --period 3m

# 输出HTML报告
python fund_correlation_v3.py 510050 510300 --output html

# 输出CSV文件
python fund_correlation_v3.py 510050 510300 --output csv

# 完整示例
python fund_correlation_v3.py 006105 000614 003629 003646 --period 3m --output html
```

### 参数说明

| 参数 | 说明 | 可选值 |
|------|------|--------|
| `funds` | 基金代码列表（6位数字） | 至少2个 |
| `--period`, `-p` | 时间跨度 | `3m`, `6m`, `12m` (默认3m) |
| `--output`, `-o` | 输出格式 | `table`, `csv`, `json`, `html` |
| `--verbose`, `-v` | 显示详细日志 | - |

## 输出示例

### HTML可视化报告

![HTML报告预览](screenshots/html-report-preview.png)

HTML报告包含：
- 颜色编码的相关系数矩阵
- 图例说明（强正相关/中等正相关/弱正相关/基本无关/弱负相关/中等负相关/强负相关）
- 两两配对详细数据
- 解读说明

### CSV格式

```csv
"基金名称","上证50ETF (510050)","沪深300ETF (510300)","中证500ETF (510500)"
"上证50ETF (510050)",1.0000,0.9502,0.8231
"沪深300ETF (510300)",0.9502,1.0000,0.8892
"中证500ETF (510500)",0.8231,0.8892,1.0000
```

### 控制台表格

```
相关系数矩阵:
======================================================================
基金列表:
  1. 宏利印度股票(QDII)A (006105)
  2. 华安德国(DAX)联接(QDII)A (000614)
  3. 摩根全球多元配置(QDII-FOF)人民币A (003629)
  4. 创金合信中证1000指数增强A (003646)

Pairwise Correlation:
------------------------------------------------------------------
  宏利印度股票(QDII)A   vs 华安德国(DAX)联接(QDII)A : +0.3358 [Weak Positive]
  宏利印度股票(QDII)A   vs 摩根全球多元配置(QDII-FOF)人民币A : +0.3930 [Weak Positive]
  宏利印度股票(QDII)A   vs 创金合信中证1000指数增强A : +0.0333 [Near Zero]
  华安德国(DAX)联接(QDII)A vs 摩根全球多元配置(QDII-FOF)人民币A : +0.8397 [Strong Positive]
  华安德国(DAX)联接(QDII)A vs 创金合信中证1000指数增强A : +0.5161 [Medium Positive]
  摩根全球多元配置(QDII-FOF)人民币A vs 创金合信中证1000指数增强A : +0.3897 [Weak Positive]
```

## 技术实现

### 双接口方案

| 接口 | 功能 | 数据源 |
|------|------|--------|
| `ak.fund_name_em()` | 获取基金规范名称 | 天天基金网，一次加载26709只基金 |
| `ak.fund_open_fund_info_em()` | 获取历史净值数据 | AkShare，支持按日期过滤 |

### 相关性计算

- 算法：皮尔逊相关系数 (Pearson Correlation Coefficient)
- 数据对齐：取所有基金收益率序列的最小共同长度
- 解读标准：
  - `≥ 0.8`: 强正相关
  - `0.5-0.8`: 中等正相关
  - `0.3-0.5`: 弱正相关
  - `-0.3-0.3`: 基本无关
  - `< -0.3`: 负相关

### 数据样本量

| 时间跨度 | 约数据点数 | 适用场景 |
|----------|-----------|----------|
| 3m | 46-53点 | 短期趋势分析 |
| 6m | 109-116点 | 中期趋势分析 |
| 12m | 220-234点 | 长期趋势分析 |

## 安装依赖

```bash
pip install akshare pandas
```

## 示例基金代码

### QDII基金
- `006105`: 宏利印度股票(QDII)A
- `000614`: 华安德国(DAX)联接(QDII)A
- `003629`: 摩根全球多元配置(QDII-FOF)人民币A

### 国内ETF
- `510050`: 上证50ETF
- `510300`: 沪深300ETF华泰柏瑞
- `159919`: 沪深300ETF嘉实
- `510500`: 中证500ETF
- `159915`: 创业板ETF

### 主动管理基金
- `110022`: 易方达消费行业股票
- `163406`: 兴全合润混合

## 文件结构

```
fund-correlation-tool/
├── SKILL.md                  # 本文件
├── fund_correlation_v3.py    # 主程序
├── README.md                 # 详细使用文档
└── screenshots/
    └── html-report-preview.png  # HTML报告截图
```

## 使用场景

1. **投资组合优化**：分析基金间相关性，构建低相关性组合
2. **QDII配置分析**：评估海外资产与国内资产的相关性
3. **指数基金对比**：比较同类型ETF的跟踪误差和相关性
4. **行业基金分析**：分析主动管理基金与基准指数的相关性

## 注意事项

1. 数据来自AkShare，部分QDII基金数据可能延迟
2. 历史数据不代表未来表现
3. 相关系数仅衡量线性关系，非线性关系可能无法捕捉
4. 建议结合多时间跨度综合分析
