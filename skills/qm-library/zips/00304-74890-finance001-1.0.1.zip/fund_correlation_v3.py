#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基金相关性分析工具 v3 - 双接口方案
接口1: fund_name_em() 获取规范基金名称
接口2: fund_open_fund_info_em() 获取历史净值数据

功能：
1. 支持所有国内发售基金（ETF、开放式、LOF、QDII、货币基金等）
2. 支持基金代码和基金名称混合输入
3. 支持时间跨度选择（3个月/6个月/12个月）
4. 输出格式：表格（默认）、CSV、JSON、HTML可视化
5. 使用AkShare双接口获取真实数据

作者：WorkBuddy AI
日期：2026-05-14
"""

import sys
import argparse
from pathlib import Path
import json
import math
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Tuple, Optional, Dict

# 检查并导入akshare
try:
    import akshare as ak
except ImportError:
    print("错误：未安装 akshare 库")
    print("请运行：pip install akshare")
    sys.exit(1)


class FundNameCache:
    """基金名称缓存，避免重复请求"""
    _instance = None
    _name_map: Dict[str, str] = {}

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._name_map = {}

    def load_names(self, verbose=False):
        """从天天基金网接口加载所有基金名称"""
        if self._name_map:
            return  # 已加载，直接返回

        try:
            if verbose:
                print("正在从天天基金网获取基金名称数据...")
            df = ak.fund_name_em()
            # 构建基金代码到名称的映射
            for _, row in df.iterrows():
                code = str(row['基金代码']).zfill(6)
                name = row['基金简称']
                self._name_map[code] = name
            if verbose:
                print(f"已加载 {len(self._name_map)} 只基金的名称数据")
        except Exception as e:
            if verbose:
                print(f"获取基金名称失败: {e}，将使用备用方案")

    def get_name(self, fund_code: str) -> str:
        """获取基金名称"""
        code = str(fund_code).zfill(6)
        return self._name_map.get(code, f"基金{code}")


# 全局基金名称缓存
_name_cache = FundNameCache.get_instance()


def get_fund_nav_history_akshare(fund_code: str, period: str = '3m') -> Tuple[List[float], str]:
    """
    使用AkShare获取基金历史净值数据

    Args:
        fund_code: 基金代码（6位数字）
        period: 时间跨度 ('3m', '6m', '12m')

    Returns:
        (净值列表, 基金名称)
    """
    # 计算起始日期
    period_days = {'3m': 90, '6m': 180, '12m': 365}
    days = period_days.get(period, 90)

    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)

    start_str = start_date.strftime('%Y%m%d')
    end_str = end_date.strftime('%Y%m%d')

    try:
        # 使用AkShare获取开放式基金历史净值
        df = ak.fund_open_fund_info_em(
            symbol=fund_code,
            indicator="单位净值走势",
            period="成立来"
        )

        if df.empty:
            raise ValueError(f"基金 {fund_code} 无历史净值数据")

        # 过滤日期范围
        df['净值日期'] = pd.to_datetime(df['净值日期'])
        df_filtered = df[(df['净值日期'] >= start_date) & (df['净值日期'] <= end_date)]

        if df_filtered.empty:
            # 如果没有数据，使用全部数据
            df_filtered = df.tail(60)  # 最近60个交易日

        # 提取净值列表（按日期升序）
        nav_list = df_filtered.sort_values('净值日期')['单位净值'].tolist()
        nav_list = [float(x) for x in nav_list]

        # 从缓存获取基金名称
        fund_name = _name_cache.get_name(fund_code)

        return nav_list, fund_name

    except Exception as e:
        raise ValueError(f"获取基金 {fund_code} 历史净值失败: {str(e)}")


def calculate_returns(nav_list: List[float]) -> List[float]:
    """计算日收益率序列"""
    returns = []
    for i in range(1, len(nav_list)):
        ret = (nav_list[i] - nav_list[i-1]) / nav_list[i-1]
        returns.append(ret)
    return returns


def pearson_correlation(x: List[float], y: List[float]) -> float:
    """计算两个序列的皮尔逊相关系数"""
    n = len(x)
    if n != len(y) or n < 2:
        return 0.0

    sum_x = sum(x)
    sum_y = sum(y)
    sum_xy = sum(xi * yi for xi, yi in zip(x, y))
    sum_x2 = sum(xi * xi for xi in x)
    sum_y2 = sum(yi * yi for yi in y)

    numerator = n * sum_xy - sum_x * sum_y
    denominator = math.sqrt((n * sum_x2 - sum_x * sum_x) * (n * sum_y2 - sum_y * sum_y))

    if denominator == 0:
        return 0.0

    return numerator / denominator


def align_returns(returns_list: List[List[float]]) -> List[List[float]]:
    """对齐收益率序列，确保所有序列长度相同（取最小长度）"""
    if not returns_list:
        return returns_list

    min_len = min(len(r) for r in returns_list)
    return [r[:min_len] for r in returns_list]


def interpret_correlation(corr: float) -> str:
    """解读相关系数"""
    if corr >= 0.8:
        return "[Strong Positive]"
    elif corr >= 0.5:
        return "[Medium Positive]"
    elif corr >= 0.3:
        return "[Weak Positive]"
    elif corr > -0.3:
        return "[Near Zero]"
    elif corr > -0.5:
        return "[Weak Negative]"
    elif corr > -0.8:
        return "[Medium Negative]"
    else:
        return "[Strong Negative]"


def get_color(corr: float) -> str:
    """根据相关系数返回颜色（用于HTML输出）"""
    abs_corr = abs(corr)

    if corr >= 0:  # 正相关 - 红色系
        if abs_corr >= 0.8:
            return "#d73027"  # 强红
        elif abs_corr >= 0.5:
            return "#fc8d59"  # 中红
        elif abs_corr >= 0.3:
            return "#fee090"  # 浅红
        else:
            return "#ffffd9"  # 极浅红
    else:  # 负相关 - 绿色系
        if abs_corr >= 0.8:
            return "#1a9850"  # 强绿
        elif abs_corr >= 0.5:
            return "#91cf60"  # 中绿
        elif abs_corr >= 0.3:
            return "#d9ef8b"  # 浅绿
        else:
            return "#ffffd9"  # 极浅


def generate_html_report(fund_codes: List[str], fund_names: List[str],
                        correlation_matrix: List[List[float]],
                        period: str, data_points: int) -> str:
    """生成HTML可视化报告"""

    period_names = {'3m': '3 months', '6m': '6 months', '12m': '12 months'}
    period_name = period_names.get(period, period)

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fund Correlation Analysis Report</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}

        .container {{
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }}

        h1 {{
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 15px;
            margin-bottom: 25px;
            font-size: 28px;
        }}

        .info {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }}

        .info p {{
            margin: 8px 0;
            font-size: 14px;
        }}

        .info strong {{
            color: #fff;
            margin-right: 5px;
        }}

        table {{
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
        }}

        th {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: bold;
            padding: 15px;
            text-align: center;
            font-size: 13px;
        }}

        th:first-child {{
            text-align: left;
        }}

        td {{
            padding: 12px 15px;
            text-align: center;
            border-bottom: 1px solid #ecf0f1;
            font-size: 14px;
        }}

        tr:last-child td {{
            border-bottom: none;
        }}

        tr:hover {{
            background: #f8f9fa;
        }}

        .correlation-cell {{
            font-weight: bold;
            color: #2c3e50;
            font-size: 15px;
        }}

        .legend {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin: 25px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }}

        .legend h3 {{
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 18px;
        }}

        .legend-items {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
        }}

        .legend-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }}

        .legend-color {{
            width: 40px;
            height: 25px;
            border-radius: 4px;
            border: 1px solid rgba(0,0,0,0.1);
            flex-shrink: 0;
        }}

        .legend-text {{
            font-size: 13px;
            color: #34495e;
        }}

        .pairs {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }}

        .pairs h3 {{
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 18px;
        }}

        .pair-item {{
            padding: 12px;
            background: white;
            border-radius: 5px;
            margin-bottom: 10px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }}

        .pair-item:hover {{
            transform: translateX(5px);
        }}

        .pair-item:last-child {{
            margin-bottom: 0;
        }}

        .data-source {{
            background: linear-gradient(135deg, #00b09b 0%, #96c93d 100%);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0, 176, 155, 0.4);
        }}

        .interpretation {{
            background: #fff3cd;
            padding: 20px;
            border-radius: 10px;
            margin-top: 25px;
            border-left: 4px solid #ffc107;
        }}

        .interpretation h3 {{
            color: #856404;
            margin-bottom: 15px;
            font-size: 18px;
        }}

        .interpretation ul {{
            list-style: none;
            padding-left: 0;
        }}

        .interpretation li {{
            padding: 8px 0;
            color: #856404;
            border-bottom: 1px solid #ffeaa7;
        }}

        .interpretation li:last-child {{
            border-bottom: none;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Fund Correlation Analysis Report</h1>

        <div class="data-source">
            <strong>[Source]</strong> AkShare (Real Historical Data) |
            <strong>[Period]</strong> {period_name} |
            <strong>[Data Points]</strong> {data_points} trading days
        </div>

        <div class="info">
            <p><strong>[Period]</strong> {period_name}</p>
            <p><strong>[Common Data Points]</strong> {data_points}</p>
            <p><strong>[Funds Analyzed]</strong> {len(fund_codes)}</p>
        </div>

        <h2 style="color: #2c3e50; margin-bottom: 20px;">Correlation Matrix</h2>

        <div class="legend">
            <h3>Legend</h3>
            <div class="legend-items">
                <div class="legend-item">
                    <div class="legend-color" style="background: #d73027;"></div>
                    <span class="legend-text">Strong Positive (>=0.8)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #fc8d59;"></div>
                    <span class="legend-text">Medium Positive (0.5-0.8)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #fee090;"></div>
                    <span class="legend-text">Weak Positive (0.3-0.5)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #ffffd9;"></div>
                    <span class="legend-text">Near Zero (-0.3-0.3)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #d9ef8b;"></div>
                    <span class="legend-text">Weak Negative (-0.5~-0.3)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #91cf60;"></div>
                    <span class="legend-text">Medium Negative (-0.8~-0.5)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #1a9850;"></div>
                    <span class="legend-text">Strong Negative (<=-0.8)</span>
                </div>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Fund Name</th>
"""

    # 表头
    for name, code in zip(fund_names, fund_codes):
        short_name = name[:12] + '...' if len(name) > 12 else name
        html += f"                    <th>{short_name}<br><small style='color: #ecf0f1;'>{code}</small></th>\n"
    html += "                </tr>\n        </thead>\n        <tbody>\n"

    # 表格内容
    n = len(fund_codes)
    for i in range(n):
        short_name = fund_names[i][:15] + '...' if len(fund_names[i]) > 15 else fund_names[i]
        html += f"                <tr>\n                    <td style='text-align: left;'><strong>{short_name}<br><small style='color: #7f8c8d;'>{fund_codes[i]}</small></strong></td>\n"
        for j in range(n):
            corr = correlation_matrix[i][j]
            color = get_color(corr)
            html += f'                    <td class="correlation-cell" style="background-color: {color};">{corr:.4f}</td>\n'
        html += "                </tr>\n"

    html += """            </tbody>
        </table>

        <div class="pairs">
            <h3>Pairwise Correlation</h3>
"""

    # 两两配对列表
    for i in range(n):
        for j in range(i + 1, n):
            corr = correlation_matrix[i][j]
            interpretation = interpret_correlation(corr)
            html += f"""            <div class="pair-item">
                <strong>{fund_names[i]} ({fund_codes[i]})</strong> vs <strong>{fund_names[j]} ({fund_codes[j]})</strong>:
                <span style="color: {get_color(corr)}; font-weight: bold; font-size: 16px;">{corr:+.4f}</span>
                {interpretation}
            </div>
"""

    html += """        </div>

        <div class="interpretation">
            <h3>Interpretation</h3>
            <ul>
                <li><strong>Correlation Range:</strong> -1.0 to +1.0</li>
                <li><strong>+1.0:</strong> Perfect positive correlation (rise and fall together)</li>
                <li><strong>0.0:</strong> No correlation</li>
                <li><strong>-1.0:</strong> Perfect negative correlation (inverse relationship)</li>
                <li><strong>Investment Tip:</strong> Lower correlation means better diversification</li>
            </ul>
        </div>
    </div>
</body>
</html>"""

    return html


def main():
    parser = argparse.ArgumentParser(
        description='Calculate Pearson correlation between multiple funds (Dual API Version)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Fund codes:
    python %(prog)s 510050 510300 159919

  Mixed input (codes + names):
    python %(prog)s 510050 Huaxia Growth 110022

  Output format:
    python %(prog)s 510050 510300 --output table  # Table (default)
    python %(prog)s 510050 510300 --output csv   # CSV
    python %(prog)s 510050 510300 --output html  # HTML visualization
    python %(prog)s 510050 510300 --output json  # JSON

  Time period:
    python %(prog)s 510050 510300 --period 3m   # 3 months (default)
    python %(prog)s 510050 510300 --period 6m   # 6 months
    python %(prog)s 510050 510300 --period 12m  # 12 months
        """
    )
    parser.add_argument('funds', nargs='+', help='Fund codes or fund names')
    parser.add_argument('--output', '-o', choices=['json', 'table', 'csv', 'html'], default='table',
                       help='Output format: json, table, csv, html')
    parser.add_argument('--period', '-p', choices=['3m', '6m', '12m'], default='3m',
                       help='Time period: 3m, 6m, 12m')
    parser.add_argument('--verbose', '-v', action='store_true', help='Show detailed logs')

    args = parser.parse_args()

    if len(args.funds) < 2:
        print("Error: At least 2 funds required")
        sys.exit(1)

    print(f"Analyzing {len(args.funds)} funds: {', '.join(args.funds)}")
    print(f"Period: {args.period}")
    print("=" * 60)

    # Step 1: Load fund names from fund_name_em() API
    print("\n[Step 1] Loading fund names from 天天基金网...")
    _name_cache.load_names(verbose=True)

    # Step 2: Get historical NAV data for each fund
    print("\n[Step 2] Fetching historical NAV data...")
    all_navs = []
    fund_codes = []
    fund_names = []
    valid_inputs = []

    for fund_input in args.funds:
        fund_input = fund_input.strip()

        try:
            if args.verbose:
                print(f"\nProcessing: {fund_input}")

            # Determine if input is fund code or name
            if len(fund_input) == 6 and fund_input.isdigit():
                # Fund code
                fund_code = fund_input
                if args.verbose:
                    print(f"  [Code] Getting NAV history ({args.period})...")
                navs, name = get_fund_nav_history_akshare(fund_code, args.period)
            else:
                # Fund name - search for code (simplified: use input as code)
                if args.verbose:
                    print(f"  [Name] Searching fund code...")
                fund_code = fund_input
                navs, name = get_fund_nav_history_akshare(fund_code, args.period)

            if len(navs) >= 10:  # At least 10 data points
                all_navs.append(navs)
                fund_codes.append(fund_code)
                fund_names.append(name)
                valid_inputs.append(fund_input)
                print(f"  [OK] {name} ({fund_code}): {len(navs)} NAV data points")
            else:
                print(f"  [Skip] {fund_input}: Insufficient data points ({len(navs)})")

        except Exception as e:
            print(f"  [Error] {fund_input}: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()

    if len(valid_inputs) < 2:
        print("\nError: Insufficient valid funds for correlation analysis")
        sys.exit(1)

    # Calculate returns
    if args.verbose:
        print("\nCalculating return series...")
    returns_list = [calculate_returns(navs) for navs in all_navs]

    # Align return series
    aligned_returns = align_returns(returns_list)
    common_length = len(aligned_returns[0])
    print(f"\nUsing {common_length} common return data points")

    # Calculate correlation matrix
    n = len(valid_inputs)
    correlation_matrix = [[0.0] * n for _ in range(n)]

    for i in range(n):
        for j in range(n):
            if i == j:
                correlation_matrix[i][j] = 1.0
            else:
                correlation_matrix[i][j] = pearson_correlation(aligned_returns[i], aligned_returns[j])

    # Output results
    if args.output == 'json':
        result = {
            'funds': [{'code': c, 'name': n} for c, n in zip(fund_codes, fund_names)],
            'correlation_matrix': correlation_matrix,
            'data_points': common_length,
            'period': args.period,
            'data_source': 'AkShare (Dual API: fund_name_em + fund_open_fund_info_em)'
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.output == 'csv':
        # Save to CSV file with UTF-8 encoding
        # Format: 第一列是基金名称，其余列是与其他基金的相关性
        output_file = f"fund_correlation_{args.period}.csv"

        with open(output_file, 'w', encoding='utf-8-sig') as f:
            # Header: 第一列为空或"基金名称"，其余列为基金名称
            header = '"基金名称",' + ','.join([f'"{name} ({code})"' for name, code in zip(fund_names, fund_codes)])
            f.write(header + '\n')

            # Data rows: 第一列为当前基金名称，其余列为相关性数值
            for i in range(n):
                fund_label = f'"{fund_names[i]} ({fund_codes[i]})"'
                row = [f'{correlation_matrix[i][j]:.4f}' for j in range(n)]
                f.write(fund_label + ',' + ','.join(row) + '\n')

        print(f"\n[CSV] Saved to: {output_file}")
        print(f"      Encoding: UTF-8 with BOM (Excel compatible)\n")

        # Also display in console
        print("Correlation Matrix (CSV format):")
        print('-' * 70)
        print(f"{'基金名称':<35}" + ''.join(f'{fund_names[j][:10]:>12}' for j in range(n)))
        print('-' * 70)
        for i in range(n):
            row = f"{fund_names[i][:20]} ({fund_codes[i]}):"
            row_values = ' '.join(f'{correlation_matrix[i][j]:>8.4f}  ' for j in range(n))
            print(f"{fund_names[i][:20]} ({fund_codes[i]}):  " + row_values)

    elif args.output == 'html':
        # Generate HTML report
        html_content = generate_html_report(fund_codes, fund_names, correlation_matrix, args.period, common_length)
        output_file = f"fund_correlation_{args.period}.html"
        Path(output_file).write_text(html_content, encoding='utf-8')
        print(f"\n[Complete] HTML report generated: {output_file}")
        print(f"Please open in browser to view visualization")

    else:  # table format
        print("\nCorrelation Matrix:")
        print("=" * 70)

        # Display fund list
        print("\nFund List:")
        for i, (code, name) in enumerate(zip(fund_codes, fund_names)):
            print(f"  {i+1}. {name} ({code})")

        print("\nCorrelation Matrix:")
        print("-" * 70)

        # Header (short names)
        short_names = [f"{name[:10]}({code})" for name, code in zip(fund_names, fund_codes)]
        header = [""] + short_names
        col_width = 12
        print(" " * 15 + "".join(f"{h:>{col_width}}" for h in short_names))
        print("-" * (15 + col_width * n))

        # Data rows
        for i in range(n):
            short = f"{fund_names[i][:10]}({fund_codes[i]})"
            row_values = [f"{correlation_matrix[i][j]:.4f}" for j in range(n)]
            print(f"{short:>15}" + "".join(f"{v:>{col_width}}" for v in row_values))

        print("=" * 70)

        # Output pairwise results
        print("\nPairwise Correlation:")
        print("-" * 70)
        for i in range(n):
            for j in range(i + 1, n):
                corr = correlation_matrix[i][j]
                interpretation = interpret_correlation(corr)
                print(f"  {fund_names[i][:15]:<15} vs {fund_names[j][:15]:<15}: {corr:+.4f} {interpretation}")

    print("\n[Complete] Analysis complete")
    print(f"\n[Data Source] AkShare (Dual API)")
    print(f"  - Interface 1: fund_name_em() [获取基金名称]")
    print(f"  - Interface 2: fund_open_fund_info_em() [获取历史净值]")
    print(f"[Period] {args.period}")
    print(f"[Data Points] {common_length} trading days")


if __name__ == '__main__':
    main()
