## Description: <br>
Provides agents with OOMOL-backed commands for querying ipdata.co IP geolocation, network, and threat intelligence data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect schemas and run ipdata.co lookup actions for IP geolocation, ASN, carrier, company, currency, time zone, EU endpoint, and threat intelligence workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Setup guidance includes remote installer commands, and current-IP lookup actions may send the user's public IP address to ipdata.co when no IP is provided. <br>
Mitigation: Review install commands before execution, prefer a pinned or package-manager install path, and confirm whether the action should use the current public IP address. <br>


## Reference(s): <br>
- [ipdata.co homepage](https://ipdata.co) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ipdata-co) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are returned as JSON data with execution metadata from the oo connector.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
