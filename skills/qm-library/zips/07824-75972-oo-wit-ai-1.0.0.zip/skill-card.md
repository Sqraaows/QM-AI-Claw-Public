## Description: <br>
Wit.ai enables an agent to inspect, analyze, create, update, and delete Wit.ai app data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Wit.ai apps, intents, entities, traits, utterances, language detection, and message analysis from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Credentialed actions can read or modify Wit.ai account data through the connected OOMOL account. <br>
Mitigation: Install only when agent access to the Wit.ai account is intended, and review payloads before approving write operations. <br>
Risk: Deletion of utterances can remove training data from a Wit.ai app. <br>
Mitigation: Confirm the target utterances and obtain explicit user approval before running destructive actions. <br>
Risk: Connector schemas and upstream Wit.ai fields can change over time. <br>
Mitigation: Inspect the live action schema with the oo CLI before constructing payloads. <br>


## Reference(s): <br>
- [Wit.ai homepage](https://wit.ai) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-wit-ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance, API Calls] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses are returned as JSON from the oo CLI, with execution metadata included by the connector.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
