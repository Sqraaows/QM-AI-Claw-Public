## Description: <br>
Mapbox (mapbox.com). Use this skill for Mapbox geocoding, directions, and matrix requests through an OOMOL-connected account instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Mapbox connector schemas and run geocoding, routing, and travel matrix actions through the oo CLI. It is suited for workflows that need location lookup, route calculation, or distance and duration matrices using an already connected Mapbox account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL and Mapbox account, so requests may be sent to OOMOL and Mapbox and may consume account credits. <br>
Mitigation: Install and run it only for intended OOMOL-connected Mapbox workflows; review payloads and account billing impact before execution. <br>
Risk: Connector actions can use live upstream schemas whose fields and defaults may change. <br>
Mitigation: Fetch the authoritative schema with `oo connector schema` before constructing each payload. <br>
Risk: Actions described as create, update, send, post, delete, or remove can change account state or have destructive effects. <br>
Mitigation: Confirm the exact payload, target, and intended effect with the user before running state-changing or destructive actions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-mapbox) <br>
- [Mapbox homepage](https://www.mapbox.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
