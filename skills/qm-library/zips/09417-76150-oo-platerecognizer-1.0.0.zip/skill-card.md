## Description: <br>
Operates Plate Recognizer through OOMOL's platerecognizer connector to read license plates from images and retrieve Snapshot Cloud usage statistics. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External developers and operators use this skill to run Plate Recognizer actions through an OOMOL-connected account. It supports reading number plates from a single image and checking current-month Snapshot Cloud usage and reset information. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: License plate image data may be submitted to Plate Recognizer through OOMOL when running the read_number_plates action. <br>
Mitigation: Use the skill only for images the user is authorized to process, and confirm that sending plate image data through OOMOL and Plate Recognizer is acceptable for the user's environment. <br>
Risk: The skill depends on an OOMOL account connection and server-side credentials for Plate Recognizer. <br>
Mitigation: Use only the intended OOMOL account, verify that the Plate Recognizer connection is active, and reconnect only when an auth or scope error requires it. <br>
Risk: First-time setup can involve running the oo CLI installer from a remote URL. <br>
Mitigation: Review the oo CLI installer before running it, and run setup commands only when the CLI is missing or authentication fails. <br>
Risk: Connector usage can be blocked by billing or account limits. <br>
Mitigation: Check usage statistics and billing status before retrying after HTTP 402 or OOMOL_INSUFFICIENT_CREDIT errors. <br>


## Reference(s): <br>
- [Plate Recognizer homepage](https://platerecognizer.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_statistics action](actions/get_statistics.md) <br>
- [read_number_plates action](actions/read_number_plates.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Guidance, JSON] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires a signed-in OOMOL account with Plate Recognizer connected; action schemas are fetched live before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release.version and SKILL.md metadata.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
