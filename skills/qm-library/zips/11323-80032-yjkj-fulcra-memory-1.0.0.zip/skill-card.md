## Description: <br>
Manages agent memory backup, restoration, rollback, and cloning using Fulcra's versioned file storage. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[fulcra](https://clawhub.ai/user/fulcra) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill to save, inspect, restore, roll back, and clone agent memory through Fulcra's versioned file storage. It also supports approved artifact uploads and team inbox workflows when those are relevant to the user's work. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Memory restore, rollback, or cloning can overwrite an agent's local identity and memory state. <br>
Mitigation: Require explicit user approval and create a fresh backup before any restore, rollback, or clone operation. <br>
Risk: Backups and artifact uploads can expose private user data or secrets if sensitive files are stored in memory paths. <br>
Mitigation: Use only trusted Fulcra accounts, avoid storing secrets or private user data in memory files, and review files before upload. <br>
Risk: Downloaded or cloned archives can introduce untrusted memory or identity content into a live workspace. <br>
Mitigation: Inspect restored or cloned archives before extraction and only apply archives from agents and accounts the user is allowed to access. <br>
Risk: Team inbox deletion can remove active task messages before they are safely retained. <br>
Mitigation: Archive each inbox message before deletion and require user approval for destructive inbox changes. <br>


## Reference(s): <br>
- [Fulcra Memory CLI Reference](references/fulcra-memory-cli.md) <br>


## Skill Output: <br>
**Output Type(s):** [Markdown, Shell commands, Configuration guidance, Files] <br>
**Output Format:** [Markdown guidance with inline shell commands and file path conventions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces and manages compressed memory archives, top-of-mind summaries, restored files, uploaded artifacts, and team inbox messages through Fulcra CLI workflows.] <br>

## Skill Version(s): <br>
0.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
