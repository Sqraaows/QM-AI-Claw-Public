## Description: <br>
Exa helps agents search the web, retrieve page contents, find similar pages, and generate citation-backed answers through an OOMOL-connected Exa account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill when an assistant needs Exa-backed web search, citation-backed answers, content retrieval for URLs or document IDs, or similar-page discovery. The skill is intended for OOMOL-connected Exa accounts and normal ClawHub release use. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive Exa credentials through an OOMOL-connected account. <br>
Mitigation: Connect Exa through OOMOL and avoid placing raw API keys in prompts, files, or shell history. <br>
Risk: First-time setup may install or authenticate the oo CLI. <br>
Mitigation: Review OOMOL's oo CLI installer before setup and run authentication or connection steps only when an Exa action fails for that reason. <br>
Risk: Connector action schemas and upstream defaults can change. <br>
Mitigation: Inspect the live Exa connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Exa Skill](https://clawhub.ai/oomol/oo-exa) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Exa Homepage](https://exa.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, guidance] <br>
**Output Format:** [Markdown or plain text guidance with oo CLI commands and JSON action payloads or responses.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an OOMOL sign-in, and a connected Exa API key. Routine use should inspect the live connector schema before running an Exa action.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
