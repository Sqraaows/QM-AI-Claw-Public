## Description: <br>
Operate Neon resources through an OOMOL-connected account using the oo CLI for read, create, update, and delete actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Neon projects, branches, databases, operations, and the current user profile from an agent session through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, or delete Neon projects, branches, and databases through the user's connected account. <br>
Mitigation: Review write requests carefully and require explicit approval for exact destructive targets and payloads before execution. <br>
Risk: The skill requires sensitive account credentials through an OOMOL-connected Neon integration. <br>
Mitigation: Install and use the skill only when the agent is intended to manage Neon resources for that connected account. <br>


## Reference(s): <br>
- [Neon homepage](https://neon.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses from the oo connector with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
