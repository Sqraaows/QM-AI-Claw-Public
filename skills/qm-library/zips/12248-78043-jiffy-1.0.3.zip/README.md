# gif-connect

**纯JavaScript的GIF和APNG编码器，从图像帧合成动画。零依赖。**

直接从原始RGBA像素数据生成GIF和APNG动画。适用于浏览器（Canvas `ImageData`）和Node.js（配合 `sharp` 等图像库）。

- **GIF**：GIF89a格式，Floyd-Steinberg抖动算法，LZW压缩，支持透明度，每帧最多256色
- **APNG**：动画PNG，完整RGBA通道，通过原生 `CompressionStream` API进行DEFLATE压缩，无颜色损失

## 安装

```bash
npm install gif-connect
```

## 快速开始

### 浏览器（配合Canvas）

```html
<script type="module">
  import { GifEncoder, ApngEncoder } from 'https://esm.sh/gif-connect';

  const img = document.querySelector('img');
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  // 绘制第一帧
  img.src = 'frame1.png';
  await img.decode();
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  ctx.drawImage(img, 0, 0);

  const encoder = new GifEncoder(canvas.width, canvas.height);
  encoder.setRepeat(0); // 0 = 无限循环
  encoder.addFrame(ctx.getImageData(0, 0, canvas.width, canvas.height).data, 500);

  // 绘制第二帧
  img.src = 'frame2.png';
  await img.decode();
  ctx.drawImage(img, 0, 0);
  encoder.addFrame(ctx.getImageData(0, 0, canvas.width, canvas.height).data, 300);

  const gifBytes = encoder.encode();
  const blob = new Blob([gifBytes], { type: 'image/gif' });
  const url = URL.createObjectURL(blob);
  // 用 <img src={url}> 显示，或触发下载
</script>
```

### Node.js

```js
import { GifEncoder, ApngEncoder } from 'gif-connect';
import sharp from 'sharp';

async function createGif(framePaths, delays, outputPath) {
  // 加载第一帧获取尺寸
  const first = await sharp(framePaths[0]).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width, height } = first.info;

  const encoder = new GifEncoder(width, height);
  encoder.setRepeat(0);

  for (let i = 0; i < framePaths.length; i++) {
    const { data } = await sharp(framePaths[i])
      .resize(width, height, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
      .ensureAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });

    encoder.addFrame(new Uint8ClampedArray(data), delays[i]);
  }

  const gifBytes = encoder.encode();
  await sharp(Buffer.from(gifBytes), { animated: true, pages: framePaths.length })
    .toFile(outputPath);
  // 或直接写入：fs.writeFileSync(outputPath, gifBytes);
}

// APNG的encode()是异步的：
async function createApng(framePaths, delays, outputPath) {
  const first = await sharp(framePaths[0]).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width, height } = first.info;

  const encoder = new ApngEncoder(width, height);
  encoder.setRepeat(0);

  for (let i = 0; i < framePaths.length; i++) {
    const { data } = await sharp(framePaths[i])
      .resize(width, height, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
      .ensureAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });

    encoder.addFrame(new Uint8ClampedArray(data), delays[i]);
  }

  const apngBytes = await encoder.encode();
  fs.writeFileSync(outputPath, apngBytes);
}
```

## API

### `GifEncoder`

```ts
class GifEncoder {
  constructor(width: number, height: number)
  setRepeat(repeat: number): void       // 0 = 无限循环
  addFrame(imageData: Uint8ClampedArray, delayMs: number): void
  encode(): Uint8Array                  // 同步
}
```

- `imageData`：RGBA像素数组，长度恰好为 `width * height * 4` 字节
- `delayMs`：帧延时时长（毫秒）
- `encode()` 返回完整的GIF文件 `Uint8Array`，可直接保存或创建 `Blob`

### `ApngEncoder`

```ts
class ApngEncoder {
  constructor(width: number, height: number)
  setRepeat(repeat: number): void       // 0 = 无限循环
  addFrame(imageData: Uint8ClampedArray, delayMs: number): void
  encode(): Promise<Uint8Array>         // 异步——使用CompressionStream
}
```

与 `GifEncoder` 接口相同，但 `encode()` 是异步的，因为DEFLATE压缩使用了浏览器/Node端的 `CompressionStream` API。

### repeat参数值

| 值 | 行为 |
|---|------|
| `0` | 无限循环 |
| `1` | 播放一次（不循环） |
| `N` | 播放N次 |

## 工作原理

### GIF编码流程

1. **Floyd-Steinberg抖动** — 将半透明像素与白色背景混合，将量化误差扩散到相邻像素
2. **颜色量化** — 将颜色减少到每帧最多256色（5位RGB立方体 + 最近匹配回退）
3. **LZW压缩** — GIF原生的无损压缩，动态字典（最多4096条目）
4. **GIF89a组装** — 文件头、全局/局部颜色表、图形控制扩展、Netscape循环扩展

### APNG编码流程

1. **PNG扫描线转换** — 每行添加滤镜字节（None）
2. **DEFLATE压缩** — 通过 `CompressionStream('deflate-raw')` 配合zlib包装；不可用时回退到不压缩块
3. **块组装** — IHDR + acTL + fcTL/IDAT（第0帧）+ fcTL/fdAT（第1..N帧）+ IEND，附带CRC32校验

## 格式对比

| 特性 | GIF | APNG |
|------|-----|------|
| 颜色 | 每帧256色 | 1670万色（真彩色） |
| 透明度 | 二值（开/关） | 完整8位透明通道 |
| 文件大小 | 较小 | 较大（但质量更好） |
| 浏览器支持 | 全部支持 | 所有现代浏览器 |
| 压缩方式 | LZW | DEFLATE |

## 运行要求

- **浏览器**：任意支持 `Uint8Array`、`Map` 的现代浏览器
- **Node.js**：>= 18（用于 `CompressionStream`；不可用时回退到不压缩模式）
- **零npm依赖**

## 许可证

MIT
