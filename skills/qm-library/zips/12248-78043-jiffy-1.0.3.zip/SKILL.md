---
name: gif-connect
description: 当用户要求"合成GIF"、"生成动图"、"制作APNG"、"图片合成动画"、"多张图片转GIF"、"帧合成APNG"，或提到"GIF编码器"、"APNG编码器"、"动画PNG"、"帧序列动画"时，应使用此技能。提供零依赖的GIF89a和APNG编码器，支持Floyd-Steinberg抖动算法和LZW/DEFLATE压缩。
version: 1.0.0
license: MIT
---

# GIF/APNG 动画编码器

纯 JavaScript 的 GIF89a 和 APNG 编码器。从 RGBA 像素帧合成动画，零外部依赖，浏览器和 Node.js >= 18 均可用。

> 完整技能定义位于 `skills/gif-connect/SKILL.md`，配套源码和示例均在该目录下。

## 核心能力

- **GifEncoder**：GIF89a 格式，Floyd-Steinberg 抖动，LZW 压缩，每帧 256 色，同步 encode()
- **ApngEncoder**：动画 PNG，完整 RGBA，DEFLATE 压缩，CRC32 校验，异步 encode()

## 使用方式

编码器源码位于 `skills/gif-connect/src/` 下，示例位于 `skills/gif-connect/examples/` 下。技能触发后，读取对应源码文件写入用户项目即可零依赖使用。

API：

```js
const encoder = new GifEncoder(width, height);
encoder.setRepeat(0);              // 0 = 无限循环
encoder.addFrame(rgbaPixels, 500); // Uint8ClampedArray RGBA, 延时(毫秒)
const bytes = encoder.encode();    // GifEncoder: 同步; ApngEncoder: await
```

## 附加资源

- `skills/gif-connect/references/api-reference.md` — 完整 API 参考
- `skills/gif-connect/examples/browser.html` — 浏览器演示
- `skills/gif-connect/examples/node-example.js` — Node.js 示例
- `src/` — npm 包编码器副本（与技能目录内容一致）
