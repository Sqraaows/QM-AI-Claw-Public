/**
 * Pure JavaScript GIF89a encoder.
 * Supports transparency and Floyd-Steinberg dithering for alpha blending.
 *
 * @example
 * const encoder = new GifEncoder(800, 600);
 * encoder.setRepeat(0); // 0 = loop forever
 * encoder.addFrame(imageData, 500); // 500ms delay
 * const bytes = encoder.encode();   // Uint8Array
 */
export class GifEncoder {
  constructor(width, height) {
    this.width = width;
    this.height = height;
    this.frames = [];
    this.repeat = 0;
  }

  /** @param {number} repeat - 0 = infinite loop, N = play N times */
  setRepeat(repeat) {
    this.repeat = repeat;
  }

  /**
   * Add a frame to the animation.
   * @param {Uint8ClampedArray} imageData - RGBA pixel data (width * height * 4 bytes)
   * @param {number} delay - frame delay in milliseconds
   */
  addFrame(imageData, delay) {
    this.frames.push({
      data: imageData,
      delay: Math.round(delay / 10),
    });
  }

  // Floyd-Steinberg error diffusion dithering for semi-transparent pixel blending
  dither(pixels, width, height) {
    const dithered = new Float32Array(pixels.length);
    for (let i = 0; i < pixels.length; i++) {
      dithered[i] = pixels[i];
    }

    const bgR = 255, bgG = 255, bgB = 255;

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const a = dithered[idx + 3];
        if (a < 16) continue;

        const alpha = a / 255;
        const blendedR = dithered[idx] * alpha + bgR * (1 - alpha);
        const blendedG = dithered[idx + 1] * alpha + bgG * (1 - alpha);
        const blendedB = dithered[idx + 2] * alpha + bgB * (1 - alpha);

        const qR = Math.round(blendedR / 8) * 8;
        const qG = Math.round(blendedG / 8) * 8;
        const qB = Math.round(blendedB / 8) * 8;

        dithered[idx] = qR;
        dithered[idx + 1] = qG;
        dithered[idx + 2] = qB;

        const errR = blendedR - qR;
        const errG = blendedG - qG;
        const errB = blendedB - qB;

        if (x + 1 < width) {
          dithered[idx + 4] += errR * 7 / 16;
          dithered[idx + 5] += errG * 7 / 16;
          dithered[idx + 6] += errB * 7 / 16;
        }
        if (y + 1 < height) {
          const downIdx = idx + width * 4;
          if (x > 0) {
            dithered[downIdx - 4] += errR * 3 / 16;
            dithered[downIdx - 3] += errG * 3 / 16;
            dithered[downIdx - 2] += errB * 3 / 16;
          }
          dithered[downIdx] += errR * 5 / 16;
          dithered[downIdx + 1] += errG * 5 / 16;
          dithered[downIdx + 2] += errB * 5 / 16;
          if (x + 1 < width) {
            dithered[downIdx + 4] += errR * 1 / 16;
            dithered[downIdx + 5] += errG * 1 / 16;
            dithered[downIdx + 6] += errB * 1 / 16;
          }
        }
      }
    }

    return dithered;
  }

  // Color quantization with transparency support (max 256 colors)
  quantize(pixels, width, height) {
    const dithered = this.dither(pixels, width, height);
    const colorMap = new Map();
    const palette = [[0, 0, 0]]; // index 0 = transparent
    const indexedPixels = new Uint8Array(pixels.length / 4);
    let hasTransparency = false;

    for (let i = 0; i < dithered.length; i += 4) {
      const a = pixels[i + 3]; // use original alpha
      if (a < 16) {
        indexedPixels[i / 4] = 0;
        hasTransparency = true;
        continue;
      }

      const r = Math.min(255, Math.max(0, Math.round(dithered[i])));
      const g = Math.min(255, Math.max(0, Math.round(dithered[i + 1])));
      const b = Math.min(255, Math.max(0, Math.round(dithered[i + 2])));

      const qR = r & 0xF8;
      const qG = g & 0xF8;
      const qB = b & 0xF8;
      const key = (qR << 16) | (qG << 8) | qB;

      if (!colorMap.has(key)) {
        if (palette.length < 256) {
          colorMap.set(key, palette.length);
          palette.push([qR, qG, qB]);
        } else {
          let minDist = Infinity;
          let minIdx = 1;
          for (let j = 1; j < palette.length; j++) {
            const dr = qR - palette[j][0];
            const dg = qG - palette[j][1];
            const db = qB - palette[j][2];
            const dist = dr * dr + dg * dg + db * db;
            if (dist < minDist) { minDist = dist; minIdx = j; }
          }
          colorMap.set(key, minIdx);
        }
      }
      indexedPixels[i / 4] = colorMap.get(key);
    }

    while (palette.length < 256) palette.push([0, 0, 0]);
    return { palette, indexedPixels, hasTransparency };
  }

  // LZW compression for GIF image data
  lzwEncode(indexedPixels, minCodeSize) {
    const clearCode = 1 << minCodeSize;
    const eoiCode = clearCode + 1;
    let codeSize = minCodeSize + 1;
    let nextCode = eoiCode + 1;
    const maxCode = 4096;
    const output = [];
    let bitBuffer = 0;
    let bitCount = 0;

    function writeBits(code, size) {
      bitBuffer |= (code << bitCount);
      bitCount += size;
      while (bitCount >= 8) {
        output.push(bitBuffer & 0xFF);
        bitBuffer >>= 8;
        bitCount -= 8;
      }
    }

    let dictionary = new Map();
    function resetDictionary() {
      dictionary = new Map();
      for (let i = 0; i < clearCode; i++) dictionary.set(String(i), i);
      nextCode = eoiCode + 1;
      codeSize = minCodeSize + 1;
    }

    resetDictionary();
    writeBits(clearCode, codeSize);
    let current = String(indexedPixels[0]);

    for (let i = 1; i < indexedPixels.length; i++) {
      const next = String(indexedPixels[i]);
      const combined = current + ',' + next;
      if (dictionary.has(combined)) {
        current = combined;
      } else {
        writeBits(dictionary.get(current), codeSize);
        if (nextCode < maxCode) {
          dictionary.set(combined, nextCode++);
          if (nextCode > (1 << codeSize) && codeSize < 12) codeSize++;
        } else {
          writeBits(clearCode, codeSize);
          resetDictionary();
        }
        current = next;
      }
    }

    writeBits(dictionary.get(current), codeSize);
    writeBits(eoiCode, codeSize);
    if (bitCount > 0) output.push(bitBuffer & 0xFF);
    return output;
  }

  /**
   * Encode all frames into a GIF binary.
   * @returns {Uint8Array} GIF file bytes
   */
  encode() {
    const bytes = [];
    const writeByte = (b) => bytes.push(b & 0xFF);
    const writeShort = (s) => { bytes.push(s & 0xFF); bytes.push((s >> 8) & 0xFF); };
    const writeString = (s) => { for (let i = 0; i < s.length; i++) bytes.push(s.charCodeAt(i)); };

    // Header
    writeString('GIF89a');
    writeShort(this.width);
    writeShort(this.height);
    writeByte(0xF7); // global color table follows, 256 colors
    writeByte(0);    // background color index
    writeByte(0);    // pixel aspect ratio

    // Global color table from first frame
    const firstFrame = this.frames[0];
    const firstQuantized = this.quantize(firstFrame.data, this.width, this.height);
    for (let i = 0; i < 256; i++) {
      writeByte(firstQuantized.palette[i][0]);
      writeByte(firstQuantized.palette[i][1]);
      writeByte(firstQuantized.palette[i][2]);
    }

    // Netscape extension (loop count)
    writeByte(0x21); writeByte(0xFF); writeByte(0x0B);
    writeString('NETSCAPE2.0');
    writeByte(0x03); writeByte(0x01);
    writeShort(this.repeat);
    writeByte(0x00);

    // Image data blocks
    for (let f = 0; f < this.frames.length; f++) {
      const frame = this.frames[f];
      const quantized = (f === 0) ? firstQuantized : this.quantize(frame.data, this.width, this.height);

      // Graphic control extension
      writeByte(0x21); writeByte(0xF9); writeByte(0x04);
      writeByte(quantized.hasTransparency ? 0x09 : 0x00);
      writeShort(frame.delay);
      writeByte(0x00); // transparent color index
      writeByte(0x00); // block terminator

      // Image descriptor
      writeByte(0x2C);
      writeShort(0); writeShort(0);           // left, top
      writeShort(this.width); writeShort(this.height);

      if (f === 0) {
        writeByte(0x00); // use global color table
      } else {
        writeByte(0x87); // local color table follows, sorted
        for (let i = 0; i < 256; i++) {
          writeByte(quantized.palette[i][0]);
          writeByte(quantized.palette[i][1]);
          writeByte(quantized.palette[i][2]);
        }
      }

      // LZW compressed image data
      const minCodeSize = 8;
      writeByte(minCodeSize);
      const lzwData = this.lzwEncode(quantized.indexedPixels, minCodeSize);
      let offset = 0;
      while (offset < lzwData.length) {
        const blockSize = Math.min(255, lzwData.length - offset);
        writeByte(blockSize);
        for (let i = 0; i < blockSize; i++) writeByte(lzwData[offset + i]);
        offset += blockSize;
      }
      writeByte(0x00); // block terminator
    }

    writeByte(0x3B); // GIF trailer
    return new Uint8Array(bytes);
  }
}
