/**
 * Pure JavaScript APNG (Animated PNG) encoder.
 * Supports full alpha transparency (no dithering needed).
 * Uses native CompressionStream API for DEFLATE compression.
 *
 * Note: encode() is async because it uses CompressionStream.
 *
 * @example
 * const encoder = new ApngEncoder(800, 600);
 * encoder.setRepeat(0);
 * encoder.addFrame(imageData, 500);
 * const bytes = await encoder.encode(); // Uint8Array
 */
export class ApngEncoder {
  constructor(width, height) {
    this.width = width;
    this.height = height;
    this.frames = [];
    this.repeat = 0;
  }

  /** @param {number} repeat - 0 = infinite loop, N = play N times */
  setRepeat(repeat) {
    this.repeat = repeat;
  }

  /**
   * Add a frame to the animation.
   * @param {Uint8ClampedArray} imageData - RGBA pixel data (width * height * 4 bytes)
   * @param {number} delay - frame delay in milliseconds
   */
  addFrame(imageData, delay) {
    this.frames.push({ data: imageData, delay });
  }

  // CRC32 computation for PNG chunks
  crc32(buffer) {
    const table = ApngEncoder._crcTable();
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < buffer.length; i++) {
      crc = table[(crc ^ buffer[i]) & 0xFF] ^ (crc >>> 8);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  static _crcTable() {
    if (ApngEncoder._crc32Table) return ApngEncoder._crc32Table;
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) {
        c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[i] = c;
    }
    ApngEncoder._crc32Table = table;
    return table;
  }

  /** Create a PNG chunk: 4B length + 4B type + data + 4B CRC32 */
  createChunk(type, data) {
    const length = data ? data.length : 0;
    const chunk = new Uint8Array(length + 12);
    chunk[0] = (length >> 24) & 0xFF;
    chunk[1] = (length >> 16) & 0xFF;
    chunk[2] = (length >> 8) & 0xFF;
    chunk[3] = length & 0xFF;
    for (let i = 0; i < 4; i++) chunk[4 + i] = type.charCodeAt(i);
    if (data) chunk.set(data, 8);
    const crc = this.crc32(chunk.slice(4, 8 + length));
    chunk[8 + length] = (crc >> 24) & 0xFF;
    chunk[8 + length + 1] = (crc >> 16) & 0xFF;
    chunk[8 + length + 2] = (crc >> 8) & 0xFF;
    chunk[8 + length + 3] = crc & 0xFF;
    return chunk;
  }

  // Convert flat RGBA to PNG scanline format (filter byte 0 = None per row)
  preparePixelData(pixels) {
    const { width, height } = this;
    const rowSize = width * 4 + 1;
    const data = new Uint8Array(rowSize * height);
    for (let y = 0; y < height; y++) {
      data[y * rowSize] = 0; // filter: None
      for (let x = 0; x < width; x++) {
        const srcIdx = (y * width + x) * 4;
        const dstIdx = y * rowSize + 1 + x * 4;
        data[dstIdx] = pixels[srcIdx];
        data[dstIdx + 1] = pixels[srcIdx + 1];
        data[dstIdx + 2] = pixels[srcIdx + 2];
        data[dstIdx + 3] = pixels[srcIdx + 3];
      }
    }
    return data;
  }

  // DEFLATE compression via browser/Node CompressionStream API
  async compressDeflate(data) {
    if (typeof CompressionStream !== 'undefined') {
      try {
        const cs = new CompressionStream('deflate-raw');
        const writer = cs.writable.getWriter();
        writer.write(data);
        writer.close();
        const chunks = [];
        const reader = cs.readable.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
        }
        const totalLength = chunks.reduce((sum, c) => sum + c.length, 0);
        const compressed = new Uint8Array(totalLength);
        let offset = 0;
        for (const chunk of chunks) { compressed.set(chunk, offset); offset += chunk.length; }

        // Adler-32 checksum
        let a = 1, b = 0;
        for (let i = 0; i < data.length; i++) {
          a = (a + data[i]) % 65521;
          b = (b + a) % 65521;
        }
        const adler32 = (b << 16) | a;

        // Wrap in zlib container: CMF + FLG + compressed data + Adler-32
        const result = new Uint8Array(2 + compressed.length + 4);
        result[0] = 0x78;
        result[1] = 0x9C;
        result.set(compressed, 2);
        result[2 + compressed.length] = (adler32 >> 24) & 0xFF;
        result[2 + compressed.length + 1] = (adler32 >> 16) & 0xFF;
        result[2 + compressed.length + 2] = (adler32 >> 8) & 0xFF;
        result[2 + compressed.length + 3] = adler32 & 0xFF;
        return result;
      } catch (e) {
        // fall through to 'deflate' format
      }

      try {
        const cs = new CompressionStream('deflate');
        const writer = cs.writable.getWriter();
        writer.write(data);
        writer.close();
        const chunks = [];
        const reader = cs.readable.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
        }
        const totalLength = chunks.reduce((sum, c) => sum + c.length, 0);
        const result = new Uint8Array(totalLength);
        let offset = 0;
        for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.length; }
        return result;
      } catch (e) {
        // fall through to uncompressed fallback
      }
    }

    return this.deflateUncompressed(data);
  }

  // Fallback: chunked uncompressed DEFLATE blocks
  deflateUncompressed(data) {
    const MAX_BLOCK = 65535;
    const numBlocks = Math.ceil(data.length / MAX_BLOCK);
    let totalSize = 2 + numBlocks * 5 + data.length + 4;

    const result = new Uint8Array(totalSize);
    let offset = 0;

    result[offset++] = 0x78; // CMF
    result[offset++] = 0x9C; // FLG

    for (let blockNum = 0; blockNum < numBlocks; blockNum++) {
      const blockStart = blockNum * MAX_BLOCK;
      const blockEnd = Math.min(blockStart + MAX_BLOCK, data.length);
      const blockLen = blockEnd - blockStart;
      const isLast = blockNum === numBlocks - 1;
      const nLen = (~blockLen) & 0xFFFF;

      result[offset++] = isLast ? 0x01 : 0x00;
      result[offset++] = blockLen & 0xFF;
      result[offset++] = (blockLen >> 8) & 0xFF;
      result[offset++] = nLen & 0xFF;
      result[offset++] = (nLen >> 8) & 0xFF;
      result.set(data.slice(blockStart, blockEnd), offset);
      offset += blockLen;
    }

    let a = 1, b = 0;
    for (let i = 0; i < data.length; i++) {
      a = (a + data[i]) % 65521;
      b = (b + a) % 65521;
    }
    const adler32 = (b << 16) | a;
    result[offset++] = (adler32 >> 24) & 0xFF;
    result[offset++] = (adler32 >> 16) & 0xFF;
    result[offset++] = (adler32 >> 8) & 0xFF;
    result[offset++] = adler32 & 0xFF;

    return result;
  }

  /** Create an fcTL (frame control) chunk for APNG */
  createFctlChunk(seq, w, h, xOff, yOff, delayNum, delayDen, disposeOp, blendOp) {
    const data = new Uint8Array(26);
    // sequence number
    data[0] = (seq >> 24) & 0xFF; data[1] = (seq >> 16) & 0xFF;
    data[2] = (seq >> 8) & 0xFF;  data[3] = seq & 0xFF;
    // width, height
    data[4] = (w >> 24) & 0xFF;   data[5] = (w >> 16) & 0xFF;
    data[6] = (w >> 8) & 0xFF;    data[7] = w & 0xFF;
    data[8] = (h >> 24) & 0xFF;   data[9] = (h >> 16) & 0xFF;
    data[10] = (h >> 8) & 0xFF;   data[11] = h & 0xFF;
    // x/y offset
    data[12] = (xOff >> 24) & 0xFF; data[13] = (xOff >> 16) & 0xFF;
    data[14] = (xOff >> 8) & 0xFF;  data[15] = xOff & 0xFF;
    data[16] = (yOff >> 24) & 0xFF; data[17] = (yOff >> 16) & 0xFF;
    data[18] = (yOff >> 8) & 0xFF;  data[19] = yOff & 0xFF;
    // delay (numerator/denominator)
    data[20] = (delayNum >> 8) & 0xFF; data[21] = delayNum & 0xFF;
    data[22] = (delayDen >> 8) & 0xFF; data[23] = delayDen & 0xFF;
    // dispose op, blend op
    data[24] = disposeOp;
    data[25] = blendOp;
    return this.createChunk('fcTL', data);
  }

  /**
   * Encode all frames into an APNG binary.
   * Async — uses CompressionStream for DEFLATE.
   * @returns {Promise<Uint8Array>} APNG file bytes
   */
  async encode() {
    const chunks = [];
    const signature = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]);

    // IHDR
    const ihdrData = new Uint8Array(13);
    ihdrData[0] = (this.width >> 24) & 0xFF;  ihdrData[1] = (this.width >> 16) & 0xFF;
    ihdrData[2] = (this.width >> 8) & 0xFF;   ihdrData[3] = this.width & 0xFF;
    ihdrData[4] = (this.height >> 24) & 0xFF; ihdrData[5] = (this.height >> 16) & 0xFF;
    ihdrData[6] = (this.height >> 8) & 0xFF;  ihdrData[7] = this.height & 0xFF;
    ihdrData[8] = 8;  // bit depth
    ihdrData[9] = 6;  // color type: RGBA
    ihdrData[10] = 0; ihdrData[11] = 0; ihdrData[12] = 0;
    chunks.push(this.createChunk('IHDR', ihdrData));

    if (this.frames.length === 0) {
      chunks.push(this.createChunk('IEND'));
    } else {
      // acTL (animation control)
      const actlData = new Uint8Array(8);
      actlData[0] = (this.frames.length >> 24) & 0xFF;
      actlData[1] = (this.frames.length >> 16) & 0xFF;
      actlData[2] = (this.frames.length >> 8) & 0xFF;
      actlData[3] = this.frames.length & 0xFF;
      actlData[4] = (this.repeat >> 24) & 0xFF;
      actlData[5] = (this.repeat >> 16) & 0xFF;
      actlData[6] = (this.repeat >> 8) & 0xFF;
      actlData[7] = this.repeat & 0xFF;
      chunks.push(this.createChunk('acTL', actlData));

      let seq = 0;

      // First frame: fcTL + IDAT
      const delayNum0 = Math.round(this.frames[0].delay / 10);
      chunks.push(this.createFctlChunk(seq++, this.width, this.height, 0, 0, delayNum0, 100, 1, 0));
      const pixelData0 = this.preparePixelData(this.frames[0].data);
      const compressed0 = await this.compressDeflate(pixelData0);
      chunks.push(this.createChunk('IDAT', compressed0));

      // Subsequent frames: fcTL + fdAT
      for (let i = 1; i < this.frames.length; i++) {
        const frame = this.frames[i];
        const delayNum = Math.round(frame.delay / 10);
        chunks.push(this.createFctlChunk(seq++, this.width, this.height, 0, 0, delayNum, 100, 1, 0));

        const pixelData = this.preparePixelData(frame.data);
        const compressed = await this.compressDeflate(pixelData);

        const fdatData = new Uint8Array(4 + compressed.length);
        fdatData[0] = (seq >> 24) & 0xFF; fdatData[1] = (seq >> 16) & 0xFF;
        fdatData[2] = (seq >> 8) & 0xFF;  fdatData[3] = seq & 0xFF;
        seq++;
        fdatData.set(compressed, 4);
        chunks.push(this.createChunk('fdAT', fdatData));
      }

      chunks.push(this.createChunk('IEND'));
    }

    // Concatenate all chunks
    let totalSize = signature.length;
    for (const chunk of chunks) totalSize += chunk.length;
    const result = new Uint8Array(totalSize);
    let offset = 0;
    result.set(signature, offset);
    offset += signature.length;
    for (const chunk of chunks) {
      result.set(chunk, offset);
      offset += chunk.length;
    }
    return result;
  }
}
