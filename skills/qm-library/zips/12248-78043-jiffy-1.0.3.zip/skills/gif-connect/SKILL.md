---
name: gif-connect
description: 当用户要求"合成GIF"、"生成动图"、"制作APNG"、"图片合成动画"、"多张图片转GIF"、"帧合成APNG"，或提到"GIF编码器"、"APNG编码器"、"动画PNG"、"帧序列动画"时，应使用此技能。提供零依赖的GIF89a和APNG编码器，支持Floyd-Steinberg抖动算法和LZW/DEFLATE压缩。
version: 1.0.0
license: MIT
---

# GIF/APNG 动画编码器

纯 JavaScript 的 GIF89a 和 APNG 编码器。从 RGBA 像素帧合成动画，零外部依赖，浏览器和 Node.js >= 18 均可用。

## 核心能力

### GifEncoder (GIF89a)
- Floyd-Steinberg 误差扩散抖动处理半透明像素（对白色背景混合，alpha < 16 视为透明）
- 自适应颜色量化，每帧最多 256 色，超出时最近欧几里得距离匹配
- LZW 压缩，动态字典最多 4096 条目
- encode() 为**同步**方法

### ApngEncoder (动画 PNG)
- 完整 8 位 RGBA 通道，无颜色损失
- 通过原生 CompressionStream API 进行 DEFLATE 压缩，不可用时自动回退到不压缩块
- CRC32 块完整性校验
- encode() 为**异步**方法

### 格式选择
| 场景 | 推荐 |
|------|------|
| 需要透明度/半透明 | APNG |
| 文件大小优先 | GIF |
| 兼容旧浏览器 | GIF |
| 质量优先 | APNG |
| 需同步生成 | GIF |

## 使用方式

编码器源码位于本技能目录的 `src/` 下：
- `src/gif-encoder.js` — GifEncoder 类，约 280 行
- `src/apng-encoder.js` — ApngEncoder 类，约 310 行

两个文件均为独立、零依赖的 ES 模块。使用时：

1. **读取编码器源码**：根据用户需要的格式，读取对应的 `src/gif-encoder.js` 或 `src/apng-encoder.js`
2. **将编码器写入用户项目**：把文件内容写入用户项目目录（如 `gif-encoder.js`），然后在用户代码中 `import { GifEncoder } from './gif-encoder.js'` 即可使用
3. **编写合成代码**：参考下方示例

编码器 API：

```js
const encoder = new GifEncoder(width, height);
encoder.setRepeat(0);              // 0 = 无限循环
encoder.addFrame(rgbaPixels, 500); // Uint8ClampedArray, 延时(毫秒)
const bytes = encoder.encode();    // GifEncoder: 同步返回 Uint8Array
// const bytes = await encoder.encode(); // ApngEncoder: 异步
```

### 浏览器场景

通过 Canvas 获取 ImageData，送入编码器：

```js
import { GifEncoder } from './gif-encoder.js';

const canvas = document.createElement('canvas');
canvas.width = maxWidth;
canvas.height = maxHeight;
const ctx = canvas.getContext('2d');

const encoder = new GifEncoder(maxWidth, maxHeight);
encoder.setRepeat(0);

for (const img of images) {
  ctx.clearRect(0, 0, maxWidth, maxHeight);
  const ox = Math.floor((maxWidth - img.width) / 2);
  const oy = Math.floor((maxHeight - img.height) / 2);
  ctx.drawImage(img, ox, oy);
  encoder.addFrame(ctx.getImageData(0, 0, maxWidth, maxHeight).data, 500);
}

const blob = new Blob([encoder.encode()], { type: 'image/gif' });
const url = URL.createObjectURL(blob);
```

### Node.js 场景

需安装 `sharp` 解码图片（`npm install sharp`），sharp 不是编码器本身的依赖：

```js
import { GifEncoder } from './gif-encoder.js';
import sharp from 'sharp';
import fs from 'fs';

async function makeGif(framePaths, delays) {
  const first = await sharp(framePaths[0]).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width, height } = first.info;

  const encoder = new GifEncoder(width, height);
  encoder.setRepeat(0);

  for (let i = 0; i < framePaths.length; i++) {
    const { data } = await sharp(framePaths[i])
      .resize(width, height, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
      .ensureAlpha().raw().toBuffer({ resolveWithObject: true });
    encoder.addFrame(new Uint8ClampedArray(data), delays[i] || 500);
  }

  fs.writeFileSync('output.gif', encoder.encode());
}
```

## 边界情况

- **帧尺寸不一致**：以最大宽高创建编码器，将较小帧居中绘制
- **GIF 半透明**：Floyd-Steinberg 自动将半透明像素与白色背景混合
- **GIF 调色板溢出**（>256 色）：自动最近颜色匹配，照片类内容建议用 APNG
- **CompressionStream 不可用**（Node.js < 18）：APNG 自动回退到不压缩，输出变大但不报错

## 附加资源

- **`references/api-reference.md`** — 完整 API 参考，含 TypeScript 类型签名和所有边界情况
- **`examples/browser.html`** — 浏览器演示页面，生成四色方块动画
- **`examples/node-example.js`** — Node.js 命令行示例，将图片序列转换为 GIF/APNG
