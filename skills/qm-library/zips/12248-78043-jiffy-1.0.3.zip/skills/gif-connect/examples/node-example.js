/**
 * Node.js example: create a GIF from local image files.
 *
 * Usage:
 *   node examples/node-example.js frame1.png frame2.png frame3.png
 *
 * Requires: npm install sharp
 */

import { GifEncoder, ApngEncoder } from '../index.js';
import sharp from 'sharp';
import fs from 'fs';

async function createGif(framePaths, delays, outputPath) {
  const first = await sharp(framePaths[0]).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width, height } = first.info;

  const encoder = new GifEncoder(width, height);
  encoder.setRepeat(0);

  for (let i = 0; i < framePaths.length; i++) {
    const { data } = await sharp(framePaths[i])
      .resize(width, height, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
      .ensureAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });

    encoder.addFrame(new Uint8ClampedArray(data), delays[i] || 500);
  }

  fs.writeFileSync(outputPath, encoder.encode());
  console.log(`GIF saved: ${outputPath} (${fs.statSync(outputPath).size} bytes)`);
}

async function createApng(framePaths, delays, outputPath) {
  const first = await sharp(framePaths[0]).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width, height } = first.info;

  const encoder = new ApngEncoder(width, height);
  encoder.setRepeat(0);

  for (let i = 0; i < framePaths.length; i++) {
    const { data } = await sharp(framePaths[i])
      .resize(width, height, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
      .ensureAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });

    encoder.addFrame(new Uint8ClampedArray(data), delays[i] || 500);
  }

  const bytes = await encoder.encode();
  fs.writeFileSync(outputPath, bytes);
  console.log(`APNG saved: ${outputPath} (${fs.statSync(outputPath).size} bytes)`);
}

// CLI: node node-example.js frame1.png frame2.png ...
const args = process.argv.slice(2);
if (args.length < 2) {
  console.log('Usage: node node-example.js <frame1> <frame2> [...]');
  console.log('Output: output.gif and output.apng');
  process.exit(1);
}

const delays = args.map(() => 500);
await createGif(args, delays, 'output.gif');
await createApng(args, delays, 'output.apng');
