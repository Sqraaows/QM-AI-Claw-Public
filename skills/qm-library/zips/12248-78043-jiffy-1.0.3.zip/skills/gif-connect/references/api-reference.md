# API Reference — gif-connect

Complete TypeScript signatures and behavioral details for both encoder classes.

---

## `GifEncoder`

### Constructor

```ts
new GifEncoder(width: number, height: number)
```

- `width`, `height`: dimensions in pixels. All frames must use these dimensions.
- Internally initializes empty frame list and `repeat = 0`.

### `setRepeat(repeat: number): void`

Set loop behavior for the animated GIF.

| Value | Behavior |
|-------|----------|
| `0` | Loop forever |
| `1` | Play once (no loop) |
| `2..N` | Play N times, then stop |

Must be called before `encode()`. Default is `0`.

### `addFrame(imageData: Uint8ClampedArray, delayMs: number): void`

Append a frame to the animation.

- **`imageData`**: RGBA pixel data. Length must equal `width * height * 4`. Each pixel is 4 consecutive bytes: `[R, G, B, A]`, values 0-255.
- **`delayMs`**: Frame display duration in **milliseconds**. Internally converted to GIF units (1/100 second). Minimum effective resolution is 10ms.
- Frames are encoded in the order they are added.

### `encode(): Uint8Array`

Encode all added frames into a GIF89a binary.

- **Synchronous** — no I/O or async operations.
- Returns the complete GIF file as `Uint8Array`, ready to write to disk or wrap in `Blob`.
- Per-frame operations: Floyd-Steinberg dithering → color quantization (256 colors) → LZW compression.
- Throws if no frames were added (empty frame list).

### Encoding Pipeline (per frame)

1. **Dithering**: Semi-transparent pixels are blended against white background using Floyd-Steinberg error diffusion. Quantization error from each pixel is distributed to right, bottom-left, bottom, and bottom-right neighbors at 7/16, 3/16, 5/16, 1/16 ratios.
2. **Quantization**: Colors reduced to a 256-entry palette. The RGB space is quantized to 5 bits per channel (0xF8 mask). When palette exceeds 256 entries, closest Euclidean match is used.
3. **LZW Compression**: Dictionary-based lossless compression with 4096-entry limit. Dictionary reset on overflow.
4. **Assembly**: GIF89a header → global color table → Netscape loop extension → per-frame graphic control + image descriptor + LZW data → trailer (0x3B).

### GIF File Size Factors

- **Color complexity**: Fewer unique colors = better LZW compression
- **Frame count**: Each frame adds a local color table (768 bytes) + compressed pixel data
- **Dithering noise**: Floyd-Steinberg adds high-frequency detail that LZW compresses less efficiently than flat color regions

---

## `ApngEncoder`

### Constructor

```ts
new ApngEncoder(width: number, height: number)
```

Same interface as `GifEncoder`.

### `setRepeat(repeat: number): void`

Same semantics as `GifEncoder.setRepeat()`.

Internally stored as 32-bit unsigned integer in the `acTL` chunk.

### `addFrame(imageData: Uint8ClampedArray, delayMs: number): void`

Same interface as `GifEncoder.addFrame()`.

- APNG delay precision: numerator stored in 16-bit, denominator fixed at 100. Internally uses `Math.round(delayMs / 10)` to convert ms to APNG delay units.
- No pre-processing on `imageData` — full RGBA is preserved.

### `encode(): Promise<Uint8Array>`

Encode all frames into an APNG binary.

- **Asynchronous** — DEFLATE compression uses the browser/Node `CompressionStream` API.
- Returns the complete APNG file as `Uint8Array`.
- Chunk structure: PNG signature → IHDR → acTL → (fcTL + IDAT) × 1 + (fcTL + fdAT) × (N-1) → IEND.

### Compression Strategy

1. **Primary**: `CompressionStream('deflate-raw')` — raw DEFLATE stream wrapped in zlib container (0x78 0x9C header + Adler-32 trailer). Available in all modern browsers and Node.js >= 18.
2. **Fallback 1**: `CompressionStream('deflate')` — zlib-wrapped DEFLATE. Used when `deflate-raw` format is not supported.
3. **Fallback 2**: Uncompressed DEFLATE blocks — each 65535-byte chunk stored as a non-compressed DEFLATE block (BTYPE=00) with LEN/NLEN headers. Guaranteed to work everywhere but produces larger output.

### CRC32

All PNG chunks include a CRC32 checksum over the chunk type + data bytes. The CRC32 table is lazily initialized (256 × 32-bit values, shared across all ApngEncoder instances via static cache).

### APNG File Size Factors

- **Frame dimensions × 4 bytes** per pixel, plus filter byte per row
- **Compression ratio** depends on content complexity (similar to PNG)
- **No color quantization loss** — preserves exact RGBA values
- When CompressionStream is unavailable, fallback uncompressed output is ~2× the raw pixel data size

---

## Shared Patterns

### Frame Dimensions

Both encoders require that all frames have the same dimensions as the constructor. To handle differently-sized source images:

1. Determine `maxWidth`, `maxHeight` across all input images
2. Create encoder with those dimensions
3. For each frame, draw the source image centered on a canvas of encoder dimensions
4. Extract `ImageData` from the full canvas

```js
const w = Math.max(...images.map(i => i.width));
const h = Math.max(...images.map(i => i.height));
const enc = new GifEncoder(w, h);

for (const img of images) {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  const ox = Math.floor((w - img.width) / 2);
  const oy = Math.floor((h - img.height) / 2);
  ctx.drawImage(img, ox, oy);
  enc.addFrame(ctx.getImageData(0, 0, w, h).data, 500);
}
```

### Creating a Blob for Download (Browser)

```js
// GIF
const blob = new Blob([encoder.encode()], { type: 'image/gif' });

// APNG
const blob = new Blob([await encoder.encode()], { type: 'image/png' });

// Trigger download
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = 'animation.' + (isApng ? 'png' : 'gif');
a.click();
URL.revokeObjectURL(url);
```

### Writing to Disk (Node.js)

```js
import { writeFileSync } from 'fs';

// GIF (sync)
writeFileSync('output.gif', encoder.encode());

// APNG (async)
writeFileSync('output.png', await encoder.encode());
```

---

## Error Conditions

| Condition | Behavior |
|-----------|----------|
| `encode()` with 0 frames | Returns valid GIF/APNG with no image data (GIF: header + trailer only; APNG: IHDR + IEND) |
| Frame count > 256 in GIF palette | Closest-match Euclidean distance fallback; quality degradation |
| `CompressionStream` unavailable (APNG) | Falls back to uncompressed DEFLATE silently; larger output |
| `addFrame()` with wrong-length `imageData` | Undefined behavior (LZW/quantizer reads out of bounds) |
| NaN/Infinity delay | `Math.round()` coerces to 0; frame may not display long enough |
