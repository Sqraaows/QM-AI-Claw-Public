## Description: <br>
Manages Google Calendar events and Google Meet spaces through gogcli, including scheduling, event updates, invitation responses, Meet space creation, conference ending, and history or participant lookups. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to connect a local MCP server to gogcli for Google Calendar and Google Meet workflows such as scheduling, event maintenance, invitation responses, and meeting administration. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can delete or modify Google Calendar events. <br>
Mitigation: Confirm the calendar, event identifier, date, attendees, and requested action before allowing create, update, delete, or response operations. <br>
Risk: The skill can end active Google Meet conferences and retrieve meeting participant or call history. <br>
Mitigation: Confirm the Meet space or conference code and limit participant or history output to authorized users and contexts. <br>
Risk: The skill operates through an authenticated gogcli account. <br>
Mitigation: Use the intended GOG_ACCOUNT value and an account whose calendar and meeting permissions match the agent's expected scope. <br>


## Reference(s): <br>
- [ClawHub package page](https://clawhub.ai/chrischall/gogcli-mcp-calendar) <br>
- [Publisher profile](https://clawhub.ai/user/chrischall) <br>
- [gogcli project](https://github.com/openclaw/gogcli) <br>
- [gogcli MCP project](https://github.com/chrischall/gogcli-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline JSON and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May guide agents to invoke MCP tools that operate on authenticated Google Calendar and Meet data.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
