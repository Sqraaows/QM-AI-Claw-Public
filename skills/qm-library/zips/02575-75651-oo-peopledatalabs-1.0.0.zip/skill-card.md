## Description: <br>
People Data Labs (peopledatalabs.com). Use this skill for People Data Labs requests involving search, company enrichment, and person enrichment through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and analysts use this skill to search People Data Labs company and person datasets and enrich a single company or person record through the OOMOL `oo` CLI connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Search and enrichment payloads can contain personal or business-identifying data. <br>
Mitigation: Use the skill only with data the user is authorized to process through People Data Labs and the connected OOMOL account. <br>
Risk: Connector calls may incur People Data Labs or OOMOL service and billing usage. <br>
Mitigation: Confirm the intended query or enrichment target before running actions likely to consume paid service credits. <br>
Risk: The skill depends on sensitive account credentials managed through OOMOL. <br>
Mitigation: Install and run it only when the OOMOL publisher and connected People Data Labs account are trusted. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-peopledatalabs) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [People Data Labs Homepage](https://www.peopledatalabs.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payload expectations] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill guides agents to inspect live connector schemas before execution and to use JSON payloads and JSON responses for People Data Labs connector actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
