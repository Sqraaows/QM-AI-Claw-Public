## Description: <br>
HTML to Image helps an agent use an OOMOL-connected HTML to Image account to convert raw HTML and CSS into images or capture public webpages as screenshots. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to generate image URLs from supplied HTML/CSS or public webpage URLs through the HTML to Image service, using an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: HTML-to-image jobs are routed through OOMOL and may contain user-provided HTML, CSS, or public webpage URLs. <br>
Mitigation: Use the skill only when that service trust boundary is acceptable, and avoid submitting sensitive content unless the account and service use are approved. <br>
Risk: First-time setup may require installing the oo CLI with a curl-to-bash or PowerShell installer command. <br>
Mitigation: Review the installer source and trust boundary before running the setup command, as recommended by the security guidance. <br>


## Reference(s): <br>
- [HTML to Image homepage](https://html2img.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-html-to-image) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command responses containing generated image or screenshot URLs.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an authenticated OOMOL account, and a connected HTML to Image service account.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
