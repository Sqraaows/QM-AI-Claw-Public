## Description: <br>
Hyperbrowser helps agents search the web, fetch pages, and run crawl workflows through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to search the web, fetch page content, and manage Hyperbrowser crawl jobs through the oo CLI after connecting a Hyperbrowser account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on a connected Hyperbrowser account and may require sensitive credentials through OOMOL. <br>
Mitigation: Use the trusted OOMOL account connection flow and avoid exposing raw Hyperbrowser API tokens. <br>
Risk: First-time setup may involve remote shell install commands for the oo CLI. <br>
Mitigation: Prefer official, verifiable oo CLI installation steps and inspect install commands before running them. <br>
Risk: Crawl and page-fetch actions can access external web content or start asynchronous jobs. <br>
Mitigation: Inspect the live action schema and confirm payloads before running actions that create, update, send, post, delete, or remove data. <br>


## Reference(s): <br>
- [Hyperbrowser homepage](https://www.hyperbrowser.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands inspect live connector schemas and return JSON responses from Hyperbrowser actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
