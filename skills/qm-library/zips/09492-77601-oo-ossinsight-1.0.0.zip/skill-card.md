## Description: <br>
OSS Insight (ossinsight.io) lets agents search and read open-source GitHub analytics through the OOMOL ossinsight connector instead of calling the service API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, maintainers, and analysts use this skill to inspect OSS Insight repository collections, trending repositories, contributor histories, and audience breakdowns by country or organization. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on the OOMOL oo CLI and may fail in environments where the CLI is not installed or the user is not signed in. <br>
Mitigation: Run the documented first-time setup only after a command fails for a missing CLI or authentication reason. <br>
Risk: Connector schemas and returned data come from the remote OSS Insight service and can change over time. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each payload. <br>
Risk: Analytics results may be incomplete, stale, or shaped by upstream OSS Insight data coverage. <br>
Mitigation: Treat returned analytics as service-provided evidence and verify important conclusions against the live response metadata or additional sources. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ossinsight) <br>
- [OSS Insight homepage](https://ossinsight.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, API Calls, JSON] <br>
**Output Format:** [Markdown guidance with shell commands that return JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses are returned by the remote connector as data plus execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
