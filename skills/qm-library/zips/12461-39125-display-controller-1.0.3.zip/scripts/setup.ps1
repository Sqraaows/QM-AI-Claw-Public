# 获取脚本所在的目录（即 <skill_root>/scripts/）
$scriptDir = $PSScriptRoot
# 目标 exe 文件路径（同一目录下）
$exePath = Join-Path $scriptDir "DisplayControlSkill.exe"

if (-not (Test-Path $exePath)) {
    # 确保目录存在（其实已经存在，但为保险起见）
    New-Item -ItemType Directory -Force -Path $scriptDir | Out-Null
    Write-Output "Downloading DisplayControlSkill.exe to $exePath ..."
    Invoke-WebRequest -Uri 'https://github.com/society2012/DisplayControlTool/releases/download/tag002/DisplayControlSkill.exe' -OutFile $exePath -UseBasicParsing
    Write-Output "Download completed."
} else {
    Write-Output "EXE already exists at $exePath"
}