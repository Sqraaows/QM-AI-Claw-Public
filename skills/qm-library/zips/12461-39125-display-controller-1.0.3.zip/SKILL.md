---
name: display-controller
description: 显示器控制工具。当用户询问显示器信息、调整亮度/对比度、查询显示器状态、关闭/打开显示器时使用此技能。支持子命令模式，可管理多个显示器。
---

# 显示器控制工具 (DisplayControl)

完整的显示器管理和控制工具，支持获取信息、调整设置等功能。


## 使用说明

在运行此技能前，请确保已下载所需的控制台工具。

AI 应执行以下操作DisplayControlSkill.exe不存在要下载，存在不下载（仅一次）：
- 如果 `scripts/DisplayControlSkill.exe` 不存在，运行 `scripts/setup.ps1`（Windows）或等效脚本，从 https://github.com/society2012/DisplayControlTool/releases/download/tag002/DisplayControlSkill.exe 下载该工具。
- 后续调用该 EXE 获取 JSON 输出。


## 使用方法（子命令模式）

### 基本语法

```bash
# 使用 exec 工具调用
exec: scripts/DisplayControlSkill.exe <command> [options]
```

### 支持的命令

| 命令 | 参数 | 说明 |
|------|------|------|
| `get_monitor_base_info` | `<index>` | 获取显示器的基本信息 |
| `set_monitor_power_mode` | `<index> <mode>` | 设置显示器的电源模式 |
| `get_monitor_power_mode` | `<index>` | 获取显示器的电源模式 |
| `set_monitor_power_off` | `<index>` | 关闭显示器 |
| `set_monitor_power_on` | `<index>` | 打开显示器 |
| `get_monitor_sn` | `<index>` | 获取显示器的sn |
| `get_monitor_mt` | `<index>` | 获取显示器的制作商标识符|
| `get_monitor_fw_version` | `<index>` | 获取显示器的固件版本号 |
| `get_monitor_sync_technology_name` | `<index>` | 获取显示器的同步技术名称 |
| `get_monitor_panel_size` | `<index>` | 获取显示器的尺寸 |
| `get_monitor_resolution` | `<index>` | 获取显示器的分辨率 |
| `get_monitor_manufacturer` | `<index>` | 获取显示器的制作商 |
| `get_monitor_count` | `<index>` | 获取连接显示器的个数 |
| `get_monitor_feature_count` | `<index>` | 获取显示器支持的功能个数 |
| `get_monitor_feature_list` | `<index>` | 获取显示器支持的功能列表 |
| `get_monitor_feature_by_index` | `<index> <featureIndex>` | 获取显示器的某个功能详情 |
| `get_monitor_name` | `<index>` | 获取显示器的名称 |
| `get_monitor_brightness` | `<index>` | 获取显示器的亮度 |
| `set_monitor_brightness` | `<index> <value>` | 设置显示器的亮度（0-100） |
| `get_monitor_max_freq` | `<index>` | 获取显示器的最大刷新率 |
| `help` | 无 | 其他command查看帮助信息 |

### 命令示例

```bash
# 获取显示器数量
exec: scripts/DisplayControlSkill.exe get_monitor_count

# 获取指定显示器支持的功能列表
exec: scripts/DisplayControlSkill.exe get_monitor_base_info 0

# 获取第 1 个显示器（索引 0）的详细信息
exec: scripts/DisplayControlSkill.exe get_monitor_base_info 0

# 设置亮度
exec: scripts/DisplayControlSkill.exe set_monitor_brightness 0 80

# 设置电源模式 (0=On, 1=Standby, 2=Suspend, 3=PowerDown)
exec: scripts/DisplayControlSkill.exe set_monitor_power_mode 0 1
```

## 输出格式（JSON）

### 成功响应示例

**count 命令:**
```json
{
  "success": true,
  "message": "Success",
  "command": "get_monitor_count",
  "data": 1,
  "timestamp": "2026-04-24 15:14:38"
}
```

### 错误响应示例

```json
{
  "success": false,
  "command": "get_monitor_count",
  "data": 0,
  "timestamp": "2026-04-24 15:14:38"
}
```

## 使用场景

| 用户问题 | 对应命令 |
|----------|----------|
| "我连接了几台显示器？" | `get_monitor_count` |
| "显示器支持哪些功能" | `get_monitor_feature_list 0` |
| "显示器的基本信息是什么" | `get_monitor_base_info 0` |
| "当前亮度是多少？" | `get_monitor_brightness 0` |
| "把亮度调到 80" | `set_monitor_brightness 0 80` |

## 参数说明

### 显示器索引 (index)
- 从 0 开始计数
- `0` = 第 1 个显示器
- `1` = 第 2 个显示器
- 以此类推

### 功能index (featureIndex)
- 范围：0-200
- 自动裁剪超出范围的值

### 亮度/对比度 (value)
- 范围：0-100
- 自动裁剪超出范围的值

### 电源模式 (mode)
| 值 | 模式 | 说明 |
|----|------|------|
| 0 | On | 开启 |
| 1 | Standby | 待机 |
| 2 | Suspend | 挂起 |
| 3 | PowerDown | 关机 |
