## Description: <br>
BugBug helps agents search, read, and run test-related data in BugBug through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and QA engineers use this skill to inspect BugBug tests, suites, run profiles, and historical test runs from a connected BugBug workspace, and to run BugBug tests when explicitly requested. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The security review flags a mismatch between the read/search listing and the ability to run BugBug tests through a credentialed account. <br>
Mitigation: Use the skill for explicit BugBug tasks only, and require clear user confirmation before running tests or any action that can consume resources or change BugBug state. <br>
Risk: The skill requires sensitive credentials through the connected OOMOL account. <br>
Mitigation: Review access before installation in production or credit-sensitive BugBug workspaces and use the documented setup flow only when authentication or connection errors occur. <br>


## Reference(s): <br>
- [BugBug homepage](https://bugbug.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-bugbug) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May trigger live BugBug connector calls through a credentialed OOMOL account when the agent executes the documented commands.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
