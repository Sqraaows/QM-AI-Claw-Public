## Description: <br>
OCR.space helps an agent extract text from images and retrieve OCR.space conversion statistics through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents use this skill to operate OCR.space through an OOMOL-connected account, extracting text from public image URLs or Base64 uploads and checking monthly conversion statistics without handling raw OCR.space credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Fallback setup may run remote oo CLI installer scripts without checksum verification. <br>
Mitigation: Install the oo CLI through a trusted channel or review the installer source before allowing fallback setup. <br>
Risk: OCR requests may route image contents through OCR.space and the OOMOL connector. <br>
Mitigation: Avoid sending sensitive images unless OCR.space and OOMOL handling are acceptable for the data. <br>


## Reference(s): <br>
- [OCR.space homepage](https://ocr.space) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ocrspace) <br>


## Skill Output: <br>
**Output Type(s):** [text, JSON, shell commands, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill asks the agent to inspect the live connector schema before sending an action payload.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
