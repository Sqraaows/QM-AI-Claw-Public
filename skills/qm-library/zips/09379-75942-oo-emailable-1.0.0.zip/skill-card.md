## Description: <br>
Uses the OOMOL Emailable connector to verify email addresses, create and check batch verification jobs, and retrieve account information through the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to operate Emailable through an OOMOL-connected account for single email verification, batch verification workflows, batch status retrieval, and account credit lookup. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Batch verification can submit bulk email data to Emailable and create a verification job. <br>
Mitigation: Require explicit confirmation of the payload and expected effect before creating batch verification jobs or submitting bulk email data. <br>
Risk: The first-time setup path includes a remote oo CLI installer command. <br>
Mitigation: Review the installer before running it and use setup commands only when the CLI is missing or authentication fails. <br>
Risk: Live connector schemas can change upstream. <br>
Mitigation: Inspect the authoritative connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-emailable) <br>
- [Emailable homepage](https://emailable.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_account_info action](actions/get_account_info.md) <br>
- [get_batch_status action](actions/get_batch_status.md) <br>
- [verify_batch_emails action](actions/verify_batch_emails.md) <br>
- [verify_email action](actions/verify_email.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API calls, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to inspect the live connector schema before constructing payloads and returns connector responses as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
