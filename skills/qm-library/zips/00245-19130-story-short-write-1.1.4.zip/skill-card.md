## Description: <br>
Helps writers plan, draft, revise, and quality-check Chinese short web fiction with emphasis on emotional pacing, hooks, reversals, and platform-style manuscript structure. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External writers and content teams use this skill to turn a short-fiction idea into a structured outline, scene plan, and polished Chinese web-novel draft. It is most useful when the user wants guidance on emotional arcs, genre conventions, reversals, hooks, formatting, and manuscript quality checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can actively create and revise local story draft files. <br>
Mitigation: Use a dedicated project folder and review target paths before allowing writes or reruns. <br>
Risk: Built-in genre, gender, or political assumptions may not match the intended story. <br>
Mitigation: Explicitly override those assumptions in the prompt and review drafts before publication. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/worldwonderer/story-short-write) <br>
- [Publisher profile](https://clawhub.ai/user/worldwonderer) <br>
- [OpenClaw source metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [Skill definition](SKILL.md) <br>
- [Writing workflow](references/writing-workflow.md) <br>
- [Format and structure](references/format-and-structure.md) <br>
- [Writing craft](references/writing-craft.md) <br>
- [Genre catalog](references/genre-catalog.md) <br>
- [Output contract](references/output-contract.md) <br>
- [Quality checklist](references/quality-checklist.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, files, guidance] <br>
**Output Format:** [Markdown prose and local draft files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May create or revise story project files such as settings, outline, and manuscript drafts.] <br>

## Skill Version(s): <br>
1.1.4 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
