## Description: <br>
ERPNext (erpnext.com). Use this skill for reading, creating, updating, and deleting ERPNext documents through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external operators, and developers use this skill to inspect, list, create, update, and delete ERPNext records through the configured OOMOL ERPNext connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, or set values on ERPNext records, which may affect real business or financial data. <br>
Mitigation: Review the exact payload and intended effect with the user before running write actions. <br>
Risk: The delete action can remove ERPNext documents. <br>
Mitigation: Confirm the target DocType and document name, then obtain explicit user approval before deletion. <br>
Risk: The skill requires access to an OOMOL-connected ERPNext account. <br>
Mitigation: Install and use it only when the user intends the agent to operate that ERPNext account through OOMOL. <br>


## Reference(s): <br>
- [ERPNext homepage](https://erpnext.com) <br>
- [ClawHub ERPNext skill page](https://clawhub.ai/oomol/oo-erpnext) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Agent output may include ERPNext command results, including JSON data and meta.executionId values returned by the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
