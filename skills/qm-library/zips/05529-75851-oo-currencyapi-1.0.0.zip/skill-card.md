## Description: <br>
Use currencyapi through an OOMOL-connected account to retrieve exchange-rate data, convert amounts, inspect supported currencies, and check account quota status. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill when they need currencyapi data without handling raw API tokens directly. It supports currency conversion, latest and historical exchange rates, supported-currency metadata, and quota status checks through the oo CLI connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: First-time setup may fetch and execute a remote oo CLI installer script. <br>
Mitigation: Install only from OOMOL's trusted instructions or another trusted installation method before using the connector. <br>
Risk: Connector actions use the user's OOMOL-connected currencyapi account and may consume quota or require valid credentials. <br>
Mitigation: Confirm the account connection and intended request payload before running actions that affect quota, billing, or account usage. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-currencyapi) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [currencyapi homepage](https://currencyapi.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
