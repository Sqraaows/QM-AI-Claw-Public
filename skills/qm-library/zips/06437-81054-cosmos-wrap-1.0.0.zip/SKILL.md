---
name: NVIDIA Cosmos 物理AI开发套件
slug: cosmos-wrap
description: NVIDIA Cosmos 物理 AI 开发套件 — 专注于机器人仿真、自动驾驶、智能基础设施等领域的物理 AI 世界模型平台。基于 NVIDIA 开源项目封装，普通开发者无需高端 GPU 即可体验物理模拟。支持 Manipulator、Humanoid、Quadruped 等多种机器人类型，提供 Jupyter Notebook 快速入门示例、Docker 环境一键部署、Python API 封装等增强功能。适用于 AI 研究者、机器人工程师、自动驾驶开发者等场景。 | 来源：https://github.com/q15004040209-creator/cosmos-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/cosmos-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
