# 🌐 cosmos-wrap

> 基于 [NVIDIA Cosmos](https://github.com/NVIDIA/cosmos) 的物理 AI 开发套件封装 — 机器人仿真、自动驾驶、智能基础设施的**世界模型平台**，普通开发者也能玩转 NVIDIA 级物理模拟。

## 🎯 是什么

NVIDIA Cosmos 是开源的物理 AI 世界模型平台：
- 🤖 **机器人仿真**：支持 Manipulator、Humanoid、Quadruped 等机器人类型
- 🚗 **自动驾驶**：交通场景仿真、传感器模拟
- 🏗️ **智能基础设施**：城市级物理仿真
- 🧠 **世界模型**：基于 Transformer 的物理规律预测

cosmos-wrap 在原版基础上增加：
- ✅ **Jupyter Notebook 快速入门**（拿过来就能跑）
- ✅ **Docker 环境配置**（无需配 CUDA 环境）
- ✅ **Python API 封装**（简化核心调用）
- ✅ **中文注释 + 示例**

## 🚀 快速开始

### 方式一：Jupyter Notebook（推荐，10分钟上手）

```bash
# 克隆项目
git clone https://github.com/q15004040209-creator/cosmos-wrap.git
cd cosmos-wrap

# 启动 Jupyter 环境
docker run --gpus all -p 8888:8888 -p 6006:6006 \
  -v $(pwd):/workspace \
  nvcr.io/nvidia/pytorch:24.01-py3-jupyter

# 打开 http://localhost:8888
# 运行 notebooks/01_quickstart.ipynb
```

### 方式二：Docker 完整环境

```bash
docker-compose up -d
# 包含：PyTorch + CUDA + Cosmos + JupyterLab + TensorBoard
```

## 📊 项目结构

```
cosmos-wrap/
├── README.md
├── notebooks/               # Jupyter Notebooks
│   ├── 01_quickstart.ipynb       # 快速入门
│   ├── 02_robot_simulation.ipynb # 机器人仿真
│   ├── 03_autonomous_driving.ipynb # 自动驾驶
│   └── 04_world_model.ipynb      # 世界模型
├── cosmos_api/              # Python API 封装
│   ├── __init__.py
│   ├── simulator.py         # 仿真器封装
│   ├── world_model.py       # 世界模型封装
│   └── data_loader.py       # 数据加载
├── docker/                  # Docker 配置
│   └── Dockerfile
└── docs/
    ├── QUICKSTART.md
    └── API.md
```

## 🧪 核心示例

### 1. 快速仿真（5行代码）

```python
from cosmos_api import RobotSimulator

# 创建机器人仿真器
sim = RobotSimulator(
    robot_type="manipulator",  # manipulator | humanoid | quadruped
    gpu_id=0
)

# 加载预训练策略
sim.load_policy("cosmos_policy_pick_and_place.pt")

# 运行仿真
result = sim.run(
    num_envs=100,    # 并行环境数
    max_steps=500,   # 每环境最大步数
)

print(f"成功率: {result.success_rate:.1%}")
print(f"平均用时: {result.avg_time:.2f}s")
```

### 2. 世界模型预测

```python
from cosmos_api import WorldModel

# 初始化世界模型
wm = WorldModel(model_name="cosmos-1.0-diffusion-xl")

# 给定当前帧，预测未来5帧
current_frame = "/path/to/robot_camera_frame.png"
future_frames = wm.predict(
    current_frame,
    num_frames=5,
    seed=42
)

# 保存预测结果
for i, frame in enumerate(future_frames):
    frame.save(f"predicted_frame_{i:02d}.png")
```

### 3. 数据加载

```python
from cosmos_api import CosmosDataset

# 加载官方数据集
dataset = CosmosDataset(
    split="train",
    task="robot_pick_and_place",
    download=True  # 自动下载
)

# 获取数据样本
sample = dataset[0]
print(f"观测: {sample['observation'].shape}")   # (H, W, C)
print(f"动作: {sample['action'].shape}")        # (7,) for 7-DOF arm
print(f"奖励: {sample['reward']}")               # scalar
```

## 🐳 Docker 环境

```dockerfile
FROM nvcr.io/nvidia/pytorch:24.01-py3

# 安装 Cosmos
RUN pip install cosmos-sdk

# 预下载模型
RUN cosmos download --model=cosmos-1.0-diffusion-xl
```

## 📋 系统要求

| 组件 | 最低要求 | 推荐 |
|------|---------|------|
| GPU | NVIDIA RTX 3090 | A100 或 H100 |
| 显存 | 16GB | 24GB+ |
| 内存 | 32GB | 64GB |
| CUDA | 12.1+ | 12.4 |
| Python | 3.10+ | 3.11 |

## 📄 许可证

基于 NVIDIA 开放许可，部分模型有额外许可条款，请查阅 [Cosmos 许可证](https://github.com/NVIDIA/cosmos/blob/main/LICENSE)。

## 🔗 链接

- 原始项目：https://github.com/NVIDIA/cosmos
- 模型下载：https://huggingface.co/nvidia/cosmos
- 官方文档：https://cosmos нейронная.platform.dev/
