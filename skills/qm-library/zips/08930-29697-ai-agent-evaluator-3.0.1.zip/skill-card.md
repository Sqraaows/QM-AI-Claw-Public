## Description: <br>
AI-powered agent evaluation and benchmarking assistant that helps teams design evaluation suites, run structured assessments, compare agent frameworks, generate benchmark reports, and choose evaluation methodology. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[gechengling](https://clawhub.ai/user/gechengling) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, AI engineers, ML platform teams, product managers, and QA teams use this skill to evaluate agent reliability, safety, latency, task completion, framework fit, and production readiness. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Conversation samples, agent logs, and failed task transcripts can contain personal data, customer details, credentials, regulated information, or proprietary business content. <br>
Mitigation: Redact sensitive information before using real transcripts; prefer synthetic or minimized examples when possible. <br>
Risk: Benchmark scores and framework comparisons may become outdated. <br>
Mitigation: Check current published leaderboards and framework documentation before making production decisions. <br>
Risk: Evaluation results may be misapplied as final production approval. <br>
Mitigation: Have qualified ML engineers and the appropriate security team review production safety evaluations and readiness decisions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/gechengling/ai-agent-evaluator) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, analysis, configuration] <br>
**Output Format:** [Markdown guidance with tables, rubrics, scorecards, recommendations, and text diagrams] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only guidance; does not execute code or tools directly.] <br>

## Skill Version(s): <br>
3.0.1 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
