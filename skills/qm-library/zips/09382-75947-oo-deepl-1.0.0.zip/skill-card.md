## Description: <br>
DeepL lets an agent operate the DeepL connector through an OOMOL-connected account to translate text, list supported languages, and check API usage. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, employees, and external users use this skill to perform DeepL translation tasks through OOMOL's connector without directly handling raw API tokens. It supports translating text, discovering supported languages, and retrieving usage or quota counters for the connected DeepL API key. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Translation text and usage requests are sent through OOMOL's DeepL connector. <br>
Mitigation: Review payloads before translating sensitive text and install the skill only when this connector path is acceptable. <br>
Risk: The skill requires a connected OOMOL and DeepL account with server-side credential handling. <br>
Mitigation: Run login or connection setup only after an authentication or connection error, and confirm that the intended DeepL account is connected. <br>
Risk: Live connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the action schema with `oo connector schema` before constructing payloads. <br>


## Reference(s): <br>
- [ClawHub DeepL skill page](https://clawhub.ai/oomol/oo-deepl) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [DeepL homepage](https://www.deepl.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId fields when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
