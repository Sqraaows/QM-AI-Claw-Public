## Description: <br>
Use when adding or reviewing Progressive Web App capabilities such as installability, manifest metadata, Service Worker registration, Workbox caching, offline fallback, app update prompts, maskable icons, or iOS PWA compatibility. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[bovinphang](https://clawhub.ai/user/bovinphang) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to add or review Progressive Web App behavior in web applications, including installability, manifest metadata, Service Worker registration, Workbox caching, offline fallback, update prompts, and mobile platform compatibility. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated PWA changes could cache sensitive routes or authenticated actions. <br>
Mitigation: Keep login, payment, permission changes, write operations, and other sensitive requests network-only, and review generated Service Worker and Workbox rules before deployment. <br>
Risk: Incorrect caching or update behavior could serve stale application code or data. <br>
Mitigation: Use explicit cache boundaries, max entries, max age, visible update prompts, offline fallback testing, and Lighthouse or browser DevTools verification before release. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/bovinphang/fec-pwa-implementation) <br>
- [Manifest, icons, and install entry reference](references/manifest-and-icons.md) <br>
- [Service Worker, Workbox, and update flow reference](references/service-worker-workbox.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Markdown, Code, Shell commands, Configuration] <br>
**Output Format:** [Markdown guidance with code and configuration examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include PWA implementation steps, manifest and HTML snippets, Service Worker registration code, Workbox configuration, offline fallback guidance, update-flow guidance, and validation checks.] <br>

## Skill Version(s): <br>
2.5.1 (source: ClawHub release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
