## Description: <br>
API Ninjas (api-ninjas.com). Use this skill for API Ninjas search and read requests through the OOMOL `oo` CLI instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to run OOMOL-backed API Ninjas lookups for geocoding, reverse geocoding, timezone metadata, current weather, weather forecasts, and air quality data. The skill guides agents to inspect the live connector schema before sending JSON input for each read-oriented action. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected API Ninjas account. <br>
Mitigation: Install only if the user is comfortable using OOMOL's oo CLI and connecting an API Ninjas API key through OOMOL; avoid exposing raw credentials in prompts or command output. <br>
Risk: Setup, login, billing, or connection steps can change account state or open external account flows. <br>
Mitigation: Treat setup, login, billing, and connection steps as user-approved actions and run them only when needed to resolve an observed command failure. <br>
Risk: Connector fields and defaults can change upstream, which can make stale payloads incorrect. <br>
Mitigation: Inspect the live connector schema before building each action payload, then send JSON that matches the current schema. <br>


## Reference(s): <br>
- [API Ninjas homepage](https://api-ninjas.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub API Ninjas skill page](https://clawhub.ai/oomol/oo-api-ninjas) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, OOMOL sign-in, and an API Ninjas connection; action inputs should be based on the live connector schema.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
