## Description: <br>
Connects agents to World News API for searching, retrieving, and reading news data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to search World News API, retrieve top-news clusters or specific articles, search news sources, and resolve locations while relying on OOMOL-managed credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: World News API searches may send user queries and API payloads through the OOMOL connector. <br>
Mitigation: Review payloads for sensitive search terms before running broad searches. <br>
Risk: The skill depends on connected OOMOL and World News API credentials. <br>
Mitigation: Install only when the user is comfortable connecting those accounts and credentials. <br>


## Reference(s): <br>
- [World News API homepage](https://worldnewsapi.com) <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-world-news-api) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an authenticated OOMOL account, and a connected World News API credential.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
