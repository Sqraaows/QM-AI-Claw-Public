## Description: <br>
Typeform (typeform.com). Use this skill for Typeform requests that search or read data through an OOMOL-connected Typeform account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and support teams use this skill to inspect Typeform users, forms, workspaces, and submitted responses from an authenticated OOMOL-connected Typeform account. It is intended for read-only Typeform data retrieval and schema-aware command construction. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Typeform responses can include respondent names, emails, free-text answers, or other sensitive submissions. <br>
Mitigation: Use the skill only for tasks that require Typeform access and handle returned form responses as sensitive user data. <br>
Risk: The connector requires OAuth or other sensitive credentials managed through the connected OOMOL account. <br>
Mitigation: Rely on the OOMOL connection flow and do not expose or request raw tokens in agent prompts, logs, or payloads. <br>
Risk: Connector schemas and upstream Typeform contracts can change. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Typeform skill](https://clawhub.ai/oomol/oo-typeform) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Typeform homepage](https://www.typeform.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill guides agents to fetch live connector schemas before running read-only Typeform actions; command results are returned as JSON with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence metadata and release version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
