## Description: <br>
Typefully helps agents read, create, update, list, and delete Typefully drafts through an OOMOL-connected Typefully account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Social media and marketing operators use this skill to manage Typefully drafts and social sets from an agent workflow. It supports draft creation, updates, retrieval, listing, deletion, and current-user lookup after the user has connected a Typefully API key. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Typefully API key and can access account-specific draft and social-set data. <br>
Mitigation: Install only when the publisher is trusted, connect the Typefully account intentionally, and keep API key access scoped and monitored through the connected service. <br>
Risk: Create, update, and delete draft actions can change or remove Typefully content. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write or destructive actions. <br>
Risk: Security evidence notes a documentation inconsistency for the get_social_set action warning. <br>
Mitigation: Treat get_social_set as needing reviewer attention before release and correct the action documentation so its warning matches actual behavior. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-typefully) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [Typefully homepage](https://typefully.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payload instructions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses with data and execution metadata from the OOMOL connector.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
