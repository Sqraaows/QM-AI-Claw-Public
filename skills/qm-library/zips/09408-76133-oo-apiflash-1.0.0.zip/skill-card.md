## Description: <br>
ApiFlash (apiflash.com). Use this skill for ApiFlash tasks through an OOMOL-connected account, including website screenshots, quota checks, and screenshot metadata lookup. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to run ApiFlash screenshot and metadata workflows through the oo CLI while relying on OOMOL-managed credentials. It supports capturing website screenshots, checking remaining quota and reset timing, and reading metadata for previously returned screenshot URLs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup path can involve a remote oo CLI shell installer. <br>
Mitigation: Review the installer source or use a trusted package path before installing the CLI. <br>
Risk: Screenshot capture can consume ApiFlash quota and create externally hosted screenshot URLs. <br>
Mitigation: Confirm screenshot-capture payloads and expected effects with the user before running the action. <br>
Risk: The connector relies on OOMOL as an intermediary for ApiFlash account access. <br>
Mitigation: Install and use the skill only when the user trusts OOMOL to manage the ApiFlash connection. <br>


## Reference(s): <br>
- [ApiFlash homepage](https://apiflash.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ApiFlash ClawHub listing](https://clawhub.ai/oomol/oo-apiflash) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads/responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses include a data object and meta.executionId when run through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
