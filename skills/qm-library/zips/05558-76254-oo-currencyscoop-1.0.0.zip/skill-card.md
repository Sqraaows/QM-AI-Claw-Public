## Description: <br>
CurrencyBeacon helps agents retrieve supported currencies, latest and historical exchange rates, time series data, and currency conversions through the OOMOL currencyscoop connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users can use this skill to query CurrencyBeacon exchange-rate data, convert currency amounts, and inspect historical or time-series rates from an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected CurrencyBeacon account and requires sensitive credentials managed through OOMOL. <br>
Mitigation: Use it only with intended OOMOL and CurrencyBeacon connections, and review command payloads before running connector actions. <br>
Risk: Exchange-rate outputs may be unsuitable as the sole basis for financial, accounting, or contractual decisions. <br>
Mitigation: Verify rates, dates, currencies, and any derived amounts against an authoritative source before acting on them. <br>
Risk: Connector use can fail or stop when authentication, app connection, or OOMOL billing state is invalid. <br>
Mitigation: Resolve sign-in, connection scope, credential expiry, or billing errors before retrying the requested action. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-currencyscoop) <br>
- [CurrencyBeacon Homepage](https://currencybeacon.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands call the oo currencyscoop connector and return JSON responses from CurrencyBeacon.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
