# Hum Song Skill Layer

This directory documents the lightweight skill layer for `hum-song`.

The root `SKILL.md` is intentionally an installer/launcher skill. It tells OpenClaw/Hermes users how to download the repository, install dependencies, link the package into their skill directories, and start the full agent.

The full agent metadata is in:

```text
agents/hum-song-agent.yaml
```

The runtime command is:

```bash
node scripts/hum-song.mjs
```

Use this split when publishing or explaining the package:

- **Skill**: discovery, install guidance, configuration guidance, safety boundaries.
- **Agent**: runtime commands, health/submit/status/wait/cancel/serve capabilities.
