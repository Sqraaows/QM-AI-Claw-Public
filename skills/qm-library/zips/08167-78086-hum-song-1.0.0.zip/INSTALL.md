# Install hum-song agent

This ZIP is the lightweight hum-song skill package. It helps users download and install the full hum-song agent.

Full agent repository:

https://github.com/harrylabsj/hum-song

Install the full agent:

```bash
git clone https://github.com/harrylabsj/hum-song.git
cd hum-song
pnpm install
bash scripts/install.sh --both
pnpm verify
```

Default install targets:

```text
OpenClaw: ~/.openclaw/workspace/skills/hum-song
Hermes:   ~/.hermes/skills/creative/hum-song
```

Start the agent API:

```bash
pnpm serve
```
