## Description: <br>
Dub (dub.co). Use this skill for ANY Dub request, including reading, creating, updating, and deleting Dub workspace data through the OOMOL oo connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Dub short links, folders, tags, and analytics from an authenticated Dub workspace without calling the Dub API directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Create and update actions can change Dub workspace state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create or update commands. <br>
Risk: Delete actions can remove Dub links, folders, or tags. <br>
Mitigation: Confirm the target and obtain explicit user approval before running delete commands. <br>
Risk: The skill depends on an authenticated OOMOL oo CLI connection to a Dub workspace. <br>
Mitigation: Use it only when the user trusts the OOMOL oo CLI, the connected Dub workspace, and the required first-time setup steps. <br>


## Reference(s): <br>
- [Dub homepage](https://dub.co) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-dub) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands inspect live connector schemas before sending JSON payloads to OOMOL oo CLI actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
