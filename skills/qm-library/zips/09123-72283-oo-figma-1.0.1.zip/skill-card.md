## Description: <br>
Figma connector skill for reading, creating, updating, and deleting Figma data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, designers, and automation agents use this skill to inspect Figma files, projects, comments, components, styles, image assets, and dev resources, and to make approved comment, reaction, or dev-resource changes through the Figma connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates a connected Figma account and may access design files, comments, libraries, projects, image fills, and dev resources available to that account. <br>
Mitigation: Install it only when agent access to the connected Figma account is intended, and scope user requests to the specific files, projects, or resources needed. <br>
Risk: Comment, reaction, and dev-resource actions can create, update, or delete Figma state. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write or destructive actions. <br>
Risk: Two action references are reported as having write-warning documentation inconsistencies despite read-style behavior. <br>
Mitigation: Inspect the live connector schema before constructing payloads and treat those warnings as publisher documentation issues until corrected. <br>


## Reference(s): <br>
- [Figma homepage](https://www.figma.com) <br>
- [Figma skill on ClawHub](https://clawhub.ai/oomol/oo-figma) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an OOMOL sign-in, and a connected Figma account before connector actions can run.] <br>

## Skill Version(s): <br>
1.0.1 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
