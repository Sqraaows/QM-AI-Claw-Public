## Description: <br>
Use this skill to read Pingdom uptime monitoring data through an OOMOL-connected Pingdom account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to inspect Pingdom uptime checks, account credits, and probe server information from a connected Pingdom account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Pingdom monitoring data, probe information, and account credit details through the connected OOMOL account. <br>
Mitigation: Install it only for accounts where that data access is acceptable, and avoid connecting broader Pingdom credentials than needed. <br>
Risk: The trigger wording is broad for Pingdom-related requests. <br>
Mitigation: Review the intended Pingdom action and requested data before execution, especially when the user request is ambiguous. <br>
Risk: First-time setup may involve installing the oo CLI or connecting a Pingdom credential. <br>
Mitigation: Run setup steps only after the matching command, authentication, or connection error occurs. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-pingdom) <br>
- [Pingdom homepage](https://www.pingdom.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before action execution; credentials are handled through the connected OOMOL account.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
