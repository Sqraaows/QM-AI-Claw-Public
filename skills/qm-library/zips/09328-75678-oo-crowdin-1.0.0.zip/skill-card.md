## Description: <br>
Crowdin helps agents read, create, and update Crowdin localization resources through the OOMOL oo CLI connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, localization teams, and external users use this skill to inspect Crowdin projects, branches, directories, and source files, then create Crowdin structure or upload source files through a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can modify Crowdin project state through branch, directory, and source file upload actions. <br>
Mitigation: Confirm the exact Crowdin project, path, payload, and intended effect with the user before running write actions. <br>
Risk: The skill requires a connected OOMOL/Crowdin account and sensitive credential handling by the connector. <br>
Mitigation: Use the connected account only when needed, trust OOMOL as the connector provider, and avoid exposing raw credentials. <br>
Risk: First-time setup can run a remote oo CLI installer. <br>
Mitigation: Run the installer only when the oo CLI is missing and the connector is needed. <br>


## Reference(s): <br>
- [Crowdin homepage](https://crowdin.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-crowdin) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Crowdin connector responses are JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
