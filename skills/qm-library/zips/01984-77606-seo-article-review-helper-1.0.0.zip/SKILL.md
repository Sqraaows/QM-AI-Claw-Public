---
name: seo-article-review
description: "SEO/AEO 诊断助手适合内容创作者、运营、市场营销、technical在用户提出“这篇能被 AI 引用吗”这类问题，需要快速拆解目标、判断重点并形成可执行结果时使用，帮助基于输入材料生成摘要、诊断结论、行动建议和可复用交付物。"
requiredEnvVars:
  - name: AISKILLS_API_KEY
    description: "从 AI Skills 官网 https://ai-skills.ai 获取的 API Key，用于运行导出的技能调用。"
---

# seo-article-review SEO/AEO 诊断助手

[快速开始](https://github.com/allinherog-star/ai-skills/tree/main#%E5%BF%AB%E9%80%9F%E5%BC%80%E5%A7%8B)

[更多技能](https://ai-skills.ai)

### 概述

SEO/AEO 诊断助手用于回答「这篇能被 AI 引用吗」、SEO、AEO、文章优化，适合内容创作者、运营、市场营销、technical在明确业务目标、内容材料或分析对象后调用。
它会结合SEO/AEO 文章稿、可粘贴待审文章正文、标题方案或搜索优化草稿；建议保留 H1/H2、…等输入，整理关键上下文，并输出摘要、诊断结论、行动建议和可复用交付物，便于继续执行、复盘或交付。

### 什么时候使用

**适用场景**

- 用户提出“这篇能被 AI 引用吗”这类问题，需要快速拆解目标、判断重点并形成可执行结果
- 内容创作者、运营、市场营销、technical需要围绕SEO/AEO 诊断助手生成摘要、诊断结论、行动建议和可复用交付物
- 用户已经准备了转化目标（例如提升关键词覆盖、搜索排名、AI 摘要引用、线索转化或内容权威感。）、目标人群（说明搜索用户画像和意图阶段，例如新手学习、方案比较、采购决策或专家复核。）、文章公开链接（填写无需登录即可访问的文章页、博客页或搜索落地页链接。），希望整理成可执行的分析或优化结果
- 用户需要把SEO/AEO 诊断助手相关材料转成清晰结论、优先级和下一步动作

### 调用方式

通过导出的 Python runner 直接调用 AI Skills API：

### 命令示例

**基础调用**

```bash
python3 scripts/run.py --params '{}'
```

**带常用参数调用**

```bash
python3 scripts/run.py --params '{"goal":"转化目标"}'
```

### 参数说明

| 参数 | 类型 | 必填 | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `goal` | string | 否 | - | 例如提升关键词覆盖、搜索排名、AI 摘要引用、线索转化或内容权威感 |
| `audience` | string | 否 | - | 说明搜索用户画像和意图阶段，例如新手学习、方案比较、采购决策或专家复核 |
| `materialUrl` | string | 否 | - | 填写无需登录即可访问的文章页、博客页或搜索落地页链接；需要传可访问的完整 URL |
| `reviewDepth` | string | 否 | `标准诊断` | 诊断深度；可选值：`快速体检`、`标准诊断`、`深度改稿` |
| `materialFile` | string | 否 | - | 支持 docx、pdf、md、txt 等文章稿件，适合提交 Markdown、Word 或审稿版文件 |
| `materialText` | string | 否 | - | 可粘贴待审文章正文、标题方案或搜索优化草稿；建议保留 H1/H2、关键词和内链标记 |
| `searchIntent` | string | 否 | - | 例如了解概念、比较方案、购买决策、教程操作 |
| `targetKeyword` | string | 否 | - | 希望覆盖的核心关键词或查询语句 |
| `targetPlatform` | string | 否 | `SEO/AEO` | 目标平台；可选值：`SEO/AEO`、`官网博客`、`知识库` |
| `brandRequirements` | string | 否 | - | 补充品牌语气、必须保留的事实、内部链接要求、合规边界或禁用表达 |

完整机器可读参数结构见 `references/form-schema.json`。

### 参数取值参考

当前技能没有需要额外查表的分类参数。

### 支持的输入格式

当前技能直接接收 JSON 参数；如果参数里包含链接字段，请传完整、可访问的 URL。

### 示例请求

下面的示例参数可直接传给 `scripts/run.py`，runner 会把它们发送给 AI Skills API。

```bash
python3 scripts/run.py --params '{"goal":"转化目标"}'
```

等价的 `--params` JSON：

```json
{
  "goal": "转化目标"
}
```

### 返回结果示例

```json
{
  "success": true,
  "data": {
    "message": "示例结果请以技能真实返回结构为准。"
  },
  "meta": {
    "executionTime": 842,
    "cached": false
  }
}
```

### 交付内容

- 摘要、诊断结论、行动建议和可复用交付物：围绕用户目标整理可直接阅读、复盘或交付的核心结果。
- 输入材料解读：结合转化目标（例如提升关键词覆盖、搜索排名、AI 摘要引用、线索转化或内容权威感。）、目标人群（说明搜索用户画像和意图阶段，例如新手学习、方案比较、采购决策或专家复核。）、文章公开链接（填写无需登录即可访问的文章页、博客页或搜索落地页链接。）提炼关键上下文和判断依据。
- 下一步动作：给出优先级、执行建议或可继续加工的内容框架。

### 结果使用建议

- 先判断输出是否回答了用户关于「SEO/AEO 诊断助手」的核心问题。
- 再检查结果是否覆盖摘要、诊断结论、行动建议和可复用交付物，以及是否给出明确下一步动作。
- 如果输入材料较少，建议让用户补充目标、受众、限制条件或原始材料后再运行。

### 运行前准备

- `AISKILLS_BASE_URL`：默认 `https://ai-skills.ai`
- `AISKILLS_API_KEY`：必填，用于认证调用
- `AISKILLS_TENANT_ID`：默认 `default`
