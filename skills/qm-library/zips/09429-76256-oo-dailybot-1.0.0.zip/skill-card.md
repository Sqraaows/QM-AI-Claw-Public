## Description: <br>
Dailybot (dailybot.com). Use this skill for Dailybot requests that read organization, user, and team data or send Dailybot messages and email notifications through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees and teams use this skill to operate Dailybot from an agent, including looking up organization, user, and team context and sending Dailybot chat messages or email notifications after confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Dailybot organization, user, team, and membership information through the connected account. <br>
Mitigation: Install and use it only for Dailybot workspaces where the user is authorized to access that information. <br>
Risk: The skill can send Dailybot chat messages and email notifications through the connected account. <br>
Mitigation: Confirm the recipient, payload, and intended effect with the user before running send actions. <br>
Risk: The skill requires a connected Dailybot credential managed through OOMOL. <br>
Mitigation: Use the OOMOL connection flow and avoid exposing raw Dailybot credentials in prompts, files, or command arguments. <br>


## Reference(s): <br>
- [Dailybot homepage](https://www.dailybot.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Dailybot skill on ClawHub](https://clawhub.ai/oomol/oo-dailybot) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads; connector responses are JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
