## Description: <br>
Manage AI coding agent sessions via Agent of Empires (aoe). <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[njbrake](https://clawhub.ai/user/njbrake) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to create, organize, monitor, and capture AI coding agent sessions managed by Agent of Empires in tmux. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Powerful session commands, YOLO mode, and forced worktree deletion can affect running agents or local work if used on the wrong target. <br>
Mitigation: Verify the target session, path, git status, and backup or commit state before using YOLO mode or destructive worktree cleanup commands. <br>


## Reference(s): <br>
- [ClawHub skill listing](https://clawhub.ai/njbrake/aoe) <br>
- [Agent of Empires homepage](https://github.com/agent-of-empires/agent-of-empires) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration] <br>
**Output Format:** [Markdown with inline shell commands and JSON examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Guidance assumes the aoe and tmux binaries are installed.] <br>

## Skill Version(s): <br>
1.10.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
