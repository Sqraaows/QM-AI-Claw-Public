## Description: <br>
Synchronizes frontend project documentation with source-of-truth files such as package manifests, environment examples, routes, API clients, schemas, tests, CI, and deployment configuration. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[bovinphang](https://clawhub.ai/user/bovinphang) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and maintainers use this skill to compare frontend project documentation against source files and update README, docs, ADRs, changelogs, environment, setup, deployment, and API documentation. It is intended for fact-based documentation synchronization rather than general prose polishing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Documentation updates can introduce incorrect or misleading project guidance if source facts are stale or misunderstood. <br>
Mitigation: Review generated documentation changes and run relevant consistency, type, test, build, or packaging checks before committing. <br>
Risk: The skill may read private internal docs or release notes while synchronizing repository documentation. <br>
Mitigation: Limit the requested documentation scope and review proposed changes before publishing or committing them. <br>


## Reference(s): <br>
- [Doc Sync on ClawHub](https://clawhub.ai/bovinphang/fec-doc-sync) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown summary with proposed documentation edits, validation commands, and risk notes] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include synchronized file lists, source facts, verification commands, and manual confirmation items.] <br>

## Skill Version(s): <br>
2.5.0 (source: release evidence, package.json, metadata.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
