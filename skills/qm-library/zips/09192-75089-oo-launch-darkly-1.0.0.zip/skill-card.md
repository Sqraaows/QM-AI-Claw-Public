## Description: <br>
LaunchDarkly helps an agent manage LaunchDarkly projects, environments, feature flags, segments, contexts, members, teams, tags, and access tokens through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect and administer LaunchDarkly resources from an agent while requiring confirmation for create, update, reset, and delete operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, reset, or delete LaunchDarkly resources, including access tokens. <br>
Mitigation: Use least-privilege LaunchDarkly credentials and require explicit user approval for payloads and targets before state-changing actions. <br>
Risk: Credential and token-management actions can alter sensitive access. <br>
Mitigation: Review token scopes and avoid token create, patch, reset, or delete actions unless the requested change is specific and approved. <br>


## Reference(s): <br>
- [LaunchDarkly homepage](https://launchdarkly.com) <br>
- [ClawHub LaunchDarkly skill listing](https://clawhub.ai/oomol/oo-launch-darkly) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload or response expectations] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill directs the agent to inspect live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
