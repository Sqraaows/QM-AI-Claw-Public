## Description: <br>
ChatbotX helps agents administer an omnichannel chat marketing platform for contacts, conversations, flows, broadcasts, and sequences across messaging, email, and webchat channels. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[sunghajung43](https://clawhub.ai/user/sunghajung43) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and marketing teams use this skill to configure ChatbotX access and guide agent-driven administration of contacts, tags, custom fields, conversations, broadcasts, flows, and sequences. It is suited for teams that need ChatbotX automation through CLI or MCP workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: ChatbotX API credentials can allow access to customer conversations and contact data. <br>
Mitigation: Use a least-privilege API token, keep production credentials out of tests, and rotate or revoke tokens when access is no longer needed. <br>
Risk: The skill can guide create, update, delete, message, block, and unblock actions in ChatbotX. <br>
Mitigation: Require explicit approval before any mutating action, and verify target IDs, contact records, flows, tags, and message content before execution. <br>
Risk: Allowing self-signed certificates can weaken TLS protections. <br>
Mitigation: Do not enable CHATBOTX_ALLOW_SELF_SIGNED_CERT except temporarily on a controlled local network for a trusted self-hosted instance. <br>


## Reference(s): <br>
- [ClawHub skill listing](https://clawhub.ai/sunghajung43/chatbotx) <br>
- [Publisher profile](https://clawhub.ai/user/sunghajung43) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and configuration examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires CHATBOTX_API_KEY and CHATBOTX_API_URL; CHATBOTX_ALLOW_SELF_SIGNED_CERT is optional for controlled self-hosted testing.] <br>

## Skill Version(s): <br>
0.1.4 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
