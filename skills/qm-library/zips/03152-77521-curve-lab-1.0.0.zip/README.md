# 曲线合成器

一个基于浏览器的轻量级工具，可从 CSV/TXT 数据文件生成多轴曲线图。
拖入文件 → 配置坐标轴 → 应用平滑 → 导出结果，全部在浏览器中完成。

同时可作为 **Claude Code 技能**使用 —— 详见 [SKILL.md](./SKILL.md)。

## 快速开始

```bash
# 启动 templates/ 目录（推荐）：
cd templates && python -m http.server 8080
# → 浏览器访问 http://localhost:8080

# 或者直接用浏览器打开：
open templates/index.html
```

无需 `npm install`，无需构建。所有依赖（Chart.js、Luxon）均从 CDN 加载。

## 功能特性

- **拖放上传** CSV / TXT 文件（自动检测 `,` `;` `\t` 分隔符）
- **数据预览** —— 可滚动表格展示前 20 行
- **三步坐标轴向导**
  1. 选择一个 X 轴列
  2. 勾选一个或多个 Y 轴列
  3. 将每个 Y 列分配到左侧或右侧坐标轴组
- **平滑算法** —— 移动平均（可配置窗口大小）、样条插值（Catmull-Rom）
- **自动时间序列检测** —— 列名含 `time`/`date`/`timestamp`/`时间` 的列自动解析为日期时间
- **导出** —— PNG（图表图片）、JSON、CSV（UTF-8 BOM）

## 项目结构

```
curve-synthesizer/
├── SKILL.md                        # Claude Code 技能定义
├── README.md                       # 本文件
├── scripts/
│   └── curve-synthesizer.js        # 核心引擎（解析器、算法、Chart.js 绑定）
├── templates/
│   ├── index.html                  # 独立 Web 界面
│   └── style.css                   # 样式
└── assets/
    └── examples/
        ├── sample_data.csv         # 数值 X 轴演示数据
        └── sample_timeseries.csv   # 时间序列演示数据
```

## 使用方法

### 1. 准备 CSV 文件

```csv
时间,温度,压力,流量
0,25.0,101.3,12.5
1,25.3,101.4,12.7
```

或时间序列：
```csv
采集时间,CPU使用率,内存占用
2026-01-15 08:00:00,12.5,4.2
2026-01-15 08:05:00,15.8,4.5
```

### 2. 打开工具

用任意 HTTP 服务器托管 `templates/` 目录，或直接打开 `templates/index.html`。

### 3. 配置并生成

1. 拖入数据文件到上传区域（或点击 **浏览…**）
2. **第一步** —— 选择 X 轴列
3. **第二步** —— 勾选 Y 轴列
4. **第三步** —— 将各列分配到坐标轴组（不同单位/量级的列建议分开）
5. 可选：启用平滑算法
6. 点击 **生成曲线**

### 4. 导出

- **PNG** —— 右键保存或使用导出按钮
- **JSON** —— 将选中列导出为结构化数据
- **CSV** —— Excel 兼容格式（UTF-8 BOM）

## 平滑算法指南

| 算法 | 适用场景 | 参数 |
|---|---|---|
| 移动平均 | 含噪声的传感器数据 | 窗口大小 5-10 |
| 样条插值 | 稀疏数据、需要光滑曲线 | 无 |
| 不平滑 | 干净/密集的数据 | — |

## 安装为 Claude Code 技能

```bash
# 复制到技能目录：
cp -r curve-synthesizer ~/.claude/skills/
```

之后在 Claude Code 中，当你提到绘制 CSV 数据、生成曲线或可视化表格数据时，
该技能会自动触发。

## 依赖项

全部通过 CDN 加载，无需本地安装：

| 库 | 用途 |
|---|---|
| [Chart.js](https://www.chartjs.org/) | 图表渲染 |
| [Luxon](https://moment.github.io/luxon/) | 日期时间处理 |
| [chartjs-adapter-luxon](https://github.com/chartjs/chartjs-adapter-luxon) | 时间刻度适配 |

## 浏览器兼容性

Chrome 90+、Firefox 90+、Edge 90+、Safari 15+

## 许可证

MIT
