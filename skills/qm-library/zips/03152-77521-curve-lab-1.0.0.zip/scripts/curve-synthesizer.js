/**
 * Curve Synthesizer — Core Engine
 *
 * A standalone, dependency-free data processing layer that powers the
 * curve-synthesizer UI.  It parses CSV/TXT, applies smoothing algorithms,
 * and renders multi-axis Chart.js line charts.
 *
 * Dependencies (loaded via CDN in index.html):
 *   - Chart.js
 *   - Luxon
 *   - chartjs-adapter-luxon
 *
 * Usage:
 *   const app = new CurveSynthesizer();
 *   // Drop a CSV/TXT file onto the drop-zone or click "Browse".
 */

class CurveSynthesizer {

  /* ---- state ------------------------------------------------------------ */
  data             = null;
  columns          = [];
  xAxis            = null;
  yAxisColumns     = new Set();
  axisAssignments  = {};
  axisCounter      = 1;
  availableAxes    = ['axis1'];
  chart            = null;

  /* ---- colour palette --------------------------------------------------- */
  PALETTE = [
    'rgba(54, 162, 235, OPACITY)',   // blue
    'rgba(255, 99, 132, OPACITY)',   // red
    'rgba(75, 192, 192, OPACITY)',   // green
    'rgba(255, 159, 64, OPACITY)',   // orange
    'rgba(153, 102, 255, OPACITY)',  // purple
    'rgba(255, 205, 86, OPACITY)',   // yellow
    'rgba(201, 203, 207, OPACITY)',  // grey
  ];

  /* =======================================================================
     Initialisation
     ======================================================================= */

  constructor() {
    this._bindUI();
  }

  /* =======================================================================
     File Handling
     ======================================================================= */

  /** Accept a File object from input or drop. */
  handleFile(file) {
    if (!file) return;

    const ext = file.name.split('.').pop().toLowerCase();
    if (!['csv', 'txt'].includes(ext)) {
      this._status('Please upload a .csv or .txt file.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        this._parse(e.target.result);
        this._status(`Loaded "${file.name}"`, 'success');
      } catch (err) {
        this._status(`Parse error: ${err.message}`, 'error');
      }
    };
    reader.onerror = () => this._status('File read failed.', 'error');
    reader.readAsText(file);
  }

  /* =======================================================================
     CSV / TXT Parser
     ======================================================================= */

  /**
   * Auto-detect delimiter (,  ;  \t) and parse the raw text into an
   * array of row-objects keyed by header name.
   */
  _parse(raw) {
    const lines = raw.trim().split(/\r?\n/);
    if (lines.length < 2) throw new Error('File has no data rows.');

    // --- detect delimiter -------------------------------------------------
    let delim = ',';
    const header = lines[0];
    if (header.includes('\t')) delim = '\t';
    else if (header.includes(';')) delim = ';';

    // --- headers ----------------------------------------------------------
    this.columns = header.split(delim).map((h) => h.trim());

    // --- rows -------------------------------------------------------------
    this.data = [];
    for (let i = 1; i < lines.length; i++) {
      const row = lines[i].trim();
      if (!row) continue;

      const values = row.split(delim).map((v) => {
        const t = v.trim();
        const n = Number(t);
        return isNaN(n) ? t : n;
      });

      if (values.length !== this.columns.length) continue;

      const obj = {};
      this.columns.forEach((col, idx) => {
        const val = values[idx];
        obj[col] = this._maybeDate(col, val);
      });
      this.data.push(obj);
    }

    if (this.data.length === 0) throw new Error('No valid data rows found.');

    this._renderPreview();
    this._buildXStep();
    this._show('#chart-controls');
    this._show('#export-section');
  }

  /**
   * If the column name hints at a timestamp AND the value is a string,
   * attempt to parse it as a Date.  Otherwise return the value unchanged.
   */
  _maybeDate(colName, value) {
    if (typeof value !== 'string') return value;
    const lo = colName.toLowerCase();
    const isTimeCol = lo.includes('time') || lo.includes('date') ||
                      lo.includes('timestamp') || lo.includes('时间');
    if (!isTimeCol) return value;

    // Try "YYYY-MM-DD HH:MM:SS" or "YYYY/MM/DD HH:MM:SS"
    const m = value.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})\s+(\d{1,2}):(\d{1,2}):(\d{1,2})$/);
    if (m) {
      const [, y, mo, d, h, mi, s] = m;
      return new Date(+y, +mo - 1, +d, +h, +mi, +s);
    }
    return value;
  }

  /* =======================================================================
     Data Preview Table
     ======================================================================= */

  _renderPreview() {
    const thead = document.getElementById('table-head');
    const tbody = document.getElementById('table-body');
    thead.innerHTML = '';
    tbody.innerHTML = '';

    const tr = document.createElement('tr');
    this.columns.forEach((c) => {
      const th = document.createElement('th');
      th.textContent = c;
      tr.appendChild(th);
    });
    thead.appendChild(tr);

    const limit = Math.min(this.data.length, 20);
    for (let i = 0; i < limit; i++) {
      const row = document.createElement('tr');
      this.columns.forEach((c) => {
        const td = document.createElement('td');
        const v = this.data[i][c];
        td.textContent = v instanceof Date ? v.toLocaleString() : v;
        row.appendChild(td);
      });
      tbody.appendChild(row);
    }
    this._show('#data-preview-section');
  }

  /* =======================================================================
     Three-Step Axis Setup
     ======================================================================= */

  /** Step 1 — pick the X-axis column (radio buttons). */
  _buildXStep() {
    const container = document.getElementById('x-axis-selection');
    container.innerHTML = '';
    this.xAxis = null;

    this.columns.forEach((col, i) => {
      const div = this._rowWrap();
      const radio = this._el('input', { type: 'radio', name: 'x-axis',
        id: `x-col-${i}`, value: col, checked: i === 0 });
      const label = this._el('label', { for: `x-col-${i}` }, col);
      div.append(radio, label);
      container.appendChild(div);

      radio.addEventListener('change', (e) => {
        if (!e.target.checked) return;
        this.xAxis = col;
        this._show('#y-axis-step');
        this._buildYStep();
      });
      if (i === 0) this.xAxis = col;
    });

    this._show('#y-axis-step');
    this._buildYStep();
  }

  /** Step 2 — pick Y-axis columns (checkboxes). */
  _buildYStep() {
    const container = document.getElementById('y-axis-selection');
    container.innerHTML = '';
    this.yAxisColumns.clear();

    const candidates = this.columns.filter((c) => c !== this.xAxis);

    candidates.forEach((col, i) => {
      const div = this._rowWrap();
      const cb = this._el('input', { type: 'checkbox',
        id: `y-col-${i}`, value: col, checked: i < 4 });
      const label = this._el('label', { for: `y-col-${i}` }, col);
      div.append(cb, label);
      container.appendChild(div);

      cb.addEventListener('change', (e) => {
        e.target.checked ? this.yAxisColumns.add(col)
                         : this.yAxisColumns.delete(col);
        this.yAxisColumns.size
          ? (this._show('#axis-step'), this._buildAxisGrouping())
          : this._hide('#axis-step');
      });
      if (i < 4) this.yAxisColumns.add(col);
    });

    if (this.yAxisColumns.size) {
      this._show('#axis-step');
      this._buildAxisGrouping();
    }
  }

  /** Step 3 — assign each Y column to a named axis (dropdowns). */
  _buildAxisGrouping() {
    const container = document.getElementById('axis-grouping');
    container.innerHTML = '';

    const cols = [...this.yAxisColumns];
    this.axisAssignments = {};
    cols.forEach((col, i) => {
      this.axisAssignments[col] = `axis${i + 1}`;
    });
    this.axisCounter = cols.length + 1;
    this.availableAxes = cols.map((_, i) => `axis${i + 1}`);

    const wrap = document.createElement('div');
    wrap.className = 'axis-grouping-container';

    cols.forEach((col) => {
      const item = document.createElement('div');
      item.className = 'axis-grouping-item';

      const label = this._el('label', { for: `axis-sel-${col}` }, col);
      const select = this._el('select', { id: `axis-sel-${col}` });
      select.className = 'axis-select';

      this.availableAxes.forEach((ax) => {
        const opt = document.createElement('option');
        opt.value = ax;
        opt.textContent = `Axis ${ax.replace('axis', '')}`;
        opt.selected = this.axisAssignments[col] === ax;
        select.appendChild(opt);
      });

      select.addEventListener('change', (e) => {
        this.axisAssignments[col] = e.target.value;
      });

      item.append(label, select);
      wrap.appendChild(item);
    });
    container.appendChild(wrap);
  }

  /** "Add Axis" button handler — appends a new named axis to all dropdowns. */
  addAxis() {
    const name = `axis${this.axisCounter++}`;
    this.availableAxes.push(name);
    document.querySelectorAll('.axis-select').forEach((sel) => {
      const opt = document.createElement('option');
      opt.value = name;
      opt.textContent = `Axis ${name.replace('axis', '')}`;
      sel.appendChild(opt);
    });
  }

  /* =======================================================================
     Smoothing Algorithms
     ======================================================================= */

  /**
   * Moving Average — sliding window of `windowSize`.
   * Edge values use partial windows.
   */
  applyMovingAverage(data, windowSize) {
    if (windowSize < 3 || windowSize > data.length) return [...data];
    const half = Math.floor(windowSize / 2);
    const out = [];
    for (let i = 0; i < data.length; i++) {
      let sum = 0, cnt = 0;
      for (let j = -half; j <= half; j++) {
        const idx = i + j;
        if (idx >= 0 && idx < data.length) { sum += data[idx]; cnt++; }
      }
      out.push(sum / cnt);
    }
    return out;
  }

  /**
   * Spline Interpolation — simplified Catmull-Rom spline.
   * Requires at least 4 points; endpoints pass through unchanged.
   */
  applySplineInterpolation(data) {
    if (data.length < 4) return [...data];
    const out = [];
    const n = data.length;
    for (let i = 0; i < n; i++) {
      if (i === 0 || i === n - 1) {
        out.push(data[i]);
      } else {
        const p0 = data[i - 1];
        const p1 = data[i];
        const p2 = data[i + 1];
        const p3 = i < n - 2 ? data[i + 2] : p2;
        out.push(-0.5 * p0 + 0.5 * p1 + 0.5 * p2 - 0.5 * p3);
      }
    }
    return out;
  }

  /**
   * Min-Max Normalisation — scale values into [0, 1].
   */
  normalize(data) {
    const min = Math.min(...data);
    const max = Math.max(...data);
    const r = max - min;
    return r === 0 ? data.map(() => 0.5) : data.map((v) => (v - min) / r);
  }

  /* =======================================================================
     Chart Generation
     ======================================================================= */

  generateChart() {
    if (!this.xAxis) return this._status('Please select an X-axis column.', 'error');
    if (!this.yAxisColumns.size) return this._status('Please select at least one Y-axis column.', 'error');

    const smoothType = document.getElementById('smooth-select').value;
    const windowSize = parseInt(document.getElementById('window-size').value, 10) || 5;

    // Group Y columns by their assigned axis
    const axisToCols = {};
    for (const [col, ax] of Object.entries(this.axisAssignments)) {
      if (!this.yAxisColumns.has(col)) continue;
      (axisToCols[ax] ??= []).push(col);
    }
    const axisNames = Object.keys(axisToCols);

    // Build data-point array: { x, yValues: { axisName: { col: val } } }
    const points = this.data.map((row, idx) => {
      let x = row[this.xAxis];
      if (x instanceof Date) x = x.getTime();
      else if (typeof x === 'string') { const p = parseFloat(x); x = isNaN(p) ? idx : p; }

      const yv = {};
      for (const [ax, cols] of Object.entries(axisToCols)) {
        yv[ax] = {};
        for (const c of cols) {
          const v = row[c];
          yv[ax][c] = typeof v === 'string' ? (parseFloat(v) || v) : v;
        }
      }
      return { x, yValues: yv };
    });

    const datasets = [];
    let colourIdx = 0;

    for (const ax of axisNames) {
      for (const col of axisToCols[ax]) {
        const pts = points
          .filter((p) => typeof p.yValues[ax]?.[col] === 'number')
          .map((p) => ({ x: p.x, y: p.yValues[ax][col] }));

        if (!pts.length) continue;

        let yVals = pts.map((p) => p.y);
        if (smoothType === 'moving-average') yVals = this.applyMovingAverage(yVals, windowSize);
        else if (smoothType === 'spline') yVals = this.applySplineInterpolation(yVals);

        const processed = pts.map((p, i) => ({
          x: p.x,
          y: i < yVals.length ? yVals[i] : p.y,
        }));

        datasets.push({
          label: col,
          data: processed,
          borderColor: this._color(colourIdx, 1),
          backgroundColor: this._color(colourIdx, 0.1),
          borderWidth: 2,
          fill: false,
          yAxisID: ax,
          parsing: false,
          showLine: true,
          pointRadius: 2,
          pointBackgroundColor: this._color(colourIdx, 1),
          pointBorderColor: this._color(colourIdx, 1),
          pointBorderWidth: 1,
          pointStyle: 'circle',
          pointHoverRadius: 4,
          pointHoverBackgroundColor: this._color(colourIdx, 1),
          pointHoverBorderColor: '#fff',
          pointHoverBorderWidth: 2,
        });

        colourIdx++;
      }
    }

    if (!datasets.length) return this._status('No numeric data found in selected columns.', 'error');

    // Time-series heuristic: is the first x-value a large timestamp?
    const isTimeSeries = datasets.some(
      (ds) => ds.data[0] && typeof ds.data[0].x === 'number' && ds.data[0].x > 1e12,
    );

    this._renderChart(datasets, axisToCols, isTimeSeries);
    this._show('#chart-container');
    this._status('Chart generated.', 'success');
  }

  _renderChart(datasets, axisToCols, isTimeSeries) {
    if (this.chart) this.chart.destroy();

    const ctx = document.getElementById('curve-chart').getContext('2d');
    const self = this;

    const options = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'top' },
        tooltip: {
          mode: 'index',
          intersect: false,
          callbacks: {
            title(ctx) {
              if (isTimeSeries && ctx[0])
                return self._fmtTimestampFull(ctx[0].parsed.x);
              return '';
            },
            label(ctx) {
              return `${ctx.dataset.label}: ${ctx.parsed.y.toFixed(2)}`;
            },
            afterLabel(ctx) {
              if (!isTimeSeries && ctx.parsed.x != null)
                return `X: ${ctx.parsed.x.toFixed(2)}`;
              return '';
            },
          },
        },
      },
      scales: {
        x: {
          display: true,
          title: { display: true, text: this.xAxis || 'X' },
          type: 'linear',
          ticks: isTimeSeries
            ? {
                callback(v) { return self._fmtTimestamp(v); },
                maxTicksLimit: 15,
                autoSkip: true,
              }
            : {},
        },
      },
    };

    Object.entries(axisToCols).forEach(([ax, cols], i) => {
      const title =
        cols.length > 1
          ? `Axis ${ax.replace('axis', '')} (${cols.join(', ')})`
          : `Axis ${ax.replace('axis', '')} (${cols[0]})`;
      options.scales[ax] = {
        type: 'linear',
        display: true,
        position: i % 2 === 0 ? 'left' : 'right',
        title: { display: true, text: title },
        grid: { drawOnChartArea: i === 0 },
        ticks: { color: this._color(i, 1) },
      };
    });

    this.chart = new Chart(ctx, {
      type: 'line',
      data: { datasets },
      options,
    });
  }

  /* =======================================================================
     Export
     ======================================================================= */

  exportImage() {
    if (!this.chart) return this._status('Generate a chart first.', 'error');
    const a = document.createElement('a');
    a.download = `chart_${this._ts()}.png`;
    a.href = this.chart.toBase64Image();
    a.click();
    this._status('Chart exported as PNG.', 'success');
  }

  exportJSON() {
    if (!this.data) return this._status('No data to export.', 'error');
    const cols = [...this.yAxisColumns];
    const out = this.data.map((row) => {
      const r = {};
      for (const c of cols) r[c] = row[c];
      return r;
    });
    this._download(`data_${this._ts()}.json`,
      JSON.stringify(out, null, 2), 'application/json');
    this._status('Data exported as JSON.', 'success');
  }

  exportCSV() {
    if (!this.data) return this._status('No data to export.', 'error');
    const cols = [...this.yAxisColumns];
    const rows = [cols.join(',')];
    for (const row of this.data) {
      rows.push(cols.map((c) => {
        const v = row[c];
        if (typeof v === 'string' && (v.includes(',') || v.includes('"')))
          return `"${v.replace(/"/g, '""')}"`;
        return v;
      }).join(','));
    }
    this._download(`data_${this._ts()}.csv`,
      '﻿' + rows.join('\n'), 'text/csv;charset=utf-8');
    this._status('Data exported as CSV.', 'success');
  }

  /* =======================================================================
     Internal Helpers
     ======================================================================= */

  _bindUI() {
    const fileInput = document.getElementById('file-input');
    fileInput.addEventListener('change', (e) => this.handleFile(e.target.files[0]));
    document.getElementById('browse-btn').addEventListener('click', () => fileInput.click());
    document.getElementById('generate-chart-btn').addEventListener('click', () => this.generateChart());
    document.getElementById('add-axis-btn').addEventListener('click', () => this.addAxis());

    const smooth = document.getElementById('smooth-select');
    smooth.addEventListener('change', (e) => {
      document.getElementById('smooth-params').style.display =
        e.target.value === 'moving-average' ? 'block' : 'none';
    });

    document.getElementById('export-image-btn').addEventListener('click', () => this.exportImage());
    document.getElementById('export-data-btn').addEventListener('click', () => this.exportJSON());
    document.getElementById('export-csv-btn').addEventListener('click', () => this.exportCSV());

    // drag & drop
    const drop = document.getElementById('drop-area');
    drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('drag-over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('drag-over'));
    drop.addEventListener('drop', (e) => {
      e.preventDefault();
      drop.classList.remove('drag-over');
      if (e.dataTransfer.files[0]) this.handleFile(e.dataTransfer.files[0]);
    });
  }

  _color(idx, opacity) {
    return this.PALETTE[idx % this.PALETTE.length].replace('OPACITY', opacity);
  }

  _fmtTimestamp(ts) {
    const d = new Date(ts);
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  _fmtTimestampFull(ts) {
    const d = new Date(ts);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  _ts() {
    return new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-');
  }

  _status(msg, type = 'info') {
    const el = document.getElementById('status');
    el.textContent = msg;
    el.className = `status ${type}`;
    if (type === 'success' || type === 'info') {
      setTimeout(() => { if (el.textContent === msg) { el.textContent = ''; el.className = 'status'; } }, 5000);
    }
  }

  _show(sel) { const el = document.querySelector(sel); if (el) el.style.display = 'block'; }
  _hide(sel) { const el = document.querySelector(sel); if (el) el.style.display = 'none'; }

  _el(tag, attrs = {}, text = '') {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) e[k] = v;
    if (text) e.textContent = text;
    return e;
  }

  _rowWrap() {
    const d = document.createElement('div');
    d.style.cssText = 'display:flex;align-items:center;gap:5px;margin-bottom:8px';
    return d;
  }

  _download(filename, body, mime) {
    const blob = new Blob([body], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

/* ---- bootstrap ---------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => new CurveSynthesizer());
