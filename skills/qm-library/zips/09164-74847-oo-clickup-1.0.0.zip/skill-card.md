## Description: <br>
ClickUp lets agents read, create, update, and delete ClickUp workspaces, spaces, folders, lists, tasks, views, comments, custom fields, tags, dependencies, and attachments through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to manage ClickUp task-management data from an agent session. It supports workspace discovery plus task, list, folder, space, comment, checklist, tag, custom-field, dependency, attachment, template, user, and view workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can run create, update, delete, and remove actions that change ClickUp workspace data. <br>
Mitigation: Let read-only actions run normally, review every create or update payload before execution, and require explicit approval for delete or remove actions. <br>
Risk: The skill requires a connected ClickUp account and sensitive credentials handled through the OOMOL connector. <br>
Mitigation: Install only after confirming trust in OOMOL and the ClickUp connector, and connect accounts with the minimum access needed for the intended workflow. <br>
Risk: First-time setup includes optional curl-to-bash and PowerShell iex installer commands. <br>
Mitigation: Prefer the official install guide or a verified package and signature path before running installer commands. <br>


## Reference(s): <br>
- [ClawHub ClickUp Skill](https://clawhub.ai/oomol/oo-clickup) <br>
- [ClickUp homepage](https://clickup.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before payload construction; responses from actions are JSON from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
