## Description: <br>
Provides agent access to homes.com real-estate listing searches, property details, price and tax history, market reports, saved homes, and photo galleries through the homes-mcp MCP server. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent retrieve homes.com property search results, listing details, histories, market reports, saved homes, saved searches, and photo galleries. It is suited for read-only real-estate research workflows that rely on a locally installed MCP server and browser fetch proxy. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill relies on an external npm MCP package and a separately installed Chrome extension that can use a signed-in homes.com session. <br>
Mitigation: Use project-scoped MCP configuration when possible, review the external package and extension before installation, and only enable access for homes.com data the user is comfortable letting an agent read. <br>
Risk: Saved homes and saved searches require an authenticated homes.com tab and may expose personal real-estate research data. <br>
Mitigation: Keep the browser session and active homes.com account scoped to the intended task, and disable the MCP server or extension when saved-account data is not needed. <br>
Risk: homes.com does not provide a public consumer API, so page extraction can fail or return incomplete results when the site changes or presents access challenges. <br>
Mitigation: Treat returned listing data as research assistance, verify important property facts against homes.com or another authoritative source, and review site terms before use. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/homes-mcp) <br>
- [homes-mcp npm package](https://www.npmjs.com/package/homes-mcp) <br>
- [homes-mcp source](https://github.com/chrischall/homes-mcp) <br>
- [fetchproxy extension](https://github.com/chrischall/fetchproxy) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, configuration, guidance] <br>
**Output Format:** [Markdown guidance with JSON configuration snippets and MCP tool outputs.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only property data may include listing attributes, photos, price history, tax history, saved-home data, and local calculator results.] <br>

## Skill Version(s): <br>
0.12.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
