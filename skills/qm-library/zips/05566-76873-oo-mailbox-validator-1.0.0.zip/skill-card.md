## Description: <br>
MailboxValidator validates email addresses and checks whether addresses belong to disposable or free email providers through an OOMOL-connected MailboxValidator account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and marketing or support teams use this skill to validate a single email address and check whether it belongs to a disposable or free provider before acting on the result. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected MailboxValidator account and may process email addresses. <br>
Mitigation: Install it only when you intend to use OOMOL with MailboxValidator, and submit only email addresses you are permitted to validate. <br>
Risk: First-time setup may run a remote oo CLI installer if the CLI is missing. <br>
Mitigation: Review the oo CLI installer before execution and run the install step only when the command is unavailable. <br>


## Reference(s): <br>
- [MailboxValidator homepage](https://www.mailboxvalidator.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-mailbox-validator) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
