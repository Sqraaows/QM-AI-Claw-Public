## Description: <br>
Humanitix lets agents read Humanitix event and tag data through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents and operators use this skill to inspect Humanitix events and account tags without calling the Humanitix API directly. It supports listing accessible events, retrieving metadata for a specific event, and listing tags after the user has connected Humanitix through OOMOL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Humanitix account and sensitive credentials managed through OOMOL. <br>
Mitigation: Install it only when that connection is intended, and use the documented schema-first workflow so raw Humanitix tokens are not handled locally. <br>
Risk: Future write or delete actions could change Humanitix state even though the current artifact documents read actions. <br>
Mitigation: Treat any create, update, send, post, delete, or remove action as higher risk and require explicit user confirmation before execution. <br>


## Reference(s): <br>
- [ClawHub Humanitix Skill](https://clawhub.ai/oomol/oo-humanitix) <br>
- [Humanitix Homepage](https://humanitix.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Humanitix Connection](https://console.oomol.com/app-connections?provider=humanitix) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration guidance, JSON] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return connector data with metadata including an execution ID.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
