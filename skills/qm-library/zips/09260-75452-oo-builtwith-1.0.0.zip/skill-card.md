## Description: <br>
BuiltWith helps agents search and read BuiltWith technology intelligence through OOMOL's oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and external users can use this skill to retrieve BuiltWith domain profiles, technology summaries, recommendations, redirect history, and social-profile domain matches through a connected BuiltWith account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected BuiltWith account and OOMOL oo CLI authentication. <br>
Mitigation: Install only when intending to use OOMOL's oo CLI with BuiltWith, and review the installer, persistent sign-in, and server-side credential use before first-time setup. <br>
Risk: Upstream connector input and output schemas can change. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub BuiltWith Skill](https://clawhub.ai/oomol/oo-builtwith) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [OOMOL BuiltWith app connection](https://console.oomol.com/app-connections?provider=builtwith) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Reads live action schemas before constructing connector payloads; responses include connector data and an execution id.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
