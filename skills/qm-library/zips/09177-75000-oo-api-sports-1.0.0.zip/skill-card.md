## Description: <br>
API-SPORTS helps agents query football data from api-sports.io through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users can use this skill to retrieve football leagues, teams, squads, players, fixtures, standings, injuries, predictions, lineups, events, and match statistics through API-SPORTS. It is suited for agents that need current football data while relying on an existing OOMOL account connection for credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected API-SPORTS account and uses sensitive credentials managed by OOMOL. <br>
Mitigation: Use an authorized OOMOL connection and avoid exposing raw API tokens in prompts, files, or command output. <br>
Risk: Queries may incur third-party API costs or encounter rate limits. <br>
Mitigation: Confirm high-volume or repeated data requests before running them and monitor account billing or quota limits. <br>
Risk: Optional setup commands can install the oo CLI or initiate account authentication. <br>
Mitigation: Run setup only after an auth, connection, or missing-command failure shows it is necessary. <br>


## Reference(s): <br>
- [API-SPORTS homepage](https://api-sports.io) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-api-sports) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Agent actions return API-SPORTS data through the oo CLI as JSON responses that include data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
