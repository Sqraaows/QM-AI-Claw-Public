## Description: <br>
CloudConvert enables agents to operate CloudConvert through an OOMOL-connected account for file conversion jobs and job or task management. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to create URL-based CloudConvert conversion jobs, inspect account jobs and tasks, wait for conversions, retry failed tasks, and manage CloudConvert job or task lifecycle actions through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create conversion jobs and consume CloudConvert credits through the connected account. <br>
Mitigation: Confirm the exact conversion payload and intended effect before approving create or retry actions. <br>
Risk: The skill can cancel active tasks or delete jobs and tasks. <br>
Mitigation: Verify the exact target ID and intended destructive effect before approving cancel or delete requests. <br>
Risk: The skill requires sensitive account credentials through the OOMOL-connected CloudConvert account. <br>
Mitigation: Install only when comfortable with an agent using the connected CloudConvert account for the documented job and task actions. <br>


## Reference(s): <br>
- [CloudConvert homepage](https://cloudconvert.com) <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-cloudconvert) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
