## Description: <br>
Globalping helps an agent use OOMOL's Globalping connector to inspect schemas, create measurements, check limits, retrieve measurement results, and list online probes. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and network operators use this skill to run Globalping network diagnostics, review account limits, discover online probes, and retrieve measurement results through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Globalping account through OOMOL and can access credential-backed actions. <br>
Mitigation: Install it only after confirming the OOMOL and Globalping connection is acceptable for the environment, and keep credentials managed through the connector rather than exposing raw tokens. <br>
Risk: Creating Globalping measurements can consume account limits or credits. <br>
Mitigation: Review the create_measurement payload and confirm the intended target, probe selection, and effect with the user before running the action. <br>
Risk: Globalping action schemas and service defaults can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload and verify the command output before relying on it. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-globalping) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Globalping homepage](https://globalping.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command examples and JSON action payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the oo CLI to inspect connector schemas and run Globalping actions; action responses are returned as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
