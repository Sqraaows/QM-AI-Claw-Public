## Description: <br>
Operates ASIN Data API through an OOMOL-connected account to inspect collections, manage destinations, and delete collection requests via the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to query ASIN Data API account data and perform destination or collection maintenance through an OOMOL-connected account. It is intended for tasks that require live schema inspection before running connector actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected ASIN Data API account and can access account data. <br>
Mitigation: Install only for users who intentionally use ASIN Data API through OOMOL, and verify the account connection before running actions. <br>
Risk: Update and delete actions can change or remove ASIN Data API account data. <br>
Mitigation: Review the live action schema and exact JSON payload with the user, then obtain explicit approval before write or destructive actions. <br>


## Reference(s): <br>
- [ASIN Data API homepage](https://www.asindataapi.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub ASIN Data API skill page](https://clawhub.ai/oomol/oo-asin-data-api) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses may include connector command output from the oo CLI, including data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
