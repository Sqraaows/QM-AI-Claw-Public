## Description: <br>
Provides agent-facing guidance for operating Clerk through OOMOL's oo CLI connector, including user lookup, listing, creation, updates, deletion, locking, banning, unbanning, and metadata management. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to administer users in a connected Clerk account through the OOMOL connector. It supports read workflows, account lifecycle actions, access-state changes, and metadata updates. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill enables sensitive Clerk account-management operations, including create, update, delete, lock, unlock, ban, and unban actions. <br>
Mitigation: Verify that the requester is authorized, confirm the exact user ID and payload, and keep audit records before running any state-changing operation. <br>
Risk: The security scan verdict is suspicious because activation and confirmation rules are broad for identity administration. <br>
Mitigation: Use the skill only when intentional Clerk administration through OOMOL is required, and require explicit approval for destructive or access-changing actions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-clerk) <br>
- [Clerk homepage](https://clerk.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands run through oo connector return JSON responses with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
