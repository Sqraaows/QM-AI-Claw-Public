## Description: <br>
FraudLabs Pro helps agents screen orders, retrieve fraud screening results, and submit approve or reject feedback through an OOMOL-connected FraudLabs Pro account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, fraud operations teams, and support teams use this skill to run FraudLabs Pro transaction screening workflows from an agent. It supports screening orders, checking existing screening results, and recording review feedback. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires write-capable access to a connected FraudLabs Pro account. <br>
Mitigation: Install it only for users authorized to operate that account and review the connected account access before use. <br>
Risk: The release is described as read-oriented but includes feedback that can approve or reject order transactions. <br>
Mitigation: Confirm the transaction ID, payload, and approve or reject decision with the user before running feedback_order. <br>
Risk: Connector action schemas can change upstream, which can make stale payloads incorrect. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [FraudLabs Pro homepage](https://www.fraudlabspro.com/) <br>
- [ClawHub FraudLabs Pro skill page](https://clawhub.ai/oomol/oo-fraudlabspro) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas for action payloads; requires a connected FraudLabs Pro account.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
