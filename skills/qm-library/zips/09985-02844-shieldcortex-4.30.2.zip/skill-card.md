## Description: <br>
ShieldCortex provides persistent AI-agent memory with semantic search, knowledge graphs, decay, security scanning for prompt injection, credential leaks, and poisoning, plus audits for agent instruction files and MCP configs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jarvis-drakon](https://clawhub.ai/user/jarvis-drakon) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use ShieldCortex to add local persistent memory, recall, memory search, agent instruction auditing, and runtime scanning to AI-agent workflows. It is especially relevant where agents need long-lived context while still checking stored content and tool-bound memory writes for security issues. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can persist selected agent conversation data and memory content locally. <br>
Mitigation: Review or disable auto-memory for sensitive projects, and periodically inspect and purge stored memories and audit logs. <br>
Risk: Cloud sync can transmit team memory content when explicitly enabled. <br>
Mitigation: Keep cloud sync disabled unless team or cloud features are intended, and review sync settings before storing sensitive memories. <br>
Risk: Automatic hook self-repair and relaxed high/critical interceptor defaults may not match every enforcement policy. <br>
Mitigation: Review hook behavior and interceptor configuration before relying on ShieldCortex as an enforcement control. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/jarvis-drakon/shieldcortex) <br>
- [ShieldCortex homepage](https://shieldcortex.ai) <br>
- [ShieldCortex documentation](https://shieldcortex.ai/docs) <br>
- [npm package](https://www.npmjs.com/package/shieldcortex) <br>
- [Changelog](https://shieldcortex.ai/changelog) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and configuration notes] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces agent-facing guidance for using a local memory and security system; no fixed token cap is specified.] <br>

## Skill Version(s): <br>
4.30.2 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
