## Description: <br>
TiDB Cloud enables an agent to inspect TiDB Cloud organization and cluster information through the OOMOL tidb connector and oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to query TiDB Cloud clusters, branches, imports, exports, regions, node specs, API keys, audit logs, cloud providers, and organization quota through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access sensitive TiDB Cloud organization data through an OOMOL-connected account, including API-key and audit-log visibility. <br>
Mitigation: Install and run it only with intended TiDB Cloud scopes, review account permissions, and avoid exposing returned sensitive data unnecessarily. <br>
Risk: Upstream action schemas can change, which may make a prepared payload inaccurate. <br>
Mitigation: Inspect the live action schema with oo connector schema before constructing or running an action payload. <br>
Risk: The get_import documentation includes a confusing write-action warning even though the action is described as fetching an import task. <br>
Mitigation: Confirm the live schema and intended effect before running get_import or any action that appears to modify TiDB Cloud state. <br>


## Reference(s): <br>
- [TiDB Cloud Homepage](https://www.pingcap.com/tidb/cloud/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-tidb) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are returned by the oo CLI as JSON containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
