## Description: <br>
ClassMarker helps agents search and read ClassMarker groups, links, assigned tests, and recent results through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operations staff, and agents with a connected ClassMarker account use this skill to discover accessible groups, links, assigned tests, and recent results for account reporting or result targeting. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read recent ClassMarker results across every group or link available to the connected API key. <br>
Mitigation: Use a ClassMarker API key scoped to only the access needed for the user's task. <br>
Risk: First-time setup may require installing the OOMOL CLI from a remote installer. <br>
Mitigation: Review the OOMOL CLI installer before running the remote install command. <br>
Risk: The skill depends on an OOMOL-connected account that handles ClassMarker credentials server-side. <br>
Mitigation: Install only if the user trusts OOMOL and wants agent access to ClassMarker data through that connected account. <br>


## Reference(s): <br>
- [ClassMarker homepage](https://www.classmarker.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClassMarker skill on ClawHub](https://clawhub.ai/oomol/oo-classmarker) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include a data object and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
