## Description: <br>
Elorus helps agents read, create, and update contacts, products or services, and invoices through an OOMOL-connected Elorus account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees and external users can use this skill to operate Elorus finance workflows from an agent, including listing and retrieving records and preparing confirmed create or update actions for contacts, products or services, and invoices. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an Elorus finance account through OOMOL and uses sensitive connected-account credentials. <br>
Mitigation: Install only if the user trusts OOMOL and is comfortable connecting Elorus through its connector. <br>
Risk: Create and update actions can change invoices, contacts, products, or services in Elorus. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running any write action. <br>
Risk: First-time setup documentation includes remote pipe-to-shell install commands for the oo CLI. <br>
Mitigation: Prefer a verified installation path for the oo CLI and avoid running remote shell installer commands blindly. <br>


## Reference(s): <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-elorus) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Elorus homepage](https://www.elorus.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
