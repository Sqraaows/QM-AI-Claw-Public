#!/usr/bin/env python3
"""
跨境电商视觉内容生成工具
包含AI图片生成、视频制作、详情页排版等功能
"""

import os
import re
import json
import base64
import random
import requests
from typing import List, Dict, Tuple
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO

class VisualGenerator:
    def __init__(self, config: Dict):
        self.config = config
        self.ai_config = config.get('ai_config', {})
        self.template_dir = config.get('template_dir', 'templates/page_templates/')
        self.font_dir = config.get('font_dir', 'templates/fonts/')
        self.output_dir = config.get('output_dir', 'output/')
        
        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 初始化AI客户端
        self.openai_client = self._init_openai_client()
        self.midjourney_client = self._init_midjourney_client()
    
    def _init_openai_client(self):
        """初始化OpenAI客户端"""
        try:
            import openai
            client = openai.OpenAI(api_key=self.ai_config.get('openai_api_key'))
            return client
        except ImportError:
            return None
    
    def _init_midjourney_client(self):
        """初始化MidJourney客户端"""
        # 这里可以集成MidJourney API或第三方服务
        return None
    
    def generate_main_image(self, product_name: str, category: str, style: str = 'professional') -> str:
        """生成产品主图"""
        prompt = self._create_main_image_prompt(product_name, category, style)
        
        try:
            if self.openai_client:
                return self._generate_with_dalle(prompt, product_name, "main_image")
            else:
                return self._generate_with_fallback(product_name, category, "main_image")
        except Exception as e:
            print(f"主图生成失败: {e}")
            return self._generate_placeholder_image(product_name, category)
    
    def _create_main_image_prompt(self, product_name: str, category: str, style: str) -> str:
        """创建主图生成提示词"""
        style_prompts = {
            'professional': "professional product photography, clean white background, studio lighting, 8K, ultra-detailed",
            'lifestyle': "lifestyle product photography, natural setting, realistic lighting, 4K, warm tones",
            'minimalist': "minimalist product design, simple background, high contrast, 4K, clean lines",
            'vibrant': "vibrant product photography, colorful background, dynamic lighting, 8K, eye-catching",
            'technical': "technical product shot, exploded view, detailed specifications, 4K, engineering drawing style"
        }
        
        base_prompt = f"{product_name}, {category}, {style_prompts.get(style, style_prompts['professional'])}"
        
        # 添加类别特定提示
        category_prompts = {
            'electronics': 'high-tech appearance, glossy finish, attention to detail',
            'clothing': 'soft fabric texture, comfortable fit, natural drape',
            'home': 'cozy, warm, inviting atmosphere, high-quality materials',
            'beauty': 'clean, hygienic, professional cosmetic photography',
            'sports': 'dynamic, energetic, action-oriented, durable materials'
        }
        
        for cat, prompt in category_prompts.items():
            if cat.lower() in category.lower():
                base_prompt += ", " + prompt
                break
                
        return base_prompt
    
    def _generate_with_dalle(self, prompt: str, product_name: str, image_type: str) -> str:
        """使用DALL-E生成图片"""
        response = self.openai_client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            size="1024x1024",
            quality="standard",
            n=1,
        )
        
        image_url = response.data[0].url
        
        # 下载图片
        image_response = requests.get(image_url)
        image = Image.open(BytesIO(image_response.content))
        
        # 保存图片
        filename = f"{image_type}_{self._sanitize_filename(product_name)}.png"
        filepath = os.path.join(self.output_dir, filename)
        image.save(filepath, "PNG")
        
        return filepath
    
    def _generate_with_fallback(self, product_name: str, category: str, image_type: str) -> str:
        """使用fallback方法生成图片"""
        # 创建一个简单的占位图片
        width, height = 1024, 1024
        image = Image.new('RGB', (width, height), color='white')
        
        draw = ImageDraw.Draw(image)
        
        # 尝试加载字体
        try:
            font_large = ImageFont.truetype(os.path.join(self.font_dir, 'Arial.ttf'), 40)
            font_small = ImageFont.truetype(os.path.join(self.font_dir, 'Arial.ttf'), 24)
        except:
            font_large = ImageFont.load_default()
            font_small = ImageFont.load_default()
        
        # 添加文本
        text_lines = [product_name, category, "AI Generated Image"]
        
        y_pos = height // 2 - 60
        for line in text_lines:
            text_width, text_height = draw.textsize(line, font=font_large if line == product_name else font_small)
            x_pos = (width - text_width) // 2
            draw.text((x_pos, y_pos), line, fill='black', font=font_large if line == product_name else font_small)
            y_pos += text_height + 20
        
        # 保存图片
        filename = f"{image_type}_{self._sanitize_filename(product_name)}.png"
        filepath = os.path.join(self.output_dir, filename)
        image.save(filepath, "PNG")
        
        return filepath
    
    def _generate_placeholder_image(self, product_name: str, category: str) -> str:
        """生成占位图片"""
        width, height = 1024, 1024
        image = Image.new('RGB', (width, height), color='lightgray')
        
        draw = ImageDraw.Draw(image)
        
        try:
            font = ImageFont.truetype(os.path.join(self.font_dir, 'Arial.ttf'), 32)
        except:
            font = ImageFont.load_default()
        
        text_lines = ["Image Generation Unavailable", product_name, category]
        
        y_pos = height // 2 - 40
        for line in text_lines:
            text_width, text_height = draw.textsize(line, font=font)
            x_pos = (width - text_width) // 2
            draw.text((x_pos, y_pos), line, fill='darkgray', font=font)
            y_pos += text_height + 15
        
        filename = f"placeholder_{self._sanitize_filename(product_name)}.png"
        filepath = os.path.join(self.output_dir, filename)
        image.save(filepath, "PNG")
        
        return filepath
    
    def generate_scene_image(self, product_name: str, category: str, scene: str = 'home') -> str:
        """生成产品场景图"""
        scene_prompts = {
            'home': 'in a cozy home environment, realistic setting, natural lighting, lifestyle photography',
            'office': 'in a modern office setting, professional environment, bright lighting',
            'outdoor': 'outdoor setting, natural environment, sunlight, active lifestyle',
            'gym': 'in a gym/fitness setting, workout environment, energetic atmosphere',
            'travel': 'travel setting, on the go, portable, adventure atmosphere'
        }
        
        prompt = f"{product_name} being used in a {scene_prompts.get(scene, scene_prompts['home'])}, 8K, ultra-realistic"
        
        try:
            if self.openai_client:
                return self._generate_with_dalle(prompt, product_name, "scene_image")
            else:
                return self._generate_with_fallback(product_name, category, "scene_image")
        except Exception as e:
            print(f"场景图生成失败: {e}")
            return self._generate_placeholder_image(product_name, category)
    
    def generate_short_video(self, product_name: str, description: str) -> str:
        """生成短视频"""
        # 这里可以集成Runway ML或其他视频生成API
        # 目前返回占位视频文件路径
        
        try:
            # 创建一个简单的视频占位文件
            filename = f"video_{self._sanitize_filename(product_name)}.mp4"
            filepath = os.path.join(self.output_dir, filename)
            
            # 创建一个空的MP4文件（实际使用时需要生成真实视频）
            with open(filepath, 'w') as f:
                f.write("Video placeholder content")
            
            return filepath
        except Exception as e:
            print(f"视频生成失败: {e}")
            return ""
    
    def generate_detail_page_images(self, product_name: str, description: str, features: List[str]) -> List[str]:
        """生成详情页长图"""
        page_images = []
        
        # 生成标题图
        title_image = self._create_title_section(product_name)
        page_images.append(title_image)
        
        # 生成特性图
        for i, feature in enumerate(features[:5], 1):
            feature_image = self._create_feature_section(feature, i)
            page_images.append(feature_image)
        
        # 生成描述图
        desc_image = self._create_description_section(description)
        page_images.append(desc_image)
        
        # 生成规格图
        spec_image = self._create_specifications_section()
        if spec_image:
            page_images.append(spec_image)
        
        return page_images
    
    def _create_title_section(self, product_name: str) -> str:
        """创建标题部分图片"""
        width, height = 1080, 300
        image = Image.new('RGB', (width, height), color='#2c3e50')
        
        draw = ImageDraw.Draw(image)
        
        try:
            font = ImageFont.truetype(os.path.join(self.font_dir, 'Arial Bold.ttf'), 48)
        except:
            font = ImageFont.load_default()
        
        text_width, text_height = draw.textsize(product_name, font=font)
        x_pos = (width - text_width) // 2
        y_pos = (height - text_height) // 2
        
        draw.text((x_pos, y_pos), product_name, fill='white', font=font)
        
        filename = f"detail_page_title_{self._sanitize_filename(product_name)}.png"
        filepath = os.path.join(self.output_dir, filename)
        image.save(filepath, "PNG")
        
        return filepath
    
    def _create_feature_section(self, feature: str, index: int) -> str:
        """创建特性部分图片"""
        width, height = 1080, 200
        image = Image.new('RGB', (width, height), color='#ecf0f1')
        
        draw = ImageDraw.Draw(image)
        
        try:
            font_num = ImageFont.truetype(os.path.join(self.font_dir, 'Arial Bold.ttf'), 64)
            font_text = ImageFont.truetype(os.path.join(self.font_dir, 'Arial.ttf'), 32)
        except:
            font_num = ImageFont.load_default()
            font_text = ImageFont.load_default()
        
        # 添加序号
        draw.text((50, 60), str(index), fill='#3498db', font=font_num)
        
        # 添加特性文本
        text_width, text_height = draw.textsize(feature, font=font_text)
        draw.text((150, 80 - text_height // 2), feature, fill='#2c3e50', font=font_text)
        
        filename = f"detail_page_feature_{index}_{self._sanitize_filename(feature[:20])}.png"
        filepath = os.path.join(self.output_dir, filename)
        image.save(filepath, "PNG")
        
        return filepath
    
    def _create_description_section(self, description: str) -> str:
        """创建描述部分图片"""
        width, height = 1080, 400
        image = Image.new('RGB', (width, height), color='white')
        
        draw = ImageDraw.Draw(image)
        
        try:
            font_title = ImageFont.truetype(os.path.join(self.font_dir, 'Arial Bold.ttf'), 36)
            font_text = ImageFont.truetype(os.path.join(self.font_dir, 'Arial.ttf'), 28)
        except:
            font_title = ImageFont.load_default()
            font_text = ImageFont.load_default()
        
        # 添加标题
        draw.text((50, 30), "Product Description", fill='#2c3e50', font=font_title)
        
        # 添加描述文本（自动换行）
        margin = 50
        padding = 30
        max_width = width - 2 * margin
        
        lines = self._wrap_text(description, font_text, max_width)
        y_pos = margin + padding + 20
        
        for line in lines[:8]:  # 限制显示行数
            draw.text((margin, y_pos), line, fill='#34495e', font=font_text)
            y_pos += font_text.size + 10
        
        filename = f"detail_page_description_{self._sanitize_filename(description[:20])}.png"
        filepath = os.path.join(self.output_dir, filename)
        image.save(filepath, "PNG")
        
        return filepath
    
    def _create_specifications_section(self) -> str:
        """创建规格部分图片"""
        # 这里可以根据实际产品数据生成规格图
        return ""
    
    def _wrap_text(self, text: str, font, max_width: int) -> List[str]:
        """文本自动换行"""
        words = text.split()
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            test_width, _ = font.getsize(test_line)
            
            if test_width <= max_width:
                current_line.append(word)
            else:
                lines.append(' '.join(current_line))
                current_line = [word]
                
        if current_line:
            lines.append(' '.join(current_line))
            
        return lines
    
    def adapt_to_platform(self, image_path: str, platform: str) -> str:
        """将图片适配到特定平台"""
        platform_specs = {
            'amazon': {'main': (1000, 1000), 'detail': (1000, 1000)},  # 亚马逊要求至少1000x1000
            'aliexpress': {'main': (800, 800), 'detail': (750, 750)},   # 速卖通标准尺寸
            'ozon': {'main': (800, 800), 'detail': (800, 800)}         # Ozon标准尺寸
        }
        
        specs = platform_specs.get(platform, platform_specs['amazon'])
        
        try:
            image = Image.open(image_path)
            
            # 处理主图
            if 'main' in image_path.lower():
                target_size = specs['main']
            else:
                target_size = specs['detail']
                
            # 调整大小并保持比例
            image.thumbnail(target_size, Image.Resampling.LANCZOS)
            
            # 添加白色背景（如果需要）
            new_image = Image.new('RGB', target_size, (255, 255, 255))
            paste_position = ((target_size[0] - image.width) // 2, 
                             (target_size[1] - image.height) // 2)
            new_image.paste(image, paste_position)
            
            # 保存适配后的图片
            filename = f"{platform}_{os.path.basename(image_path)}"
            filepath = os.path.join(self.output_dir, filename)
            new_image.save(filepath, "PNG", quality=95)
            
            return filepath
        except Exception as e:
            print(f"图片平台适配失败: {e}")
            return image_path
    
    def remove_image_duplicates(self, image_paths: List[str]) -> List[str]:
        """去除重复图片"""
        seen_hashes = set()
        unique_images = []
        
        for path in image_paths:
            try:
                with open(path, 'rb') as f:
                    image_hash = base64.b64encode(f.read()).decode('utf-8')[:32]
                    
                if image_hash not in seen_hashes:
                    seen_hashes.add(image_hash)
                    unique_images.append(path)
            except Exception as e:
                print(f"图片去重失败: {e}")
                unique_images.append(path)
                
        return unique_images
    
    def modify_image_md5(self, image_path: str) -> str:
        """修改图片MD5值（防重复铺货）"""
        try:
            image = Image.open(image_path)
            draw = ImageDraw.Draw(image)
            
            # 添加一个不可见的小点
            x = random.randint(0, image.width - 1)
            y = random.randint(0, image.height - 1)
            color = (255, 255, 255, 0) if image.mode == 'RGBA' else (255, 255, 255)
            draw.point((x, y), fill=color)
            
            # 保存修改后的图片
            filename = f"md5_modified_{os.path.basename(image_path)}"
            filepath = os.path.join(self.output_dir, filename)
            image.save(filepath, "PNG", quality=95)
            
            return filepath
        except Exception as e:
            print(f"MD5修改失败: {e}")
            return image_path
    
    def _sanitize_filename(self, filename: str) -> str:
        """清理文件名"""
        filename = re.sub(r'[^\\w\\s-]', '', filename.lower())
        filename = re.sub(r'[-\\s]+', '-', filename).strip('-_')
        return filename[:50]  # 限制长度

if __name__ == "__main__":
    # 示例用法
    visual_gen = VisualGenerator({})
    
    # 生成主图
    main_image = visual_gen.generate_main_image(
        "Wireless Bluetooth Earbuds", 
        "Electronics/Headphones",
        "professional"
    )
    print(f"生成的主图: {main_image}")
    
    # 生成场景图
    scene_image = visual_gen.generate_scene_image(
        "Wireless Bluetooth Earbuds", 
        "Electronics/Headphones",
        "home"
    )
    print(f"生成的场景图: {scene_image}")
    
    # 生成详情页
    detail_images = visual_gen.generate_detail_page_images(
        "Wireless Bluetooth Earbuds",
        "Premium wireless earbuds with active noise cancelling, 30-hour battery life, and comfortable fit.",
        ["Active Noise Cancelling", "30-hour Battery Life", "IPX7 Waterproof", "Touch Controls"]
    )
    print(f"生成的详情页图片数量: {len(detail_images)}")
    
    # 平台适配
    adapted_image = visual_gen.adapt_to_platform(main_image, "amazon")
    print(f"亚马逊适配后的图片: {adapted_image}")