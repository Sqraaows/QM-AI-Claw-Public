#!/usr/bin/env python3
"""
跨境电商详情页制作工具
包含模块化图文合成、多平台格式转换等功能
"""

import os
import re
import json
import time
from typing import List, Dict, Tuple
from PIL import Image, ImageDraw, ImageFont

class PageBuilder:
    def __init__(self, config: Dict):
        self.config = config
        self.template_dir = config.get('template_dir', 'templates/page_templates/')
        self.font_dir = config.get('font_dir', 'templates/fonts/')
        self.output_dir = config.get('output_dir', 'output/')
        self.platform_templates = self._load_platform_templates()
        
        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 初始化字体
        self._init_fonts()
    
    def _load_platform_templates(self) -> Dict:
        """加载多平台详情页模板"""
        templates = {}
        
        # 内置模板
        templates['amazon'] = {
            'name': '亚马逊A+页面模板',
            'layout': ['title', 'feature_3', 'image_text', 'specs', 'footer'],
            'width': 1000,
            'color_scheme': {'primary': '#232F3E', 'secondary': '#FF9900', 'background': '#FFFFFF'}
        }
        
        templates['aliexpress'] = {
            'name': '速卖通详情页模板',
            'layout': ['title', 'image_slider', 'feature_list', 'description', 'specs', 'footer'],
            'width': 750,
            'color_scheme': {'primary': '#FF4444', 'secondary': '#FF8800', 'background': '#FFFFFF'}
        }
        
        templates['ozon'] = {
            'name': 'Ozon详情页模板',
            'layout': ['title', 'main_image', 'features', 'description', 'video', 'specs'],
            'width': 800,
            'color_scheme': {'primary': '#005BBB', 'secondary': '#FFD500', 'background': '#FFFFFF'}
        }
        
        # 加载自定义模板
        if os.path.exists(self.template_dir):
            for filename in os.listdir(self.template_dir):
                if filename.endswith('.json'):
                    try:
                        with open(os.path.join(self.template_dir, filename), 'r', encoding='utf-8') as f:
                            template = json.load(f)
                            template_name = os.path.splitext(filename)[0]
                            templates[template_name] = template
                    except Exception as e:
                        print(f"加载模板失败: {e}")
        
        return templates
    
    def _init_fonts(self):
        """初始化字体"""
        self.fonts = {}
        
        try:
            self.fonts['title'] = ImageFont.truetype(os.path.join(self.font_dir, 'Arial Bold.ttf'), 48)
            self.fonts['subtitle'] = ImageFont.truetype(os.path.join(self.font_dir, 'Arial Bold.ttf'), 36)
            self.fonts['body'] = ImageFont.truetype(os.path.join(self.font_dir, 'Arial.ttf'), 28)
            self.fonts['small'] = ImageFont.truetype(os.path.join(self.font_dir, 'Arial.ttf'), 20)
        except Exception as e:
            print(f"加载字体失败，使用默认字体: {e}")
            self.fonts['title'] = ImageFont.load_default()
            self.fonts['subtitle'] = ImageFont.load_default()
            self.fonts['body'] = ImageFont.load_default()
            self.fonts['small'] = ImageFont.load_default()
    
    def build_detail_page(self, title: str, bullet_points: List[str], images: List[str], 
                         parameters: Dict = None, platform: str = 'amazon') -> str:
        """构建完整详情页"""
        template = self.platform_templates.get(platform, self.platform_templates['amazon'])
        
        # 创建页面元素
        page_elements = []
        
        for section_type in template['layout']:
            section_func = self._get_section_builder(section_type)
            if section_func:
                try:
                    section_image = section_func(title, bullet_points, images, parameters, template)
                    if section_image:
                        page_elements.append(section_image)
                except Exception as e:
                    print(f"生成{section_type}部分失败: {e}")
        
        # 拼接所有部分
        if page_elements:
            full_page = self._combine_sections(page_elements, template['width'])
            filename = f"detail_page_{platform}_{int(time.time())}.png"
            filepath = os.path.join(self.output_dir, filename)
            full_page.save(filepath, "PNG", quality=95)
            return filepath
        
        return ""
    
    def _get_section_builder(self, section_type: str):
        """获取对应部分的构建函数"""
        section_builders = {
            'title': self._build_title_section,
            'feature_3': self._build_3_feature_section,
            'feature_list': self._build_feature_list_section,
            'image_text': self._build_image_text_section,
            'image_slider': self._build_image_slider_section,
            'main_image': self._build_main_image_section,
            'description': self._build_description_section,
            'specs': self._build_specs_section,
            'footer': self._build_footer_section
        }
        
        return section_builders.get(section_type)
    
    def _build_title_section(self, title: str, bullet_points: List[str], images: List[str], 
                           parameters: Dict, template: Dict) -> Image.Image:
        """构建标题部分"""
        width = template['width']
        height = 300
        
        image = Image.new('RGB', (width, height), color=template['color_scheme']['background'])
        draw = ImageDraw.Draw(image)
        
        # 添加背景装饰
        self._draw_gradient_background(draw, width, height, template['color_scheme']['primary'])
        
        # 添加标题文本
        title_text = self._wrap_text(title, self.fonts['title'], width - 100)
        
        y_pos = 50
        for line in title_text:
            text_width, text_height = self._get_text_size(line, self.fonts['title'])
            x_pos = (width - text_width) // 2
            draw.text((x_pos, y_pos), line, fill='white', font=self.fonts['title'])
            y_pos += text_height + 10
        
        return image
    
    def _build_3_feature_section(self, title: str, bullet_points: List[str], images: List[str], 
                               parameters: Dict, template: Dict) -> Image.Image:
        """构建三列特性部分"""
        width = template['width']
        height = 400
        
        image = Image.new('RGB', (width, height), color=template['color_scheme']['background'])
        draw = ImageDraw.Draw(image)
        
        # 分割为三列
        col_width = (width - 40) // 3
        
        for i, feature in enumerate(bullet_points[:3]):
            x_pos = 20 + i * (col_width + 10)
            y_pos = 30
            
            # 添加图标背景
            draw.ellipse([x_pos + col_width//2 - 30, y_pos, x_pos + col_width//2 + 30, y_pos + 60], 
                        fill=template['color_scheme']['secondary'])
            
            # 添加序号
            number_text = str(i+1)
            num_width, num_height = self._get_text_size(number_text, self.fonts['subtitle'])
            draw.text((x_pos + col_width//2 - num_width//2, y_pos + 15), 
                     number_text, fill='white', font=self.fonts['subtitle'])
            
            # 添加特性文本
            feature_text = self._wrap_text(feature, self.fonts['body'], col_width - 20)
            text_y = y_pos + 80
            
            for line in feature_text[:3]:
                text_width, text_height = self._get_text_size(line, self.fonts['body'])
                draw.text((x_pos + col_width//2 - text_width//2, text_y), 
                         line, fill=template['color_scheme']['primary'], font=self.fonts['body'])
                text_y += text_height + 8
        
        return image
    
    def _build_feature_list_section(self, title: str, bullet_points: List[str], images: List[str], 
                                  parameters: Dict, template: Dict) -> Image.Image:
        """构建特性列表部分"""
        width = template['width']
        line_height = 60
        height = min(600, line_height * len(bullet_points) + 40)
        
        image = Image.new('RGB', (width, height), color=template['color_scheme']['background'])
        draw = ImageDraw.Draw(image)
        
        # 添加标题
        subtitle_text = "核心特性"
        sub_width, sub_height = self._get_text_size(subtitle_text, self.fonts['subtitle'])
        draw.text((20, 10), subtitle_text, fill=template['color_scheme']['primary'], font=self.fonts['subtitle'])
        
        # 添加特性列表
        for i, feature in enumerate(bullet_points[:8]):
            y_pos = 70 + i * line_height
            
            # 添加图标
            draw.rectangle([20, y_pos, 50, y_pos + 30], fill=template['color_scheme']['secondary'])
            draw.text((28, y_pos + 2), "✓", fill='white', font=self.fonts['body'])
            
            # 添加文本
            feature_text = self._wrap_text(feature, self.fonts['body'], width - 80)
            text_width, text_height = self._get_text_size(feature_text[0], self.fonts['body'])
            draw.text((70, y_pos + 10 - text_height//2), feature_text[0], 
                     fill=template['color_scheme']['primary'], font=self.fonts['body'])
            
            # 添加分隔线
            if i < len(bullet_points) - 1:
                draw.line([20, y_pos + line_height - 10, width - 20, y_pos + line_height - 10], 
                          fill='#EEEEEE', width=1)
        
        return image
    
    def _build_main_image_section(self, title: str, bullet_points: List[str], images: List[str], 
                                parameters: Dict, template: Dict) -> Image.Image:
        """构建主图片展示部分"""
        width = template['width']
        height = int(width * 0.8)  # 保持图片比例
        
        image = Image.new('RGB', (width, height), color='#F5F5F5')
        
        # 使用第一张图片或占位图
        if images:
            try:
                main_image = Image.open(images[0])
                main_image.thumbnail((width - 40, height - 40))
                
                # 居中放置
                paste_x = (width - main_image.width) // 2
                paste_y = (height - main_image.height) // 2
                image.paste(main_image, (paste_x, paste_y))
            except Exception as e:
                print(f"加载主图失败: {e}")
                draw = ImageDraw.Draw(image)
                draw.text((width//2 - 100, height//2 - 20), "主图展示区", fill='#999999', font=self.fonts['body'])
        
        return image
    
    def _build_image_text_section(self, title: str, bullet_points: List[str], images: List[str], 
                                parameters: Dict, template: Dict) -> Image.Image:
        """构建图片加文本部分"""
        width = template['width']
        height = 400
        
        image = Image.new('RGB', (width, height), color=template['color_scheme']['background'])
        draw = ImageDraw.Draw(image)
        
        # 左半部分图片
        img_width = width // 2
        img_height = height - 40
        
        if images:
            try:
                section_image = Image.open(images[0])
                section_image.thumbnail((img_width, img_height))
                image.paste(section_image, (20, 20))
            except Exception as e:
                draw.rectangle([20, 20, img_width + 10, img_height + 10], fill='#F5F5F5')
                draw.text((20 + img_width//2 - 60, 20 + img_height//2 - 20), 
                          "图片展示区", fill='#999999', font=self.fonts['body'])
        
        # 右半部分文本
        text_x = img_width + 40
        text_y = 40
        
        for i, feature in enumerate(bullet_points[:3]):
            feature_text = self._wrap_text(feature, self.fonts['body'], width - img_width - 60)
            
            for line in feature_text[:2]:
                draw.text((text_x, text_y), line, fill=template['color_scheme']['primary'], font=self.fonts['body'])
                text_y += 40
            text_y += 20
        
        return image
    
    def _build_image_slider_section(self, title: str, bullet_points: List[str], images: List[str], 
                                  parameters: Dict, template: Dict) -> Image.Image:
        """构建图片轮播部分"""
        width = template['width']
        height = 400
        
        image = Image.new('RGB', (width, height), color='#F5F5F5')
        draw = ImageDraw.Draw(image)
        
        # 显示三张缩略图
        if images:
            thumb_width = (width - 60) // 3
            thumb_height = height - 40
            
            for i in range(min(3, len(images))):
                try:
                    thumb_img = Image.open(images[i])
                    thumb_img.thumbnail((thumb_width, thumb_height))
                    
                    x_pos = 20 + i * (thumb_width + 10)
                    y_pos = 20
                    image.paste(thumb_img, (x_pos, y_pos))
                except Exception as e:
                    print(f"加载轮播图失败: {e}")
                    draw.rectangle([20 + i * (thumb_width + 10), 20, 
                                   20 + i * (thumb_width + 10) + thumb_width, 20 + thumb_height], 
                                  fill='#DDDDDD')
        
        # 添加轮播指示器
        draw.text((width//2 - 50, height - 30), "◀ 查看更多图片 ▶", fill='#666666', font=self.fonts['small'])
        
        return image
    
    def _build_description_section(self, title: str, bullet_points: List[str], images: List[str], 
                                 parameters: Dict, template: Dict) -> Image.Image:
        """构建详细描述部分"""
        width = template['width']
        
        # 生成描述文本
        description_text = "\n".join([
            "产品概述:",
            "这是一款高品质的产品，为您提供卓越的使用体验。我们致力于为客户提供最好的产品和服务。",
            "\n特点优势:",
            "- 采用最新技术，性能卓越",
            "- 精心设计的外观，时尚美观",
            "- 严格的质量控制，可靠耐用",
            "- 完善的售后服务，购物无忧"
        ])
        
        # 计算高度
        lines = self._wrap_text(description_text, self.fonts['body'], width - 40)
        height = len(lines) * 30 + 100
        height = min(height, 800)  # 限制最大高度
        
        image = Image.new('RGB', (width, height), color=template['color_scheme']['background'])
        draw = ImageDraw.Draw(image)
        
        # 添加标题
        subtitle_text = "详细描述"
        sub_width, sub_height = self._get_text_size(subtitle_text, self.fonts['subtitle'])
        draw.text((20, 10), subtitle_text, fill=template['color_scheme']['primary'], font=self.fonts['subtitle'])
        
        # 添加文本
        y_pos = 60
        for line in lines[:int((height - 80)/30)]:
            draw.text((20, y_pos), line, fill='#333333', font=self.fonts['body'])
            y_pos += 30
        
        return image
    
    def _build_specs_section(self, title: str, bullet_points: List[str], images: List[str], 
                           parameters: Dict, template: Dict) -> Image.Image:
        """构建规格参数部分"""
        width = template['width']
        height = 300
        
        image = Image.new('RGB', (width, height), color=template['color_scheme']['background'])
        draw = ImageDraw.Draw(image)
        
        # 添加标题
        subtitle_text = "产品规格"
        sub_width, sub_height = self._get_text_size(subtitle_text, self.fonts['subtitle'])
        draw.text((20, 10), subtitle_text, fill=template['color_scheme']['primary'], font=self.fonts['subtitle'])
        
        # 示例规格数据
        specs = {
            '材质': '高品质材料',
            '尺寸': '待定',
            '重量': '待定',
            '颜色': '多种可选',
            '包装清单': '主机, 说明书, 保修卡'
        }
        
        # 使用提供的参数
        if parameters:
            specs.update(parameters)
        
        # 绘制表格
        y_pos = 60
        row_height = 40
        
        for i, (key, value) in enumerate(list(specs.items())[:6]):
            # 绘制背景
            if i % 2 == 1:
                draw.rectangle([0, y_pos, width, y_pos + row_height - 1], fill='#F8F8F8')
            
            # 绘制文本
            key_width, key_height = self._get_text_size(key, self.fonts['body'])
            draw.text((20, y_pos + 5), key, fill='#555555', font=self.fonts['body'])
            
            value_width, value_height = self._get_text_size(value, self.fonts['body'])
            draw.text((width//2, y_pos + 5), value, fill='#333333', font=self.fonts['body'])
            
            # 绘制分隔线
            draw.line([0, y_pos + row_height - 1, width, y_pos + row_height - 1], fill='#EEEEEE', width=1)
            
            y_pos += row_height
        
        return image
    
    def _build_footer_section(self, title: str, bullet_points: List[str], images: List[str], 
                            parameters: Dict, template: Dict) -> Image.Image:
        """构建页脚部分"""
        width = template['width']
        height = 200
        
        image = Image.new('RGB', (width, height), color=template['color_scheme']['primary'])
        draw = ImageDraw.Draw(image)
        
        # 添加文本
        footer_texts = [
            "✅ 正品保证",
            "🚚 快速发货",
            "🛡️ 售后保障",
            "💬 在线客服"
        ]
        
        col_width = width // 4
        
        for i, text in enumerate(footer_texts):
            x_pos = i * col_width + col_width//2
            y_pos = 80
            
            text_width, text_height = self._get_text_size(text, self.fonts['body'])
            draw.text((x_pos - text_width//2, y_pos), text, fill='white', font=self.fonts['body'])
        
        # 添加版权信息
        copyright_text = "© 2024 版权所有"
        cr_width, cr_height = self._get_text_size(copyright_text, self.fonts['small'])
        draw.text((width - cr_width - 20, height - cr_height - 10), copyright_text, fill='#CCCCCC', font=self.fonts['small'])
        
        return image
    
    def _combine_sections(self, sections: List[Image.Image], width: int) -> Image.Image:
        """拼接所有部分为完整页面"""
        total_height = sum(section.height for section in sections)
        
        full_page = Image.new('RGB', (width, total_height), color='#FFFFFF')
        
        y_pos = 0
        for section in sections:
            full_page.paste(section, (0, y_pos))
            y_pos += section.height
            
        return full_page
    
    def _draw_gradient_background(self, draw: ImageDraw.Draw, width: int, height: int, color: str):
        """绘制渐变背景"""
        r, g, b = self._hex_to_rgb(color)
        
        for y in range(height):
            alpha = y / height
            new_r = int(r * (1 - alpha) + 255 * alpha)
            new_g = int(g * (1 - alpha) + 255 * alpha)
            new_b = int(b * (1 - alpha) + 255 * alpha)
            
            draw.line([(0, y), (width, y)], fill=(new_r, new_g, new_b))
    
    def _init_fonts(self):
        """初始化字体"""
        # 尝试加载各种字体
        font_paths = [
            'Arial.ttf',
            'Arial Bold.ttf',
            'simhei.ttf',  # 黑体
            'simsun.ttc',  # 宋体
        ]
        
        for font_path in font_paths:
            try:
                full_path = os.path.join(self.font_dir, font_path)
                if os.path.exists(full_path):
                    size = 48 if 'Bold' in font_path else 36
                    ImageFont.truetype(full_path, size)
            except:
                pass
    
    def _wrap_text(self, text: str, font, max_width: int) -> List[str]:
        """文本自动换行"""
        words = text.split()
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            test_width, _ = self._get_text_size(test_line, font)
            
            if test_width <= max_width:
                current_line.append(word)
            else:
                lines.append(' '.join(current_line))
                current_line = [word]
                
        if current_line:
            lines.append(' '.join(current_line))
            
        return lines
    
    def _get_text_size(self, text: str, font) -> Tuple[int, int]:
        """获取文本尺寸"""
        try:
            return font.getsize(text)
        except:
            # 简化处理
            return (len(text) * 12, 24)
    
    def _hex_to_rgb(self, hex_color: str) -> Tuple[int, int, int]:
        """十六进制颜色转RGB"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def convert_between_platforms(self, source_file: str, target_platform: str) -> str:
        """多平台详情页格式转换"""
        # 这里可以实现不同平台详情页格式的转换
        # 目前返回原文件路径
        return source_file
    
    def get_platform_format(self, platform: str) -> Dict:
        """获取平台格式要求"""
        format_specs = {
            'amazon': {
                'max_width': 1000,
                'max_height': 20000,
                'allowed_formats': ['JPG', 'PNG'],
                'file_size_limit': '10MB'
            },
            'aliexpress': {
                'max_width': 750,
                'max_height': 10000,
                'allowed_formats': ['JPG', 'PNG'],
                'file_size_limit': '5MB'
            },
            'ozon': {
                'max_width': 800,
                'max_height': 15000,
                'allowed_formats': ['JPG', 'PNG'],
                'file_size_limit': '8MB'
            }
        }
        
        return format_specs.get(platform, format_specs['amazon'])

if __name__ == "__main__":
    # 示例用法
    page_builder = PageBuilder({})
    
    # 构建亚马逊详情页
    amazon_page = page_builder.build_detail_page(
        "Wireless Bluetooth Earbuds Noise Cancelling",
        ["Active Noise Cancelling", "30-hour Battery Life", "IPX7 Waterproof", "Touch Controls"],
        [],  # 图片路径列表
        platform="amazon"
    )
    print(f"生成的亚马逊详情页: {amazon_page}")
    
    # 构建速卖通详情页
    aliexpress_page = page_builder.build_detail_page(
        "Wireless Bluetooth Earbuds Noise Cancelling",
        ["Active Noise Cancelling", "30-hour Battery Life", "IPX7 Waterproof", "Touch Controls"],
        [],
        platform="aliexpress"
    )
    print(f"生成的速卖通详情页: {aliexpress_page}")