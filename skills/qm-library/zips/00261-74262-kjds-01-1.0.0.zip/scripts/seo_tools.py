#!/usr/bin/env python3
"""
跨境电商SEO文案工具
包含标题生成、关键词挖掘、描述创作、违禁词检测等功能
"""

import re
import json
import random
from typing import List, Dict, Tuple
from collections import Counter

class SEOTools:
    def __init__(self, config: Dict):
        self.config = config
        self.keyword_database = self._load_keyword_database()
        self.forbidden_words = self._load_forbidden_words()
        self.platform_rules = self._load_platform_rules()
        self.translator = self._init_translator()
    
    def _load_keyword_database(self) -> Dict:
        """加载关键词数据库"""
        try:
            with open('data/keyword_database/keywords.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
    
    def _load_forbidden_words(self) -> Dict[str, List[str]]:
        """加载违禁词库"""
        try:
            forbidden = {}
            for platform in ['amazon', 'aliexpress', 'ozon']:
                with open(f'data/forbidden_words/{platform}_forbidden.txt', 'r', encoding='utf-8') as f:
                    forbidden[platform] = [line.strip() for line in f if line.strip()]
            return forbidden
        except FileNotFoundError:
            return {}
    
    def _load_platform_rules(self) -> Dict:
        """加载平台规则"""
        try:
            with open('data/platform_rules/platform_rules.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {
                'amazon': {'title_max_length': 200, 'bullet_points': 5},
                'aliexpress': {'title_max_length': 128, 'bullet_points': 5},
                'ozon': {'title_max_length': 150, 'bullet_points': 7}
            }
    
    def _init_translator(self):
        """初始化翻译器"""
        try:
            from google.cloud import translate_v2 as translate
            return translate.Client()
        except ImportError:
            return None
    
    def generate_title(self, product_name: str, category: str, platform: str, keywords: List[str] = None) -> str:
        """智能生成平台专属标题"""
        rules = self.platform_rules.get(platform, {})
        max_length = rules.get('title_max_length', 200)
        
        # 基础关键词
        base_keywords = [product_name] + (keywords or [])
        
        # 根据平台生成不同风格
        if platform == 'amazon':
            return self._generate_amazon_title(product_name, category, base_keywords, max_length)
        elif platform == 'aliexpress':
            return self._generate_aliexpress_title(product_name, category, base_keywords, max_length)
        elif platform == 'ozon':
            return self._generate_ozon_title(product_name, category, base_keywords, max_length)
        else:
            return self._generate_general_title(product_name, base_keywords, max_length)
    
    def _generate_amazon_title(self, product_name: str, category: str, keywords: List[str], max_length: int) -> str:
        """生成亚马逊风格标题"""
        title_parts = []
        
        # 品牌 + 产品名
        title_parts.append(f"{product_name}")
        
        # 核心特性
        feature_keywords = self._extract_feature_keywords(keywords)
        if feature_keywords:
            title_parts.append(", ".join(feature_keywords[:3]))
        
        # 适用信息
        usage_keywords = self._extract_usage_keywords(keywords)
        if usage_keywords:
            title_parts.append(f"for {', '.join(usage_keywords[:2])}")
        
        # 规格信息
        spec_keywords = self._extract_spec_keywords(keywords)
        if spec_keywords:
            title_parts.append(", ".join(spec_keywords[:2]))
        
        # 组合并截断
        full_title = " ".join(title_parts)
        if len(full_title) > max_length:
            full_title = full_title[:max_length-3] + "..."
        
        # 优化关键词密度
        return self._optimize_keyword_density(full_title, keywords)
    
    def _generate_aliexpress_title(self, product_name: str, category: str, keywords: List[str], max_length: int) -> str:
        """生成速卖通风格标题"""
        title_template = "{brand} {product} {features} {specs} {usage} - Best Price {category}"
        
        features = self._extract_feature_keywords(keywords)[:4]
        specs = self._extract_spec_keywords(keywords)[:2]
        usage = self._extract_usage_keywords(keywords)[:2]
        
        title = title_template.format(
            brand = "2025 New",
            product = product_name,
            features = ", ".join(features) if features else "",
            specs = ", ".join(specs) if specs else "",
            usage = f"for {', '.join(usage)}" if usage else "",
            category = category.split('/')[-1] if '/' in category else category
        )
        
        # 清理多余空格
        title = re.sub(' +', ' ', title).strip()
        title = re.sub(' - ', ' - ', title)
        
        # 截断
        if len(title) > max_length:
            title = title[:max_length-3] + "..."
            
        return title
    
    def _generate_ozon_title(self, product_name: str, category: str, keywords: List[str], max_length: int) -> str:
        """生成Ozon风格标题"""
        # Ozon标题更侧重俄语本地化和关键词密度
        title_parts = []
        
        # 产品名（俄语优先）
        ru_product_name = self.translate(product_name, 'ru') or product_name
        title_parts.append(ru_product_name)
        
        # 核心关键词
        main_keywords = [kw for kw in keywords if len(kw.split()) <= 2][:3]
        if main_keywords:
            title_parts.append(", ".join(main_keywords))
        
        # 促销信息
        title_parts.append("Акция! Лучшая цена!")
        
        # 组合
        title = " ".join(title_parts)
        
        # 截断
        if len(title) > max_length:
            title = title[:max_length-3] + "..."
            
        return title
    
    def _generate_general_title(self, product_name: str, keywords: List[str], max_length: int) -> str:
        """生成通用标题"""
        title_parts = [product_name]
        
        relevant_keywords = [kw for kw in keywords if kw.lower() not in product_name.lower()][:5]
        if relevant_keywords:
            title_parts.append(", ".join(relevant_keywords))
        
        title = " ".join(title_parts)
        
        if len(title) > max_length:
            title = title[:max_length-3] + "..."
            
        return title
    
    def _extract_feature_keywords(self, keywords: List[str]) -> List[str]:
        """提取特性关键词"""
        feature_patterns = [
            r'waterproof|water resistant|ipx\d',
            r'wireless|bluetooth|wifi',
            r'noise cancelling|noise reduction',
            r'fast charging|quick charge',
            r'durable|shockproof',
            r'ergonomic|comfortable'
        ]
        
        feature_keywords = []
        for kw in keywords:
            if any(re.search(pattern, kw.lower()) for pattern in feature_patterns):
                feature_keywords.append(kw)
                
        return feature_keywords
    
    def _extract_usage_keywords(self, keywords: List[str]) -> List[str]:
        """提取使用场景关键词"""
        usage_patterns = [
            r'for \w+|compatible with \w+',
            r'sports|fitness|running|gym',
            r'travel|outdoor|camping',
            r'home|office|gaming'
        ]
        
        usage_keywords = []
        for kw in keywords:
            if any(re.search(pattern, kw.lower()) for pattern in usage_patterns):
                keyword = re.sub(r'^for |^compatible with ', '', kw.lower(), flags=re.IGNORECASE)
                usage_keywords.append(keyword.title())
                
        return usage_keywords
    
    def _extract_spec_keywords(self, keywords: List[str]) -> List[str]:
        """提取规格关键词"""
        spec_patterns = [
            r'\d+mm|\d+inch|\d+cm',
            r'\d+gb|\d+tb',
            r'\d+mah|\d+hour battery',
            r'\d+k resolution|\d+p'
        ]
        
        spec_keywords = []
        for kw in keywords:
            if any(re.search(pattern, kw.lower()) for pattern in spec_patterns):
                spec_keywords.append(kw)
                
        return spec_keywords
    
    def _optimize_keyword_density(self, text: str, keywords: List[str]) -> str:
        """优化关键词密度"""
        text_lower = text.lower()
        keyword_counts = {}
        
        for kw in keywords:
            kw_lower = kw.lower()
            count = text_lower.count(kw_lower)
            keyword_counts[kw] = count
        
        # 平衡关键词分布
        optimized_text = text
        for kw, count in keyword_counts.items():
            if count == 0 and len(optimized_text) + len(kw) + 1 <= 200:
                optimized_text += " " + kw
            elif count > 3:
                # 减少关键词重复
                words = optimized_text.split()
                kw_lower = kw.lower()
                keep_indices = []
                keep_count = 0
                
                for i, word in enumerate(words):
                    if word.lower() == kw_lower:
                        if keep_count < 3:
                            keep_indices.append(i)
                            keep_count += 1
                    else:
                        keep_indices.append(i)
                        
                optimized_text = " ".join([words[i] for i in sorted(keep_indices)])
                
        return optimized_text
    
    def generate_bullet_points(self, description: str, platform: str, features: List[str] = None) -> List[str]:
        """生成五点描述/副标题"""
        rules = self.platform_rules.get(platform, {})
        num_points = rules.get('bullet_points', 5)
        
        bullet_points = []
        
        # 从描述中提取卖点
        description_points = self._extract_points_from_description(description)
        bullet_points.extend(description_points[:num_points])
        
        # 添加额外特性
        if features:
            feature_points = [self._format_feature_point(f) for f in features]
            bullet_points.extend(feature_points[:num_points - len(bullet_points)])
        
        # 如果仍不够，生成通用卖点
        if len(bullet_points) < num_points:
            missing = num_points - len(bullet_points)
            general_points = self._generate_general_points(description, missing)
            bullet_points.extend(general_points)
        
        # 格式化并截断
        formatted_points = []
        for point in bullet_points[:num_points]:
            formatted = self._format_bullet_point(point, platform)
            formatted_points.append(formatted)
            
        return formatted_points
    
    def _extract_points_from_description(self, description: str) -> List[str]:
        """从描述中提取卖点"""
        # 分割句子
        sentences = re.split(r'[.!?]+', description)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        # 提取包含关键词的句子
        key_patterns = [r'\bwith\b|\bfeature\b|\bincludes\b|\bhas\b|\boffers\b']
        points = []
        
        for sentence in sentences:
            if any(re.search(pattern, sentence.lower()) for pattern in key_patterns):
                points.append(sentence)
                
        return points
    
    def _format_feature_point(self, feature: str) -> str:
        """格式化特性为卖点"""
        feature_lower = feature.lower()
        
        # 添加引导词
        if not feature_lower.startswith(('with ', 'features ', 'includes ')):
            if feature_lower.startswith(('a ', 'an ', 'the ')):
                feature = "With " + feature
            else:
                feature = "With " + feature
                
        return feature
    
    def _generate_general_points(self, description: str, count: int) -> List[str]:
        """生成通用卖点"""
        general_points = [
            "High quality materials for long-lasting durability",
            "Easy to use and maintain",
            "Satisfaction guaranteed with our 30-day return policy",
            "Fast and reliable shipping worldwide",
            "Compatible with most devices and systems"
        ]
        
        # 选择与描述相关的点
        relevant_points = []
        desc_lower = description.lower()
        
        if any(word in desc_lower for word in ['electronic', 'device', 'tech']):
            relevant_points.append("Advanced technology for superior performance")
        elif any(word in desc_lower for word in ['kitchen', 'cook', 'food']):
            relevant_points.append("Safe and easy to clean for everyday use")
        elif any(word in desc_lower for word in ['clothing', 'wear', 'apparel']):
            relevant_points.append("Comfortable and stylish design for all occasions")
        
        # 补充通用点
        while len(relevant_points) < count:
            point = random.choice(general_points)
            if point not in relevant_points:
                relevant_points.append(point)
                
        return relevant_points[:count]
    
    def _format_bullet_point(self, point: str, platform: str) -> str:
        """格式化亚马逊风格的卖点"""
        # 首字母大写
        point = point.strip()
        if not point:
            return ""
            
        point = point[0].upper() + point[1:]
        
        # 添加句号
        if not point.endswith(('.', '!', '?')):
            point += '.'
            
        # 根据平台调整长度
        max_length = self.platform_rules.get(platform, {}).get('bullet_max_length', 500)
        if len(point) > max_length:
            point = point[:max_length-3] + "..."
            
        return point
    
    def mine_keywords(self, product_name: str, category: str, platform: str) -> List[str]:
        """挖掘相关关键词"""
        keywords = []
        
        # 从产品名提取
        keywords.extend(self._extract_keywords_from_text(product_name))
        
        # 从类别提取
        keywords.extend(self._extract_keywords_from_text(category))
        
        # 从数据库推荐
        if category in self.keyword_database:
            platform_keywords = self.keyword_database[category].get(platform, [])
            keywords.extend(platform_keywords[:10])
        
        # 生成变体关键词
        keyword_variants = self._generate_keyword_variants(keywords)
        keywords.extend(keyword_variants)
        
        # 去重和排序
        unique_keywords = list(set(keywords))
        sorted_keywords = self._rank_keywords(unique_keywords, product_name)
        
        return sorted_keywords[:20]
    
    def _extract_keywords_from_text(self, text: str) -> List[str]:
        """从文本中提取关键词"""
        # 移除停用词
        stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'in', 'on', 'at', 'for', 'with'}
        
        words = re.findall(r'\b\w+\b', text.lower())
        keywords = [word for word in words if word not in stop_words and len(word) > 2]
        
        # 提取复合关键词
        compound_patterns = [
            r'\b\w+\s+(?:wireless|bluetooth|waterproof|hd|4k)\b',
            r'\b(?:wireless|bluetooth|waterproof|hd|4k)\s+\w+\b'
        ]
        
        for pattern in compound_patterns:
            matches = re.findall(pattern, text.lower())
            keywords.extend(matches)
            
        return keywords
    
    def _generate_keyword_variants(self, keywords: List[str]) -> List[str]:
        """生成关键词变体"""
        variants = []
        
        for kw in keywords:
            # 单复数变体
            if kw.endswith('s'):
                variants.append(kw[:-1])
            else:
                variants.append(kw + 's')
                
            # 形容词变体
            if kw.endswith('e'):
                variants.append(kw + 'd')
                variants.append(kw + 'ing')
            elif kw.endswith('y'):
                variants.append(kw[:-1] + 'ier')
                variants.append(kw[:-1] + 'iest')
            else:
                variants.append(kw + 'ed')
                variants.append(kw + 'ing')
                variants.append(kw + 'er')
                variants.append(kw + 'est')
                
        return variants
    
    def _rank_keywords(self, keywords: List[str], product_name: str) -> List[str]:
        """根据相关性排序关键词"""
        product_words = set(re.findall(r'\b\w+\b', product_name.lower()))
        
        # 计算关键词得分
        keyword_scores = {}
        
        for kw in keywords:
            score = 0
            kw_words = set(re.findall(r'\b\w+\b', kw.lower()))
            
            # 与产品名匹配度
            common_words = product_words.intersection(kw_words)
            score += len(common_words) * 3
            
            # 关键词长度（越长越具体）
            score += len(kw.split()) * 2
            
            # 包含特殊术语
            if any(term in kw.lower() for term in ['pro', 'plus', 'max', 'mini', 'ultra']):
                score += 2
                
            keyword_scores[kw] = score
            
        # 按得分排序
        sorted_keywords = sorted(keywords, key=lambda x: keyword_scores.get(x, 0), reverse=True)
        
        return sorted_keywords
    
    def translate(self, text: str, target_lang: str) -> str:
        """多语种翻译"""
        if not self.translator:
            return text
            
        try:
            result = self.translator.translate(text, target_language=target_lang)
            return result['translatedText']
        except Exception as e:
            print(f"翻译失败: {e}")
            return text
    
    def localize(self, text: str, target_lang: str, platform: str) -> str:
        """本土化润色"""
        translated = self.translate(text, target_lang)
        
        # 根据平台进行本土化调整
        if platform == 'ozon' and target_lang == 'ru':
            return self._localize_for_russia(translated)
        elif platform == 'aliexpress' and target_lang == 'es':
            return self._localize_for_spain(translated)
        else:
            return translated
    
    def _localize_for_russia(self, text: str) -> str:
        """俄语本土化"""
        replacements = {
            'Bluetooth': 'Блютуз',
            'Wi-Fi': 'Вай-Фай',
            'USB': 'ЮСБ',
            'HD': 'Высокое разрешение',
            '4K': '4К разрешение',
            'waterproof': 'водонепроницаемый',
            'wireless': 'беспроводной',
            'charger': 'зарядное устройство',
            'battery': 'аккумулятор'
        }
        
        for eng, rus in replacements.items():
            text = re.sub(r'\b' + eng + r'\b', rus, text, flags=re.IGNORECASE)
            
        return text
    
    def _localize_for_spain(self, text: str) -> str:
        """西班牙语本土化"""
        replacements = {
            'Bluetooth': 'Bluetooth',
            'Wi-Fi': 'Wi-Fi',
            'USB': 'USB',
            'HD': 'Alta Definición',
            '4K': '4K',
            'waterproof': 'a prueba de agua',
            'wireless': 'inalámbrico',
            'charger': 'cargador',
            'battery': 'batería'
        }
        
        for eng, esp in replacements.items():
            text = re.sub(r'\b' + eng + r'\b', esp, text, flags=re.IGNORECASE)
            
        return text
    
    def check_forbidden_words(self, text: str, platform: str) -> Tuple[bool, List[str]]:
        """检测违禁词"""
        forbidden_words = self.forbidden_words.get(platform, [])
        found_forbidden = []
        
        text_lower = text.lower()
        
        for word in forbidden_words:
            if word.lower() in text_lower:
                found_forbidden.append(word)
                
        return len(found_forbidden) == 0, found_forbidden
    
    def optimize_keyword_list(self, keywords: List[str], platform: str) -> List[str]:
        """优化关键词列表"""
        # 去重
        unique_keywords = list(set(keywords))
        
        # 移除违禁词
        allowed_keywords = []
        for kw in unique_keywords:
            is_allowed, forbidden = self.check_forbidden_words(kw, platform)
            if is_allowed:
                allowed_keywords.append(kw)
        
        # 按长度排序（短关键词在前）
        sorted_keywords = sorted(allowed_keywords, key=lambda x: len(x.split()))
        
        return sorted_keywords

if __name__ == "__main__":
    # 示例用法
    seo_tools = SEOTools({})
    
    # 生成标题
    title = seo_tools.generate_title(
        "Wireless Bluetooth Earbuds", 
        "Electronics/Headphones", 
        "amazon",
        ["noise cancelling", "30-hour battery", "IPX7 waterproof"]
    )
    print(f"生成的标题: {title}")
    
    # 生成五点描述
    bullet_points = seo_tools.generate_bullet_points(
        "Premium wireless earbuds with active noise cancelling, 30-hour battery life, and comfortable fit.",
        "amazon",
        ["Active Noise Cancelling", "30-hour Battery Life", "IPX7 Waterproof", "Touch Controls"]
    )
    print("\n生成的五点描述:")
    for i, point in enumerate(bullet_points, 1):
        print(f"{i}. {point}")
    
    # 挖掘关键词
    keywords = seo_tools.mine_keywords(
        "Wireless Bluetooth Earbuds", 
        "Electronics/Headphones", 
        "amazon"
    )
    print(f"\n挖掘的关键词: {keywords[:10]}")