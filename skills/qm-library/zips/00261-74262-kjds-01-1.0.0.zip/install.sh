#!/bin/bash

# 跨境电商AI助手安装脚本

echo "🚀 开始安装跨境电商AI全能助手..."

# 检查Python版本
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 未找到，请先安装Python3"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d ' ' -f 2)
echo "✅ Python版本: $PYTHON_VERSION"

# 检查pip
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 未找到，请先安装pip"
    exit 1
fi
echo "✅ pip3 已安装"

# 创建虚拟环境
echo "📦 创建虚拟环境..."
python3 -m venv venv
source venv/bin/activate || source venv/Scripts/activate

echo "✅ 虚拟环境已创建并激活"

# 安装依赖包
echo "📥 安装Python依赖包..."
pip3 install requests beautifulsoup4 pillow openai python-dotenv boto3 mws python-multipart
echo "✅ Python依赖安装完成"

# 创建目录结构
echo "📁 创建目录结构..."
mkdir -p scripts templates data/examples data/keyword_database data/forbidden_words data/platform_rules

echo "✅ 目录结构创建完成"

# 复制示例文件
echo "📝 复制示例配置文件..."

# 示例商品数据
cat > examples/sample_product.json << 'EOF'
{
  "name": "Wireless Bluetooth Earbuds Noise Cancelling",
  "category": "Electronics/Headphones",
  "base_price": 49.99,
  "description": "Premium wireless earbuds with active noise cancelling, 30-hour battery life, and comfortable fit.",
  "features": ["Active Noise Cancelling", "30-hour Battery Life", "IPX7 Waterproof", "Touch Controls"],
  "keywords": ["bluetooth earbuds", "noise cancelling headphones", "wireless earphones"]
}
EOF

# 示例配置文件
cat > config.example.yaml << 'EOF'
# 跨境电商AI助手配置文件

# AI服务配置
ai_config:
  openai_api_key: "your_openai_api_key_here"
  midjourney_api_key: "your_midjourney_api_key_here"
  translate_api_key: "your_translate_api_key_here"

# 平台API配置
platform_configs:
  amazon:
    access_key: "your_amazon_access_key"
    secret_key: "your_amazon_secret_key"
    account_id: "your_amazon_account_id"
    region: "US"
  
  aliexpress:
    app_key: "your_aliexpress_app_key"
    app_secret: "your_aliexpress_app_secret"
    session_token: "your_aliexpress_session_token"
  
  ozon:
    client_id: "your_ozon_client_id"
    api_key: "your_ozon_api_key"

# 路径配置
template_dir: "templates/page_templates/"
font_dir: "templates/fonts/"
output_dir: "output/"

# 其他配置
default_platforms: ["amazon", "aliexpress", "ozon"]
max_keywords: 20
forbidden_word_check: true
EOF

# 复制示例关键词库
cat > data/keyword_database/keywords.json << 'EOF'
{
  "Electronics/Headphones": {
    "amazon": [
      "wireless earbuds", "noise cancelling headphones", "bluetooth earphones",
      "true wireless", "earbuds with mic", "sports headphones",
      "active noise cancelling", "ANC earbuds", "waterproof earphones"
    ],
    "aliexpress": [
      "bluetooth earbuds", "wireless headphones", "noise cancelling",
      "tws earbuds", "earphones", "sports earbuds",
      "headphones with mic", "gaming earphones", "hifi sound"
    ]
  }
}
EOF

echo "✅ 示例文件复制完成"

# 显示安装完成信息
echo ""
echo "🎉 跨境电商AI全能助手安装完成！"
echo ""
echo "📖 快速开始："
echo "1. 配置环境变量: source venv/bin/activate"
echo "2. 复制并修改配置文件: cp config.example.yaml config.yaml"
echo "3. 编辑config.yaml，填入API密钥等信息"
echo "4. 运行示例: python main.py --workflow --product examples/sample_product.json"
echo ""
echo "📁 目录结构:"
echo "├── scripts/          # 功能模块脚本"
echo "├── templates/        # 模板文件"
echo "├── data/            # 数据文件"
echo "│   ├── keyword_database/    # 关键词数据库"
echo "│   ├── forbidden_words/      # 违禁词库"
echo "│   └── platform_rules/       # 平台规则"
echo "├── examples/        # 示例文件"
echo "├── output/          # 输出目录"
echo "├── main.py          # 主程序"
echo "└── config.yaml      # 配置文件"
echo ""
echo "🔧 命令示例:"
echo "# 执行全链路上架流程"
echo "python main.py --workflow --product examples/sample_product.json --platforms amazon aliexpress ozon"
echo ""
echo "# 仅生成SEO内容"
echo "python main.py --step seo --product examples/sample_product.json"
echo ""
echo "# 仅生成视觉内容"
echo "python main.py --step visual --product examples/sample_product.json"
echo ""
echo "🤝 如有问题，请查看README.md或提交Issue"
