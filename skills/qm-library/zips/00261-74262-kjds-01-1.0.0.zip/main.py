#!/usr/bin/env python3
"""
跨境电商AI助手 - 主程序
支持文案SEO、图片生成、详情页制作、多平台自动铺货
"""

import os
import sys
import json
import time
import argparse
from datetime import datetime

# 导入功能模块
from scripts.seo_tools import SEOTools
from scripts.visual_generator import VisualGenerator
from scripts.page_builder import PageBuilder
from scripts.uploader import PlatformUploader

class CrossborderEcommerceAI:
    def __init__(self, config_file='config.yaml'):
        self.config = self.load_config(config_file)
        self.seo_tools = SEOTools(self.config)
        self.visual_generator = VisualGenerator(self.config)
        self.page_builder = PageBuilder(self.config)
        self.uploader = PlatformUploader(self.config)
        
    def load_config(self, config_file):
        """加载配置文件"""
        import yaml
        with open(config_file, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    
    def run_full_workflow(self, product_data, platforms=['amazon', 'aliexpress', 'ozon']):
        """执行全链路上架流程"""
        workflow_steps = [
            ("导入商品信息", self._step_import_product),
            ("生成标题关键词", self._step_generate_seo),
            ("生成主图视频", self._step_generate_visuals),
            ("生成详情页", self._step_build_page),
            ("自动上架", self._step_upload),
            ("回执结果", self._step_notify_result)
        ]
        
        result = {"product": product_data, "steps": [], "status": "success"}
        
        for step_name, step_func in workflow_steps:
            try:
                print(f"\n🚀 执行步骤: {step_name}")
                step_result = step_func(result, platforms)
                result["steps"].append({
                    "name": step_name,
                    "status": "success",
                    "result": step_result,
                    "timestamp": datetime.now().isoformat()
                })
            except Exception as e:
                print(f"❌ 步骤失败: {step_name} - {str(e)}")
                result["steps"].append({
                    "name": step_name,
                    "status": "failed",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                })
                result["status"] = "failed"
                break
        
        return result
    
    def _step_import_product(self, result, platforms):
        """导入商品信息"""
        product = result["product"]
        # 验证必填字段
        required_fields = ["name", "category", "base_price", "description"]
        missing = [f for f in required_fields if f not in product]
        if missing:
            raise ValueError(f"商品信息缺少必填字段: {', '.join(missing)}")
        
        print(f"✅ 成功导入商品: {product['name']}")
        return {"product_id": f"prod_{int(time.time())}", "imported_fields": list(product.keys())}
    
    def _step_generate_seo(self, result, platforms):
        """生成标题和关键词"""
        product = result["product"]
        seo_results = {}
        
        for platform in platforms:
            print(f"📝 为{platform}生成SEO内容...")
            
            # 生成标题
            title = self.seo_tools.generate_title(
                product["name"], 
                product["category"], 
                platform,
                product.get('keywords', [])
            )
            
            # 生成五点描述
            bullet_points = self.seo_tools.generate_bullet_points(
                product["description"], 
                platform,
                product.get('features', [])
            )
            
            # 挖掘关键词
            keywords = self.seo_tools.mine_keywords(
                product["name"], 
                product["category"], 
                platform
            )
            
            seo_results[platform] = {
                "title": title,
                "bullet_points": bullet_points,
                "keywords": keywords,
                "optimized": True
            }
        
        result["seo_data"] = seo_results
        return seo_results
    
    def _step_generate_visuals(self, result, platforms):
        """生成主图和视频"""
        product = result["product"]
        visual_results = {}
        
        print("🖼️  生成视觉内容...")
        
        # 生成主图
        main_image = self.visual_generator.generate_main_image(
            product["name"], 
            product["category"],
            product.get('style', 'professional')
        )
        
        # 生成场景图
        scene_image = self.visual_generator.generate_scene_image(
            product["name"], 
            product["category"],
            product.get('scene', 'home')
        )
        
        # 生成短视频
        video = self.visual_generator.generate_short_video(
            product["name"], 
            product["description"]
        )
        
        # 多平台尺寸适配
        platform_images = {}
        for platform in platforms:
            platform_images[platform] = self.visual_generator.adapt_to_platform(
                main_image, platform
            )
        
        visual_results = {
            "main_image": main_image,
            "scene_image": scene_image,
            "short_video": video,
            "platform_specific": platform_images
        }
        
        result["visual_data"] = visual_results
        return visual_results
    
    def _step_build_page(self, result, platforms):
        """生成详情页"""
        seo_data = result["seo_data"]
        visual_data = result["visual_data"]
        product = result["product"]
        
        page_results = {}
        
        for platform in platforms:
            print(f"📄 为{platform}生成详情页...")
            
            page_content = self.page_builder.build_detail_page(
                seo_data[platform]["title"],
                seo_data[platform]["bullet_points"],
                visual_data["platform_specific"][platform],
                product.get('parameters', {}),
                platform
            )
            
            page_results[platform] = {
                "page_content": page_content,
                "format": self.page_builder.get_platform_format(platform),
                "ready_to_upload": True
            }
        
        result["page_data"] = page_results
        return page_results
    
    def _step_upload(self, result, platforms):
        """自动上架到平台"""
        seo_data = result["seo_data"]
        visual_data = result["visual_data"]
        page_data = result["page_data"]
        product = result["product"]
        
        upload_results = {}
        
        for platform in platforms:
            print(f"📤 上传到{platform}...")
            
            upload_result = self.uploader.upload_product(
                platform,
                {
                    "title": seo_data[platform]["title"],
                    "description": page_data[platform]["page_content"],
                    "images": visual_data["platform_specific"][platform],
                    "video": visual_data["short_video"],
                    "price": product["base_price"],
                    "category": product["category"],
                    "keywords": seo_data[platform]["keywords"]
                }
            )
            
            upload_results[platform] = upload_result
        
        result["upload_data"] = upload_results
        return upload_results
    
    def _step_notify_result(self, result, platforms):
        """回执结果"""
        notification_content = {
            "product_name": result["product"]["name"],
            "total_steps": len(result["steps"]),
            "successful_steps": sum(1 for s in result["steps"] if s["status"] == "success"),
            "upload_status": result.get("upload_data", {}),
            "timestamp": datetime.now().isoformat()
        }
        
        # 发送通知（可扩展为邮件、消息等）
        print("\n📧 发送结果通知:")
        print(json.dumps(notification_content, indent=2, ensure_ascii=False))
        
        return notification_content

def main():
    parser = argparse.ArgumentParser(description="跨境电商AI全能助手")
    parser.add_argument("--product", help="商品数据文件路径")
    parser.add_argument("--platforms", nargs='+', default=['amazon', 'aliexpress', 'ozon'],
                       help="目标平台 (amazon, aliexpress, ozon)")
    parser.add_argument("--workflow", action='store_true', help="执行全流程")
    parser.add_argument("--step", help="执行单个步骤")
    
    args = parser.parse_args()
    
    # 初始化AI助手
    ai_assistant = CrossborderEcommerceAI()
    
    # 加载商品数据
    if args.product:
        with open(args.product, 'r', encoding='utf-8') as f:
            product_data = json.load(f)
    else:
        # 使用示例数据
        product_data = {
            "name": "Wireless Bluetooth Earbuds Noise Cancelling",
            "category": "Electronics/Headphones",
            "base_price": 49.99,
            "description": "Premium wireless earbuds with active noise cancelling, 30-hour battery life, and comfortable fit.",
            "features": ["Active Noise Cancelling", "30-hour Battery Life", "IPX7 Waterproof", "Touch Controls"],
            "keywords": ["bluetooth earbuds", "noise cancelling headphones", "wireless earphones"]
        }
    
    if args.workflow:
        # 执行全流程
        print("🎯 开始跨境电商全链路上架流程")
        result = ai_assistant.run_full_workflow(product_data, args.platforms)
        
        # 保存结果
        output_file = f"workflow_result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        print(f"\n📋 流程完成，结果已保存到: {output_file}")
        
        if result["status"] == "success":
            print("🎉 全流程执行成功!")
            sys.exit(0)
        else:
            print("❌ 流程执行失败!")
            sys.exit(1)
    
    elif args.step:
        # 执行单个步骤
        print(f"⚡ 执行单个步骤: {args.step}")
        # 这里可以添加单步执行逻辑
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()