---
name: crossborder-ecommerce-ai-assistant
version: 1.0.0
description: 跨境电商全能AI助手 - 集成文案SEO、图片视频生成、详情页制作、多平台自动铺货全链路功能
author: OpenClaw AI
website: https://openclaw.ai
skills:
  - crossborder-copilot-seo
  - crossborder-copilot-visual
  - crossborder-copilot-pagebuilder
  - crossborder-copilot-uploader
dependencies:
  - python: requests
  - python: beautifulsoup4
  - python: pillow
  - python: openai
  - python: google-cloud-translate
  - nodejs: alibaba-openapi-sdk
  - nodejs: amazon-mws-sdk
  - nodejs: ozon-api-client
---

# 跨境电商全能AI助手

## 🚀 核心功能

### 一、文案SEO技能
- **多平台标题智能生成**：亚马逊、速卖通、Ozon等平台专属标题生成
- **标题优化**：合规化+权重埋词+流量词布局
- **描述自动生成**：五点描述/副标题/产品卖点自动撰写
- **关键词工具**：词根拆分/流量词挖掘/关键词库导出
- **本土化润色**：英/俄/西/法等多语种专业翻译
- **风险检测**：违禁词/极限词自动排查防下架

### 二、视觉内容生成
- **AI图片生成**：主图/场景图/细节图一键生成
- **智能合成**：产品场景自动合成/背景替换
- **详情页排版**：模块化图文自动组合长图
- **短视频制作**：产品演示/开箱/种草视频自动生成
- **图片处理**：自动去重/MD5修改/尺寸适配
- **多平台适配**：亚马逊A+/速卖通/Ozon格式自动转换

### 三、详情页自动化
- **架构设计**：标准化详情页文案架构（痛点→卖点→参数→场景）
- **参数生成**：产品参数表自动提取与格式化
- **模块化合成**：图文模块自由组合
- **格式转换**：一键导出各平台专用格式

### 四、多平台自动铺货
- **自动上架**：亚马逊/速卖通/Ozon全字段自动填充
- **一键分发**：多店铺多平台同步发布
- **SKU管理**：变体自动生成/批量编辑
- **店铺管理**：上下架/库存/价格批量操作
- **智能重试**：失败任务自动重试/日志记录

## 📦 部署指南

### 最简启动顺序
1. ✅ **基础工具**：违禁词检测 + 关键词挖掘
2. ✅ **文案创作**：标题优化 + 描述生成 + 语种润色
3. ✅ **视觉内容**：主图生成 + 详情页制作 + 短视频
4. ✅ **自动铺货**：亚马逊/速卖通/Ozon自动上架

### 快速启动配置
```plaintext
[任务类型] 跨境电商全链路上架
[平台] 亚马逊,速卖通,Ozon
[技能启用]
文案类：标题优化、副标题/五点生成、关键词挖掘、语种润色、违禁词检测
视觉类：主图生成、场景图、详情页长图、短视频生成、图片去重
上架类：亚马逊自动上架、速卖通自动铺货、Ozon自动上架、多平台分发、SKU变体生成
[执行流程]
1.导入商品信息→2.生成标题关键词→3.生成主图视频→4.生成详情页→5.自动上架→6.回执结果
```

## 🔧 技术规格

### 支持平台
- 亚马逊（Amazon.com, Amazon.co.uk, Amazon.de等全站点）
- 速卖通（AliExpress）
- Ozon（俄罗斯/欧洲站点）
- Wish、Shopify（扩展支持）

### 支持语种
- 英语、俄语、西班牙语、法语、德语、意大利语、日语、韩语

### AI模型集成
- OpenAI GPT-4o（文案生成）
- MidJourney/DALL-E 3（图片生成）
- Runway ML（视频生成）
- Google Translate API（专业翻译）

## 📁 文件结构

```
crossborder-ecommerce-ai-assistant/
├── SKILL.md                  # 技能说明文档
├── config.yaml               # 配置文件
├── scripts/
│   ├── seo_tools.py          # 文案SEO工具
│   ├── visual_generator.py   # 视觉内容生成
│   ├── page_builder.py       # 详情页制作
│   └── uploader.py           # 自动铺货功能
├── templates/
│   ├── title_templates/      # 多平台标题模板
│   ├── description_templates/# 描述模板
│   └── page_templates/       # 详情页模板
├── data/
│   ├── keyword_database/     # 关键词数据库
│   ├── forbidden_words/      # 违禁词库
│   └── platform_rules/       # 平台规则库
└── examples/
    ├── sample_product.csv    # 示例商品数据
    └── workflow_example.yml  # 示例工作流
```

## 🎯 使用场景

### 适合人群
- 跨境电商商家/运营人员
- 专业美工设计师
- 代运营公司/团队
- 个人卖家/中小卖家

### 解决痛点
- 节省文案创作时间90%
- 降低视觉设计成本80%
- 提升上架效率10倍
- 统一多平台内容风格
- 减少违规下架风险

## 📞 技术支持

- 官方文档：https://docs.openclaw.ai/crossborder
- 社区论坛：https://discord.gg/clawd
- 问题反馈：https://github.com/openclaw/openclaw/issues
- 商务合作：contact@openclaw.ai

---

*本技能基于OpenClaw AgentSkills平台开发，兼容龙虾（Lobster）工作流引擎*