# 跨境电商AI全能助手

一个集成文案SEO、视觉内容生成、详情页制作、多平台自动铺货的全链路跨境电商AI助手。

## 🚀 核心功能

### 一、文案SEO技能
- **多平台标题智能生成**：亚马逊、速卖通、Ozon等平台专属标题生成
- **标题优化**：合规化+权重埋词+流量词布局
- **描述自动生成**：五点描述/副标题/产品卖点自动撰写
- **关键词工具**：词根拆分/流量词挖掘/关键词库导出
- **本土化润色**：英/俄/西/法等多语种专业翻译
- **风险检测**：违禁词/极限词自动排查防下架

### 二、视觉内容生成
- **AI图片生成**：主图/场景图/细节图一键生成
- **智能合成**：产品场景自动合成/背景替换
- **详情页排版**：模块化图文自动组合长图
- **短视频制作**：产品演示/开箱/种草视频自动生成
- **图片处理**：自动去重/MD5修改/尺寸适配
- **多平台适配**：亚马逊A+/速卖通/Ozon格式自动转换

### 三、详情页自动化
- **架构设计**：标准化详情页文案架构（痛点→卖点→参数→场景）
- **参数生成**：产品参数表自动提取与格式化
- **模块化合成**：图文模块自由组合
- **格式转换**：一键导出各平台专用格式

### 四、多平台自动铺货
- **自动上架**：亚马逊/速卖通/Ozon全字段自动填充
- **一键分发**：多店铺多平台同步发布
- **SKU管理**：变体自动生成/批量编辑
- **店铺管理**：上下架/库存/价格批量操作
- **智能重试**：失败任务自动重试/日志记录

## 📦 快速开始

### 安装方式

#### 方式1：使用安装脚本（推荐）
```bash
bash install.sh
```

#### 方式2：手动安装
```bash
# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate

# 安装依赖
pip3 install requests beautifulsoup4 pillow openai python-dotenv

# 创建目录
mkdir -p scripts templates data/examples output
```

### 配置

1. 复制并编辑配置文件：
```bash
cp config.example.yaml config.yaml
```

2. 编辑`config.yaml`，填入API密钥和平台配置：
```yaml
ai_config:
  openai_api_key: "your_openai_api_key_here"

platform_configs:
  amazon:
    access_key: "your_amazon_access_key"
    secret_key: "your_amazon_secret_key"
```

### 运行示例

```bash
# 执行全链路上架流程
python main.py --workflow --product examples/sample_product.json --platforms amazon aliexpress ozon

# 仅生成SEO内容
python main.py --step seo --product examples/sample_product.json

# 仅生成视觉内容
python main.py --step visual --product examples/sample_product.json

# 仅执行自动上架
python main.py --step upload --product examples/sample_product.json
```

## 🛠️ 技术栈

### 核心技术
- **Python 3.8+**：主要开发语言
- **OpenAI GPT-4o**：文案生成和优化
- **DALL-E 3/MidJourney**：图片生成
- **Pillow**：图片处理
- **Requests**：HTTP请求
- **BeautifulSoup4**：HTML解析

### 平台集成
- **亚马逊MWS API**：自动上架和店铺管理
- **速卖通开放平台API**：自动铺货
- **Ozon Seller API**：俄罗斯平台集成
- **Shopify API**：独立站支持

## 🎯 使用场景

### 适合人群
- 跨境电商商家/运营人员
- 专业美工设计师
- 代运营公司/团队
- 个人卖家/中小卖家

### 解决痛点
- 节省文案创作时间90%
- 降低视觉设计成本80%
- 提升上架效率10倍
- 统一多平台内容风格
- 减少违规下架风险

## 🔧 命令行参数

```bash
usage: main.py [-h] [--product PRODUCT] [--platforms PLATFORMS [PLATFORMS ...]] [--workflow] [--step STEP]

跨境电商AI全能助手

optional arguments:
  -h, --help            show this help message and exit
  --product PRODUCT     商品数据文件路径
  --platforms PLATFORMS [PLATFORMS ...]
                        目标平台 (amazon, aliexpress, ozon)
  --workflow            执行全流程
  --step STEP           执行单个步骤 (seo, visual, page, upload)
```

## 📁 项目结构

```
crossborder-ecommerce-ai-assistant/
├── main.py                 # 主程序入口
├── install.sh              # 安装脚本
├── config.example.yaml     # 示例配置文件
├── config.yaml             # 配置文件（需创建）
├── scripts/
│   ├── seo_tools.py        # 文案SEO工具
│   ├── visual_generator.py # 视觉内容生成
│   ├── page_builder.py     # 详情页制作
│   └── uploader.py         # 自动铺货功能
├── templates/
│   ├── title_templates/    # 多平台标题模板
│   ├── description_templates/# 描述模板
│   └── page_templates/     # 详情页模板
├── data/
│   ├── keyword_database/   # 关键词数据库
│   ├── forbidden_words/    # 违禁词库
│   └── platform_rules/     # 平台规则库
├── examples/
│   ├── sample_product.csv  # 示例商品数据
│   └── workflow_example.yml  # 示例工作流
└── output/                 # 输出目录
```

## 📊 工作流程

### 标准工作流
1. **导入商品信息** → 读取商品基本数据
2. **生成标题关键词** → SEO优化和关键词挖掘
3. **生成主图视频** → AI视觉内容生成
4. **生成详情页** → 模块化详情页制作
5. **自动上架** → 多平台一键分发
6. **回执结果** → 任务状态和链接返回

### 可扩展性
- **自定义模板**：支持添加平台专属模板
- **API扩展**：轻松集成新的电商平台
- **插件系统**：可扩展功能模块

## 🤝 贡献指南

欢迎提交Issue和Pull Request！

### 开发环境
```bash
# 安装开发依赖
pip3 install pytest flake8 black

# 运行测试
pytest tests/

# 代码格式化
black .

# 代码检查
flake8 .
```

### 贡献规范
1. Fork本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开Pull Request

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 📞 联系方式

- 项目主页: [https://github.com/your-repo/crossborder-ecommerce-ai-assistant](https://github.com/your-repo/crossborder-ecommerce-ai-assistant)
- 问题反馈: [https://github.com/your-repo/crossborder-ecommerce-ai-assistant/issues](https://github.com/your-repo/crossborder-ecommerce-ai-assistant/issues)
- 商务合作: contact@example.com

---

⭐ 如果这个项目对你有帮助，请给个Star支持一下！