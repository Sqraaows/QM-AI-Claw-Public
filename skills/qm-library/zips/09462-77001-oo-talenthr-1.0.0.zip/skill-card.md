## Description: <br>
TalentHR lets agents operate a TalentHR account through the OOMOL oo CLI, including inspecting connector schemas and running the change_employee_role action. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees and HR operators use this skill to act on TalentHR data through an OOMOL-connected TalentHR account. It is especially relevant when an agent needs to inspect the live TalentHR connector schema and update an employee role to Employee or HR-Manager after explicit confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill exposes a sensitive TalentHR role-changing action while the main description frames the skill as useful for searching and reading data. <br>
Mitigation: Install only when TalentHR administrative changes are expected, require explicit confirmation before every role change, and inspect the live schema before sending payloads. <br>
Risk: Role updates can affect employee permissions in TalentHR. <br>
Mitigation: Use a TalentHR account with permissions limited to the intended HR tasks and verify the exact target employee and role before execution. <br>
Risk: First-time setup suggests shell installation commands for the oo CLI. <br>
Mitigation: Prefer a verified oo CLI installation path and review installer sources before running remote shell commands. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-talenthr) <br>
- [TalentHR Homepage](https://www.talenthr.io/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, Guidance, API Calls] <br>
**Output Format:** [Markdown with inline bash commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses from the oo CLI, including data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
