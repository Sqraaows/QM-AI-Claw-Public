# HeartFlow 实际能力审计（2026-05-20）

## 真相：SKILL.md 有能力膨胀

SKILL.md 描述的 16 项能力，约一半无法通过统一 API 调用。

---

## heartflow.js 统一入口（实际可调用）

| 方法 | 功能 | 源码 |
|---|---|---|
| `analyzePsychology(text)` | 4层心理感知 | `psychology/engine.js` |
| `verifyReasoning(r, c)` | 4步推理验证 | `identity/self-verifier.js` |
| `checkTruthfulness(s)` | hedging/abs检测 | `security/truthfulness.js` |
| `heal(error)` | Q-learning自愈 | `evolution/loop.js` |
| `checkLessonPattern(i)` | 教训匹配 | `identity/lesson-bank.js` |
| `dreamNow()` | 梦境整合 | `dream/engine.js` |
| `detectIdentityDrift()` | 身份漂移检测 | `identity/self-model.js` |
| `processEmotionally(i)` | 情感协议 | `security/emotional-protocol.js` |
| `getTopLessons(n)` | 教训提取 | `identity/lesson-bank.js` |

**共9个公开方法**，来自13个真实子系统。

---

## SKILL.md 描述但实际未集成的

| 描述 | 真相 |
|---|---|
| CausalReasoning | `dist/core/reasoning/` 源码存在，未接入 heartflow.js |
| 真善美系统 | `archive/true-being-engine.js.bak`，从未接入 |
| 六层哲学 | 同上 |
| 五层记忆 L1-L5 | `associative-engine/` 独立引擎，完全未连接 |
| StabilityGuard | heartflow-engine.js 加载了，heartflow.js 未加载 |
| ExecutionVerifier | 同上 |
| LanguageHonesty | `src/core/` 有源码，未被 require |

---

## 两套并行入口

```
heartflow-engine.js  ← CLI test 入口，加载 19 个模块
heartflow.js         ← 统一 API 出口，13 个子系统
        ↑
   互不连接，共享极少
```

---

## 教训

**写 SKILL.md 前必须先确认：**
1. 模块是否被 `require` 进主入口？
2. 是否有公开方法暴露给调用方？
3. 描述的能力和实际 API 是否匹配？

禁止在 SKILL.md 里写"源码存在但未集成"的模块作为 capability。
