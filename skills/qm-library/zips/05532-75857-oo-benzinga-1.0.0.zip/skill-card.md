## Description: <br>
Use this skill for Benzinga requests to search and read market data through an OOMOL-connected account instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and agents use this skill to retrieve Benzinga market data through OOMOL-managed connector actions, including consensus ratings, analyst rating events, earnings events, and news channels. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on an OOMOL-brokered Benzinga connection and may require sensitive account credentials to be configured outside the agent. <br>
Mitigation: Install only when the user trusts OOMOL to broker the Benzinga connection, and review the connected account and scopes before use. <br>
Risk: Installer commands for the oo CLI can execute remote installation scripts. <br>
Mitigation: Review the installer source or use an approved installation path before running the documented install commands. <br>
Risk: Benzinga connector schemas and defaults can change upstream, which may make stale payloads invalid or misleading. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-benzinga) <br>
- [Benzinga homepage](https://www.benzinga.com/) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action execution and returns connector responses as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
