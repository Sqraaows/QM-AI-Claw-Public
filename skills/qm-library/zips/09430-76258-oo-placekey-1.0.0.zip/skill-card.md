## Description: <br>
Placekey guides agents to resolve addresses and location records through the OOMOL Placekey connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and data analysts use this skill to resolve postal addresses and location records into Placekey identifiers or matched geocode responses through an OOMOL-connected Placekey account, including single and bulk lookup workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on a user-run oo CLI installer before actions can be executed. <br>
Mitigation: Review the installer source or install through a trusted package path before enabling the workflow. <br>
Risk: Placekey workflows may transmit sensitive address or location datasets to the connected Placekey/OOMOL account. <br>
Mitigation: Use the skill only with datasets the user is comfortable sending to that connected account, and confirm authorization before processing sensitive or bulk location data. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Placekey skill page](https://clawhub.ai/oomol/oo-placekey) <br>
- [Placekey homepage](https://www.placekey.io) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, json] <br>
**Output Format:** [Markdown guidance with bash command examples and JSON payload or response conventions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action runs return connector JSON containing data and meta.executionId when executed through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
