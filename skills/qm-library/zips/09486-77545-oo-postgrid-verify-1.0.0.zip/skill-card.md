## Description: <br>
PostGrid Verify helps agents inspect schemas and run OOMOL oo connector actions for US and Canadian address autocomplete, postal lookup, parsing, and verification. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to validate, standardize, parse, autocomplete, or look up US and Canadian address data through a connected PostGrid Verify account. <br>

### Deployment Geography for Use: <br>
Global; address workflows are documented for the United States and Canada. <br>

## Known Risks and Mitigations: <br>
Risk: Address data is sent through the OOMOL PostGrid Verify connector and may require a connected PostGrid API key. <br>
Mitigation: Install and run the skill only when the user intends to use that connector, and send only address data needed for the task. <br>
Risk: Connector fields and defaults can change upstream, which could make a stale payload incorrect. <br>
Mitigation: Inspect the live action schema with oo connector schema before constructing or running action payloads. <br>
Risk: Authentication, missing connection scopes, expired credentials, or billing limits can block execution. <br>
Mitigation: Use the documented first-time setup and billing recovery steps only after a command fails for the matching reason. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-postgrid-verify) <br>
- [PostGrid Verify Homepage](https://www.postgrid.com/address-verification/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, OOMOL sign-in, and a connected PostGrid Verify account; live schemas should be inspected before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
