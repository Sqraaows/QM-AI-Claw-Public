## Description: <br>
Plausible Analytics lets agents query Plausible site analytics and record pageviews or custom events through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and marketing teams use this skill to retrieve Plausible Analytics reports, inspect live connector schemas, and record approved analytics events from an OOMOL-connected Plausible account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The record_event action can add pageview or custom-event data and affect analytics reporting. <br>
Mitigation: Confirm the exact site and event payload with the user before running record_event. <br>
Risk: The skill operates through an OOMOL-connected Plausible account. <br>
Mitigation: Install it only when agent access to that Plausible account is intended, and keep credentials handled through the OOMOL connection rather than exposing raw tokens. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-plausible-analytics) <br>
- [Plausible Analytics Homepage](https://plausible.io) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an OOMOL-connected Plausible Analytics account and fetches the live connector schema before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence.release.version and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
