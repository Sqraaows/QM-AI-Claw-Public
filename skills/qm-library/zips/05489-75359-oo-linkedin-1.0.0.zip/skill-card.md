## Description: <br>
LinkedIn (linkedin.com). Use this skill for LinkedIn requests that read, create, reshare, or delete content through an OOMOL-connected LinkedIn account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate LinkedIn through an OOMOL-connected account, including retrieving the authenticated member profile, publishing text or article posts, creating reshares, and deleting posts after approval. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can post, reshare, or delete LinkedIn content through the connected account. <br>
Mitigation: Confirm the exact payload, target, and intended effect with the user before any write action, and require explicit approval before deleting posts. <br>
Risk: The skill depends on an OOMOL-connected LinkedIn account and the oo CLI, including a curl-to-shell installer path for setup. <br>
Mitigation: Install only when the user wants this account access enabled, and review the oo CLI installer before running setup commands. <br>
Risk: Connector schemas and upstream LinkedIn fields can change. <br>
Mitigation: Fetch the live connector schema before building every payload and validate the JSON against that schema before execution. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-linkedin) <br>
- [LinkedIn homepage](https://www.linkedin.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL LinkedIn connection page](https://console.oomol.com/app-connections?provider=linkedin) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands should inspect the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
