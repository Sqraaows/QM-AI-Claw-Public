## Description: <br>
Countdown API lets agents search eBay products, retrieve product details, fetch autocomplete suggestions, and check account usage through an OOMOL-connected Countdown API account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to run read-oriented Countdown API workflows for eBay product discovery, product detail lookup, autocomplete suggestions, and account usage checks through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Countdown API account and sensitive credentials handled through OOMOL. <br>
Mitigation: Install only if you trust OOMOL and keep the API key scoped appropriately. <br>
Risk: Product searches and account checks can affect billing, quotas, or credits. <br>
Mitigation: Monitor Countdown API usage and quota, and pause retries when billing or quota errors occur. <br>
Risk: Action schemas and upstream defaults can change. <br>
Mitigation: Fetch the live oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [Countdown API homepage](https://countdownapi.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Countdown API ClawHub listing](https://clawhub.ai/oomol/oo-countdown-api) <br>
- [autocomplete action](actions/autocomplete.md) <br>
- [get_account action](actions/get_account.md) <br>
- [get_product action](actions/get_product.md) <br>
- [search_products action](actions/search_products.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads; API responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
