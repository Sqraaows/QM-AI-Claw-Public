## Description: <br>
Slite (slite.com). Use this skill for ANY Slite request - reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to operate Slite through an OOMOL-connected account, including reading, searching, creating, updating, and deleting notes and groups. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill handles sensitive credentials through OOMOL and the oo CLI. <br>
Mitigation: Use scoped or revocable credentials where possible, prefer secret storage or environment variables, and avoid pasting live tokens into chat. <br>
Risk: Create and update actions change Slite workspace state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: Delete actions can remove Slite notes and children. <br>
Mitigation: Confirm the target and obtain explicit user approval before running destructive actions. <br>


## Reference(s): <br>
- [ClawHub Slite skill](https://clawhub.ai/oomol/oo-slite) <br>
- [Slite homepage](https://slite.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read actions can return Slite note content as Markdown, HTML, or SliteML where supported by the connector.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
