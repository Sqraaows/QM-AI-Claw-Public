## Description: <br>
HotspotSystem (hotspotsystem.com) lets an agent search and read HotspotSystem data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to verify the connected HotspotSystem operator account and list locations, customers, and subscribers through the OOMOL `oo` CLI. It is intended for read-only HotspotSystem workflows backed by a connected API key. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses sensitive HotspotSystem credentials through an OOMOL-connected API key. <br>
Mitigation: Install only if you trust OOMOL and intend to let the agent read HotspotSystem data through the connected account. <br>
Risk: Returned customer and subscriber records can contain sensitive operational or personal data. <br>
Mitigation: Treat returned HotspotSystem customer, subscriber, and location data as sensitive and share it only with authorized users. <br>
Risk: First-time setup may require running the OOMOL CLI installer. <br>
Mitigation: Review the OOMOL CLI installer before running one-time setup commands. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-hotspotsystem) <br>
- [HotspotSystem homepage](https://www.hotspotsystem.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
