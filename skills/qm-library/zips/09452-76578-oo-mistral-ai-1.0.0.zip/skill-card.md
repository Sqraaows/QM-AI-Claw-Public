## Description: <br>
Mistral AI (mistral.ai). Use this skill for ANY Mistral AI request - reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect live Mistral AI connector schemas and run Mistral AI actions through an OOMOL-connected account, including chat completions, agents, files, libraries, OCR, embeddings, moderation, and model listing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and change Mistral AI account data through OOMOL-connected connector actions. <br>
Mitigation: Use it only with an intended Mistral AI connection and review action names, schemas, and payloads before execution. <br>
Risk: Upload, sharing, update, send, and delete actions may alter account state or remove data. <br>
Mitigation: Confirm the exact payload, target resource, and intended effect with the user before state-changing actions, and require explicit approval before destructive actions. <br>
Risk: Signed URLs, fileTransit download links, conversation history, and extracted document text may expose sensitive data. <br>
Mitigation: Share returned links and retrieved content only with intended recipients and avoid storing or reposting sensitive outputs unnecessarily. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-mistral-ai) <br>
- [Mistral AI homepage](https://mistral.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to fetch the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
