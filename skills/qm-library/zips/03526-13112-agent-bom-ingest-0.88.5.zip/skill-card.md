## Description: <br>
Validate and ingest operator-pushed agent-bom inventory JSON from AWS, Azure, GCP, Snowflake, CMDB, or endpoint collectors for local findings, graph, policy, provenance, and auditor-ready exports without giving agent-bom direct cloud credentials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
Apache-2.0 <br>


## Use Case: <br>
Developers, security engineers, and auditors use this skill when they already have canonical agent-bom inventory JSON and need local validation, scanning, graph analysis, policy review, provenance checks, or review-ready exports. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Inventory files and generated exports can contain sensitive asset, package, permissions, provenance, and security intelligence data. <br>
Mitigation: Validate inventory against the packaged schema, keep analysis local by default, and review exports before sharing them. <br>
Risk: Optional control-plane push can disclose inventory data or credentials if pointed at an untrusted destination. <br>
Mitigation: Only set AGENT_BOM_PUSH_URL to an operator-trusted control plane and keep AGENT_BOM_API_KEY in environment variables rather than chat or logs. <br>
Risk: Malformed inventory or missing discovery provenance can lead to unsupported trust claims. <br>
Mitigation: Require discovery_provenance and permissions_used for cloud or operator-pushed discovery, and stop rather than scanning a best-effort summary when trust fields are missing. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/msaad00/agent-bom-ingest) <br>
- [agent-bom project homepage](https://github.com/msaad00/agent-bom) <br>
- [agent-bom PyPI package](https://pypi.org/project/agent-bom/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command blocks and references to JSON, SARIF, HTML, Markdown, CycloneDX, and SPDX export options] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires Python 3.11+ and agent-bom 0.84.4+. Reads operator-selected inventory JSON and writes only to operator-selected export paths.] <br>

## Skill Version(s): <br>
0.88.5 (source: server release metadata and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
