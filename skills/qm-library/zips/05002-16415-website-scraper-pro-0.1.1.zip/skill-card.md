## Description: <br>
Website Scraper Pro scrapes a single web page into clean markdown or deterministic JSON with optional JavaScript rendering and query-focused narrowing. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[youpele52](https://clawhub.ai/user/youpele52) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to retrieve content from a specified public URL as markdown or structured JSON. It is suited for direct single-page scraping, JavaScript-rendered pages, and deterministic narrowing by query text. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Fetching user-supplied pages can expose request metadata to the destination site. <br>
Mitigation: Use the skill only for URLs the user is authorized to access, and avoid private, authenticated, internal, or sensitive pages unless that exposure is intended. <br>
Risk: Browser-backed scraping may require local Crawl4AI or Playwright setup before the skill can run. <br>
Mitigation: Follow the documented one-time setup commands when browser setup is missing, and run the skill in an environment where installing those dependencies is acceptable. <br>


## Reference(s): <br>
- [Website Scraper Pro on ClawHub](https://clawhub.ai/youpele52/website-scraper-pro) <br>
- [Crawl4AI project homepage](https://github.com/unclecode/crawl4ai) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, JSON, guidance] <br>
**Output Format:** [Markdown by default, or deterministic JSON with title, URL, markdown, links, metadata, JavaScript mode, query, and markdown source fields.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Single-page output only; query mode uses deterministic filtering and the skill does not perform AI summarization.] <br>

## Skill Version(s): <br>
0.1.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
