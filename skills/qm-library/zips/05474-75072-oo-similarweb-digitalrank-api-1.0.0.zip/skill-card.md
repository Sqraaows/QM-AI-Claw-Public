## Description: <br>
Similarweb helps agents retrieve Similarweb Digital Rank data through an OOMOL-connected account, including top sites, rank-tracker configuration, and subscription status. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Marketing, analytics, and growth users with an OOMOL-connected Similarweb account use this skill to query Similarweb ranking data, inspect rank-tracker campaign configuration, and check remaining API allowance. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Setup may require installing the oo CLI and connecting a Similarweb account through OOMOL. <br>
Mitigation: Review the oo CLI installer before running curl or PowerShell setup commands, and install only when you intend to use an OOMOL-connected Similarweb account. <br>
Risk: Read actions may consume Similarweb or OOMOL quota. <br>
Mitigation: Check the subscription status and expected query scope before repeated or broad requests. <br>
Risk: Connector fields and defaults can change upstream. <br>
Mitigation: Fetch the live connector schema before building action payloads and match requests to that schema. <br>


## Reference(s): <br>
- [ClawHub Similarweb skill](https://clawhub.ai/oomol/oo-similarweb-digitalrank-api) <br>
- [Similarweb homepage](https://www.similarweb.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON API responses.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON data with execution metadata; outputs depend on the live Similarweb connector schema and the connected account.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
