## Description: <br>
OpenPageRank helps agents look up page rank scores and normalized rank metadata for one or more domains through the OOMOL OpenPageRank connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and marketing teams use this skill to retrieve OpenPageRank scores for domains and incorporate the returned rank metadata into SEO, marketing, and data analytics workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected OpenPageRank account. <br>
Mitigation: Install only when comfortable using OOMOL's oo CLI and connect OpenPageRank credentials through OOMOL; do not handle raw tokens in agent prompts. <br>
Risk: First-time setup may require installing the oo CLI and signing in to OOMOL. <br>
Mitigation: Run setup steps only after an auth, connection, or missing-CLI failure, and review CLI installation commands before execution. <br>
Risk: Connector schemas can change upstream, causing incorrect payloads or assumptions about returned fields. <br>
Mitigation: Fetch the live OpenPageRank action schema with `oo connector schema` before constructing each action payload. <br>


## Reference(s): <br>
- [OpenPageRank homepage](https://openpagerank.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-openpagerank) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the OOMOL oo CLI, an OOMOL sign-in, and a connected OpenPageRank API key or account. The documented action is read-only.] <br>

## Skill Version(s): <br>
1.0.0 (source: server-resolved release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
