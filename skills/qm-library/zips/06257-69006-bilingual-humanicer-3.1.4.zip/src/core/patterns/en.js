'use strict';

/**
 * en.js — All 29 English pattern definitions.
 */

const {
  findMatches,
  countMatches,
  wordCount,
  wordRegex,
  scanWordList,
  scanPhrases,
} = require('./helpers');
const { AI_PHRASES } = require('../../vocabulary');
const { getLocale } = require('../../locales');

// ─── Significance / Promotional Phrase Lists ─────────────
// (Kept here for patterns that need inline regex arrays)

const SIGNIFICANCE_PHRASES = [
  /marking a pivotal/gi,
  /pivotal moment/gi,
  /pivotal role/gi,
  /key role/gi,
  /crucial role/gi,
  /vital role/gi,
  /significant role/gi,
  /is a testament/gi,
  /stands as a testament/gi,
  /serves as a testament/gi,
  /serves as a reminder/gi,
  /reflects broader/gi,
  /broader trends/gi,
  /broader movement/gi,
  /evolving landscape/gi,
  /evolving world/gi,
  /setting the stage for/gi,
  /marking a shift/gi,
  /key turning point/gi,
  /indelible mark/gi,
  /deeply rooted/gi,
  /focal point/gi,
  /symbolizing its ongoing/gi,
  /enduring legacy/gi,
  /lasting impact/gi,
  /contributing to the/gi,
  /underscores the importance/gi,
  /highlights the significance/gi,
  /represents a shift/gi,
  /shaping the future/gi,
  /the evolution of/gi,
  /rich tapestry/gi,
  /rich heritage/gi,
  /stands as a beacon/gi,
  /marks a milestone/gi,
  /paving the way/gi,
  /charting a course/gi,
];

const PROMOTIONAL_WORDS = [
  /\bnestled\b/gi,
  /\bin the heart of\b/gi,
  /\bbreathtaking\b/gi,
  /\bmust-visit\b/gi,
  /\bstunning\b/gi,
  /\brenowned\b/gi,
  /\bnatural beauty\b/gi,
  /\brich cultural heritage\b/gi,
  /\brich history\b/gi,
  /\bcommitment to\b/gi,
  /\bexemplifies\b/gi,
  /\bworld-class\b/gi,
  /\bstate-of-the-art\b/gi,
  /\bgame-changing\b/gi,
  /\bgame changer\b/gi,
  /\bunparalleled\b/gi,
  /\bprofound\b/gi,
  /\bbest-in-class\b/gi,
  /\btrailblazing\b/gi,
  /\bvisionary\b/gi,
  /\bcutting-edge\b/gi,
  /\bworldwide recognition\b/gi,
];

const VAGUE_ATTRIBUTION_PHRASES = [
  /\bexperts (believe|argue|say|suggest|note|agree|contend|have noted)\b/gi,
  /\bindustry (reports|observers|experts|analysts|leaders|insiders)\b/gi,
  /\bobservers have (cited|noted|pointed out)\b/gi,
  /\bsome critics argue\b/gi,
  /\bsome experts (say|believe|suggest)\b/gi,
  /\bseveral sources\b/gi,
  /\baccording to reports\b/gi,
  /\bwidely (regarded|considered|recognized|acknowledged)\b/gi,
  /\bit is widely (known|believed|accepted)\b/gi,
  /\bmany (experts|scholars|researchers|analysts) (believe|argue|suggest)\b/gi,
  /\bstudies (show|suggest|indicate|have shown)\b/gi,
  /\bresearch (shows|suggests|indicates|has shown)\b/gi,
  /\bsources close to\b/gi,
  /\bpeople familiar with\b/gi,
];

const CHALLENGES_PHRASES = [
  /despite (its|these|the|their) (challenges|setbacks|obstacles|difficulties|limitations)/gi,
  /faces (several|many|numerous|various) challenges/gi,
  /continues to thrive/gi,
  /continues to grow/gi,
  /future (outlook|prospects) (remain|look|appear)/gi,
  /challenges and (future|legacy|opportunities)/gi,
  /despite these (challenges|hurdles|obstacles)/gi,
  /overcoming (obstacles|challenges|adversity)/gi,
  /weather(ing|ed) the storm/gi,
];

const COPULA_AVOIDANCE = [
  /\bserves as( a)?\b/gi,
  /\bstands as( a)?\b/gi,
  /\bmarks a\b/gi,
  /\brepresents a\b/gi,
  /\bboasts (a|an|over|more)\b/gi,
  /\bfeatures (a|an|over|more)\b/gi,
  /\boffers (a|an)\b/gi,
  /\bfunctions as\b/gi,
  /\bacts as( a)?\b/gi,
  /\boperates as( a)?\b/gi,
];

const HIDDEN_UNICODE_CHARS = /(?:\u200B|\u200C|\u200D|\u2060|\uFEFF|\u00AD)/g;
const NON_BREAKING_SPACES = /(?:\u00A0|\u202F)/g;

// ─── Pattern Definitions ─────────────────────────────────

const enPatterns = [
  // ── CONTENT PATTERNS ────────────────────────────────────

  {
    id: 'PatternEN-1',
    name: 'Significance inflation',
    category: 'content',
    langs: ['en'],
    description:
      'Inflated claims about significance, legacy, or broader trends. LLMs puff up importance of mundane things.',
    weight: 4,
    detect(text) {
      const results = [];
      for (const regex of SIGNIFICANCE_PHRASES) {
        results.push(
          ...findMatches(
            text,
            regex,
            'Remove inflated significance claim. State concrete facts instead.',
            'high',
          ),
        );
      }
      return results;
    },
  },

  {
    id: 'PatternEN-2',
    name: 'Notability name-dropping',
    category: 'content',
    langs: ['en'],
    description:
      'Listing media outlets or sources to claim notability without providing context or specific claims.',
    weight: 3,
    detect(text) {
      const mediaList =
        /\b(cited|featured|covered|mentioned|reported|published|recognized|highlighted) (in|by) .{0,20}(The New York Times|BBC|CNN|The Washington Post|The Guardian|Wired|Forbes|Reuters|Bloomberg|Financial Times|The Verge|TechCrunch|The Hindu|Al Jazeera|Time|Newsweek|The Economist|Nature|Science).{0,100}(,\s*(and\s+)?(The New York Times|BBC|CNN|The Washington Post|The Guardian|Wired|Forbes|Reuters|Bloomberg|Financial Times|The Verge|TechCrunch|The Hindu|Al Jazeera|Time|Newsweek|The Economist|Nature|Science))+/gi;
      const results = findMatches(
        text,
        mediaList,
        'Instead of listing outlets, cite one specific claim from one source.',
        'high',
      );
      results.push(
        ...findMatches(
          text,
          /\bactive social media presence\b/gi,
          'Remove — not meaningful without specific context.',
          'high',
        ),
      );
      results.push(
        ...findMatches(
          text,
          /\bwritten by a leading expert\b/gi,
          'Name the expert and their specific credential.',
          'medium',
        ),
      );
      results.push(
        ...findMatches(
          text,
          /\bhas been (featured|recognized|acknowledged) (by|in)\b/gi,
          'Cite the specific feature with a concrete claim.',
          'medium',
        ),
      );
      return results;
    },
  },

  {
    id: 'PatternEN-3',
    name: 'Superficial -ing analyses',
    category: 'content',
    langs: ['en'],
    description: 'Tacking "-ing" participial phrases onto sentences to fake depth.',
    weight: 4,
    detect(text) {
      const ingPhrases =
        /,\s*(highlighting|underscoring|emphasizing|ensuring|reflecting|symbolizing|contributing to|cultivating|fostering|encompassing|showcasing|demonstrating|illustrating|representing|signaling|indicating|solidifying|reinforcing|cementing|underscoring|bolstering|reaffirming|illuminating|epitomizing)\b[^.]{5,}/gi;
      return findMatches(
        text,
        ingPhrases,
        'Remove trailing -ing phrase. If the point matters, give it its own sentence with specifics.',
        'high',
      );
    },
  },

  {
    id: 'PatternEN-4',
    name: 'Promotional language',
    category: 'content',
    langs: ['en'],
    description: 'Ad-copy language that sounds like a tourism brochure or press release.',
    weight: 3,
    detect(text) {
      const results = [];
      for (const regex of PROMOTIONAL_WORDS) {
        results.push(
          ...findMatches(
            text,
            regex,
            'Replace promotional language with neutral, factual description.',
            'high',
          ),
        );
      }
      return results;
    },
  },

  {
    id: 'PatternEN-5',
    name: 'Vague attributions',
    category: 'content',
    langs: ['en'],
    description: 'Attributing claims to unnamed experts, industry reports, or vague authorities.',
    weight: 4,
    detect(text) {
      const results = [];
      for (const regex of VAGUE_ATTRIBUTION_PHRASES) {
        results.push(
          ...findMatches(
            text,
            regex,
            "Name the specific source, study, or person. If you can't, remove the claim.",
            'high',
          ),
        );
      }
      return results;
    },
  },

  {
    id: 'PatternEN-6',
    name: 'Formulaic challenges',
    category: 'content',
    langs: ['en'],
    description: 'Boilerplate "Despite challenges... continues to thrive" sections.',
    weight: 3,
    detect(text) {
      const results = [];
      for (const regex of CHALLENGES_PHRASES) {
        results.push(
          ...findMatches(
            text,
            regex,
            'Replace with specific challenges and concrete outcomes.',
            'high',
          ),
        );
      }
      return results;
    },
  },

  // ── LANGUAGE PATTERNS ──────────────────────────────────

  {
    id: 'PatternEN-7',
    name: 'AI vocabulary',
    category: 'language',
    langs: ['en'],
    description:
      'Words and phrases that appear far more frequently in AI-generated text. 500+ words tracked across 3 tiers.',
    weight: 5,
    detect(text, lang = 'en') {
      const locale = getLocale(lang);
      const results = [];
      const words = wordCount(text);

      // Tier 1: always flag
      results.push(...scanWordList(text, locale.TIER_1, 'Tier 1 AI word', 'high'));

      // Tier 2: flag if 2+ tier-2 words appear
      const tier2Matches = scanWordList(text, locale.TIER_2, 'Tier 2 AI word', 'medium');
      if (tier2Matches.length >= 2) {
        results.push(...tier2Matches);
      }

      // Tier 3: flag only at high density (>3% of words are tier-3)
      if (words > 50) {
        const tier3Count = locale.TIER_3.reduce((count, word) => {
          const regex = wordRegex(word);
          return count + countMatches(text, regex);
        }, 0);
        const density = tier3Count / words;
        if (density > 0.03) {
          results.push(
            ...scanWordList(text, locale.TIER_3, 'Tier 3 AI word (high density)', 'low'),
          );
        }
      }

      // AI phrases (from locale)
      results.push(
        ...scanPhrases(
          text,
          (locale.AI_PHRASES || []).filter(
            (p) =>
              p.fix &&
              !p.fix.startsWith('(remove') &&
              !p.fix.startsWith('(eliminar') &&
              !['to', 'because', 'now', 'if', 'can', 'first', 'finally'].includes(p.fix),
          ),
        ),
      );

      return results;
    },
  },

  {
    id: 'PatternEN-8',
    name: 'Copula avoidance',
    category: 'language',
    langs: ['en'],
    description:
      'Using "serves as", "functions as", "boasts" instead of simple "is", "has", "are".',
    weight: 3,
    detect(text) {
      const results = [];
      for (const regex of COPULA_AVOIDANCE) {
        results.push(
          ...findMatches(text, regex, 'Use simple "is", "are", or "has" instead.', 'high'),
        );
      }
      return results;
    },
  },

  {
    id: 'PatternEN-9',
    name: 'Negative parallelisms',
    category: 'language',
    langs: ['en'],
    description:
      '"It\'s not just X, it\'s Y" or "Not only X but Y" constructions — overused by LLMs.',
    weight: 3,
    detect(text) {
      const negParallel =
        /\b(it'?s|this is) not (just|merely|only|simply) .{3,60}(,|;|—)\s*(it'?s|this is|but)\b/gi;
      const notOnly = /\bnot only .{3,60} but (also )?\b/gi;
      return [
        ...findMatches(
          text,
          negParallel,
          'Rewrite directly. State what the thing IS, not what it "isn\'t just".',
          'high',
        ),
        ...findMatches(
          text,
          notOnly,
          'Simplify. Remove the "not only...but also" frame.',
          'medium',
        ),
      ];
    },
  },

  {
    id: 'PatternEN-10',
    name: 'Rule of three',
    category: 'language',
    langs: ['en'],
    description: 'Forcing ideas into groups of three. LLMs love triads that sound "comprehensive".',
    weight: 2,
    detect(text) {
      // Abstract noun triads
      const buzzyTriad =
        /\b(\w+tion|\w+ity|\w+ment|\w+ness|\w+ance|\w+ence),\s+(\w+tion|\w+ity|\w+ment|\w+ness|\w+ance|\w+ence),\s+and\s+(\w+tion|\w+ity|\w+ment|\w+ness|\w+ance|\w+ence)\b/gi;
      const results = findMatches(
        text,
        buzzyTriad,
        'Rule of three with abstract nouns. Pick the one or two that actually matter.',
        'medium',
      );

      // Buzzy adjective triads
      const buzzAdj = [
        'seamless',
        'intuitive',
        'powerful',
        'innovative',
        'dynamic',
        'robust',
        'comprehensive',
        'cutting-edge',
        'scalable',
        'agile',
        'efficient',
        'effective',
        'engaging',
        'impactful',
        'meaningful',
        'transformative',
        'sustainable',
        'resilient',
        'inclusive',
        'accessible',
      ];
      const adjPattern = buzzAdj.join('|');
      const adjTriad = new RegExp(
        `\\b(${adjPattern}),\\s+(${adjPattern}),\\s+and\\s+(${adjPattern})\\b`,
        'gi',
      );
      results.push(
        ...findMatches(
          text,
          adjTriad,
          'Buzzy adjective triad. Pick one and make it specific.',
          'medium',
        ),
      );

      return results;
    },
  },

  {
    id: 'PatternEN-11',
    name: 'Synonym cycling',
    category: 'language',
    langs: ['en'],
    description:
      'Referring to the same thing by different names in consecutive sentences to avoid repetition.',
    weight: 2,
    detect(text) {
      const synonymSets = [
        ['protagonist', 'main character', 'central figure', 'hero', 'lead character', 'lead'],
        ['company', 'firm', 'organization', 'enterprise', 'corporation', 'establishment', 'entity'],
        ['city', 'metropolis', 'urban center', 'municipality', 'locale', 'township'],
        ['building', 'structure', 'edifice', 'facility', 'complex', 'establishment'],
        ['tool', 'instrument', 'mechanism', 'apparatus', 'device', 'utility'],
        ['country', 'nation', 'state', 'republic', 'sovereign state'],
        ['problem', 'challenge', 'issue', 'obstacle', 'hurdle', 'difficulty'],
        ['solution', 'approach', 'methodology', 'framework', 'strategy', 'paradigm'],
      ];

      const results = [];
      const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0);

      for (const synonyms of synonymSets) {
        for (let i = 0; i < sentences.length - 1; i++) {
          const found = [];
          for (let j = i; j < Math.min(i + 4, sentences.length); j++) {
            const lower = sentences[j].toLowerCase();
            for (const syn of synonyms) {
              if (lower.includes(syn) && !found.includes(syn)) {
                found.push(syn);
              }
            }
          }
          if (found.length >= 3) {
            results.push({
              match: `Synonym cycling: ${found.join(' → ')}`,
              index: text.indexOf(sentences[i]),
              line: text.substring(0, text.indexOf(sentences[i])).split('\n').length,
              column: 1,
              suggestion: `Pick one term and stick with it. Found "${found.join('", "')}" used as synonyms in nearby sentences.`,
              confidence: 'medium',
            });
            break;
          }
        }
      }
      return results;
    },
  },

  {
    id: 'PatternEN-12',
    name: 'False ranges',
    category: 'language',
    langs: ['en'],
    description: '"From X to Y" where X and Y aren\'t on a meaningful scale.',
    weight: 2,
    detect(text) {
      const doubleRange = /\bfrom .{3,40} to .{3,40},\s*from .{3,40} to .{3,40}/gi;
      const results = findMatches(
        text,
        doubleRange,
        "False range — X and Y probably aren't on a meaningful scale. Just list the topics.",
        'high',
      );

      const abstractRange =
        /\bfrom (the )?(dawn|birth|inception|beginning|advent|emergence|rise|earliest) .{3,60} to (the )?(modern|current|present|contemporary|latest|cutting-edge|digital|future)/gi;
      results.push(
        ...findMatches(
          text,
          abstractRange,
          "Unnecessarily broad range. Be specific about what you're actually covering.",
          'medium',
        ),
      );

      return results;
    },
  },

  // ── STYLE PATTERNS ──────────────────────────────────────

  {
    id: 'PatternEN-13',
    name: 'Em dash overuse',
    category: 'style',
    langs: ['en'],
    description: 'LLMs overuse em dashes (—) as a crutch for punchy writing.',
    weight: 2,
    detect(text) {
      const emDashes = text.match(/—/g) || [];
      const words = wordCount(text);
      const ratio = words > 0 ? emDashes.length / (words / 100) : 0;

      if (ratio > 1.0 && emDashes.length >= 2) {
        return findMatches(
          text,
          /—/g,
          `High em dash density (${emDashes.length} in ${words} words). Replace most with commas, periods, or parentheses.`,
          'medium',
        );
      }
      return [];
    },
  },

  {
    id: 'PatternEN-14',
    name: 'Boldface overuse',
    category: 'style',
    langs: ['en'],
    description:
      'Mechanical emphasis of phrases in bold. AI uses **bold** as a highlighting crutch.',
    weight: 2,
    detect(text) {
      const boldMatches = text.match(/\*\*[^*]+\*\*/g) || [];
      if (boldMatches.length >= 3) {
        return findMatches(
          text,
          /\*\*[^*]+\*\*/g,
          'Excessive boldface. Remove emphasis — let the writing carry the weight.',
          'medium',
        );
      }
      return [];
    },
  },

  {
    id: 'PatternEN-15',
    name: 'Inline-header lists',
    category: 'style',
    langs: ['en'],
    description: 'Lists where each item starts with a bolded header followed by a colon.',
    weight: 3,
    detect(text) {
      const inlineHeaders = /^[*-]\s+\*\*[^*]+:\*\*\s/gm;
      const matches = text.match(inlineHeaders) || [];
      if (matches.length >= 2) {
        return findMatches(
          text,
          inlineHeaders,
          'Inline-header list pattern. Convert to a paragraph or use a simpler list.',
          'high',
        );
      }
      return [];
    },
  },

  {
    id: 'PatternEN-16',
    name: 'Title Case headings',
    category: 'style',
    langs: ['en'],
    description: 'Capitalizing Every Main Word In Headings. AI chatbots default to this.',
    weight: 1,
    detect(text) {
      const headingRegex = /^#{1,6}\s+(.+)$/gm;
      const results = [];
      let m;
      while ((m = headingRegex.exec(text)) !== null) {
        const heading = m[1].trim();
        const words = heading.split(/\s+/);
        if (words.length >= 3) {
          const skipWords =
            /^(I|AI|API|CLI|URL|HTML|CSS|JS|TS|NPM|NYC|USA|UK|EU|LLM|GPT|SaaS|IoT|CEO|CTO|VP|PR|HR|IT|UI|UX)\b/;
          const capitalizedCount = words.filter(
            (w) => /^[A-Z]/.test(w) && !skipWords.test(w),
          ).length;
          if (capitalizedCount / words.length > 0.7) {
            const lineNum = text.substring(0, m.index).split('\n').length;
            results.push({
              match: m[0],
              index: m.index,
              line: lineNum,
              column: 1,
              suggestion:
                'Use sentence case for headings (only capitalize first word and proper nouns).',
              confidence: 'medium',
            });
          }
        }
      }
      return results;
    },
  },

  {
    id: 'PatternEN-17',
    name: 'Emoji overuse',
    category: 'style',
    langs: ['en'],
    description: 'Decorating headings or bullet points with emojis in professional/technical text.',
    weight: 2,
    detect(text) {
      const emojiCount = countMatches(text, /[\u{1F300}-\u{1F9FF}\u{2600}-\u{27BF}]/gu);
      if (emojiCount >= 3) {
        return findMatches(
          text,
          /[\u{1F300}-\u{1F9FF}\u{2600}-\u{27BF}\u{2300}-\u{23FF}\u{2B50}]/gu,
          'Remove emoji decoration from professional text.',
          'high',
        );
      }
      return [];
    },
  },

  {
    id: 'PatternEN-18',
    name: 'Curly quotes',
    category: 'style',
    langs: ['en'],
    description:
      'ChatGPT uses Unicode curly quotes (\u201C\u201D\u2018\u2019) instead of straight quotes.',
    weight: 1,
    detect(text) {
      return findMatches(
        text,
        /[\u201C\u201D\u2018\u2019]/g,
        'Replace curly quotes with straight quotes.',
        'high',
      );
    },
  },

  // ── COMMUNICATION PATTERNS (19-21) ─────────────────────

  {
    id: 'PatternEN-19',
    name: 'Chatbot artifacts',
    category: 'communication',
    langs: ['en'],
    description:
      'Leftover chatbot phrases: "I hope this helps!", "Let me know if...", "Here is an overview".',
    weight: 5,
    detect(text) {
      // Use the phrase-level detection from vocabulary.js
      return scanPhrases(
        text,
        AI_PHRASES.filter(
          (p) => p.fix === '(remove)' || p.fix === '(remove — start with the content)',
        ),
      );
    },
  },

  {
    id: 'PatternEN-20',
    name: 'Cutoff disclaimers',
    category: 'communication',
    langs: ['en'],
    description: 'AI knowledge-cutoff disclaimers left in text.',
    weight: 4,
    detect(text) {
      return scanPhrases(
        text,
        AI_PHRASES.filter(
          (p) =>
            p.fix === '(remove)' &&
            (p.pattern.source.includes('training') ||
              p.pattern.source.includes('details are') ||
              p.pattern.source.includes('available')),
        ),
      );
    },
  },

  {
    id: 'PatternEN-21',
    name: 'Sycophantic tone',
    category: 'communication',
    langs: ['en'],
    description:
      'Overly positive, people-pleasing language: "Great question!", "You\'re absolutely right!".',
    weight: 4,
    detect(text) {
      return scanPhrases(
        text,
        AI_PHRASES.filter(
          (p) =>
            p.fix &&
            (p.fix.includes('(remove)') || p.fix.includes('address the substance')) &&
            (p.pattern.source.includes('question') ||
              p.pattern.source.includes('point') ||
              p.pattern.source.includes('right') ||
              p.pattern.source.includes('observation')),
        ),
      );
    },
  },

  // ── FILLER & HEDGING (22-24) ────────────────────────────

  {
    id: 'PatternEN-22',
    name: 'Filler phrases',
    category: 'filler',
    langs: ['en'],
    description:
      'Wordy filler that can be shortened: "in order to" → "to", "due to the fact that" → "because".',
    weight: 3,
    detect(text) {
      return scanPhrases(
        text,
        AI_PHRASES.filter(
          (p) =>
            p.fix &&
            !p.fix.startsWith('(') &&
            [
              'to',
              'because',
              'now',
              'if',
              'can',
              'to / for',
              'first',
              'finally',
              'for / regarding',
              'because / since',
            ].includes(p.fix),
        ),
      );
    },
  },

  {
    id: 'PatternEN-23',
    name: 'Excessive hedging',
    category: 'filler',
    langs: ['en'],
    description: 'Stacking qualifiers: "could potentially possibly", "might arguably perhaps".',
    weight: 3,
    detect(text) {
      return scanPhrases(
        text,
        AI_PHRASES.filter(
          (p) =>
            p.fix &&
            (p.fix.includes('could') ||
              p.fix.includes('might') ||
              p.fix.includes('may') ||
              p.fix.includes('perhaps') ||
              p.fix.includes('maybe')),
        ),
      );
    },
  },

  {
    id: 'PatternEN-24',
    name: 'Generic conclusions',
    category: 'filler',
    langs: ['en'],
    description: 'Vague upbeat endings: "The future looks bright", "Exciting times lie ahead".',
    weight: 3,
    detect(text) {
      return scanPhrases(
        text,
        AI_PHRASES.filter(
          (p) =>
            p.fix &&
            (p.fix.includes('specific fact') ||
              p.fix.includes('concrete') ||
              p.fix.includes('cite evidence') ||
              p.fix.includes('what you do know') ||
              p.fix.includes('what happens next')),
        ),
      );
    },
  },

  // ─── NEW PATTERNS (v2.2) ─────────────────────────────────

  {
    id: 'PatternEN-25',
    name: 'Reasoning chain artifacts',
    category: 'communication',
    langs: ['en'],
    description:
      'Exposed chain-of-thought reasoning: "Let me think...", "Step 1:", "Breaking this down..."',
    weight: 4,
    detect(text) {
      const reasoningPatterns = [
        /\blet me think( about this| through this| step by step)?\b/gi,
        /\blet's (think|reason|work) (about|through|this out)\b/gi,
        /\bbreaking (this|it) down\b/gi,
        /\bto approach this (systematically|methodically|logically)\b/gi,
        /\breasoning through (this|the problem|it)\b/gi,
        /\bworking through the logic\b/gi,
        /\bstep ([1-9]|one|two|three|four|five):/gi,
        /\bfirst,? let'?s consider\b/gi,
        /\bthinking about this (carefully|logically|systematically)\b/gi,
        /\bhere'?s my (thought process|reasoning|thinking)\b/gi,
      ];
      const results = [];
      for (const regex of reasoningPatterns) {
        results.push(
          ...findMatches(
            text,
            regex,
            'Hide reasoning or make it natural: "Here\'s my take:" instead of "Let me think step by step:"',
          ),
        );
      }
      return results;
    },
  },

  {
    id: 'PatternEN-26',
    name: 'Excessive structure',
    category: 'style',
    langs: ['en'],
    description:
      'Over-formatted responses: too many headers, nested bullets, or numbered lists for simple content.',
    weight: 3,
    detect(text) {
      const results = [];
      const words = wordCount(text);

      // Count markdown headers
      const headers = (text.match(/^#{1,6}\s+.+$/gm) || []).length;
      // Count bullet points
      const bullets = (text.match(/^[\s]*[-*+]\s+/gm) || []).length;
      // Count numbered items
      const numbered = (text.match(/^[\s]*\d+\.\s+/gm) || []).length;

      // Flag if structure seems excessive for content length
      if (words < 300 && headers >= 3) {
        results.push({
          match: `${headers} headers in ${words} words`,
          index: 0,
          line: 1,
          column: 1,
          suggestion: 'Too many headers for short content. Use prose instead.',
          confidence: 'medium',
        });
      }
      if (words < 200 && bullets + numbered >= 8) {
        results.push({
          match: `${bullets + numbered} list items in ${words} words`,
          index: 0,
          line: 1,
          column: 1,
          suggestion: 'Excessive lists. Could this be a paragraph instead?',
          confidence: 'medium',
        });
      }

      // Check for "Overview:", "Key Points:", "Summary:" pattern
      const structureHeaders =
        /^#+\s*(overview|key (points|takeaways)|summary|conclusion|introduction|background)\s*:?\s*$/gim;
      results.push(
        ...findMatches(
          text,
          structureHeaders,
          'Formulaic structure. Let content flow naturally.',
          'medium',
        ),
      );

      return results;
    },
  },

  {
    id: 'PatternEN-27',
    name: 'Confidence calibration',
    category: 'communication',
    langs: ['en'],
    description:
      'Artificially hedged or over-confident phrasing: "I\'m confident that...", "It\'s worth noting..."',
    weight: 3,
    detect(text) {
      const patterns = [
        {
          regex: /\bI'?m confident (that|in)\b/gi,
          fix: 'State the fact without prefacing confidence',
        },
        { regex: /\bit'?s worth (noting|mentioning|pointing out) that\b/gi, fix: 'Just say it' },
        { regex: /\binterestingly (enough)?,?\b/gi, fix: 'Let reader decide if interesting' },
        { regex: /\bsurprisingly,?\s/gi, fix: 'State the fact; surprise is implied' },
        { regex: /\bimportantly,?\s/gi, fix: 'Let reader judge importance' },
        { regex: /\bsignificantly,?\s/gi, fix: 'Be specific about the significance' },
        { regex: /\bnotably,?\s/gi, fix: 'Just state the notable thing' },
        { regex: /\bcertainly,?\s/gi, fix: 'Remove or state with evidence' },
        { regex: /\bundoubtedly,?\s/gi, fix: 'Remove or cite evidence' },
        { regex: /\bwithout (a )?doubt,?\s/gi, fix: 'Remove or cite evidence' },
      ];
      const results = [];
      for (const { regex, fix } of patterns) {
        results.push(...findMatches(text, regex, fix));
      }
      return results;
    },
  },

  {
    id: 'PatternEN-28',
    name: 'Acknowledgment loops',
    category: 'communication',
    langs: ['en'],
    description: 'Restating the question before answering: "You\'re asking about X. X is..."',
    weight: 4,
    detect(text) {
      const patterns = [
        /\byou'?re asking (about|whether|if|how|why|what)\b/gi,
        /\bthe question of (whether|how|why|what)\b/gi,
        /\bwhen it comes to your question\b/gi,
        /\bin (terms of|response to|answer to) your question\b/gi,
        /\bto (answer|address) your question\b/gi,
        /\byour question (about|regarding|concerning)\b/gi,
        /\bthat'?s a (great|good|interesting) question\. (the|it|so)\b/gi,
        /\bI understand you'?re (asking|wondering|curious)\b/gi,
      ];
      const results = [];
      for (const regex of patterns) {
        results.push(...findMatches(text, regex, "Just answer. Don't restate the question."));
      }
      return results;
    },
  },

  {
    id: 'PatternEN-29',
    name: 'Invisible unicode obfuscation',
    category: 'style',
    langs: ['en'],
    description:
      'Hidden unicode characters (zero-width chars, soft hyphens, non-breaking spaces) used to evade detectors or distort text.',
    weight: 4,
    detect(text) {
      const results = [
        ...findMatches(
          text,
          HIDDEN_UNICODE_CHARS,
          'Remove hidden unicode characters. Some tools insert these to game detectors.',
          'high',
        ),
      ];

      const nbspMatches = findMatches(
        text,
        NON_BREAKING_SPACES,
        'Replace non-breaking spaces with regular spaces unless formatting requires them.',
        'medium',
      );

      // A single NBSP is often harmless (copy/paste from docs).
      // Flag when density suggests obfuscation or accidental corruption.
      if (nbspMatches.length >= 2) {
        results.push(...nbspMatches);
      }

      return results;
    },
  },
];

module.exports = { enPatterns };
