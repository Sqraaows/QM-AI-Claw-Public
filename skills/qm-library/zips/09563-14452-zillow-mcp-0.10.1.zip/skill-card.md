## Description: <br>
Look up real-estate listings, property details, Zestimates, saved searches and homes, and market reports on Zillow via MCP. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to ask an agent for Zillow property searches, property details, Zestimate history, saved Zillow activity, market reports, and mortgage estimates. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The MCP and fetchproxy extension use the user's signed-in Zillow browser session, which can expose saved Zillow activity to the agent workflow. <br>
Mitigation: Enable the skill only in trusted workspaces, keep requests user-directed, and avoid enabling the MCP or extension globally without review. <br>
Risk: The integration relies on unofficial Zillow web endpoints and may encounter captcha, session, or endpoint changes. <br>
Mitigation: Treat results as advisory, verify important property or market information against Zillow directly, and expect occasional authentication or captcha handling. <br>
Risk: Bulk scraping or commercial use may conflict with the security guidance for this release. <br>
Mitigation: Avoid bulk collection and commercial use patterns, and review the external zillow-mcp and fetchproxy code before deployment. <br>


## Reference(s): <br>
- [zillow-mcp npm package](https://www.npmjs.com/package/zillow-mcp) <br>
- [zillow-mcp source repository](https://github.com/chrischall/zillow-mcp) <br>
- [fetchproxy browser extension source](https://github.com/chrischall/fetchproxy) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with MCP setup snippets and structured real-estate results] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only Zillow MCP results; saved-search and saved-home tools require the user's signed-in Zillow browser session.] <br>

## Skill Version(s): <br>
0.10.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
