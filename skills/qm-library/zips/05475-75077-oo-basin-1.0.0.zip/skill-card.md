## Description: <br>
Basin helps an agent read and manage Basin projects, forms, submissions, and webhooks through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent operate a connected Basin account for project, form, submission, and webhook workflows. It is suited to support and marketing operations that need schema-checked Basin actions through OOMOL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Basin submissions that may contain sensitive user information. <br>
Mitigation: Install and use it only when the agent should access the connected Basin account, and limit requests to the data needed for the task. <br>
Risk: Create, update, webhook, and delete actions can change or remove Basin data. <br>
Mitigation: Inspect the live connector schema, review the exact payload and intended effect, and require explicit user confirmation before state-changing or destructive actions. <br>
Risk: The skill requires connected Basin credentials through OOMOL. <br>
Mitigation: Rely on OOMOL-managed credentials and avoid exposing raw API keys in prompts, files, or command arguments. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-basin) <br>
- [Basin homepage](https://usebasin.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, Guidance, JSON] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses from connector runs are JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
