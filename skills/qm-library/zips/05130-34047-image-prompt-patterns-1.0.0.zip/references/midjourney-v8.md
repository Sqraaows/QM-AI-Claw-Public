# Midjourney v8.1 References

> MJ v8.1 专属知识沉淀。Neal 的实战样本 + 骨头分析。source: `raw-data/midjourney-v8-samples.md`

## 何时用本文档

- 用户指定 Midjourney / MJ / `--s` `--ar` `--style raw` 参数
- 用户复制 MJ 官网 prompt / Discord prompt 来优化
- 需要"不提名字"做 celebrity 骨相锚点
- 撞到 banned prompt 需要改写
- 其他模型（GPT-Image-2 / Flux / Nano Banana）请读对应 references

---

## 1. 工作流差异：Discord vs 官网/App

| 维度 | Discord | 官网/App |
|---|---|---|
| Prompt 组织 | 单行文本 + 末尾参数 | 文本 body + 右侧参数栏独立 |
| 参数位置 | `--ar 3:4 --s 50 --style raw --v 8.1` 拼在末尾 | 侧栏控件（ar / s / raw / profile 独立选择） |
| 复制文本时 | 完整 prompt（含参数） | **只有 body**，参数不在文本里 |

**实战影响**：从官网复制来的 prompt **没有参数后缀** ≠ 作者忘写。分析时不要吐槽"没加 `--ar`"，那是 UI 差异。

---

## 2. Neal 的默认后缀表（Discord）

Neal 的稳定偏好：**尽量不加 `--s`**，让 `--style raw` 做主——靠 prompt 词本身调味，不靠 MJ 加美学滤镜也不靠 stylize 拉扯。

| 场景 | 后缀 |
|---|---|
| **默认（绝大多数情况）** | `--ar X --style raw --v 8.1` |
| 极少数想再压一档 MJ 味 | 加 `--s 50`（不要更高）|
| 用户明确说「加点 MJ 味」 | `--s 150`（仅此一档，别更高） |
| niji / 动漫 | `--niji --v 8.1`（raw 不一定保留）|
| 比例：人像 3:4 / 电影 3:2 / 海报 2:3 / 方图 1:1 / 超宽 16:9 | |

**两条血的教训（2026-05-09 Pics topic 连踩两次）**：
1. 不要自作聪明按场景分档（海报 s200 / 电影 s80 / 写实 s100）——Neal 明确纠正 "人家 s50 你怎么 200"
2. 紧接着我又错误地把「s50 一刀切」当 baseline——Neal 再次纠正 "**我是尽可能不用 s，raw 就行**"

**记住**：`--style raw` 是 Neal 的主手，`--s` 是偶尔才动的副手。分清这两个。

---

## 3. 语法红线（绝不要写）

### 3.1 自然语言里的 `no X` 是 SD 时代遗毒

❌ `no watermark, no logo, no extra limbs, no distortion`
❌ `no body below chest, no full body, no wide shot`

MJ 的语言模型把这些词当成**描述画面里有的东西**，反而激活被否定的概念。

**正确做法**：
- 用 `--no X, Y, Z` 参数（不是自然语言）
- 干脆不写——MJ v7+ 对多指、多肢基本修复
- 构图类否定用正面词替代：`close-up portrait framed from chest up` 而不是 `no full body`

### 3.2 "careful attention to hands (five fingers on each)" 同类遗毒

❌ `realistic anatomy with careful attention to hands`
❌ `five fingers on each hand`

v7+ 手指默认不翻车。显式提醒反而让模型过度采样"手"问题空间。**闭嘴反而稳**。

### 3.3 价值判断词是虚词

MJ 视觉训练集没有"价格"维度。

❌ `expensive gold watch`
❌ `luxury silk scarf`
❌ `cheap plastic chair`

✅ 换成具体样式：`chunky gold Cartier-style watch` / `Hermès-style silk scarf with maritime print` / `molded polypropylene cafeteria chair`

**例外**：`luxury marine lifestyle campaign` 这种做**场景类型标签**可以，因为它锚的是广告场景类型，不是单品判断。

### 3.4 多重风格标签堆叠会打架

❌ `photorealistic editorial fashion photography, cinematic hyperrealism, luxury marine lifestyle campaign`

三个不同亚类（杂志叙事 / 电影写实 / 品牌广告）→ MJ 折中给平均值，每个都稀释。

✅ **精选一个主标签 + 一个质感标签**：`luxury campaign, cinematic hyperrealism`

### 3.5 数值写法规范

❌ `80 100mm macro`（两个数字连写）
✅ `80-100mm macro` 或 `100mm macro`

---

## 4. 参数语义

### 4.1 `--s` Stylize 档位

| 值 | 效果 |
|---|---|
| **不写**（Neal 默认）| 靠 `--style raw` 做主，不额外拉 MJ 美学 |
| 0 | 纯 prompt 解释，无 MJ 美学 |
| 50 | 极低 MJ 干预 |
| 100 | MJ 默认（未显式指定时系统值） |
| 250 | 明显的"MJ 味儿"开始 |
| 500 | MJ 美学覆盖，prompt adherence 下降 |
| 750-1000 | MJ 自由发挥，可能偏离 prompt |

**Neal 的用法**：绝大多数 prompt **不加 `--s`**，直接 `--style raw` 顶。只有想再压一档 MJ 味儿时才 `--s 50`。

**文字渲染优先不写 s 或 s50-80**——高 stylize 会让 MJ 即兴改编文字。

### 4.2 `--style raw`

MJ 的"关味精"开关。更贴 prompt、更克制的肤色/光、少一点"MJ 感"。
**跟低 stylize 是叠加关系不是替代**：`--s 100 --style raw` ≠ `--s 50`。
推荐默认全开 raw，除非做纯艺术/奇幻题材。

### 4.3 `--v 8.1`

**当前主力版本**。官网 UI 上显示为 `v 8.1`（右侧栏）。
不要与 stylize 混淆——之前从截图看 `s 8.1` 误以为是 stylize，实际是 version 号。
其他可选：`--v 8` / `--v 7` / `--niji` 系列。

### 4.4 `--no X, Y`

参数化负向提示的**正确位置**。
- ✅ `--no watermark, logo, text`
- ❌ 自然语言写 "no watermark"

### 4.4b 角色参考：版本 ≠ 参数（极易翻车）

**血的教训（2026-05-13 Pics topic）**：把 v7 的 `--oref` 用到了 v8.1 上，被 Neal 当场打脸 "--oref is not compatible with --version 8.1"。

| 版本 | 参数 | 权重 | 范围 |
|---|---|---|---|
| **v8.1** | `--cref <url>` | `--cw N` | 0-100（默认 100，0=只锁脸） |
| v7 | `--oref <url>` | `--ow N` | 0-1000（默认 100） |
| niji 6 | `--cref` | `--cw` | 0-100 |

**死规则**：写完 prompt 检查 `--v 8.1` 和参考参数是否匹配——v8.1 永远配 `--cref/--cw`，看到 `--oref` 立刻换。

**`--cw` 档位（v8.1）**：
- `0`：只锁面部特征
- `50`：脸 + 大致毛色
- `100`（默认/最大）：脸 + 毛色花纹 + 整体外观——动物/复杂花色/celebrity 锁身份首选

**多视图 + cref 翻车点**：MJ 经常把三视图画成三只不同花的同款狗。必加 `identical proportions and identical coat markings across all three panels`。还翻就降级单视图分跑同 cref，事后拼版。

### 4.5 Profile Stacking（高阶）

`--profile abc123 --profile xyz789` 两个 personalization profile 叠加。
- 一个 profile 可能锁"冷感肤色肌理"，另一个锁"极简高定构图"
- 叠加产生定制化视觉指纹
- Profile 代码用户自己训练/收藏，不透明但可组合

**助手工作边界**：profile 代码由用户提供，助手不推测、不生成。


---

## 5. 文字渲染规则（v8 关键知识点）

MJ v8 相对 v6/v7 在文字渲染上**重大跃升**，但仍有边界。

### 5.1 可渲染（准确率 70-80%）

- 大写短标题，3-5 词以内
- 引号包裹：`the title "THE NEW YORK TRENDS"`
- 招牌/标识上的单词

### 5.2 不可渲染（会出乱码装饰字）

- 报纸 body text / 段落文字
- 多行标题
- 非英文（中/日/韩/阿拉伯基本翻车）
- 指定字体名（`in Helvetica` / `Times New Roman` 无效）

### 5.3 提高准确率的配置

- `--s 50-80`（低 stylize）
- `--style raw`
- 大写 + 引号
- 只指挥 hero text，其余让它涂鸦

### 5.4 字体"风格描述"可替代字体名

❌ `in Helvetica Bold`
✅ `bold sans-serif headline style`
✅ `condensed tabloid serif`

---

## 6. Banned Prompt 触发词库

### 6.1 累积触发机制

**单词可能过，组合必卡**。MJ banned filter 是叠加的。

**高风险组合**（样本 6 / nun 案例）：
- `teen` + 武器 + 宗教形象
- `teen` + `sensual/intimate`
- `underage` + 任何亲密词
- 指定真人名字 + 暴力/色情语境

### 6.2 边缘词库（单独放可能过，组合易卡）

`teen` / `nun` / `pistol` / `fires` / `intimacy` / `coltish` / `Euphoria-era` / `stick-and-poke` / `biracial` / `voluptuous` / `sensual` / `undressed`

### 6.3 改写套路（保意图，绕词库）

| 原词 | 替代 |
|---|---|
| `teen` / `teenager` | `early twenties` / `young adult` / `youthful` |
| `nun` | `woman in religious habit` / `black hooded cleric outfit` |
| `fires a pistol` | `raises a gold-plated ornamental pistol toward the sky` |
| `pistol` / `gun` | `ornamental pistol` / `stage prop firearm` |
| `voluptuous` | `curvaceous` / `full-figured` |
| `sensual` | `alluring` / `magnetic presence` |

**核心思路**：
1. 年龄词 → 明确成年
2. 暴力动作 → 持握/姿态，去掉动作语义
3. 武器 → 加 "ornamental/prop/ceremonial" 前缀淡化功能性
4. 宗教身份 → 服装描述替代（"religious habit" 而不是 "nun"）

### 6.4 改写后还要验证

改完不一定一次过。触发了再换词。**不要硬推同一套不改**。

---

## 7. 反 MJ 默认偏向的压制指令

MJ 有几个烦人的"默认美化偏向"，需要显式压制。

### 7.1 反"友好微笑"默认

MJ 对女性面孔默认偏向"温柔友好笑"。压制方法：
- 含蓄：`neutral expression` / `quiet intensity`
- 明示：`not smiling` / `cold gaze` / `emotionless`
- 命令式：`neutral emotionless face, editorial cold gaze`（双词锁死）

### 7.2 反"磨皮厚粉"默认

MJ 对"美女"默认给塑料皮、厚粉底、CG 轮廓。压制方法：
- `visible skin texture`
- `no heavy powder or contour`
- `fine natural pore texture`
- `unretouched editorial realism`

### 7.3 反"模板脸"默认

MJ 对族裔/年龄的默认给最高频模板（K-pop idol face / Instagram 网红脸）。压制三档强度：

| 档位 | 例词 |
|---|---|
| 含蓄 | `distinctive features` / `unconventional beauty` / `subtle asymmetry` / `unfamiliar` |
| 明示 | `not mainstream beauty` / `not polished` |
| 命令式 | `not model prettiness, but weathered earned gravitas`（`not X, but Y` 句式） |

### 7.4 ⚠️ 反默认 vs Celebrity Pretty 的取舍

**重大教训（2026-05-09 Pics topic）**：

"反模板脸"+"visible skin texture" 这套适合**纪录片 / editorial 写实 / 男性粗犷肖像**。
但如果用户要"一眼 celebrity 好看"，这套会出**长得像但不好看**的人。

Celebrity pretty = **骨相锚点 + 杂志抛光语言**，两件事都要。

| 要达到的气质 | 要删 | 要加 |
|---|---|---|
| 纪录片写实 | - | `visible pores, imperfections, no heavy makeup, sun-weathering` |
| Celebrity 封面 | 上述写实词 | `cover star of Vanity Fair, flawless luminous skin, dewy radiant glow, immaculate editorial makeup, silver-screen star gravitas` |

**同样的骨相五维 + 不同的语境抛光 = 完全不同的脸**。骨相提供"像谁"，语境决定"好不好看"。

---

## 8. 骨相五维锚点库（Celebrity 不提名字方法论）

### 8.1 五维框架

| 维度 | 描述什么 | 例词 |
|---|---|---|
| 骨相 | 脸型、颧骨、下颌骨、眉骨、鼻形 | `heart-shaped face`, `strong angular jawline`, `high cheekbones`, `aquiline nose`, `deep-set eyes` |
| 比例 | 身高、身形、颈长、手足 | `slender willowy frame`, `lean but solidly built`, `long elegant neck` |
| 皮肤 | 肤色、质感、雀斑、纹理 | `porcelain skin with faint freckles`, `sun-damaged with visible pores`, `olive complexion`, `translucent pale` |
| 眼神 | 眼形、眼距、眼色、凝视 | `unusually wide-set large doe eyes`, `steel-blue with thousand-yard stare`, `hooded almond eyes`, `unblinking hypnotic gaze` |
| 气场 | 仪态、性格投射、时代感 | `old Hollywood poise`, `quiet earned confidence`, `magnetic screen presence` |

### 8.2 三层替代（不提名字）

想要某明星的"范式"而非本人，拆三层：
1. **骨相五维**（识别特征——来源）
2. **时代锚点**（silent film era / pre-Raphaelite / 60s mod / 90s heroin chic）
3. **作品意境 / 角色气场**（用角色特征暗引，不说作品名）

**示例：ATJ（Anya Taylor-Joy）不提名字**
- 骨相：`heart-shaped face, sharply tapering jawline, high angular cheekbones, naturally arched brows, unusually wide-set large doe eyes, pale blue-gray or hazel`
- 比例：`slender willowy frame, long elegant neck`
- 皮肤：`porcelain skin with faint scattered freckles across the nose bridge`
- 眼神：`unblinking hypnotic gaze with quiet intensity`
- 气场：`old Hollywood poise, magnetic screen presence`
- 时代：`silent film era allure, pre-Raphaelite muse gravitas`
- 角色：`the kind of woman who thinks three moves ahead and doesn't raise her voice`（Beth Harmon 暗引）

### 8.3 男性范本（样本 10）

- 骨相：`strong angular jaw, deep-set eyes`
- 比例：`lean but solidly built`
- 皮肤：`sun-damaged with visible pore texture and slight sun-weathering`
- 眼神：`steel-blue or dark brown eyes with a thousand-yard stare, slight squint`
- 气场：`quiet earned confidence, not model prettiness`
- 文化锚：`Marlboro Man energy, Friday Night Lights grit`
- 行为锚：`the kind of man who fixes fences and doesn't talk much`

### 8.4 Behavioral / Biographical Anchor

**用"他是做什么的/怎么生活的"替代"他是什么样的"**。

| ❌ 形容词锚 | ✅ 行为锚 |
|---|---|
| `tough quiet man` | `the kind of man who fixes fences and doesn't talk much` |
| `elegant sophisticated woman` | `the kind of woman who orders bourbon neat and reads Joan Didion` |
| `intelligent aloof woman` | `the kind of woman who thinks three moves ahead and doesn't raise her voice` |
| `creative bohemian man` | `the kind of man who paints at 3am and forgets to eat` |

MJ v7-v8 非常吃这种隐性文化/阶层/生活方式锚点，远比形容词丰富。

---

## 9. 高权重锚点库（一词顶一段）

### 9.1 胶片锚点

| 胶片 | 视觉指纹 |
|---|---|
| `Kodak Portra 400` | 暖肤色、柔和高光、绿色保守、细颗粒。时尚/肖像首选 |
| `Kodak Tri-X 400` | 经典黑白报道感、中等颗粒 |
| `Ilford HP5 Plus` | 粗颗粒硬朗黑白、fine art 风 |
| `Fuji Acros 100` | 细腻摩登黑白、无颗粒感 |
| `Fuji 400H` | 冷调干净、Kinfolk 风 |
| `Cinestill 800T` | 夜景红晕 halation、钨丝灯氛围 |
| `Ektar 100` | 饱和风光、广告风 |
| `Velvia 50` | 厚饱和、National Geographic 风 |

### 9.2 器材锚点（中画幅质感）

| 器材 | 视觉指纹 |
|---|---|
| `Hasselblad H6D` / `X2D 100C` | 中画幅立体感、肤色层次、时尚/肖像标配 |
| `Phase One XF IQ4 150MP` | 顶级商业中画幅、美妆/静物/广告标配 |
| `Leica M` | 纪实感、35mm 人文摄影 |
| `Arri Alexa` | 电影机感、narrative cinema |
| `RED Komodo` | 现代商业电影、锐利 |
| `Super 8` | 复古家庭录像 |
| `Polaroid SX-70` | 拍立得即时感 |

### 9.3 品牌/地名锚点

- **品牌三连激活一整套视觉包**：`Riva speedboat + Lake Como + Hasselblad` → 木纹弧线 + 湖山别墅 + 中画幅立体感
- 单锚点例：`Lake Como` / `Tokyo Shinjuku` / `Marrakech medina` / `Route 66`

### 9.4 文化 IP 锚点

- `Marlboro Man energy`（硬汉西部）
- `Friday Night Lights grit`（德州高中橄榄球粗砺）
- `West Coast visual attitude`（Chicano / lowrider / 嘻哈）
- `pre-Raphaelite muse`（前拉斐尔派油画气质）
- `silent film era allure`（默片时代妖异）
- `Old Hollywood glamour`（金色年代）

### 9.5 当代美学标签（TikTok/Instagram 流派）

MJ v7-v8 训练数据已吸收。一个标签激活整套时装+妆容+色调+场景。

- `dark feminine` / `dark academia` / `light academia`
- `old money` / `coastal grandmother` / `clean girl`
- `soft girl` / `mob wife` / `cottage core` / `y2k`
- `heroin chic`（90s）/ `indie sleaze`（晚 10s）

---

## 10. 专业领域词汇库（行话 = 强锚点）

MJ 对专业圈行话的视觉响应远高于俗话。

### 10.1 美妆 / Beauty Editorial

- `MLBB` = My Lips But Better（比原唇深一度的裸唇）
- `tightline` = 内眼线
- `cupid's bow` = 唇峰
- `cupid's bow highlight` = 唇峰打高光
- `dewy skin` / `hydrated glow` / `translucent skin`
- `blurred lip line` = 唇线模糊处理
- `diffused blush` = 晕染腮红
- `soft brushed up brows` = 自然眉
- `focus stacked` = 多焦点合成（美妆高清必备）
- `fresh translucent skin` / `no heavy powder`

### 10.2 摄影技术

- `dappled light` = 斑驳光（透过叶）
- `rim light` / `backlit` = 轮廓光 / 逆光
- `chiaroscuro` = 明暗强对比
- `volumetric light` = 体积光
- `caustic light` = 水面光斑
- `hard raking light` = 斜侧硬光
- `golden hour` / `blue hour` = 日落前 / 日出前
- `3/4 angle` = 四分之三面角度（肖像经典）
- `shallow depth of field` / `bokeh`

### 10.3 机位 / 景别

- `medium close-up` / `close-up` / `extreme close-up`
- `wide shot` / `establishing shot` / `over-the-shoulder`
- `low angle` / `high angle` / `Dutch angle`（倾斜）
- `eye-level` / `worm's-eye view` / `bird's-eye view`

### 10.4 构图

- `rule of thirds` / `centered composition` / `symmetrical`
- `leading lines` / `negative space` / `frame within frame`
- `foreground / midground / background layered depth`（深度分层）

---

## 11. 高阶技法

### 11.1 三连锚点

**规律**：三个同类锚点同时激活 → 调出一整套视觉世界。比十个形容词堆叠管用。

| 类型 | 例 |
|---|---|
| 品牌三连 | `Riva speedboat + Lake Como + Hasselblad H6D` |
| 文化符号三连 | `lowrider + West Coast + 90s rap poster` |
| 道具三连 | `curlers + cat-eye sunglasses + newspaper` |
| 时代锚三连 | `silent film era + pre-Raphaelite muse + old Hollywood poise` |

### 11.2 `or` 双选结构

`steel-blue or dark brown eyes` / `Hasselblad X2D or Phase One XF IQ4`

给 MJ 留解释空间，比强制指定一个更灵活。MJ 会在两个相似选项中择优。

### 11.3 遮挡脸技法家族（脸部控制策略）

**规避 MJ 脸部随机性最有效的构图策略**。种类：
- 纱 / 布遮半脸（样本 1）
- 帽檐压住脸（样本 3）
- 道具遮（报纸 / 书 / 手机 / 杯子，样本 8）
- 烟雾 / 雾气
- 手势（手挡 / 捂 / 遮）
- 发丝 / 阴影

**连带效果**：降低 prompt 复杂度——不用写五官、不用做骨相锚点，直接绕开 MJ 最不稳的部位。

### 11.4 深度分层构图

显式声明前中后景，MJ v8 响应非常好。

```
foreground: chains, wet stones, pier texture for depth
midground: the subject
background: ferry passing slowly, Blue Mosque softly emerging through fog
```

比写 "cinematic composition" 准确率高一个量级。

### 11.5 结果导向光线描述

**不是"这里有光"，是"这束光该在哪里反射出什么"**。

结构：**光源性质 + 方向 + 目标反射物**

例：`strong direct midday sunlight from front right creating sharp highlights on gold jewelry and mahogany wheel`

比 "45 度侧光" 几何描述、"warm lighting" 氛围描述效率高一个量级。

### 11.6 色系统一（美妆专属）

美妆类 prompt 的妆容色彩**要做整体色系**，不是各部位独立挑色。

❌ `pink eyeshadow + coral blush + red lips`（打架）
✅ `warm beige peach eyeshadow + warm peach blush + rosy coral MLBB lips`（同属 peach/coral 暖色系）

### 11.7 克制动态描写

`hair beginning to flutter` > `hair flying wild`

"beginning to" 暗示瞬间初始，比完全爆发更摄影感。同理：`swinging gently` > `wildly swinging`。

### 11.8 矛盾指令 = 功能性指令

`warm light` + `black and white photography` 看似矛盾，实则是老摄影师行话。黑白会吃掉色温，但 "warm" 指定了**光源性质**（低色温钨丝偏硬），替换 "cool" 就是另一种光质。

---

## 12. 美妆 vs 人像 vs 美食：技术参数分档

**不要一刀切"50mm f/2.0 稳定"**，按任务类型定：

| 任务 | 镜头 | 光圈 | 原因 |
|---|---|---|---|
| 肖像 | 85mm / 50mm | f/1.4 - f/2.8 | 眼部集中 + 背景虚化 |
| 美妆 beauty | 100mm macro / 85mm | f/8 + focus stacked | 全脸多焦点清晰 |
| 全身时装 | 35mm - 50mm | f/2.8 - f/5.6 | 体型保真 |
| 风光 | 16-35mm | f/8 - f/11 | 深景深 |
| 微距产品 | 100mm macro | f/11 + focus stacked | 全清晰 |

**硬参数稳定区**（MJ 训练数据高频组合）：`50mm f/1.8` / `85mm f/1.4` / `35mm f/2`。
**非稳定区**（概念或不常见数值）：`800mm telephoto` / `tilt-shift 24mm` → 推荐软描述 `ultra telephoto compression` / `miniaturization tilt-shift effect`。


---

## 13. Prompt 字数甜点

- **常规写实摄影**：60-120 词
- **美妆 beauty editorial**：120-200 词（细节密度容忍度高）
- **简约 poster / minimal**：30-60 词
- **风格化绘画**：40-80 词（更长会稀释风格锚）
- **140+ 词**：尾部指令开始被稀释——关键信息务必前置

**信息密度原则**：少即是多。一个 Portra 400 顶十个形容词。

---

## 14. 写作顺序（MJ 友好结构）

按此顺序组织，MJ v8 响应最稳：

1. **景别 / 风格标签**（`Close-up portrait` / `Cinematic editorial portrait`）
2. **主体基础**（who，概述族裔年龄骨相）
3. **皮肤 / 质感**
4. **面部结构细节**
5. **眼神 / 表情**
6. **体型 / 比例**
7. **气场 / 态度**（anti-default 词在这里）
8. **服装**
9. **光线**
10. **镜头 / 景深**
11. **机位角度**
12. **背景**
13. **行为 / 生活锚点**（biographical anchor）
14. **文化 / 时代锚点**（收尾定调）
15. **参数后缀**

**每一层 2-3 个具体词 > 一个形容词**。

---

## 15. 案例库（正反面对照）

完整样本见 `raw-data/midjourney-v8-samples.md`。

### 15.1 正面教材

| 样本 | 题材 | 亮点 |
|---|---|---|
| 1 | 黑白纱质肖像 | 矛盾指令做光质（warm light + B&W） |
| 3 | 帽下少女 | Portra 400 锚点 + 藏脸规避脸部随机 + 情绪三连 |
| 4 | 韩系冷感近照 | 反"友好"+反"磨皮"双默认 + structured fabric 聪明细节 |
| 5 | Lake Como 快艇 | 品牌三连激活视觉世界 + 结果导向光线描述 |
| 7 | 韩系美妆近照 | 美妆行话密度 + macro+f/8+focus stacked 专业配置 |
| 8 | 黑白报纸肖像 | 文字渲染案例 + 遮挡脸技法 + 道具三连 |
| 9 | Istanbul 雾码头 | 深度分层构图 + 当代美学标签（dark feminine） |
| 10 | Texas 粗犷男 | 男性骨相五维完整范本 + behavioral anchor |

### 15.2 反面教材

| 样本 | 题材 | 问题 |
|---|---|---|
| 2 | 动漫女摔倒 | `no watermark, no logo` 自然语言负向提示 + `careful attention to hands` SD 遗毒 + 140 词尾部指令稀释 |
| 6 | 修女 + 金枪 lowrider | `teen` + `nun` + `fires pistol` 三重累积触发 banned prompt |
| ATJ v1 | 不提名字复刻 | "骨相+realism" 语言 → 出"长得像但不好看"——缺 celebrity 抛光语 |

### 15.3 成功改写案例

**样本 6 改写**（规避 banned 词库）：

原：`teen nun fires a gold-plated pistol`
改：`young woman, early twenties, in a full black religious habit and veil, raising a gold-plated ornamental pistol toward the sky`

**ATJ 复刻迭代**：

v1（❌ 丑）：`ethereal young woman, porcelain skin with visible pore texture, no heavy makeup, wide-set doe eyes, not girl-next-door charm` — 骨相对但写实语言把脸做糙了。

v2（✅ 好看）：`Cinematic editorial portrait in the style of a Vanity Fair cover shoot, breathtakingly beautiful young woman, iconic leading-lady face, hypnotically wide-set large doe eyes, flawless luminous porcelain skin, dewy radiant glow, immaculate editorial makeup, old Hollywood leading-lady poise, magnetic screen presence, silver-screen star gravitas, timeless magazine cover beauty` — 同骨相 + 封面抛光语 → celebrity 感。

---

## 16. 项目溯源

### 本 references 诞生（2026-05-09 Pics topic）

**背景**：Neal 在 NoS Pics topic 开 MJ 实战专区，连发 10 条 MJ 官网/Discord prompt 样本让 Nono 拆解。积累到第 10 条后搭出这份 references。

**Neal 原始需求（要沉淀的 7 项）**：
1. v8.1 语法红线（`::` multi-prompt 废除、`--no` 变化）
2. `--s` stylize 档位实际影响
3. Banned Prompt 触发词库 + 累积机制
4. 名人 vibe 不提名字的锚点拆解法
5. Celebrity pretty 的骨相五维库
6. MJ 与 GPT-Image-2 的语法差异对照
7. MJ prompt 字数甜点 + `--style raw` 作用

**本文档覆盖**：1-5、7。第 6 项跨模型对比留给未来 `gpt-image-2.md` + `cross-model-comparison.md` 做。

**关键踩坑**：
- 2026-05-09 v1：Nono 按"海报 s200 / 电影 s80 / 写实 s100" 分档，Neal 纠正"人家 s50 你怎么 200"。
- 2026-05-09 v2：Nono 修正为「s50 一刀切」baseline——Neal 再次纠正「**我是尽可能不用 s，raw 就行**」。最终默认表订正为「不加 `--s`，让 `--style raw` 做主」。
- 2026-05-09：ATJ 第一版复刻出图"丑"。分析：骨相锚对，但"visible pore / no heavy makeup / not girl-next-door" 这套写实压制词对男版粗犷 portrait 加分，对女版 celebrity 扣分。得出结论：**骨相锚点（"像谁"）+ 语境抛光（"好不好看"）要分开处理**。

**下一版更新方向**：
- 跑图对比 `--s 50` vs `--s 100` vs `--s 250` 实际差异（带图）
- 收集更多 banned prompt 触发样本
- Profile 叠加的具体配方（需 Neal 提供自己的 profile 库索引）
- `--sref` style reference 玩法（未覆盖）
- `--cref` character reference 玩法（未覆盖）
