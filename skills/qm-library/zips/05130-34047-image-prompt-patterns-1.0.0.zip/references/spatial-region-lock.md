# Spatial Region Lock（空间区域分锁）

> **场景**：单图编辑里**只让一部分像素改变**——局部绿幕替换、画中画区域更新、屏幕内容切换、窗外景色变化、海报里某一格替换、产品图背景部分改色——其余像素必须保持源图一致。

## 为什么需要这个模式

**模型对"局部"的默认理解 = 全图**。

你说 "replace the background" / "behind her transforms" / "edit the right side"——模型在 latent space 里把"非主体"打包成单一可替换平面，结果连你想保留的部分（半透明绿幕之外的真实墙面、窗外天空、相邻区域）一起被吃掉。

这个失败模式在以下工具上都会出现：
- **GPT Image 2 edit / Nano Banana Pro inpaint**：局部编辑模式下 prompt 边界没说清，模型会扩张修改区域
- **Flux Kontext**：单图改写场景下，"修改 X 区域"经常变成"修改整个背景"
- **Midjourney v8.1 vary region**：region mask 框得粗一点，模型就会渗进框外
- **Stable Diffusion inpaint**：mask 很精确时还行；只靠 prompt 引导边界就崩

## 核心思路

**先用 prompt 建立空间表征，再描述修改动作。**

模型读 prompt 是从前往后建空间表征。如果你先写"换背景"，再补"只换右边那块"，前面已经把整个背景标记为可替换平面了，后面的限定改不动。

正确顺序：
1. **SCENE GEOMETRY** 段开头——把每个元素的物理位置 / 性质 / 边界钉死
2. **REGION A / B / C** 索引段——每个区域单独描述自己的内容和动作
3. **LOCK** 段结尾——三连 ONLY + pixel-identical 兜底

## 结构模板

```
SCENE GEOMETRY (read first, do not violate):
- Frame layout: {主体位置 + 镜头描述}.
- {区域 A 位置说明，用绝对方位 + 相对主体双锁}: {区域 A 是什么物体 + 
  这是 ONLY 会变化的区域 + 边界范围（rectangular / circular / panel）}.
- {区域 B 位置说明}: {区域 B 是什么 + 跟 A 是不同的物理元素 + 
  显式反类型说明，例如 "THIS IS A WINDOW, NOT A SCREEN"}.
- All other pixels ({列出要保留的元素：主体的脸/服装/姿势/手/桌面/墙面/
  灯具/前景物等}): pixel-identical to source. No reframing.

REGION A — {名称} ONLY ({位置}):
{区域 A 的完整描述：替换后的内容 / 风格 / 颜色 / 文字}

REGION B — {名称} ONLY ({位置}):
{区域 B 的完整描述}

[REGION C — {主体本身（如果允许微调）}:
{主体姿势/表情的微调描述}]

LOCK: ONLY Region A and Region B change content. 
No global background replacement. 
No bleed of {A 内容} outside Region A's boundary.
No bleed of {B 内容} outside Region B's boundary.
The rest of the image is pixel-identical to source.
```

## 关键原则

### 1. SCENE GEOMETRY 必须开头

模型读 prompt 是顺序建表征。先写 GEOMETRY，模型先建空间地图；再写动作，动作锚定到地图的具体格子上。

✅ 第一段就把每个元素的物理位置 / 性质 / 边界钉死
❌ 不要把空间限定塞在描述动作的句子末尾（"...behind her, on the right side"）——已经晚了

### 2. 区域用「绝对方位」+「相对主体」双坐标

✅ `ON THE ANCHOR'S RIGHT SIDE (camera-left of her right shoulder): a rectangular display panel`
✅ `ON THE LEFT SIDE OF THE FRAME, behind her left shoulder: a physical glass window`
❌ `behind her`（覆盖整个背景半球，模型分不开）
❌ `next to her`（左右不明）

**为什么双坐标**：单一方位词容易歧义。给镜头方位（camera-left/right）+ 主体方位（her left/right）+ 高度（above/below shoulder/eye-level）三组坐标交叉锁定，歧义被压死。

### 3. 显式反类型（关键！）

如果某个区域容易被模型误解为另一类东西，必须显式反制。

✅ `THIS IS A WINDOW, NOT A SCREEN, NOT GREEN — remains a window throughout with real glass reflections`
✅ `THIS IS THE ONLY GREEN-SCREEN AREA; the rest of the studio wall is solid material, NOT replaceable`
✅ `THIS IS A REAL TV SET in the room, NOT a digital overlay; preserve the bezel and reflections`

模型默认把"绿色矩形 + 在画面里"= 绿幕 = 可替换。你要保留的非绿幕区域如果碰巧也是矩形或者也有亮色，模型会同时擦掉。**只有显式说"这不是 X，是 Y"才能扳回来**。

### 4. ONLY 三连

```
ONLY {A}
ONLY {B}
ONLY animate / change in their own spatial areas
```

至少出现三次 ONLY 才能压住模型的「全图改造」倾向。这跟 Seedance V2V 的 LOCK 段同源——重复是约束的力度。

### 5. pixel-identical 是硬锁词

✅ `All other pixels ... pixel-identical to source.`

GPT Image 2 / Nano Banana Pro / Flux Kontext / Runway Gen-4.5 都吃 "pixel-identical to source" 这个表述——比 "unchanged" / "preserved" / "same as before" 都硬。

实证：写 unchanged 模型还是会微调（光线、轻微构图），写 pixel-identical 模型会真的去匹配像素。

### 6. 边界几何形状要写出来

✅ `the rectangular display panel` / `the circular monitor` / `the trapezoidal billboard`
❌ `the screen` / `the panel`

模型不知道你要保留的边界是什么形状。说"rectangular"它就会沿矩形边界刷；说"the screen"它会拿框外的反光、阴影一起刷掉。

## 适用场景

| 场景 | 区域分配示例 |
|------|------------|
| 局部绿幕替换（演播室主播身后部分绿幕） | A=绿幕矩形, B=保留的演播室设景, C=主播 |
| 画中画 / 屏幕内容更新（监视器、电视、手机屏幕里） | A=屏幕内显示内容, 其余 pixel-identical |
| 窗外景色变化（室内人物 + 窗户外景色变换） | A=窗户矩形内的景色, 其余保留 |
| 多格海报某一格替换（4 格、9 格、栅格列表） | A=指定格的内容, 其余 pixel-identical |
| 产品图局部改色（一件衣服的某一部分换色） | A=指定区域颜色, 其余保留 |
| 半透明叠加更新（HUD 信息、字幕、水印） | A=overlay 内容, 主体 + 背景全部保留 |

## 不适用场景

- **整图风格迁移**（用 portrait / cinematic-storyboard，不需要区域锁）
- **主体本身大幅变化**（用 character-scene-templates 的角色 ID 注入）
- **mask 已经很精确的 inpaint**（模型已经被 mask 限定在像素级，prompt 边界是冗余的；写过头反而干扰）

## 跟 mask 工作流的关系

**Region Lock 是 prompt-only 的弱锁**。对于一定要保住边界的关键素材，应该：

1. **先 mask 后 prompt**：用 PS / ffmpeg / GIMP 做精确 alpha mask（chroma key 抠绿幕：`ffmpeg -i src.jpg -vf "colorkey=0x00FF00:0.4:0.1" mask.png`）
2. 用支持 mask 输入的工具（GPT Image 2 edit with mask / Photoshop Generative Fill / Flux Kontext with mask）
3. **prompt 只描述要填进去什么**，边界由 mask 保证

什么时候用 prompt-only Region Lock：
- 工具不支持 mask 输入（部分 t2i 模型）
- 不想引入 PS / ffmpeg 工序，要一行 prompt 跑通
- 区域形状还在迭代，懒得反复出 mask

什么时候必须上 mask 工作流：
- 边界精度要求 1px 级（产品图、合规海报、可量产素材）
- 单一 prompt 怎么写都漏（区域跟主体重叠、边界曲折、有半透明部分）
- 批量处理（mask 出一次复用 N 次，比 N 次写 prompt 稳）

## 跟 character-scene-templates 的关系

两套模板正交：
- **character-scene-templates**：把同一**主体**塞进不同场景皮（角色身份不变，环境全变）
- **spatial-region-lock**：单图里把**部分像素**改掉（绝大多数像素不变，只动一个区域）

可以叠用：用 character-scene-templates 写主体描述 + 用 spatial-region-lock 写"主体不动，背景里某块换"——但这种场景比较罕见，多见于"广告主角站着，他后面的屏幕换内容"。

## 案例溯源

### 女主播绿幕局部替换（2026-05-16 Alter 频道讨论）

**原 prompt 错误**：
```
The female weather anchor stands in front of the screen pointing at it...
The large screen behind her transforms from green into a live broadcast 
weather-channel graphic... Through the studio window behind her, the 
city skyline is visible in daylight; midway through the shot, a brilliant 
white-orange flash erupts behind the skyscrapers...
```

**失败模式**：
1. "behind her" 同时锚定屏幕动画 + 窗外核爆——模型把这两件事压成一个背景平面
2. "transforms from green into" 字面上让模型把所有绿+所有非主体一起替换
3. 没有 SCENE GEOMETRY 段先建空间地图

**修正方向**：
- 开头加 SCENE GEOMETRY，把屏幕（Region A）+ 窗户（Region B）+ 主播（Region C）分开
- Region B 显式反类型：`THIS IS A WINDOW, NOT A SCREEN, NOT GREEN`
- Region A 描述里加 `the rectangular display panel ON THE ANCHOR'S RIGHT (camera-left of her right shoulder)`，用双坐标锁死位置
- 末尾 LOCK 段三连 ONLY + pixel-identical

**学到的**：
1. **空间表征必须 prompt 开头建**——动作描述放后面，区域索引放前面
2. **绝对方位 + 相对主体**双坐标比单一方位词稳一个数量级
3. **显式反类型**（"NOT A SCREEN, NOT GREEN"）是无 mask 工作流里区分相邻区域的唯一办法
4. 真正的工业级稳定还是要 mask——prompt-only 的 Region Lock 是省工序版本，不是替代品

### 跟视频版本（seedance2）的对照

视频侧的 V2V 还有时间维度（持续层 + 拍点层），图像侧只有空间维度。但**空间区域分锁这一段是共通的**。如果在 Seedance 2.0 V2V 里同时遇到「单帧多区域 + 不同区域不同节奏」的复杂场景，就要叠两个模式：先 SCENE GEOMETRY 拆 Region A/B/C，再在 Region A 里嵌套「持续层 + 拍点层」。详细 cross-reference 见 `seedance2/references/prompt-patterns.md` 的「空间区域分锁」章节末。
