# Midjourney v8.1 Raw Samples

> 2026-05-09 Pics topic 积累的 10 条 MJ 实战 prompt 样本。
> 分析见 `references/midjourney-v8.md`。

Neal 的默认后缀：**`--ar X --style raw --v 8.1`**（尽量不用 `--s`，raw 做主；极少数情况添 `--s 50`）。官网 UI 中参数独立，复制出来只有 body。

---

## Sample 1 — 黑白纱质近照（✅ 正面教材）

```
Medium Shot of a young woman with light skin and freckles, partially obscured by sheer fabric. her face is illuminated by warm light creating geometric shadows across her forehead and nose. her eyes are light colored, full glam make up, and she has full lips with a slight sheen. the fabric, surrounds her, creating a soft, ethereal frame against a light background. her blonde hair, is visible in strands around her face and through the fabric. 3:4 ratio, black and white photography
```

**要点**：矛盾指令做光质（warm light + B&W = 老派摄影行话）/ `freckles` 高权重锚 / `ethereal` 气场词 / 95 词甜点区。

---

## Sample 2 — 动漫女摔倒（❌ 反面教材）

```
Dynamic anime-style action shot, an elegant woman with a notably voluptuous figure, wearing a dark blue pleated skirt and a slightly disheveled white button-up shirt, her striking azure hair caught in the wind, mid-fall on a bustling city street; she is depicted in a moment of comical clumsiness, arms flailing slightly, a surprised expression on her face, intense motion blur conveying speed and impact, realistic anatomy with careful attention to hands (five fingers on each), street details include wet pavement reflecting neon lights and blurred background figures, vibrant color palette with deep blues and contrasting bright neon accents, shot with a wide-angle lens feel for dramatic perspective, cinematic grading with subtle cel-shading, no watermark, no logo, no extra limbs, no distortion.
```

**红线**：`no watermark, no logo, no extra limbs` 自然语言负向提示 = SD 遗毒，MJ 反向激活；`careful attention to hands (five fingers on each)` 同类遗毒；140 词超甜点，尾部反水印被稀释；`voluptuous + comical clumsiness + disheveled` 可能累积触发 banned。

---

## Sample 3 — 帽下少女玫瑰园（✅ 正面教材）

```
Young girl in a large woven sun hat sitting in a summer garden among roses, face tipped down and hidden by brim, yellow sundress, bare feet tucked underneath her. Shot at slight angle from above, 50mm, f/2.0. Warm dappled light, soft pink and green tones. Kodak Portra 400. Quiet, dreamy, unhurried. Ultra realistic editorial photography.
```

**要点**：60 词极简高密度 / `Kodak Portra 400` 一词顶一段后期 / 藏脸规避脸部随机 / `dappled light` 光质名词 / 情绪三连 `Quiet, dreamy, unhurried` / `50mm f/2.0` 硬参数稳定区。

---

## Sample 4 — 韩系冷感近照（✅ 正面教材）

```
Close-up portrait, framed from chest up, no body below chest visible, young woman (20-21), minimalist high-fashion styling, structured fabric visible near neckline, neutral emotionless face, editorial cold gaze, soft lighting, shallow depth of field, 85mm lens, luxury fashion editorial, ultra-realistic, 8K no full body, no torso, no wide shot
```

参数（MJ 官网 UI）：`ar 2:3 · v 8.1 · style raw · stylize 50 · profile 6ucbccB · profile 2c4uajla`（这一条 stylize 显示 50——它是特例，Neal 默认是不写 `--s`）

**要点**：`structured fabric visible near neckline` 锁材质不锁形态（MVP）/ 反"友好微笑"双指令（neutral emotionless + cold gaze）/ profile 叠加 / `no full body` 构图否定冗余（有 ar 2:3 + close-up 已够）。

---

## Sample 5 — Lake Como Riva 快艇（✅ 正面教材）

```
Medium long shot of sophisticated beautiful 25 year old Asian Eastern European woman standing confidently at helm of vintage wooden Riva speedboat on Lake Como Italy, both hands on polished mahogany steering wheel, body leaning slightly forward with energy, radiant focused expression, wearing white linen loose shirt, white summer pants, silk scarf with classic maritime print tied on head, black cat eye sunglasses, massive gold earrings, gold bracelets gold rings expensive gold watch, hair beginning to flutter, deep blue sparkling water rushing past at speed, white foam wake, green Italian hillside with elegant villas in background, clear blue sky, strong direct midday sunlight from front right creating sharp highlights on gold jewelry and mahogany wheel, photorealistic editorial fashion photography, cinematic hyperrealism, luxury marine lifestyle campaign, shot on Hasselblad H6D, 85mm lens, shallow depth of field, rich contrast white clothing against deep blue water
```

**要点**：品牌三连（Riva + Como + Hasselblad）/ 结果导向光线描述（`strong direct midday from front right creating sharp highlights on gold and mahogany`）/ `hair beginning to flutter` 克制动态 / `Asian Eastern European` 混血锚点构建独特面孔。

**缺点**：`expensive gold watch` 虚词 / 三重风格标签冲突（editorial + hyperrealism + campaign）。

---

## Sample 6 — 修女金枪 lowrider（❌ 反面教材）

```
An young beautiful teen nun in full black habit and veil leaning out the window of a lowrider, frozen mid-motion as she fires a gold-plated pistol into the air, her face confident and defiant. The nun wears round sunglasses and a diamond rosary swings in the wind. Shot in bright daylight with clear blue sky, harsh shadows, and rich color contrast. West Coast visual attitude meets high-concept absurdity hip-hop editorial energy in the style of a protest album cover. Stylized like a vintage 90s rap poster, symmetrical and iconic.
```

**红线**：`teen` + `nun` + `fires pistol` 三重累积触发 banned prompt，大概率卡。

**改写（保意图）**：
```
A young woman, early twenties, in a full black religious habit and veil, leaning out the window of a vintage lowrider, frozen mid-motion as she raises a gold-plated ornamental pistol toward the sky, her face confident and defiant. Round sunglasses, a diamond rosary swinging in the wind. Bright daylight, clear blue sky, harsh shadows, rich color contrast. West Coast visual attitude meets high-concept absurdity, hip-hop editorial energy in the style of a protest album cover. Stylized like a vintage 90s rap poster, symmetrical and iconic. --ar 2:3 --s 50 --style raw --v 8.1
```

---

## Sample 7 — 韩系美妆近照（✅ 正面教材）

```
Close up beauty portrait of a Korean woman in her 20s, framed from top of head to neck, full face centered. Includes forehead, hairline, partially visible ears, jawline, chin, and neck. Calm, refined, slightly unfamiliar editorial beauty. Natural makeup: fresh translucent skin, soft hydrated glow, minimal foundation, visible skin texture, no heavy powder or contour. Soft warm beige peach eyeshadow, clean tightline, naturally curled separated lashes, delicate mascara. Full softly brushed up natural brows. Gentle warm peach blush, diffused. Luminous highlights on forehead, nose bridge, cheekbones, cupid's bow. Soft rosy coral MLBB lips, slightly glossy, blurred lip line. Hair pulled back with loose wisps on forehead and cheeks. Calm, neutral, quietly sensual expression. Pure white studio background. Soft diffused editorial lighting enhancing skin texture and glow. Hasselblad X2D 100C or Phase One XF IQ4 150MP, 80 100mm macro, f/8, ISO 100, 1/125s, focus stacked.
```

**要点**：美妆行话密度（MLBB / tightline / cupid's bow / focus stacked）/ `f/8 + macro + focus stacked` 美妆专用配置（与肖像 f/1.4 完全不同）/ `slightly unfamiliar editorial beauty` 反模板脸含蓄档 / `visible skin texture + no heavy powder` 反磨皮默认 / 色系统一（peach/coral 全暖色系）。

**小瑕疵**：`80 100mm macro` 缺连字符应为 `80-100mm`。

---

## Sample 8 — 黑白报纸女（✅ 正面教材，文字渲染案例）

```
A hyper-realistic black and white close-up photograph of a blonde woman with curlers on her head, wearing cat-eye sunglasses, holding an open newspaper in front of her, half of her face covered, looking over her glasses at the camera, daring, a lot of text on the newspaper and the title inscription "THE NEW YORK TRENDS", a light, plain white background, 8k,
```

**要点**：文字渲染案例（hero title 大写+引号 MJ v8 能渲染 70-80% 准确）/ 遮挡脸（报纸挡半脸）= 脸部控制策略 / 道具三连（curlers + cat-eye + newspaper）调出 50s-60s 家庭主妇语境。

---

## Sample 9 — Istanbul 雾码头（✅ 正面教材）

```
Istanbul Bosphorus waterfront in heavy morning fog, cinematic black and white fine art photography, dark feminine woman wearing a long black coat, standing on a wet stone pier, strong wind moving her hair and coat, visible motion, emotional tension, foreground elements (chains, wet stones, pier texture) for depth, seagulls flying dynamically across the sky, Blue Mosque silhouette softly emerging through dense fog, large ferry passing slowly in background, high contrast but soft highlights, moody shadows, deep blacks, 35mm film grain, cinematic atmosphere, feeling of solitude, quiet power, inner reflection
```

**要点**：显式深度分层（foreground: chains / midground: woman / background: ferry + mosque） / `dark feminine` 当代美学标签词 / 动态堆叠（wind + coat + hair + seagulls + ferry）/ 情绪三连（solitude, quiet power, inner reflection）。

**小修正**：`35mm film grain` 偏笼统，黑白可以直接上具体胶片：`Ilford HP5 Plus` / `Tri-X 400`。

---

## Sample 10 — Texas 粗犷男（✅ 男性骨相五维范本）

```
Hyperrealistic portrait photography, rugged weathered Texas male, early-to-mid 30s, sun-damaged skin with visible pore texture and slight sun-weathering, strong angular jaw, heavy short stubble, crow's feet at corners of eyes, deep-set steel-blue or dark brown eyes with a thousand-yard stare, slight squint from years of hard sun, lean but solidly built, quiet earned confidence not model prettiness, wearing a plain crisp white button-down shirt collar slightly open, soft directional natural side lighting, shallow depth of field, shot on 85mm f/1.4, Kodak Portra 400, facing camera at slight 3/4 angle, neutral light background, the kind of man who fixes fences and doesn't talk much, Marlboro Man energy, Friday Night Lights grit
```

参数：`--ar 3:4 --style raw --v 8.1`（Neal 默认不加 s）

**骨相五维全中**：
| 维度 | 锚点 |
|---|---|
| 骨相 | strong angular jaw / deep-set eyes |
| 比例 | lean but solidly built |
| 皮肤 | sun-damaged / visible pore / sun-weathering |
| 眼神 | thousand-yard stare / steel-blue / slight squint |
| 气场 | quiet earned confidence, not model prettiness |

**additional**：
- Behavioral anchor: `the kind of man who fixes fences and doesn't talk much`
- 文化 IP 双连: `Marlboro Man energy, Friday Night Lights grit`

---

## Sample X — ATJ 不提名字复刻（迭代案例）

参考图：Sample 10 出图（粗犷男版）。

### X.1 直接套 Sample 10 结构做女版（❌ 丑）

```
Hyperrealistic portrait photography, ethereal young woman in her late 20s, porcelain skin with faint scattered freckles across the nose bridge and cheeks, fine visible pore texture, no heavy makeup, heart-shaped face with sharply tapering jawline and a small pointed chin, high angular cheekbones, strong naturally arched brows, unusually wide-set large doe eyes, pale blue-gray or hazel, unblinking hypnotic gaze with quiet intensity, slender willowy frame with a long elegant neck, old Hollywood poise not girl-next-door charm, wearing a plain crisp white silk blouse with a small high collar, soft directional natural side lighting, shallow depth of field, shot on 85mm f/1.4, Kodak Portra 400, facing camera at slight 3/4 angle, neutral light background, the kind of woman who thinks three moves ahead and doesn't raise her voice, silent film era allure, pre-Raphaelite muse gravitas --ar 3:4 --s 50 --style raw --v 8.1
```

**问题**：骨相对、气场对，但 `visible pore texture / no heavy makeup / not girl-next-door charm` 是纪录片写实语言，女版会出"长得像但不好看"。

### X.2 加 Vanity Fair 抛光重写（✅ 一眼 celebrity）

```
Cinematic editorial portrait in the style of a Vanity Fair cover shoot, breathtakingly beautiful young woman in her late 20s, iconic leading-lady face, heart-shaped with sharply tapering jawline and a small pointed chin, high angular cheekbones, strong naturally arched brows, hypnotically wide-set large doe eyes, pale blue-gray or hazel, mesmerizing captivating gaze, flawless luminous porcelain skin with a few delicate freckles across the nose bridge, dewy radiant glow, immaculate editorial makeup with soft rose-flushed cheeks and a delicately defined lip, slender willowy figure with a long elegant neck, long flowing hair caught softly in a breeze, old Hollywood leading-lady poise, magnetic screen presence, wearing a plain crisp white silk blouse with a small high collar, soft cinematic natural side lighting, shallow depth of field, shot on 85mm f/1.4, Kodak Portra 400, facing camera at slight 3/4 angle, softly blurred neutral light background, silver-screen star gravitas, timeless magazine cover beauty --ar 3:4 --s 50 --style raw --v 8.1
```

**关键改动**：
- `Hyperrealistic portrait photography` → `Cinematic editorial portrait in the style of a Vanity Fair cover shoot`
- 删 `visible pore texture / no heavy makeup`，改 `flawless luminous porcelain skin / dewy radiant glow / immaculate editorial makeup`
- `unusually wide-set` → `hypnotically wide-set`
- `old Hollywood poise not girl-next-door charm`（反默认句）→ `iconic leading-lady face, magnetic screen presence`（正向堆叠）
- 加 `silver-screen star gravitas, timeless magazine cover beauty`

**教训**：**骨相锚点（"像谁"）+ 语境抛光（"好不好看"）要分开处理**。不提名字复刻不是骨相五维就够了，还得配对的语境词。
