## Description: <br>
Provides agent access to cloudlayer.io through OOMOL's oo CLI for creating PDF jobs and reading account, job, and asset data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent create cloudlayer.io PDF generation jobs, inspect job status, retrieve generated assets, and check account usage through a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected cloudlayer.io account through OOMOL. <br>
Mitigation: Install and use it only when the agent should operate that connected account, and rely on OOMOL-managed credentials rather than exposing raw tokens. <br>
Risk: PDF job creation can create account activity or consume credits. <br>
Mitigation: Confirm the exact job payload and intended effect with the user before running create_html_pdf_job, create_template_pdf_job, or create_url_pdf_job. <br>
Risk: First-time setup may involve running a remote oo CLI installer. <br>
Mitigation: Review the installer step before execution and run setup only when the local oo CLI is missing or authentication fails. <br>


## Reference(s): <br>
- [cloudlayer.io homepage](https://cloudlayer.io) <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-cloudlayer) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
