## Description: <br>
FlowiseAI helps agents fetch a connected FlowiseAI chatflow and send JSON-only prediction requests through OOMOL's oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect a connected FlowiseAI chatflow and send JSON-only prediction requests through an OOMOL-connected account without handling raw FlowiseAI credentials locally. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected FlowiseAI account and sensitive credentials managed through OOMOL. <br>
Mitigation: Use it only when the OOMOL intermediary and connected account are trusted, and avoid handling raw API tokens locally. <br>
Risk: The send_message action can submit user-provided payloads to the connected FlowiseAI chatflow. <br>
Mitigation: Review the live schema, exact payload, and intended effect with the user before running send actions. <br>
Risk: First-time setup may require installing the oo CLI or opening OOMOL console connection flows. <br>
Mitigation: Run install or connection steps only after an auth, connection, or missing-command error and only from trusted OOMOL domains. <br>


## Reference(s): <br>
- [FlowiseAI homepage](https://flowiseai.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [FlowiseAI ClawHub release](https://clawhub.ai/oomol/oo-flowiseai) <br>
- [get_chatflow action reference](actions/get_chatflow.md) <br>
- [send_message action reference](actions/send_message.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence.release.version and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
