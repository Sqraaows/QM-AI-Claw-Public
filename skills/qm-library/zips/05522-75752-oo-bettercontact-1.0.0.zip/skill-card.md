## Description: <br>
BetterContact helps agents operate BetterContact through an OOMOL-connected account for account balance checks and lead enrichment workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to check BetterContact credits, submit lead enrichment requests, and retrieve enrichment results through an OOMOL-connected BetterContact account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Lead enrichment submissions can consume BetterContact credits and send lead data to the connected service. <br>
Mitigation: Confirm the exact enrichment payload and intended effect with the user before running submit_enrichment. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live BetterContact action schema before constructing or running a payload. <br>
Risk: The skill requires an authenticated OOMOL-connected BetterContact account. <br>
Mitigation: Use it only in environments where the user intends to operate that connected account and has reviewed the account, credential, and billing state. <br>


## Reference(s): <br>
- [ClawHub BetterContact skill](https://clawhub.ai/oomol/oo-bettercontact) <br>
- [BetterContact homepage](https://bettercontact.rocks) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return BetterContact action results as JSON when commands are executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: SKILL.md frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
