## Description: <br>
Use when the user asks to look up, search, or manage Google Contacts and the broader People API, including Workspace directory people searches, profile fields, and manager or reports relationships. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users install this skill to let an MCP-enabled agent search, read, create, and inspect Google Contacts and People API profile data for an authenticated Google account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Contact and Workspace directory queries can expose sensitive personal or organizational data. <br>
Mitigation: Install only for a Google account whose contacts and directory data may be exposed to the MCP-enabled agent, and review organizational privacy rules before sharing results. <br>
Risk: Raw People API output can include broader profile data than a targeted lookup needs. <br>
Mitigation: Avoid raw People API dumps unless needed; prefer narrower contact or people search tools for routine lookups. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp-contacts) <br>
- [gogcli](https://github.com/openclaw/gogcli) <br>
- [gogcli-mcp](https://github.com/chrischall/gogcli-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [Text, JSON, Configuration] <br>
**Output Format:** [Markdown guidance with JSON configuration examples and MCP tool results] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return Google Contacts and Workspace directory profile data from the authenticated account.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
