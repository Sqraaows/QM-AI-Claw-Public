## Description: <br>
AI-powered code review assistant that performs static analysis, identifies security vulnerabilities, enforces coding standards, suggests refactoring patterns, and generates PR review comments. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[gechengling](https://clawhub.ai/user/gechengling) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, tech leads, security engineers, and maintainers use this skill to review code snippets, files, or pull requests for correctness, security, performance, readability, testability, and style concerns. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Broad trigger phrases such as "refactor" or "static analysis" may activate the skill unintentionally. <br>
Mitigation: Review activation context before using the skill and invoke it only for code review tasks. <br>
Risk: Garbled non-English text in the skill file may reduce clarity in some workflow sections. <br>
Mitigation: Rely on the clear English workflow sections and confirm unclear guidance before applying it. <br>
Risk: Submitted source code may contain sensitive intellectual property or secrets. <br>
Mitigation: Provide only code intended for review and remove secrets before sharing code with the agent. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/gechengling/ai-code-review-expert) <br>
- [Publisher profile](https://clawhub.ai/user/gechengling) <br>


## Skill Output: <br>
**Output Type(s):** [analysis, markdown, code, configuration, guidance] <br>
**Output Format:** [Markdown with structured findings, code blocks, review comments, scoring tables, and PR summary text.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May ask for language, framework, review focus, code context, and team standards before producing findings.] <br>

## Skill Version(s): <br>
3.0.1 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
