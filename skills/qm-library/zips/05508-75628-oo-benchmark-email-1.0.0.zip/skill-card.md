## Description: <br>
Benchmark Email lets an agent read Benchmark Email account details, contact list summaries, contact details, and paginated contact lists through the OOMOL `benchmark_email` connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and business users use this skill to retrieve Benchmark Email account and contact data from an OOMOL-connected account. It supports read-focused marketing and communication workflows such as checking account storage details, reviewing list counts, and looking up contacts. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Benchmark Email account and can read account and contact/list data. <br>
Mitigation: Install it only where that account access is appropriate, and review requested schemas and payloads before running connector commands. <br>
Risk: Future connector actions or user requests could involve creating, updating, sending, posting, deleting, or removing Benchmark Email data. <br>
Mitigation: Require explicit user confirmation for any action that changes state or targets data for deletion. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-benchmark-email) <br>
- [Benchmark Email Homepage](https://www.benchmarkemail.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON from the OOMOL connector, including a data object and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
