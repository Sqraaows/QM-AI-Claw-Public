## Description: <br>
OKSign lets agents query OKSign account and document information through the oksign connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations users with an OKSign account use this skill to check credit balance, expiry, storage details, active documents, signed document metadata, linked document identifiers, and configured users. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials or connector access for OKSign account and document data. <br>
Mitigation: Install only in trusted environments, grant the minimum OKSign access needed, and review runtime credential permissions before use. <br>
Risk: Returned document identifiers, user lists, credit balances, and account metadata may be sensitive. <br>
Mitigation: Share outputs only with authorized users and avoid pasting returned OKSign data into unrelated workflows. <br>


## Reference(s): <br>
- [OKSign homepage](https://www.oksign.be/en/) <br>
- [ClawHub OKSign skill page](https://clawhub.ai/oomol/oo-oksign) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, API calls, guidance] <br>
**Output Format:** [Markdown guidance and returned OKSign account or document data.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires OKSign credentials or connector access in the runtime environment.] <br>

## Skill Version(s): <br>
1.0.0 (source: release.version, metadata.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
