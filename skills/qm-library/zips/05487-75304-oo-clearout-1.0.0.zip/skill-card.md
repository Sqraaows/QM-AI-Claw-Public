## Description: <br>
Clearout helps agents operate Clearout through an OOMOL-connected account to check credits and verify or classify email addresses. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to run Clearout credit checks and real-time email verification or classification through an OOMOL-connected Clearout account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Submitted email addresses may be sent through the OOMOL connector to Clearout for verification. <br>
Mitigation: Confirm the user intends to use OOMOL and Clearout for the email addresses being checked before running verification actions. <br>
Risk: The skill requires an installed and authenticated oo CLI plus a connected Clearout account. <br>
Mitigation: Use setup or reconnection steps only after a command fails with the matching CLI, authentication, or connection error. <br>
Risk: Connector schemas and available fields can change upstream. <br>
Mitigation: Fetch the live oo connector schema for the selected Clearout action before constructing each payload. <br>
Risk: Clearout credit or billing limits can prevent verification actions from completing. <br>
Mitigation: Check available credits when needed and stop for recharge or billing resolution if an insufficient-credit error is returned. <br>


## Reference(s): <br>
- [Clearout homepage](https://clearout.io) <br>
- [Clearout skill on ClawHub](https://clawhub.ai/oomol/oo-clearout) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload or response descriptions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before action payloads; no additional post-processing specified.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
