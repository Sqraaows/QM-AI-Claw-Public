## Description: <br>
MoonClerk helps agents read MoonClerk customer, payment form, and payment data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent search and retrieve MoonClerk customers, payment forms, and payments from an OOMOL-connected MoonClerk account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected MoonClerk account. <br>
Mitigation: Install it only when the agent should read MoonClerk customer, form, and payment data through OOMOL. <br>
Risk: Requests to create, update, send, post, delete, change billing, or perform setup could affect account state or cost. <br>
Mitigation: Require explicit user approval before running those actions or setup steps. <br>
Risk: The fallback CLI installation command runs a remote installer. <br>
Mitigation: Use the installer only when the oo CLI is missing and the user has approved the setup step. <br>


## Reference(s): <br>
- [MoonClerk homepage](https://moonclerk.com) <br>
- [MoonClerk skill on ClawHub](https://clawhub.ai/oomol/oo-moonclerk) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Reads MoonClerk data through OOMOL; connector command responses include data and an executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
