## Description: <br>
Grist lets an agent inspect, read, add, update, and delete records in a connected Grist account through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and operations teams use this skill to work with Grist workspaces, documents, tables, columns, and records from an agent session. It supports schema inspection before action payloads and covers both read workflows and confirmed data changes. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Grist data available to the connected API key. <br>
Mitigation: Install it only for trusted OOMOL and Grist accounts, and use credentials with the least access needed for the task. <br>
Risk: Add, update, and delete actions can change or remove Grist records. <br>
Mitigation: Confirm the exact payload, target table, affected row IDs, and intended effect with the user before executing any write or delete action. <br>
Risk: First-time setup may require installing or authenticating the oo CLI. <br>
Mitigation: Use official, verifiable installation and sign-in instructions, and avoid repeating setup steps unless a command fails for that specific reason. <br>


## Reference(s): <br>
- [Grist homepage](https://www.getgrist.com) <br>
- [ClawHub Grist skill page](https://clawhub.ai/oomol/oo-grist) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload descriptions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON data from the Grist connector when executed with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
