## Description: <br>
U301 (u301.com). Use this skill for U301 requests involving reading, creating, updating, and deleting short-link data through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate U301 short links from an OOMOL-connected account, including listing domains, creating short links, and deleting existing short links. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or delete U301 short links, which can change externally visible routing behavior. <br>
Mitigation: Confirm the exact action payload and expected effect with the user before creating links, and require explicit approval before deleting a link. <br>
Risk: First-time setup may require running remote installer commands for the OOMOL oo CLI. <br>
Mitigation: Install only after verifying the OOMOL oo CLI source, and do not run setup commands proactively when an existing authenticated CLI session works. <br>
Risk: The skill requires a connected U301 API key through OOMOL. <br>
Mitigation: Use the existing OOMOL-managed connection and avoid exposing, copying, or requesting raw U301 credentials in agent conversation. <br>


## Reference(s): <br>
- [ClawHub U301 skill page](https://clawhub.ai/oomol/oo-u301) <br>
- [U301 homepage](https://u301.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON action results] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions are executed through the oo CLI against the connected U301 account.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
