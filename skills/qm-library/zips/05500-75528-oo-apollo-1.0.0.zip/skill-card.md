## Description: <br>
Apollo helps agents search, read, enrich, and inspect Apollo account data through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and business operators use this skill to run Apollo prospecting, enrichment, organization search, people search, and API usage lookups from an OOMOL-connected Apollo account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires the oo CLI and an OOMOL-connected Apollo account, so account access and credentials are involved. <br>
Mitigation: Confirm OOMOL is trusted, install the oo CLI through an approved method, and connect Apollo only from the intended account. <br>
Risk: Apollo connector fields and defaults can change upstream, which may make stale payloads incorrect. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>
Risk: People and organization search or enrichment can return business contact data. <br>
Mitigation: Use results according to organizational policy, Apollo account permissions, and the user's stated task. <br>


## Reference(s): <br>
- [Apollo ClawHub Skill](https://clawhub.ai/oomol/oo-apollo) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>
- [enrich_organization action](actions/enrich_organization.md) <br>
- [enrich_person action](actions/enrich_person.md) <br>
- [get_api_usage_stats action](actions/get_api_usage_stats.md) <br>
- [search_organizations action](actions/search_organizations.md) <br>
- [search_people action](actions/search_people.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown instructions with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, OOMOL sign-in, and an OOMOL-connected Apollo account.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
