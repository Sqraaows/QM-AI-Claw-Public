## Description: <br>
Story Short Scan helps writers analyze short-form web fiction rankings across platforms such as Zhihu Yanyan, Qimao, Heiyan, and Dianzhong to identify current themes, emotional hooks, and topic opportunities. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Writers, editors, and market researchers use this skill to collect or review short-story ranking samples, compare platform-specific patterns, and produce scan reports with trend candidates, saturation risks, and follow-up validation steps. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can reuse a logged-in browser session and extract an admin token for a management backend. <br>
Mitigation: Use a dedicated browser profile with only the required account logged in, confirm authorization before scraping, and avoid personal sessions. <br>
Risk: Generated markdown may include private or operational data from authenticated pages. <br>
Mitigation: Write outputs to a controlled directory and review generated markdown before sharing it. <br>


## Reference(s): <br>
- [Story Short Scan ClawHub page](https://clawhub.ai/worldwonderer/story-short-scan) <br>
- [OpenClaw source metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [Short web fiction market reference](references/real-market-data.md) <br>
- [Dianzhong browse page](https://www.ishugui.com/browse) <br>
- [Heiyan management booklist](https://manage.zhangwenpindu.cn/books/booklist) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, guidance, files] <br>
**Output Format:** [Markdown reports and instructions, with optional generated markdown data files from scraper scripts] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Reports should label sample date, signal strength, and rescan timing; authenticated collection requires an authorized browser session.] <br>

## Skill Version(s): <br>
1.1.3 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
