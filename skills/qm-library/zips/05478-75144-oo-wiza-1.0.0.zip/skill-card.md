## Description: <br>
Wiza connector skill for searching prospects, retrieving list and credit information, and running individual reveal workflows through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Sales, marketing, recruiting, and operations users can use this skill to search Wiza prospect data, inspect lists and credit balances, and start or check individual contact reveals from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Running Wiza reveal or enrichment actions can consume Wiza credits or expose contact data. <br>
Mitigation: Review the payload and intended effect before starting reveal or enrichment actions, and check credit balance when relevant. <br>
Risk: The skill requires access to a connected Wiza account through OOMOL. <br>
Mitigation: Use OOMOL server-side credential handling and avoid collecting or storing raw Wiza credentials locally. <br>
Risk: The workflow may require installing the oo CLI from a remote installer. <br>
Mitigation: Install the oo CLI only from trusted OOMOL sources and review installer commands before running them. <br>


## Reference(s): <br>
- [Wiza homepage](https://wiza.co) <br>
- [ClawHub Wiza skill listing](https://clawhub.ai/oomol/oo-wiza) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands require an installed oo CLI, an OOMOL sign-in, and a connected Wiza account; connector responses are JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
