## Description: <br>
Use the Surface mail CLI to read and act on Gmail, Outlook, and generic IMAP/SMTP mail through one JSON-first contract. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[vishalj99](https://clawhub.ai/user/vishalj99) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents and developers use this skill to operate Surface CLI for email search, unread triage, message reading, attachment handling, drafting, sending, mailbox actions, and thread watches across Gmail, Outlook, and generic IMAP/SMTP accounts. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can give an agent sensitive access to mailbox contents and account credentials. <br>
Mitigation: Install it only for intended mail operations, avoid sharing passwords in chat, and review local Surface CLI configuration before use. <br>
Risk: Send, reply, archive, and read-state actions can change live mailboxes. <br>
Mitigation: Keep write safety enabled, prefer drafts before live sends, and confirm recipients and mailbox actions before execution. <br>
Risk: External summarizer configuration may send email content outside the local machine. <br>
Mitigation: Confirm the privacy tradeoff with the user before enabling or changing any external summarizer backend. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/vishalj99/surface-cli) <br>
- [Publisher Profile](https://clawhub.ai/user/vishalj99) <br>
- [Surface CLI Homepage](https://github.com/VishalJ99/surface-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and configuration guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses Surface CLI JSON outputs, stable message and thread refs, and local account configuration.] <br>

## Skill Version(s): <br>
0.4.1 (source: release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
