## Description: <br>
Operates Beehiiv through an OOMOL-connected account to inspect schemas and run connector actions for publications, posts, and subscriptions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to retrieve Beehiiv publication, post, and subscription data through an OOMOL-connected Beehiiv account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Beehiiv account or API key through OOMOL and can access business and subscriber data. <br>
Mitigation: Install only when OOMOL is trusted for the connected Beehiiv account and review requested connector payloads before execution. <br>
Risk: Future create, update, send, post, delete, or remove actions could change Beehiiv state or be destructive. <br>
Mitigation: Confirm the exact payload, target, and intended effect with the user before running any state-changing or destructive action. <br>


## Reference(s): <br>
- [ClawHub Beehiiv skill](https://clawhub.ai/oomol/oo-beehiiv) <br>
- [Beehiiv homepage](https://www.beehiiv.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
