## Description: <br>
Access Splitwise expense and group data via MCP. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent read Splitwise users, friends, groups, balances, expenses, categories, currencies, and notifications. With a configured Splitwise API key, the agent can also create, edit, or delete expenses and manage group membership through the Splitwise MCP server. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can let an agent create, edit, or delete real Splitwise expenses and change group membership. <br>
Mitigation: Require explicit user confirmation before any create, edit, delete, or group membership action. <br>
Risk: The skill requires a sensitive Splitwise API key for MCP server access. <br>
Mitigation: Install only trusted releases, keep the key out of shared files, and rotate or remove the key when the skill is no longer used. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/chrischall/splitwise-mcp) <br>
- [npm package: splitwise-mcp](https://www.npmjs.com/package/splitwise-mcp) <br>
- [Splitwise app registration](https://secure.splitwise.com/apps/register) <br>


## Skill Output: <br>
**Output Type(s):** [API Calls, Configuration, Guidance, Shell commands] <br>
**Output Format:** [Markdown with JSON and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires a Splitwise API key and a registered splitwise MCP server.] <br>

## Skill Version(s): <br>
2.0.8 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
