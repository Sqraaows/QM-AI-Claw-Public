## Description: <br>
Operate Cloudflare Workers through an OOMOL-connected account, including reading, creating, updating, and deleting workers, scripts, settings, and secrets. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to manage Cloudflare Workers and Worker scripts through the oo CLI after connecting a Cloudflare account in OOMOL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Write and delete actions can change or remove Cloudflare Worker resources. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write actions, and require explicit approval before destructive actions. <br>
Risk: Secret-binding actions handle sensitive Worker configuration. <br>
Mitigation: Use the OOMOL-connected credential flow, avoid exposing raw secret values in prompts or logs, and confirm the script and binding name before changing secrets. <br>
Risk: ClawHub installation or sync workflows can use local registry credentials and minimal install telemetry. <br>
Mitigation: Review local credential handling and disable sync telemetry when organizational policy requires it. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-cloudflare-worker) <br>
- [Cloudflare Workers](https://workers.cloudflare.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector actions return JSON with data and meta.executionId when run.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
