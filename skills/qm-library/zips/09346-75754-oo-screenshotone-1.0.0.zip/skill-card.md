## Description: <br>
ScreenshotOne helps agents operate ScreenshotOne through an OOMOL-connected account for screenshot, animated capture, bulk capture, usage, and device preset requests. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, designers, and automation agents use this skill to inspect ScreenshotOne connector schemas, run screenshot capture actions, retrieve usage information, and list device presets through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Screenshot capture actions contact target URLs through an external service and may consume ScreenshotOne quota or credits. <br>
Mitigation: Confirm screenshot, animated screenshot, and bulk capture payloads before execution, especially target URLs and requested output settings. <br>
Risk: The skill depends on the oo CLI, OOMOL authentication, and a connected ScreenshotOne API key. <br>
Mitigation: Install only for users who intend to use ScreenshotOne through OOMOL, and resolve authentication or connection setup only when an action fails for that reason. <br>
Risk: Capture actions can create output files. <br>
Mitigation: Review requested capture settings and expected file outputs before running capture or bulk capture actions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-screenshotone) <br>
- [ScreenshotOne homepage](https://screenshotone.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, Guidance, JSON, Files] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads; connector runs may return JSON data and generated screenshot files.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and a connected ScreenshotOne API key.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
