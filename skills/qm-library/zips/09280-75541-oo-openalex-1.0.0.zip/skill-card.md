## Description: <br>
OpenAlex (openalex.org). Use this skill for ANY OpenAlex request - searching and reading data. Whenever a task involves OpenAlex, use this skill instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, researchers, and analysts use this skill to search OpenAlex, retrieve works and entities by identifier, and inspect live connector schemas before running OpenAlex actions through the OOMOL oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses OOMOL-connected OpenAlex access, so connector calls may use the user's connected account and credits. <br>
Mitigation: Use the skill only with a trusted OOMOL account connection, and resolve billing or connection errors before retrying requests. <br>
Risk: First-time setup may execute an OOMOL oo CLI installer if the CLI is not already available. <br>
Mitigation: Run installer commands only after confirming the setup need and trusting the OOMOL installer source. <br>
Risk: OpenAlex action schemas can change upstream, which can make stale payloads incorrect. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing payloads. <br>


## Reference(s): <br>
- [OpenAlex homepage](https://openalex.org/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [autocomplete action](actions/autocomplete.md) <br>
- [get_entity action](actions/get_entity.md) <br>
- [get_work action](actions/get_work.md) <br>
- [list_entities action](actions/list_entities.md) <br>
- [list_works action](actions/list_works.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
