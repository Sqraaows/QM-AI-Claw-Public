## Description: <br>
Look up Compass real-estate listings, property details, photos, price history, comparable rentals, and address resolutions through MCP. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agent workflows can use this skill to query Compass listings, compare properties, inspect listing details and photos, resolve addresses, and calculate mortgage or affordability estimates. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill routes Compass requests through the user's signed-in browser session. <br>
Mitigation: Use it only with a Compass session whose listing data the user is willing for the agent to query, and review the active browser session before use. <br>
Risk: The setup relies on an external npm MCP package and Chrome fetchproxy extension. <br>
Mitigation: Install from the expected package and extension sources, keep dependencies updated, and avoid use in environments where browser-session bridging is not allowed. <br>
Risk: Compass does not provide a public consumer API for these lookups, so page-rendered data extraction may become incomplete or stale. <br>
Mitigation: Verify important property details directly on Compass before making financial or operational decisions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/compass-mcp) <br>
- [Publisher profile](https://clawhub.ai/user/chrischall) <br>
- [compass-mcp npm package](https://www.npmjs.com/package/compass-mcp) <br>
- [fetchproxy Chrome extension source](https://github.com/chrischall/fetchproxy) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, configuration, guidance] <br>
**Output Format:** [Markdown responses with structured listing data and inline configuration snippets.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only Compass listing lookup; network tools require compass-mcp, fetchproxy, the Chrome extension, and a signed-in Compass tab.] <br>

## Skill Version(s): <br>
0.11.2 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
