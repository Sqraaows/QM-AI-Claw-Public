---
name: andrew-translate
description: 高质量三步式翻译工作流（初稿 → 反思校正 → 精稿）。基于 Andrew Ng 开源 translation-agent 思路，通过初译、专家反思、定稿改写三个阶段，生成接近母语者水准的翻译。当用户需要翻译文本（中英互译、跨语种翻译、文档翻译、技术文档/论文/书籍/邮件/字幕/产品文案翻译）、需要"高质量翻译""润色翻译""专业翻译""信达雅翻译""二次校对翻译"，或者明确提到"三步翻译""反思式翻译""translation agent""translation-agent"时，必须主动使用本 skill。即便用户只是说"帮我翻译这段话""把这段英文翻成中文""translate this""润色一下译文"也应触发本 skill，而不是直接给出一遍机器翻译。当用户希望指定地区风格（如"翻成台湾繁体""美式英语""英式英语""墨西哥西班牙语"）时尤其适用。
version: 1.0
---

# AIBox Translate — 三步式高质量翻译

本 skill 的核心思想：**一遍翻译往往不够好**。直接让模型"翻译这段话"得到的是机器翻译水准的初稿，而真正接近母语者水平的译文需要经过"反思—改写"两轮迭代。本 skill 把这个过程显式化，分三步执行。

参考开源项目：<https://github.com/andrewyng/translation-agent>

## 何时使用

- 用户要求翻译任意文本（句子、段落、整篇文章、代码注释、字幕、邮件、文档）。
- 用户要求"高质量翻译""信达雅""润色""校对""二次校对"已有译文。
- 用户希望翻译结果带有特定地区风格（台湾繁体、香港繁体、美式/英式英语、拉美西班牙语等）。
- 用户提到 translation agent / 反思式翻译 / 三步翻译。

如果用户只是问"xxx 这个词什么意思"或要求术语解释，**不要**强行套用三步流程，直接回答即可。本 skill 针对的是**成段文本翻译**。

## 输入参数

每次执行翻译前，先确认以下参数（缺失则向用户询问或合理默认）：

| 参数 | 说明 | 默认 |
| --- | --- | --- |
| `source_lang` | 源语言（如 English、Chinese、Japanese） | 自动从源文本识别 |
| `target_lang` | 目标语言 | 必须由用户指定，或根据上下文推断（如用户用中文提问翻英文，则反之） |
| `source_text` | 待翻译的原文 | 必填 |
| `country` | 目标语言的地区/国家变体（如 "Taiwan"、"USA"、"Mexico"） | 可选，默认空字符串 |

**关键判断**：如果用户没有明确说目标语言，就用对话语言的另一端作为默认（例如用户用中文请求翻英文文章，那 target_lang 就是 Chinese）。

## 工作流：三步翻译

> 严格按顺序执行三步，**每一步都是一次独立的 LLM 推理**，不要把三步合并成一个提示词，否则反思和改写会失去独立判断的价值。

### 步骤 1 — 初稿（Initial Translation）

目的：先得到一份完整、忠实的直译，作为后续反思的对象。

**System message**：
```
You are an expert linguist, specializing in translation from {source_lang} to {target_lang}.
```

**User prompt**：
```
This is an {source_lang} to {target_lang} translation, please provide the {target_lang} translation for this text. Do not provide any explanations or text apart from the translation.
{source_lang}: {source_text}

{target_lang}:
```

把这一步的结果保存为 `translation_1`。**不要展示给用户**——这只是中间产物。

### 步骤 2 — 反思校正（Reflection）

目的：让模型以"专家审校者"的身份找出初稿的问题，给出具体改进建议。这是质量提升的关键一步。

**System message**：
```
You are an expert linguist specializing in translation from {source_lang} to {target_lang}. You will be provided with a source text and its translation and your goal is to improve the translation.
```

**User prompt**（当 `country` 非空时使用 A 版，否则使用 B 版）：

详细的两个版本提示词模板见 `references/prompts.md` 的 "Step 2: Reflection" 章节。核心要点：让模型从四个维度审查 —— **准确性 / 流畅性 / 风格 / 术语一致性**，并写成"逐条改进建议清单"，每条只针对译文的一个具体问题。

把这一步的结果保存为 `reflection`。**不要展示给用户**——除非用户明确要求看审校意见。

### 步骤 3 — 精稿（Improved Translation）

目的：让模型作为"翻译编辑"，结合原文、初稿和反思建议，输出最终定稿。

**System message**：
```
You are an expert linguist, specializing in translation editing from {source_lang} to {target_lang}.
```

**User prompt** 详见 `references/prompts.md` 的 "Step 3: Improved Translation" 章节。核心要求：把 `<SOURCE_TEXT>` `<TRANSLATION>` `<EXPERT_SUGGESTIONS>` 三段内容用 XML 标签清晰分隔后交给模型，要求它**仅输出新译文**、不要任何解释。

把结果保存为 `translation_2`，这就是要交给用户的最终成品。

## 输出格式

默认只把**最终精稿** `translation_2` 交给用户，保持简洁。

如果用户明确要求"展示三步过程""我想看初稿和审校意见""show me the reflection"，则按以下结构输出：

```
## 初稿
<translation_1>

## 审校意见
<reflection>

## 精稿（推荐使用）
<translation_2>
```

## 实施要点

1. **三次独立调用**。三步必须是三次独立的模型调用，不能合并。如果当前环境只有一个对话上下文，就在同一会话中**依次发出三条消息**，每条对应一步，确保前一步的输出作为下一步的输入。

2. **不要泄漏中间产物**。除非用户要求，否则不要把初稿和反思贴出来——它们会让最终交付显得啰嗦。

3. **长文本分块**。如果原文超过模型上下文一次能稳妥处理的长度（经验上 >2000 词的英文或 >3000 字的中文），先按段落语义切分，对每个 chunk 独立跑三步流程，最后拼接。**切分时不要打散一个完整段落**。

4. **保留格式**。原文中的 Markdown、代码块、HTML 标签、列表编号、占位符（如 `{name}`、`%s`）必须原样保留在译文里，绝不翻译这些结构性元素。

5. **专有名词与代码**。人名、产品名、API 名、命令行参数、文件路径默认保留原文；只有在目标语言有公认译名（如 "Microsoft" → "微软"）时才翻译，并且首次出现时可在括号里附原文。

6. **`country` 参数怎么用**。当用户说"翻成台湾繁体""用美式英语"，就把 `country` 设成对应值（"Taiwan" / "USA" / "UK" / "Mexico" 等），让反思步骤注意地区性词汇、拼写、习语差异。

## 示例

**用户输入**：
> 帮我把这段翻成中文：
> "An important configuration setting is the number of tokens to generate in a response. Generating more tokens requires more computation from the LLM, leading to higher energy consumption..."

**你的处理**（内部三步，对外只交付精稿）：

1. 步骤 1 产出直译（可能偏机械："一个重要的配置设置是在响应中生成的 token 数量..."）
2. 步骤 2 反思（可能指出：「"配置设置"重复啰嗦」「"token"在中文技术语境保留原词更自然」「"导致更高的能耗"不够流畅，可改为"会带来更高的能耗"」等）
3. 步骤 3 整合反思，输出定稿

**最终交付**：
> 一个重要的配置项是响应中生成的 token 数量。生成的 token 越多，LLM 所需的计算量就越大，相应地会带来更高的能耗，可能拖慢响应速度，并推高调用成本……

## 详细资源

- `references/prompts.md` — 三步完整提示词模板（含带/不带 country 的两种 reflection 变体、XML 分隔规范）。**当你要严格复刻原始 translation-agent 行为时，必读。**
- `references/languages.md` — 常见 `source_lang` / `target_lang` / `country` 取值参考、地区变体差异速查。

## 常见误区

- ❌ 把三步合并成一个 prompt 让模型"先译再审再改"——模型会偷懒，反思流于形式。
- ❌ 跳过反思步骤，只做"翻译 + 自我润色"——质量提升远不如显式反思。
- ❌ 把所有中间产物都贴给用户——除非他们要求，否则只交付定稿。
- ❌ 翻译时打乱原文段落顺序、合并段落、改写结构——译文应与原文段落一一对应。
