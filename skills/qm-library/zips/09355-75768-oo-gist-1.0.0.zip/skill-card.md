## Description: <br>
Gist operates GitHub Gists through an OOMOL-connected account, letting an agent read, create, update, delete, fork, star, and comment on gists through the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and technical users use this skill when they want an agent to manage GitHub Gists through an existing OOMOL/GitHub connection. It supports gist creation, retrieval, updates, deletion, forks, comments, stars, revisions, commits, and user or public gist listing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected OOMOL/GitHub Gist account and can act with that account's access. <br>
Mitigation: Install it only for accounts where agent-managed Gist access is intended, and keep the OOMOL/GitHub connection scoped to the needed use. <br>
Risk: Create, update, star, unstar, fork, and comment actions can change Gist state. <br>
Mitigation: Review the exact payload and expected effect with the user before running state-changing actions. <br>
Risk: Delete actions can remove Gist data or comments. <br>
Mitigation: Confirm the target explicitly and ensure backups or recovery plans exist before deletion. <br>


## Reference(s): <br>
- [Gist homepage](https://gist.github.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-gist) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires live schema inspection before action payloads and an OOMOL-connected GitHub Gist account.] <br>

## Skill Version(s): <br>
1.0.0 (source: release metadata and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
