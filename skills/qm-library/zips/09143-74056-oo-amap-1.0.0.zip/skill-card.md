## Description: <br>
AMap lets agents search and read AMap data through OOMOL's amap connector for geocoding, places, routes, weather, districts, input tips, and IP location. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to query AMap through an OOMOL-connected account for addresses, coordinates, place search, route planning, administrative districts, IP location, input tips, and weather. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: AMap queries can include sensitive addresses, coordinates, routes, or IP lookup data. <br>
Mitigation: Send only the data needed for the user's requested lookup and confirm sensitive or business-critical location payloads before execution. <br>
Risk: The skill depends on an OOMOL-managed AMap connection and API-key-backed usage. <br>
Mitigation: Install and use it only when the user trusts OOMOL as the connector provider and accepts routing requests through the managed CLI connection. <br>
Risk: AMap connector schemas and defaults can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub AMap skill](https://clawhub.ai/oomol/oo-amap) <br>
- [AMap homepage](https://www.amap.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON command output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live OOMOL connector schemas before building JSON payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
