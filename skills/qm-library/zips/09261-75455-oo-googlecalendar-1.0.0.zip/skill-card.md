## Description: <br>
Use this skill for Google Calendar requests, including reading, creating, updating, and deleting calendar data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and external users use this skill to let an agent operate Google Calendar through the OOMOL connector for scheduling, availability lookup, calendar administration, ACL management, and event lifecycle tasks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access and modify sensitive Google Calendar data through an OOMOL-connected account. <br>
Mitigation: Install it only when that level of calendar access is acceptable, and review exact payloads before write operations. <br>
Risk: Calendar clears, deletions, attendee removal, ACL changes, event moves, and updates can be destructive or affect other users. <br>
Mitigation: Confirm the target resource, payload, and intended effect with the user before running destructive or state-changing actions. <br>
Risk: Setup, login, or connection repair commands may affect the user's OOMOL account or connected Google Calendar authorization. <br>
Mitigation: Run installation, login, or connection steps only when the connector reports that setup or authorization is required. <br>


## Reference(s): <br>
- [Google Calendar product page](https://workspace.google.com/products/calendar/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Google Calendar skill page](https://clawhub.ai/oomol/oo-googlecalendar) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Configuration guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
