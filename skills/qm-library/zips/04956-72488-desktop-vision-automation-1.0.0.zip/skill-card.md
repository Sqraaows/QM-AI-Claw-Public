## Description: <br>
Provides Windows desktop vision and automation actions for screen capture, screen recording, UI detection, OCR, image matching, keyboard and mouse control, window management, and batch task execution. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[wuyifeishu](https://clawhub.ai/user/wuyifeishu) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill to let an OpenClaw agent inspect a Windows desktop, collect screenshots or OCR results, and execute controlled desktop automation workflows such as clicking, typing, window management, recording, playback, and batch tasks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can capture or record sensitive desktop content. <br>
Mitigation: Use it only in controlled sessions, avoid running it while passwords or confidential content are visible, and review output paths before saving files. <br>
Risk: The skill can type, click, use hotkeys, replay recorded actions, and close or move windows across the desktop. <br>
Mitigation: Require explicit human approval before input simulation, playback, hotkeys, and window-closing actions; test workflows in a non-production environment first. <br>
Risk: Recorded action scripts can preserve sensitive coordinates, keystrokes, or workflow data. <br>
Mitigation: Store scripts in approved locations, review them before replay, and delete recordings that are no longer needed. <br>


## Reference(s): <br>
- [Desktop Vision Automation on ClawHub](https://clawhub.ai/wuyifeishu/desktop-vision-automation) <br>
- [Publisher profile](https://clawhub.ai/user/wuyifeishu) <br>
- [Tesseract OCR Windows installer guidance](https://github.com/UB-Mannheim/tesseract/wiki) <br>


## Skill Output: <br>
**Output Type(s):** [text, code, shell commands, configuration, guidance, files] <br>
**Output Format:** [JSON responses plus generated screenshot, recording, OCR, and action-script files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions are invoked with an action name and JSON parameters; some actions write files to caller-specified paths.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
