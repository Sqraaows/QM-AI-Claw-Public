---
name: "camera-ai"
version: "1.0.1"
description: "摄像头AI视觉识别工具。当用户说'看这个''拍个照''这是什么''识别一下''摄像头看看''拍照识别''这是谁''人脸识别'等与摄像头/图像/人脸相关的请求时调用此技能。支持：1)USB摄像头捕获 2)MiniMax AI分析(人物/物体/场景) 3)本地人脸辨识(认出是谁)。首次使用需运行安装脚本。"
---

# CameraAI Skill - 摄像头AI识别（含人脸辨识）v1.0.1

## ⚠️ 首次使用 - 必读！

### 安装依赖

首次使用本 SKILL 时，需要安装依赖。依赖清单见 `requirements.txt`。

#### 方式1：OpenClaw 自动安装（推荐）

OpenClaw 会自动读取 `requirements.txt` 并生成安装脚本。

#### 方式2：手动安装

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 安装 camera_ai 包（开发模式）
cd camera-ai
pip install -e .

# 3. 验证安装
python -m camera_ai status
```

#### 方式3：逐个安装

```bash
pip install opencv-python numpy
cd camera-ai
pip install -e .
```

### 手动检查依赖

```bash
python -c "
deps = {
    'cv2': 'OpenCV (摄像头)',
    'numpy': 'NumPy',
    'camera_ai': 'CameraAI 包'
}
missing = []
for name, desc in deps.items():
    try:
        __import__(name)
        print(f'✓ {desc}: 已安装')
    except ImportError:
        print(f'✗ {desc}: 未安装')
        missing.append(name)

if missing:
    print(f'\n请安装依赖: pip install -r requirements.txt')
else:
    print('\n所有依赖已就绪！')
"
```

### 依赖清单

| 依赖 | 用途 | 必须 | 内存占用 |
|------|------|------|---------|
| **opencv-python** | 摄像头捕获、图像处理、人脸检测 | ✅ 是 | ~50MB |
| **numpy** | 数值计算 | ✅ 是 | ~30MB |
| **camera_ai** | 本 SKILL 包（pip install -e . 安装） | ✅ 是 | - |
| **mmx-cli** | MiniMax AI 图像理解 | ⚠️ AI分析需要 | 不占本地内存 |

> **内存优化**：本 SKILL 使用 OpenCV 内置人脸检测，无需额外安装 dlib/face_recognition，对低配置设备友好。

### 硬件要求

| 组件 | 要求 | 说明 |
|------|------|------|
| **摄像头** | USB 接口摄像头 | 支持 USB Webcam，即插即用 |
| **分辨率** | 最低 640x480 | 推荐 1280x720 或更高 |
| **系统** | Windows/Linux/Mac |跨平台支持 |

> **注意**：本 SKILL 仅支持 USB 接口摄像头，不支持 IP 摄像头。如需 IP 摄像头支持，请自行扩展。

### 图像增强

由于部分 USB 摄像头存在曝光过度或色彩偏黄的问题，拍照时建议使用 `--auto-adjust` 参数进行**自动图像增强**：

```bash
python -m camera_ai capture --auto-adjust
```

**增强技术**：
- **白平衡校正** - 修正色彩偏黄问题
- **CLAHE 对比度增强** - 改善细节和局部对比度

---

## 快速使用指南（给 OpenClaw / 智能体）

### 触发词列表

当用户说以下内容时，调用此 SKILL：

| 用户说的话 | 功能分类 | 执行命令 |
|-----------|---------|---------|
| **"你看这个是什么？"** | 拍照+AI分析 | `capture` → `analyze` |
| **"这是谁？" / "认识吗？"** | 拍照+人脸辨识 | `capture` → `face identify` |
| **"拍张照"** | 纯拍照 | `capture` |
| **"帮我注册一下爸爸的脸"** | 注册人脸 | `face register --name 爸爸 --camera` |
| **"监控有没有人来"** | 持续监控 | `monitor -m person` |
| **"识别人脸"** | 分析图片中的人脸 | `face identify -i 图片.jpg` |

### 标准工作流程

#### 流程A：通用场景理解（"这是什么？"）

```
步骤1: 拍照
  → python -m camera_ai capture -o ./captures/latest.jpg

步骤2: MiniMax AI 分析
  → python -m camera_ai analyze -i ./captures/latest.jpg

步骤3: 返回结果给用户
```

#### 流程B：人脸身份识别（"这是谁？"）

```
前提条件: 已通过 `face register` 注册过人脸

步骤1: 拍照
  → python -m camera_ai capture -o ./captures/latest.jpg

步骤2: 本地人脸比对
  → python -m camera_ai face identify -i ./captures/latest.jpg

步骤3: 返回结果: "这是张三 (置信度 97.5%)"

可选: 同时调用 MiniMax 描述场景细节
  → python -m camera_ai analyze -i ./captures/latest.jpg
```

#### 一键完整命令（推荐 OpenClaw 使用）

```python
# 拍照 + 人脸识别 + 场景分析 = 完整感知
import subprocess, os, json, sys

# 添加 SKILL 路径
sys.path.insert(0, '.trae/skills/camera-ai')

from camera_ai.core import capture_image, CaptureOptions
from camera_ai.core.face.registry import FaceRegistry
from camera_ai.core.face.engine import get_face_engine, release_face_engine
from camera_ai.core.minimax import MinimaxClient
from camera_ai.core.result import ResultFormatter
from camera_ai.core.types import AnalysisMode

# 1. 拍照
result = capture_image(CaptureOptions(output='./captures/quick_capture.jpg'))
if not result['success']:
    print(f'拍照失败: {result.get("error")}')
    exit(1)

img_path = result['output_path']

# 2. 人脸识别（如果有人脸库）
registry = FaceRegistry()
if registry.count > 0:
    engine = get_face_engine()
    if engine.check_available()[0]:
        face_result = registry.identify_from_image(img_path, engine)
        print("\n[人脸识别]")
        print(ResultFormatter.format(face_result, 'text') if hasattr(face_result, 'raw_text') else str(face_result))
        release_face_engine()

# 3. 场景分析
client = MinimaxClient()
analysis = client.analyze(img_path, mode=AnalysisMode.GENERAL)
print("\n[场景分析]")
print(ResultFormatter.format(analysis, 'text'))
```

---

## 命令参考

### 基础命令

```bash
# === 状态检查 ===
python -m camera_ai status                    # 查看系统状态和依赖

# === 拍照 ===
python -m camera_ai capture                   # 默认拍照
python -m camera_ai capture -o photo.jpg       # 指定路径
python -m camera_ai capture -w 640 -h 480      # 低分辨率（省内存）
python -m camera_ai capture --auto-adjust      # 自动图像增强（推荐）
python -m camera_ai capture -a                  # 简写：自动增强

# === AI分析（MiniMax VLM）===
python -m camera_ai analyze -i photo.jpg              # 通用分析
python -m camera_ai analyze -i photo.jpg -m face      # 人脸描述
python -m camera_ai analyze -i photo.jpg -m object    # 物体识别
python -m camera_ai analyze -i photo.jpg -f json      # JSON输出

# === 监控 ===
python -m camera_ai monitor                          # 每5秒监控
python -m camera_ai monitor -t 10 -m person           # 每10秒检测人
```

### 人脸识别命令

```bash
# === 注册人脸（一次性操作）===

# 从图片注册
python -m camera_ai face register -n "张三" -i zhangsan.jpg
python -m camera_ai face register -n "妈妈" -i mom.jpg

# 从摄像头直接拍照注册
python -m camera_ai face register -n "爸爸" --camera

# 查看已注册列表
python -m camera_ai face identify --list
# 输出:
#   [1] 张三     ID: 张三_001  注册于: 2026-05-09
#   [2] 妈妈     ID: 妈妈_001  注册于: 2026-05-09


# === 识别人脸 ===

# 从图片识别
python -m camera_ai face identify -i photo.jpg
# 输出:
# ════════════════════════════
#   CameraAI 人脸识别结果
# ════════════════════════════
#   时间: 15:30:00
#   图片: photo.jpg
#   检测到: 1 张人脸
# ────────────────────────────
#   [1] ✓ 匹配成功 | 张三 | 置信度: 97.5%
# ════════════════════════════

# 更严格匹配（减少误判）
python -m camera_ai face identify -i photo.jpg -t 0.5

# JSON输出（程序化处理）
python -m camera_ai face identify -i photo.jpg -f json

# 识别后释放内存（8GB设备推荐）
python -m camera_ai face identify -i photo.jpg --release


# === 删除已注册人脸 ===
# 直接编辑 ~/.camera-ai/faces.json
```

---

## 项目结构

```
camera-ai/
├── SKILL.md                        # 本文件（技能描述）
├── requirements.txt                 # 依赖清单
├── setup.py                        # Python 包安装配置
├── config.default.json             # 默认配置
│
└── camera_ai/                      # Python 包
    ├── __init__.py
    ├── __main__.py                 # 主入口
    │
    ├── core/
    │   ├── __init__.py
    │   ├── types.py                # 类型定义
    │   ├── config.py               # 配置管理
    │   ├── camera.py               # 摄像头操作 (OpenCV)
    │   ├── minimax.py              # MiniMax API 客户端
    │   ├── result.py               # 结果格式化
    │   │
    │   └── face/                   # 人脸识别模块
    │       ├── __init__.py
    │       ├── models.py            # 数据模型
    │       ├── engine.py            # 引擎封装（按需加载）
    │       ├── registry.py          # 人脸库管理
    │       └── opencv_fallback.py   # OpenCV 备用引擎
    │
    └── commands/
        ├── analyze.py
        ├── monitor.py
        ├── face_register.py        # 注册命令
        └── face_identify.py        # 识别命令
```

---

## 人脸识别详细说明

### 工作原理

```
[注册阶段]                              [识别阶段]

拍照片 → 提取特征向量 → 存入JSON           拍照片 → 检测人脸 → 提取特征 → 与库比对 → 返回姓名

数据存储: ~/.camera-ai/faces.json          匹配算法: 余弦相似度 + 阈值判断
文件大小: 几KB（非常轻量）                  内存占用: ~50MB峰值（用完即释放）
```

### 人脸检测引擎

本 SKILL 使用 **OpenCV 内置的人脸检测**，无需安装 dlib/face_recognition：

| 引擎模式 | 说明 | 优点 |
|---------|------|------|
| **haar** | Haar 级联分类器 | 快速，资源占用低 |
| **dnn** | DNN 深度学习模型 | 更准确（需要 OpenCV 4.2+） |

### 特点

| 特性 | 说明 |
|------|------|
| **纯本地** | 无网络需求，隐私安全 |
| **轻量级** | JSON 存储，无数据库依赖 |
| **内存友好** | 按需加载，自动释放 |
| **跨平台** | Windows/Linux/Mac 均可运行 |

### 配置参数

在 `~/.camera-ai/faces.json` 中可调整：

```json
{
  "settings": {
    "tolerance": 0.6,
    "engine": "haar"
  }
}
```

| 参数 | 说明 | 范围 |
|------|------|------|
| tolerance | 匹配阈值 | 0.4（宽松）~ 0.7（严格） |
| engine | 人脸检测引擎 | "haar"（默认）或 "dnn" |

### 推荐使用建议

1. **每人注册 2-3 张不同角度的照片**
2. **光线充足、正对镜头的照片效果最好**
3. **匹配阈值建议 0.55-0.6（平衡准确率和误判率）**

---

## 给智能体的集成指引

### 检查清单

当智能体加载此 SKILL 时：

```python
# 伪代码示例
def load_camera_ai_skill():

    # 1. 检查基础依赖
    check_dependencies(['cv2', 'numpy', 'camera_ai'])

    # 2. 检查 MiniMax CLI（用于 AI 分析）
    check_mm_cli_auth()

    # 3. 加载完成
    return SkillLoaded(
        name="camera-ai",
        triggers=["看这个", "拍个照", "这是谁", "人脸识别"],
        commands=["capture", "analyze", "monitor", "face register", "face identify"]
    )
```

### 典型对话流程

```
用户: "帮我看看门口是谁？"

智能体内部处理:
  1. 识别触发词 "看看...是谁?" → camera-ai skill
  2. 判断需要: capture + face identify
  3. 检查依赖: ✓ cv2 ✓ numpy ✓ camera_ai
  4. 执行:
     - capture → captures/latest.jpg
     - face identify → matches=[{name:"快递员", confidence:0.89}]
  5. 组织回复:
     "我看到门口有一个不认识的人，
      可能是快递员（置信度89%）。他穿着蓝色制服，
      手里拿着一个包裹。"
```

---

## 安装故障排除

### 问题：opencv-python 安装失败

```
[WARN] OpenCV installation failed
```

**解决方案**：
1. 确保已安装 Visual Studio Build Tools（C++ 编译环境）
2. 或使用预编译版本：`pip install opencv-python-headless`

### 问题：camera_ai 包安装失败

```
[WARN] Could not install in editable mode
```

**解决方案**：
1. 确保在 SKILL 目录下运行安装脚本
2. 手动运行：`pip install -e "C:\path\to\camera-ai"`

### 问题：摄像头无法打开

```
[ERROR] Camera index out of range
```

**解决方案**：
1. 检查摄像头是否被其他程序占用
2. 尝试其他摄像头索引：`python -m camera_ai capture -c 1`
3. 检查设备管理器中摄像头驱动是否正常

---

## 许可证

MIT License

## 相关链接

- [OpenCV Python](https://docs.opencv.org/4.x/d9/df8/tutorial_root.html)
- [MiniMax CLI](https://github.com/MiniMax-AI/cli)