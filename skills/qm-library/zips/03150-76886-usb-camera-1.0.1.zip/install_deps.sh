#!/bin/bash
# ============================================================
# CameraAI Skill - 依赖安装脚本 (Linux/Mac)
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "============================================================"
echo "  CameraAI Skill - Dependency Installer (Linux/Mac)"
echo "  Location: $SCRIPT_DIR"
echo "============================================================"
echo ""

PYTHON_CMD="python3"
if ! command -v $PYTHON_CMD &> /dev/null; then
    PYTHON_CMD="python"
fi

if ! command -v $PYTHON_CMD &> /dev/null; then
    echo -e "${RED}[ERROR] Python not found. Please install Python 3.8+${NC}"
    exit 1
fi

echo "[1/6] Checking Python..."
$PYTHON_CMD --version

echo ""
echo "[2/6] Upgrading pip..."
$PYTHON_CMD -m pip install --upgrade pip --quiet 2>/dev/null || echo -e "${YELLOW}    [WARN] pip upgrade failed (continuing...)${NC}"

echo ""
echo "[3/6] Installing core dependencies (opencv-python, numpy)..."
if $PYTHON_CMD -m pip install opencv-python numpy --quiet 2>/dev/null; then
    echo -e "       ${GREEN}[OK] opencv-python and numpy installed${NC}"
else
    echo -e "${RED}[ERROR] OpenCV installation failed${NC}"
    exit 1
fi

echo ""
echo "[4/6] Installing camera_ai package..."
echo "      This enables: python -m camera_ai"

if $PYTHON_CMD -m pip install -e . --quiet 2>/dev/null; then
    echo -e "       ${GREEN}[OK] camera_ai package installed${NC}"
else
    if $PYTHON_CMD -m pip install -e "$SCRIPT_DIR" --quiet 2>/dev/null; then
        echo -e "       ${GREEN}[OK] camera_ai package installed${NC}"
    else
        echo -e "${RED}[ERROR] camera_ai package installation failed${NC}"
        exit 1
    fi
fi

echo ""
echo "[5/6] Verifying dependencies..."
echo ""

ALL_OK=true

if $PYTHON_CMD -c "import cv2; print('OK:OpenCV:'+cv2.__version__)" 2>/dev/null; then
    CV_VERSION=$($PYTHON_CMD -c "import cv2; print(cv2.__version__)")
    echo -e "  ${GREEN}[OK] OpenCV: $CV_VERSION${NC}"
else
    echo -e "  ${RED}[X] OpenCV: FAILED - Required!${NC}"
    ALL_OK=false
fi

if $PYTHON_CMD -c "import numpy; print('OK:NumPy')" 2>/dev/null; then
    echo -e "  ${GREEN}[OK] NumPy: installed${NC}"
else
    echo -e "  ${RED}[X] NumPy: FAILED - Required!${NC}"
    ALL_OK=false
fi

if $PYTHON_CMD -c "import camera_ai" 2>/dev/null; then
    echo -e "  ${GREEN}[OK] camera_ai: installed${NC}"
else
    echo -e "  ${RED}[X] camera_ai: FAILED${NC}"
    ALL_OK=false
fi

if [ "$ALL_OK" = false ]; then
    echo ""
    echo "============================================================"
    echo -e "${RED}[ERROR] Dependencies failed to install!${NC}"
    echo "============================================================"
    exit 1
fi

echo ""
echo "[6/6] MiniMax CLI check (optional)..."
if command -v npx &> /dev/null; then
    if npx mmx-cli auth status >/dev/null 2>&1; then
        echo -e "       ${GREEN}[OK] MiniMax CLI: authenticated${NC}"
    else
        echo -e "       ${YELLOW}[!!] MiniMax CLI: not authenticated${NC}"
        echo -e "           Run: npx mmx-cli auth login"
    fi
else
    echo -e "       ${YELLOW}[INFO] MiniMax CLI: not found (optional for AI analysis)${NC}"
fi

echo ""
echo "============================================================"
echo "  Installation Complete!"
echo "============================================================"
echo ""
echo "  Installed:"
echo "    - opencv-python (camera capture)"
echo "    - numpy (computation)"
echo "    - camera_ai (this package)"
echo ""
echo "  Next step:"
echo "    python -m camera_ai status"
echo ""
echo "============================================================"