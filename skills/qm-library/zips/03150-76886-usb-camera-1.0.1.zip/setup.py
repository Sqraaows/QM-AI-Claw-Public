"""
CameraAI Skill - Setup Configuration
"""

from setuptools import setup, find_packages

setup(
    name="camera_ai",
    version="1.0.0",
    description="Camera AI vision recognition tool for OpenClaw",
    long_description=open("SKILL.md", "r", encoding="utf-8").read() if __import__("os").path.exists("SKILL.md") else "",
    long_description_content_type="text/markdown",
    author="OpenClaw Team",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "opencv-python>=4.0.0",
        "numpy>=1.20.0",
    ],
    extras_require={
        "face": [
            "face_recognition>=1.3.0",
        ],
        "dev": [],
    },
    entry_points={
        "console_scripts": [
            "camera-ai=camera_ai.__main__:main",
        ],
    },
    package_data={
        "camera_ai": [
            "core/face/*.json",
            "*.json",
        ],
    },
    include_package_data=True,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)