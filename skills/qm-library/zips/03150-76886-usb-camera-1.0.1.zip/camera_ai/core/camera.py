"""
CameraAI - 摄像头捕获模块
基于 OpenCV 实现跨平台摄像头访问
"""

import cv2
import sys
import os
from datetime import datetime
from pathlib import Path
from typing import Tuple, Optional, List

from .types import CaptureOptions


def ensure_directory(dir_path: str) -> None:
    """确保目录存在"""
    Path(dir_path).mkdir(parents=True, exist_ok=True)


def generate_timestamp() -> str:
    """生成时间戳字符串"""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def generate_output_path(
    base_dir: str,
    prefix: str = "capture",
    ext: str = "jpg"
) -> str:
    """生成输出文件路径"""
    ensure_directory(base_dir)
    timestamp = generate_timestamp()
    return os.path.join(base_dir, f"{prefix}_{timestamp}.{ext}")


def enhance_image_auto(frame):
    """自动调整图像 - 改善曝光、对比度和白平衡

    Args:
        frame: 输入图像帧

    Returns:
        调整后的图像
    """
    import numpy as np

    # 白平衡校正 (Gray World 算法)
    result = frame.astype(np.float32)
    avg_b = np.mean(result[:, :, 0])
    avg_g = np.mean(result[:, :, 1])
    avg_r = np.mean(result[:, :, 2])
    avg_gray = (avg_b + avg_g + avg_r) / 3

    result[:, :, 0] = np.clip(result[:, :, 0] * (avg_gray / avg_b), 0, 255)
    result[:, :, 1] = np.clip(result[:, :, 1] * (avg_gray / avg_g), 0, 255)
    result[:, :, 2] = np.clip(result[:, :, 2] * (avg_gray / avg_r), 0, 255)
    frame = result.astype(np.uint8)

    # 转换到 LAB 色彩空间进行亮度/对比度调整
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    # 限制 L 通道的 CLAHE (对比度受限自适应直方图均衡化)
    clahe = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8))
    l = clahe.apply(l)

    # 合并通道
    lab = cv2.merge([l, a, b])
    frame = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    return frame


def enhance_image_exposure(frame, exposure_factor=0.8, saturation_factor=1.1):
    """手动调整图像曝光和饱和度

    Args:
        frame: 输入图像帧
        exposure_factor: 曝光因子 (0.5-2.0, <1 变暗, >1 变亮)
        saturation_factor: 饱和度因子 (0.0-2.0)

    Returns:
        调整后的图像
    """
    import numpy as np

    # 调整曝光
    frame = cv2.convertScaleAbs(frame, alpha=exposure_factor, beta=0)

    # 调整饱和度
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 1] = hsv[:, :, 1] * saturation_factor
    hsv[:, :, 1] = np.clip(hsv[:, :, 1], 0, 255)
    frame = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

    return frame


def capture_and_save_with_enhancement(
    camera_manager,
    output_path: str,
    format_type: str = "jpeg",
    quality: int = 85,
    auto_adjust: bool = False,
    exposure_factor: float = 1.0,
    saturation_factor: float = 1.0
) -> dict:
    """捕获一帧并保存（带图像增强）

    Args:
        camera_manager: CameraManager 实例
        output_path: 输出文件路径
        format_type: 图片格式 ('jpeg' 或 'png')
        quality: JPEG 质量 (0-100)
        auto_adjust: 是否自动调整图像
        exposure_factor: 曝光因子 (仅在 auto_adjust=False 时生效)
        saturation_factor: 饱和度因子 (仅在 auto_adjust=False 时生效)

    Returns:
        包含结果的字典
    """
    result = camera_manager.capture_frame()

    if result is None or not result[0]:
        return {
            "success": False,
            "error": "无法捕获图像"
        }

    frame = result[1]

    # 应用图像增强
    if auto_adjust:
        frame = enhance_image_auto(frame)
    elif exposure_factor != 1.0 or saturation_factor != 1.0:
        frame = enhance_image_exposure(frame, exposure_factor, saturation_factor)

    # 设置编码参数
    if format_type.lower() == "png":
        params = []
    else:
        params = [cv2.IMWRITE_JPEG_QUALITY, quality]

    # 保存图像
    success = cv2.imwrite(output_path, frame, params)

    if not success:
        return {
            "success": False,
            "error": f"无法保存图像到 {output_path}"
        }

    # 获取实际分辨率
    actual_width = int(camera_manager.capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    actual_height = int(camera_manager.capture.get(cv2.CAP_PROP_FRAME_HEIGHT))

    return {
        "success": True,
        "output_path": output_path,
        "width": actual_width,
        "height": actual_height,
        "format": format_type,
        "enhanced": auto_adjust or (exposure_factor != 1.0 or saturation_factor != 1.0)
    }


class CameraManager:
    """摄像头管理器"""

    def __init__(self, device_id: int = 0):
        self.device_id = device_id
        self.capture: Optional[cv2.VideoCapture] = None
        self.is_opened = False

    def open(self, width: int = 1280, height: int = 720) -> bool:
        """打开摄像头

        Args:
            width: 分辨率宽度
            height: 分辨率高度

        Returns:
            是否成功打开
        """
        self.capture = cv2.VideoCapture(self.device_id)

        if not self.capture.isOpened():
            print(f"[错误] 无法打开摄像头设备 {self.device_id}")
            return False

        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

        self.is_opened = True
        print(f"[信息] 摄像头已打开 (设备ID: {self.device_id})")
        return True

    def set_brightness(self, value: float) -> bool:
        """设置亮度 (0.0 - 1.0)"""
        if self.capture is None:
            return False
        result = self.capture.set(cv2.CAP_PROP_BRIGHTNESS, value)
        return result

    def set_contrast(self, value: float) -> bool:
        """设置对比度 (0.0 - 1.0)"""
        if self.capture is None:
            return False
        result = self.capture.set(cv2.CAP_PROP_CONTRAST, value)
        return result

    def set_exposure(self, value: float) -> bool:
        """设置曝光 (-1.0 - 1.0)，-1 表示自动曝光"""
        if self.capture is None:
            return False
        result = self.capture.set(cv2.CAP_PROP_EXPOSURE, value)
        return result

    def set_gain(self, value: float) -> bool:
        """设置增益 (0.0 - 1.0)"""
        if self.capture is None:
            return False
        result = self.capture.set(cv2.CAP_PROP_GAIN, value)
        return result

    def apply_capture_options(self, options) -> None:
        """应用 CaptureOptions 中的摄像头参数"""
        if options.brightness is not None:
            self.set_brightness(options.brightness)
        if options.contrast is not None:
            self.set_contrast(options.contrast)
        if options.exposure is not None:
            self.set_exposure(options.exposure)
        if options.gain is not None:
            self.set_gain(options.gain)

    def capture_frame(self) -> Optional[Tuple[bool, any]]:
        """捕获一帧图像
        
        Returns:
            (成功标志, 帧数据) 元组
        """
        if not self.is_opened or self.capture is None:
            print("[错误] 摄像头未打开")
            return None
        
        ret, frame = self.capture.read()
        return (ret, frame)

    def capture_and_save(
        self,
        output_path: str,
        format_type: str = "jpeg",
        quality: int = 85
    ) -> dict:
        """捕获一帧并保存到文件
        
        Args:
            output_path: 输出文件路径
            format_type: 图片格式 ('jpeg' 或 'png')
            quality: JPEG 质量 (0-100)
            
        Returns:
            包含结果的字典
        """
        result = self.capture_frame()
        
        if result is None or not result[0]:
            return {
                "success": False,
                "error": "无法捕获图像"
            }
        
        frame = result[1]
        
        # 设置编码参数
        if format_type.lower() == "png":
            params = []
        else:
            params = [cv2.IMWRITE_JPEG_QUALITY, quality]
        
        # 保存图像
        success = cv2.imwrite(output_path, frame, params)
        
        if not success:
            return {
                "success": False,
                "error": f"无法保存图像到 {output_path}"
            }
        
        # 获取实际分辨率
        actual_width = int(self.capture.get(cv2.CAP_PROP_FRAME_WIDTH))
        actual_height = int(self.capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        return {
            "success": True,
            "output_path": output_path,
            "width": actual_width,
            "height": actual_height,
            "format": format_type
        }

    def close(self) -> None:
        """关闭摄像头"""
        if self.capture is not None:
            self.capture.release()
            self.is_opened = False
            print("[信息] 摄像头已关闭")

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False


def capture_image(options: CaptureOptions) -> dict:
    """便捷函数：捕获单张图片（支持图像增强）

    Args:
        options: 捕获选项

    Returns:
        结果字典
    """
    # 确定输出路径
    if options.output:
        output_path = options.output
    else:
        ext = "png" if options.format == "png" else "jpg"
        output_path = generate_output_path(options.save_dir, "capture", ext)

    print(f"[信息] 正在从摄像头 {options.device} 捕获图像...")
    print(f"[调试] 分辨率: {options.width}x{options.height}, 格式: {options.format}, 质量: {options.quality}")
    if options.auto_adjust:
        print(f"[调试] 图像增强: 自动调整")

    with CameraManager(options.device) as camera:
        if not camera.open(options.width, options.height):
            return {"success": False, "error": f"无法打开摄像头设备 {options.device}"}

        camera.apply_capture_options(options)

        result = capture_and_save_with_enhancement(
            camera,
            output_path,
            options.format,
            options.quality,
            auto_adjust=options.auto_adjust
        )

    if result["success"]:
        print(f"[信息] 图像捕获成功: {result['output_path']}")
        print(f"[调试] 实际分辨率: {result['width']}x{result['height']}")
        if result.get("enhanced"):
            print(f"[调试] 图像已增强处理")

        if options.show_preview:
            show_preview(output_path)

    return result


def show_preview(image_path: str, duration_ms: int = 3000) -> None:
    """显示图像预览窗口
    
    Args:
        image_path: 图像路径
        duration_ms: 显示时长（毫秒）
    """
    try:
        img = cv2.imread(image_path)
        if img is None:
            print(f"[警告] 无法读取预览图像: {image_path}")
            return
        
        cv2.imshow('Camera Preview', img)
        cv2.waitKey(duration_ms)
        cv2.destroyAllWindows()
    except Exception as e:
        print(f"[警告] 预览窗口显示失败: {e}")


def list_cameras() -> List[int]:
    """列出可用的摄像头设备
    
    Returns:
        可用设备ID列表
    """
    available = []
    
    for i in range(10):  # 检查前10个设备
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            available.append(i)
            cap.release()
    
    return available


def check_camera_available(device_id: int = 0) -> bool:
    """检查指定摄像头是否可用
    
    Args:
        device_id: 设备ID
        
        Returns:
            是否可用
    """
    cap = cv2.VideoCapture(device_id)
    available = cap.isOpened()
    cap.release()
    return available
