"""
CameraAI - 摄像头AI识别工具
核心类型定义
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Literal
from enum import Enum


class AnalysisMode(str, Enum):
    """分析模式枚举"""
    GENERAL = "general"
    FACE = "face"
    PERSON = "person"
    OBJECT = "object"
    SCENE = "scene"
    OCR = "ocr"
    SAFETY = "safety"
    CUSTOM = "custom"


@dataclass
class PersonInfo:
    """人物信息"""
    position: Optional[str] = None
    gender: Optional[str] = None
    age_range: Optional[str] = None
    clothing: Optional[str] = None
    pose: Optional[str] = None
    features: Optional[str] = None


@dataclass
class SceneInfo:
    """场景信息"""
    type: Optional[Literal["indoor", "outdoor", "unknown"]] = None
    environment: Optional[str] = None
    description: Optional[str] = None
    time_guess: Optional[str] = None


@dataclass
class AnalysisResultData:
    """分析结果数据"""
    persons: List[PersonInfo] = field(default_factory=list)
    objects: List[str] = field(default_factory=list)
    scene: Optional[SceneInfo] = None
    text_content: List[str] = field(default_factory=list)
    safety_alerts: List[str] = field(default_factory=list)
    description: Optional[str] = None


@dataclass
class AnalysisResult:
    """分析结果"""
    success: bool
    timestamp: str
    image_file: str
    analysis_mode: str
    result: AnalysisResultData
    raw_text: str
    token_usage: Optional[int] = None
    error: Optional[str] = None


@dataclass
class CaptureOptions:
    """捕获选项"""
    output: Optional[str] = None
    device: int = 0
    width: int = 1280
    height: int = 720
    format: str = "jpeg"
    quality: int = 85
    show_preview: bool = False
    save_dir: str = "./captures"
    brightness: Optional[float] = None
    contrast: Optional[float] = None
    exposure: Optional[float] = None
    gain: Optional[float] = None
    auto_adjust: bool = False


@dataclass
class AnalyzeOptions:
    """分析选项"""
    image: str
    prompt: Optional[str] = None
    mode: AnalysisMode = AnalysisMode.GENERAL
    output_format: Literal["text", "json"] = "text"
    save_result: Optional[str] = None
    verbose: bool = False


@dataclass
class MonitorOptions:
    """监控选项"""
    interval: int = 5
    prompt: Optional[str] = None
    mode: AnalysisMode = AnalysisMode.GENERAL
    output_format: Literal["text", "json"] = "text"
    max_count: int = 0
    save_images: bool = False
    save_dir: str = "./monitor_snapshots"
    on_detect: Optional[str] = None
    threshold: int = 30
    quiet: bool = False
    log_file: Optional[str] = None
