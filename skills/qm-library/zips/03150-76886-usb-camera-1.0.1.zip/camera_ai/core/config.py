"""
CameraAI - 配置管理模块
"""

import json
import os
from pathlib import Path
from typing import Any, Optional

# 默认配置
DEFAULT_CONFIG = {
    "camera": {
        "device_id": 0,
        "width": 1280,
        "height": 720,
        "format": "jpeg",
        "quality": 85,
        "save_dir": "./captures"
    },
    "analysis": {
        "default_mode": "general",
        "default_prompt": "",
        "output_format": "text"
    },
    "monitor": {
        "interval": 5,
        "threshold": 30,
        "max_count": 0,
        "save_images": False,
        "save_dir": "./monitor_snapshots"
    },
    "output": {
        "log_level": "info",
        "show_timestamp": True
    }
}


class ConfigManager:
    """配置管理器"""

    def __init__(self, config_path: Optional[str] = None):
        # 确定配置文件路径
        if config_path:
            self.config_path = Path(config_path)
        else:
            config_dir = os.environ.get(
                "CAMERA_AI_CONFIG_PATH",
                os.path.join(Path.home(), ".camera-ai")
            )
            self.config_path = Path(config_dir) / "config.json"

        self.config = self._load_config()

    def _load_config(self) -> dict:
        """加载配置文件，如果不存在则使用默认配置"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                return self._merge_configs(DEFAULT_CONFIG, user_config)
            except (json.JSONDecodeError, IOError) as e:
                print(f"[警告] 配置文件加载失败: {e}，使用默认配置")
        
        return {**DEFAULT_CONFIG}

    @staticmethod
    def _merge_configs(default_cfg: dict, user_cfg: dict) -> dict:
        """递归合并配置（用户配置覆盖默认配置）"""
        result = default_cfg.copy()
        for key, value in user_cfg.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = ConfigManager._merge_configs(result[key], value)
            else:
                result[key] = value
        return result

    def get(self, section: str, key: Optional[str] = None) -> Any:
        """获取配置值
        
        Args:
            section: 配置段名称 (如 'camera', 'analysis')
            key: 配置键名 (可选，不传则返回整个section)
            
        Returns:
            配置值
        """
        if section not in self.config:
            raise KeyError(f"配置段 '{section}' 不存在")
        
        if key is None:
            return self.config[section]
        
        return self.config[section].get(key)

    def set(self, key_path: str, value: Any) -> None:
        """设置配置值
        
        Args:
            key_path: 配置路径，用 '.' 分隔 (如 'camera.width')
            value: 要设置的值
        """
        keys = key_path.split('.')
        config = self.config
        
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        config[keys[-1]] = value
        self.save()

    def get_all(self) -> dict:
        """获取完整配置"""
        return {**self.config}

    def save(self) -> None:
        """保存配置到文件"""
        # 确保目录存在
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)

    def reset(self) -> None:
        """重置为默认配置"""
        self.config = {**DEFAULT_CONFIG}
        self.save()

    def export_schema(self) -> str:
        """导出配置schema（JSON格式）"""
        return json.dumps(DEFAULT_CONFIG, indent=2, ensure_ascii=False)

    def show(self) -> None:
        """显示当前配置"""
        print("当前配置:")
        print(json.dumps(self.config, indent=2, ensure_ascii=False))
