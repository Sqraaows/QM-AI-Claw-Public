"""
CameraAI - 人脸注册库管理
使用 JSON 文件存储人脸数据，轻量无依赖
"""

import json
import os
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Dict, Any

from .models import FaceProfile, FaceMatchResult


class FaceRegistry:
    """
    人脸注册库管理器
    
    功能：
    - 注册新的人脸（保存特征向量）
    - 识别人脸身份（与库中数据比对）
    - 列出/删除已注册人脸
    - 数据持久化到 JSON 文件
    """
    
    DEFAULT_DB_NAME = "faces.json"
    DEFAULT_DB_DIR = "~/.camera-ai"
    
    def __init__(self, db_path: Optional[str] = None):
        """
        初始化人脸库
        
        Args:
            db_path: 数据库文件路径，默认 ~/.camera-ai/faces.json
        """
        if db_path:
            self.db_path = Path(db_path)
        else:
            db_dir = Path(self.DEFAULT_DB_DIR).expanduser()
            db_dir.mkdir(parents=True, exist_ok=True)
            self.db_path = db_dir / self.DEFAULT_DB_NAME
        
        self.faces: List[FaceProfile] = []
        self._load()
    
    def _load(self):
        """从文件加载数据"""
        if not self.db_path.exists():
            return
        
        try:
            with open(self.db_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if 'faces' in data:
                self.faces = [FaceProfile.from_dict(p) for p in data['faces']]
                
        except (json.JSONDecodeError, KeyError) as e:
            print(f"[警告] 加载人脸库失败: {e}")
    
    def _save(self):
        """保存数据到文件"""
        # 确保目录存在
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        data = {
            'version': '1.0',
            'updated_at': datetime.now().isoformat(),
            'face_count': len(self.faces),
            'faces': [f.to_dict() for f in self.faces]
        }
        
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    @property
    def count(self) -> int:
        return len(self.faces)
    
    @property
    def names(self) -> List[str]:
        return list(set(f.name for f in self.faces))
    
    @property
    def db_path_str(self) -> str:
        return str(self.db_path)
    
    def register(
        self,
        name: str,
        embedding: List[float],
        source_image: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ) -> FaceProfile:
        """
        注册新人脸
        
        Args:
            name: 姓名/标识名
            embedding: 128维特征向量
            source_image: 来源图片路径
            metadata: 额外信息
            
        Returns:
            创建的 FaceProfile 对象
        """
        face_id = f"{name}_{len(self.faces)+1:03d}"
        
        profile = FaceProfile(
            id=face_id,
            name=name,
            embedding=embedding,
            source_image=source_image or "",
            registered_at=datetime.now().isoformat(),
            metadata=metadata or {}
        )
        
        self.faces.append(profile)
        self._save()
        
        print(f"[信息] 已注册人脸: {name} (ID: {face_id})")
        return profile
    
    def identify(
        self,
        unknown_embedding: List[float],
        engine=None,
        tolerance: float = 0.6
    ) -> FaceMatchResult:
        """
        识别未知人脸身份
        
        Args:
            unknown_embedding: 待识别人脸的特征向量
            engine: FaceEngine 实例（可选，用于精确比对）
            tolerance: 匹配阈值
            
        Returns:
            FaceMatchResult
        """
        if not self.faces:
            return FaceMatchResult(matched=False, similarity=0.0)
        
        best_match = None
        best_similarity = 0.0
        
        for face in self.faces:
            if engine:
                result = engine.compare_faces(face.embedding, unknown_embedding)
                if result.matched and result.similarity > best_similarity:
                    best_match = face
                    best_similarity = result.similarity
            else:
                # 简单余弦相似度计算
                sim = self._cosine_similarity(face.embedding, unknown_embedding)
                if sim > best_similarity and sim > (1 - tolerance):
                    best_match = face
                    best_similarity = sim
        
        if best_match:
            return FaceMatchResult(
                matched=True,
                similarity=best_similarity,
                name=best_match.name,
                face_id=best_match.id
            )
        
        return FaceMatchResult(matched=False, similarity=best_similarity)
    
    def identify_from_image(
        self,
        image_path: str,
        engine=None,
        tolerance: float = 0.6
    ):
        """
        从图片直接识别人脸（一步完成）
        
        Args:
            image_path: 图片路径
            engine: FaceEngine 实例
            tolerance: 匹配阈值
            
        Returns:
            FaceIdentifyResult
        """
        from .models import FaceIdentifyResult
        from datetime import datetime
        
        if not engine:
            from .engine import get_face_engine
            engine = get_face_engine()
        
        # 构建已知人脸字典
        known_faces = {f.name: f.embedding for f in self.faces}
        
        if not known_faces:
            return FaceIdentifyResult(
                success=True,
                timestamp=datetime.now().isoformat(),
                image_file=image_path,
                detected_faces=0,
                matches=[],
                unknown_count=0,
                raw_text="人脸库为空，请先注册人脸"
            )
        
        # 调用引擎识别
        # 根据引擎类型选择正确的识别方法
        if hasattr(engine, 'identify_from_image'):
            # dlib 模式：引擎有自己的识别方法
            return engine.identify_from_image(image_path, known_faces)
        else:
            # OpenCV 模式：使用简化的本地实现
            return self._opencv_identify(image_path, engine, tolerance)
    
    def _opencv_identify(self, image_path: str, engine, tolerance: float = 0.6):
        """OpenCV 模式的识别实现"""
        from .models import FaceIdentifyResult, FaceMatchResult
        from datetime import datetime
        
        detection = engine.detect_faces(image_path)
        
        if not detection.success or detection.face_count == 0:
            return FaceIdentifyResult(
                success=True,
                timestamp=datetime.now().isoformat(),
                image_file=image_path,
                detected_faces=0,
                matches=[],
                unknown_count=0,
                raw_text='No face detected'
            )
        
        matches = []
        unknown_count = 0
        
        for face_info in detection.faces:
            embedding = engine.generate_simple_embedding(image_path, face_info['bbox'])
            
            if not embedding:
                unknown_count += 1
                continue
            
            # 与所有已注册人脸比对
            best_match = None
            best_score = 0.0
            
            for face in self.faces:
                # face 可能是 FaceProfile 对象或字典
                emb = face.embedding if hasattr(face, 'embedding') else face['embedding']
                sim = engine.compare_faces_simple(emb, embedding)
                if sim > best_score:
                    best_score = sim
                    best_match = face
            
            if best_match and best_score > (1 - tolerance):
                fname = best_match.name if hasattr(best_match, 'name') else best_match['name']
                fid = best_match.id if hasattr(best_match, 'id') else best_match['id']
                matches.append(FaceMatchResult(
                    matched=True,
                    similarity=best_score,
                    name=fname,
                    face_id=fid
                ))
            else:
                unknown_count += 1
        
        text_parts = []
        for m in matches:
            if m.matched:
                text_parts.append(f"{m.name} ({m.similarity*100:.1f}%)")
        if unknown_count > 0:
            text_parts.append(f"unknown: {unknown_count}")
        
        return FaceIdentifyResult(
            success=True,
            timestamp=datetime.now().isoformat(),
            image_file=image_path,
            detected_faces=detection.face_count,
            matches=matches,
            unknown_count=unknown_count,
            raw_text='; '.join(text_parts) if text_parts else 'No matches'
        )
    
    def remove(self, face_id: str = None, name: str = None) -> bool:
        """
        删除已注册人脸
        
        Args:
            face_id: 按ID删除
            name: 按姓名删除（删除所有同名）
            
        Returns:
            是否成功删除
        """
        original_count = len(self.faces)
        
        if face_id:
            self.faces = [f for f in self.faces if f.id != face_id]
        elif name:
            self.faces = [f for f in self.faces if f.name != name]
        else:
            return False
        
        deleted = original_count - len(self.faces) > 0
        
        if deleted:
            self._save()
        
        return deleted
    
    def list_all(self, show_details: bool = False) -> List[Dict]:
        """
        列出所有已注册人脸
        
        Args:
            show_details: 是否显示详细信息
            
        Returns:
            人脸列表字典
        """
        result = []
        for i, face in enumerate(self.faces, 1):
            item = {
                'index': i,
                'id': face.id,
                'name': face.name,
                'registered': face.registered_at[:10]
            }
            
            if show_details:
                item['embedding_dim'] = len(face.embedding)
                item['source_image'] = face.source_image or "N/A"
                item['metadata'] = face.metadata
            
            result.append(item)
        
        return result
    
    def get_by_name(self, name: str) -> Optional[FaceProfile]:
        """按姓名查找"""
        for f in self.faces:
            if f.name == name:
                return f
        return None
    
    def get_by_id(self, face_id: str) -> Optional[FaceProfile]:
        """按ID查找"""
        for f in self.faces:
            if f.id == face_id:
                return f
        return None
    
    def clear(self):
        """清空所有人脸数据"""
        count = len(self.faces)
        self.faces = []
        self._save()
        print(f"[信息] 已清空 {count} 条人脸记录")
    
    def export_to_json(self, output_path: str = None) -> str:
        """导出人脸库为 JSON"""
        if not output_path:
            output_path = str(self.db_path).replace('.json', '_export.json')
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({
                'exported_at': datetime.now().isoformat(),
                'faces': [f.to_dict() for f in self.faces]
            }, f, indent=2, ensure_ascii=False)
        
        return output_path
    
    def import_from_json(self, input_path: str) -> int:
        """从 JSON 导入人脸数据"""
        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        imported = 0
        if 'faces' in data:
            for face_data in data['faces']:
                profile = FaceProfile.from_dict(face_data)
                # 确保ID唯一
                existing_ids = {f.id for f in self.faces}
                if profile.id in existing_ids:
                    profile.id = f"{profile.name}_{len(self.faces)+1:03d}"
                
                self.faces.append(profile)
                imported += 1
        
        if imported > 0:
            self._save()
        
        return imported
    
    @staticmethod
    def _cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
        """计算余弦相似度"""
        import math
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = math.sqrt(sum(a * a for a in vec1))
        norm2 = math.sqrt(sum(b * b for b in vec2))
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    def __repr__(self) -> str:
        return f"FaceRegistry(count={self.count}, path='{self.db_path}')"
