"""
CameraAI - 人脸识别引擎封装
支持两种模式:
  1. face_recognition (dlib) - 高精度，需安装 dlib
  2. OpenCV 内置检测器 - 轻量级，无需额外依赖
自动回退: 当 dlib 不可用时使用 OpenCV 模式
"""

import sys
import os

# 全局引擎实例（懒加载）
_engine_instance = None
_use_opencv_fallback = False


def get_face_engine():
    """获取或创建人脸识别引擎（单例模式，自动选择最佳方案）"""
    global _engine_instance, _use_opencv_fallback
    
    if _engine_instance is None:
        # 尝试使用 face_recognition (dlib)
        try:
            import face_recognition
            _engine_instance = FaceEngine()
            _use_opencv_fallback = False
            print("[信息] 使用 face_recognition 引擎 (dlib)")
        except ImportError:
            # 回退到 OpenCV 模式
            from .opencv_fallback import OpenCVFaceEngine
            _engine_instance = OpenCVFaceEngine()
            _use_opencv_fallback = True
            print("[信息] 使用 OpenCV 内置引擎 (无 dlib 依赖)")
    
    return _engine_instance


def is_using_opencv() -> bool:
    """检查当前是否使用 OpenCV 回退模式"""
    return _use_opencv_fallback


def release_face_engine():
    """释放人脸识别引擎以节省内存"""
    global _engine_instance
    if _engine_instance is not None:
        if hasattr(_engine_instance, 'cleanup'):
            _engine_instance.cleanup()
        _engine_instance = None


class FaceEngine:
    """
    人脸识别引擎封装类
    
    特点：
    - 按需加载：首次调用时才初始化 dlib/face_recognition
    - 内存友好：可通过 release() 主动释放资源
    - 轻量配置：针对低配设备优化参数
    """
    
    _fr_module = None
    _np_module = None
    _initialized = False
    _model_loaded_time = None
    
    # 默认配置（适合低配设备）
    DEFAULT_TOLERANCE = 0.6      # 匹配阈值（越小越严格）
    DEFAULT_MODEL = "hog"         # 检测模型：hog(快) / cnn(准但慢)
    DEFAULT_UPSAMPLES = 1        # 上采样次数（提高小脸检测率）
    
    def __init__(self, tolerance=None, model=None):
        """
        初始化引擎（不立即加载模型）
        
        Args:
            tolerance: 匹配阈值 0-1，默认0.6
            model: 检测模型类型 "hog" 或 "cnn"
        """
        self.tolerance = tolerance or self.DEFAULT_TOLERANCE
        self.model = model or self.DEFAULT_MODEL
        self._fr = None
        
    def ensure_loaded(self):
        """确保模型已加载（内部使用）"""
        if not self._initialized:
            self._load_model()
        return self._initialized
    
    def _load_model(self):
        """加载 face_recognition 模型"""
        try:
            import face_recognition as fr
            import numpy as np
            
            self._fr = fr
            self._np = np
            self._initialized = True
            
            from datetime import datetime
            self._model_loaded_time = datetime.now().isoformat()
            
        except ImportError as e:
            raise ImportError(
                f"缺少依赖库: {e}\n"
                f"请运行安装脚本: python install_deps.py\n"
                f"或手动执行: pip install face_recognition dlib"
            )
    
    def cleanup(self):
        """释放资源"""
        self._fr = None
        self._np = None
        self._initialized = False
        self._model_loaded_time = None
        
        # 强制垃圾回收
        import gc
        gc.collect()
    
    @property
    def is_loaded(self) -> bool:
        """检查是否已加载"""
        return self._initialized and self._fr is not None
    
    def check_available(self) -> tuple:
        """
        检查依赖是否可用
        
        Returns:
            (是否可用, 错误信息)
        """
        missing = []
        
        try:
            import face_recognition
        except ImportError:
            missing.append("face_recognition")
        
        try:
            import dlib
        except ImportError:
            missing.append("dlib")
        
        if missing:
            return False, f"缺少依赖: {', '.join(missing)}\n请运行: python install_deps.py"
        
        return True, ""
    
    def detect_faces(self, image_path: str) -> 'FaceDetectionResult':
        """
        检测图片中的人脸
        
        Args:
            image_path: 图片文件路径
            
        Returns:
            FaceDetectionResult 包含人脸位置信息
        """
        from .models import FaceDetectionResult
        
        self.ensure_loaded()
        
        try:
            image = self._fr.load_image_file(image_path)
            
            # 检测人脸位置
            face_locations = self._fr.face_locations(
                image, 
                number_of_upsamples=self.DEFAULT_UPSAMPLES,
                model=self.model
            )
            
            faces_info = []
            for i, location in enumerate(face_locations):
                top, right, bottom, left = location
                faces_info.append({
                    'index': i,
                    'bbox': [left, top, right, bottom],
                    'width': right - left,
                    'height': bottom - top,
                    'center_x': (left + right) // 2,
                    'center_y': (top + bottom) // 2
                })
            
            return FaceDetectionResult(
                success=True,
                face_count=len(face_locations),
                faces=faces_info
            )
            
        except Exception as e:
            return FaceDetectionResult(
                success=False,
                face_count=0,
                error=str(e)
            )
    
    def extract_embedding(self, image_path: str, face_index: int = 0):
        """
        从图片中提取人脸特征向量（128维）
        
        Args:
            image_path: 图片路径
            face_index: 第几张脸（默认第一张）
            
        Returns:
            特征向量 list[float]，失败返回 None
        """
        self.ensure_loaded()
        
        try:
            image = self._fr.load_image_file(image_path)
            
            # 提取特征编码
            encodings = self._fr.face_encodings(
                image, 
                known_face_locations=self._fr.face_locations(
                    image, 
                    number_of_upsamples=self.DEFAULT_UPSAMPLES,
                    model=self.model
                ) if self.model == "cnn" else None
            )
            
            if len(encodings) > face_index:
                return encodings[face_index].tolist()
            
            return None
            
        except Exception as e:
            print(f"[错误] 提取特征失败: {e}")
            return None
    
    def compare_faces(self, known_embedding: list, unknown_embedding: list) -> 'FaceMatchResult':
        """
        比对两张人脸是否为同一人
        
        Args:
            known_embedding: 已知人脸的特征向量
            unknown_embedding: 待识别人脸的特征向量
            
        Returns:
            FaceMatchResult
        """
        from .models import FaceMatchResult
        
        self.ensure_loaded()
        
        try:
            known_array = self._np.array(known_embedding)
            unknown_array = self._np.array(unknown_embedding)
            
            # 计算距离并判断匹配
            results = self._fr.compare_faces([known_array], unknown_array, tolerance=self.tolerance)
            
            # 计算相似度（距离转相似度）
            distance = self._fr.face_distance([known_array], unknown_array)[0]
            similarity = float(1.0 - distance)
            
            return FaceMatchResult(
                matched=bool(results[0]),
                similarity=max(0.0, min(1.0, similarity))
            )
            
        except Exception as e:
            return FaceMatchResult(matched=False, similarity=0.0)
    
    def identify_from_image(self, image_path: str, known_faces: dict) -> 'FaceIdentifyResult':
        """
        从图片中识别人脸身份
        
        Args:
            image_path: 图片路径
            known_faces: {姓名: 特征向量} 字典
            
        Returns:
            FaceIdentifyResult 完整识别结果
        """
        from .models import FaceIdentifyResult, FaceMatchResult
        from datetime import datetime
        
        self.ensure_loaded()
        
        timestamp = datetime.now().isoformat()
        
        try:
            image = self._fr.load_image_file(image_path)
            
            # 检测人脸位置
            face_locations = self._fr.face_locations(
                image, 
                number_of_upsamples=self.DEFAULT_UPSAMPLES,
                model=self.model
            )
            
            if not face_locations:
                return FaceIdentifyResult(
                    success=True,
                    timestamp=timestamp,
                    image_file=image_path,
                    detected_faces=0,
                    matches=[],
                    unknown_count=0,
                    raw_text="未检测到人脸"
                )
            
            # 提取所有特征
            face_encodings = self._fr.face_encodings(face_locations)
            
            if not face_encodings or len(face_encodings) == 0:
                return FaceIdentifyResult(
                    success=True,
                    timestamp=timestamp,
                    image_file=image_path,
                    detected_faces=len(face_locations),
                    matches=[],
                    unknown_count=len(face_locations),
                    raw_text="无法提取人脸特征"
                )
            
            # 准备已知数据
            known_names = list(known_faces.keys())
            known_embeddings = [
                self._np.array(embedding) 
                for embedding in known_faces.values()
            ]
            
            matches = []
            unknown_count = 0
            
            for i, face_encoding in enumerate(face_encodings):
                # 比对所有已注册人脸
                results = self._fr.compare_faces(
                    known_embeddings, 
                    face_encoding, 
                    tolerance=self.tolerance
                )
                
                # 找最佳匹配
                best_match_idx = -1
                best_distance = float('inf')
                
                for j, is_match in enumerate(results):
                    distance = self._fr.face_distance([known_embeddings[j]], face_encoding)[0]
                    if distance < best_distance:
                        best_distance = distance
                        best_match_idx = j
                
                # 判断是否匹配成功
                if best_match_idx >= 0 and results[best_match_idx]:
                    similarity = float(1.0 - best_distance)
                    match_result = FaceMatchResult(
                        matched=True,
                        similarity=similarity,
                        name=known_names[best_match_idx]
                    )
                    matches.append(match_result)
                else:
                    unknown_count += 1
            
            # 生成文本描述
            text_parts = []
            if matches:
                for m in matches:
                    text_parts.append(f"识别到: {m.name} (置信度: {m.similarity*100:.1f}%)")
            if unknown_count > 0:
                text_parts.append(f"未知人员: {unknown_count}人")
            
            return FaceIdentifyResult(
                success=True,
                timestamp=timestamp,
                image_file=image_path,
                detected_faces=len(face_locations),
                matches=matches,
                unknown_count=unknown_count,
                raw_text="; ".join(text_parts) if text_parts else "未匹配到已注册人员"
            )
            
        except Exception as e:
            return FaceIdentifyResult(
                success=False,
                timestamp=timestamp,
                image_file=image_path,
                detected_faces=0,
                error=str(e)
            )
    
    def get_status(self) -> dict:
        """获取引擎状态"""
        return {
            'loaded': self.is_loaded,
            'tolerance': self.tolerance,
            'model': self.model,
            'loaded_time': self._model_loaded_time,
            'available_check': self.check_available()
        }
