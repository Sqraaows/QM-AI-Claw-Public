"""
CameraAI - OpenCV 人脸识别引擎 (无 dlib 依赖)
基于 OpenCV Haar/DNN 的轻量级人脸检测方案
适用于: 无法安装 dlib 的环境 (Windows/低配设备)
"""

import cv2
import os
import numpy as np
from typing import List, Optional, Dict, Any, Tuple

from .models import FaceProfile, FaceDetectionResult, FaceIdentifyResult, FaceMatchResult


class OpenCVFaceEngine:
    """
    基于 OpenCV 的轻量级人脸识别引擎
    
    特点:
    - 无需 dlib/face_recognition 依赖
    - 使用 Haar 级联分类器或 DNN 模型
    - 内存占用极低 (~50MB)
    - 适合低配设备
    """
    
    def __init__(self, model_type: str = "haar"):
        """
        初始化引擎
        
        Args:
            model_type: "haar" (快速) 或 "dnn" (准确)
        """
        self.model_type = model_type
        self.face_cascade = None
        self._loaded = False
        
        if model_type == "haar":
            self._load_haar_classifier()
        else:
            self._load_dnn_model()
    
    def _load_haar_classifier(self):
        """加载 Haar 级联分类器"""
        try:
            # 使用 OpenCV 内置的 Haar 分类器
            haar_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            
            if not os.path.exists(haar_path):
                # 如果内置路径不存在，尝试其他可能的位置
                import pkg_resources
                try:
                    haar_path = pkg_resources.resource_filename('cv2', 
                        'data/haarcascades/haarcascade_frontalface_default.xml')
                except:
                    pass
            
            if os.path.exists(haar_path):
                self.face_cascade = cv2.CascadeClassifier(haar_path)
                self._loaded = True
            else:
                print("[警告] 未找到 Haar 分类器文件")
                
        except Exception as e:
            print(f"[警告] 加载 Haar 分类器失败: {e}")
    
    def _load_dnn_model(self):
        """加载 DNN 模型 (可选，更准确但需要下载模型文件)"""
        # DNN 模型需要单独下载，这里暂不实现
        # 回退到 Haar
        self._load_haar_classifier()
    
    @property
    def is_loaded(self) -> bool:
        return self._loaded and self.face_cascade is not None
    
    def check_available(self) -> Tuple[bool, str]:
        """检查是否可用"""
        try:
            import cv2
            return True, ""
        except ImportError:
            return False, "OpenCV not installed"
    
    def detect_faces(self, image_path: str) -> FaceDetectionResult:
        """
        检测图片中的人脸位置
        
        Args:
            image_path: 图片路径
            
        Returns:
            FaceDetectionResult
        """
        from datetime import datetime
        
        if not self.is_loaded:
            return FaceDetectionResult(
                success=False,
                face_count=0,
                error="Face detector not loaded"
            )
        
        try:
            img = cv2.imread(image_path)
            if img is None:
                return FaceDetectionResult(
                    success=False,
                    face_count=0,
                    error=f"Cannot read image: {image_path}"
                )
            
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # 检测人脸 (放宽参数以提高检出率)
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.08,   # 更小的缩放步长
                minNeighbors=3,     # 更少的邻居要求
                minSize=(20, 20)    # 更小的最小尺寸
            )
            
            faces_info = []
            for i, (x, y, w, h) in enumerate(faces):
                faces_info.append({
                    'index': i,
                    'bbox': [int(x), int(y), int(x+w), int(y+h)],
                    'width': int(w),
                    'height': int(h),
                    'center_x': int(x + w//2),
                    'center_y': int(y + h//2),
                    'size': int(w * h)
                })
            
            return FaceDetectionResult(
                success=True,
                face_count=len(faces_info),
                faces=faces_info
            )
            
        except Exception as e:
            return FaceDetectionResult(
                success=False,
                face_count=0,
                error=str(e)
            )
    
    def extract_face_region(self, image_path: str, bbox: List[int]) -> Optional[np.ndarray]:
        """
        裁剪出人脸区域图像
        
        Args:
            image_path: 原图路径
            bbox: [x1, y1, x2, y2]
            
        Returns:
            人脸区域图像 (numpy array)，失败返回 None
        """
        try:
            img = cv2.imread(image_path)
            if img is None:
                return None
            
            x1, y1, x2, y2 = bbox
            # 扩展边界 20%
            w = x2 - x1
            h = y2 - y1
            padding_w = int(w * 0.2)
            padding_h = int(h * 0.2)
            
            x1 = max(0, x1 - padding_w)
            y1 = max(0, y1 - padding_h)
            x2 = min(img.shape[1], x2 + padding_w)
            y2 = min(img.shape[0], y2 + padding_h)
            
            face_img = img[y1:y2, x1:x2]
            return face_img
            
        except Exception:
            return None
    
    def generate_simple_embedding(self, image_path: str, bbox: List[int]) -> List[float]:
        """
        生成简化的特征向量 (用于比对)
        
        基于人脸区域的颜色直方图特征
        不如 dlib 的深度学习特征准确，但无需额外依赖
        
        Returns:
            特征向量 list[float]
        """
        face_img = self.extract_face_region(image_path, bbox)
        if face_img is None:
            return []
        
        try:
            # 转换为 HSV 颜色空间
            hsv = cv2.cvtColor(face_img, cv2.COLOR_BGR2HSV)
            
            # 计算颜色直方图
            hist_h = cv2.calcHist([hsv], [0], None, [50], [0, 180])
            hist_s = cv2.calcHist([hsv], [1], None, [60], [0, 256])
            hist_v = cv2.calcHist([hsv], [2], None, [64], [0, 256])
            
            # 归一化
            cv2.normalize(hist_h, hist_h)
            cv2.normalize(hist_s, hist_s)
            cv2.normalize(hist_v, hist_v)
            
            # 合并为特征向量
            feature = np.concatenate([
                hist_h.flatten(),
                hist_s.flatten(),
                hist_v.flatten()
            ])
            
            return feature.tolist()
            
        except Exception:
            return []
    
    def compare_faces_simple(self, embedding1: List[float], embedding2: List[float]) -> float:
        """
        比较两个简单特征的相似度
        
        Returns:
            相似度 0.0 - 1.0
        """
        if not embedding1 or not embedding2 or len(embedding1) != len(embedding2):
            return 0.0
        
        import math
        
        v1 = np.array(embedding1)
        v2 = np.array(embedding2)
        
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        similarity = float(np.dot(v1, v2) / (norm1 * norm2))
        return max(0.0, similarity)


class SimpleFaceRegistry:
    """
    简化版人脸注册库 (配合 OpenCV 引擎使用)
    存储人脸区域特征用于比对
    """
    
    DEFAULT_DB_NAME = "faces_opencv.json"
    DEFAULT_DB_DIR = "~/.camera-ai"
    
    def __init__(self, db_path: str = None):
        if db_path:
            self.db_path = db_path
        else:
            db_dir = os.path.expanduser(self.DEFAULT_DB_DIR)
            os.makedirs(db_dir, exist_ok=True)
            self.db_path = os.path.join(db_dir, self.DEFAULT_DB_NAME)
        
        self.faces: List[Dict[str, Any]] = []
        self._load()
    
    def _load(self):
        import json
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self.faces = data.get('faces', [])
            except:
                self.faces = []
    
    def _save(self):
        import json
        from datetime import datetime
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        data = {
            'version': '1.0-opencv',
            'updated_at': datetime.now().isoformat(),
            'face_count': len(self.faces),
            'faces': self.faces
        }
        
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    @property
    def count(self) -> int:
        return len(self.faces)
    
    @property
    def names(self) -> List[str]:
        return list(set(f['name'] for f in self.faces))
    
    def register(self, name: str, embedding: List[float], source_image: str = "",
                 bbox: List[int] = None, metadata: Dict = None) -> Dict:
        """注册人脸"""
        face_id = f"{name}_{len(self.faces)+1:03d}"
        
        face_data = {
            'id': face_id,
            'name': name,
            'embedding': embedding,
            'source_image': source_image,
            'bbox': bbox or [],
            'registered_at': __import__('datetime').datetime.now().isoformat(),
            'metadata': metadata or {},
            'engine': 'opencv-haar'
        }
        
        self.faces.append(face_data)
        self._save()
        
        print(f"[信息] 已注册人脸: {name} (ID: {face_id}) [OpenCV模式]")
        return face_data
    
    def identify(self, unknown_embedding: List[float], threshold: float = 0.65) -> Dict:
        """识别人脸身份"""
        engine = OpenCVFaceEngine()
        
        best_match = None
        best_score = 0.0
        
        for face in self.faces:
            sim = engine.compare_faces_simple(face['embedding'], unknown_embedding)
            if sim > best_score and sim > (1 - threshold):
                best_match = face
                best_score = sim
        
        if best_match:
            return {
                'matched': True,
                'similarity': round(best_score, 4),
                'name': best_match['name'],
                'face_id': best_match['id']
            }
        
        return {'matched': False, 'similarity': best_score}
    
    def identify_from_image(self, image_path: str, engine=None) -> Dict:
        """从图片直接识别"""
        from datetime import datetime
        
        if engine is None:
            engine = OpenCVFaceEngine()
        
        if not engine.is_loaded:
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'image_file': image_path,
                'detected_faces': 0,
                'matches': [],
                'unknown_count': 0,
                'raw_text': 'Face detector not available',
                'error': None
            }
        
        # 检测人脸
        detection = engine.detect_faces(image_path)
        
        if not detection.success or detection.face_count == 0:
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'image_file': image_path,
                'detected_faces': 0,
                'matches': [],
                'unknown_count': 0,
                'raw_text': 'No face detected',
                'error': None
            }
        
        # 对每个检测到的人脸进行识别
        matches = []
        unknown_count = 0
        
        for face_info in detection.faces:
            embedding = engine.generate_simple_embedding(image_path, face_info['bbox'])
            
            if embedding and self.count > 0:
                result = self.identify(embedding)
                
                match_result = FaceMatchResult(
                    matched=result['matched'],
                    similarity=result.get('similarity', 0),
                    name=result.get('name'),
                    face_id=result.get('face_id')
                )
                matches.append(match_result)
                
                if not result['matched']:
                    unknown_count += 1
            else:
                unknown_count += 1
        
        text_parts = []
        if matches:
            for m in matches:
                if m.matched:
                    text_parts.append(f"{m.name} ({m.similarity*100:.1f}%)")
                else:
                    text_parts.append("unknown")
        if unknown_count > 0:
            text_parts.append(f"unknown: {unknown_count}")
        
        return {
            'success': True,
            'timestamp': datetime.now().isoformat(),
            'image_file': image_path,
            'detected_faces': detection.face_count,
            'matches': [m.to_dict() for m in matches],
            'unknown_count': unknown_count,
            'raw_text': '; '.join(text_parts) if text_parts else 'No matches',
            'error': None
        }
    
    def list_all(self) -> List[Dict]:
        """列出所有已注册人脸"""
        result = []
        for i, f in enumerate(self.faces, 1):
            result.append({
                'index': i,
                'id': f['id'],
                'name': f['name'],
                'registered': f.get('registered_at', '')[:10],
                'engine': f.get('engine', 'opencv')
            })
        return result
    
    def remove(self, name: str = None, face_id: str = None) -> bool:
        """删除人脸"""
        original = len(self.faces)
        if face_id:
            self.faces = [f for f in self.faces if f['id'] != face_id]
        elif name:
            self.faces = [f for f in self.faces if f['name'] != name]
        
        if len(self.faces) < original:
            self._save()
            return True
        return False


def get_opencv_face_engine():
    """获取 OpenCV 人脸引擎实例"""
    return OpenCVFaceEngine()


def get_opencv_registry():
    """获取 OpenCV 人脸注册库实例"""
    return SimpleFaceRegistry()
