"""
CameraAI - 人脸识别模块
基于 face_recognition (dlib) 的轻量级人脸辨识系统
按需加载，内存友好
"""

from .models import FaceProfile, FaceDetectionResult, FaceIdentifyResult, FaceMatchResult
from .engine import FaceEngine, get_face_engine, release_face_engine
from .registry import FaceRegistry

__all__ = [
    'FaceProfile',
    'FaceDetectionResult', 
    'FaceIdentifyResult',
    'FaceMatchResult',
    'FaceEngine',
    'get_face_engine',
    'release_face_engine',
    'FaceRegistry'
]
