"""
CameraAI - 人脸识别数据模型
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime


@dataclass
class FaceProfile:
    """已注册的人脸档案"""
    id: str
    name: str
    embedding: List[float]
    source_image: str
    registered_at: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'name': self.name,
            'embedding': self.embedding,
            'source_image': self.source_image,
            'registered_at': self.registered_at,
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'FaceProfile':
        return cls(
            id=data['id'],
            name=data['name'],
            embedding=data['embedding'],
            source_image=data.get('source_image', ''),
            registered_at=data.get('registered_at', ''),
            metadata=data.get('metadata', {})
        )


@dataclass 
class FaceDetectionResult:
    """人脸检测结果"""
    success: bool
    face_count: int
    faces: List[Dict[str, Any]] = field(default_factory=list)
    error: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            'success': self.success,
            'face_count': self.face_count,
            'faces': self.faces,
            'error': self.error
        }


@dataclass
class FaceMatchResult:
    """单次比对结果"""
    matched: bool
    similarity: float  # 0.0 - 1.0
    name: Optional[str] = None
    face_id: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            'matched': self.matched,
            'similarity': round(self.similarity, 4),
            'name': self.name,
            'face_id': self.face_id
        }


@dataclass
class FaceIdentifyResult:
    """完整识别结果"""
    success: bool
    timestamp: str
    image_file: str
    detected_faces: int
    matches: List[FaceMatchResult] = field(default_factory=list)
    unknown_count: int = 0
    raw_text: str = ""
    error: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            'success': self.success,
            'timestamp': self.timestamp,
            'image_file': self.image_file,
            'detected_faces': self.detected_faces,
            'matches': [m.to_dict() for m in self.matches],
            'unknown_count': self.unknown_count,
            'raw_text': self.raw_text,
            'error': self.error
        }
