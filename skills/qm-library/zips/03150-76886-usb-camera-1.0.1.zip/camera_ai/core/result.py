"""
CameraAI - 结果格式化模块
处理分析结果的输出格式化
"""

import json
from typing import Optional
from pathlib import Path

from .types import AnalysisResult, AnalysisResultData, PersonInfo, SceneInfo


class ResultFormatter:
    """结果格式化器"""

    @staticmethod
    def format_text(result: AnalysisResult) -> str:
        """格式化为文本输出
        
        Args:
            result: 分析结果
            
        Returns:
            格式化的文本字符串
        """
        lines = []
        
        if not result.success:
            lines.extend([
                "=== CameraAI 分析失败 ===",
                f"时间: {result.timestamp}",
                f"错误: {result.error}",
            ])
            return "\n".join(lines)
        
        # 头部信息
        lines.extend([
            "=== CameraAI 分析结果 ===",
            f"时间: {result.timestamp}",
            f"图片来源: {result.image_file}",
            f"分析模式: {result.analysis_mode}",
            ""
        ])
        
        lines.append("【分析结果】")
        
        data = result.result
        
        # 描述内容
        if data.description:
            lines.append(data.description)
            lines.append("")
        
        # 人物信息
        if data.persons:
            lines.append(f"检测到 {len(data.persons)} 个人物：")
            for idx, person in enumerate(data.persons, 1):
                details = []
                if person.position:
                    details.append(f"位置: {person.position}")
                if person.gender:
                    details.append(f"性别: {person.gender}")
                if person.age_range:
                    details.append(f"年龄范围: {person.age_range}")
                if person.clothing:
                    details.append(f"穿着: {person.clothing}")
                if person.pose:
                    details.append(f"姿态: {person.pose}")
                if person.features:
                    details.append(f"特征: {person.features}")
                
                lines.append(f"  - 人物{idx}: {', '.join(details)}")
            lines.append("")
        
        # 物体列表
        if data.objects:
            lines.append(f"其他物体: {', '.join(data.objects)}")
            lines.append("")
        
        # 场景信息
        if data.scene:
            scene_details = []
            if data.scene.type:
                type_cn = "室内" if data.scene.type == "indoor" else "室外"
                scene_details.append(f"类型: {type_cn}")
            if data.scene.environment:
                scene_details.append(f"环境: {data.scene.environment}")
            if data.scene.description:
                scene_details.append(f"描述: {data.scene.description}")
            
            if scene_details:
                lines.append(f"场景: {', '.join(scene_details)}")
                lines.append("")
        
        # 文字内容
        if data.text_content:
            lines.append("【文字内容】")
            for text in data.text_content:
                lines.append(f"  {text}")
            lines.append("")
        
        # 安全警告
        if data.safety_alerts:
            lines.append("⚠️ 安全警告:")
            for alert in data.safety_alerts:
                lines.append(f"  - {alert}")
            lines.append("")
        
        # 底部信息
        lines.append("---")
        if result.token_usage:
            lines.append(f"消耗Token数: ~{result.token_usage}")
        
        return "\n".join(lines)

    @staticmethod
    def format_json(result: AnalysisResult) -> str:
        """格式化为JSON输出
        
        Args:
            result: 分析结果
            
        Returns:
            JSON字符串
        """
        output = {
            "success": result.success,
            "timestamp": result.timestamp,
            "image_file": result.image_file,
            "analysis_mode": result.analysis_mode,
            "result": {
                "persons": [
                    {
                        "position": p.position,
                        "gender": p.gender,
                        "age_range": p.age_range,
                        "clothing": p.clothing,
                        "pose": p.pose,
                        "features": p.features
                    } for p in result.result.persons
                ] if result.result.persons else [],
                "objects": result.result.objects or [],
                "scene": {
                    "type": result.result.scene.type,
                    "environment": result.result.scene.environment,
                    "description": result.result.scene.description
                } if result.result.scene else None,
                "text_content": result.result.text_content or [],
                "safety_alerts": result.result.safety_alerts or [],
                "description": result.result.description
            },
            "raw_text": result.raw_text,
            "token_usage": result.token_usage,
            "error": result.error
        }
        
        return json.dumps(output, indent=2, ensure_ascii=False)

    @classmethod
    def format(cls, result: AnalysisResult, fmt: str = "text") -> str:
        """通用格式化方法
        
        Args:
            result: 分析结果
            fmt: 输出格式 ('text' 或 'json')
            
        Returns:
            格式化后的字符串
        """
        if fmt == "json":
            return cls.format_json(result)
        else:
            return cls.format_text(result)

    @staticmethod
    def save_to_file(content: str, file_path: str) -> None:
        """保存结果到文件
        
        Args:
            content: 要保存的内容
            file_path: 文件路径
        """
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"结果已保存到: {file_path}")
