"""
CameraAI - MiniMax API 客户端模块
封装 mmx-cli 命令调用
"""

import subprocess
import json
import re
import hashlib
import os
from pathlib import Path
from typing import Optional, Dict, Any

from .types import (
    AnalysisMode, 
    AnalysisResult, 
    AnalysisResultData,
    PersonInfo,
    SceneInfo
)


# 预设提示词模板
PROMPT_TEMPLATES = {
    AnalysisMode.GENERAL: "请详细描述这张图片的内容，包括：人物（数量、特征）、物体（名称、位置）、场景（环境、氛围）。请用中文回答，结构清晰。",
    
    AnalysisMode.FACE: "请分析图片中的人脸信息：人脸数量、性别估计、年龄范围估计、表情状态、是否有遮挡。请用中文回答。",
    
    AnalysisMode.PERSON: "图片中有人吗？如果有，请描述：人数、大致位置、穿着特征、动作姿态。如果没有，请说明。请用中文回答。",
    
    AnalysisMode.OBJECT: "请列出图片中所有可见的物体，包括物体名称和大致位置。按重要程度排序。请用中文回答。",
    
    AnalysisMode.SCENE: "请描述图片的场景类型（室内/室外）、环境特征、时间推测（白天/夜晚）、整体氛围。请用中文回答。",
    
    AnalysisMode.OCR: "请提取图片中所有可见的文字内容，保持原有格式和顺序。如果没有文字，请说明。请用中文回答。",
    
    AnalysisMode.SAFETY: "请检查图片中是否存在安全隐患或异常情况。如果有，请详细描述；如果安全，请确认。请用中文回答。",
    
    AnalysisMode.CUSTOM: ""
}


def get_prompt_for_mode(mode: AnalysisMode) -> str:
    """根据模式获取提示词"""
    return PROMPT_TEMPLATES.get(mode, PROMPT_TEMPLATES[AnalysisMode.GENERAL])


class MinimaxClient:
    """MiniMax API 客户端"""

    def __init__(self):
        self.mmx_command = "npx mmx-cli"

    def analyze(
        self,
        image_path: str,
        prompt: Optional[str] = None,
        mode: AnalysisMode = AnalysisMode.GENERAL,
        output_format: str = "text"
    ) -> AnalysisResult:
        """分析图像
        
        Args:
            image_path: 图像文件路径或URL
            prompt: 自定义提示词（可选）
            mode: 分析模式
            output_format: 输出格式 ('text' 或 'json')
            
        Returns:
            分析结果对象
        """
        from datetime import datetime
        
        timestamp = datetime.now().isoformat()
        
        # 使用指定prompt或模式对应的默认prompt
        analysis_prompt = prompt or get_prompt_for_mode(mode)
        
        try:
            # 构建命令
            args = [
                self.mmx_command,
                "vision", "describe",
                "--image", image_path,
                "--prompt", analysis_prompt
            ]
            
            if output_format == "json":
                args.extend(["--output", "json"])
            
            # 执行命令
            command_str = self.mmx_command + " " + " ".join(
                ('"' + arg.replace('"', '') + '"' if ' ' in arg else arg) 
                for arg in args[1:]
            )
            result = subprocess.run(
                command_str,
                capture_output=True,
                text=True,
                timeout=60,
                shell=True,
                encoding='utf-8',
                errors='replace'
            )
            
            if result.returncode != 0:
                return AnalysisResult(
                    success=False,
                    timestamp=timestamp,
                    image_file=image_path,
                    analysis_mode=mode.value,
                    result=AnalysisResultData(),
                    raw_text="",
                    error=f"API调用失败: {result.stderr}"
                )
            
            # 解析结果
            raw_text = result.stdout.strip()
            parsed_data = self._parse_result(raw_text)
            
            return AnalysisResult(
                success=True,
                timestamp=timestamp,
                image_file=image_path,
                analysis_mode=mode.value,
                result=parsed_data,
                raw_text=raw_text
            )
            
        except subprocess.TimeoutExpired:
            return AnalysisResult(
                success=False,
                timestamp=timestamp,
                image_file=image_path,
                analysis_mode=mode.value,
                result=AnalysisResultData(),
                raw_text="",
                error="请求超时（60秒）"
            )
        except FileNotFoundError:
            return AnalysisResult(
                success=False,
                timestamp=timestamp,
                image_file=image_path,
                analysis_mode=mode.value,
                result=AnalysisResultData(),
                raw_text="",
                error="未找到 npx 命令，请确保安装了 Node.js 和 mmx-cli"
            )
        except Exception as e:
            return AnalysisResult(
                success=False,
                timestamp=timestamp,
                image_file=image_path,
                analysis_mode=mode.value,
                result=AnalysisResultData(),
                raw_text="",
                error=str(e)
            )

    def _parse_result(self, raw_text: str) -> AnalysisResultData:
        """解析MiniMax返回的原始文本为结构化数据"""
        data = AnalysisResultData()
        data.description = raw_text
        
        # 尝试提取人物数量
        person_match = re.search(r'(\d+)\s*(个人?物?|people|person)', raw_text, re.IGNORECASE)
        if person_match:
            count = int(person_match.group(1))
            data.persons = [PersonInfo(position=f"person_{i+1}") for i in range(count)]
        
        # 尝试提取物体列表
        object_match = re.search(r'(?:物体|object|item)s?[：:]\s*([^\n]+)', raw_text, re.IGNORECASE)
        if object_match:
            objects_str = object_match.group(1)
            data.objects = [
                obj.strip() for obj in re.split(r'[,，、]', objects_str) 
                if obj.strip()
            ]
        
        # 判断场景类型
        indoor_match = re.search(r'室内|indoor', raw_text, re.IGNORECASE)
        outdoor_match = re.search(r'室外|outdoor', raw_text, re.IGNORECASE)
        if indoor_match or outdoor_match:
            data.scene = SceneInfo(
                type="indoor" if indoor_match else "outdoor"
            )
        
        return data

    def check_auth_status(self) -> bool:
        """检查认证状态
        
        Returns:
            是否已认证
        """
        try:
            result = subprocess.run(
                f'{self.mmx_command} auth status',
                capture_output=True,
                text=True,
                timeout=45,
                shell=True
            )
            if result.returncode != 0:
                return False
            return ('api-key' in result.stdout or 'Valid' in result.stdout)
        except Exception:
            return False

    def get_quota_info(self) -> str:
        """获取配额信息
        
        Returns:
            配额信息文本
        """
        try:
            result = subprocess.run(
                f'{self.mmx_command} quota',
                capture_output=True,
                text=True,
                timeout=30,
                shell=True
            )
            if result.returncode == 0:
                return result.stdout
            else:
                return f"获取配额失败: {result.stderr}"
        except Exception as e:
            return f"获取配额出错: {e}"
