#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CameraAI - 摄像头AI识别工具（含人脸辨识）
基于 MiniMax VLM + OpenCV + face_recognition 的智能图像分析工具

使用方法:
    python -m camera_ai <command> [options]
    
命令:
    capture       从摄像头捕获图像并保存
    analyze       分析图像内容（调用MiniMax VLM）
    monitor       持续监控摄像头并进行AI分析
    face register 注册人脸到本地库
    face identify 识别人脸身份
    config        显示或修改配置
    status        显示系统状态和依赖检查
    help          显示帮助信息

示例:
    python -m camera_ai capture                          # 拍照保存
    python -m camera_ai analyze -i photo.jpg             # 分析图片
    python -m camera_ai face register -n "张三" --camera  # 注册人脸
    python -m camera_ai face identify -i photo.jpg        # 识别人脸
    python -m camera_ai monitor -t 10                    # 每10秒监控一次
    python -m camera_ai status                           # 查看状态
"""

import sys
import os

VERSION = "1.1.0"


def print_banner():
    """打印启动横幅"""
    banner = """
╔══════════════════════════════════════════════════╗
║          CameraAI - 摄像头AI识别工具 v{ver}      ║
║   MiniMax VLM + OpenCV + face_recognition         ║
╚══════════════════════════════════════════════════╝
""".format(ver=VERSION)
    print(banner)


def print_usage():
    """打印使用帮助"""
    print(f"""
版本: {VERSION}

用法: python -m camera_ai <command> [选项]

基础命令:
  capture           从摄像头捕获图像并保存
  analyze           分析图像内容（调用 MiniMax VLM）
  monitor           持续监控摄像头并进行 AI 分析

人脸识别命令 (新增):
  face register     注册人脸到本地识别库
  face identify     识别人脸身份

系统命令:
  config            显示或修改配置
  status            显示系统状态和依赖检查
  install-deps      运行依赖安装脚本

全局选项:
  help, -h          显示帮助信息
  version, -v       显示版本号

运行 'python -m camera_ai <command> --help' 获取更多命令详情。

快速开始:
  1. 首次使用运行安装脚本: install_deps.bat (Windows)
  2. 检查状态: python -m camera_ai status
  3. 测试拍照: python -m camera_ai capture
  4. 注册人脸: python -m camera_ai face register -n "姓名" -i 照片.jpg
  5. 识别人脸: python -m camera_ai face identify -i 照片.jpg

更多信息请访问 SKILL.md
""")


def cmd_capture(args: list) -> int:
    """执行 capture 命令"""
    from camera_ai.core import CaptureOptions, capture_image

    output = None
    device_id = 0
    width = 1280
    height = 720
    format_type = "jpeg"
    quality = 85
    show_preview = False
    brightness = None
    contrast = None
    exposure = None
    gain = None
    auto_adjust = False

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ('-o', '--output'):
            i += 1
            output = args[i]
        elif arg in ('-d', '--device'):
            i += 1
            device_id = int(args[i])
        elif arg in ('-w', '--width'):
            i += 1
            width = int(args[i])
        elif arg in ('-h', '--height'):
            i += 1
            height = int(args[i])
        elif arg in ('-f', '--format'):
            i += 1
            format_type = args[i]
        elif arg in ('-q', '--quality'):
            i += 1
            quality = int(args[i])
        elif arg == '--show-preview':
            show_preview = True
        elif arg in ('--brightness', '-b'):
            i += 1
            brightness = float(args[i])
        elif arg in ('--contrast', '-c'):
            i += 1
            contrast = float(args[i])
        elif arg in ('--exposure', '-e'):
            i += 1
            exposure = float(args[i])
        elif arg in ('--gain', '-g'):
            i += 1
            gain = float(args[i])
        elif arg in ('--auto-adjust', '-a'):
            auto_adjust = True
        elif arg in ('--help', '-h'):
            print("""
Usage: python -m camera_ai capture [options]

Options:
  --output, -o <path>        输出文件路径 (默认: ./captures/capture_<timestamp>.jpg)
  --device, -d <id>          摄像头设备ID (默认: 0)
  --width, -w <pixels>       图像宽度 (默认: 1280)
  --height, -h <pixels>       图像高度 (默认: 720)
  --format, -f <format>       输出格式: jpeg|png (默认: jpeg)
  --quality, -q <number>      JPEG质量 0-100 (默认: 85)
  --show-preview              捕获后显示预览窗口
  --auto-adjust, -a           自动调整图像（曝光、色彩）
  --brightness, -b <0.0-1.0> 亮度 (默认: 自动)
  --contrast, -c <0.0-1.0>    对比度 (默认: 自动)
  --exposure, -e <-1.0-1.0>   曝光 (默认: 自动，-1 为自动)
  --gain, -g <0.0-1.0>       增益 (默认: 自动)

Examples:
  python -m camera_ai capture
  python -m camera_ai capture -o my_photo.jpg
  python -m camera_ai capture -w 1920 -h 1080 -q 95
  python -m camera_ai capture --auto-adjust
""")
            return 0

        i += 1

    options = CaptureOptions(
        output=output,
        device=device_id,
        width=width,
        height=height,
        format=format_type,
        quality=quality,
        show_preview=show_preview,
        brightness=brightness,
        contrast=contrast,
        exposure=exposure,
        gain=gain,
        auto_adjust=auto_adjust
    )

    result = capture_image(options)

    if result["success"]:
        return 0
    else:
        print(f"[错误] 捕获失败: {result.get('error')}")
        return 1


def cmd_analyze(args: list) -> int:
    """执行 analyze 命令"""
    from camera_ai.commands.analyze import parse_args as analyze_parse_args, execute_analyze
    
    if not args or '--help' in args or '-h' in args:
        from camera_ai.commands.analyze import print_help as analyze_print_help
        analyze_print_help()
        return 0
    
    options = analyze_parse_args(args)
    return execute_analyze(options)


def cmd_monitor(args: list) -> int:
    """执行 monitor 命令"""
    from camera_ai.commands.monitor import parse_args as monitor_parse_args, execute_monitor
    
    if not args or '--help' in args or '-h' in args:
        from camera_ai.commands.monitor import print_help as monitor_print_help
        monitor_print_help()
        return 0
    
    options = monitor_parse_args(args)
    return execute_monitor(options)


def cmd_face_register(args: list) -> int:
    """执行 face register 命令"""
    from camera_ai.commands.face_register import execute_register, print_help as reg_help
    
    if not args or '--help' in args or '-h' in args:
        reg_help()
        return 0
    
    return execute_register(args)


def cmd_face_identify(args: list) -> int:
    """执行 face identify 命令"""
    from camera_ai.commands.face_identify import execute_identify, print_help as id_help
    
    if not args or '--help' in args or '-h' in args:
        id_help()
        return 0
    
    return execute_identify(args)


def cmd_config(args: list) -> int:
    """执行 config 命令"""
    from camera_ai.core import ConfigManager
    
    config_manager = ConfigManager()
    
    if not args or args[0] == 'show':
        config_manager.show()
        return 0
    
    subcommand = args[0]
    
    if subcommand == 'set':
        if len(args) < 3:
            print("[错误] 用法: camera-ai config set <key> <value>")
            return 1
        config_manager.set(args[1], args[2])
        print(f"[信息] 配置已更新: {args[1]} = {args[2]}")
    
    elif subcommand == 'reset':
        config_manager.reset()
        print("[信息] 配置已重置为默认值")
    
    elif subcommand == 'export-schema':
        print(config_manager.export_schema())
    
    else:
        print(f"[错误] 未知的配置命令: {subcommand}")
        return 1
    
    return 0


def cmd_status(args: list = None) -> int:
    """执行 status 命令（增强版，含人脸功能检测）"""
    from camera_ai.core import (
        MinimaxClient, 
        ConfigManager, 
        list_cameras
    )
    
    print("\n" + "=" * 50)
    print("  CameraAI 系统状态")
    print("=" * 50 + "\n")
    
    all_ok = True
    
    # === 依赖检查 ===
    print("[依赖检查]")
    
    # Python
    print(f"  Python:         ✓ {sys.version.split()[0]}")
    
    # OpenCV
    try:
        import cv2
        print(f"  OpenCV:         ✓ {cv2.__version__}")
    except ImportError:
        print("  OpenCV:         ✗ 未安装 (pip install opencv-python)")
        all_ok = False
    
    # NumPy
    try:
        import numpy
        print(f"  NumPy:          ✓ {numpy.__version__}")
    except ImportError:
        print("  NumPy:          ✗ 未安装 (pip install numpy)")
        all_ok = False
    
    # face_recognition (可选)
    try:
        import face_recognition
        print(f"  face_recogn.:   ✓ 已安装 (dlib)")
    except ImportError:
        print("  face_recogn.:   ○ 未安装 (人脸识别需要，可选)")
    
    print("")
    
    # === MiniMax CLI ===
    print("[MiniMax AI]")
    client = MinimaxClient()
    auth_ok = client.check_auth_status()
    print(f"  认证状态:       {'✓ 已认证' if auth_ok else '✗ 未认证'}")
    
    if auth_ok:
        print("\n  [配额信息]")
        quota_info = client.get_quota_info()
        for line in quota_info.strip().split('\n')[:8]:
            print(f"    {line}")
    print("")
    
    # === 人脸库状态 ===
    print("[人脸识别库]")
    try:
        from camera_ai.core.face.registry import FaceRegistry
        registry = FaceRegistry()
        
        if registry.count > 0:
            print(f"  已注册人数:     ✓ {registry.count} 人")
            print(f"  姓名:           {', '.join(registry.names[:10])}" + ("..." if registry.count > 10 else ""))
        else:
            print("  已注册人数:     ○ 空 (尚未注册)")
            print("                  提示: 运行 face register 注册人脸")
        
        print(f"  数据库位置:     {registry.db_path_str}")
    except Exception as e:
        print(f"  状态:           ✗ 无法加载 ({e})")
    print("")
    
    # === 摄像头设备 ===
    print("[摄像头设备]")
    cameras = list_cameras()
    if cameras:
        for cam_id in cameras:
            print(f"  设备 {cam_id}:      ✓ 可用")
    else:
        print("  状态:           ✗ 未检测到摄像头")
    print("")
    
    # === 当前配置 ===
    print("[配置概要]")
    config_manager = ConfigManager()
    cfg = config_manager.get_all()
    print(f"  分辨率:         {cfg['camera']['width']}x{cfg['camera']['height']}")
    print(f"  输出格式:       {cfg['camera']['format']}")
    print(f"  默认分析模式:   {cfg['analysis']['default_mode']}")
    print(f"  监控间隔:       {cfg['monitor']['interval']}s")
    print("")
    
    # === 总体状态 ===
    print("-" * 50)
    if all_ok and auth_ok:
        print("总体状态: ✓ 就绪，可以使用所有功能")
    elif all_ok and not auth_ok:
        print("总体状态: △ 基础就绪，需认证 MiniMax")
    else:
        print("总体状态: ✗ 存在问题，请检查上方报告")
        print("\n修复建议:")
        if not all_ok:
            print("  运行安装脚本: install_deps.bat (Windows)")
        if not auth_ok:
            print("  认证 MiniMax: npx mmx-cli auth login")
    print("=" * 50)
    
    return 0


def cmd_install_deps() -> int:
    """执行安装依赖脚本"""
    import subprocess
    import platform
    
    script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    system = platform.system().lower()
    
    if system == 'windows':
        script_path = os.path.join(script_dir, '..', 'install_deps.bat')
        print("[信息] 运行 Windows 安装脚本...")
        result = subprocess.run([script_path], shell=True)
    else:
        script_path = os.path.join(script_dir, '..', 'install_deps.sh')
        print("[信息] 运行 Linux/Mac 安装脚本...")
        result = subprocess.run(['bash', script_path])
    
    return result.returncode


def main():
    """主入口函数"""
    args = sys.argv[1:]
    
    if not args:
        print_usage()
        sys.exit(0)
    
    command = args[0]
    command_args = args[1:]
    
    # 处理全局选项
    if command in ('help', '--help', '-h'):
        print_usage()
        sys.exit(0)
    
    if command in ('version', '--version', '-v'):
        print(f"camera-ai version {VERSION}")
        sys.exit(0)
    
    # 分发到各命令处理函数
    commands = {
        'capture': cmd_capture,
        'analyze': cmd_analyze,
        'monitor': cmd_monitor,
        'face': {
            'register': cmd_face_register,
            'identify': cmd_face_identify,
        },
        'config': cmd_config,
        'status': cmd_status,
        'install-deps': cmd_install_deps,
    }
    
    # 处理 face 子命令
    if command == 'face':
        if not command_args:
            print("""
Usage: python -m camera_ai face <subcommand>

子命令:
  register     注册人脸到本地库
  identify     识别人脸身份

示例:
  python -m camera_ai face register -n "张三" -i photo.jpg
  python -m camera_ai face identify -i photo.jpg
""")
            sys.exit(1)
        
        face_cmd = command_args[0]
        face_args = command_args[1:]
        
        face_commands = commands['face']
        
        if face_cmd not in face_commands:
            print(f"[错误] 未知的 face 子命令: {face_cmd}")
            print("可用子命令: register, identify")
            sys.exit(1)
        
        exit_code = face_commands[face_cmd](face_args)
        sys.exit(exit_code)
    
    if command not in commands or isinstance(commands[command], dict):
        print(f"[错误] 未知命令: {command}")
        print_usage()
        sys.exit(1)
    
    exit_code = commands[command](command_args)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
