# CameraAI Package
from .core import *

__version__ = "1.0.0"
__author__ = "CameraAI Team"
