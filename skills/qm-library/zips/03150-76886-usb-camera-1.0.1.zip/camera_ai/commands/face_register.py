"""
CameraAI - face register 命令
注册人脸到本地数据库
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from camera_ai.core.face.engine import get_face_engine, release_face_engine
from camera_ai.core.face.registry import FaceRegistry
from camera_ai.core.camera import capture_image, CaptureOptions


def print_help():
    print("""
Usage: camera-ai face register [options]

Options:
  --name, -n <name>          姓名/标识名 (必需)
  --image, -i <path>         图片路径 (从图片注册)
  --camera, -c               从摄像头拍照注册
  --device, -d <id>          摄像头设备ID (配合 --camera 使用，默认: 0)

Examples:
  python -m camera_ai face register -n "张三" -i photo.jpg
  python -m camera_ai face register -n "爸爸" --camera
""")


def execute_register(args):
    name = None
    image_path = None
    use_camera = False
    device_id = 0
    
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ('-n', '--name'):
            i += 1
            name = args[i]
        elif arg in ('-i', '--image'):
            i += 1
            image_path = args[i]
        elif arg in ('--camera', '-c'):
            use_camera = True
        elif arg in ('-d', '--device'):
            i += 1
            device_id = int(args[i])
        elif arg in ('--help', '-h'):
            print_help()
            return 0
        i += 1
    
    if not name:
        print("[错误] 必须指定姓名 (--name / -n)")
        print_help()
        return 1
    
    if not image_path and not use_camera:
        print("[错误] 必须指定图片路径 (-i) 或使用摄像头 (--camera)")
        print_help()
        return 1
    
    engine = get_face_engine()
    
    available, error_msg = engine.check_available()
    if not available:
        print(error_msg)
        print("\n请运行安装脚本: install_deps.bat (Windows) 或 bash install_deps.sh")
        return 1
    
    registry = FaceRegistry()
    
    actual_image_path = image_path
    
    if use_camera:
        print(f"[信息] 正在从摄像头 {device_id} 拍照...")
        
        from datetime import datetime
        save_dir = os.path.join(os.getcwd(), "registrations")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"reg_{name}_{timestamp}.jpg"
        output_path = os.path.join(save_dir, output_file)
        
        opts = CaptureOptions(
            device=device_id,
            width=640,
            height=480,
            format="jpeg",
            quality=85,
            save_dir=save_dir,
            output=output_path
        )
        
        capture_result = capture_image(opts)
        
        if not capture_result.get("success"):
            print(f"[错误] 拍照失败: {capture_result.get('error')}")
            return 1
        
        actual_image_path = capture_result["output_path"]
    
    if not os.path.exists(actual_image_path):
        print(f"[错误] 图片文件不存在: {actual_image_path}")
        return 1
    
    print(f"[信息] 正在提取人脸特征...")
    
    from camera_ai.core.face.engine import is_using_opencv
    
    if is_using_opencv():
        # OpenCV 模式: 先检测人脸位置，再提取特征
        detection = engine.detect_faces(actual_image_path)
        
        if not detection.success or detection.face_count == 0:
            print("[错误] 未在图片中检测到人脸")
            print("请确保图片中有清晰的正脸")
            return 1
        
        # 使用第一张人脸的位置生成特征
        bbox = detection.faces[0]['bbox']
        embedding = engine.generate_simple_embedding(actual_image_path, bbox)
        
        if not embedding:
            print("[错误] 无法从图片中提取人脸特征")
            return 1
    else:
        # dlib 模式: 直接提取特征
        embedding = engine.extract_embedding(actual_image_path)
        
        if embedding is None:
            print("[错误] 无法从图片中提取人脸特征")
            print("请确保图片中有清晰的正脸")
            return 1
    
    profile = registry.register(
        name=name,
        embedding=embedding,
        source_image=actual_image_path
    )
    
    print("")
    print("=" * 40)
    print("人脸注册成功!")
    print("=" * 40)
    print("  姓名:     " + profile.name)
    print("  ID:       " + profile.id)
    print("  来源:     " + profile.source_image)
    print("  特征维度: " + str(len(profile.embedding)))
    print("  注册时间: " + profile.registered_at[:19])
    print("")
    print("当前库中已注册 " + str(registry.count) + " 个人脸")
    
    release_face_engine()
    
    return 0


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or '--help' in args or '-h' in args:
        print_help()
        sys.exit(0)
    
    exit_code = execute_register(args)
    sys.exit(exit_code)
