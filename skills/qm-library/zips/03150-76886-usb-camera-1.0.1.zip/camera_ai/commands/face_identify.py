"""
CameraAI - face identify 命令
识别人脸身份
"""

import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from camera_ai.core.face.engine import get_face_engine, release_face_engine
from camera_ai.core.face.registry import FaceRegistry
from camera_ai.core.face.models import FaceIdentifyResult


def print_help():
    """打印帮助信息"""
    print("""
Usage: camera-ai face identify [options]

Options:
  --image, -i <path>         图片路径 (必需)
  --tolerance, -t <float>   匹配阈值 0-1 (默认: 0.6, 越小越严格)
  --output-format, -f       输出格式: text|json (默认: text)
  --save-result, -s <path>  保存结果到文件
  --list                    先显示已注册列表再识别
  --release                  识别完成后释放内存

Examples:
  # 基本识别
  python -m camera_ai face identify -i photo.jpg
  
  # 更严格匹配
  python -m camera_ai face identify -i photo.jpg -t 0.5
  
  # JSON输出
  python -m camera_ai face identify -i photo.jpg -f json
  
  # 显示已注册列表
  python -m camera_ai face identify --list

Notes:
  - 首次运行会自动加载模型（约需几秒）
  - 8GB 内存设备建议使用后加 --release 释放资源
  - 匹配阈值说明:
    * 0.4-0.5: 宽松（可能误匹配）
    * 0.5-0.6: 平衡（推荐）
    * 0.6-0.7: 严格（需要高质量照片）
""")


def format_text_result(result: FaceIdentifyResult) -> str:
    """格式化为文本输出"""
    lines = []
    
    if not result.success:
        lines.extend([
            "=== CameraAI 人脸识别失败 ===",
            f"时间: {result.timestamp}",
            f"错误: {result.error}"
        ])
        return "\n".join(lines)
    
    lines.extend([
        "",
        "=" * 45,
        "  CameraAI 人脸识别结果",
        "=" * 45,
        f"  时间: {result.timestamp[11:19]}",
        f"  图片: {os.path.basename(result.image_file)}",
        f"  检测到: {result.detected_faces} 张人脸",
        "-" * 45
    ])
    
    if result.matches:
        lines.append("  【识别结果】")
        for i, match in enumerate(result.matches, 1):
            status = "✓ 匹配成功" if match.matched else "✗ 未匹配"
            conf_pct = match.similarity * 100
            lines.append(f"    [{i}] {status} | {match.name or '未知'} | 置信度: {conf_pct:.1f}%")
    
    if result.unknown_count > 0:
        lines.append(f"\n  ⚠️  未匹配到已注册人员: {result.unknown_count} 人")
    
    if result.raw_text:
        lines.append(f"\n  详情: {result.raw_text}")
    
    lines.extend(["", "=" * 45])
    
    return "\n".join(lines)


def format_json_result(result: FaceIdentifyResult) -> str:
    """格式化为 JSON 输出"""
    output = {
        "success": result.success,
        "timestamp": result.timestamp,
        "image_file": result.image_file,
        "detected_faces": result.detected_faces,
        "matches": [
            {
                "matched": m.matched,
                "similarity": round(m.similarity, 4),
                "name": m.name,
                "face_id": m.face_id
            } for m in result.matches
        ],
        "unknown_count": result.unknown_count,
        "raw_text": result.raw_text,
        "error": result.error
    }
    return json.dumps(output, indent=2, ensure_ascii=False)


def execute_identify(args: list) -> int:
    """执行人脸识别"""
    image_path = None
    tolerance = 0.6
    output_format = "text"
    save_result = None
    show_list = False
    auto_release = False
    
    i = 0
    while i < len(args):
        arg = args[i]
        
        if arg in ('-i', '--image'):
            i += 1
            image_path = args[i]
        elif arg in ('-t', '--tolerance'):
            i += 1
            tolerance = float(args[i])
        elif arg in ('-f', '--output-format'):
            i += 1
            output_format = args[i]
        elif arg in ('-s', '--save-result'):
            i += 1
            save_result = args[i]
        elif arg == '--list':
            show_list = True
        elif arg == '--release':
            auto_release = True
        elif arg in ('--help', '-h'):
            print_help()
            return 0
        
        i += 1
    
    # 初始化
    registry = FaceRegistry()
    
    # 如果只显示列表
    if show_list:
        print(f"\n{'='*50}")
        print(f"  已注册人脸列表 (共 {registry.count} 人)")
        print(f"{'='*50}")
        
        all_faces = registry.list_all(show_details=True)
        
        if not all_faces:
            print("\n  (空) 尚未注册任何人脸")
            print("\n注册示例:")
            print("  python -m camera_ai face register -n \"张三\" -i photo.jpg")
        else:
            for f in all_faces:
                print(f"  [{f['index']:2d}] {f['name']:<10} ID: {f['id']}  注册于: {f['registered']}")
        
        print(f"\n数据库位置: {registry.db_path_str}")
        return 0
    
    if not image_path:
        print("[错误] 必须指定图片路径 (--image / -i)")
        print_help()
        return 1
    
    if not os.path.exists(image_path):
        print(f"[错误] 图片不存在: {image_path}")
        return 1
    
    if registry.count == 0:
        print("[错误] 人脸库为空，请先注册人脸")
        print("\n注册命令:")
        print("  python -m camera_ai face register -n \"姓名\" -i 照片.jpg")
        return 1
    
    # 加载引擎
    engine = get_face_engine()
    
    available, error_msg = engine.check_available()
    if not available:
        print(error_msg)
        print("\n请运行安装脚本:")
        print("  Windows: install_deps.bat")
        print("  Linux/Mac: bash install_deps.sh")
        return 1
    
    # 执行识别
    print(f"[信息] 正在分析图片: {image_path}")
    print(f"[信息] 已加载 {registry.count} 个已知人脸进行比对\n")
    
    result = registry.identify_from_image(
        image_path=image_path,
        engine=engine,
        tolerance=tolerance
    )
    
    # 格式化输出
    if output_format == "json":
        formatted = format_json_result(result)
    else:
        formatted = format_text_result(result)
    
    print(formatted)
    
    # 保存结果
    if save_result:
        with open(save_result, 'w', encoding='utf-8') as f:
            f.write(formatted)
        print(f"\n结果已保存到: {save_result}")
    
    # 释放资源
    if auto_release:
        release_face_engine()
        print("[信息] 已释放人脸识别引擎内存")
    
    return 0 if result.success else 1


if __name__ == "__main__":
    args = sys.argv[1:]
    
    if not args or '--help' in args or '-h' in args:
        print_help()
        sys.exit(0)
    
    exit_code = execute_identify(args)
    sys.exit(exit_code)
