"""
CameraAI - monitor 命令
持续监控摄像头并进行AI分析
"""

import sys
import os
import time
import subprocess
import hashlib
from datetime import datetime

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from camera_ai.core import (
    MinimaxClient,
    ResultFormatter,
    CameraManager,
    capture_image,
    AnalysisMode,
    MonitorOptions,
    CaptureOptions,
    generate_timestamp,
    ensure_directory
)


def print_help():
    """打印帮助信息"""
    print("""
Usage: camera-ai monitor [options]

Options:
  --interval, -t <seconds>     捕获间隔秒数 (默认: 5)
  --prompt, -p <text>          分析提示词
  --mode, -m <type>            分析模式: general|face|person|object|scene|ocr|safety
  --output-format, -f <fmt>    输出格式: text|json (默认: text)
  --max-count, -n <number>     最大检测次数 (默认: 0=无限)
  --save-images, -d <dir>      保存图片目录
  --on-detect, -c <command>    检测到目标时执行的回调命令
  --threshold, -r <number>     变化检测阈值 0-100 (默认: 30)
  --quiet                      静默模式，仅输出检测结果

Examples:
  camera-ai monitor
  camera-ai monitor -t 10 -m person
  camera-ai monitor -n 20
  camera-ai monitor -d ./snapshots
  camera-ai monitor -m person -c "notify-send 'Detection'"
  camera-ai monitor -r 10
""")


def compute_frame_hash(image_path: str) -> str:
    """计算图像的MD5哈希值（用于变化检测）"""
    with open(image_path, 'rb') as f:
        return hashlib.md5(f.read()).hexdigest()[:16]


def calculate_similarity(hash1: str, hash2: str) -> float:
    """计算两个哈希值的相似度"""
    if len(hash1) != len(hash2) or not hash1 or not hash2:
        return 0.0
    
    differences = sum(1 for a, b in zip(hash1, hash2) if a != b)
    return 1.0 - (differences / len(hash1))


def has_significant_change(image_path: str, previous_hash: str, threshold: int) -> tuple:
    """检测图像是否有显著变化
    
    Args:
        image_path: 当前图像路径
        previous_hash: 上一帧的哈希值
        threshold: 变化阈值 (0-100)
        
    Returns:
        (是否有变化, 新的哈希值)
    """
    current_hash = compute_frame_hash(image_path)
    
    if not previous_hash:
        return True, current_hash
    
    similarity = calculate_similarity(previous_hash, current_hash)
    change_percent = (1 - similarity) * 100
    
    return change_percent >= threshold, current_hash


def execute_monitor(options: MonitorOptions) -> int:
    """执行监控模式
    
    Args:
        options: 监控选项
        
    Returns:
        退出码
    """
    interval = options.interval
    max_count = options.max_count
    threshold = options.threshold
    quiet = options.quiet
    
    # 检查认证
    client = MinimaxClient()
    
    if not client.check_auth_status():
        print("[错误] MiniMax 认证失败，请运行: npx mmx-cli auth login")
        return 1
    
    # 准备临时目录
    temp_dir = options.save_dir if options.save_images else "./monitor_temp"
    ensure_directory(temp_dir)
    
    count = 0
    previous_hash = ""
    start_time = time.time()
    
    print(f"[信息] 开始监控模式 (间隔: {interval}s, 阈值: {threshold}%, 模式: {options.mode.value})")
    
    if max_count > 0:
        print(f"[信息] 将在 {max_count} 次检测后停止")
    
    try:
        while True:
            count += 1
            
            # 检查是否达到最大次数
            if max_count > 0 and count > max_count:
                print(f"[信息] 已达到最大检测次数 ({max_count})，停止...")
                break
            
            timestamp = generate_timestamp()
            
            if not quiet:
                print(f"[{count}] 正在捕获帧... ({datetime.now().strftime('%H:%M:%S')})")
            
            # 捕获图像
            capture_opts = CaptureOptions(
                device=0,
                width=1280,
                height=720,
                format="jpeg",
                quality=80,
                save_dir=temp_dir,
                output=os.path.join(temp_dir, f"frame_{timestamp}.jpg")
            )
            
            capture_result = capture_image(capture_opts)
            
            if not capture_result["success"]:
                print(f"[错误] 捕获失败: {capture_result.get('error')}")
                time.sleep(interval)
                continue
            
            frame_path = capture_result["output_path"]
            
            # 变化检测
            should_analyze, new_hash = has_significant_change(frame_path, previous_hash, threshold)
            previous_hash = new_hash
            
            if not should_analyze:
                if not quiet:
                    print(f"[调试] 帧已跳过（无显著变化）")
                
                # 如果不保存图片则删除
                if not options.save_images and os.path.exists(frame_path):
                    os.remove(frame_path)
                
                time.sleep(interval)
                continue
            
            # 分析图像
            if not quiet:
                print(f"[{count}] 正在分析帧...")
            
            analysis_result = client.analyze(
                image_path=frame_path,
                prompt=options.prompt,
                mode=options.mode,
                output_format=options.output_format
            )
            
            # 格式化并输出
            formatted = ResultFormatter.format(analysis_result, options.output_format)
            
            separator = "=" * 50
            print(f"\n{separator}")
            print(f"[{count}] 检测结果 ({datetime.now().strftime('%H:%M:%S')})")
            print(separator + "\n")
            print(formatted)
            print(f"\n{separator}\n")
            
            # 回调命令
            if options.on_detect and analysis_result.success:
                print(f"[信息] 执行回调命令: {options.on_detect}")
                try:
                    env = os.environ.copy()
                    env["CAMERA_AI_RESULT"] = ResultFormatter.format(analysis_result, "json")
                    env["CAMERA_AI_IMAGE"] = frame_path
                    
                    subprocess.run(
                        options.on_detect,
                        shell=True,
                        timeout=10,
                        env=env
                    )
                except Exception as e:
                    print(f"[错误] 回调执行失败: {e}")
            
            # 清理临时文件
            if not options.save_images and os.path.exists(frame_path):
                os.remove(frame_path)
            
            time.sleep(interval)
    
    except KeyboardInterrupt:
        print("\n[信息] 用户中断监控")
    
    duration = int(time.time() - start_time)
    print(f"[信息] 监控停止。总时长: {duration}s, 分析帧数: {count}")
    
    return 0


def parse_args(args: list) -> MonitorOptions:
    """解析命令行参数"""
    options = MonitorOptions()
    
    i = 0
    while i < len(args):
        arg = args[i]
        
        if arg in ('-t', '--interval'):
            i += 1
            options.interval = int(args[i])
        elif arg in ('-p', '--prompt'):
            i += 1
            options.prompt = args[i]
        elif arg in ('-m', '--mode'):
            i += 1
            try:
                options.mode = AnalysisMode(args[i].lower())
            except ValueError:
                print(f"[错误] 无效的模式: {args[i]}")
                sys.exit(1)
        elif arg in ('-f', '--output-format'):
            i += 1
            options.output_format = args[i]
        elif arg in ('-n', '--max-count'):
            i += 1
            options.max_count = int(args[i])
        elif arg in ('-d', '--save-images'):
            options.save_images = True
            if i + 1 < len(args) and not args[i+1].startswith('-'):
                i += 1
                options.save_dir = args[i]
        elif arg in ('-c', '--on-detect'):
            i += 1
            options.on_detect = args[i]
        elif arg in ('-r', '--threshold'):
            i += 1
            options.threshold = int(args[i])
        elif arg == '--quiet':
            options.quiet = True
        elif arg in ('--help', '-h'):
            print_help()
            sys.exit(0)
        
        i += 1
    
    return options


if __name__ == "__main__":
    args = sys.argv[1:]
    
    if not args or '--help' in args or '-h' in args:
        print_help()
        sys.exit(0)
    
    options = parse_args(args)
    exit_code = execute_monitor(options)
    sys.exit(exit_code)
