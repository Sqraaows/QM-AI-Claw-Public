"""
CameraAI - analyze 命令
分析图像内容（调用 MiniMax VLM）
"""

import sys
import os

# 添加父目录到路径，以便导入模块
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from camera_ai.core import (
    MinimaxClient, 
    ResultFormatter, 
    AnalysisMode,
    AnalyzeOptions,
    get_prompt_for_mode
)


def print_help():
    """打印帮助信息"""
    print("""
Usage: camera-ai analyze [options]

Options:
  --image, -i <path>         图片路径或URL (必需)
  --prompt, -p <text>        自定义分析提示词
  --mode, -m <type>          分析模式:
                             general   - 通用描述（默认）
                             face      - 人脸识别
                             person    - 人物检测
                             object    - 物体识别
                             scene     - 场景理解
                             ocr       - 文字提取
                             safety    - 安全检测
                             custom    - 自定义（需配合 -p）
  --output-format, -f <fmt>  输出格式: text|json (默认: text)
  --save-result, -s <path>   保存结果到文件
  --verbose, -v              显示详细输出

Examples:
  camera-ai analyze -i photo.jpg
  camera-ai analyze -i photo.jpg -m face
  camera-ai analyze -i photo.jpg -p "图中有几个人？"
  camera-ai analyze -i photo.jpg -f json -s result.json
""")


def execute_analyze(options: AnalyzeOptions) -> int:
    """执行图像分析
    
    Args:
        options: 分析选项
        
    Returns:
        退出码 (0=成功, 1=失败)
    """
    import logging
    
    logging.info(f"开始分析图像: {options.image}")
    
    # 检查图片是否存在
    if not os.path.exists(options.image):
        print(f"[错误] 图片文件不存在: {options.image}")
        return 1
    
    # 验证模式
    if options.mode == AnalysisMode.CUSTOM and not options.prompt:
        print("[错误] 使用 custom 模式时必须指定 --prompt")
        return 1
    
    # 创建客户端并检查认证
    client = MinimaxClient()
    
    if not client.check_auth_status():
        print("[错误] MiniMax 认证失败，请运行: npx mmx-cli auth login")
        return 1
    
    # 执行分析
    result = client.analyze(
        image_path=options.image,
        prompt=options.prompt,
        mode=options.mode,
        output_format=options.output_format
    )
    
    # 格式化输出
    formatted = ResultFormatter.format(result, options.output_format)
    print("\n" + formatted + "\n")
    
    # 保存结果到文件
    if options.save_result:
        ResultFormatter.save_to_file(formatted, options.save_result)
    
    return 0 if result.success else 1


def parse_args(args: list) -> AnalyzeOptions:
    """解析命令行参数"""
    image_path = None
    prompt = None
    mode = AnalysisMode.GENERAL
    output_format = "text"
    save_result = None
    verbose = False
    
    i = 0
    while i < len(args):
        arg = args[i]
        
        if arg in ('-i', '--image'):
            i += 1
            image_path = args[i]
        elif arg in ('-p', '--prompt'):
            i += 1
            prompt = args[i]
        elif arg in ('-m', '--mode'):
            i += 1
            try:
                mode = AnalysisMode(args[i].lower())
            except ValueError:
                print(f"[错误] 无效的模式: {args[i]}")
                print(f"可用模式: {[m.value for m in AnalysisMode]}")
                sys.exit(1)
        elif arg in ('-f', '--output-format'):
            i += 1
            output_format = args[i]
        elif arg in ('-s', '--save-result'):
            i += 1
            save_result = args[i]
        elif arg in ('-v', '--verbose'):
            verbose = True
        elif arg in ('--help', '-h'):
            print_help()
            sys.exit(0)
        
        i += 1
    
    if not image_path:
        print("[错误] 必须指定图片路径 (--image 或 -i)")
        print_help()
        sys.exit(1)
    
    return AnalyzeOptions(
        image=image_path,
        prompt=prompt,
        mode=mode,
        output_format=output_format,
        save_result=save_result,
        verbose=verbose
    )


if __name__ == "__main__":
    args = sys.argv[1:]
    
    if not args or '--help' in args or '-h' in args:
        print_help()
        sys.exit(0)
    
    options = parse_args(args)
    exit_code = execute_analyze(options)
    sys.exit(exit_code)
