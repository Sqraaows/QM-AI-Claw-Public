## Description: <br>
x0x provides secure computer-to-computer networking for AI agents, including gossip broadcast, direct messaging, CRDT sync, group encryption, and NAT traversal. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jimcollinson](https://clawhub.ai/user/jimcollinson) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use x0x to install and operate a local CLI and daemon for peer-to-peer agent communication. It supports private direct messages, gossip pub/sub, encrypted group workflows, and REST or WebSocket integration with local agent tools. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The release uses mutable latest download URLs for installer artifacts. <br>
Mitigation: Review the installer and release source before installing, and prefer pinned or verified artifacts where operational policy requires reproducibility. <br>
Risk: Running x0x starts a persistent local agent-network daemon that creates local identity key files. <br>
Mitigation: Install only when a persistent local agent-network service is intended, and protect machine, agent, and optional human identity key files. <br>
Risk: Local API operations depend on bearer token credentials. <br>
Mitigation: Keep the local API token private, avoid logging it, and restrict local API access to trusted clients. <br>


## Reference(s): <br>
- [ClawHub x0x listing](https://clawhub.ai/jimcollinson/x0x) <br>
- [OpenClaw install archive: macOS arm64](https://github.com/saorsa-labs/x0x/releases/latest/download/x0x-macos-arm64.tar.gz) <br>
- [OpenClaw install archive: macOS x64](https://github.com/saorsa-labs/x0x/releases/latest/download/x0x-macos-x64.tar.gz) <br>
- [OpenClaw install archive: Linux x64 GNU](https://github.com/saorsa-labs/x0x/releases/latest/download/x0x-linux-x64-gnu.tar.gz) <br>
- [OpenClaw install archive: Linux arm64 GNU](https://github.com/saorsa-labs/x0x/releases/latest/download/x0x-linux-arm64-gnu.tar.gz) <br>
- [OpenClaw install archive: Windows x64](https://github.com/saorsa-labs/x0x/releases/latest/download/x0x-windows-x64.zip) <br>
- [x0x API Reference](https://github.com/saorsa-labs/x0x/blob/main/docs/api-reference.md) <br>
- [x0x Security and Cryptography](https://github.com/saorsa-labs/x0x/blob/main/docs/security.md) <br>
- [x0x SDK Quickstart](https://github.com/saorsa-labs/x0x/blob/main/docs/sdk-quickstart.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with bash commands, JSON request examples, TOML configuration snippets, and REST or WebSocket usage guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Includes commands that download binaries, start a local daemon, create local identity keys, and use bearer-token-protected local API calls.] <br>

## Skill Version(s): <br>
0.21.2 (source: release evidence and target metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
