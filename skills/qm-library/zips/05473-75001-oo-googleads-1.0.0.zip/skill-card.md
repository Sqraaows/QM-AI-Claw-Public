## Description: <br>
Operate Google Ads through an OOMOL-connected account for reading, creating, updating, and deleting advertising data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and marketing operators use this skill to read Google Ads data, run GAQL queries, and create, update, or remove campaigns, ad groups, and customer lists through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Campaign, ad group, and customer-list write or removal actions can change advertising state, targeting, customer data, or spend. <br>
Mitigation: Inspect the live action schema, review the exact JSON payload and intended effect, and obtain explicit user approval before running state-changing actions. <br>
Risk: The skill requires OAuth-connected Google Ads access and sensitive account credentials managed through OOMOL. <br>
Mitigation: Install and use it only for accounts where the user intends to authorize agent-managed Google Ads operations. <br>


## Reference(s): <br>
- [Google Ads homepage](https://ads.google.com) <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-googleads) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return Google Ads connector responses as JSON containing data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
