---
name: dev-team
description: "一键搭建AI全栈开发团队：项目经理+全栈开发+测试。默认大模型应用全栈开发架构，首次安装只需确认即可。"
metadata:
  version: "3.2.0"
  author: "贾维斯团队"
  category: "multi-agent"
  tags: ["dev-team", "multi-agent", "fullstack", "testing", "token-saving"]
license: "MIT"
homepage: "https://github.com/openclaw/openclaw"
allowed-tools: ["exec", "read", "write", "edit", "sessions_spawn", "session_status", "process"]
---

# Dev Team — AI 全栈开发团队一键部署 v3.1

一键创建 3-agent 全栈开发团队：main(项目经理) + my_dev(全栈开发) + my_test(测试)。

## Security

- 此 skill 会修改 `openclaw.json` 并创建 agent 配置和 workspace 文件
- 不会执行任何外部网络请求
- 不会读取或上传你的 API key 到任何地方
- 所有配置仅保存在本地 `~/.openclaw/` 目录
- 创建的 agent 仅在本地 Gateway 运行，不连接外部服务

## 触发条件

用户说以下任意关键词时触发：
- "搭建开发团队"
- "配置多agent开发"
- "安装dev-team"
- "创建AI开发团队"
- "部署开发团队skill"

## 首次安装流程（极简，3步完成）

### Step 1: 读取本地配置

从 `openclaw.json` 读取当前默认模型：

```bash
openclaw config get agents.defaults.model
```

记录 `primary` 和 `fallbacks` 作为后续步骤的默认值。

### Step 2: 模型确认

向用户展示当前默认模型，询问是否需要指定专用模型：

```
当前默认模型：{读取到的primary模型}

是否为开发团队指定专用模型？
1. 使用默认模型（推荐） — 三个agent共用当前默认模型
2. 指定专用模型 — 需要提供provider名称、Base URL、API Key、模型ID
```

**如果用户选择1（默认）**：直接跳到 Step 3。

**如果用户选择2（指定）**：询问：

```
请提供模型配置：
  Provider名称（如 custom-openai）: ___
  Base URL: ___
  API Key: ___
  模型ID（如 gpt-4o）: ___
```

如果用户只有一个模型，dev 和 test 共用同一个。

### Step 3: 确认并执行

展示配置摘要，用户确认后立即执行：

```
📋 开发团队配置摘要：

团队架构（固定）：
  main（项目经理）→ 路由 + 状态流转
  my_dev（全栈开发）→ 代码开发 + 单元测试
  my_test（测试）→ 部署验证 + 接口测试

默认技术栈（固定）：
  前端：Vue 3 + TypeScript + Vite + Pinia + Element Plus
  后端：Spring Boot 3 + Java 17 + MyBatis-Plus
  AI：LangChain4j (Java)

模型配置：
  主模型：{primary模型}
  备用模型：{fallback模型 或 同主模型}

确认后开始配置...（输入 确认 继续）
```

**用户确认后，执行以下操作：**

#### 3.1 创建 agent

```bash
openclaw agents add my_dev
openclaw agents add my_test
```

#### 3.2 写入 openclaw.json 补丁

通过 `openclaw config patch` 写入以下配置（只写增量，不覆盖现有配置）：

```json
{
  "agents": {
    "defaults": {
      "subagents": {
        "maxSpawnDepth": 2,
        "maxConcurrent": 5,
        "maxChildrenPerAgent": 5
      }
    }
  },
  "tools": {
    "agentToAgent": {
      "enabled": true,
      "allow": ["main", "my_dev", "my_test"]
    }
  }
}
```

#### 3.3 创建 workspace 文件

**my_dev workspace**（`~/.openclaw/workspace_dev/`）：
- `SOUL.md` — 人格定义
- `AGENTS.md` — 行为规范
- `TOOLS.md` — 环境和工具配置
- `IDENTITY.md` — 身份标识

**my_test workspace**（`~/.openclaw/workspace_test/`）：
- `SOUL.md` — 人格定义
- `AGENTS.md` — 行为规范
- `TOOLS.md` — 环境和工具配置
- `IDENTITY.md` — 身份标识

**模板文件位置**：`references/` 目录下

#### 3.4 更新 main 的 allowAgents

在 openclaw.json 中更新 main agent 的 `subagents.allowAgents`，加入 `my_dev` 和 `my_test`。

#### 3.5 验证

```bash
openclaw config validate
```

#### 3.6 完成提示

```
✅ 开发团队配置完成！

创建的 Agent:
- main（项目经理）— {主模型}
- my_dev（全栈开发）— {主模型}
- my_test（测试）— {备用模型}

开发流水线:
  需求 → main分解 → my_dev开发 → my_test测试 → 交付
                ↑                    │
                └── 不通过：返工 ────┘

默认技术栈:
  前端：Vue 3 + TS + Vite + Pinia + Element Plus
  后端：Spring Boot 3 + Java 17 + MyBatis-Plus

使用方式:
  直接告诉 main 你的开发需求，它会自动调度 my_dev 和 my_test。

⚠️ 请执行 openclaw gateway restart 使配置生效。
```

## 非首次安装

如果用户说"修改开发团队配置"或"更新dev-team"：
1. 读取当前 openclaw.json 中的 agents 配置
2. 问用户要改什么
3. 只修改相关部分，不重置整个配置

## 技术栈模板

**默认技术栈（大模型应用全栈开发）**：
- 前端：Vue 3 + TypeScript + Vite + Pinia + Element Plus
- 后端：Spring Boot 3 + Java 17 + MyBatis-Plus
- AI：LangChain4j (Java)

**可选技术栈**：

| 选择 | 前端描述 | 后端描述 |
|------|----------|----------|
| Vue3+TS（默认） | Vue 3 + TypeScript + Vite + Pinia + Element Plus | Spring Boot 3 + Java 17 + MyBatis-Plus |
| React+TS | React 18 + TypeScript + Vite + Ant Design | Spring Boot 3 + Java 17 + MyBatis-Plus |
| Express | - | Express.js + TypeScript + Prisma |
| Gin | - | Gin (Go) + GORM |

## 开发报告格式（my_dev）

reports/{任务ID}-dev.md:
```yaml
task_id: T-001
status: success | failed
file_location: "开发文件路径"
summary: "一句话摘要，不超过30字"
fail_reason: "失败原因（选填）"
fuction: "已经开发过的功能列表(供my_test进行测试)"
```

## 测试报告格式（my_test）

reports/{任务ID}-test.md:
```yaml
task_id: T-001
recommendation: complete | retry
result: pass | fail
summary: "一句话总结测试结果，不超过30字"
fail_reason: "失败原因（result=fail 时必填）"
tests_run: 5
tests_passed: 4
tested_features:
  - "功能A：通过"
  - "功能B：失败 - 接口返回500"
```

## main 路由规则（写死）
- 读取 test 报告的 `recommendation` 字段
- `recommendation: complete` → 完成
- `recommendation: retry` → 返工（上限 3 次）

## 开发规范
- **日志输出使用中文**：所有后端/前端日志、控制台输出使用中文，方便排查问题

## 测试服务关闭规范（写死）
- **只关闭测试期间启动的前后端服务**
- 后端关闭：调用 shutdown 接口（如 POST /api/shutdown）或使用项目自带的停止脚本
- 前端关闭：Ctrl+C 终止 npm dev 进程，或使用 `npm run dev -- --close`
- **绝对禁止**：taskkill 杀进程（会误杀 openclaw 的 node 进程）、关闭 openclaw gateway、关闭 MySQL/Redis 等基础设施

## 注意事项

- 不要覆盖用户现有的 main agent 的 SOUL.md/AGENTS.md（只补充缺失的）
- **TASKS.md 和 reports/ 必须放在项目目录下，不是 workspace**（子 agent 的 workspace 独立，看不到 main 的 workspace 文件）
- 所有 workspace 文件保持精简（每个 <2KB）
- 用户的技术栈选择会影响 dev 和 test 的 TOOLS.md 内容
- 每个 agent 的 AGENTS.md 中要写明 TASKS.md 和 reports/ 的绝对路径
