# Dev Team — AI 全栈开发团队一键部署 v3.2

一键创建 3-agent 全栈开发团队：**项目经理 + 全栈开发 + 测试**。

## 团队架构

```
main (项目经理)
  ├── my_dev (全栈开发)
  └── my_test (测试)
```

## 开发流水线

```
用户需求 → main 分解任务 → my_dev 开发 → my_test 测试 → 交付
                        ↑                    │
                        └── 不通过：返工 ────┘
```

## 默认技术栈

- **前端**：Vue 3 + TypeScript + Vite + Pinia + Element Plus
- **后端**：Spring Boot 3 + Java 21 + MyBatis-Plus
- **AI**：LangGraph(Python) + LangChain4j(Java)

## 安装

```bash
# 在 OpenClaw 中说：
"搭建开发团队"
```

只需确认模型配置即可完成安装，3步搞定。

## Agent ID

| Agent | ID | 职责 |
|-------|-----|------|
| 项目经理 | main | 路由 + 状态流转 |
| 全栈开发 | my_dev | 代码开发 + 单元测试 |
| 测试 | my_test | 部署验证 + 接口测试 |

## 核心特性

### 🔧 环境变量配置
- 自动识别 `OPENCLAW_WORKSPACE`、`PROJECT_ROOT`、`USER_HOME` 路径
- 子 Agent 调度时自动替换路径变量

### 🛡️ 上下文隔离
- Main 严禁读取子 Agent 完整代码/日志
- 只读取 YAML 头部元数据和 Summary
- 防止 Token 爆炸

### 📋 文件豁免权
- Main 只能操作：TASKS.md、reports/*.md、MEMORY.md
- 严格定义可操作的文件范围
- 防止文件污染

### 📊 标准工作流

#### Main (项目经理)
- Step 1: 需求澄清与任务初始化
- Step 2: 开发与测试流转
- Step 3: 决策与返工闭环
- 熔断机制：返工 > 3 次自动停止

#### my_dev (全栈开发)
- Step 0: 加载初始上下文
- Step 1: 需求对齐与分析
- Step 2: 架构 & 方案设计
- Step 3: 编写代码
- Step 4: 简单自测与编译
- Step 5: 编写测试清单
- Step 6: 编写开发报告 + 交付 main

#### my_test (测试)
- Step 0: 强制上下文加载
- Step 1: 接收任务与参数校验
- Step 2: 环境部署（后台运行）
- Step 3: 逐项测试（只读验证）
- Step 4: 输出报告与极简回报
- Step 5: 强制环境清理

## 报告格式

### 开发报告 (my_dev)
```yaml
task_id: T-001
status: success | failed
file_location: "开发文件路径"
summary: "一句话摘要，不超过30字"
fail_reason: "失败原因（选填）"
fuction: "已经开发过的功能列表"
test_plan_path: "测试清单路径"
```

### 测试报告 (my_test)
```yaml
task_id: T-001
recommendation: complete | retry
result: pass | fail
summary: "一句话总结测试结果"
fail_reason: "失败原因（result=fail 时必填）"
tests_run: 5
tests_passed: 4
tested_features:
  - "功能A：通过"
  - "功能B：失败 - 接口返回500"
```

## 版本历史

- **v3.2** — 配置同步：同步 main/my_dev/my_test 到 skill references
- **v3.1** — 极简安装流程，默认大模型应用全栈开发架构
- **v3.0** — 团队精简为3人，砍掉 Code Review
- **v2.1** — 报告写文件 + token 节省规则
- **v2.0** — 砍掉 Code Review + 判断逻辑下沉
- **v1.0** — 初始版本（4-agent + Code Review）

## 注意事项

- TASKS.md 和 reports/ 必须放在项目目录下，不是 workspace
- 所有 workspace 文件保持精简（每个 <2KB）
- 日志输出使用中文
- 子 Agent 回报限制在 30 字以内
- 禁止在对话中传递大段代码
