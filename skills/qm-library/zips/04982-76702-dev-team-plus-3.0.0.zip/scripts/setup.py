#!/usr/bin/env python3
"""
Dev Team Skill — 一键搭建AI全栈开发团队
v3.1: 极简安装，默认大模型应用全栈开发架构
"""
import json
import os
import sys
from pathlib import Path

STATE_DIR = Path(os.environ.get("OPENCLAW_STATE_DIR", Path.home() / ".openclaw"))
CONFIG_PATH = STATE_DIR / "openclaw.json"


def load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def get_default_model(cfg):
    """从当前配置读取默认模型"""
    defaults = cfg.get("agents", {}).get("defaults", {})
    model = defaults.get("model", {})
    primary = model.get("primary", "")
    fallbacks = model.get("fallbacks", [])
    return primary, fallbacks


def ensure_agent(cfg, agent_id, name, model_primary, workspace, agent_dir=None):
    """确保 agents.list 中存在指定 agent"""
    agents = cfg.setdefault("agents", {})
    agents_list = agents.setdefault("list", [])

    # 检查是否已存在
    for a in agents_list:
        if a.get("id") == agent_id:
            a["name"] = name
            a["model"] = {"primary": model_primary}
            a["workspace"] = str(workspace)
            if agent_dir:
                a["agentDir"] = str(agent_dir)
            return a

    # 创建新 agent
    new_agent = {
        "id": agent_id,
        "name": name,
        "model": {"primary": model_primary},
        "workspace": str(workspace),
    }
    if agent_dir:
        new_agent["agentDir"] = str(agent_dir)
    agents_list.append(new_agent)
    return new_agent


def ensure_auth_profiles(agent_id, providers):
    """为子 agent 创建 auth-profiles.json"""
    auth_dir = STATE_DIR / "agents" / agent_id / "agent"
    auth_dir.mkdir(parents=True, exist_ok=True)
    auth_file = auth_dir / "auth-profiles.json"

    profiles = {}
    for p in providers:
        key = p["provider"]
        profiles[key] = {
            "type": "api_key",
            "provider": key,
            "key": p["apiKey"],
        }

    data = {"version": 1, "profiles": profiles}
    with open(auth_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def create_workspace_file(workspace, filename, content):
    """创建 workspace 文件"""
    ws = Path(workspace)
    ws.mkdir(parents=True, exist_ok=True)
    filepath = ws / filename
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)


def setup(cfg, team_config):
    """
    team_config 结构:
    {
        "models": {
            "primary": { "provider": "...", "baseUrl": "...", "apiKey": "...", "modelId": "..." },
            "secondary": { ... }  # 可选
        }
    }
    """
    models = team_config["models"]

    # 1. 配置 agents.defaults
    defaults = cfg.setdefault("agents", {}).setdefault("defaults", {})
    primary_ref = f"{models['primary']['provider']}/{models['primary']['modelId']}"
    secondary_ref = f"{models['secondary']['provider']}/{models['secondary']['modelId']}" if models.get("secondary") else primary_ref

    defaults["model"] = {
        "primary": primary_ref,
        "fallbacks": [secondary_ref] if models.get("secondary") else [],
    }

    defaults["subagents"] = {
        "maxSpawnDepth": 2,
        "maxConcurrent": 5,
        "maxChildrenPerAgent": 5,
    }

    # 2. 创建 agents
    # main
    main_ws = str(STATE_DIR / "workspace")
    main_agent = ensure_agent(cfg, "main", "项目经理", primary_ref, main_ws)
    main_agent["subagents"] = {"allowAgents": ["my_dev", "my_test"]}
    main_agent["bootstrapMaxChars"] = 15000
    main_agent["bootstrapTotalMaxChars"] = 60000

    # my_dev
    dev_ws = str(STATE_DIR / "workspace_dev")
    dev_agent_dir = str(STATE_DIR / "agents" / "my_dev" / "agent")
    dev_agent = ensure_agent(cfg, "my_dev", "全栈开发 ⚒️", primary_ref, dev_ws, dev_agent_dir)
    dev_agent["bootstrapMaxChars"] = 12000
    dev_agent["bootstrapTotalMaxChars"] = 40000
    dev_agent["tools"] = {
        "allow": ["exec", "read", "write", "edit", "process", "sessions_send", "session_status"]
    }

    # my_test
    test_ws = str(STATE_DIR / "workspace_test")
    test_agent_dir = str(STATE_DIR / "agents" / "my_test" / "agent")
    test_agent = ensure_agent(cfg, "my_test", "测试专家 🔍", secondary_ref, test_ws, test_agent_dir)
    test_agent["bootstrapMaxChars"] = 10000
    test_agent["bootstrapTotalMaxChars"] = 30000
    test_agent["tools"] = {
        "allow": ["exec", "read", "write", "process", "sessions_send", "session_status"]
    }

    # 3. 配置 tools.agentToAgent
    tools = cfg.setdefault("tools", {})
    tools["agentToAgent"] = {
        "enabled": True,
        "allow": ["main", "my_dev", "my_test"],
    }

    # 4. 配置认证
    all_providers = [models["primary"]]
    if models.get("secondary"):
        all_providers.append(models["secondary"])

    for aid in ["my_dev", "my_test"]:
        ensure_auth_profiles(aid, all_providers)

    # 5. 保存配置
    save_config(cfg)
    print(f"✅ 配置已写入 {CONFIG_PATH}")
    return cfg


if __name__ == "__main__":
    print("Dev Team Setup Script v3.1")
    print("此脚本由 SKILL.md 调用，请通过 OpenClaw 交互式安装流程使用。")
