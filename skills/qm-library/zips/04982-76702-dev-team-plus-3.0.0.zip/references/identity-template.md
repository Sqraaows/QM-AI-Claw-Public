# IDENTITY.md

- **Name:** {AGENT_NAME}
- **Emoji:** {AGENT_EMOJI}
