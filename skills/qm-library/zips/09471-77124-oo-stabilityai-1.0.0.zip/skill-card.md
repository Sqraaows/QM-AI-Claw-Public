## Description: <br>
Provides an OOMOL-backed Stability AI connector action that generates audio from a text prompt and uploads the generated file to connector transit storage. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and workflow users use this skill to operate Stability AI through an OOMOL-connected account, inspect the live connector schema, and run the `text_to_audio` action with a matching JSON payload. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can generate audio and upload artifacts while its summary presents it as a read/search connector. <br>
Mitigation: Before running `text_to_audio`, confirm the prompt, requested settings, cost or quota impact, and where the uploaded artifact will be stored or expire. <br>
Risk: The skill requires a connected Stability AI account and sensitive credentials managed through OOMOL. <br>
Mitigation: Use the OOMOL-connected account flow and avoid asking users to paste or expose raw Stability AI API keys. <br>
Risk: Connector input fields and defaults can change upstream. <br>
Mitigation: Fetch the live schema with `oo connector schema "stabilityai" --action "text_to_audio"` before constructing payloads. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-stabilityai) <br>
- [Stability AI homepage](https://stability.ai) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [text_to_audio action reference](actions/text_to_audio.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are JSON from the oo CLI and may include connector transit-storage file references.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
