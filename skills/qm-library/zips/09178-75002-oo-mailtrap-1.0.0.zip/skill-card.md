## Description: <br>
Mailtrap connector skill for reading, creating, updating, and deleting Mailtrap data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to inspect and manage Mailtrap accounts, projects, inboxes, captured messages, contacts, templates, sending domains, suppressions, billing usage, permissions, and sending statistics through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change or delete Mailtrap resources, including projects, contacts, lists, templates, sending domains, inbox messages, and other account data. <br>
Mitigation: Require explicit user confirmation for destructive actions and review the exact target and payload before execution. <br>
Risk: Inbox cleaning and SMTP credential reset actions can disrupt active testing or integrations. <br>
Mitigation: Confirm the affected inbox and operational impact before running clean_inbox or reset_inbox_credentials. <br>
Risk: Connector input fields can change upstream, which may make stale payloads incorrect. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each payload. <br>
Risk: The skill requires access to a connected Mailtrap account and may expose sensitive account data to the agent during use. <br>
Mitigation: Install only for intended Mailtrap management workflows and use the minimum connected account scope appropriate for the task. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-mailtrap) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [Mailtrap homepage](https://mailtrap.io/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON data and execution metadata from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact metadata and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
