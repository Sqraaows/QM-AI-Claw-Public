## Description: <br>
This Mixpanel skill helps agents search, read, export, and report on Mixpanel analytics data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to query Mixpanel projects, inspect live connector schemas, export raw events, and retrieve funnel, retention, segmentation, frequency, saved report, top event, cohort, profile, and numeric metric data. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Raw event exports and profile queries may expose sensitive Mixpanel analytics or profile data. <br>
Mitigation: Review requested date ranges, filters, selected properties, and export scope before running actions. <br>
Risk: The connector uses an OOMOL-connected account to access Mixpanel project data. <br>
Mitigation: Install only when the user trusts OOMOL and intends to grant the connector access to the relevant Mixpanel project. <br>


## Reference(s): <br>
- [ClawHub Mixpanel Skill](https://clawhub.ai/oomol/oo-mixpanel) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Mixpanel Homepage](https://mixpanel.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, API calls, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses containing data and meta.executionId when run through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
