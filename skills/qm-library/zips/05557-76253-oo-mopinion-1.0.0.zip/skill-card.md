## Description: <br>
Mopinion (mopinion.com). Use this skill for ANY Mopinion request -- searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to read Mopinion account, deployment, dataset, feedback, field, and report data through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Mopinion feedback records may contain sensitive customer or business information. <br>
Mitigation: Install and use the skill only in workspaces where exposing connected Mopinion data to the agent is appropriate. <br>
Risk: The skill depends on live connector schemas and a connected OOMOL account, so commands can fail if authentication, scopes, billing, or upstream schemas change. <br>
Mitigation: Inspect the live action schema before building payloads and retry setup steps only after a command reports the matching auth, connection, scope, or billing error. <br>


## Reference(s): <br>
- [Mopinion homepage](https://www.mopinion.com) <br>
- [Mopinion ClawHub page](https://clawhub.ai/oomol/oo-mopinion) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Runs read-only Mopinion connector actions through the oo CLI and returns JSON data from the connected account.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
