## Description: <br>
Operates Algolia through OOMOL-connected credentials for reading, creating, updating, and deleting search data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect and manage Algolia indices, records, rules, and synonyms through the OOMOL `oo` CLI. It supports read workflows as well as state-changing record, rule, synonym, and filtered delete operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive Algolia credentials brokered through OOMOL. <br>
Mitigation: Install only if you trust OOMOL to broker the connection, and grant the connected API key only the scopes needed for intended workflows. <br>
Risk: Write, rule, synonym, and filtered delete actions can affect production search data. <br>
Mitigation: Review exact payloads and intended effects before approving writes, and require explicit confirmation for destructive filtered deletes. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-algolia) <br>
- [Algolia Homepage](https://www.algolia.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
