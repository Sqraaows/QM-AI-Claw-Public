## Description: <br>
Gamma (gamma.app). Use this skill for Gamma requests that read, create, or update Gamma data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Gamma through OOMOL's oo CLI: creating Gamma generations, creating from templates, checking generation status, and listing workspace folders and themes. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create Gamma content and may consume service credits. <br>
Mitigation: Review create-generation requests and approve the exact payload before execution. <br>
Risk: The skill requires a connected Gamma account through OOMOL. <br>
Mitigation: Install it only when comfortable using OOMOL-managed Gamma access and avoid exposing raw Gamma credentials. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-gamma) <br>
- [Gamma homepage](https://gamma.app) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses from connector actions are JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
