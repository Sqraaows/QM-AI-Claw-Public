## Description: <br>
Pushover (pushover.net). Use this skill for Pushover requests including reading, creating, updating, sending, and deleting data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Pushover notifications, delivery groups, Open Client workflows, application limits, receipts, Teams operations, and Glances updates through the oo CLI. It is useful when an agent needs to inspect schemas, run Pushover connector actions, or prepare account-management commands with user confirmation for state-changing operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Review before execution as proposals could introduce incorrect or misleading guidance into skills. <br>
Mitigation: Review and scan skill before deployment. <br>

## Reference(s): <br>
- [ClawHub Pushover skill](https://clawhub.ai/oomol/oo-pushover) <br>
- [Pushover homepage](https://pushover.net) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an OOMOL sign-in, and a connected Pushover provider account; sensitive token-return and token-storage actions should be used only when specifically needed.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
