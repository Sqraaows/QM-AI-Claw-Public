## Description: <br>
Use when programming Unihiker K10 board with Arduino/C++, uploading code, flashing firmware, or accessing K10 Arduino APIs for screen, sensors, RGB, audio, AI, TTS, and ASR. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[rockets-cn](https://clawhub.ai/user/rockets-cn) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to set up Arduino CLI tooling for the Unihiker K10, compile and upload sketches, flash firmware, troubleshoot ports, and consult K10 Arduino APIs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup flow can change Arduino CLI configuration and install board packages, libraries, package-manager dependencies, sudo-managed tools, and MicroPython tools beyond the stated Arduino scope. <br>
Mitigation: Review setup commands before running them, prefer manual execution with visible output, and install only the tools required for the current K10 workflow. <br>
Risk: OTA upload can send firmware to a device IP. <br>
Mitigation: Use OTA upload only with a K10 device IP you control and verify the target address before sending firmware. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/rockets-cn/unihiker-k10-arduino) <br>
- [Arduino API reference](references/arduino-api.md) <br>
- [Arduino examples](references/arduino-examples.md) <br>
- [Arduino CLI releases](https://github.com/arduino/arduino-cli/releases) <br>
- [DFRobot UNIHIKER board package index](https://downloadcd.dfrobot.com.cn/UNIHIKER/package_unihiker_index.json) <br>
- [Espressif ESP32 Arduino core package index](https://dl.espressif.com/dl/package_esp32_index.json) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell, PowerShell, Python, and Arduino/C++ code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include commands that change Arduino CLI configuration, install board packages or libraries, and upload firmware to a connected or networked K10 device.] <br>

## Skill Version(s): <br>
1.0.2 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
