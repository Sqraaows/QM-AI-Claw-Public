## Description: <br>
Enables agents to search, list, and retrieve Outline collections and documents through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agent users and developers use this skill to answer Outline-related requests by searching workspace documents, browsing collections, and retrieving specific documents visible to the connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Outline content available to the OOMOL-connected account. <br>
Mitigation: Install it only when that access is intended, and keep the connected Outline credential scoped as narrowly as practical. <br>
Risk: First-time setup may require installing or updating the oo CLI. <br>
Mitigation: Review the oo CLI installer before running it and avoid repeating setup steps unless a command fails with an authentication or connection error. <br>
Risk: Requests that merely mention Outline may not require live workspace access. <br>
Mitigation: Use the skill only when the user request requires searching or reading Outline workspace data. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each payload. <br>


## Reference(s): <br>
- [Outline homepage](https://www.getoutline.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [get_collection action](artifact/actions/get_collection.md) <br>
- [get_document action](artifact/actions/get_document.md) <br>
- [list_collection_documents action](artifact/actions/list_collection_documents.md) <br>
- [list_collections action](artifact/actions/list_collections.md) <br>
- [list_documents action](artifact/actions/list_documents.md) <br>
- [search_documents action](artifact/actions/search_documents.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads/results.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only Outline connector actions return JSON with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
