## Description: <br>
StatusCake helps agents read, create, update, and delete StatusCake uptime tests through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, site reliability engineers, and operations teams use this skill to manage StatusCake uptime tests, inspect monitoring history, review alerts, and list monitoring locations from an OOMOL-connected StatusCake account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Create and update actions can change StatusCake monitoring configuration. <br>
Mitigation: Review the exact payload and intended effect with the user before executing write actions. <br>
Risk: Delete actions can remove uptime tests and reduce monitoring coverage. <br>
Mitigation: Require explicit user approval for the target uptime test before running delete actions. <br>
Risk: The skill requires sensitive StatusCake credentials through an OOMOL-connected account. <br>
Mitigation: Install only when the agent should operate StatusCake through OOMOL, and avoid handling raw StatusCake tokens directly. <br>


## Reference(s): <br>
- [ClawHub StatusCake skill page](https://clawhub.ai/oomol/oo-statuscake) <br>
- [StatusCake homepage](https://www.statuscake.com) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution; command responses are JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
