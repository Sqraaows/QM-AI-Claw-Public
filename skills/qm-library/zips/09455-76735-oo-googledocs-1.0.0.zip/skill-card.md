## Description: <br>
Google Docs (workspace.google.com). Use this skill for Google Docs requests that read, create, update, delete, search, export, or otherwise manage document content through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents and users use this skill to operate Google Docs through the OOMOL CLI, including discovering documents, retrieving content, creating new documents, applying structured edits, managing document elements, exporting PDFs, and supporting chart-embedding workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The connected OOMOL account can read and modify Google Docs content. <br>
Mitigation: Install only for accounts where this access is acceptable, and review command payloads before write operations. <br>
Risk: Delete and remove actions can permanently alter document content or structure. <br>
Mitigation: Require explicit user approval for the target document, range, row, column, header, footer, named range, or bullet operation before execution. <br>
Risk: The skill can read Google Sheets chart metadata for embedding workflows. <br>
Mitigation: Treat spreadsheet chart metadata as in-scope account data and confirm that spreadsheet access is expected before using chart-related actions. <br>


## Reference(s): <br>
- [Google Docs product page](https://workspace.google.com/products/docs/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses from the OOMOL Google Docs connector, including data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
