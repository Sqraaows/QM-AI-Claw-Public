## Description: <br>
Provides Gmail reading, search, draft, send, reply, label, filter, settings, and mailbox-management actions through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to let an agent work with a connected Gmail mailbox, including reading messages, drafting and sending email, organizing labels and threads, and managing filters and mailbox settings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access a connected Gmail account with broad read, send, organization, settings, and delete capabilities. <br>
Mitigation: Install only if OOMOL is trusted with Gmail access, and review requested Gmail OAuth scopes before connecting the account. <br>
Risk: Write actions can send email, create or update drafts, alter labels and filters, and change mailbox settings. <br>
Mitigation: Require the agent to show exact recipients, message bodies, filter changes, settings changes, and intended effects before approval. <br>
Risk: Destructive actions can delete drafts, filters, labels, or move messages and threads to trash. <br>
Mitigation: Require explicit approval of the exact target before any destructive or remove action runs. <br>


## Reference(s): <br>
- [Gmail Skill on ClawHub](https://clawhub.ai/oomol/oo-gmail) <br>
- [Gmail Homepage](https://workspace.google.com/gmail/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action results are returned as JSON from the oo connector when commands are executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
