## Description: <br>
Genderize helps agents predict likely gender from first names through the OOMOL Genderize connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to query Genderize for single-name or small batch gender-probability predictions, optionally scoped by country. It is intended for data and analytics workflows that need structured connector results rather than direct API calls. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill sends names and optional country context through OOMOL to Genderize for prediction. <br>
Mitigation: Only submit names and country context that the user is comfortable having processed for gender prediction. <br>
Risk: The skill depends on the oo CLI, OOMOL account state, connected Genderize credentials, and available OOMOL billing credit. <br>
Mitigation: Install or authenticate the oo CLI and connect Genderize only when command failures indicate setup is required; stop and resolve billing or connection errors before retrying. <br>
Risk: Gender prediction results are probabilistic and can be inappropriate if treated as definitive identity information. <br>
Mitigation: Use returned probability data as an estimate for suitable analytics workflows, not as a definitive statement about a person. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-genderize) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Genderize homepage](https://genderize.io/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON containing data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
