## Description: <br>
CircleCI (circleci.com). Use this skill for CircleCI requests, including reading CI data, inspecting project and workflow status, and triggering pipelines through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to inspect CircleCI projects, pipelines, jobs, workflows, artifacts, insights, and masked environment variable names from an OOMOL-connected CircleCI account. They can also trigger a CircleCI pipeline after confirming the exact payload and intended effect. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected CircleCI account and may expose CI metadata through read actions. <br>
Mitigation: Install it only for a CircleCI account you are comfortable connecting through OOMOL, and review schemas and payloads before running actions. <br>
Risk: Triggering a pipeline changes CircleCI state. <br>
Mitigation: Require explicit user confirmation of the exact payload and intended effect before running trigger_pipeline or any future write/delete action. <br>


## Reference(s): <br>
- [CircleCI homepage](https://circleci.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-circleci) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; connector command responses are JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
