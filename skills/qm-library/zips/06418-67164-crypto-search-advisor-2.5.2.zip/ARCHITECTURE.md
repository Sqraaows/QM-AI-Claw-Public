# 工程架构

## 组件结构

```
crypto-search-advisor/
├── README.md              # 用户入门（4KB）
├── RULES.md               # 核心规则（6KB）
├── FORMAT.md              # 输出格式（8KB）
├── EXAMPLES.md            # 示例（5KB）
├── ARCHITECTURE.md        # 工程细节（本文件）
├── SKILL.md               # OpenClaw 技能入口
├── tools.json             # OpenClaw 工具配置
├── scripts/
│   └── crypto_advisor.py  # 主控脚本（~500行）
└── references/
    └── format-legacy.md   # 旧版完整格式（归档）
```

## 数据流转

```
用户输入 → OpenClaw 意图识别
              │
              ▼
    ┌─────────────────┐
    │ 交易意图？       │
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ 是 → 调用 reject │ 直接拒绝，返回安全提示
    │      脚本拒绝    │
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ 否 → 继续分析    │
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ web_search      │ ← OpenClaw 系统能力
    │ 获取行情信息     │
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ 用户发送截图     │（可选）
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ image_recog     │ ← OpenClaw 系统能力
    │ 提取价格/时间    │
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ Python 脚本处理  │
    │ - classify_coin │ 币种分类
    │ - detect_conflict│ 价格冲突检测
    │ - assess_quality │ 截图质量评估
    │ - calculate_     │ 数据可信度评分
    │   input_reliability│
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ format_output   │ 生成标准化 JSON
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ llm_chat        │ ← OpenClaw 系统能力
    │ 生成自然语言回复 │
    └────────┬────────┘
             │
             ▼
         返回用户
```

## 核心函数

### classify_coin(symbol, price)

分类逻辑：
- 稳定币：符号匹配 USDT/USDC/DAI 等，或价格 0.95-1.05
- Meme币：符号匹配 DOGE/SHIB/PEPE 等，或价格 < 0.01
- 主流币：其他

### detect_conflict(screenshot_price, search_min, search_max)

冲突检测：
- 偏差 < 1% → low
- 1-3% → medium
- > 3% → high

### calculate_input_reliability(category, conflict, quality, search_data)

数据可信度评分（0-10）：
- data_credibility 25%（截图质量+冲突）
- completeness 20%（搜索完整性）
- feasibility 25%（币种类别+置信度）
- risk_controllability 20%（冲突级别）
- freshness 10%（时效性）

## CLI 接口

```bash
# 币种分类
python crypto_advisor.py classify --symbol BTC [--price 65000]

# 交易意图检测
python crypto_advisor.py detect_trade_intent --message "帮我买BTC"

# 冲突检测
python crypto_advisor.py conflict \
  --screenshot-price 65000 \
  --search-min 64000 \
  --search-max 66000

# 完整分析
python crypto_advisor.py analyze \
  --symbol BTC \
  [--screenshot-price 65000] \
  [--clarity clear|blurry] \
  [--confidence high|medium|low] \
  [--missing "volume,indicators"]
```

## 依赖

```json
{
  "python": ["requests>=2.28.0"]
}
```

## 故障排查

| 问题 | 排查方法 |
|------|---------|
| 分类错误 | 检查 symbol 是否在预设集合中 |
| 冲突检测异常 | 检查价格和单位是否为数字 |
| 质量评估为 C 级 | 检查 clarity 是否为 blurry |
| 输出 JSON 错误 | 检查输入参数是否完整 |

## 安全机制

1. **交易意图拦截**：检测到 "帮我买"/"下单"/"开多" 等关键词 → 直接拒绝
2. **敏感信息保护**：索要密码/助记词 → 拒绝并提示诈骗风险
3. **免责声明**：所有输出强制包含 disclaimer 字段
4. **评分诚实性**：明确说明 input_reliability 仅评估数据质量，不预测价格
