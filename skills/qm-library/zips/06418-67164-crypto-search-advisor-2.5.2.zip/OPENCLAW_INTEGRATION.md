# OpenClaw 集成指南

## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                        OpenClaw 系统                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  web_search  │  │ image_recog  │  │   llm_chat   │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                 │                 │              │
│         └────────┬────────┴────────┬────────┘              │
│                  │                 │                        │
│         ┌────────▼─────────────────▼────────┐              │
│         │      Skill 编排逻辑 (Python)       │              │
│         │  ┌─────────────────────────────┐  │              │
│         │  │  crypto-search-advisor 脚本  │  │              │
│         │  │  - classify_coin.py         │  │              │
│         │  │  - detect_conflict.py       │  │              │
│         │  │  - assess_quality.py        │  │              │
│         │  │  - format_output.py         │  │              │
│         │  └─────────────────────────────┘  │              │
│         └───────────────────────────────────┘              │
│                            │                               │
│                            ▼                               │
│                   标准 JSON 输出                           │
└─────────────────────────────────────────────────────────────┘
```

## 集成方式

### 方式一：Shell 调用（推荐）

OpenClaw 通过 `subprocess` 调用脚本，获取 JSON 输出。

```python
# openclaw_skill.py
import subprocess
import json

def classify_coin(symbol: str, price: float = None) -> dict:
    """调用币种分类脚本"""
    cmd = ['python', 'scripts/classify_coin.py', '--symbol', symbol]
    if price:
        cmd.extend(['--price', str(price)])
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

def detect_conflict(screenshot_price: float, search_min: float, search_max: float) -> dict:
    """调用冲突检测脚本"""
    cmd = [
        'python', 'scripts/detect_conflict.py',
        '--screenshot-price', str(screenshot_price),
        '--search-min', str(search_min),
        '--search-max', str(search_max)
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)
```

### 方式二：Python Import（性能更优）

OpenClaw 直接导入脚本模块调用函数。

```python
# openclaw_skill.py
import sys
sys.path.insert(0, './scripts')

from classify_coin import classify_coin as do_classify
from detect_conflict import detect_conflict as do_detect
from assess_quality import assess_screenshot_quality
from format_output import format_mainstream_output, format_stablecoin_output, format_meme_output

def analyze_crypto(symbol: str, screenshot_data: dict, search_data: dict) -> dict:
    """完整分析流程"""
    # 1. 币种分类
    category = do_classify(symbol, screenshot_data.get('price'))
    
    # 2. 冲突检测
    conflict = do_detect(
        screenshot_data['price'],
        search_data['min'],
        search_data['max']
    )
    
    # 3. 质量评估
    quality = assess_screenshot_quality(
        screenshot_data.get('clarity', 'clear'),
        screenshot_data.get('confidence', 'high'),
        screenshot_data.get('missing', [])
    )
    
    # 4. 格式化输出
    base_data = {
        'symbol': symbol,
        'category': category['category'],
        'server_time': get_current_time(),
        'timezone': '北京时间 (UTC+8)',
        'disclaimer': '仅市场分析，不构成投资建议',
        'freshness_check': {
            'is_fresh': True,
            'screenshot_time': screenshot_data.get('time'),
            'note': '基于用户提供的截图'
        },
        'data_conflict_check': conflict,
        'screenshot_quality': quality,
        'search_availability': {'status': 'search_ok'}
    }
    
    # 根据分类选择输出模板
    if category['category'] == 'mainstream':
        base_data.update({
            'price': {'value': screenshot_data['price'], 'currency': 'USD', 'display': f'${screenshot_data["price"]:,}'},
            'final_price': {'value': screenshot_data['price'], 'currency': 'USD', 'display': f'${screenshot_data["price"]:,}'},
            'final_price_source': 'screenshot',
            'trend': '震荡偏多',
            'lobster_view': '偏多'
        })
        return format_mainstream_output(base_data)
    
    elif category['category'] == 'stablecoin':
        base_data.update({
            'current_price': {'value': screenshot_data['price'], 'currency': 'USD', 'display': f'${screenshot_data["price"]}'},
            'peg_deviation': calculate_peg_deviation(screenshot_data['price'])
        })
        return format_stablecoin_output(base_data)
    
    else:  # meme
        base_data.update({
            'current_price': {'value': screenshot_data['price'], 'currency': 'USD', 'display': f'${screenshot_data["price"]}'},
            'dump_risk_detector': {'risk_level': 'medium'}
        })
        return format_meme_output(base_data)
```

## 完整工作流程

```python
# openclaw_workflow.py

class CryptoAdvisorWorkflow:
    """OpenClaw 加密货币分析工作流"""
    
    def __init__(self):
        self.search_tool = web_search  # OpenClaw 系统搜索工具
        self.vision_tool = image_recognition  # OpenClaw 图像识别
    
    def process_user_query(self, user_input: str, screenshot: bytes = None):
        """处理用户查询"""
        
        # Step 1: 检测交易意图
        if self._detect_trade_intent(user_input):
            return self._reject_trade(user_input)
        
        # Step 2: 提取币种
        symbol = self._extract_symbol(user_input)
        
        # Step 3: 联网搜索
        search_results = self.search_tool(f"{symbol} 实时价格 今日行情")
        search_price = self._extract_price_from_search(search_results)
        
        # Step 4: 如果有截图，进行图像识别
        screenshot_data = {}
        if screenshot:
            ocr_result = self.vision_tool(screenshot)
            screenshot_data = {
                'price': ocr_result.get('price'),
                'time': ocr_result.get('time'),
                'clarity': ocr_result.get('quality', 'clear'),
                'confidence': ocr_result.get('confidence', 'high'),
                'missing': ocr_result.get('missing_elements', [])
            }
        
        # Step 5: 调用 Skill 脚本进行分析和格式化
        from classify_coin import classify_coin
        from detect_conflict import detect_conflict
        from format_output import format_mainstream_output
        
        category = classify_coin(symbol, screenshot_data.get('price'))
        conflict = detect_conflict(
            screenshot_data['price'],
            search_price['min'],
            search_price['max']
        )
        
        # Step 6: 生成最终输出
        result = self._format_output(symbol, category, conflict, screenshot_data, search_results)
        
        # Step 7: 追加截图引导
        if not screenshot:
            result['screenshot_prompt'] = '如需精准技术分析，请发送交易所APP实时截图'
        
        return result
    
    def _detect_trade_intent(self, text: str) -> bool:
        """检测交易意图关键词"""
        trade_keywords = ['买', '卖', '做空', '做多', '开仓', '平仓', '买入', '卖出']
        return any(kw in text for kw in trade_keywords)
    
    def _reject_trade(self, intent: str) -> dict:
        """拒绝交易请求"""
        return {
            'action': 'rejected',
            'action_type': 'trade_request',
            'reason': '龙虾不支持直接交易操作',
            'alternatives': ['龙虾仅提供市场分析，请通过正规交易所操作'],
            'risk_warning': '请勿向任何人透露账户密码或私钥'
        }
    
    def _extract_symbol(self, text: str) -> str:
        """从用户输入提取币种符号"""
        # 使用别名映射表
        alias_map = {
            '比特币': 'BTC', '大饼': 'BTC',
            '以太坊': 'ETH', '二饼': 'ETH',
            '泰达币': 'USDT', 'U': 'USDT',
            '狗狗币': 'DOGE', '狗币': 'DOGE'
        }
        
        for alias, symbol in alias_map.items():
            if alias in text.upper() or symbol in text.upper():
                return symbol
        return 'BTC'  # 默认
    
    def _extract_price_from_search(self, search_results: list) -> dict:
        """从搜索结果提取价格区间"""
        # 简化示例
        return {'min': 77800, 'max': 78200}
    
    def _format_output(self, symbol, category, conflict, screenshot_data, search_results):
        """格式化最终输出"""
        # 调用 format_output.py 中的函数
        from format_output import format_mainstream_output
        
        base_data = {
            'symbol': symbol,
            'category': category['category'],
            'server_time': datetime.now().isoformat(),
            'timezone': '北京时间 (UTC+8)',
            'disclaimer': '仅市场分析，不构成投资建议',
            'freshness_check': {
                'is_fresh': True,
                'screenshot_time': screenshot_data.get('time'),
                'note': '基于用户提供的截图'
            },
            'data_conflict_check': conflict,
            'price': {'value': screenshot_data.get('price', 0), 'currency': 'USD'},
            'final_price': {'value': screenshot_data.get('price', 0), 'currency': 'USD'},
            'final_price_source': 'screenshot' if screenshot_data else 'search'
        }
        
        return format_mainstream_output(base_data)


# 使用示例
workflow = CryptoAdvisorWorkflow()

# 场景1: 用户问价格
result = workflow.process_user_query("BTC现在多少？")

# 场景2: 用户发截图
with open('screenshot.png', 'rb') as f:
    result = workflow.process_user_query("帮我看看这张图", screenshot=f.read())

# 场景3: 交易意图被拒绝
result = workflow.process_user_query("帮我买1个BTC")
```

## 配置示例

```yaml
# openclaw_skill_config.yaml
name: crypto-search-advisor
description: 加密货币搜索顾问 + 截图分析
tools:
  - web_search
  - image_recognition
  
scripts:
  path: ./scripts
  entry: crypto_advisor.py
  
workflow:
  steps:
    - detect_trade_intent
    - classify_coin
    - web_search
    - detect_conflict
    - assess_quality
    - format_output
```

## 错误处理

```python
def safe_script_call(script_func, *args, **kwargs):
    """安全调用脚本，处理异常"""
    try:
        return script_func(*args, **kwargs)
    except subprocess.CalledProcessError as e:
        return {
            'error': '脚本执行失败',
            'detail': str(e),
            'fallback': '使用默认分析'
        }
    except json.JSONDecodeError as e:
        return {
            'error': '解析失败',
            'detail': str(e),
            'fallback': '请稍后重试'
        }
```

## 性能优化

```python
# 使用缓存避免重复分类
from functools import lru_cache

@lru_cache(maxsize=128)
def cached_classify(symbol: str, price: float) -> dict:
    """缓存币种分类结果"""
    return classify_coin(symbol, price)
```

## 调试模式

```python
# 开启调试日志
import logging
logging.basicConfig(level=logging.DEBUG)

# 查看脚本调用过程
def debug_call(cmd: list) -> dict:
    logging.debug(f"执行命令: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    logging.debug(f"返回结果: {result.stdout}")
    return json.loads(result.stdout)
```
