# 加密货币零翻墙拆解

🛡️ 国内直连·截图+搜索交叉验证加密货币行情助手

## 特性

- ✅ **国内直连**：无需VPN
- ✅ **零付费**：免费使用，无需API Key
- ✅ **交叉验证**：截图识别 + 搜索聚合
- ✅ **六模分析**：稳定币锚定·主流币结构·山寨币流动性·Meme币情绪·大宗商品宏观·股票代币基本面
- ✅ **安全边界**：不代操、不存资产、不预测价格

## 安装

```bash
# 克隆仓库
git clone https://github.com/你的用户名/crypto-search-advisor.git
cd crypto-search-advisor

# 安装依赖
pip install pytest
```

## 使用

```bash
# 币种分类
python scripts/crypto_advisor.py classify --symbol BTC

# 冲突检测
python scripts/crypto_advisor.py conflict --screenshot-price 100 --search-min 99 --search-max 101

# 完整分析
python scripts/crypto_advisor.py analyze --symbol BTC --screenshot-price 97000 --search-min 96800 --search-max 97200
```

## 测试

```bash
cd scripts
pytest tests/ -v
```

## 文档

- [SKILL.md](SKILL.md) - 完整使用文档
- [scripts/tests/](scripts/tests/) - 测试用例

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request！
