# 示例

## 示例1：BTC主流币分析

**输入**：
```bash
python crypto_advisor.py analyze \
  --symbol BTC \
  --screenshot-price 65000 \
  --search-min 64000 \
  --search-max 66000 \
  --clarity clear \
  --confidence high
```

**输出**：
```json
{
  "symbol": "BTC",
  "category": "mainstream",
  "screenshot_price": "$65,000",
  "search_price_range": "$64,000 - $66,000",
  "trend": "震荡偏多",
  "data_conflict_check": {
    "price_diff_pct": {"value": 0.0, "unit": "%"},
    "conflict_level": "low"
  },
  "input_reliability": {
    "score": 10.0,
    "grade": "A+",
    "assessment_type": "数据可信度评分（非价格预测）"
  },
  "observation_plan": {
    "bias": "long",
    "focus_zone": "$64,000 - $66,000",
    "risk_level_below": "$63,360",
    "upside_targets": ["$66,000", "$69,300"],
    "position_advice": "建议轻仓观察，等待放量突破后加仓"
  },
  "risk_flags": ["macro_uncertainty"]
}
```

---

## 示例2：USDT稳定币分析

**输入**：
```bash
python crypto_advisor.py analyze --symbol USDT
```

**输出**：
```json
{
  "symbol": "USDT",
  "category": "stablecoin",
  "current_price": 1.0001,
  "peg_deviation": {"value": 0.01, "unit": "%"},
  "peg_status": "正常锚定",
  "depeg_alert_system": {
    "triggered": false,
    "alert_level": "normal"
  },
  "input_reliability": {
    "score": 8.5,
    "grade": "A"
  },
  "strategy": "可作为过渡性资金载体"
}
```

---

## 示例3：PEPE Meme币分析（低质量截图）

**输入**：
```bash
python crypto_advisor.py analyze \
  --symbol PEPE \
  --screenshot-price 0.000015 \
  --clarity blurry \
  --confidence low \
  --missing "volume,indicators"
```

**输出**：
```json
{
  "symbol": "PEPE",
  "category": "meme",
  "current_price": 0.000015,
  "screenshot_quality": {
    "clarity": "blurry",
    "confidence": "low",
    "usable_level": "C"
  },
  "input_reliability": {
    "score": 5.1,
    "grade": "C+",
    "important_note": "截图质量C级，谨慎参考"
  },
  "dump_risk_detector": {
    "risk_level": "high",
    "dump_probability": {"value": 0.65, "display": "65%"}
  },
  "risk_flags": ["high_volatility", "screenshot_quality_low"]
}
```

---

## 示例4：价格冲突警告

**场景**：截图$70,000 vs 搜索$67,000（偏差4.3%）

**输出**：
```json
{
  "data_conflict_check": {
    "price_diff_pct": {"value": 4.3, "unit": "%"},
    "conflict_level": "high",
    "resolution": "价格偏差超过3%，建议核实数据源",
    "note": "截图 $70,000 vs 搜索 $67,000"
  },
  "input_reliability": {
    "score": 6.2,
    "grade": "B",
    "calculation_details": ["价格冲突HIGH，可信度扣3分"]
  }
}
```
