<!--
  作者: timo.cao | 邮箱: miscdd@163.com
  生成: 大帅教练系统 (dashuai coach)
  许可: MIT License
-->

# Token Secretary - 本地预处理压缩引擎

[English](README-en.md) | [中文](README.md)

## 简介

Token Secretary 是一个轻量级的本地小模型预处理引擎。它在用户长篇输入（3000字以上）到达云端大模型之前，用本地1B级别的微型模型将文本压缩为结构化JSON摘要，从而节省 **50%-80%** 的推理Token消耗。

## 核心价值

- 🚀 **极致省Token**：万字长文压缩为结构化摘要，只把关键信息交给大模型
- 🔒 **完全离线**：预处理过程在本地完成，不消耗任何云端资源
- ⚡ **即插即用**：原生支持 OpenClaw Skill 格式，可直接挂载到任何 Agent 系统中
- 💻 **硬件友好**：最低仅需 400MB 显存（Qwen3-0.6B Int4），可在老旧电脑上运行

## 快速开始

```bash
# 1. 克隆仓库
git clone https://github.com/Timo2026/token-secretary.git
cd token-secretary

# 2. 安装依赖
pip install openai pyyaml

# 3. 配置本地模型
cp config/config.example.yaml config/config.yaml
# 编辑 config.yaml 设置你的 Ollama 地址和模型

# 4. 运行测试
bash scripts/compress_knowledge.sh "你的长文本内容"
```

## 架构

```
用户输入 → Token秘书（本地小模型压缩） → 结构化JSON摘要 → 云端大模型深度推理
```

## 实测数据

| 场景 | 原始Token | 压缩后 | 节省比例 |
|------|-----------|--------|----------|
| 万字方案 | 15,000 | 2,500-3,000 | 80% |
| 技术文档 | 8,000 | 1,600 | 80% |
| 会议纪要 | 5,000 | 1,000 | 80% |

- 压缩过程耗时：**1-3秒**
- 云端推理效率提升：**3倍以上**

## 适用场景

- 长文档方案处理
- 多文件信息合并
- 任何需要降低推理成本的高精度任务

## 项目结构

```
token-secretary/
├── SKILL.md                 # OpenClaw Skill 格式定义
├── config/
│   └── config.example.yaml  # 配置模板
├── scripts/
│   └── compress_knowledge.sh # 压缩脚本
└── references/
    └── ...
```

## 相关项目

- [OpenClaw-CNC-Safe2](https://github.com/Timo2026/OpenClaw-CNC-Safe2) - CNC智能报价系统
- [meta-ceo-decision](https://github.com/Timo2026/meta-ceo-decision) - 多模型决策系统

## 作者

**timo.cao**
- 邮箱: miscdd@163.com
- GitHub: https://github.com/Timo2026

CNC智能报价系统 Union·由你 创始人
15年制造业销售经验，跨界AI开发者

## 许可

MIT License - 请查看 [LICENSE](LICENSE) 文件

---

*本项目由大帅教练系统 (dashuai coach) 生成*