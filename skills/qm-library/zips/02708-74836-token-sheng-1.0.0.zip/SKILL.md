# Token秘书 (Token Secretary)

## 简介
将"本地知识检索 → 情报压缩 → 云端精加工"封装为可复用的标准 Skill。
最大化节省云端 Token，让回答扎根于本地知识库，降低幻觉。

**本 Skill 是 GLOBAL_RULES.md vFinal Agentic RAG 架构的具名封装，复用所有已有脚本，不重复实现。**

## 触发方式
- 直接提及：`@Token秘书`
- 关键词触发：`情报压缩` `省token` `本地知识分析` `RAG增强`
- 默认：GLOBAL_RULES.md 已将该流程设为技术问题的默认行为，不用显式调用

## 执行流程

严格复用 GLOBAL_RULES.md §2 定义的 5 步流程：

### ① 意图分类
使用 GLOBAL_RULES.md §2 中定义的正则模式匹配：
- 寒暄模式 → 直接回复，不进入后续流程
- 技术/工艺/报价模式 → 继续

### ② 实体提取
从用户问题中正则提取 {材料, 工艺, 参数, 问题类型}。
模式定义见 GLOBAL_RULES.md §2 "技术问题模式"。

### ③ 双路知识检索（并行）
```bash
/home/timo/.miniconda/bin/python3 /home/timo/projects/knowledge_querier.py "{关键词}" 10
/home/timo/.miniconda/bin/python3 /home/timo/projects/rag_semantic_search.py "{用户问题}" 10
```
合并去重，保留最多 20 条。

### ④ 知识情报压缩
```bash
bash /home/timo/projects/compress_knowledge.sh "{知识条目文本}"
```
- 模型：llama3.2:1b（唯一 GPU 常驻）
- 目标：≤500 字
- 超时 60s → 降级为取前 3 条原文截断
- 已知代价：~15% 杂质率

### ⑤ 云端精加工
将以下内容发送给 DeepSeek：

```
【本地情报块】
{情报块内容}

【用户问题】
{原始问题}

【任务指令】
1. 基于本地情报块中的数据回答用户问题
2. 情报块可能含 15% 杂质，以下内容视为杂质直接丢弃：
   - 虚构的英文文件名/技能名
   - 英文单词混入中文短语
   - 错误的材料标签
   - 来源不明的占位符
3. 仅保留情报块中的：材料牌号、工艺名称、尺寸参数、价格数据、技术术语
4. 如果情报块数据不足，可用云端通用知识补充
5. 回复时明确区分：
   - "基于本地知识库"后面写情报块中确认的事实
   - "基于云端通用知识"后面写推理补充的内容
6. 回复不引用情报块中不存在的数据
```

### ⑥ 可观测性标记
回复开头必须：
```
[路由: Token秘书]
[本地知识: 检索 X 条 | 压缩为 Y 字 | 耗时 Zs]
[情报: K1, K2, K3]
```

## 依赖（全部复用已有脚本，不新增）

| 工具 | 路径 | 用途 |
|------|------|------|
| 关键词查询 | ~/projects/knowledge_querier.py | 精确关键词检索 |
| 语义搜索 | ~/projects/rag_semantic_search.py | FAISS 语义检索 |
| 知识压缩 | ~/projects/compress_knowledge.sh | llama3.2:1b 压缩 |
| 文本压缩 | ~/.openclaw/skills/ollama-manager/scripts/compress.sh | 长文本压缩（>3000字） |
| 架构规则 | ~/workspace/GLOBAL_RULES.md | 意图分类/实体提取正则模式 |

## 与其他 Skill 的关系

| Skill | 关系 |
|-------|------|
| quote-ptuning | Token秘书可嵌入报价流程：检索→压缩→报价计算 |
| step-factory | Token秘书可为 STEP 生成提供材料工艺建议 |
| orchestrator | 不依赖编排器（本 Skill 独立执行） |

## 降级策略

| 故障 | 处理 |
|------|------|
| FAISS 索引损坏 | 仅用 knowledge_querier.py |
| Ollama 不可用 | 跳过压缩，知识原文截断直送 |
| 压缩超时 | 取前 3 条原文 |
| 检索无结果 | 情报块="本地无匹配"，纯云端推理 |

## 示例

```
用户: @Token秘书 6061铝合金薄壁件铣削用什么夹持？

系统:
[路由: Token秘书]
[本地知识: 检索 8 条 | 压缩为 213 字 | 耗时 18s]
[情报: 6061铝合金, 软爪, 热处理]

基于本地知识库：6061铝合金是常用薄壁结构材料...
基于云端通用知识：推荐软爪全包夹持，面积≥60%...
```

---

_创建时间：2026-05-09 23:43 CST | 版本：v1.0_
_本 Skill 不包含独立实现代码，所有逻辑由 GLOBAL_RULES.md vFinal 驱动_