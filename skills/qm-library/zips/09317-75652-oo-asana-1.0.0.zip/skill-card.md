## Description: <br>
Provides OOMOL CLI-backed Asana actions for reading, creating, and updating workspaces, projects, and tasks through a connected Asana account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent inspect Asana workspaces and projects, list or retrieve tasks, and create or update Asana projects and tasks after reviewing write payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update Asana projects and tasks through the connected account. <br>
Mitigation: Review the exact payload and intended effect before approving write actions. <br>
Risk: The skill depends on a trusted OOMOL CLI installation and connected Asana credentials. <br>
Mitigation: Verify the installed oo CLI and Asana connection before allowing an agent to operate the account. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-asana) <br>
- [Asana homepage](https://asana.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payloads or responses.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands operate through the OOMOL oo CLI and return JSON connector responses when run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release version and SKILL.md metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
