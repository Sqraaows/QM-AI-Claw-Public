## Description: <br>
Operates Gigasheet through OOMOL's oo CLI for searching library metadata, inspecting datasets, listing files and exports, and checking account usage. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to query Gigasheet through an OOMOL-connected account, including library search, dataset inspection, export discovery, storage usage, and enrichment credit checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL and Gigasheet account and can access account-backed Gigasheet data. <br>
Mitigation: Install only when the agent should query Gigasheet through OOMOL, and use the connected account intentionally without exposing raw tokens. <br>
Risk: First-time setup may require running the OOMOL CLI installer. <br>
Mitigation: Review the OOMOL CLI installer before executing setup commands. <br>
Risk: Future mutating Gigasheet actions could change or delete data if added beyond the current read-oriented action set. <br>
Mitigation: Confirm the exact target, payload, and effect with the user before any create, update, send, post, delete, or remove action. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-gigasheet) <br>
- [Gigasheet homepage](https://www.gigasheet.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Gigasheet action references](artifact/actions/) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, JSON, Configuration guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payloads; connector responses are JSON.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schema inspection before building payloads; documented actions are read-oriented.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
