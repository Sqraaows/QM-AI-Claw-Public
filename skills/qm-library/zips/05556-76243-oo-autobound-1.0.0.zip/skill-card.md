## Description: <br>
Autobound helps agents search contacts and companies, enrich contact or company records, list signal types, and check account details through an OOMOL-connected Autobound account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Sales, marketing, and data operations users use this skill to query Autobound signal data, enrich account and contact records, and check account credit status through an existing OOMOL connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Commands can access business or contact data through the connected Autobound account and may consume Autobound or OOMOL credits. <br>
Mitigation: Fetch the live action schema, review payloads before execution, and confirm credit-sensitive enrichment or search work with the user when appropriate. <br>
Risk: The skill depends on an authenticated OOMOL connection and the oo CLI, so failures can stem from missing CLI setup, expired credentials, missing scopes, or billing limits. <br>
Mitigation: Use the documented setup, connection, and billing recovery steps only after a command fails with the matching error. <br>


## Reference(s): <br>
- [Autobound homepage](https://www.autobound.ai) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub listing](https://clawhub.ai/oomol/oo-autobound) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with shell command examples and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, OOMOL sign-in, and an Autobound connection; live schemas should be fetched before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
