## Description: <br>
Serply (serply.io). Use this skill for ANY Serply request - searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to run Serply Google web, news, scholar, and video searches through an OOMOL-connected account while fetching the live connector schema before building payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Serply account and sensitive credentials managed through OOMOL. <br>
Mitigation: Use only with an intended OOMOL-connected Serply account and do not expose raw credentials in prompts, files, or shell history. <br>
Risk: Search queries and results pass through the oo CLI, OOMOL, and Serply path and may consume account quota. <br>
Mitigation: Avoid sensitive queries unless that data flow is acceptable, and confirm expected query volume before running repeated searches. <br>
Risk: Connector input schemas can change upstream. <br>
Mitigation: Run the documented oo connector schema command before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-serply) <br>
- [Serply homepage](https://serply.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return a JSON object with data and meta.executionId when run through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
