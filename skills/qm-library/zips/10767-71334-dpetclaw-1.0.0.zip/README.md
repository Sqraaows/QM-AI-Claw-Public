# 龙虾守护宠物 Dpetclaw

桌面端的 AI 语音助手桌宠，基于声纹识别 + OpenClaw Gateway，为主人提供贴身语音指令入口，同时对陌生人保持静默。

> **注意**：这是小龙虾守护宠物的 Electron 版本入口，桌面宠物形象更美观，支持透明窗口。旧 Tk 入口已统一转发到这一套。

---

## 效果一览

- 桌面上显示透明龙虾宠物形象
- 说出唤醒词（"在吗在吗" / "小虾小虾" 等）即可唤醒
- 声纹验证通过后，转发语音指令给 OpenClaw AI
- 访客模式：非主人只能获得公开信息，无法访问本地数据
- Gateway 掉线自动重启，全程无需人工干预

---

## 三阶段升级状态

- V1 ✅ 固定引导词录入主人声音，生成声纹模板
- V2 ✅ 录入时采集 3 次样本并取平均，提升稳定性
- V3 ✅ 唤醒词匹配 + 声纹门禁双重保险

---

## 快速安装

### 前置依赖

- **Python 3.10+**（建议 Anaconda）
- **Node.js 18+**（含 npm）
- **FFmpeg**（音频处理用，需加入 PATH）
- **硅基流动 API Key**（[https://cloud.siliconflow.cn](https://cloud.siliconflow.cn) 注册获取）

### 安装步骤

**1. 克隆项目**
```bash
git clone <your-repo-url> lobster_pet
cd lobster_pet
```

**2. 安装 Python 依赖**
```bash
pip install -r requirements.txt
```

**3. 安装 Node.js 依赖**
```bash
npm install
```

**4. 配置 API Key**
```bash
cp .env.example .env
# 编辑 .env，填入你的 SILICONFLOW_API_KEY
```

**5. 首次使用 - 录入主人声音**
```bash
python register_owner_voice.py
```

录音时请连续 3 次朗读引导词：
> 小龙虾守护已激活，今天也请听我的命令。

**6. 启动桌宠**
```bash
wscript .\start_lobster_pet_electron_silent.vbs
```

---

## 配置说明

所有配置集中在 `config.json`（自动生成，首次运行后可见）：

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `wake_phrases` | 唤醒词列表 | 5个中文唤醒词 |
| `openclaw_cli_path` | OpenClaw CLI 路径 | `openclaw`（PATH中） |
| `siliconflow_api_key` | 硅基流动 API Key | 需在 `.env` 中配置 |
| `siliconflow_chat_model` | 对话模型 | `Qwen/Qwen3-Omni-30B-A3B-Instruct` |
| `siliconflow_tts_model` | TTS 模型 | `fnlp/MOSS-TTSD-v0.5` |
| `microphone_name` | 麦克风名称 | `null`（自动选择） |
| `asr_backend` | ASR 后端 | `siliconflow_omni`（也支持 `vosk` / `faster_whisper`） |
| `speaker_verification_threshold` | 声纹验证阈值 | `0.65` |
| `pet_scale` | 宠物缩放比例 | `0.5` |
| `guest_mode_duration_minutes` | 访客模式时长（分钟） | `10` |

> **ASR 后端选择**：`siliconflow_omni` 需要网络；`vosk` 和 `faster_whisper` 为本地模型，更快更隐私。

---

## 模型下载（本地 ASR 用）

### Vosk 模型
```bash
# 下载中文轻量模型（约 45MB）
python -c "
import urllib.request, zipfile, os
url = 'https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip'
path = 'C:/Users/<your_user>/lobster_pet_assets/vosk-model-small-cn-0.22'
os.makedirs(path, exist_ok=True)
# 请手动从官网下载并解压到该路径
print('请从 https://alphacephei.com/vosk/models 下载并解压到上述路径')
"
```

### Faster-Whisper 模型
```bash
# 自动下载（首次使用时会提示）
# 模型文件会缓存到 ~/.cache/huggingface/
```

---

## 使用流程

1. 双击启动桌宠（`start_lobster_pet_electron_silent.vbs`）
2. 你说"在吗在吗"或"小虾小虾"
3. 桌宠先做唤醒词匹配，再做声纹验证
4. 验证通过后，启动 OpenClaw 和 dashboard
5. 之后 90 秒内，你继续说的话会被转达给 OpenClaw

**访客模式**：说"开启访客模式"，非主人可获得公开帮助，但无法访问本地数据。

---

## 项目结构

```
虾宠/
├── lobster_pet/           # Python 核心逻辑
│   ├── app.py            # 主控制器
│   ├── voice_listener.py  # 语音监听 + ASR
│   ├── speaker_verifier.py # 声纹验证
│   ├── openclaw_client.py # OpenClaw Gateway 通信
│   ├── chat_client.py    # 硅基流动对话
│   ├── tts_client.py     # 硅基流动 TTS
│   ├── pet_window.py     # Tk 窗口（备用）
│   └── electron_bridge_main.py # Electron 后端桥接
├── electron/              # Electron 前端
│   ├── main.js          # Electron 主进程
│   ├── preload.js       # 预加载脚本
│   └── renderer/         # 前端资源
├── models/               # 本地 ASR 模型（需自己下载）
├── voice_profiles/       # 声纹模板（自动生成）
├── openclaw_bridge.mjs   # OpenClaw Gateway 桥接器
├── register_owner_voice.py # 声纹录入工具
├── config.json          # 运行时配置
├── .env                 # API Key（不提交）
└── requirements.txt
```

---

## 技术亮点

- **声纹门禁**：3 次采样平均 + 动态阈值，主人才能发指令
- **多 ASR 后端**：硅基流动 Omni（全离线可用）、Vosk（轻量本地）、Faster-Whisper（精准本地）
- **双进程架构**：Electron 前端 + Python 后端，通过 JSON over stdout 通信
- **Gateway 自动守护**：掉线后 8 秒内自动重启 OpenClaw
- **访客沙箱**：访客模式强制静默本地数据，仅返回公开信息

---

## 常见问题

**Q: 启动后提示"麦克风未找到"**
A: 编辑 `config.json`，将 `microphone_name` 改为你的实际麦克风名称，或设为 `null` 自动选择。

**Q: 声纹验证一直失败**
A: 检查 `speaker_verification_threshold` 是否设得过低（建议 0.6~0.7），或重新运行 `register_owner_voice.py` 重新录入。

**Q: OpenClaw Gateway 连接失败**
A: 确认 OpenClaw 已安装并在 PATH 中（`openclaw --version` 应有输出）。

---

## Star History

如果觉得有用，欢迎 star ⭐

---

## License

MIT
