from __future__ import annotations

from pathlib import Path

import speech_recognition as sr

from lobster_pet.config import load_config
from lobster_pet.speaker_verifier import SpeakerVerifier


LISTEN_TIMEOUT_SECONDS = 15
PHRASE_TIME_LIMIT_SECONDS = 10


def _pick_microphone(config_name: str | None) -> sr.Microphone:
    if not config_name:
        return sr.Microphone()
    for index, name in enumerate(sr.Microphone.list_microphone_names()):
        if config_name.lower() in name.lower():
            return sr.Microphone(device_index=index)
    return sr.Microphone()


def main() -> int:
    base_dir = Path(__file__).resolve().parent
    config, _ = load_config(base_dir)
    verifier = SpeakerVerifier(base_dir, threshold=config.speaker_verification_threshold)

    if not verifier.has_profile():
        print("还没有找到主人的声纹模板，请先运行 register_owner_voice.py 录入。")
        return 1

    recognizer = sr.Recognizer()
    recognizer.pause_threshold = config.pause_threshold
    recognizer.energy_threshold = config.energy_threshold
    recognizer.dynamic_energy_threshold = config.dynamic_energy_threshold
    microphone = _pick_microphone(config.microphone_name)

    print("开始验证主人声纹。")
    print(f"当前阈值: {config.speaker_verification_threshold:.2f}")
    print(f"请在 {PHRASE_TIME_LIMIT_SECONDS} 秒内说一句完整的话。")

    with microphone as source:
        print("正在校准环境噪声，请保持安静 1 秒...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        audio = recognizer.listen(
            source,
            timeout=LISTEN_TIMEOUT_SECONDS,
            phrase_time_limit=PHRASE_TIME_LIMIT_SECONDS,
        )

    wav_bytes = audio.get_wav_data(convert_rate=16000, convert_width=2)
    result = verifier.verify_wav_bytes(wav_bytes)

    print(f"相似度分数: {result.score:.3f}")
    print(f"通过阈值: {result.threshold:.3f}")
    if result.score == 0.0:
        print("提示: 这段录音更像静音、环境噪声或短促杂音，没有进入有效人声比对。")
    print("验证结果: " + ("通过" if result.accepted else "未通过"))
    return 0 if result.accepted else 2


if __name__ == "__main__":
    raise SystemExit(main())
