const shellEl = document.querySelector('.shell');
const statusLabelEl = document.getElementById('statusLabel');
const statusDetailEl = document.getElementById('statusDetail');
const subtitleEl = document.getElementById('subtitle');
const closeBtn = document.getElementById('closeBtn');

let blinkTimer = null;
let subtitleTimer = null;
let isQuitting = false;

const LABELS = {
  setup: '设置中',
  idle: '在线',
  listening: '倾听中',
  verifying: '确认中',
  recognizing: '识别中',
  forwarding: '转达中',
  wake_success: '已响应',
  guarding: '守护中',
  running: '在线',
  error: '出错了'
};

function setState(state, detail) {
  shellEl.dataset.state = state || 'idle';
  statusLabelEl.textContent = LABELS[state] || '';
  statusDetailEl.textContent = detail || '';
}

function blinkOnce() {
  shellEl.classList.add('blink');
  clearTimeout(blinkTimer);
  blinkTimer = setTimeout(() => {
    shellEl.classList.remove('blink');
  }, 140);
}

function showSubtitle(text, durationMs = 5000) {
  if (!text) return;
  subtitleEl.textContent = text;
  subtitleEl.classList.add('show');
  clearTimeout(subtitleTimer);
  subtitleTimer = setTimeout(() => {
    subtitleEl.classList.remove('show');
  }, durationMs);
}

window.lobsterShell.onBackendEvent((frame) => {
  if (frame.event === 'state') {
    setState(frame.state, frame.detail);
    if (frame.state === 'listening' || frame.state === 'wake_success') {
      blinkOnce();
    }
  } else if (frame.event === 'subtitle') {
    showSubtitle(frame.text, frame.duration_ms);
  } else if (frame.event === 'backend_error') {
    if (isQuitting) return;
    setState('error', String(frame.text || '').trim());
  } else if (frame.event === 'backend_exit') {
    if (isQuitting) return;
    setState('error', `后端已退出（code=${frame.code}）`);
  }
});

closeBtn.addEventListener('click', () => {
  isQuitting = true;
  window.lobsterShell.quit();
});

setInterval(() => {
  if (Math.random() < 0.65) {
    blinkOnce();
  }
}, 3600);
