const { app, BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow = null;
let backendProcess = null;
const singleInstanceLock = app.requestSingleInstanceLock();

if (!singleInstanceLock) {
  app.quit();
}

function resolvePython() {
  return process.env.LOBSTER_PYTHON || 'C:\\ProgramData\\anaconda3\\python.exe';
}

function sendToRenderer(payload) {
  if (!mainWindow || mainWindow.isDestroyed()) {
    return;
  }
  const contents = mainWindow.webContents;
  if (!contents || contents.isDestroyed()) {
    return;
  }
  try {
    contents.send('backend-event', payload);
  } catch (_err) {
    // Ignore sends during normal shutdown.
  }
}

function createWindow() {
  const display = screen.getPrimaryDisplay().workAreaSize;
  mainWindow = new BrowserWindow({
    width: 286,
    height: 382,
    title: '',
    backgroundColor: '#00000000',
    backgroundMaterial: 'none',
    x: display.width - 332,
    y: display.height - 432,
    frame: false,
    transparent: true,
    hasShadow: false,
    roundedCorners: false,
    thickFrame: false,
    resizable: false,
    skipTaskbar: false,
    alwaysOnTop: true,
    show: false,
    paintWhenInitiallyHidden: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  mainWindow.webContents.on('did-finish-load', () => {
    mainWindow?.setBackgroundColor('#00000000');
    mainWindow?.webContents.executeJavaScript(`
      document.documentElement.style.background = 'transparent';
      document.documentElement.style.backgroundColor = 'transparent';
      document.body.style.background = 'transparent';
      document.body.style.backgroundColor = 'transparent';
      const shell = document.querySelector('.shell');
      if (shell) {
        shell.style.background = 'transparent';
        shell.style.backgroundColor = 'transparent';
      }
    `).catch(() => {});
  });
  mainWindow.once('ready-to-show', () => {
    mainWindow?.showInactive();
  });
}

function startBackend() {
  if (backendProcess && !backendProcess.killed) {
    return;
  }

  const python = resolvePython();
  const env = {
    ...process.env,
    PYTHONUTF8: '1',
    PYTHONIOENCODING: 'utf-8'
  };
  backendProcess = spawn(
    python,
    ['-X', 'utf8', '-m', 'lobster_pet.electron_bridge_main'],
    {
      cwd: path.join(__dirname, '..'),
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env
    }
  );

  backendProcess.stdout.setEncoding('utf8');
  backendProcess.stdout.on('data', (chunk) => {
    const lines = chunk.split(/\r?\n/).filter(Boolean);
    for (const line of lines) {
      try {
        const frame = JSON.parse(line);
        sendToRenderer(frame);
      } catch (err) {
        sendToRenderer({
          event: 'backend_raw',
          text: line
        });
      }
    }
  });

  backendProcess.stderr.setEncoding('utf8');
  backendProcess.stderr.on('data', (chunk) => {
    sendToRenderer({
      event: 'backend_error',
      text: String(chunk)
    });
  });

  backendProcess.on('exit', (code) => {
    backendProcess = null;
    sendToRenderer({
      event: 'backend_exit',
      code: code ?? 0
    });
  });
}

app.whenReady().then(() => {
  createWindow();
  startBackend();
});

app.on('second-instance', () => {
  if (!mainWindow || mainWindow.isDestroyed()) {
    return;
  }
  if (mainWindow.isMinimized()) {
    mainWindow.restore();
  }
  mainWindow.showInactive();
  mainWindow.focus();
});

ipcMain.handle('quit-app', () => {
  app.quit();
});

app.on('window-all-closed', () => {
  app.quit();
});

app.on('browser-window-closed', () => {
  mainWindow = null;
});

app.on('before-quit', () => {
  if (backendProcess && !backendProcess.killed) {
    backendProcess.kill();
  }
});
