const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lobsterShell', {
  quit: () => ipcRenderer.invoke('quit-app'),
  onBackendEvent: (callback) => ipcRenderer.on('backend-event', (_event, payload) => callback(payload))
});
