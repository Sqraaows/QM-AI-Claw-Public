from __future__ import annotations

from pathlib import Path

import speech_recognition as sr

from lobster_pet.config import load_config
from lobster_pet.speaker_verifier import SpeakerVerifier


REFERENCE_TEXT = "小龙虾守护已激活，今天也请听我的命令。"
SAMPLE_COUNT = 3
LISTEN_TIMEOUT_SECONDS = 15
PHRASE_TIME_LIMIT_SECONDS = 10


def _pick_microphone(config_name: str | None) -> sr.Microphone:
    if not config_name:
        return sr.Microphone()
    for index, name in enumerate(sr.Microphone.list_microphone_names()):
        if config_name.lower() in name.lower():
            return sr.Microphone(device_index=index)
    return sr.Microphone()


def main() -> int:
    base_dir = Path(__file__).resolve().parent
    config, _ = load_config(base_dir)
    recognizer = sr.Recognizer()
    recognizer.pause_threshold = config.pause_threshold
    recognizer.energy_threshold = config.energy_threshold
    recognizer.dynamic_energy_threshold = config.dynamic_energy_threshold
    microphone = _pick_microphone(config.microphone_name)
    verifier = SpeakerVerifier(base_dir, threshold=config.speaker_verification_threshold)

    print("开始录入主人声音。")
    print(f"请连续录 {SAMPLE_COUNT} 次，每次都读这句话：")
    print(REFERENCE_TEXT)
    samples: list[bytes] = []

    with microphone as source:
        print("正在校准环境噪声，请保持安静 1 秒...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        for index in range(SAMPLE_COUNT):
            print(f"\n第 {index + 1}/{SAMPLE_COUNT} 次录音，请在 {PHRASE_TIME_LIMIT_SECONDS} 秒内读完。")
            audio = recognizer.listen(
                source,
                timeout=LISTEN_TIMEOUT_SECONDS,
                phrase_time_limit=PHRASE_TIME_LIMIT_SECONDS,
            )
            samples.append(audio.get_wav_data(convert_rate=16000, convert_width=2))
            print("已录到。")

    meta = verifier.enroll_from_wav_samples(samples, REFERENCE_TEXT)
    print("\n主人声音录入完成。")
    print(f"样本数: {meta['sample_count']}")
    print(f"阈值: {meta['threshold']}")
    print("之后桌宠会先识别唤醒词，再校验是否是你的声音。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
