from __future__ import annotations

import math
import tkinter as tk
from tkinter import ttk

from .states import PetState, STATE_PRESENTATIONS


class LobsterPetWindow:
    def __init__(self, always_on_top: bool = True, scale: float = 1.0) -> None:
        self.scale = max(scale, 0.5)
        self.root = tk.Tk()
        self.root.title("龙虾守护宠物")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", always_on_top)
        self.root.configure(bg="#00ff00")
        self.root.wm_attributes("-transparentcolor", "#00ff00")

        self.width = int(280 * self.scale)
        self.height = int(320 * self.scale)
        self.canvas = tk.Canvas(
            self.root,
            width=self.width,
            height=self.height,
            bg="#00ff00",
            highlightthickness=0,
            bd=0,
        )
        self.canvas.pack()

        self.state = PetState.IDLE
        self.detail_override: str | None = None
        self.tick = 0
        self.drag_start_x = 0
        self.drag_start_y = 0
        self.close_button_bounds: tuple[float, float, float, float] | None = None
        self._bubble_top = 24 * self.scale
        self._bubble_bottom = 94 * self.scale
        self.subtitle_text = ""
        self.subtitle_until_tick = 0
        self.menu_actions: dict[str, callable] = {}
        self.control_panel: tk.Toplevel | None = None

        self.canvas.bind("<ButtonPress-1>", self._start_drag)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonPress-3>", self._show_context_menu)
        self.root.bind("<Escape>", lambda event: self.root.destroy())

        self._animate()

    def set_state(self, state: PetState, detail: str | None = None) -> None:
        self.state = state
        self.detail_override = detail
        self.draw()

    def set_menu_actions(self, actions: dict[str, callable]) -> None:
        self.menu_actions = actions

    def show_subtitle(self, text: str, duration_ms: int = 5000) -> None:
        self.subtitle_text = text.strip()
        self.subtitle_until_tick = self.tick + max(1, duration_ms // 50)
        self.draw()

    def move_to_corner(self) -> None:
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        x = screen_w - self.width - 24
        y = screen_h - self.height - 72
        self.root.geometry(f"{self.width}x{self.height}+{x}+{y}")

    def show(self) -> None:
        self.root.deiconify()
        self.draw()

    def after(self, delay_ms: int, callback) -> None:
        self.root.after(delay_ms, callback)

    def mainloop(self) -> None:
        self.root.mainloop()

    def draw(self) -> None:
        c = self.canvas
        c.delete("all")
        bob = math.sin(self.tick / 12) * 3 * self.scale

        self._draw_aura(bob)
        self._draw_shadow(bob)
        self._draw_body(bob)

        self._draw_limbs(bob)
        self._draw_face(bob)
        self._draw_antennas(bob)
        self._draw_status_bubble()
        self._draw_subtitle()
        self._draw_close_button()

    def _draw_aura(self, bob: float) -> None:
        c = self.canvas
        palette = {
            PetState.SETUP: "#ff9868",
            PetState.IDLE: "#ff735e",
            PetState.LISTENING: "#79f1ff",
            PetState.VERIFYING: "#ffe37b",
            PetState.RECOGNIZING: "#8fd1ff",
            PetState.FORWARDING: "#7cd8ff",
            PetState.WAKE_SUCCESS: "#fff18a",
            PetState.GUARDING: "#8fffb4",
            PetState.RUNNING: "#8bffe7",
            PetState.ERROR: "#ff8e8e",
        }
        glow = palette.get(self.state, "#ff735e")
        c.create_oval(
            8 * self.scale,
            (18 + bob) * self.scale,
            272 * self.scale,
            (276 + bob) * self.scale,
            fill=glow,
            outline="",
            stipple="gray12",
        )
        c.create_oval(
            18 * self.scale,
            (28 + bob) * self.scale,
            262 * self.scale,
            (262 + bob) * self.scale,
            fill=glow,
            outline="",
            stipple="gray25",
        )
        c.create_oval(
            28 * self.scale,
            (42 + bob) * self.scale,
            252 * self.scale,
            (252 + bob) * self.scale,
            fill=glow,
            outline="",
            stipple="gray50",
        )

    def _draw_shadow(self, bob: float) -> None:
        c = self.canvas
        c.create_oval(
            46 * self.scale,
            (246 + bob) * self.scale,
            232 * self.scale,
            (278 + bob) * self.scale,
            fill="#2e3442",
            outline="",
            stipple="gray25",
        )
        c.create_oval(
            60 * self.scale,
            (252 + bob) * self.scale,
            218 * self.scale,
            (274 + bob) * self.scale,
            fill="#434c5f",
            outline="",
            stipple="gray50",
        )

    def _draw_body(self, bob: float) -> None:
        c = self.canvas
        body = self._body_color()
        c.create_oval(
            36 * self.scale,
            (48 + bob) * self.scale,
            244 * self.scale,
            (254 + bob) * self.scale,
            fill=body,
            outline="#5c0815",
            width=2,
        )
        c.create_oval(
            42 * self.scale,
            (54 + bob) * self.scale,
            238 * self.scale,
            (248 + bob) * self.scale,
            fill="#ff6a58",
            outline="",
            stipple="gray75",
        )
        c.create_oval(
            56 * self.scale,
            (68 + bob) * self.scale,
            224 * self.scale,
            (194 + bob) * self.scale,
            fill="#ffac97",
            outline="",
            stipple="gray50",
        )
        c.create_oval(
            70 * self.scale,
            (78 + bob) * self.scale,
            182 * self.scale,
            (140 + bob) * self.scale,
            fill="#ffe1d8",
            outline="",
            stipple="gray25",
        )
        c.create_oval(
            148 * self.scale,
            (96 + bob) * self.scale,
            220 * self.scale,
            (170 + bob) * self.scale,
            fill="#ff5b54",
            outline="",
            stipple="gray50",
        )
        c.create_arc(
            42 * self.scale,
            (48 + bob) * self.scale,
            244 * self.scale,
            (254 + bob) * self.scale,
            start=230,
            extent=110,
            style=tk.ARC,
            outline="#ffd4cb",
            width=max(2, int(3 * self.scale)),
        )
        c.create_arc(
            34 * self.scale,
            (46 + bob) * self.scale,
            246 * self.scale,
            (256 + bob) * self.scale,
            start=300,
            extent=120,
            style=tk.ARC,
            outline="#9f1625",
            width=max(2, int(3 * self.scale)),
        )

    def _draw_limbs(self, bob: float) -> None:
        c = self.canvas
        self._draw_claw(side="left", bob=bob)
        self._draw_claw(side="right", bob=bob)
        c.create_rectangle(
            90 * self.scale,
            (224 + bob) * self.scale,
            132 * self.scale,
            (254 + bob) * self.scale,
            fill="#151b23",
            outline="#2a303d",
            width=2,
        )
        c.create_rectangle(
            148 * self.scale,
            (224 + bob) * self.scale,
            190 * self.scale,
            (254 + bob) * self.scale,
            fill="#151b23",
            outline="#2a303d",
            width=2,
        )

    def _draw_claw(self, side: str, bob: float) -> None:
        c = self.canvas
        dark = "#222833"
        claw_red = "#ff3131"
        claw_red_shadow = "#cf1f2c"
        claw_highlight = "#ffb36a"
        joint_dark = "#91202a"
        swing_base = math.sin(self.tick / 10) * 4 * self.scale
        swing = swing_base if side == "left" else -swing_base

        if side == "left":
            c.create_line((86 * self.scale) + swing, (160 + bob) * self.scale, (106 * self.scale) + swing, (122 + bob) * self.scale, fill=dark, width=8, smooth=True)
            c.create_oval((78 * self.scale) + swing, (150 + bob) * self.scale, (94 * self.scale) + swing, (166 + bob) * self.scale, fill=joint_dark, outline=dark, width=2)
            c.create_oval((70 * self.scale) + swing, (138 + bob) * self.scale, (86 * self.scale) + swing, (154 + bob) * self.scale, fill=claw_red_shadow, outline=dark, width=2)
            c.create_oval((62 * self.scale) + swing, (126 + bob) * self.scale, (78 * self.scale) + swing, (142 + bob) * self.scale, fill=claw_red, outline=dark, width=2)
            c.create_polygon(
                (28 * self.scale) + swing, (72 + bob) * self.scale,
                (56 * self.scale) + swing, (58 + bob) * self.scale,
                (84 * self.scale) + swing, (68 + bob) * self.scale,
                (78 * self.scale) + swing, (92 + bob) * self.scale,
                (60 * self.scale) + swing, (108 + bob) * self.scale,
                (46 * self.scale) + swing, (102 + bob) * self.scale,
                (54 * self.scale) + swing, (90 + bob) * self.scale,
                (42 * self.scale) + swing, (82 + bob) * self.scale,
                fill=claw_red,
                outline=dark,
                width=3,
                smooth=True,
            )
            c.create_polygon(
                (34 * self.scale) + swing, (118 + bob) * self.scale,
                (64 * self.scale) + swing, (112 + bob) * self.scale,
                (78 * self.scale) + swing, (122 + bob) * self.scale,
                (64 * self.scale) + swing, (142 + bob) * self.scale,
                (40 * self.scale) + swing, (146 + bob) * self.scale,
                (24 * self.scale) + swing, (136 + bob) * self.scale,
                (30 * self.scale) + swing, (128 + bob) * self.scale,
                (44 * self.scale) + swing, (130 + bob) * self.scale,
                fill=claw_red_shadow,
                outline=dark,
                width=3,
                smooth=True,
            )
            c.create_oval((42 * self.scale) + swing, (82 + bob) * self.scale, (54 * self.scale) + swing, (98 + bob) * self.scale, fill=claw_highlight, outline="")
        else:
            c.create_line((194 * self.scale) + swing, (160 + bob) * self.scale, (174 * self.scale) + swing, (122 + bob) * self.scale, fill=dark, width=8, smooth=True)
            c.create_oval((186 * self.scale) + swing, (150 + bob) * self.scale, (202 * self.scale) + swing, (166 + bob) * self.scale, fill=joint_dark, outline=dark, width=2)
            c.create_oval((194 * self.scale) + swing, (138 + bob) * self.scale, (210 * self.scale) + swing, (154 + bob) * self.scale, fill=claw_red_shadow, outline=dark, width=2)
            c.create_oval((202 * self.scale) + swing, (126 + bob) * self.scale, (218 * self.scale) + swing, (142 + bob) * self.scale, fill=claw_red, outline=dark, width=2)
            c.create_polygon(
                (252 * self.scale) + swing, (72 + bob) * self.scale,
                (224 * self.scale) + swing, (58 + bob) * self.scale,
                (196 * self.scale) + swing, (68 + bob) * self.scale,
                (202 * self.scale) + swing, (92 + bob) * self.scale,
                (220 * self.scale) + swing, (108 + bob) * self.scale,
                (234 * self.scale) + swing, (102 + bob) * self.scale,
                (226 * self.scale) + swing, (90 + bob) * self.scale,
                (238 * self.scale) + swing, (82 + bob) * self.scale,
                fill=claw_red,
                outline=dark,
                width=3,
                smooth=True,
            )
            c.create_polygon(
                (246 * self.scale) + swing, (118 + bob) * self.scale,
                (216 * self.scale) + swing, (112 + bob) * self.scale,
                (202 * self.scale) + swing, (122 + bob) * self.scale,
                (216 * self.scale) + swing, (142 + bob) * self.scale,
                (240 * self.scale) + swing, (146 + bob) * self.scale,
                (256 * self.scale) + swing, (136 + bob) * self.scale,
                (250 * self.scale) + swing, (128 + bob) * self.scale,
                (236 * self.scale) + swing, (130 + bob) * self.scale,
                fill=claw_red_shadow,
                outline=dark,
                width=3,
                smooth=True,
            )
            c.create_oval((226 * self.scale) + swing, (82 + bob) * self.scale, (238 * self.scale) + swing, (98 + bob) * self.scale, fill=claw_highlight, outline="")

    def _draw_face(self, bob: float) -> None:
        c = self.canvas
        blink = self.tick % 120 > 108
        eye_h = 14 * self.scale if blink else 52 * self.scale
        iris = {
            PetState.WAKE_SUCCESS: "#7ffff6",
            PetState.VERIFYING: "#ffe88a",
            PetState.FORWARDING: "#9de3ff",
            PetState.GUARDING: "#a6ffb9",
            PetState.ERROR: "#ffd1d1",
        }.get(self.state, "#4ae9ff")
        for x in (88, 152):
            c.create_oval(
                x * self.scale,
                (108 + bob) * self.scale,
                (x + 42) * self.scale,
                (108 + bob + eye_h) * self.scale,
                fill="#08111a",
                outline="#0b1622",
                width=2,
            )
            if not blink:
                c.create_oval((x + 4) * self.scale, (118 + bob) * self.scale, (x + 36) * self.scale, (152 + bob) * self.scale, fill="#0d2130", outline="")
                c.create_oval((x + 8) * self.scale, (123 + bob) * self.scale, (x + 32) * self.scale, (147 + bob) * self.scale, fill=iris, outline="")
                c.create_oval((x + 14) * self.scale, (115 + bob) * self.scale, (x + 26) * self.scale, (127 + bob) * self.scale, fill="#ffffff", outline="")
                c.create_oval((x + 20) * self.scale, (132 + bob) * self.scale, (x + 28) * self.scale, (141 + bob) * self.scale, fill="#dafcff", outline="")

    def _draw_antennas(self, bob: float) -> None:
        c = self.canvas
        excitement = {
            PetState.SETUP: 8,
            PetState.IDLE: 0,
            PetState.LISTENING: 7,
            PetState.VERIFYING: 10,
            PetState.RECOGNIZING: 12,
            PetState.FORWARDING: 14,
            PetState.WAKE_SUCCESS: 18,
            PetState.GUARDING: 14,
            PetState.RUNNING: 10,
            PetState.ERROR: -8,
        }[self.state]
        wave = math.sin(self.tick / 6) * (4 if self.state != PetState.IDLE else 1.5)
        left_tip_x = 84 * self.scale
        left_tip_y = (48 + bob - excitement - wave) * self.scale
        right_tip_x = 196 * self.scale
        right_tip_y = (48 + bob - excitement + wave) * self.scale
        c.create_line(94 * self.scale, (94 + bob) * self.scale, left_tip_x, left_tip_y, fill="#232933", width=max(2, int(3 * self.scale)), smooth=True)
        c.create_line(186 * self.scale, (94 + bob) * self.scale, right_tip_x, right_tip_y, fill="#232933", width=max(2, int(3 * self.scale)), smooth=True)

    def _draw_status_bubble(self) -> None:
        c = self.canvas
        presentation = STATE_PRESENTATIONS[self.state]
        detail = self.detail_override or presentation.detail

        bubble_left = 18 * self.scale
        bubble_top = 24 * self.scale
        bubble_right = 262 * self.scale
        bubble_padding_x = 14 * self.scale
        bubble_padding_top = 14 * self.scale
        label_gap = 22 * self.scale
        detail_top_gap = 10 * self.scale
        bubble_padding_bottom = 14 * self.scale
        content_width = bubble_right - bubble_left - (bubble_padding_x * 2) - (30 * self.scale)

        detail_lines = self._estimate_lines(detail, max_chars_per_line=14)
        detail_line_height = 16 * self.scale
        detail_height = max(detail_line_height, detail_lines * detail_line_height)
        bubble_height = bubble_padding_top + label_gap + detail_top_gap + detail_height + bubble_padding_bottom
        bubble_height = max(78 * self.scale, bubble_height)
        bubble_bottom = bubble_top + bubble_height
        self._bubble_top = bubble_top
        self._bubble_bottom = bubble_bottom

        c.create_rectangle(
            bubble_left,
            bubble_top,
            bubble_right,
            bubble_bottom,
            fill="#f5fbff",
            outline="#d0dfe8",
            width=1,
        )
        c.create_text(
            bubble_left + bubble_padding_x,
            bubble_top + bubble_padding_top,
            text=presentation.label,
            anchor="w",
            fill="#22313f",
            font=("Microsoft YaHei UI", max(int(11 * self.scale), 9), "bold"),
        )
        c.create_text(
            bubble_left + bubble_padding_x,
            bubble_top + bubble_padding_top + label_gap,
            text=detail,
            anchor="nw",
            fill="#536575",
            width=content_width,
            font=("Microsoft YaHei UI", max(int(9 * self.scale), 8)),
        )
        c.create_line(
            bubble_left + 12 * self.scale,
            bubble_top + 10 * self.scale,
            bubble_right - 42 * self.scale,
            bubble_top + 10 * self.scale,
            fill="#ffffff",
        )

    def _draw_subtitle(self) -> None:
        if not self.subtitle_text or self.tick > self.subtitle_until_tick:
            return
        c = self.canvas
        left = 24 * self.scale
        right = 256 * self.scale
        bottom = 305 * self.scale
        lines = self._estimate_lines(self.subtitle_text, max_chars_per_line=16)
        height = max(32 * self.scale, (12 * self.scale) + lines * (14 * self.scale))
        top = bottom - height
        c.create_rectangle(left, top, right, bottom, fill="#112132", outline="#27445f", width=1)
        c.create_line(left + 10 * self.scale, top + 8 * self.scale, right - 10 * self.scale, top + 8 * self.scale, fill="#85d9ff")
        c.create_text(
            left + 10 * self.scale,
            top + 8 * self.scale,
            text=self.subtitle_text,
            anchor="nw",
            fill="#eff9ff",
            width=(right - left) - 20 * self.scale,
            font=("Microsoft YaHei UI", max(int(8 * self.scale), 8)),
        )

    def _draw_close_button(self) -> None:
        c = self.canvas
        left = 232 * self.scale
        top = self._bubble_top + 8 * self.scale
        right = 256 * self.scale
        bottom = top + 24 * self.scale
        self.close_button_bounds = (left, top, right, bottom)
        c.create_oval(left, top, right, bottom, fill="#15202b", outline="#44505b", width=1)
        c.create_text((left + right) / 2, (top + bottom) / 2, text="×", fill="#ffffff", font=("Microsoft YaHei UI", max(int(11 * self.scale), 9), "bold"))

    def _body_color(self) -> str:
        palette = {
            PetState.ERROR: "#c72727",
            PetState.SETUP: "#ff6a4e",
            PetState.VERIFYING: "#ff8b44",
            PetState.FORWARDING: "#ff5544",
            PetState.GUARDING: "#ff6d5e",
            PetState.RUNNING: "#ff4740",
            PetState.LISTENING: "#ff4e47",
            PetState.RECOGNIZING: "#ff5a4f",
            PetState.WAKE_SUCCESS: "#ff6c46",
            PetState.IDLE: "#ff4138",
        }
        return palette.get(self.state, "#ff3131")

    def _animate(self) -> None:
        self.tick = (self.tick + 1) % 240
        self.draw()
        self.root.after(50, self._animate)

    def _start_drag(self, event) -> None:
        if self._hit_close_button(event.x, event.y):
            self.root.destroy()
            return
        self.drag_start_x = event.x
        self.drag_start_y = event.y

    def _drag(self, event) -> None:
        x = self.root.winfo_x() + event.x - self.drag_start_x
        y = self.root.winfo_y() + event.y - self.drag_start_y
        self.root.geometry(f"+{x}+{y}")

    def _show_context_menu(self, event) -> None:
        menu = tk.Menu(self.root, tearoff=0)
        if self.menu_actions.get("toggle_listening"):
            menu.add_command(label="暂停/继续监听", command=self.menu_actions["toggle_listening"])
        if self.menu_actions.get("re_enroll"):
            menu.add_command(label="重新录入主人声音", command=self.menu_actions["re_enroll"])
        if self.menu_actions.get("test_microphone"):
            menu.add_command(label="测试麦克风", command=self.menu_actions["test_microphone"])
        if self.menu_actions.get("restart_openclaw"):
            menu.add_command(label="重启 OpenClaw", command=self.menu_actions["restart_openclaw"])
        menu.add_command(label="控制面板", command=self._open_control_panel)
        if self.menu_actions.get("open_log"):
            menu.add_command(label="打开日志", command=self.menu_actions["open_log"])
        if self.menu_actions.get("quit_app"):
            menu.add_separator()
            menu.add_command(label="退出", command=self.menu_actions["quit_app"])
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _open_control_panel(self) -> None:
        if self.control_panel and self.control_panel.winfo_exists():
            self.control_panel.lift()
            return

        panel = tk.Toplevel(self.root)
        panel.title("龙虾控制面板")
        panel.configure(bg="#f6fbff")
        panel.attributes("-topmost", True)
        panel.geometry(f"+{max(self.root.winfo_x() - 220, 20)}+{self.root.winfo_y() + 40}")
        self.control_panel = panel

        ttk.Label(panel, text="龙虾控制面板").pack(anchor="w", padx=14, pady=(12, 8))
        for key, label in (
            ("toggle_listening", "暂停 / 继续监听"),
            ("re_enroll", "重新录入主人声音"),
            ("test_microphone", "测试麦克风"),
            ("restart_openclaw", "重启 OpenClaw"),
            ("open_log", "打开日志"),
            ("quit_app", "退出桌宠"),
        ):
            if key not in self.menu_actions:
                continue
            ttk.Button(panel, text=label, command=self.menu_actions[key]).pack(fill="x", padx=14, pady=4)
        ttk.Button(panel, text="关闭", command=panel.destroy).pack(fill="x", padx=14, pady=(8, 14))

    def _hit_close_button(self, x: float, y: float) -> bool:
        if not self.close_button_bounds:
            return False
        left, top, right, bottom = self.close_button_bounds
        return left <= x <= right and top <= y <= bottom

    @staticmethod
    def _estimate_lines(text: str, max_chars_per_line: int) -> int:
        if not text:
            return 1
        explicit_lines = text.splitlines() or [text]
        line_count = 0
        for line in explicit_lines:
            line_count += max(1, math.ceil(len(line) / max_chars_per_line))
        return line_count
