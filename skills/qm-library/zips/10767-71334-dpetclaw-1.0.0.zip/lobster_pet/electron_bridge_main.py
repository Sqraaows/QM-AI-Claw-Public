from __future__ import annotations

from pathlib import Path

from .app import LobsterPetController
from .headless_window import HeadlessPetWindow


def main() -> int:
    controller = LobsterPetController(
        Path(__file__).resolve().parent.parent,
        window=HeadlessPetWindow(always_on_top=True, scale=0.5),
    )
    return controller.run()


if __name__ == "__main__":
    raise SystemExit(main())
