from __future__ import annotations

import io
import json
import warnings
import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np

try:
    import torch  # type: ignore
except Exception:  # pragma: no cover
    torch = None

try:
    import torchaudio  # type: ignore
except Exception:  # pragma: no cover
    torchaudio = None


VOICE_DIR = "voice_profiles"
OWNER_EMBEDDING = "owner_embedding.npy"
OWNER_META = "owner_meta.json"
FEATURE_VERSION = "speechbrain_ecapa_v1"
FALLBACK_FEATURE_VERSION = "fallback_spectral_v2"
MODEL_DIR = Path(r"C:\Users\super\lobster_pet_assets\speechbrain_ecapa")
MODEL_SOURCE = "speechbrain/spkrec-ecapa-voxceleb"
TARGET_SAMPLE_RATE = 16000
MIN_RMS_ENERGY = 0.0025
MIN_PEAK_ENERGY = 0.012
MIN_ACTIVE_FRAMES = 4
VERIFY_MIN_RMS_ENERGY = 0.0010
VERIFY_MIN_PEAK_ENERGY = 0.005
VERIFY_MIN_ACTIVE_FRAMES = 2


@dataclass(frozen=True)
class VerificationResult:
    accepted: bool
    score: float
    threshold: float


class SpeakerVerifier:
    def __init__(self, base_dir: Path, threshold: float = 0.82) -> None:
        self.base_dir = base_dir
        self.threshold = threshold
        self.profile_dir = base_dir / VOICE_DIR
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.embedding_path = self.profile_dir / OWNER_EMBEDDING
        self.meta_path = self.profile_dir / OWNER_META
        self.owner_embedding: np.ndarray | None = None
        self._classifier = None
        self._feature_version = FALLBACK_FEATURE_VERSION
        self._model_source = "local-fallback"
        self._load_classifier()
        self._load_profile()

    def has_profile(self) -> bool:
        return self.owner_embedding is not None

    def enroll_from_wav_samples(self, wav_samples: list[bytes], transcript: str) -> dict[str, object]:
        if not wav_samples:
            raise RuntimeError("没有可用的主人录音样本。")

        embeddings = [self._extract_embedding(sample, strict=True) for sample in wav_samples]
        merged = np.mean(np.stack(embeddings), axis=0)
        merged = self._normalize_vector(merged)
        self.owner_embedding = merged
        np.save(self.embedding_path, merged)
        meta = {
            "sample_count": len(wav_samples),
            "reference_text": transcript,
            "threshold": self.threshold,
            "feature_version": self._feature_version,
            "model_source": self._model_source,
        }
        self.meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return meta

    def verify_wav_bytes(self, wav_bytes: bytes) -> VerificationResult:
        if self.owner_embedding is None:
            return VerificationResult(accepted=False, score=0.0, threshold=self.threshold)

        try:
            sample_embedding = self._extract_embedding(wav_bytes, strict=False)
        except RuntimeError:
            return VerificationResult(accepted=False, score=0.0, threshold=self.threshold)

        sample_embedding = self._normalize_vector(sample_embedding)
        score = float(np.dot(self.owner_embedding, sample_embedding))
        return VerificationResult(
            accepted=score >= self.threshold,
            score=score,
            threshold=self.threshold,
        )

    def _load_profile(self) -> None:
        if not (self.embedding_path.exists() and self.meta_path.exists()):
            return

        try:
            meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
        except Exception:
            return

        if meta.get("feature_version") != self._feature_version:
            return

        try:
            embedding = np.load(self.embedding_path)
        except Exception:
            return

        self.owner_embedding = self._normalize_vector(embedding.astype(np.float32))

    def _load_classifier(self) -> None:
        try:
            if torch is None or torchaudio is None:
                self._classifier = None
                self._feature_version = FALLBACK_FEATURE_VERSION
                self._model_source = "local-fallback"
                return

            if not hasattr(torchaudio, "list_audio_backends"):
                torchaudio.list_audio_backends = lambda: []

            warnings.filterwarnings(
                "ignore",
                message="SpeechBrain could not find any working torchaudio backend.*",
            )
            warnings.filterwarnings(
                "ignore",
                message="`torch.cuda.amp.custom_fwd\\(args\\.\\.\\.\\)` is deprecated.*",
                category=FutureWarning,
            )
            warnings.filterwarnings(
                "ignore",
                message="`torch.cuda.amp.custom_bwd\\(args\\.\\.\\.\\)` is deprecated.*",
                category=FutureWarning,
            )
            from speechbrain.inference.speaker import EncoderClassifier
            from speechbrain.utils.fetching import LocalStrategy

            MODEL_DIR.mkdir(parents=True, exist_ok=True)
            self._classifier = EncoderClassifier.from_hparams(
                source=MODEL_SOURCE,
                savedir=str(MODEL_DIR),
                local_strategy=LocalStrategy.COPY,
            )
            self._feature_version = FEATURE_VERSION
            self._model_source = MODEL_SOURCE
        except Exception:
            self._classifier = None
            self._feature_version = FALLBACK_FEATURE_VERSION
            self._model_source = "local-fallback"

    def _extract_embedding(self, wav_bytes: bytes, strict: bool) -> np.ndarray:
        samples, sample_rate = self._read_wav_bytes(wav_bytes)
        if samples.size < 512:
            raise RuntimeError("录音太短，无法生成声纹。")

        if sample_rate != TARGET_SAMPLE_RATE:
            samples = self._resample(samples, sample_rate, TARGET_SAMPLE_RATE)
            sample_rate = TARGET_SAMPLE_RATE

        self._ensure_speech_present(samples, sample_rate, strict=strict)

        if self._classifier is None or torch is None:
            return self._extract_fallback_embedding(samples, sample_rate)

        waveform = torch.tensor(samples, dtype=torch.float32).unsqueeze(0)
        with torch.inference_mode():
            embedding = self._classifier.encode_batch(waveform)
        return embedding.detach().cpu().numpy().reshape(-1).astype(np.float32)

    @staticmethod
    def _extract_fallback_embedding(samples: np.ndarray, sample_rate: int) -> np.ndarray:
        frame_length = max(256, int(0.025 * sample_rate))
        hop_length = max(128, int(0.010 * sample_rate))
        frames = SpeakerVerifier._frame_signal(samples, frame_length, hop_length)
        if frames.size == 0:
            raise RuntimeError("录音太短，无法生成声纹。")

        window = np.hanning(frame_length).astype(np.float32)
        windowed = frames * window
        spectrum = np.abs(np.fft.rfft(windowed, axis=1)).astype(np.float32)
        spectrum = np.log1p(spectrum)

        mean_spec = np.mean(spectrum, axis=0)
        std_spec = np.std(spectrum, axis=0)
        frame_rms = np.sqrt(np.mean(frames ** 2, axis=1)).astype(np.float32)

        bins = 64
        if mean_spec.size < bins:
            mean_spec = np.pad(mean_spec, (0, bins - mean_spec.size))
            std_spec = np.pad(std_spec, (0, bins - std_spec.size))
        else:
            mean_spec = mean_spec[:bins]
            std_spec = std_spec[:bins]

        summary = np.array(
            [
                float(np.mean(frame_rms)),
                float(np.std(frame_rms)),
                float(np.max(frame_rms)),
                float(np.percentile(frame_rms, 75)),
            ],
            dtype=np.float32,
        )
        return np.concatenate([mean_spec, std_spec, summary], axis=0).astype(np.float32)

    @staticmethod
    def _ensure_speech_present(samples: np.ndarray, sample_rate: int, strict: bool) -> None:
        rms = float(np.sqrt(np.mean(samples ** 2)))
        peak = float(np.max(np.abs(samples)))
        min_rms = MIN_RMS_ENERGY if strict else VERIFY_MIN_RMS_ENERGY
        min_peak = MIN_PEAK_ENERGY if strict else VERIFY_MIN_PEAK_ENERGY
        min_active_frames = MIN_ACTIVE_FRAMES if strict else VERIFY_MIN_ACTIVE_FRAMES
        if rms < min_rms or peak < min_peak:
            raise RuntimeError("录音能量太低，像是静音或环境噪声。")

        frame_length = int(0.032 * sample_rate)
        hop_length = int(0.010 * sample_rate)
        frames = SpeakerVerifier._frame_signal(samples, frame_length, hop_length)
        if frames.size == 0:
            raise RuntimeError("录音太短，无法判断是否有人声。")

        frame_rms = np.sqrt(np.mean(frames ** 2, axis=1))
        active_threshold = max(rms * 1.12, min_rms * 1.02)
        active_frames = int(np.sum(frame_rms >= active_threshold))
        if active_frames < min_active_frames:
            raise RuntimeError("有效人声太少，像是环境音或短促杂音。")

    @staticmethod
    def _normalize_vector(vector: np.ndarray) -> np.ndarray:
        norm = float(np.linalg.norm(vector)) + 1e-9
        return vector / norm

    @staticmethod
    def _frame_signal(samples: np.ndarray, frame_length: int, hop_length: int) -> np.ndarray:
        if samples.size < frame_length:
            return np.empty((0, frame_length), dtype=np.float32)
        frame_count = 1 + (samples.size - frame_length) // hop_length
        frames = np.stack(
            [samples[index * hop_length : index * hop_length + frame_length] for index in range(frame_count)],
            axis=0,
        )
        return frames.astype(np.float32)

    @staticmethod
    def _resample(samples: np.ndarray, source_rate: int, target_rate: int) -> np.ndarray:
        if source_rate == target_rate:
            return samples.astype(np.float32)
        duration = samples.size / float(source_rate)
        source_positions = np.linspace(0.0, duration, num=samples.size, endpoint=False)
        target_length = max(1, int(duration * target_rate))
        target_positions = np.linspace(0.0, duration, num=target_length, endpoint=False)
        return np.interp(target_positions, source_positions, samples).astype(np.float32)

    @staticmethod
    def _read_wav_bytes(wav_bytes: bytes) -> tuple[np.ndarray, int]:
        with wave.open(io.BytesIO(wav_bytes), "rb") as wav_file:
            sample_rate = wav_file.getframerate()
            sample_width = wav_file.getsampwidth()
            channels = wav_file.getnchannels()
            frames = wav_file.readframes(wav_file.getnframes())

        dtype_map = {1: np.uint8, 2: np.int16, 4: np.int32}
        dtype = dtype_map.get(sample_width)
        if dtype is None:
            raise RuntimeError(f"不支持的音频位宽: {sample_width}")

        samples = np.frombuffer(frames, dtype=dtype).astype(np.float32)
        if channels > 1:
            samples = samples.reshape(-1, channels).mean(axis=1)

        if sample_width == 1:
            samples = (samples - 128.0) / 128.0
        elif sample_width == 2:
            samples = samples / 32768.0
        else:
            samples = samples / 2147483648.0
        return samples.astype(np.float32), sample_rate
