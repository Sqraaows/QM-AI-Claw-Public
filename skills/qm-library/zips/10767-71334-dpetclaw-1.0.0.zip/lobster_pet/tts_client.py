from __future__ import annotations

import json
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable


class SiliconFlowTTS:
    def __init__(
        self,
        api_key: str,
        model: str,
        voice: str,
        on_audio_ready: Callable[[str], None],
        on_error: Callable[[str], None],
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._voice = voice
        self._on_audio_ready = on_audio_ready
        self._on_error = on_error
        self._output_dir = Path(tempfile.gettempdir()) / "lobster_pet_audio"
        self._output_dir.mkdir(parents=True, exist_ok=True)

    def speak(self, text: str) -> None:
        worker = threading.Thread(target=self._request_audio, args=(text,), daemon=True)
        worker.start()

    def _request_audio(self, text: str) -> None:
        payload = {
            "model": self._model,
            "input": f"[S1]{text}",
            "voice": self._voice,
            "response_format": "wav",
            "sample_rate": 44100,
            "stream": False,
        }
        request = urllib.request.Request(
            "https://api.siliconflow.cn/v1/audio/speech",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                audio_bytes = response.read()
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="ignore")
            self._on_error(f"TTS 请求失败: HTTP {exc.code} {body[:180]}")
            return
        except Exception as exc:
            self._on_error(f"TTS 请求失败: {exc}")
            return

        output_path = self._output_dir / f"reply_{int(time.time() * 1000)}.wav"
        output_path.write_bytes(audio_bytes)
        self._on_audio_ready(str(output_path))
