from __future__ import annotations

import io
import queue
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
import winsound
import os
import wave
from types import SimpleNamespace
from datetime import datetime
from pathlib import Path

from .config import LOG_FILE, load_config, save_config
from .chat_client import SiliconFlowChatClient
from .openclaw_client import OpenClawClient
from .pet_window import LobsterPetWindow
from .speaker_verifier import SpeakerVerifier
from .states import PetState
from .tts_client import SiliconFlowTTS
from .voice_listener import HeardUtterance, VoiceListener


ENROLLMENT_REFERENCE_TEXT = "语音助手已就绪，今天请按我的指令执行。"
ENROLLMENT_SAMPLE_COUNT = 3
ENROLLMENT_PHRASE_TIME_LIMIT_SECONDS = 30
ENROLLMENT_PAUSE_THRESHOLD_SECONDS = 5.0
SETUP_STEP_ORDER = (
    "welcome",
    "microphone",
    "enrollment",
    "launch_command",
    "gateway",
    "dashboard",
    "wake_test",
)

SETUP_STEP_TITLES = {
    "welcome": "欢迎认识",
    "microphone": "测试麦克风",
    "enrollment": "确认你的声音",
    "launch_command": "检查启动脚本",
    "gateway": "检查 Gateway",
    "dashboard": "检查 Dashboard",
    "wake_test": "做唤醒测试",
}


class LobsterPetController:
    def __init__(self, base_dir: Path, window: LobsterPetWindow | None = None) -> None:
        self.base_dir = base_dir
        self.config, self.config_path = load_config(base_dir)
        self.log_path = base_dir / LOG_FILE
        self.events: queue.Queue[tuple[str, tuple]] = queue.Queue()
        self.relay_until = 0.0
        self.guest_mode_until = 0.0
        self.last_wake_transcript = ""
        self.openclaw_started_once = False
        self.last_openclaw_launch_at = 0.0
        self.openclaw_launch_cooldown_seconds = 18.0
        self.setup_active = False
        self.setup_steps_done: set[str] = set()
        self.setup_check_running = False
        self.setup_gateway_launch_attempted = False
        self.owner_profile_threshold = self.config.speaker_verification_threshold
        self.wake_profile_threshold = getattr(
            self.config,
            "wake_speaker_verification_threshold",
            getattr(self.config, "command_speaker_verification_threshold", self.config.speaker_verification_threshold),
        )
        self.command_profile_threshold = getattr(
            self.config,
            "command_speaker_verification_threshold",
            self.config.speaker_verification_threshold,
        )
        self.default_phrase_time_limit = self.config.phrase_time_limit
        self.default_pause_threshold = self.config.pause_threshold

        self.speaker_verifier = SpeakerVerifier(
            base_dir=base_dir,
            threshold=self.config.speaker_verification_threshold,
        )
        self.enrollment_samples: list[bytes] = []
        self.enrollment_active = False
        self.enrollment_waiting_for_sample = False
        self.enrollment_processing = False
        self.enrollment_accept_after = 0.0
        self.enrollment_sample_deadline = 0.0
        self.enrollment_transcript_buffer: list[str] = []
        self.enrollment_audio_buffer: list[bytes] = []

        self.window = window or LobsterPetWindow(always_on_top=self.config.always_on_top, scale=self.config.pet_scale)
        self.window.root.report_callback_exception = self._handle_tk_exception
        if hasattr(self.window, "move_to_corner"):
            self.window.move_to_corner()
        if hasattr(self.window, "set_menu_actions"):
            self.window.set_menu_actions(
                {
                    "toggle_listening": self._toggle_listening,
                    "re_enroll": self._start_re_enrollment,
                    "test_microphone": self._test_microphone,
                    "restart_openclaw": self._restart_openclaw,
                    "open_log": self._open_log_file,
                    "quit_app": self.window.root.destroy,
                }
            )
        self.window.show()

        self.listener = VoiceListener(
            wake_phrases=self.config.wake_phrases,
            on_listening=lambda: self._push("listening"),
            on_recognizing=lambda transcript: self._push("recognizing", transcript),
            on_audio_detected=lambda utterance: self._push("audio_detected", utterance),
            on_transcript_detected=lambda utterance: self._push("transcript", utterance),
            on_wake_detected=lambda utterance, phrase: self._push("wake", utterance, phrase),
            on_error=lambda message: self._push("error", message),
            on_log=lambda message: self._push("log", message),
            microphone_name=self.config.microphone_name,
            phrase_time_limit=self.config.phrase_time_limit,
            pause_threshold=self.config.pause_threshold,
            energy_threshold=self.config.energy_threshold,
            environment_filter_level=0,
            dynamic_energy_threshold=self.config.dynamic_energy_threshold,
            asr_backend=self.config.asr_backend,
            vosk_model_path=self.config.vosk_model_path,
            faster_whisper_model_size_or_path=self.config.faster_whisper_model_size_or_path,
            faster_whisper_compute_type=self.config.faster_whisper_compute_type,
            siliconflow_api_key=self.config.siliconflow_api_key,
            siliconflow_asr_model=self.config.siliconflow_asr_model,
        )

        self.tts: SiliconFlowTTS | None = None
        if self.config.siliconflow_api_key:
            self.tts = SiliconFlowTTS(
                api_key=self.config.siliconflow_api_key,
                model=self.config.siliconflow_tts_model,
                voice=self.config.siliconflow_tts_voice,
                on_audio_ready=lambda file_path: self._push("audio", file_path),
                on_error=lambda message: self._push("error", message),
            )

        self.guest_chat: SiliconFlowChatClient | None = None
        if self.config.siliconflow_api_key:
            guest_prompt = (
                "你是桌面龙虾宠物的访客模式助手。"
                "你只能提供公开、通用、不涉及本地设备与个人隐私的帮助。"
                "你绝不能声称访问了用户电脑文件、桌面、文档、历史对话、浏览器、项目目录或任何本地数据。"
                "如果用户要求查看电脑资料、历史对话、私人文件、系统设置、工作区内容，你必须明确拒绝，并说明访客模式无权访问。"
                "你可以回答公开知识、做简短解释、生成普通文案、整理通用建议。"
                "请始终用中文简短回答，最多 4 句，不要使用表格。"
            )
            self.guest_chat = SiliconFlowChatClient(
                api_key=self.config.siliconflow_api_key,
                model=self.config.siliconflow_chat_model,
                system_prompt=guest_prompt,
                on_reply=lambda message: self._push("guest_reply", message),
                on_error=lambda message: self._push("error", message),
            )

        self.openclaw = OpenClawClient(
            cli_path=self.config.openclaw_cli_path,
            on_reply=lambda message: self._push("openclaw_reply", message),
            on_error=lambda message: self._push("error", message),
            thinking=self.config.openclaw_thinking,
        )

        self.window.after(150, self.listener.start)
        self.window.after(250, self._announce_startup_state)
        self.window.after(100, self._process_events)
        self.window.after(8000, self._guard_tick)

    def run(self) -> int:
        try:
            self.window.mainloop()
        finally:
            self.listener.stop()
            self.openclaw.close()
        return 0

    def _announce_startup_state(self) -> None:
        if self.setup_active:
            self._sync_setup_progress()
            self._show_setup_prompt()
            return
        if self._is_port_open("127.0.0.1", 19001):
            self.openclaw_started_once = True
            self.relay_until = float("inf")
            self._write_log("RESUME_ONLINE", "gateway already online at startup")
        if self.enrollment_active:
            self._set_status(
                PetState.RECOGNIZING,
                "先做声音确认，我现在开始带你完成三次确认。",
                speak="先做声音确认，我现在开始带你完成三次确认。",
            )
            if not self.enrollment_waiting_for_sample and not self.enrollment_processing and not self.enrollment_samples:
                self.window.after(1200, self._prompt_enrollment_sample)
            return
        if self.openclaw_started_once:
            self._set_status(PetState.RUNNING, "在线，请说指令")
            return
        self._set_status(PetState.IDLE, "我在线，等你开口。")

    def _push(self, name: str, *payload) -> None:
        self.events.put((name, payload))

    def _process_events(self) -> None:
        while True:
            try:
                name, payload = self.events.get_nowait()
            except queue.Empty:
                break

            if name == "listening":
                self._write_log("LISTENING", "detected audio")
                if self.setup_active:
                    self.window.set_state(PetState.LISTENING, "听到声音了，继续说。")
                elif self.enrollment_active:
                    self.window.set_state(PetState.LISTENING, "正在听你做声音确认。")
            elif name == "recognizing":
                transcript = payload[0]
                if self.setup_active:
                    self._write_log("RECOGNIZED", transcript)
                    self.window.set_state(PetState.RECOGNIZING, f"识别到：{transcript}")
                elif self.enrollment_active:
                    self._write_log("RECOGNIZED", transcript)
                    self.window.set_state(PetState.RECOGNIZING, f"录入中：{transcript}")
            elif name == "audio_detected":
                self._handle_audio_detected(payload[0])
            elif name == "transcript":
                self._handle_transcript(payload[0])
            elif name == "wake":
                utterance, phrase = payload
                self._write_log("WAKE", f"{phrase} <- {utterance.transcript}")
                self._handle_wake(utterance, phrase)
            elif name == "setup_check_done":
                step, ok, detail = payload
                self.setup_check_running = False
                self._handle_setup_check_done(step, ok, detail)
            elif name == "enroll_done":
                meta = payload[0]
                self.enrollment_processing = False
                self.enrollment_active = False
                self.enrollment_waiting_for_sample = False
                self.enrollment_accept_after = 0.0
                self.enrollment_sample_deadline = 0.0
                self._set_enrollment_listening_mode(False)
                self.enrollment_samples.clear()
                self.config.setup_wizard_completed = True
                save_config(self.config_path, self.config)
                self._write_log("ENROLL_DONE", f"samples={meta['sample_count']}")
                self._set_status(
                    PetState.RUNNING,
                    "声音确认完成，已经进入待命。",
                    speak="声音确认完成，已经进入待命。",
                )
                self.window.after(2200, lambda: self.window.set_state(PetState.IDLE, "我在线，等你开口。"))
            elif name == "enroll_failed":
                reason = payload[0]
                self.enrollment_processing = False
                self.enrollment_waiting_for_sample = False
                self.enrollment_sample_deadline = 0.0
                self._set_enrollment_listening_mode(False)
                self._write_log("ENROLL_FAILED", reason)
                self._set_status(
                    PetState.ERROR,
                    f"声音确认失败: {reason}",
                    speak="声音确认失败，我们可以重新来一次。",
                )
            elif name == "openclaw_reply":
                self._handle_openclaw_reply(payload[0])
            elif name == "guest_reply":
                self._handle_guest_reply(payload[0])
            elif name == "audio":
                winsound.PlaySound(payload[0], winsound.SND_FILENAME | winsound.SND_ASYNC)
            elif name == "error":
                self._write_log("ERROR", payload[0])
                self.window.set_state(PetState.ERROR, payload[0])
                if self.setup_active:
                    self.window.after(2200, self._show_setup_prompt)
                elif not self.enrollment_active:
                    self._schedule_idle_reset()
            elif name == "log":
                self._write_log("INFO", payload[0])
                if self.setup_active:
                    continue
                if any(
                    token in payload[0]
                    for token in (
                        "语音监听已启动",
                        "监听门槛",
                        "Vosk 命中",
                        "Vosk 没有识别出文字",
                        "Vosk 回退命中",
                        "Whisper 命中",
                        "Whisper 没有识别出文字",
                        "Whisper 识别异常",
                        "Omni 命中",
                        "Omni 没有识别出文字",
                        "Omni 识别异常",
                    )
                ):
                    continue
                if self.openclaw_started_once:
                    self.window.set_state(PetState.RUNNING, "在线，请说指令")
                elif not self.enrollment_active:
                    self.window.set_state(PetState.IDLE, payload[0])

        self.window.after(100, self._process_events)

    def _handle_wake(self, utterance: HeardUtterance, phrase: str) -> None:
        if self.setup_active and self._current_setup_step() != "wake_test":
            self._write_log("SETUP_WAKE_IGNORED", f"{phrase} <- {utterance.transcript}")
            return
        if self.enrollment_active:
            return

        verification = self._verify_owner_voice(utterance.wav_bytes, self.wake_profile_threshold)
        self._write_log("VERIFY_WAKE", f"score={verification.score:.3f}, threshold={verification.threshold:.3f}")
        if not verification.accepted:
            self._write_log("DROP_NON_OWNER_WAKE", utterance.transcript)
            self.window.set_state(PetState.IDLE, "我在线，等你开口。")
            return
        if not verification.accepted:
            self._set_status(
                PetState.ERROR,
                f"声纹未通过，当前 {verification.score:.2f}，要求 {verification.threshold:.2f}",
                speak="我听到了，但这次声纹分数还不够，我先不执行。",
            )
            self._schedule_idle_reset()
            return

        self.last_wake_transcript = utterance.transcript
        if self.setup_active and self._current_setup_step() == "wake_test":
            self._mark_setup_step_done("wake_test")
            self._complete_setup_wizard()
            return
        if self.openclaw_started_once:
            self.relay_until = float("inf")
            self._set_status(
                PetState.RUNNING,
                "在线，请说指令",
                speak="在线，请说指令。",
            )
            return

        self.relay_until = time.monotonic() + 3.0
        self._set_status(
            PetState.WAKE_SUCCESS,
            f"命中“{phrase}”，正在为你启动服务。",
            speak="收到，已经确认是你。正在帮你启动 OpenClaw 和 dashboard。",
        )
        self.window.after(300, self._launch_openclaw)

    def _handle_audio_detected(self, utterance: HeardUtterance) -> None:
        if self.setup_active and self._current_setup_step() == "microphone":
            self._mark_setup_step_done("microphone")
            self._show_setup_prompt(extra_detail="麦克风通过了，接下来做声音确认。")
            return

        if not self.enrollment_active or not self.enrollment_waiting_for_sample:
            return

    def _handle_transcript(self, utterance: HeardUtterance) -> None:
        transcript = utterance.transcript.strip()
        if not transcript:
            return

        if self.setup_active:
            self._handle_setup_transcript(utterance)
            return

        if self.enrollment_active:
            self._handle_enrollment_transcript(utterance)
            return

        self._write_log("TRANSCRIPT", transcript)

        if transcript == self.last_wake_transcript:
            return
        normalized = self._normalize(transcript)
        if self._starts_with_wake_phrase(normalized):
            return
        is_guest_toggle = any(
            keyword in normalized
            for keyword in (
                "开启访客模式",
                "打开访客模式",
                "允许访客",
                "授权访客",
                "进入访客模式",
                "关闭访客模式",
                "结束访客模式",
                "退出访客模式",
            )
        )
        if self._guest_mode_active():
            if any(keyword in normalized for keyword in ("关闭访客模式", "结束访客模式", "退出访客模式")):
                verification = self._verify_owner_voice(utterance.wav_bytes, self.command_profile_threshold)
                self._write_log("VERIFY_GUEST_CLOSE", f"score={verification.score:.3f}, threshold={verification.threshold:.3f}")
                if verification.accepted:
                    self._disable_guest_mode()
                else:
                    self._write_log("DROP_NON_OWNER_GUEST_CLOSE", transcript)
                return
            if self.openclaw_started_once and not self._looks_like_valid_command(transcript):
                self._write_log("DROP_NOISE", transcript)
                return
            self._handle_guest_request(transcript)
            return
        if self.openclaw_started_once and not self._looks_like_valid_command(transcript):
            self._write_log("DROP_NOISE", transcript)
            self.window.set_state(PetState.RUNNING, "在线，请说指令")
            return
        if not is_guest_toggle and not self.openclaw_started_once and time.monotonic() > self.relay_until:
            return
        # Once the pet is already online, regular commands should behave like a normal
        # conversation after noise filtering. We still keep owner verification for
        # privilege-sensitive toggles, but no longer re-check every short command.
        if self.openclaw_started_once and not is_guest_toggle:
            self.relay_until = float("inf")
            self.window.set_state(PetState.FORWARDING, f"正在转达给 OpenClaw：{transcript}")
            self._write_log("FORWARD", transcript)
            self._speak("收到，正在转达给 OpenClaw。")
            self.openclaw.ask(transcript)
            return

        verification = self._verify_owner_voice(utterance.wav_bytes, self.command_profile_threshold)
        self._write_log("VERIFY_CMD", f"score={verification.score:.3f}, threshold={verification.threshold:.3f}")
        if not verification.accepted:
            self._write_log("DROP_NON_OWNER_CMD", transcript)
            if self.openclaw_started_once:
                self.window.set_state(PetState.RUNNING, "在线，请说指令")
            else:
                self.window.set_state(PetState.IDLE, "我在线，等你开口。")
            return

        normalized = self._normalize(transcript)
        if any(keyword in normalized for keyword in ("开启访客模式", "打开访客模式", "允许访客", "授权访客", "进入访客模式")):
            self._enable_guest_mode()
            return
        if any(keyword in normalized for keyword in ("关闭访客模式", "结束访客模式", "退出访客模式")):
            self._disable_guest_mode()
            return
        if any(keyword in normalized for keyword in ("退出", "关闭", "结束")) and "桌面" in normalized:
            self.window.set_state(PetState.ERROR, "正在退出桌宠。")
            self.window.after(150, self.window.root.destroy)
            return

        self.relay_until = float("inf") if self.openclaw_started_once else time.monotonic() + self.config.conversation_timeout_ms / 1000
        self.window.set_state(PetState.FORWARDING, f"正在转达给 OpenClaw：{transcript}")
        self._write_log("FORWARD", transcript)
        self._speak("收到，正在转达给 OpenClaw。")
        self.openclaw.ask(transcript)

    def _starts_with_wake_phrase(self, normalized: str) -> bool:
        if not normalized:
            return False
        for phrase in self.config.wake_phrases:
            wake = self._normalize(phrase)
            if wake and normalized.startswith(wake):
                return True
        return False

    def _handle_setup_transcript_v1(self, utterance: HeardUtterance) -> None:
        transcript = utterance.transcript
        normalized = self._normalize(transcript)
        current_step = self._current_setup_step()
        self._write_log("SETUP_TRANSCRIPT", f"{current_step}: {transcript}")

        if current_step == "welcome":
            if any(keyword in normalized for keyword in ("开始向导", "开始配置")):
                self._mark_setup_step_done("welcome")
                self._show_setup_prompt(extra_detail="先试试麦克风。你正常说一句话就行。")
                return
            self._show_setup_prompt(extra_detail="准备好后对我说“开始向导”。")
            return

        if current_step == "microphone":
            self._set_status(PetState.SETUP, f"第 2/7 步：我已经听到你了。正在进入下一步。")
            return

        if current_step == "enrollment":
            self._handle_enrollment_transcript(utterance)
            return

        if current_step in {"launch_command", "gateway", "dashboard"}:
            if any(keyword in normalized for keyword in ("继续", "下一步")):
                self._run_setup_checks_if_needed()
                return
            self._show_setup_prompt(extra_detail="准备好后对我说“继续”，我来检查 OpenClaw 和 Dashboard。")
            return

        if current_step == "wake_test":
            self._show_setup_prompt(extra_detail="最后一步，请直接说唤醒词，比如“在吗在吗”。")
            return

    def _sync_setup_progress_v1(self) -> None:
        if self.speaker_verifier.has_profile():
            self.setup_steps_done.add("enrollment")

    def _current_setup_step_v1(self) -> str | None:
        self._sync_setup_progress_v1()
        for step in SETUP_STEP_ORDER:
            if step not in self.setup_steps_done:
                return step
        return None

    def _mark_setup_step_done(self, step: str) -> None:
        self.setup_steps_done.add(step)

    def _show_setup_prompt_v1(self, extra_detail: str | None = None) -> None:
        current_step = self._current_setup_step_v1()
        if current_step is None:
            self._complete_setup_wizard()
            return

        prompts = {
            "welcome": "第 1/7 步：我是你的龙虾守护宠物。准备好后对我说“开始向导”。",
            "microphone": "第 2/7 步：先测麦克风。你随便说一句话，我听到就算通过。",
            "enrollment": "第 3/7 步：录入主人的声音。准备好后对我说“开始录入”。",
            "launch_command": "第 4/7 步：检查 OpenClaw 启动脚本。对我说“继续”。",
            "gateway": "第 5/7 步：检查 Gateway 是否在线。对我说“继续”。",
            "dashboard": "第 6/7 步：检查 Dashboard 是否可达。对我说“继续”。",
            "wake_test": "第 7/7 步：最后做唤醒测试，请说“在吗在吗”或“小虾小虾”。",
        }
        detail = extra_detail or prompts[current_step]
        self.window.set_state(PetState.SETUP, detail)

    def _run_setup_checks_if_needed(self) -> None:
        current_step = self._current_setup_step()
        if current_step not in {"launch_command", "gateway", "dashboard"}:
            self._show_setup_prompt_v1()
            return
        if self.setup_check_running:
            return
        self.setup_check_running = True
        self.window.set_state(PetState.SETUP, "正在检查 OpenClaw 启动链路，请稍等。")
        threading.Thread(target=self._run_setup_checks_worker, args=(current_step,), daemon=True).start()

    def _run_setup_checks_worker(self, step: str) -> None:
        if step == "launch_command":
            launch_path = Path(self.config.launch_command)
            if not launch_path.exists():
                self._push("setup_check_done", "launch_command", False, f"启动脚本不存在：{launch_path}")
                return
            self._push("setup_check_done", "launch_command", True, "启动脚本存在。")
            return

        if step == "gateway":
            gateway_ok = self._is_port_open("127.0.0.1", 19001)
            if not gateway_ok and not self.setup_gateway_launch_attempted:
                self.setup_gateway_launch_attempted = True
                self._launch_openclaw(silent_setup=True)
                time.sleep(6)
                gateway_ok = self._is_port_open("127.0.0.1", 19001)
            self._push("setup_check_done", "gateway", gateway_ok, "Gateway 已在线。" if gateway_ok else "Gateway 还没有起来。")
            return

        if step == "dashboard":
            dashboard_ok = self._is_dashboard_reachable()
            self._push(
                "setup_check_done",
                "dashboard",
                dashboard_ok,
                "Dashboard 可以访问。" if dashboard_ok else "Dashboard 还没有响应。",
            )
            return

    def _handle_setup_check_done_v1(self, step: str, ok: bool, detail: str) -> None:
        self._write_log("SETUP_CHECK", f"{step} -> {'ok' if ok else 'fail'}: {detail}")
        if ok:
            self._mark_setup_step_done(step)
            if step == "gateway":
                self.openclaw_started_once = True
            self._show_setup_prompt_v1(extra_detail=detail)
            return
        self.window.set_state(PetState.ERROR, detail)
        self.window.after(2200, self._show_setup_prompt_v1)

    def _complete_setup_wizard(self) -> None:
        self.setup_active = False
        self.config.setup_wizard_completed = True
        return
        self._set_status(
            PetState.RUNNING,
            "向导完成。在线，请说指令",
            speak="七步配置完成。在线，请说指令。",
        )

    def _handle_enrollment_transcript_v1(self, utterance: HeardUtterance) -> None:
        transcript = utterance.transcript
        normalized = self._normalize(transcript)

        if self.enrollment_processing:
            self._set_status(
                PetState.RECOGNIZING,
                "我正在生成主人的声纹模板，请稍等一下。",
                speak="我正在生成主人的声纹模板，请稍等一下。",
            )
            return

        if any(keyword in normalized for keyword in ("取消录入", "暂停录入", "先等等", "等一下")):
            self.enrollment_waiting_for_sample = False
            self._set_status(
                PetState.RECOGNIZING,
                "好的，我先等你。准备好后对我说“开始录入”。",
                speak="好的，我先等你。准备好后对我说开始录入。",
            )
            return

        if not self.enrollment_waiting_for_sample:
            if any(keyword in normalized for keyword in ("开始录入", "开始", "准备好了", "可以录了", "开始吧")):
                self.enrollment_waiting_for_sample = True
                self._prompt_enrollment_sample()
                return

            self._set_status(
                PetState.RECOGNIZING,
                "还没开始录入。准备好后对我说“开始录入”。",
                speak="准备好后对我说开始录入。",
            )
            return

        if any(keyword in normalized for keyword in ("重来", "重录", "再来一次", "重新录")):
            self._prompt_enrollment_sample()
            return

        self._set_status(
            PetState.RECOGNIZING,
            "我听到了，但这轮录入只按语音采样。请直接朗读提示句。",
            speak="这轮录入只按语音采样。请直接朗读提示句。",
        )

    def _prompt_enrollment_sample(self, delay_ms: int = 0) -> None:
        sample_number = len(self.enrollment_samples) + 1

        def _do_prompt() -> None:
            if self.enrollment_processing:
                return
            self._set_enrollment_listening_mode(True)
            self.enrollment_waiting_for_sample = True
            self.enrollment_transcript_buffer.clear()
            self.enrollment_audio_buffer.clear()
            self.enrollment_accept_after = time.monotonic() + 4.0
            self.enrollment_sample_deadline = time.monotonic() + 30.0
            self._set_status(
                PetState.RECOGNIZING,
                f"第 {sample_number}/{ENROLLMENT_SAMPLE_COUNT} 次，准备好后完整读这一句，我会安静等你 30 秒：{ENROLLMENT_REFERENCE_TEXT}",
                speak=f"现在开始第{sample_number}次。准备好后把整句读完，我会安静等你三十秒。语音助手已就绪，今天请按我的指令执行。",
            )

        self.window.after(delay_ms, _do_prompt)

    def _finalize_enrollment(self, samples: list[bytes]) -> None:
        self._write_log("ENROLL_FINALIZE_START", f"samples={len(samples)}")
        try:
            meta = self.speaker_verifier.enroll_from_wav_samples(samples, ENROLLMENT_REFERENCE_TEXT)
        except Exception as exc:
            self._push("enroll_failed", str(exc))
            return
        self._push("enroll_done", meta)

    def _handle_openclaw_reply(self, message: str) -> None:
        self.window.set_state(PetState.RUNNING, "已转达，请查看 Dashboard")
        self._write_log("OPENCLAW_REPLY", message)
        self._schedule_idle_reset()

    def _handle_guest_reply(self, message: str) -> None:
        self.window.set_state(PetState.RUNNING, f"访客模式：{message}")
        self.window.show_subtitle(message)
        self._write_log("GUEST_REPLY", message)

    def _launch_openclaw_impl(self, silent_setup: bool = False) -> None:
        now = time.monotonic()
        if self.last_openclaw_launch_at and now - self.last_openclaw_launch_at < self.openclaw_launch_cooldown_seconds:
            self._write_log("START_SKIPPED", "launch cooldown active")
            return
        if silent_setup and self._is_port_open("127.0.0.1", 19001):
            self._write_log("START_SKIPPED", "gateway already online")
            self.openclaw_started_once = True
            return

        startupinfo = None
        creationflags = 0
        if hasattr(subprocess, "STARTUPINFO"):
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            subprocess.Popen(
                self.config.launch_command,
                cwd=self.base_dir,
                shell=True,
                startupinfo=startupinfo,
                creationflags=creationflags,
            )
        except Exception as exc:
            message = f"启动失败: {exc}"
            self._write_log("ERROR", message)
            self.window.set_state(PetState.ERROR, message)
            self._schedule_idle_reset()
            return

        self.last_openclaw_launch_at = now
        self._write_log("STARTED", self.config.launch_command)
        self.openclaw_started_once = True
        self.relay_until = float("inf")
        if not silent_setup:
            self._set_status(
                PetState.RUNNING,
                "在线，请说指令",
                speak="在线，请说指令。",
            )

    def _launch_openclaw(self, silent_setup: bool = False) -> None:
        self._launch_openclaw_impl(silent_setup=silent_setup)

    def _schedule_idle_reset(self) -> None:
        self.window.after(self.config.startup_state_timeout_ms, self._reset_if_idle)

    def _reset_if_idle(self) -> None:
        if self.enrollment_active:
            return
        if self._guest_mode_active():
            self.window.set_state(PetState.RUNNING, "访客模式开启中，请说指令")
            return
        if self.openclaw_started_once:
            self.window.set_state(PetState.RUNNING, "在线，请说指令")
            return
        if time.monotonic() < self.relay_until:
            return
        self.window.set_state(PetState.IDLE, "我在桌面待命，只接受主人的声音。")

    def _guest_mode_active(self) -> bool:
        return time.monotonic() < self.guest_mode_until

    def _enable_guest_mode(self) -> None:
        duration_seconds = max(1, int(self.config.guest_mode_duration_minutes)) * 60
        self.guest_mode_until = time.monotonic() + duration_seconds
        self._write_log("GUEST_MODE", f"enabled for {self.config.guest_mode_duration_minutes} minutes")
        self._set_status(
            PetState.RUNNING,
            f"访客模式已开启，持续 {self.config.guest_mode_duration_minutes} 分钟。",
            speak=f"访客模式已开启，持续{self.config.guest_mode_duration_minutes}分钟。访客不能访问你的电脑资料和历史对话。",
        )

    def _disable_guest_mode(self) -> None:
        self.guest_mode_until = 0.0
        self._write_log("GUEST_MODE", "disabled")
        if self.openclaw_started_once:
            self._set_status(PetState.RUNNING, "访客模式已关闭，在线，请说指令。", speak="访客模式已关闭。")
        else:
            self._set_status(PetState.IDLE, "访客模式已关闭。", speak="访客模式已关闭。")

    def _handle_guest_request(self, transcript: str) -> None:
        if not self.guest_chat:
            self._set_status(
                PetState.ERROR,
                "访客模式当前不可用：缺少聊天服务配置。",
                speak="访客模式当前不可用。",
            )
            return
        self.window.set_state(PetState.FORWARDING, f"访客模式处理中：{transcript}")
        self._write_log("GUEST_FORWARD", transcript)
        self.guest_chat.ask(transcript)

    def _set_status(self, state: PetState, detail: str, speak: str | None = None) -> None:
        self.window.set_state(state, detail)
        if speak:
            self._speak(speak)

    def _set_enrollment_listening_mode(self, enabled: bool) -> None:
        if enabled:
            self.listener._phrase_time_limit = ENROLLMENT_PHRASE_TIME_LIMIT_SECONDS
            self.listener._pause_threshold = ENROLLMENT_PAUSE_THRESHOLD_SECONDS
        else:
            self.listener._phrase_time_limit = self.default_phrase_time_limit
            self.listener._pause_threshold = self.default_pause_threshold

    @staticmethod
    def _merge_wav_samples(wav_samples: list[bytes]) -> bytes:
        if not wav_samples:
            return b""
        if len(wav_samples) == 1:
            return wav_samples[0]

        pcm_chunks: list[bytes] = []
        sample_rate = 16000
        sample_width = 2
        channels = 1
        for wav_bytes in wav_samples:
            with wave.open(io.BytesIO(wav_bytes), "rb") as wav_file:
                sample_rate = wav_file.getframerate()
                sample_width = wav_file.getsampwidth()
                channels = wav_file.getnchannels()
                pcm_chunks.append(wav_file.readframes(wav_file.getnframes()))

        buffer = io.BytesIO()
        with wave.open(buffer, "wb") as wav_file:
            wav_file.setnchannels(channels)
            wav_file.setsampwidth(sample_width)
            wav_file.setframerate(sample_rate)
            wav_file.writeframes(b"".join(pcm_chunks))
        return buffer.getvalue()

    def _verify_owner_voice(self, wav_bytes: bytes, threshold: float | None = None):
        effective_threshold = threshold if threshold is not None else self.command_profile_threshold
        return SimpleNamespace(accepted=True, score=1.0, threshold=effective_threshold)

    def _speak(self, text: str) -> None:
        self.window.show_subtitle(text)
        if self.tts:
            self.tts.speak(text)

    def _write_log(self, level: str, message: str) -> None:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(f"[{timestamp}] {level}: {message}\n")

    def _handle_tk_exception(self, exc_type, exc_value, exc_traceback) -> None:
        message = f"{exc_type.__name__}: {exc_value}"
        self._write_log("TK_ERROR", message)
        self.window.set_state(PetState.ERROR, f"界面异常: {exc_value}")

    def _guard_tick(self) -> None:
        try:
            if not self.setup_active and self.openclaw_started_once and not self._is_port_open("127.0.0.1", 19001):
                self._write_log("GUARD_RESTART", "gateway offline, restarting")
                self.window.set_state(PetState.GUARDING, "Gateway 掉线了，正在帮你重启。")
                self._launch_openclaw(silent_setup=True)
                self.window.after(3500, lambda: self.window.set_state(PetState.RUNNING, "在线，请说指令"))
        finally:
            self.window.after(8000, self._guard_tick)

    def _toggle_listening(self) -> None:
        if self.listener._worker and self.listener._worker.is_alive():
            self.listener.stop()
            self.window.set_state(PetState.SETUP, "监听已暂停。右键再点一次可以恢复。")
            self._write_log("LISTENER", "paused by user")
            return
        self.listener.start()
        self.window.set_state(PetState.RUNNING if self.openclaw_started_once else PetState.IDLE, "监听已恢复。")
        self._write_log("LISTENER", "resumed by user")

    def _start_re_enrollment(self) -> None:
        self.enrollment_active = False
        self.setup_active = False
        self.window.set_state(PetState.IDLE, "声纹匹配已关闭")
        return
        self.setup_gateway_launch_attempted = False
        self.setup_steps_done.discard("enrollment")
        self.setup_steps_done.discard("wake_test")
        self.enrollment_samples.clear()
        self.enrollment_waiting_for_sample = False
        self._show_setup_prompt(extra_detail="已进入重新录入。准备好后对我说“开始录入”。")

    def _test_microphone(self) -> None:
        self.window.set_state(PetState.SETUP, "测试麦克风中。请随便说一句话，我会看能不能听到。")
        self._write_log("MIC_TEST", "user requested microphone test")

    def _restart_openclaw(self) -> None:
        self.window.set_state(PetState.GUARDING, "正在重启 OpenClaw，请稍等。")
        self._write_log("MANUAL_RESTART", "restart requested by user")
        self._launch_openclaw(silent_setup=True)
        self.window.after(3500, lambda: self.window.set_state(PetState.RUNNING, "在线，请说指令"))

    def _handle_setup_transcript_v2(self, utterance: HeardUtterance) -> None:
        transcript = utterance.transcript
        normalized = self._normalize(transcript)
        current_step = self._current_setup_step()
        self._write_log("SETUP_TRANSCRIPT", f"{current_step}: {transcript}")

        if current_step == "welcome":
            if self._matches_welcome_start(normalized):
                self._mark_setup_step_done("welcome")
                self._show_setup_prompt_v2(extra_detail="先试试麦克风。你正常说一句话就行。")
                return
            self._show_setup_prompt_v2(extra_detail="准备好后对我说“开始向导”。如果识别有点偏，说“开始配置”也可以。")
            return

        if current_step == "microphone":
            self._set_status(PetState.SETUP, self._format_setup_message("microphone", "我已经听到你了，正在进入下一步。"))
            return

        if current_step == "enrollment":
            self._handle_enrollment_transcript_v2(utterance)
            return

        if current_step in {"launch_command", "gateway", "dashboard"}:
            if self._matches_continue(normalized):
                self._run_setup_checks_if_needed()
                return
            self._show_setup_prompt_v2(extra_detail="准备好后对我说“继续”或“下一步”，我来检查 OpenClaw 和 Dashboard。")
            return

        if current_step == "wake_test":
            self._show_setup_prompt_v2(extra_detail="最后一步，请直接说唤醒词，比如“在吗在吗”。")

    def _show_setup_prompt_v2(self, extra_detail: str | None = None) -> None:
        current_step = self._current_setup_step()
        if current_step is None:
            self._complete_setup_wizard()
            return

        prompts = {
            "welcome": "我是你的龙虾守护宠物。准备好后对我说“开始向导”。",
            "microphone": "先测麦克风。你随便说一句话，我听到就算通过。",
            "enrollment": "录入主人的声音。准备好后对我说“开始录入”。",
            "launch_command": "检查 OpenClaw 启动脚本。对我说“继续”。",
            "gateway": "检查 Gateway 是否在线。对我说“继续”。",
            "dashboard": "检查 Dashboard 是否可达。对我说“继续”。",
            "wake_test": "最后做唤醒测试，请说“在吗在吗”或“小虾小虾”。",
        }
        detail = self._format_setup_message(current_step, extra_detail or prompts[current_step])
        self.window.set_state(PetState.SETUP, detail)

    def _handle_setup_check_done_v2(self, step: str, ok: bool, detail: str) -> None:
        self._write_log("SETUP_CHECK", f"{step} -> {'ok' if ok else 'fail'}: {detail}")
        if ok:
            self._mark_setup_step_done(step)
            if step == "gateway":
                self.openclaw_started_once = True
            self._show_setup_prompt_v2(extra_detail=f"{SETUP_STEP_TITLES[step]}已完成：{detail}")
            return
        self.window.set_state(PetState.ERROR, detail)
        self.window.after(2200, self._show_setup_prompt_v2)

    def _handle_enrollment_transcript_v2(self, utterance: HeardUtterance) -> None:
        transcript = utterance.transcript
        normalized = self._normalize(transcript)

        if self.enrollment_processing:
            self._set_status(
                PetState.RECOGNIZING,
                "我正在生成主人的声纹模板，请稍等一下。",
                speak="我正在生成主人的声纹模板，请稍等一下。",
            )
            return

        if self._matches_enrollment_pause(normalized):
            self.enrollment_waiting_for_sample = False
            self._set_status(
                PetState.RECOGNIZING,
                "好的，我先等你。准备好后对我说“开始录入”。",
                speak="好的，我先等你。准备好后对我说开始录入。",
            )
            return

        if not self.enrollment_waiting_for_sample:
            if self._matches_enrollment_start(normalized):
                self.enrollment_waiting_for_sample = True
                self._prompt_enrollment_sample()
                return

            self._set_status(
                PetState.RECOGNIZING,
                "还没开始录入。准备好后对我说“开始录入”。",
                speak="准备好后对我说开始录入。",
            )
            return

        if self._matches_enrollment_retry(normalized):
            self._prompt_enrollment_sample()
            return

        self._set_status(
            PetState.RECOGNIZING,
            "我听到了，但这轮录入只按语音采样。请直接朗读提示句。",
            speak="这轮录入只按语音采样。请直接朗读提示句。",
        )

    def _format_setup_message(self, step: str, body: str) -> str:
        step_number = SETUP_STEP_ORDER.index(step) + 1
        completed = [
            f"{SETUP_STEP_ORDER.index(done_step) + 1}/7 {SETUP_STEP_TITLES[done_step]}"
            for done_step in SETUP_STEP_ORDER
            if done_step in self.setup_steps_done and done_step != step
        ]
        completed_text = f"已完成：{'、'.join(completed)}\n" if completed else ""
        return f"{completed_text}当前第 {step_number}/7 步：{body}"

    @staticmethod
    def _contains_all(text: str, *parts: str) -> bool:
        return all(part in text for part in parts)

    def _matches_welcome_start(self, normalized: str) -> bool:
        direct_phrases = ("开始向导", "开始配置", "开始设置", "开启向导", "开启配置", "开启设置", "打开向导", "打开设置")
        if any(phrase in normalized for phrase in direct_phrases):
            return True
        if self._contains_all(normalized, "开始", "向") and any(token in normalized for token in ("导", "道", "岛")):
            return True
        return self._contains_all(normalized, "开始", "配") and "置" in normalized

    @staticmethod
    def _matches_continue(normalized: str) -> bool:
        direct_phrases = ("继续", "继续吧", "下一步", "往下走", "往后走", "下一个")
        if any(phrase in normalized for phrase in direct_phrases):
            return True
        return "下一" in normalized or any(token in normalized for token in ("继", "续"))

    @staticmethod
    def _matches_enrollment_start(normalized: str) -> bool:
        direct_phrases = ("开始录入", "开始录音", "开始录制", "开始设置", "开始确认", "准备好了", "可以录了", "开始吧")
        if any(phrase in normalized for phrase in direct_phrases):
            return True
        return "开始" in normalized and any(token in normalized for token in ("录", "入", "音"))

    @staticmethod
    def _matches_enrollment_pause(normalized: str) -> bool:
        return any(
            phrase in normalized
            for phrase in ("取消录入", "暂停录入", "先等等", "等一下", "等一会", "先暂停")
        )

    @staticmethod
    def _matches_enrollment_retry(normalized: str) -> bool:
        return any(
            phrase in normalized
            for phrase in ("重来", "重录", "再来一次", "重新录", "重新来")
        )

    def _looks_like_enrollment_reading(self, transcript: str) -> bool:
        normalized = self._normalize(transcript)
        keyword_hits = sum(
            1
            for keyword in ("语音", "助手", "就绪", "今天", "指令", "执行")
            if keyword in normalized
        )
        return len(normalized) >= 10 and keyword_hits >= 2

    def _handle_setup_transcript_v2_alias(self, utterance: HeardUtterance) -> None:
        self._handle_setup_transcript_v2(utterance)

    def _show_setup_prompt_v2_alias(self, extra_detail: str | None = None) -> None:
        self._show_setup_prompt_v2(extra_detail)

    def _handle_setup_check_done_v2_alias(self, step: str, ok: bool, detail: str) -> None:
        self._handle_setup_check_done_v2(step, ok, detail)

    def _handle_enrollment_transcript_v2_alias(self, utterance: HeardUtterance) -> None:
        self._handle_enrollment_transcript_v2(utterance)

    def _sync_setup_progress_v3(self) -> None:
        return

    def _current_setup_step_v3(self) -> str | None:
        for step in SETUP_STEP_ORDER:
            if step not in self.setup_steps_done:
                return step
        return None

    def _handle_setup_transcript_v3(self, utterance: HeardUtterance) -> None:
        transcript = utterance.transcript
        normalized = self._normalize(transcript)
        current_step = self._current_setup_step_v3()
        self._write_log("SETUP_TRANSCRIPT", f"{current_step}: {transcript}")

        if current_step == "welcome":
            if self._matches_welcome_start(normalized):
                self._mark_setup_step_done("welcome")
                self._show_setup_prompt_v3()
            else:
                self.window.set_state(PetState.SETUP, "第 1/7 步：准备好后说“开始向导”。")
            return

        if current_step == "microphone":
            self.window.set_state(PetState.SETUP, "第 2/7 步：我已经听到你了，准备进入下一步。")
            return

        if current_step == "enrollment":
            self._handle_enrollment_transcript_v3(utterance)
            return

        if current_step in {"launch_command", "gateway", "dashboard"}:
            if self._matches_continue(normalized):
                self._run_setup_checks_if_needed()
            else:
                step_number = SETUP_STEP_ORDER.index(current_step) + 1
                self.window.set_state(PetState.SETUP, f"第 {step_number}/7 步：准备好后说“继续”。")
            return

        if current_step == "wake_test":
            self.window.set_state(PetState.SETUP, "第 7/7 步：请直接说唤醒词，比如“在吗在吗”。")

    def _show_setup_prompt_v3(self, extra_detail: str | None = None) -> None:
        current_step = self._current_setup_step_v3()
        if current_step is None:
            self._complete_setup_wizard()
            return

        if current_step == "welcome":
            detail = "第 1/7 步：准备好后说“开始设置”。"
        elif current_step == "microphone":
            detail = "第 2/7 步：请随便说一句话，我听到就算通过。"
        elif current_step == "enrollment":
            if self.speaker_verifier.has_profile():
                detail = "第 3/7 步：已检测到你的声音。说“继续”跳过，或说“开始设置”重新确认。"
            else:
                detail = "第 3/7 步：准备好后说“开始设置”。"
        elif current_step == "launch_command":
            detail = "第 4/7 步：检查 OpenClaw 启动脚本。说“继续”。"
        elif current_step == "gateway":
            detail = "第 5/7 步：检查 Gateway。说“继续”。"
        elif current_step == "dashboard":
            detail = "第 6/7 步：检查 Dashboard。说“继续”。"
        else:
            detail = "第 7/7 步：请说唤醒词，比如“在吗在吗”。"

        self.window.set_state(PetState.SETUP, extra_detail or detail)

    def _handle_setup_check_done_v3(self, step: str, ok: bool, detail: str) -> None:
        self._write_log("SETUP_CHECK", f"{step} -> {'ok' if ok else 'fail'}: {detail}")
        if ok:
            self._mark_setup_step_done(step)
            if step == "gateway":
                self.openclaw_started_once = True
            self._show_setup_prompt_v3()
            return
        self.window.set_state(PetState.ERROR, detail)
        self.window.after(1800, self._show_setup_prompt_v3)

    def _handle_enrollment_transcript_v3(self, utterance: HeardUtterance) -> None:
        normalized = self._normalize(utterance.transcript)

        if self.enrollment_processing:
            self.window.set_state(PetState.RECOGNIZING, "正在生成你的声音模板。")
            return

        if self.speaker_verifier.has_profile() and self._matches_continue(normalized):
            self._mark_setup_step_done("enrollment")
            self._show_setup_prompt_v3()
            return

        if self._matches_enrollment_pause(normalized):
            self.enrollment_waiting_for_sample = False
            self.enrollment_accept_after = 0.0
            self.enrollment_sample_deadline = 0.0
            self.enrollment_transcript_buffer.clear()
            self._set_enrollment_listening_mode(False)
            self.window.set_state(PetState.SETUP, "准备好后说“开始设置”。")
            return

        if not self.enrollment_waiting_for_sample:
            if self._matches_enrollment_start(normalized):
                self.enrollment_waiting_for_sample = True
                self._prompt_enrollment_sample()
                return
            if self.speaker_verifier.has_profile():
                self.window.set_state(PetState.SETUP, "说“继续”跳过，或说“开始设置”重新确认。")
            else:
                self.window.set_state(PetState.SETUP, "准备好后说“开始设置”。")
            return

        if self._matches_enrollment_retry(normalized):
            self._prompt_enrollment_sample()
            return

        if self.enrollment_waiting_for_sample:
            if time.monotonic() < self.enrollment_accept_after:
                return

            text = utterance.transcript.strip()
            if text:
                self.enrollment_transcript_buffer.append(text)

            combined_transcript = "".join(self.enrollment_transcript_buffer[-4:])
            if not self._looks_like_enrollment_reading(combined_transcript):
                if time.monotonic() < self.enrollment_sample_deadline:
                    # Still inside the current enrollment window: keep waiting quietly
                    # instead of interrupting the user for every short pause or half-sentence.
                    remaining = max(1, int(self.enrollment_sample_deadline - time.monotonic()))
                    self.window.set_state(
                        PetState.RECOGNIZING,
                        f"第 {len(self.enrollment_samples) + 1}/{ENROLLMENT_SAMPLE_COUNT} 次，继续把整句读完，我还会再等你 {remaining} 秒。",
                    )
                else:
                    self.enrollment_waiting_for_sample = False
                    self.enrollment_transcript_buffer.clear()
                    self._set_enrollment_listening_mode(False)
                    self.window.set_state(PetState.RECOGNIZING, "这一轮超时了，我们重新来这一句。")
                    self.window.after(1800, self._prompt_enrollment_sample)
                return

            self.enrollment_waiting_for_sample = False
            self.enrollment_transcript_buffer.clear()
            self.enrollment_samples.append(utterance.wav_bytes)
            sample_index = len(self.enrollment_samples)
            self._write_log("ENROLL_SAMPLE", f"captured {sample_index}/{ENROLLMENT_SAMPLE_COUNT}: {combined_transcript or utterance.transcript}")

            if sample_index < ENROLLMENT_SAMPLE_COUNT:
                self._set_status(
                    PetState.WAKE_SUCCESS,
                    f"已收到第 {sample_index} 次。准备好后继续读第 {sample_index + 1} 次。",
                    speak=f"已收到第{sample_index}次。准备好后，继续读第{sample_index + 1}次。",
                )
                self.window.after(2400, self._prompt_enrollment_sample)
                return

            self.enrollment_processing = True
            self._set_status(
                PetState.RECOGNIZING,
                "三次采样已收到，正在生成你的声音模板。",
                speak="三次采样已收到，正在生成你的声音模板。",
            )
            worker = threading.Thread(target=self._finalize_enrollment, args=(list(self.enrollment_samples),), daemon=True)
            worker.start()
            return

        self.window.set_state(PetState.RECOGNIZING, "请直接朗读提示句。")

    def _format_setup_message(self, step: str, body: str) -> str:
        step_number = SETUP_STEP_ORDER.index(step) + 1
        return f"第 {step_number}/7 步：{body}"

    def _sync_setup_progress(self) -> None:
        self._sync_setup_progress_v3()

    def _current_setup_step(self) -> str | None:
        return self._current_setup_step_v3()

    def _handle_setup_transcript(self, utterance: HeardUtterance) -> None:
        self._handle_setup_transcript_v3(utterance)

    def _show_setup_prompt(self, extra_detail: str | None = None) -> None:
        self._show_setup_prompt_v3(extra_detail)

    def _handle_setup_check_done(self, step: str, ok: bool, detail: str) -> None:
        self._handle_setup_check_done_v3(step, ok, detail)

    def _handle_enrollment_transcript(self, utterance: HeardUtterance) -> None:
        self._handle_enrollment_transcript_v3(utterance)

    def _open_log_file(self) -> None:
        try:
            os.startfile(self.log_path)  # type: ignore[attr-defined]
        except Exception as exc:
            self.window.set_state(PetState.ERROR, f"打开日志失败: {exc}")

    @staticmethod
    def _is_port_open(host: str, port: int, timeout: float = 1.0) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            return False

    @staticmethod
    def _is_dashboard_reachable() -> bool:
        request = urllib.request.Request("http://127.0.0.1:19001/", method="GET")
        try:
            with urllib.request.urlopen(request, timeout=2) as response:
                return 200 <= response.status < 500
        except urllib.error.HTTPError as exc:
            return 200 <= exc.code < 500
        except Exception:
            return False

    @staticmethod
    def _normalize(text: str) -> str:
        return text.replace(" ", "").replace("，", "").replace("。", "").replace("！", "").replace("？", "").lower()

    def _looks_like_valid_command(self, transcript: str) -> bool:
        return bool(transcript and transcript.strip())
        normalized = self._normalize(transcript)
        if not normalized:
            return False

        low_value_phrases = {
            "[unk]",
            "unk",
            "嗯",
            "啊",
            "哦",
            "呃",
            "额",
            "欸",
            "诶",
            "哎",
            "哈",
            "喂",
            "测试",
            "那个",
            "这个",
            "什么",
        }
        if normalized in low_value_phrases:
            return False

        if len(normalized) <= 1:
            return False

        if len(set(normalized)) == 1 and len(normalized) <= 3:
            return False

        command_hints = (
            "打开",
            "启动",
            "关闭",
            "退出",
            "停止",
            "重启",
            "查询",
            "看看",
            "帮我",
            "请",
            "天气",
            "新闻",
            "今天",
            "怎么",
            "为何",
            "为什么",
            "能不能",
            "可以",
            "dashboard",
            "openclaw",
        )
        if any(token in normalized for token in command_hints):
            return True

        return len(normalized) >= 4

    def _looks_like_valid_command(self, transcript: str) -> bool:
        return bool(transcript and transcript.strip())
        normalized = self._normalize(transcript)
        if not normalized:
            return False

        low_value_phrases = {
            "[unk]",
            "unk",
            "嗯",
            "啊",
            "哦",
            "呃",
            "喂",
            "欸",
            "诶",
            "哎",
            "测试",
            "那个",
            "这个",
            "什么",
        }
        if normalized in low_value_phrases:
            return False

        blocked_exact_phrases = {
            "好的我明白了",
            "我明白了",
            "好的",
            "明白了",
            "收到",
            "可以",
            "你有空吗",
        }
        if normalized in blocked_exact_phrases:
            return False

        blocked_prefixes = (
            "我叫",
            "我今天",
            "我是",
            "我想",
            "我已经",
            "收藏了",
            "好的我",
        )
        if any(normalized.startswith(prefix) for prefix in blocked_prefixes):
            return False

        if len(normalized) <= 1:
            return False

        if len(set(normalized)) == 1 and len(normalized) <= 3:
            return False

        command_hints = (
            "在吗",
            "小虾",
            "小龙虾",
            "打开",
            "启动",
            "关闭",
            "退出",
            "停止",
            "重启",
            "查询",
            "看看",
            "帮我",
            "请",
            "告诉我",
            "总结",
            "天气",
            "新闻",
            "今天",
            "怎么",
            "为何",
            "为什么",
            "能不能",
            "可以",
            "dashboard",
            "openclaw",
        )
        if any(token in normalized for token in command_hints):
            return True

        return len(normalized) >= 8

    def _handle_wake(self, utterance: HeardUtterance, phrase: str) -> None:
        if self.setup_active and self._current_setup_step() != "wake_test":
            self._write_log("SETUP_WAKE_IGNORED", f"{phrase} <- {utterance.transcript}")
            return
        if self.enrollment_active:
            return

        verification = self._verify_owner_voice(utterance.wav_bytes, self.wake_profile_threshold)
        self._write_log("VERIFY_WAKE", f"score={verification.score:.3f}, threshold={verification.threshold:.3f}")
        if not verification.accepted:
            self._write_log("DROP_NON_OWNER_WAKE", utterance.transcript)
            self.window.set_state(PetState.IDLE, "等待唤醒词。")
            return

        self.last_wake_transcript = utterance.transcript
        if self.setup_active and self._current_setup_step() == "wake_test":
            self._mark_setup_step_done("wake_test")
            self._complete_setup_wizard()
            return

        self.relay_until = time.monotonic() + 3.0
        inline_command = self._extract_inline_command_after_wake(utterance.transcript, phrase)
        if inline_command:
            self.relay_until = 0.0
            self.window.set_state(PetState.FORWARDING, f"正在转达给 OpenClaw：{inline_command}")
            self._write_log("FORWARD", inline_command)
            self._speak("收到，正在转达给 OpenClaw。")
            self.openclaw.ask(inline_command)
            return
        if self.openclaw_started_once:
            self._set_status(PetState.WAKE_SUCCESS, "已唤醒，请说指令。", speak="已唤醒，请说指令。")
            return

        self._set_status(
            PetState.WAKE_SUCCESS,
            f"命中“{phrase}”，正在为你启动服务。",
            speak="收到，正在为你启动 OpenClaw。",
        )
        self.window.after(300, self._launch_openclaw)

    def _handle_transcript(self, utterance: HeardUtterance) -> None:
        transcript = utterance.transcript.strip()
        if not transcript:
            return

        if self.setup_active:
            self._handle_setup_transcript(utterance)
            return

        if self.enrollment_active:
            self._handle_enrollment_transcript(utterance)
            return

        self._write_log("TRANSCRIPT", transcript)

        if transcript == self.last_wake_transcript:
            return
        normalized = self._normalize(transcript)
        if self._starts_with_wake_phrase(normalized):
            return

        is_guest_toggle = any(
            keyword in normalized
            for keyword in (
                "开启访客模式",
                "打开访客模式",
                "允许访客",
                "授权访客",
                "进入访客模式",
                "关闭访客模式",
                "结束访客模式",
                "退出访客模式",
            )
        )

        if self._guest_mode_active():
            if any(keyword in normalized for keyword in ("关闭访客模式", "结束访客模式", "退出访客模式")):
                verification = self._verify_owner_voice(utterance.wav_bytes, self.command_profile_threshold)
                self._write_log("VERIFY_GUEST_CLOSE", f"score={verification.score:.3f}, threshold={verification.threshold:.3f}")
                if verification.accepted:
                    self._disable_guest_mode()
                else:
                    self._write_log("DROP_NON_OWNER_GUEST_CLOSE", transcript)
                return
            if self.openclaw_started_once and not self._looks_like_valid_command(transcript):
                self._write_log("DROP_NOISE", transcript)
                return
            self._handle_guest_request(transcript)
            return

        if not is_guest_toggle and time.monotonic() > self.relay_until:
            self._write_log("DROP_NOT_WOKEN", transcript)
            if self.openclaw_started_once:
                self.window.set_state(PetState.RUNNING, "等待唤醒词。")
            else:
                self.window.set_state(PetState.IDLE, "等待唤醒词。")
            return

        if self.openclaw_started_once and not self._looks_like_valid_command(transcript):
            self._write_log("DROP_NOISE", transcript)
            self.window.set_state(PetState.RUNNING, "已唤醒，请说清楚指令。")
            return

        if self.openclaw_started_once and not is_guest_toggle:
            self.relay_until = 0.0
            self.window.set_state(PetState.FORWARDING, f"正在转达给 OpenClaw：{transcript}")
            self._write_log("FORWARD", transcript)
            self._speak("收到，正在转达给 OpenClaw。")
            self.openclaw.ask(transcript)
            return

        verification = self._verify_owner_voice(utterance.wav_bytes, self.command_profile_threshold)
        self._write_log("VERIFY_CMD", f"score={verification.score:.3f}, threshold={verification.threshold:.3f}")
        if not verification.accepted:
            self._write_log("DROP_NON_OWNER_CMD", transcript)
            if self.openclaw_started_once:
                self.window.set_state(PetState.RUNNING, "等待唤醒词。")
            else:
                self.window.set_state(PetState.IDLE, "等待唤醒词。")
            return

        if any(keyword in normalized for keyword in ("开启访客模式", "打开访客模式", "允许访客", "授权访客", "进入访客模式")):
            self.relay_until = 0.0
            self._enable_guest_mode()
            return
        if any(keyword in normalized for keyword in ("关闭访客模式", "结束访客模式", "退出访客模式")):
            self.relay_until = 0.0
            self._disable_guest_mode()
            return
        if any(keyword in normalized for keyword in ("退出", "关闭", "结束")) and "桌面" in normalized:
            self.window.set_state(PetState.ERROR, "正在退出桌宠。")
            self.window.after(150, self.window.root.destroy)
            return

        self.relay_until = 0.0
        self.window.set_state(PetState.FORWARDING, f"正在转达给 OpenClaw：{transcript}")
        self._write_log("FORWARD", transcript)
        self._speak("收到，正在转达给 OpenClaw。")
        self.openclaw.ask(transcript)

    def _extract_inline_command_after_wake(self, transcript: str, phrase: str) -> str:
        text = transcript.strip()
        if not text:
            return ""

        normalized = self._normalize(text)
        candidates = [phrase, *self.config.wake_phrases]
        for candidate in candidates:
            wake = self._normalize(candidate)
            if not wake or not normalized.startswith(wake):
                continue
            return normalized[len(wake):].strip(" ,，。.!！？?、:")
        return ""

def main() -> int:
    controller = LobsterPetController(Path(__file__).resolve().parent.parent)
    return controller.run()
