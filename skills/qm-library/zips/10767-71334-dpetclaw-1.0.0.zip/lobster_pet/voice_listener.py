from __future__ import annotations

import audioop
import base64
import json
import math
import os
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
import urllib.request

import pyaudio
import speech_recognition as sr
from vosk import KaldiRecognizer, Model, SetLogLevel


SAMPLE_RATE = 16000
SAMPLE_WIDTH = 2
CHANNELS = 1
CHUNK_SIZE = 512
AMBIENT_MEASURE_CHUNKS = 4
PREBUFFER_CHUNKS = 16
VOSK_GAIN = 4.5
FILTER_PROFILES = {
    0: {
        "ambient_factor": 0.0,
        "delta_factor": 0.0,
        "min_trigger": 1,
        "trigger_cap": 1,
        "delta_floor": 0,
        "delta_cap": 0,
        "silence_floor": 1,
        "silence_ratio": 0.0,
        "start_trigger_chunks": 1,
        "min_phrase_chunks": 1,
        "required_voiced_chunks": 1,
        "required_run": 1,
    },
    1: {
        "ambient_factor": 0.90,
        "delta_factor": 0.0005,
        "min_trigger": 4,
        "trigger_cap": 10,
        "delta_floor": 1,
        "delta_cap": 4,
        "silence_floor": 2,
        "silence_ratio": 0.15,
        "start_trigger_chunks": 1,
        "min_phrase_chunks": 2,
        "required_voiced_chunks": 1,
        "required_run": 1,
    },
    2: {
        "ambient_factor": 1.05,
        "delta_factor": 0.0030,
        "min_trigger": 12,
        "trigger_cap": 20,
        "delta_floor": 3,
        "delta_cap": 12,
        "silence_floor": 7,
        "silence_ratio": 0.40,
        "start_trigger_chunks": 3,
        "min_phrase_chunks": 8,
        "required_voiced_chunks": 4,
        "required_run": 3,
    },
    3: {
        "ambient_factor": 1.10,
        "delta_factor": 0.0045,
        "min_trigger": 14,
        "trigger_cap": 24,
        "delta_floor": 4,
        "delta_cap": 14,
        "silence_floor": 8,
        "silence_ratio": 0.45,
        "start_trigger_chunks": 4,
        "min_phrase_chunks": 10,
        "required_voiced_chunks": 5,
        "required_run": 3,
    },
    4: {
        "ambient_factor": 1.16,
        "delta_factor": 0.0060,
        "min_trigger": 16,
        "trigger_cap": 28,
        "delta_floor": 5,
        "delta_cap": 16,
        "silence_floor": 9,
        "silence_ratio": 0.50,
        "start_trigger_chunks": 5,
        "min_phrase_chunks": 12,
        "required_voiced_chunks": 6,
        "required_run": 4,
    },
    5: {
        "ambient_factor": 1.22,
        "delta_factor": 0.0080,
        "min_trigger": 18,
        "trigger_cap": 32,
        "delta_floor": 6,
        "delta_cap": 18,
        "silence_floor": 10,
        "silence_ratio": 0.60,
        "start_trigger_chunks": 6,
        "min_phrase_chunks": 14,
        "required_voiced_chunks": 7,
        "required_run": 5,
    },
}


@dataclass(frozen=True)
class WakeMatch:
    transcript: str
    phrase: str


@dataclass(frozen=True)
class HeardUtterance:
    transcript: str
    wav_bytes: bytes


class VoiceListener:
    def __init__(
        self,
        wake_phrases: list[str],
        on_listening: Callable[[], None],
        on_recognizing: Callable[[str], None],
        on_audio_detected: Callable[[HeardUtterance], None],
        on_transcript_detected: Callable[[HeardUtterance], None],
        on_wake_detected: Callable[[HeardUtterance, str], None],
        on_error: Callable[[str], None],
        on_log: Callable[[str], None],
        microphone_name: str | None = None,
        phrase_time_limit: int = 5,
        pause_threshold: float = 0.35,
        energy_threshold: int = 30,
        environment_filter_level: int = 2,
        dynamic_energy_threshold: bool = True,
        asr_backend: str = "vosk",
        vosk_model_path: str | None = None,
        faster_whisper_model_size_or_path: str | None = None,
        faster_whisper_compute_type: str = "int8",
        siliconflow_api_key: str | None = None,
        siliconflow_asr_model: str | None = None,
        debug_audio_dir: str | None = None,
    ) -> None:
        self._wake_phrases = [phrase.strip() for phrase in wake_phrases if phrase.strip()]
        self._on_listening = on_listening
        self._on_recognizing = on_recognizing
        self._on_audio_detected = on_audio_detected
        self._on_transcript_detected = on_transcript_detected
        self._on_wake_detected = on_wake_detected
        self._on_error = on_error
        self._on_log = on_log
        self._microphone_name = microphone_name
        self._phrase_time_limit = phrase_time_limit
        self._pause_threshold = pause_threshold
        self._energy_threshold = max(1, energy_threshold)
        # Keep all utterances flowing through; environment-noise blocking is disabled.
        self._environment_filter_level = 0
        self._recognizer = sr.Recognizer()
        self._recognizer.pause_threshold = pause_threshold
        self._recognizer.energy_threshold = energy_threshold
        self._recognizer.dynamic_energy_threshold = dynamic_energy_threshold
        self._worker: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._asr_backend = (asr_backend or "vosk").lower()
        self._vosk_model_path = Path(vosk_model_path) if vosk_model_path else None
        self._faster_whisper_model_size_or_path = faster_whisper_model_size_or_path or "small"
        self._faster_whisper_compute_type = faster_whisper_compute_type or "int8"
        self._siliconflow_api_key = siliconflow_api_key
        self._siliconflow_asr_model = siliconflow_asr_model or "Qwen/Qwen3-Omni-30B-A3B-Instruct"
        self._debug_audio_dir = Path(debug_audio_dir) if debug_audio_dir else None
        self._vosk_model: Model | None = None
        self._faster_whisper_model = None
        self._grammar_phrases = self._build_grammar_phrases()

        if self._asr_backend == "siliconflow_omni" and not self._siliconflow_api_key:
            self._on_log("未配置 SiliconFlow API Key，将回退到 Vosk。")
            self._asr_backend = "vosk"
        if self._asr_backend == "faster_whisper":
            self._load_faster_whisper_model()
        if self._asr_backend == "vosk":
            self._load_vosk_model()

    def start(self) -> None:
        try:
            if self._worker and self._worker.is_alive():
                return
            device_index, microphone_label, input_sample_rate = self._select_input_device()
            self._stop_event.clear()
            self._worker = threading.Thread(
                target=self._listen_loop,
                args=(device_index, microphone_label, input_sample_rate),
                daemon=True,
            )
            self._worker.start()
            self._on_log(f"语音监听已启动，麦克风: {microphone_label}，识别后端: {self._asr_backend}")
        except Exception as exc:
            detail = str(exc) or repr(exc)
            self._on_error(f"监听启动失败: {detail}")

    def stop(self) -> None:
        self._stop_event.set()
        self._worker = None

    def _load_vosk_model(self) -> None:
        if not self._vosk_model_path:
            self._on_log("未配置 Vosk 模型路径，将回退到在线识别。")
            self._asr_backend = "google"
            return
        if not self._vosk_model_path.exists():
            self._on_log(f"找不到 Vosk 模型目录: {self._vosk_model_path}，将回退到在线识别。")
            self._asr_backend = "google"
            return

        try:
            SetLogLevel(-1)
            self._vosk_model = Model(str(self._vosk_model_path))
        except Exception as exc:
            self._on_log(f"加载 Vosk 模型失败: {exc}，将回退到在线识别。")
            self._asr_backend = "google"
            self._vosk_model = None

    def _load_faster_whisper_model(self) -> None:
        try:
            from faster_whisper import WhisperModel
        except Exception as exc:
            self._on_log(f"faster-whisper 不可用: {exc}，将回退到 Vosk。")
            self._asr_backend = "vosk"
            self._load_vosk_model()
            return

        try:
            self._faster_whisper_model = WhisperModel(
                self._faster_whisper_model_size_or_path,
                device="cpu",
                compute_type=self._faster_whisper_compute_type,
            )
        except Exception as exc:
            self._on_log(f"加载 faster-whisper 失败: {exc}，将回退到 Vosk。")
            self._faster_whisper_model = None
            self._asr_backend = "vosk"
            self._load_vosk_model()

    def _listen_loop(self, device_index: int, microphone_label: str, input_sample_rate: int) -> None:
        pa = pyaudio.PyAudio()
        stream = None
        try:
            stream = pa.open(
                format=pyaudio.paInt16,
                channels=CHANNELS,
                rate=input_sample_rate,
                input=True,
                input_device_index=device_index,
                frames_per_buffer=CHUNK_SIZE,
            )
            ambient = self._measure_ambient(stream)
            filter_level = self._environment_filter_level
            profile = FILTER_PROFILES[filter_level]
            ambient_factor = profile["ambient_factor"]
            delta_factor = profile["delta_factor"]
            min_trigger = profile["min_trigger"]
            trigger_cap = profile["trigger_cap"]
            delta_floor = profile["delta_floor"]
            delta_cap = profile["delta_cap"]
            silence_floor = profile["silence_floor"]
            silence_ratio = profile["silence_ratio"]
            start_trigger_chunks = profile["start_trigger_chunks"]
            min_phrase_chunks = profile["min_phrase_chunks"]

            ambient_based_threshold = int(ambient * ambient_factor)
            trigger_threshold = max(
                min_trigger,
                min(ambient_based_threshold, max(self._energy_threshold, trigger_cap)),
            )
            speech_delta_threshold = min(max(delta_floor, int(ambient * delta_factor)), delta_cap)
            silence_delta_threshold = max(silence_floor, int(speech_delta_threshold * silence_ratio))
            silence_chunks = max(2, math.ceil((self._pause_threshold * input_sample_rate) / CHUNK_SIZE))
            max_chunks = max(1, math.ceil((self._phrase_time_limit * input_sample_rate) / CHUNK_SIZE))
            self._on_log(
                f"监听门槛: ambient={ambient}, trigger={trigger_threshold}, delta={speech_delta_threshold}, silence={silence_delta_threshold}, filter={self._environment_filter_level}"
            )
            speaking = False
            buffered_before: list[bytes] = []
            speech_frames: list[bytes] = []
            speech_energies: list[int] = []
            silent_count = 0
            trigger_count = 0
            last_debug_at = time.monotonic()

            while not self._stop_event.is_set():
                chunk = stream.read(CHUNK_SIZE, exception_on_overflow=False)
                energy = audioop.rms(chunk, SAMPLE_WIDTH)
                now = time.monotonic()
                if not speaking and now - last_debug_at >= 3.0:
                    last_debug_at = now
                    self._on_log(
                        f"输入能量: energy={energy}, ambient={ambient}, trigger={trigger_threshold}, delta={speech_delta_threshold}"
                    )

                if not speaking:
                    buffered_before.append(chunk)
                    if len(buffered_before) > PREBUFFER_CHUNKS:
                        buffered_before.pop(0)
                    if energy > 0 and (energy >= trigger_threshold or (energy - ambient) >= speech_delta_threshold):
                        trigger_count += 1
                    else:
                        trigger_count = 0
                    if trigger_count >= start_trigger_chunks:
                        speaking = True
                        speech_frames = buffered_before[:]
                        speech_energies = [audioop.rms(frame, SAMPLE_WIDTH) for frame in buffered_before]
                        buffered_before.clear()
                        silent_count = 0
                        trigger_count = 0
                else:
                    speech_frames.append(chunk)
                    speech_energies.append(energy)
                    if (energy - ambient) < silence_delta_threshold:
                        silent_count += 1
                    else:
                        silent_count = 0

                    if silent_count >= silence_chunks or len(speech_frames) >= max_chunks:
                        if len(speech_frames) >= min_phrase_chunks:
                            if self._looks_like_speech(
                                speech_energies,
                                ambient,
                                trigger_threshold,
                                speech_delta_threshold,
                            ):
                                self._handle_phrase(b"".join(speech_frames), input_sample_rate)
                            else:
                                self._on_log(
                                    f"忽略了一段更像噪声的输入: chunks={len(speech_frames)}, ambient={ambient}, trigger={trigger_threshold}"
                                )
                        speaking = False
                        speech_frames = []
                        speech_energies = []
                        silent_count = 0
                        buffered_before.clear()
        except Exception as exc:
            detail = str(exc) or repr(exc)
            self._on_error(f"监听循环异常({microphone_label}): {detail}")
        finally:
            if stream is not None:
                try:
                    stream.stop_stream()
                    stream.close()
                except Exception:
                    pass
            pa.terminate()

    def _handle_phrase(self, pcm_bytes: bytes, input_sample_rate: int) -> None:
        if not pcm_bytes:
            return
        self._on_listening()
        pcm_for_asr = self._resample_pcm_if_needed(pcm_bytes, input_sample_rate)
        audio = sr.AudioData(pcm_for_asr, SAMPLE_RATE, SAMPLE_WIDTH)
        wav_bytes = audio.get_wav_data(convert_rate=SAMPLE_RATE, convert_width=SAMPLE_WIDTH)
        self._on_audio_detected(HeardUtterance(transcript="", wav_bytes=wav_bytes))

        try:
            transcript = self._transcribe(audio, pcm_for_asr).strip()
            if not transcript:
                self._on_log("听到了声音，但没有识别出文字")
                return
            utterance = HeardUtterance(transcript=transcript, wav_bytes=wav_bytes)
            self._on_recognizing(transcript)
            self._on_transcript_detected(utterance)
            match = self._match_phrase(transcript)
            if match:
                self._on_wake_detected(utterance, match.phrase)
        except sr.UnknownValueError:
            self._on_log("听到了声音，但没有识别出文字")
        except Exception as exc:
            detail = str(exc) or repr(exc)
            self._on_error(f"识别失败: {detail}")

    def _transcribe(self, audio: sr.AudioData, pcm_bytes: bytes) -> str:
        if self._asr_backend == "siliconflow_omni":
            transcript = self._recognize_siliconflow_omni(audio)
            if transcript:
                self._on_log(f"Omni 命中: {transcript}")
                return transcript
            self._on_log("Omni 没有识别出文字，回退到 Vosk")
            transcript, source = self._recognize_vosk_best(pcm_bytes)
            if transcript:
                self._on_log(f"Vosk 回退命中({source}): {transcript}")
                return transcript
            return ""
        if self._asr_backend == "faster_whisper":
            transcript = self._recognize_faster_whisper(audio)
            if transcript:
                self._on_log(f"Whisper 命中: {transcript}")
                return transcript
            self._on_log("Whisper 没有识别出文字")
            return ""
        if self._asr_backend == "vosk":
            transcript, source = self._recognize_vosk_best(pcm_bytes)
            if transcript:
                self._on_log(f"Vosk 命中({source}): {transcript}")
                return transcript
            self._on_log("Vosk 没有识别出文字")
            return ""

        return self._recognizer.recognize_google(audio, language="zh-CN").strip()

    def _recognize_faster_whisper(self, audio: sr.AudioData) -> str:
        if self._faster_whisper_model is None:
            return ""

        temp_path: str | None = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_file:
                temp_file.write(audio.get_wav_data(convert_rate=SAMPLE_RATE, convert_width=SAMPLE_WIDTH))
                temp_path = temp_file.name

            segments, _info = self._faster_whisper_model.transcribe(
                temp_path,
                language="zh",
                beam_size=1,
                best_of=1,
                temperature=0.0,
                vad_filter=False,
                condition_on_previous_text=False,
                initial_prompt="这是一段中文日常口语和桌面指令，优先识别自然中文句子。",
            )
            text = "".join(segment.text for segment in segments).strip()
            return self._cleanup_transcript(text)
        except Exception as exc:
            self._on_log(f"Whisper 识别异常: {exc}")
            return ""
        finally:
            if temp_path:
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass

    def _looks_like_speech(
        self,
        energies: list[int],
        ambient: int,
        trigger_threshold: int,
        speech_delta_threshold: int,
    ) -> bool:
        if not energies:
            return False
        if self._environment_filter_level == 0:
            return any(energy > 0 for energy in energies)

        voiced_flags = [
            (energy >= trigger_threshold) or ((energy - ambient) >= speech_delta_threshold)
            for energy in energies
        ]
        voiced_chunks = sum(1 for flag in voiced_flags if flag)
        profile = FILTER_PROFILES[self._environment_filter_level]
        required_voiced_chunks = profile["required_voiced_chunks"]
        if voiced_chunks < required_voiced_chunks:
            return False

        longest_run = 0
        current_run = 0
        for flag in voiced_flags:
            if flag:
                current_run += 1
                longest_run = max(longest_run, current_run)
            else:
                current_run = 0

        required_run = profile["required_run"]
        return longest_run >= required_run

    def _recognize_siliconflow_omni(self, audio: sr.AudioData) -> str:
        if not self._siliconflow_api_key:
            return ""

        audio_b64 = base64.b64encode(
            audio.get_wav_data(convert_rate=SAMPLE_RATE, convert_width=SAMPLE_WIDTH)
        ).decode("ascii")
        payload = {
            "model": self._siliconflow_asr_model,
            "temperature": 0,
            "max_tokens": 64,
            "messages": [
                {
                    "role": "system",
                    "content": "你是中文语音转写器。请只输出用户语音的中文转写结果，不要解释，不要补充标点以外的内容。常见句子包括：在吗在吗、小虾小虾、今天有什么新闻、今天天气怎么样、你能做什么、帮我启动 OpenClaw 和 dashboard。",
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "请把这段音频转写成简洁准确的中文文本。"},
                        {
                            "type": "audio_url",
                            "audio_url": {
                                "url": f"data:audio/wav;base64,{audio_b64}"
                            },
                        },
                    ],
                },
            ],
        }
        request = urllib.request.Request(
            "https://api.siliconflow.cn/v1/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._siliconflow_api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                body = json.loads(response.read().decode("utf-8"))
        except Exception as exc:
            self._on_log(f"Omni 识别异常: {exc}")
            return ""

        try:
            content = body["choices"][0]["message"]["content"]
        except Exception:
            return ""
        if isinstance(content, list):
            text = "".join(
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ).strip()
        else:
            text = str(content).strip()
        return self._cleanup_transcript(text)

    def _recognize_vosk_best(self, pcm_bytes: bytes) -> tuple[str, str]:
        if self._vosk_model is None:
            return "", "no_model"

        candidates: list[tuple[str, str]] = []
        boosted_pcm = self._apply_gain(pcm_bytes, VOSK_GAIN)

        generic = self._recognize_vosk_once(pcm_bytes)
        if generic:
            candidates.append((generic, "generic"))

        boosted = self._recognize_vosk_once(boosted_pcm)
        if boosted:
            candidates.append((boosted, "boosted"))

        wake_grammar = self._recognize_vosk_once(pcm_bytes, grammar=self._wake_phrases)
        if wake_grammar:
            candidates.append((wake_grammar, "wake_grammar"))

        grammar = self._recognize_vosk_once(boosted_pcm, grammar=self._grammar_phrases)
        if grammar:
            candidates.append((grammar, "grammar"))

        if not candidates:
            return "", "empty"

        cleaned_candidates = [(self._cleanup_transcript(text), source) for text, source in candidates]
        cleaned_candidates = [(text, source) for text, source in cleaned_candidates if text]
        if not cleaned_candidates:
            return "", "cleaned_empty"

        wake_candidates = [(text, source) for text, source in cleaned_candidates if self._match_phrase(text)]
        if wake_candidates:
            wake_candidates.sort(
                key=lambda item: (
                    1 if item[1] == "wake_grammar" else 0,
                    1 if item[1] == "grammar" else 0,
                    self._transcript_score(item[0]),
                    -len(item[0]),
                ),
                reverse=True,
            )
            return wake_candidates[0]

        cleaned_candidates.sort(key=lambda item: (self._transcript_score(item[0]), len(item[0])), reverse=True)
        return cleaned_candidates[0]

    def _recognize_vosk_once(self, pcm_bytes: bytes, grammar: list[str] | None = None) -> str:
        if self._vosk_model is None:
            return ""

        if grammar:
            recognizer = KaldiRecognizer(self._vosk_model, SAMPLE_RATE, json.dumps(grammar, ensure_ascii=False))
        else:
            recognizer = KaldiRecognizer(self._vosk_model, SAMPLE_RATE)
        recognizer.SetWords(False)

        step = CHUNK_SIZE * SAMPLE_WIDTH
        for index in range(0, len(pcm_bytes), step):
            recognizer.AcceptWaveform(pcm_bytes[index : index + step])

        try:
            payload = json.loads(recognizer.FinalResult())
        except json.JSONDecodeError:
            return ""
        return str(payload.get("text", "")).strip()

    def _select_input_device(self) -> tuple[int, str, int]:
        pa = pyaudio.PyAudio()
        try:
            candidates: list[tuple[int, str]] = []
            blocked = {
                "microsoft 声音映射器 - input",
                "microsoft 声音映射器 - output",
                "主声音捕获驱动程序",
                "主声音驱动程序",
            }
            names = sr.Microphone.list_microphone_names()

            if self._microphone_name:
                for index, name in enumerate(names):
                    lower = name.lower()
                    if lower in blocked:
                        continue
                    if self._microphone_name.lower() == lower:
                        candidates.append((index, name))
                for index, name in enumerate(names):
                    lower = name.lower()
                    if lower in blocked:
                        continue
                    if self._microphone_name.lower() in lower and (index, name) not in candidates:
                        candidates.append((index, name))

            for index in range(pa.get_device_count()):
                info = pa.get_device_info_by_index(index)
                name = str(info.get("name", ""))
                lower = name.lower()
                if lower in blocked:
                    continue
                if info.get("maxInputChannels", 0) > 0 and (index, name) not in candidates:
                    candidates.append((index, name))

            errors: list[str] = []
            for index, name in candidates:
                try:
                    stream = pa.open(
                        format=pyaudio.paInt16,
                        channels=CHANNELS,
                        rate=SAMPLE_RATE,
                        input=True,
                        input_device_index=index,
                        frames_per_buffer=CHUNK_SIZE,
                    )
                    stream.close()
                    return index, name
                except Exception as exc:
                    errors.append(f"{index}:{name} -> {exc}")

            detail = "; ".join(errors[:4]) if errors else "没有找到可用录音设备"
            raise RuntimeError(detail)
        finally:
            pa.terminate()

    @staticmethod
    def _measure_ambient(stream) -> int:
        energies: list[int] = []
        for _ in range(AMBIENT_MEASURE_CHUNKS):
            chunk = stream.read(CHUNK_SIZE, exception_on_overflow=False)
            energies.append(audioop.rms(chunk, SAMPLE_WIDTH))
        if not energies:
            return 0
        energies.sort()
        return energies[len(energies) // 2]

    def _build_grammar_phrases(self) -> list[str]:
        base_phrases = [
            "开始向导",
            "开始配置",
            "继续",
            "下一步",
            "开始录入",
            "开始录音",
            "开始录制",
            "取消录入",
            "暂停录入",
            "重来",
            "重录",
            "退出桌面",
            "关闭桌面",
            "结束桌面",
            "你能做什么",
            "状态怎么样",
        ]
        phrases = list(dict.fromkeys([*self._wake_phrases, *base_phrases]))
        return [*phrases, "[unk]"]

    def _match_phrase(self, transcript: str) -> WakeMatch | None:
        normalized = self._normalize(transcript)
        aliases: dict[str, tuple[str, ...]] = {
            "在吗在吗": ("在吗在吗", "在么在么", "在吗", "在么"),
            "小虾小虾": ("小虾小虾", "小夏小夏", "小瞎小瞎", "小霞小霞", "小侠小侠"),
            "小龙虾": ("小龙虾", "小龙夏", "小龙下"),
            "小夏小夏": ("小夏小夏", "小虾小虾", "小瞎小瞎", "小侠小侠"),
            "小瞎小瞎": ("小瞎小瞎", "小虾小虾", "小夏小夏"),
        }
        for phrase in self._wake_phrases:
            for candidate in aliases.get(phrase, (phrase,)):
                if self._normalize(candidate) in normalized:
                    return WakeMatch(transcript=transcript, phrase=phrase)
        return None

    @staticmethod
    def _apply_gain(pcm_bytes: bytes, gain: float) -> bytes:
        try:
            return audioop.mul(pcm_bytes, SAMPLE_WIDTH, gain)
        except Exception:
            return pcm_bytes

    def _cleanup_transcript(self, text: str) -> str:
        cleaned = self._normalize(text)
        if not cleaned:
            return ""
        if cleaned in {"[unk]", "unk"}:
            return ""

        replacements = {
            "在么在么": "在吗在吗",
            "在么": "在吗",
            "小夏小夏": "小虾小虾",
            "小瞎小瞎": "小虾小虾",
            "小霞小霞": "小虾小虾",
            "小侠小侠": "小虾小虾",
            "小龙夏": "小龙虾",
            "小龙下": "小龙虾",
        }
        return replacements.get(cleaned, cleaned)

    def _transcript_score(self, text: str) -> int:
        score = 0
        if self._match_phrase(text):
            score += 10
        if any(keyword in text for keyword in ("开始向导", "开始配置", "继续", "下一步", "开始录入")):
            score += 5
        if len(text) >= 2:
            score += 2
        return score

    @staticmethod
    def _normalize(text: str) -> str:
        return (
            text.replace(" ", "")
            .replace("，", "")
            .replace("。", "")
            .replace("！", "")
            .replace("？", "")
            .replace(",", "")
            .replace(".", "")
            .replace("!", "")
            .replace("?", "")
            .lower()
        )
    def _select_input_device(self) -> tuple[int, str]:
        pa = pyaudio.PyAudio()
        try:
            candidates: list[tuple[int, str]] = []
            blocked = {
                "microsoft 澹伴煶鏄犲皠鍣?- input",
                "microsoft 澹伴煶鏄犲皠鍣?- output",
                "涓诲０闊虫崟鑾烽┍鍔ㄧ▼搴?",
                "涓诲０闊抽┍鍔ㄧ▼搴?",
            }
            names = sr.Microphone.list_microphone_names()

            if self._microphone_name:
                wanted = self._microphone_name.lower()
                for index, name in enumerate(names):
                    lower = name.lower()
                    if lower in blocked:
                        continue
                    if wanted == lower and (index, name) not in candidates:
                        candidates.append((index, name))
                for index, name in enumerate(names):
                    lower = name.lower()
                    if lower in blocked:
                        continue
                    if wanted in lower and (index, name) not in candidates:
                        candidates.append((index, name))

            for index in range(pa.get_device_count()):
                info = pa.get_device_info_by_index(index)
                name = str(info.get("name", ""))
                lower = name.lower()
                if lower in blocked:
                    continue
                if info.get("maxInputChannels", 0) > 0 and (index, name) not in candidates:
                    candidates.append((index, name))

            errors: list[str] = []
            viable: list[tuple[float, int, str]] = []
            for index, name in candidates:
                try:
                    stream = pa.open(
                        format=pyaudio.paInt16,
                        channels=CHANNELS,
                        rate=SAMPLE_RATE,
                        input=True,
                        input_device_index=index,
                        frames_per_buffer=CHUNK_SIZE,
                    )
                    score = self._probe_input_level(stream)
                    stream.close()
                    sample_rate = int(info.get("defaultSampleRate", SAMPLE_RATE))
                    viable.append((score, index, name, sample_rate))
                except Exception as exc:
                    errors.append(f"{index}:{name} -> {exc}")

            if viable:
                best_rank_by_index = {index: rank for rank, index, _name, _rate in candidates}
                best_rank = min(best_rank_by_index.get(index, 99) for _score, index, _name, _rate in viable)
                ranked_viable = [
                    (score, index, name, sample_rate)
                    for score, index, name, sample_rate in viable
                    if best_rank_by_index.get(index, 99) == best_rank
                ]
                ranked_viable.sort(key=lambda item: item[0], reverse=True)
                score, index, name, sample_rate = ranked_viable[0]
                self._on_log(
                    f"已选择麦克风: {name} (index={index}, rate={sample_rate}, score={score:.1f})"
                )
                return index, name, sample_rate

            detail = "; ".join(errors[:4]) if errors else "娌℃湁鎵惧埌鍙敤褰曢煶璁惧"
            raise RuntimeError(detail)
        finally:
            pa.terminate()

    @staticmethod
    def _probe_input_level(stream) -> float:
        energies: list[int] = []
        for _ in range(12):
            chunk = stream.read(CHUNK_SIZE, exception_on_overflow=False)
            energies.append(audioop.rms(chunk, SAMPLE_WIDTH))
        if not energies:
            return 0.0
        average = sum(energies) / len(energies)
        peak = max(energies)
        voiced = sum(1 for energy in energies if energy > 0)
        return average + peak * 0.8 + voiced * 4.0

    @staticmethod
    def _resample_pcm_if_needed(pcm_bytes: bytes, input_sample_rate: int) -> bytes:
        if input_sample_rate == SAMPLE_RATE:
            return pcm_bytes
        try:
            converted, _state = audioop.ratecv(
                pcm_bytes,
                SAMPLE_WIDTH,
                CHANNELS,
                input_sample_rate,
                SAMPLE_RATE,
                None,
            )
            return converted
        except Exception:
            return pcm_bytes

    def _select_input_device(self) -> tuple[int, str]:
        pa = pyaudio.PyAudio()
        try:
            blocked = {
                "microsoft 声音映射器 - input",
                "microsoft 声音映射器 - output",
                "主声音捕获驱动程序",
                "主声音驱动程序",
            }

            exact_matches: list[tuple[int, str]] = []
            partial_matches: list[tuple[int, str]] = []
            others: list[tuple[int, str]] = []
            wanted = (self._microphone_name or "").lower().strip()

            for index in range(pa.get_device_count()):
                info = pa.get_device_info_by_index(index)
                if info.get("maxInputChannels", 0) <= 0:
                    continue
                name = str(info.get("name", ""))
                lower = name.lower()
                if lower in blocked:
                    continue
                if wanted and lower == wanted:
                    exact_matches.append((index, name))
                elif wanted and wanted in lower:
                    partial_matches.append((index, name))
                else:
                    others.append((index, name))

            candidates = [*exact_matches, *partial_matches, *others]
            errors: list[str] = []
            viable: list[tuple[float, int, str]] = []

            for index, name in candidates:
                try:
                    stream = pa.open(
                        format=pyaudio.paInt16,
                        channels=CHANNELS,
                        rate=SAMPLE_RATE,
                        input=True,
                        input_device_index=index,
                        frames_per_buffer=CHUNK_SIZE,
                    )
                    score = self._probe_input_level(stream)
                    stream.close()
                    viable.append((score, index, name))
                except Exception as exc:
                    errors.append(f"{index}:{name} -> {exc}")

            if viable:
                viable.sort(key=lambda item: item[0], reverse=True)
                _score, index, name = viable[0]
                return index, name

            detail = "; ".join(errors[:6]) if errors else "没有找到可用录音设备"
            raise RuntimeError(detail)
        finally:
            pa.terminate()

    def _recognize_siliconflow_omni(self, audio: sr.AudioData) -> str:
        if not self._siliconflow_api_key:
            return ""

        audio_b64 = base64.b64encode(
            audio.get_wav_data(convert_rate=SAMPLE_RATE, convert_width=SAMPLE_WIDTH)
        ).decode("ascii")
        payload = {
            "model": self._siliconflow_asr_model,
            "temperature": 0,
            "max_tokens": 48,
            "messages": [
                {
                    "role": "system",
                    "content": "你是中文语音转写器。只输出用户实际说出的中文内容，不要解释，不要重复题目或提示词。如果没听清，就输出空字符串。",
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "转写这段语音，只返回用户实际说的话。"},
                        {
                            "type": "audio_url",
                            "audio_url": {
                                "url": f"data:audio/wav;base64,{audio_b64}"
                            },
                        },
                    ],
                },
            ],
        }
        request = urllib.request.Request(
            "https://api.siliconflow.cn/v1/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._siliconflow_api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                body = json.loads(response.read().decode("utf-8"))
        except Exception as exc:
            self._on_log(f"Omni 识别异常: {exc}")
            return ""

        try:
            content = body["choices"][0]["message"]["content"]
        except Exception:
            return ""

        if isinstance(content, list):
            text = "".join(
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ).strip()
        else:
            text = str(content).strip()

        blocked_fragments = (
            "请把这段音频转写",
            "转写这段语音",
            "只返回用户实际说的话",
            "简洁准确的中文文本",
            "中文语音转写器",
        )
        lowered = text.lower()
        if not text:
            return ""
        if any(fragment in text for fragment in blocked_fragments):
            return ""
        if lowered in {"空字符串", "未听清", "没听清", "听不清", "无法识别"}:
            return ""
        return self._cleanup_transcript(text)

    def _select_input_device(self) -> tuple[int, str, int]:
        pa = pyaudio.PyAudio()
        try:
            blocked = {
                "microsoft 声音映射器 - input",
                "microsoft 声音映射器 - output",
                "主声音捕获驱动程序",
                "主声音驱动程序",
            }
            wanted = (self._microphone_name or "").lower().strip()
            candidates: list[tuple[int, str, int]] = []

            for index in range(pa.get_device_count()):
                info = pa.get_device_info_by_index(index)
                if info.get("maxInputChannels", 0) <= 0:
                    continue
                name = str(info.get("name", ""))
                lower = name.lower()
                if lower in blocked:
                    continue
                sample_rate = int(info.get("defaultSampleRate", SAMPLE_RATE))
                rank = 2
                if wanted and lower == wanted:
                    rank = 0
                elif wanted and wanted in lower:
                    rank = 1
                candidates.append((rank, index, name, sample_rate))

            candidates.sort(key=lambda item: (item[0], item[1]))
            errors: list[str] = []
            viable: list[tuple[float, int, str, int]] = []

            for _rank, index, name, sample_rate in candidates:
                try:
                    stream = pa.open(
                        format=pyaudio.paInt16,
                        channels=CHANNELS,
                        rate=sample_rate,
                        input=True,
                        input_device_index=index,
                        frames_per_buffer=CHUNK_SIZE,
                    )
                    score = self._probe_input_level(stream)
                    stream.close()
                    viable.append((score, index, name, sample_rate))
                except Exception as exc:
                    errors.append(f"{index}:{name} -> {exc}")

            if viable:
                best_rank_by_index = {index: rank for rank, index, _name, _rate in candidates}
                best_rank = min(best_rank_by_index.get(index, 99) for _score, index, _name, _rate in viable)
                ranked_viable = [
                    (score, index, name, sample_rate)
                    for score, index, name, sample_rate in viable
                    if best_rank_by_index.get(index, 99) == best_rank
                ]
                ranked_viable.sort(key=lambda item: item[0], reverse=True)
                _score, index, name, sample_rate = ranked_viable[0]
                return index, name, sample_rate

            detail = "; ".join(errors[:6]) if errors else "没有找到可用录音设备"
            raise RuntimeError(detail)
        finally:
            pa.terminate()
