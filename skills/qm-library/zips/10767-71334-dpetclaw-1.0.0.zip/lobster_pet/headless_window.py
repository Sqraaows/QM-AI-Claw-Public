from __future__ import annotations

import json
import sys
import threading
from typing import Callable

from .states import PetState


class _RootProxy:
    def __init__(self, owner: "HeadlessPetWindow") -> None:
        self._owner = owner
        self.report_callback_exception = lambda *args, **kwargs: None

    def destroy(self) -> None:
        self._owner.destroy()


class HeadlessPetWindow:
    def __init__(self, always_on_top: bool = True, scale: float = 1.0) -> None:
        self.always_on_top = always_on_top
        self.scale = scale
        self.root = _RootProxy(self)
        self._closed = threading.Event()
        self._timers: set[threading.Timer] = set()
        self._lock = threading.Lock()
        self._emit("window_ready", {"scale": scale, "always_on_top": always_on_top})

    def set_state(self, state: PetState, detail: str | None = None) -> None:
        self._emit("state", {"state": state.value, "detail": detail or ""})

    def set_menu_actions(self, actions: dict[str, Callable]) -> None:
        self._emit("menu", {"items": list(actions.keys())})

    def show_subtitle(self, text: str, duration_ms: int = 5000) -> None:
        self._emit("subtitle", {"text": text, "duration_ms": duration_ms})

    def move_to_corner(self) -> None:
        return

    def show(self) -> None:
        self._emit("show", {})

    def after(self, delay_ms: int, callback) -> None:
        if self._closed.is_set():
            return

        def _wrapped() -> None:
            try:
                if not self._closed.is_set():
                    callback()
            finally:
                with self._lock:
                    self._timers.discard(timer)

        timer = threading.Timer(delay_ms / 1000.0, _wrapped)
        timer.daemon = True
        with self._lock:
            self._timers.add(timer)
        timer.start()

    def mainloop(self) -> None:
        self._closed.wait()

    def destroy(self) -> None:
        if self._closed.is_set():
            return
        self._closed.set()
        with self._lock:
            timers = list(self._timers)
            self._timers.clear()
        for timer in timers:
            timer.cancel()
        self._emit("closed", {})

    @staticmethod
    def _emit(event: str, payload: dict) -> None:
        frame = {"event": event, **payload}
        sys.stdout.write(json.dumps(frame, ensure_ascii=False) + "\n")
        sys.stdout.flush()
