from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path


CONFIG_FILE = "config.json"
ENV_FILE = ".env"
LOG_FILE = "lobster_pet.log"


@dataclass
class AppConfig:
    wake_phrases: list[str] = field(
        default_factory=lambda: [
            "在吗在吗",
            "小虾小虾",
            "小龙虾",
            "小夏小夏",
            "小瞎小瞎",
        ]
    )
    launch_command: str = r"C:\Users\super\Desktop\新建文件夹\科研智能体\start_openclaw_dashboard.cmd"
    openclaw_cli_path: str = r"C:\Users\super\AppData\Roaming\npm\openclaw.cmd"
    openclaw_thinking: str = "off"
    siliconflow_api_key: str | None = None
    siliconflow_chat_model: str = "Qwen/Qwen3-Omni-30B-A3B-Instruct"
    siliconflow_chat_system_prompt: str = (
        "你是一个桌面龙虾宠物助手。"
        "语气自然、简洁。"
        "当前项目以执行和转达指令为主，不做闲聊。"
    )
    siliconflow_tts_model: str = "fnlp/MOSS-TTSD-v0.5"
    siliconflow_tts_voice: str = "fnlp/MOSS-TTSD-v0.5:anna"
    microphone_name: str | None = "Microphone Array on SoundWire D"
    asr_backend: str = "siliconflow_omni"
    vosk_model_path: str = r"C:\Users\super\lobster_pet_assets\vosk-model-small-cn-0.22"
    faster_whisper_model_size_or_path: str = "small"
    faster_whisper_compute_type: str = "int8"
    siliconflow_asr_model: str = "Qwen/Qwen3-Omni-30B-A3B-Instruct"
    speaker_verification_threshold: float = 0.0
    wake_speaker_verification_threshold: float = 0.0
    command_speaker_verification_threshold: float = 0.0
    phrase_time_limit: int = 15
    pause_threshold: float = 0.6
    energy_threshold: int = 1
    environment_filter_level: int = 0
    dynamic_energy_threshold: bool = True
    pet_scale: float = 0.5
    window_anchor: str = "bottom_right"
    always_on_top: bool = True
    startup_state_timeout_ms: int = 4500
    conversation_timeout_ms: int = 90000
    setup_wizard_completed: bool = True
    autostart_openclaw_with_pet: bool = False
    guest_mode_duration_minutes: int = 10


def load_config(base_dir: Path) -> tuple[AppConfig, Path]:
    _load_dotenv(base_dir / ENV_FILE)
    config_path = base_dir / CONFIG_FILE
    if not config_path.exists():
        config = AppConfig()
        config_path.write_text(json.dumps(asdict(config), ensure_ascii=False, indent=2), encoding="utf-8")
        return config, config_path

    loaded = json.loads(config_path.read_text(encoding="utf-8-sig"))
    defaults = asdict(AppConfig())
    defaults.update(loaded)
    config = AppConfig(**defaults)
    if not config.siliconflow_api_key:
        config.siliconflow_api_key = os.getenv("SILICONFLOW_API_KEY")
    return config, config_path


def save_config(config_path: Path, config: AppConfig) -> None:
    config_path.write_text(
        json.dumps(asdict(config), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _load_dotenv(env_path: Path) -> None:
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value
