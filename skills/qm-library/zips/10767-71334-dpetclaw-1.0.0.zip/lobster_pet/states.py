from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PetState(str, Enum):
    SETUP = "setup"
    IDLE = "idle"
    LISTENING = "listening"
    VERIFYING = "verifying"
    RECOGNIZING = "recognizing"
    FORWARDING = "forwarding"
    WAKE_SUCCESS = "wake_success"
    GUARDING = "guarding"
    RUNNING = "running"
    ERROR = "error"


@dataclass(frozen=True)
class StatePresentation:
    label: str
    detail: str


STATE_PRESENTATIONS: dict[PetState, StatePresentation] = {
    PetState.SETUP: StatePresentation("设置中", "按提示完成初始化"),
    PetState.IDLE: StatePresentation("在线", "随时可以叫我"),
    PetState.LISTENING: StatePresentation("倾听中", "听到附近有声音了"),
    PetState.VERIFYING: StatePresentation("确认中", "正在确认是不是你"),
    PetState.RECOGNIZING: StatePresentation("识别中", "正在确认你说了什么"),
    PetState.FORWARDING: StatePresentation("转达中", "正在把你的指令交给 OpenClaw"),
    PetState.WAKE_SUCCESS: StatePresentation("已响应", "正在唤醒 OpenClaw"),
    PetState.GUARDING: StatePresentation("守护中", "正在检查并恢复 OpenClaw"),
    PetState.RUNNING: StatePresentation("在线", "OpenClaw 已启动"),
    PetState.ERROR: StatePresentation("出错了", "检查麦克风或启动脚本"),
}
