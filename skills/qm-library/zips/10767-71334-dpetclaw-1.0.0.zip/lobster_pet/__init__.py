"""Lobster desktop pet package."""
