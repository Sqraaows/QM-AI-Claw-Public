from __future__ import annotations

import json
import os
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Callable


FAST_REPLY_PREFIX = (
    "请用中文极简回复，最多两句，不要表格和长段落。"
    "\n用户："
)


class OpenClawClient:
    def __init__(
        self,
        cli_path: str,
        on_reply: Callable[[str], None],
        on_error: Callable[[str], None],
        thinking: str = "minimal",
    ) -> None:
        self._cli_path = cli_path
        self._on_reply = on_reply
        self._on_error = on_error
        self._thinking = thinking
        self._lock = threading.Lock()
        self._pending: dict[str, float] = {}
        self._process: subprocess.Popen[str] | None = None
        self._bridge_path = Path(__file__).resolve().parent.parent / "openclaw_bridge.mjs"
        self._start_process()

    def ask(self, text: str) -> None:
        worker = threading.Thread(target=self._send_request, args=(text,), daemon=True)
        worker.start()

    def close(self) -> None:
        with self._lock:
            process = self._process
            self._process = None
        if not process:
            return
        try:
            if process.stdin:
                process.stdin.close()
        except Exception:
            pass
        try:
            process.terminate()
        except Exception:
            pass

    def _start_process(self) -> None:
        startupinfo = None
        creationflags = 0
        if hasattr(subprocess, "STARTUPINFO"):
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        process = subprocess.Popen(
            ["node", str(self._bridge_path)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            startupinfo=startupinfo,
            creationflags=creationflags,
            env={
                **os.environ,
                "OPENCLAW_CLI_PATH": self._cli_path,
                "OPENCLAW_PACKAGE_ROOT": str(Path(self._cli_path).resolve().parent / "node_modules" / "openclaw"),
            },
        )

        self._process = process
        threading.Thread(target=self._read_stdout, args=(process,), daemon=True).start()
        threading.Thread(target=self._read_stderr, args=(process,), daemon=True).start()

    def _ensure_process(self) -> subprocess.Popen[str]:
        with self._lock:
            if self._process and self._process.poll() is None:
                return self._process
            self._start_process()
            assert self._process is not None
            return self._process

    def _send_request(self, text: str) -> None:
        request_id = uuid.uuid4().hex
        started_at = time.perf_counter()
        try:
            process = self._ensure_process()
            frame = {
                "id": request_id,
                "text": f"{FAST_REPLY_PREFIX}{text}",
                "thinking": self._thinking,
            }
            with self._lock:
                self._pending[request_id] = started_at
                if not process.stdin:
                    raise RuntimeError("OpenClaw bridge stdin unavailable")
                process.stdin.write(json.dumps(frame, ensure_ascii=False) + "\n")
                process.stdin.flush()
        except Exception as exc:
            with self._lock:
                self._pending.pop(request_id, None)
            self._on_error(f"OpenClaw 转达失败: {exc}")

    def _read_stdout(self, process: subprocess.Popen[str]) -> None:
        if not process.stdout:
            return
        for raw_line in process.stdout:
            line = raw_line.strip()
            if not line:
                continue
            try:
                frame = json.loads(line)
            except Exception:
                continue
            self._handle_frame(frame)

    def _read_stderr(self, process: subprocess.Popen[str]) -> None:
        if not process.stderr:
            return
        for raw_line in process.stderr:
            line = raw_line.strip()
            if not line:
                continue
            upper_line = line.upper()
            if any(marker in upper_line for marker in ("ERROR", "ERR_", "EXCEPTION", "CANNOT", "FAILED")):
                self._on_error(f"OpenClaw bridge: {line}")

    def _handle_frame(self, frame: dict) -> None:
        request_id = frame.get("id")
        with self._lock:
            started_at = self._pending.pop(request_id, None)

        if frame.get("ok") is not True:
            error = frame.get("error") or "unknown error"
            self._on_error(f"OpenClaw 转达失败: {error}")
            return

        text_reply = str(frame.get("text") or "").strip()
        if not text_reply:
            text_reply = "OpenClaw 已收到指令，但没有返回可读文本。"

        bridge_meta = frame.get("meta") or {}
        elapsed = time.perf_counter() - started_at if started_at is not None else 0.0
        duration_ms = bridge_meta.get("durationMs")
        if isinstance(duration_ms, (int, float)) and duration_ms > 0:
            self._on_reply(f"[{elapsed:.1f}s | OpenClaw {duration_ms / 1000:.1f}s] {text_reply}")
        else:
            self._on_reply(f"[{elapsed:.1f}s] {text_reply}")
