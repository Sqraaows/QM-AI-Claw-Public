from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from typing import Any, Callable


class SiliconFlowChatClient:
    def __init__(
        self,
        api_key: str,
        model: str,
        system_prompt: str,
        on_reply: Callable[[str], None],
        on_error: Callable[[str], None],
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._system_prompt = system_prompt
        self._on_reply = on_reply
        self._on_error = on_error

    def ask(self, user_text: str) -> None:
        worker = threading.Thread(target=self._request, args=(user_text,), daemon=True)
        worker.start()

    def _request(self, user_text: str) -> None:
        payload = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": self._system_prompt},
                {"role": "user", "content": user_text},
            ],
            "temperature": 0.7,
            "stream": False,
        }
        request = urllib.request.Request(
            "https://api.siliconflow.cn/v1/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                body = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="ignore")
            self._on_error(f"对话请求失败: HTTP {exc.code} {detail[:180]}")
            return
        except Exception as exc:
            self._on_error(f"对话请求失败: {exc}")
            return

        try:
            reply = body["choices"][0]["message"]["content"].strip()
        except Exception:
            self._on_error(f"对话响应格式异常: {body}")
            return

        self._on_reply(reply)


class SiliconFlowPetBrainClient:
    def __init__(
        self,
        api_key: str,
        model: str,
        on_reply: Callable[[dict[str, Any]], None],
        on_error: Callable[[str], None],
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._on_reply = on_reply
        self._on_error = on_error
        self._system_prompt = (
            "你是桌面龙虾宠物的大脑调度器。"
            "你要根据用户的一句话，决定是仅仅简短回应，还是把内容转发给 OpenClaw 执行。"
            "必须只输出 JSON，不要输出 markdown。"
            'JSON 格式固定为 {"reply":"给用户的简短口语回复","forward_to_openclaw":true/false,"forward_text":"若需要转发给 OpenClaw，则填写要转发的文本，否则为空"}。'
            "规则："
            "1. 对寒暄、确认、感谢、简单状态回应，forward_to_openclaw=false。"
            "2. 对明确任务、提问、执行指令、让机器人做事，forward_to_openclaw=true。"
            "3. reply 必须简短自然，像桌宠口语，比如“好的，收到”“我来转达给 OpenClaw”“没问题”。"
        )

    def decide(self, user_text: str) -> None:
        worker = threading.Thread(target=self._request, args=(user_text,), daemon=True)
        worker.start()

    def _request(self, user_text: str) -> None:
        payload = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": self._system_prompt},
                {"role": "user", "content": user_text},
            ],
            "temperature": 0.2,
            "stream": False,
        }
        request = urllib.request.Request(
            "https://api.siliconflow.cn/v1/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                body = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="ignore")
            self._on_error(f"大模型调度失败: HTTP {exc.code} {detail[:180]}")
            return
        except Exception as exc:
            self._on_error(f"大模型调度失败: {exc}")
            return

        try:
            raw_reply = body["choices"][0]["message"]["content"].strip()
            json_start = raw_reply.find("{")
            json_end = raw_reply.rfind("}")
            if json_start == -1 or json_end == -1:
                raise ValueError(raw_reply)
            result = json.loads(raw_reply[json_start : json_end + 1])
            if "reply" not in result or "forward_to_openclaw" not in result or "forward_text" not in result:
                raise ValueError(raw_reply)
        except Exception:
            self._on_error("大模型调度返回了不可解析结果")
            return

        self._on_reply(result)
