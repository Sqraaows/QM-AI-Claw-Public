# Dpetclaw — 龙虾守护宠物

- **Slug**: `dpetclaw`
- **Name**: Dpetclaw 龙虾守护宠物
- **Tags**: desktop-pet, voice-assistant, speaker-verification, openclaw-bridge, electron, python
- **Version**: 1.0.0

## 描述

桌面端 AI 语音助手桌宠，基于**声纹识别 + OpenClaw Gateway**，为用户提供贴身语音指令入口。

### 核心功能

- 🎤 **语音唤醒词检测**（5个中文唤醒词：在吗在吗/小虾小虾/小龙虾/小夏小夏/小瞎小瞎）
- 🔊 **声纹验证**：3次采样生成主人声纹模板，非主人无法操控
- 🤖 **OpenClaw 指令转发**：唤醒后语音直接转给 OpenClaw AI 处理
- 👤 **访客沙箱模式**：非主人只能获取公开信息，无法访问本地数据
- 🔈 **TTS 语音播报**：支持硅基流动 MOSS-TTS
- 🖥️ **Electron 透明窗口桌宠 UI**：桌面宠物形象
- 🛡️ **Gateway 自动守护**：掉线后 8 秒内自动重启 OpenClaw

### 技术架构

- **后端**：Python（语音监听/ASR/声纹/TTS/OpenClaw Bridge）
- **前端**：Electron（透明窗口桌宠 UI）
- **ASR 后端**：支持 SiliconFlow Omni（在线）/ Vosk（本地）/ Faster-Whisper（本地）
- **认证**：声纹 SpeakerVerification + 唤醒词双重门禁

## 安装

### 前置依赖

- Python 3.10+
- Node.js 18+
- FFmpeg（音频处理）
- 硅基流动 API Key（[cloud.siliconflow.cn](https://cloud.siliconflow.cn) 注册）

### 安装步骤

```bash
# 1. 克隆项目
git clone https://github.com/stonestorm2024/Dpetclaw.git
cd Dpetclaw

# 2. 安装依赖
pip install -r requirements.txt
npm install

# 3. 配置 API Key
cp .env.example .env
# 编辑 .env，填入 SILICONFLOW_API_KEY

# 4. 录入主人声音
python register_owner_voice.py
# 朗读引导词：小龙虾守护已激活，今天也请听我的命令。（3次）

# 5. 启动桌宠
wscript .\start_lobster_pet_electron_silent.vbs
```

## 配置

`config.json`（首次运行后自动生成）：

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `wake_phrases` | 唤醒词列表 | 见上 |
| `siliconflow_api_key` | 硅基流动 Key | 需在 `.env` 配置 |
| `asr_backend` | ASR 后端 | `siliconflow_omni` |
| `speaker_verification_threshold` | 声纹阈值 | `0.65` |
| `pet_scale` | 宠物缩放 | `0.5` |
| `guest_mode_duration_minutes` | 访客模式时长 | `10` |

## 使用流程

1. 启动桌宠
2. 说"在吗在吗"或"小虾小虾"
3. 桌宠做唤醒词匹配 → 声纹验证
4. 验证通过后转发指令给 OpenClaw
5. 90秒内继续说的话自动转达

**访客模式**：说"开启访客模式"，非主人获得公开帮助。

## 文件结构

```
Dpetclaw/
├── lobster_pet/          # Python 核心
│   ├── app.py            # 主控制器
│   ├── voice_listener.py  # 语音监听 + ASR
│   ├── speaker_verifier.py # 声纹验证
│   ├── openclaw_client.py  # OpenClaw Gateway 通信
│   └── electron_bridge_main.py # Electron 后端桥接
├── electron/              # Electron 前端
│   ├── main.js           # 主进程
│   └── renderer/          # 前端 UI
├── openclaw_bridge.mjs    # Gateway 桥接器
├── register_owner_voice.py # 声纹录入
├── config.json           # 运行时配置
└── requirements.txt
```

## 发布者

**@stonestorm2024** — [GitHub](https://github.com/stonestorm2024/Dpetclaw)
