process.env.OPENCLAW_HIDE_BANNER ??= "1";
process.env.NODE_NO_WARNINGS ??= "1";

const passthroughLog = (...args) => {
  const text = args
    .map((value) => {
      if (typeof value === "string") return value;
      try {
        return JSON.stringify(value);
      } catch {
        return String(value);
      }
    })
    .join(" ");
  process.stderr.write(`${text}\n`);
};

console.log = passthroughLog;
console.info = passthroughLog;
console.warn = passthroughLog;
console.error = passthroughLog;

import fs from "node:fs";
import crypto from "node:crypto";
import os from "node:os";
import path from "node:path";
import readline from "node:readline";
import { pathToFileURL } from "node:url";

function resolveOpenClawRoot() {
  const cliPath = process.env.OPENCLAW_CLI_PATH?.trim();
  const explicitRoot = process.env.OPENCLAW_PACKAGE_ROOT?.trim();

  const candidates = [
    explicitRoot,
    cliPath ? path.join(path.dirname(cliPath), "node_modules", "openclaw") : null,
    path.join(os.homedir(), "AppData", "Roaming", "npm", "node_modules", "openclaw"),
  ].filter(Boolean);

  for (const candidate of candidates) {
    if (fs.existsSync(path.join(candidate, "package.json"))) {
      return candidate;
    }
  }

  throw new Error("Cannot locate OpenClaw package root");
}

function resolveDistModule(rootDir, prefix, marker) {
  const distDir = path.join(rootDir, "dist");
  const entries = fs
    .readdirSync(distDir)
    .filter((name) => name === `${prefix}.js` || (name.startsWith(`${prefix}-`) && name.endsWith(".js")))
    .sort();

  for (const name of entries) {
    const fullPath = path.join(distDir, name);
    const source = fs.readFileSync(fullPath, "utf8");
    if (!marker || source.includes(marker)) {
      return fullPath;
    }
  }

  throw new Error(`Cannot resolve OpenClaw dist module for prefix "${prefix}"`);
}

const openclawRoot = resolveOpenClawRoot();
const methodScopesModulePath = resolveDistModule(openclawRoot, "method-scopes", "GatewayClient as ");
const versionModulePath = resolveDistModule(openclawRoot, "version", "VERSION as ");
const { d: GatewayClient } = await import(pathToFileURL(methodScopesModulePath).href);
const { n: VERSION } = await import(pathToFileURL(versionModulePath).href);

const rl = readline.createInterface({
  input: process.stdin,
  crlfDelay: Infinity,
});

let queue = Promise.resolve();
let sharedClient = null;
let sharedHello = null;
let sharedReadyPromise = null;
let sharedReadyResolve = null;
let sharedReadyReject = null;

function resetSharedClient() {
  sharedClient = null;
  sharedHello = null;
  sharedReadyPromise = null;
  sharedReadyResolve = null;
  sharedReadyReject = null;
}

function createGatewayClient() {
  const client = new GatewayClient({
    url: "ws://127.0.0.1:19001",
    token: "openclaw",
    instanceId: `lobster-bridge-${Date.now()}-${crypto.randomUUID()}`,
    clientName: "cli",
    clientVersion: VERSION,
    mode: "cli",
    role: "operator",
    scopes: [
      "operator.admin",
      "operator.read",
      "operator.write",
      "operator.approvals",
      "operator.pairing",
    ],
    deviceIdentity,
    minProtocol: 3,
    maxProtocol: 3,
    onHelloOk: async (hello) => {
      sharedHello = hello;
      sharedReadyResolve?.(client);
    },
    onConnectError: (error) => {
      const wrapped = error instanceof Error ? error : new Error(String(error));
      sharedReadyReject?.(wrapped);
      resetSharedClient();
    },
    onClose: () => {
      resetSharedClient();
    },
  });

  return client;
}

async function ensureGatewayClient() {
  if (sharedClient && sharedHello) {
    return sharedClient;
  }

  if (sharedReadyPromise) {
    return await sharedReadyPromise;
  }

  sharedReadyPromise = new Promise((resolve, reject) => {
    sharedReadyResolve = resolve;
    sharedReadyReject = reject;
  });

  sharedClient = createGatewayClient();
  sharedClient.start();

  const timeoutPromise = new Promise((_, reject) => {
    setTimeout(() => reject(new Error("gateway bridge connect timeout")), 20000);
  });

  try {
    return await Promise.race([sharedReadyPromise, timeoutPromise]);
  } catch (error) {
    try {
      sharedClient?.stop();
    } catch {}
    resetSharedClient();
    throw error;
  }
}

function writeFrame(frame) {
  process.stdout.write(`${JSON.stringify(frame)}\n`);
}

function loadDeviceIdentity() {
  const identityPath = path.join(os.homedir(), ".openclaw", "identity", "device.json");
  const parsed = JSON.parse(fs.readFileSync(identityPath, "utf8"));
  return {
    deviceId: parsed.deviceId,
    publicKeyPem: parsed.publicKeyPem,
    privateKeyPem: parsed.privateKeyPem,
  };
}

const deviceIdentity = loadDeviceIdentity();

async function requestThroughGateway(frame) {
  const client = await ensureGatewayClient();
  const sessionKey =
    sharedHello?.snapshot?.sessionDefaults?.mainSessionKey || "agent:main:main";
  const result = await client.request(
    "agent",
    {
      agentId: "main",
      sessionKey,
      message: String(frame.text ?? ""),
      thinking: typeof frame.thinking === "string" ? frame.thinking : "minimal",
      idempotencyKey: crypto.randomUUID(),
    },
    {
      expectFinal: true,
      timeoutMs: 180000,
    },
  );
  return { result, sessionKey };
}

async function runRequest(frame) {
  const startedAt = Date.now();
  try {
    const { result, sessionKey } = await requestThroughGateway(frame);

    const payloads = Array.isArray(result?.result?.payloads) ? result.result.payloads : [];
    const text = payloads
      .map((payload) => (typeof payload?.text === "string" ? payload.text.trim() : ""))
      .filter(Boolean)
      .join("\n")
      .trim();

    writeFrame({
      id: frame.id,
      ok: true,
      text: text || "OpenClaw 已收到指令，但没有返回可读文本。",
      meta: {
        bridgeElapsedMs: Date.now() - startedAt,
        durationMs: result?.result?.meta?.durationMs ?? null,
        sessionKey,
      },
    });
  } catch (error) {
    writeFrame({
      id: frame.id,
      ok: false,
      error: error instanceof Error ? error.message : String(error),
      meta: {
        bridgeElapsedMs: Date.now() - startedAt,
      },
    });
  }
}

rl.on("line", (line) => {
  const trimmed = line.trim();
  if (!trimmed) return;

  let frame;
  try {
    frame = JSON.parse(trimmed);
  } catch (error) {
    writeFrame({
      id: null,
      ok: false,
      error: `invalid json: ${error instanceof Error ? error.message : String(error)}`,
    });
    return;
  }

  queue = queue.then(() => runRequest(frame)).catch((error) => {
    writeFrame({
      id: frame?.id ?? null,
      ok: false,
      error: error instanceof Error ? error.message : String(error),
    });
  });
});

rl.on("close", async () => {
  try {
    await queue;
  } finally {
    try {
      sharedClient?.stop();
    } catch {}
    process.exit(0);
  }
});
