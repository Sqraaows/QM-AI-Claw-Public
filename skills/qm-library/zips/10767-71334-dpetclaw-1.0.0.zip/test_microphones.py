from __future__ import annotations

import sys

import speech_recognition as sr


def list_devices() -> list[str]:
    names = sr.Microphone.list_microphone_names()
    for index, name in enumerate(names):
        print(f"{index}: {name}")
    return names


def test_device(index: int) -> None:
    recognizer = sr.Recognizer()
    recognizer.pause_threshold = 0.8
    recognizer.energy_threshold = 220
    recognizer.dynamic_energy_threshold = True

    names = sr.Microphone.list_microphone_names()
    if index < 0 or index >= len(names):
        print("设备编号无效")
        return

    print(f"使用设备 {index}: {names[index]}")
    microphone = sr.Microphone(device_index=index)
    with microphone as source:
        print("正在校准环境噪声 1 秒...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        print("现在说一句话，8 秒内开始说。")
        try:
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=4)
        except Exception as exc:
            print(f"录音失败: {exc}")
            return

    try:
        text = recognizer.recognize_google(audio, language="zh-CN").strip()
    except Exception as exc:
        print(f"识别失败: {exc}")
        return

    print(f"识别结果: {text}")


def main() -> int:
    if len(sys.argv) == 1:
        list_devices()
        print("\n用法: python test_microphones.py 设备编号")
        return 0

    try:
        index = int(sys.argv[1])
    except ValueError:
        print("请输入数字设备编号")
        return 1

    test_device(index)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
