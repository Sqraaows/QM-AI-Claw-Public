from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request


API_URL = "https://api.siliconflow.cn/v1/chat/completions"
MODEL = "Qwen/Qwen3-Omni-30B-A3B-Instruct"


def chat_once(user_text: str) -> str:
    api_key = os.getenv("SILICONFLOW_API_KEY")
    if not api_key:
        raise RuntimeError("缺少 SILICONFLOW_API_KEY 环境变量")

    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "你是一只桌面龙虾助手，说话简洁、自然、友好。"},
            {"role": "user", "content": user_text},
        ],
        "temperature": 0.7,
        "stream": False,
    }

    request = urllib.request.Request(
        API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc
    except Exception as exc:
        raise RuntimeError(f"请求失败: {exc}") from exc

    try:
        return body["choices"][0]["message"]["content"].strip()
    except Exception as exc:
        raise RuntimeError(f"响应格式异常: {body}") from exc


def main() -> int:
    if len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:]).strip()
    else:
        prompt = input("你想问什么？ ").strip()

    if not prompt:
        print("请输入问题。")
        return 1

    try:
        reply = chat_once(prompt)
    except Exception as exc:
        print(f"调用失败: {exc}")
        return 1

    print(reply)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
