from __future__ import annotations

import speech_recognition as sr


TARGET_NAME = "Microphone Array on SoundWire Device"


def find_microphone() -> tuple[int | None, str]:
    names = sr.Microphone.list_microphone_names()
    for index, name in enumerate(names):
        if TARGET_NAME.lower() in name.lower():
            return index, name
    return None, "系统默认麦克风"


def main() -> None:
    recognizer = sr.Recognizer()
    recognizer.pause_threshold = 0.8
    recognizer.energy_threshold = 220
    recognizer.dynamic_energy_threshold = True

    device_index, label = find_microphone()
    print(f"使用设备: {label}")

    microphone = sr.Microphone(device_index=device_index)
    with microphone as source:
        print("正在校准环境噪声，请保持安静 1 秒...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        print("现在请说：小虾小虾 或 在吗在吗")
        audio = recognizer.listen(source, timeout=8, phrase_time_limit=4)

    try:
        text = recognizer.recognize_google(audio, language="zh-CN").strip()
    except Exception as exc:
        print(f"识别失败: {exc}")
        return

    print(f"识别结果: {text}")


if __name__ == "__main__":
    main()
