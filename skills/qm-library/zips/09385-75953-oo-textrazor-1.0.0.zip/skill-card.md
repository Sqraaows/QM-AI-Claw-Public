## Description: <br>
Operate TextRazor through an OOMOL-connected account to inspect schemas, analyze content, classify text, extract entities, and manage TextRazor classifier or dictionary resources. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External developers and analysts use this skill to operate TextRazor through an OOMOL-connected account, inspect live connector schemas, analyze or classify text, extract named entities, and manage custom classifier categories or entity dictionaries. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send user text or documents to the external TextRazor service for analysis. <br>
Mitigation: Avoid submitting secrets or sensitive documents unless the user has approved that data flow and the connected TextRazor/OOMOL account is appropriate for the content. <br>
Risk: The skill can create, update, or delete TextRazor classifier and dictionary resources. <br>
Mitigation: Require explicit user confirmation for the exact target, payload, and expected effect before any create, update, remove, or delete action. <br>
Risk: The short catalog description understates the state-changing resource management capabilities. <br>
Mitigation: Review the action-specific documentation and live connector schema before running commands, especially when the user expected read-only access. <br>


## Reference(s): <br>
- [TextRazor homepage](https://www.textrazor.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [TextRazor connection settings](https://console.oomol.com/app-connections?provider=textrazor) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
