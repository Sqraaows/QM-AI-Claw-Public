## Description: <br>
Trello lets an agent read, search, create, and update Trello boards, lists, cards, labels, members, checklists, comments, and URL attachments through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, employees, and developers use this skill to operate Trello workspaces from an agent workflow, including board discovery, card management, checklist updates, comments, attachments, and membership or label changes. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, archive, remove, comment on, attach to, and otherwise change Trello resources in the connected account. <br>
Mitigation: Review the target board, list, card, member, label, attachment, and JSON payload before approving any state-changing action. <br>
Risk: Shared or business Trello boards may expose workspace data or affect collaborators when an agent runs member, label, archive, comment, or attachment actions. <br>
Mitigation: Use the least-privileged connected account practical for the task and confirm the intended effect with the user before write or destructive operations. <br>


## Reference(s): <br>
- [ClawHub Trello skill](https://clawhub.ai/oomol/oo-trello) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Trello homepage](https://trello.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command examples and JSON payloads.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and a connected Trello account.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
