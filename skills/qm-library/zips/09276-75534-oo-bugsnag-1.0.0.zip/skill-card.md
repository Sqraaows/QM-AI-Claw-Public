## Description: <br>
Bugsnag lets agents search and read Bugsnag organizations, projects, errors, events, and releases through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and support engineers use this skill to inspect Bugsnag organizations, projects, errors, error events, and releases from a connected Bugsnag account without handling raw API tokens locally. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Commands can access Bugsnag data through the user's connected account. <br>
Mitigation: Use an appropriately scoped Bugsnag connection and review the action name and JSON payload before execution. <br>
Risk: First-time setup may install or authenticate the oo CLI on the local environment. <br>
Mitigation: Run setup steps only after an auth, connection, or missing-command failure, and verify the install command before use. <br>


## Reference(s): <br>
- [Bugsnag homepage](https://www.bugsnag.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Bugsnag skill on ClawHub](https://clawhub.ai/oomol/oo-bugsnag) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Guidance, API calls] <br>
**Output Format:** [Markdown with inline bash commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Live action results are JSON when commands are run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
