## Description: <br>
Evenium helps an agent use an OOMOL-connected Evenium account to inspect schemas and run event and guest actions through the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External teams and operators use this skill to retrieve Evenium event and guest information, including RSVP and post-event attendance status, from a connected OOMOL account. It is intended for agents that need guided shell commands and schema inspection before calling Evenium connector actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses an account-connected CLI and requires sensitive Evenium credentials through OOMOL. <br>
Mitigation: Install only when the agent should use the connected OOMOL/Evenium account, keep the connection scoped to the needed account, and review the oo CLI install command before running it. <br>
Risk: The security summary flags broad activation language for Evenium requests. <br>
Mitigation: Use the skill only for clearly scoped Evenium tasks and inspect the action schema before building or running any payload. <br>
Risk: A read-labeled action is documented as changing Evenium state. <br>
Mitigation: Require explicit user confirmation before any action that could change guest or event state, especially get_guest_post_status. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/oomol/oo-evenium) <br>
- [Evenium homepage](https://corp.evenium.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, JSON, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to inspect the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
