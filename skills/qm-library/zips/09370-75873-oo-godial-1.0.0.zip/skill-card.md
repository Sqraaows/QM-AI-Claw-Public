## Description: <br>
GoDial lets an agent read GoDial accounts, lists, and contacts and create contacts through an OOMOL-connected GoDial account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and business teams use this skill to let an agent browse GoDial company records, retrieve specific contacts, list contact lists, and create contacts after user review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an OOMOL-connected GoDial account and can expose company accounts, lists, and contact records available to that account. <br>
Mitigation: Install and use it only for accounts whose GoDial data the agent is allowed to access. <br>
Risk: The create_contact action changes GoDial state by adding a contact to a target list. <br>
Mitigation: Review and confirm the exact contact creation payload and intended list before approving the write action. <br>
Risk: The action schema can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing payloads. <br>


## Reference(s): <br>
- [ClawHub GoDial skill](https://clawhub.ai/oomol/oo-godial) <br>
- [GoDial homepage](https://godial.cc) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the live GoDial connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
