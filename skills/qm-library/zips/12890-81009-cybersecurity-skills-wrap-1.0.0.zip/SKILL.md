---
name: Cybersecurity Skills 网络安全技能集
slug: cybersecurity-skills-wrap
description: Cybersecurity Skills 网络安全技能集 — 整合多种开源安全工具的渗透测试和安全评估工具包。支持漏洞扫描、密码破解、网络侦察、权限维持等核心功能。基于 Kali Linux 工具链二次开发，提供统一命令行界面和自动化脚本。适用于安全工程师、CTF 选手、企业安全团队等需要快速执行安全评估的场景。每项功能均配有详细使用文档和最佳实践建议。 | 来源：https://github.com/q15004040209-creator/cybersecurity-skills-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/cybersecurity-skills-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
