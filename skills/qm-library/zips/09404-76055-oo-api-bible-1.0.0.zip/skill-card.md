## Description: <br>
API.Bible helps an agent search and read scripture data through the OOMOL API.Bible connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to retrieve Bible versions, books, chapters, verses, passages, and scripture search results from API.Bible through a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive API.Bible credentials through an OOMOL-connected account. <br>
Mitigation: Connect only the API.Bible account or API key intended for this skill, and use it only if OOMOL as an intermediary is acceptable. <br>
Risk: First-time setup may require running an external CLI installation command. <br>
Mitigation: Review the installation command before running it and install the CLI only from the documented OOMOL source. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub API.Bible Skill](https://clawhub.ai/oomol/oo-api-bible) <br>
- [API.Bible Homepage](https://scripture.api.bible/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command examples and JSON API responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
