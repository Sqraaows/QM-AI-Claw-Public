## Description: <br>
OneDrive lets agents read, create, update, delete, search, upload, and download OneDrive content through OOMOL's one_drive connector and oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate a connected OneDrive account from an agent, including browsing, metadata lookup, file transfer, folder creation, updates, and deletes. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Downloaded files are staged in transit storage before delivery. <br>
Mitigation: Confirm where transit data is stored, who can access it, and how long it is retained before downloading sensitive OneDrive files. <br>
Risk: Create, update, upload, move, rename, and delete actions can change or remove OneDrive data. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running any write or destructive action. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing or running each action payload. <br>


## Reference(s): <br>
- [ClawHub OneDrive skill page](https://clawhub.ai/oomol/oo-one-drive) <br>
- [OneDrive homepage](https://www.microsoft.com/microsoft-365/onedrive/online-cloud-storage) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands use the OOMOL oo CLI and return connector JSON responses when run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
