## Description: <br>
Generate AI images and videos with 17+ active models via Wuli.art open platform API. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[sir1st-inc](https://clawhub.ai/user/sir1st-inc) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative users use this skill to generate or edit images and videos through Wuli.art from text prompts and reference media. It supports text-to-image, image editing, text-to-video, image-to-video, first-last-frame video, auto-video, prompt optimization, uploads, and no-watermark downloads when available. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Prompts and referenced images or videos are sent to Wuli.art and may be uploaded to Wuli OSS for processing. <br>
Mitigation: Avoid sensitive, private, regulated, or confidential media and review prompts before submission. <br>
Risk: Generated outputs are saved in the current directory and may be opened automatically by the local default viewer. <br>
Mitigation: Run the skill in an appropriate working directory and inspect generated files before sharing or reuse. <br>


## Reference(s): <br>
- [Wuli Skill on ClawHub](https://clawhub.ai/sir1st-inc/wuli) <br>
- [Wuli.art](https://wuli.art) <br>
- [Wuli Platform API Documentation](references/%E3%80%90%E5%91%9C%E5%93%A9Wuli%E3%80%91%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0%20API%20%E6%96%87%E6%A1%A3.md) <br>
- [Wuli Platform API endpoint](https://platform.wuli.art) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Files, Guidance] <br>
**Output Format:** [Markdown guidance with shell command examples and generated media files saved to the current directory] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires WULI_API_TOKEN and Python 3; sends prompts and referenced images or videos to Wuli.art, may upload local or remote media to Wuli OSS, downloads generated media, and may open outputs with the local default viewer. Security review verdict: clean. Mitigation: avoid sensitive, private, regulated, or confidential media, review prompts before submission, and use a scoped token where possible.] <br>

## Skill Version(s): <br>
1.0.8 (source: server evidence and artifact manifest) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
