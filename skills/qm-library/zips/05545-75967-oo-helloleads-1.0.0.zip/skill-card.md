## Description: <br>
HelloLeads helps agents read visible web form definitions and submit lead data through an OOMOL-connected HelloLeads account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and teams use this skill to operate HelloLeads web form workflows through an OOMOL-connected account. It supports inspecting the live connector schema, reading a web form definition, and submitting a single lead payload after confirming write effects. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates through an OOMOL-connected HelloLeads account and requires sensitive credentials or account access. <br>
Mitigation: Use an already connected account, avoid handling raw credentials directly, and review requested account access before installation or execution. <br>
Risk: The submit_web_form action creates external HelloLeads state by submitting a lead payload. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running the write action. <br>
Risk: Connector schemas and upstream fields can change over time. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing or submitting payloads. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-helloleads) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [HelloLeads homepage](https://www.helloleads.io/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Live connector responses are JSON objects containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
