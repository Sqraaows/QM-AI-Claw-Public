## Description: <br>
Aviationstack connects agents to Aviationstack through OOMOL's oo CLI for searching and reading aviation data, including flights, routes, airports, airlines, aircraft, cities, countries, and taxes. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Aviationstack action schemas and run read-only aviation data queries through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive Aviationstack credentials connected through OOMOL. <br>
Mitigation: Use only the read/query access needed for the Aviationstack connection and keep credentials managed through the OOMOL account. <br>
Risk: First-time setup may require installing the OOMOL oo CLI with remote install scripts. <br>
Mitigation: Review the OOMOL CLI installation step before running it, as recommended by the security guidance. <br>
Risk: Aviationstack requests depend on OOMOL account state, connection scopes, credential freshness, and billing. <br>
Mitigation: Treat authentication, scope, credential, and billing failures as setup issues and resolve them before retrying data queries. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-aviationstack) <br>
- [Aviationstack homepage](https://aviationstack.com/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only Aviationstack actions return JSON data and an execution ID through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
