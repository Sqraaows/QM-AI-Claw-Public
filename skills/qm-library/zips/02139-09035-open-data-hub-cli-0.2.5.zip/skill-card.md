## Description: <br>
Query Open Data Hub/NOI Techpark data through `odh`: Tourism, Mobility, traffic, A22, parking, EV charging, STA GTFS, and transit. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[galjos](https://clawhub.ai/user/galjos) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to query ODH/NOI Techpark tourism, mobility, traffic, parking, EV charging, and transit data through the `odh` CLI while preserving source and freshness warnings. <br>

### Deployment Geography for Use: <br>
Global; practical data coverage is primarily South Tyrol / Autonomous Province of Bolzano, Italy. <br>

## Known Risks and Mitigations: <br>
Risk: The setup guidance includes an optional shell installer fetched over curl. <br>
Mitigation: Prefer the pinned Go install path when possible; if using the shell installer, download and inspect it first and only run it when the GitHub project and install destination are trusted. <br>
Risk: ODH data can include stale rows, ambiguous locations, or missing realtime entities. <br>
Mitigation: Use the skill's discovery and freshness checks, surface returned warnings and source fields, and avoid presenting stale or missing realtime data as confirmed current status. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/galjos/open-data-hub-cli) <br>
- [odh-cli GitHub Repository](https://github.com/galjos/odh-cli) <br>
- [Open Data Hub API](https://opendatahub.com/api/) <br>
- [Open Data Hub Datasets](https://docs.opendatahub.com/en/latest/datasets.html) <br>
- [Open Data Hub Mobility Getting Started](https://docs.opendatahub.com/en/latest/howto/mobility/getstarted.html) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON-output recommendations] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the `odh` CLI binary and favors JSON output for parsing.] <br>

## Skill Version(s): <br>
0.2.5 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
