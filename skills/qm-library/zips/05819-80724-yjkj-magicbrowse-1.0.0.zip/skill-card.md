## Description: <br>
Browser automation fallback through the magicbrowse CLI with goal-driven act as the default primitive and observe/primitives only for recovery, with changed page state verified by fresh observation. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[xor777](https://clawhub.ai/user/xor777) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use MagicBrowse when native browser tools cannot reliably navigate a target page. The skill guides agents through setup, browser-session lifecycle, natural-language navigation, recovery primitives, and controlled stops at approval, authentication, CAPTCHA, identity, and payment boundaries. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses an external browser-automation CLI with an API key and gateway processing of page context. <br>
Mitigation: Use it only for approved workflows, keep API keys private, and avoid private pages unless the user approves that browser context being processed. <br>
Risk: Vision mode can send screenshots or richer page context outside the browser. <br>
Mitigation: Use vision only as an approved retry mode and avoid it on sensitive pages unless the user explicitly accepts that exposure. <br>
Risk: Browser automation can reach pages where the next action would buy, submit, change, delete, or otherwise affect an account or external system. <br>
Mitigation: Stop for explicit confirmation before consequential actions, re-observe the page after approval, and execute only the approved action. <br>
Risk: Credentials, identity, payment, banking, CAPTCHA, or memory-managed fields may be encountered during navigation. <br>
Mitigation: Stop at those boundaries, surface the handoff to the user or approved workflow, and never invent or enter sensitive values. <br>
Risk: Attaching to existing profiles or CDP endpoints inherits the authority of that browser session. <br>
Mitigation: Use fresh browser sessions by default and require explicit approval before using existing profiles, user data directories, or CDP endpoints. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/xor777/magicbrowse) <br>
- [MagicBrowse CLI Package](https://www.npmjs.com/package/@mercuryo-ai/magicbrowse-cli) <br>
- [OpenClaw Marketplace README](https://github.com/MercuryoAI/skills/blob/main/docs/magicbrowse/openclaw/marketplace/README.md) <br>
- [Command Guide](references/commands.md) <br>
- [Guardrails](references/guardrails.md) <br>
- [Status Handling](references/statuses.md) <br>
- [Worked Example](references/workflow.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, json, text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON status examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the magicbrowse CLI and MAGICPAY_API_KEY for gateway-backed act operations.] <br>

## Skill Version(s): <br>
0.1.14 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
