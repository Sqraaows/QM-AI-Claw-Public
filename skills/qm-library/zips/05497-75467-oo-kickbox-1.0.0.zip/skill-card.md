## Description: <br>
Kickbox (kickbox.com). Use this skill for Kickbox requests that verify email deliverability or check disposable email status through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to run Kickbox email verification and disposable email checks from an agent workflow through the oo CLI. It helps inspect live connector schemas, construct JSON payloads, and return Kickbox risk and deliverability signals. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Kickbox lookups may send email addresses or domains through the connected service. <br>
Mitigation: Confirm the lookup is intended and avoid submitting unnecessary sensitive email or domain data. <br>
Risk: First-time setup may require installing the oo CLI or starting an authentication flow. <br>
Mitigation: Require explicit user approval before running remote installers or login commands. <br>
Risk: Connector action schemas can change upstream. <br>
Mitigation: Fetch the live action schema before constructing each connector payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-kickbox) <br>
- [Kickbox Homepage](https://kickbox.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an OOMOL sign-in, and a connected Kickbox account.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
