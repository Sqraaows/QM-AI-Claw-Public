## Description: <br>
AeroLeads retrieves prospect details, emails, phone numbers, company, education, skills, and related profile data from a public LinkedIn profile URL through an OOMOL-connected AeroLeads account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, employees, and developers use this skill to look up AeroLeads prospect and contact details from public LinkedIn profile URLs through an authenticated OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can return emails, phone numbers, LinkedIn profile details, and other personal data. <br>
Mitigation: Use returned data only with appropriate authorization or lawful basis, and handle it as sensitive personal data. <br>
Risk: First-time setup may involve running an installer script from a URL. <br>
Mitigation: Verify the official oo CLI installer source before running any pipe-to-shell setup command. <br>
Risk: Expired credentials, missing scopes, or billing stops can prevent successful lookups. <br>
Mitigation: Use the documented OOMOL connection, credential, and billing remediation steps only after a command fails with the matching error. <br>


## Reference(s): <br>
- [AeroLeads homepage](https://aeroleads.com) <br>
- [ClawHub AeroLeads skill page](https://clawhub.ai/oomol/oo-aeroleads) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The action requires the oo CLI, an authenticated OOMOL account, and a connected AeroLeads API-key credential.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
