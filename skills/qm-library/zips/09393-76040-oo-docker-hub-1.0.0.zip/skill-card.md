## Description: <br>
Operates Docker Hub repositories, tags, teams, organization members, and organization access tokens through an OOMOL-connected Docker Hub account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and platform teams use this skill to inspect and administer Docker Hub repositories, image metadata, organization teams, members, and organization access tokens from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change Docker Hub organization or repository state, including repository creation, member invitations or removals, and team deletion. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write or destructive actions. <br>
Risk: The skill requires a connected Docker Hub account and can expose sensitive administrative information such as organization access token listings. <br>
Mitigation: Install only when OOMOL and the connected account are trusted for the requested Docker Hub administration scope, and review sensitive read requests before execution. <br>
Risk: Connector input and output fields can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing action payloads. <br>


## Reference(s): <br>
- [Docker Hub homepage](https://hub.docker.com) <br>
- [ClawHub Docker Hub skill page](https://clawhub.ai/oomol/oo-docker-hub) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, JSON, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload or response details] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution and requires confirmation for write or destructive Docker Hub actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
