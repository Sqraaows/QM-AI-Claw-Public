## Description: <br>
Brave Search lets an agent run web, image, news, and video searches through an OOMOL-connected Brave Search account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to retrieve Brave Search results without calling the Brave API directly. It supports web, image, news, and video search workflows through the OOMOL CLI connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may require installing and trusting the OOMOL CLI before first use. <br>
Mitigation: Verify the OOMOL CLI installer and install it only in environments where OOMOL is approved. <br>
Risk: Search requests route through an OOMOL-connected Brave Search account and may use sensitive credentials. <br>
Mitigation: Connect only the Brave Search API key intended for this workflow and confirm account, billing, and connection status before use. <br>
Risk: Connector schemas can change upstream. <br>
Mitigation: Inspect the live action schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [Brave Search homepage](https://search.brave.com/) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-brave-search) <br>


## Skill Output: <br>
**Output Type(s):** [text, JSON, shell commands, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses include connector data and execution metadata when actions are run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
