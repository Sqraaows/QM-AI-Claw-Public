## Description: <br>
apaleo lets agents operate apaleo through OOMOL-connected accounts for reading and changing property, unit, unit group, and unit attribute data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to operate apaleo through the OOMOL-connected apaleo connector, including property workflows and unit inventory, unit group, and unit attribute management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: State-changing apaleo actions can create, update, archive, delete, move, replace, or reset property and unit data. <br>
Mitigation: Require explicit approval with exact property, unit, unit group, unit attribute, and payload details before write or destructive actions. <br>
Risk: Connector runs operate through connected OOMOL and apaleo credentials and may return account data in command responses. <br>
Mitigation: Use least-privilege apaleo scopes where possible and run only against the intended connected account. <br>
Risk: Live connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live action schema before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub apaleo skill](https://clawhub.ai/oomol/oo-apaleo) <br>
- [apaleo homepage](https://apaleo.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands call the OOMOL oo CLI and return connector JSON responses with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
