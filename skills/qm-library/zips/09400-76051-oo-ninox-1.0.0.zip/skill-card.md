## Description: <br>
Ninox helps an agent read, create, update, search, and delete Ninox workspace, database, table, and record data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Ninox data workflows through the OOMOL oo CLI, including listing metadata, reading records, searching records, saving records, and deleting records. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and change Ninox data through an authenticated OOMOL connection. <br>
Mitigation: Install it only for intended Ninox automation, use a token with the minimum required permissions, and review requested operations before use. <br>
Risk: Save and delete actions can modify or remove Ninox records. <br>
Mitigation: Confirm exact payloads, record targets, and expected effects before running write or destructive actions. <br>


## Reference(s): <br>
- [Ninox homepage](https://ninox.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Ninox ClawHub release](https://clawhub.ai/oomol/oo-ninox) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
