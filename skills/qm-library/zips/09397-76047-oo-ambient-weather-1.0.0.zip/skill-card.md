## Description: <br>
Ambient Weather helps an agent list connected devices and read latest or historical observations through an OOMOL-connected Ambient Weather account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Ambient Weather connector schemas, list linked weather devices, and retrieve latest or recent historical observation records from a connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connecting an Ambient Weather account through OOMOL's CLI, which can read device metadata plus latest and historical weather observations. <br>
Mitigation: Install and use it only when OOMOL is trusted, connect only the intended account, and review requested scopes before use. <br>
Risk: First-time setup includes remote installer commands for the oo CLI. <br>
Mitigation: Review the installer before running it and prefer an approved installation path when one is available. <br>


## Reference(s): <br>
- [Ambient Weather homepage](https://ambientweather.net/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [get_device_history action](actions/get_device_history.md) <br>
- [get_latest_device_data action](actions/get_latest_device_data.md) <br>
- [list_devices action](actions/list_devices.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId fields; actions are read-only for linked Ambient Weather devices and observations.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
