---
name: cms-openclaw-honor
description: AI龙虾认证查询。用户询问「龙虾认证/AI龙虾/认证档位/本周 Token/Skill 命中/晋级条件/我是几级」等时，进入本 Skill 脚本调用流程；兼容说法「领虾档位/领虾等级」。通过依赖 cms-auth-skills 获取 AppKey 鉴权后查询当前员工本周认证状态；无需 access-token。
skillcode: cms-openclaw-honor
metadata:
  homepage: https://github.com/xgjktech/open-api
  version: 1.0.1
  status: ACTIVE
tools_provided:
  - name: honor_wall_client
    category: exec
    risk_level: low
    permission: read
    description: AI龙虾认证 Open API 客户端
    status: active
  - name: get-employee-status
    category: exec
    risk_level: low
    permission: read
    description: 查询当前员工本周 AI 龙虾认证档位、Token 用量、Skill 命中及晋级条件
    status: active
dependencies:
  - cms-auth-skills
openclaw:
  requires:
    bins:
      - python3
      - python
---

# cms-openclaw-honor — AI龙虾认证查询

OpenClaw 技能 **`name`** 为 `cms-openclaw-honor`，与 **`skillcode`** 一致。本技能用于查询**当前鉴权员工**在 AI 龙虾认证体系中的本周档位与晋级进度。

**当前版本**: 1.0.1

**接口版本**: 业务接口统一使用 `/open-api/ai-certification-honor-wall/*` 前缀，鉴权类型为 **`appKey`**（无需 `access-token`）。

## 能力概览

| 模块 | 说明 |
|------|------|
| `employee-status` | 查询当前员工本周认证档位（L1/L2/L3）、Token 用量、四 Skill 命中、晋级下一档条件 |

> 全公司认证榜单（`honor-wall`）、往期榜单（`honor-wall/history`）尚未在本 Skill 开放；若用户需要全榜，说明能力范围并引导 Web 认证/荣誉墙页面。

## 适用范围与歧义排除

- **本 skill 唯一指向**：通过 **appKey** 访问 open-api 暴露的 AI 龙虾认证接口（`/open-api/ai-certification-honor-wall/openclaw/*`）。
- **身份边界**：`corpId`、`employeeId` 由 open-api 根据 **个人 appKey** 自动解析，**调用方不得**在 Query/Header 中传入他人员工 ID 或企业 ID。
- **典型触发词**：AI龙虾、龙虾认证、认证档位、认证等级、L1/L2/L3、本周 Token、Skill 命中、晋级、我是几级；**兼容别名**：领虾、领虾档位、领虾等级、一级虾/二级虾/三级虾。
- **不走本 skill**：全公司榜单、他人档位查询、修改榜单数据。

## 统一规范

- 鉴权依赖：`cms-auth-skills/SKILL.md`
- 生产基址：`https://sg-al-cwork-web.mediportal.com.cn/open-api`
- 详细接口：`references/employee-status/README.md`
- 鉴权注入规则：`references/auth.md`

## 强制前置（鉴权）

调用任何脚本前，必须先通过依赖 Skill **`cms-auth-skills`** 获取有效 **AppKey**。

- AppKey 必须以 `--app-key` 注入脚本命令。
- 未鉴权时，**禁止**执行 `scripts/**/*.py`。
- 所有 HTTP 请求 Header 携带 `appKey`；**无需** `access-token`。

## 标准执行流程

1. 识别用户是否要**查询本人**认证档位（执行）还是了解规则（可文字说明后确认是否执行）。
2. 读取 `references/auth.md` 确认 AppKey 注入规则。
3. 读取 `references/employee-status/README.md`。
4. 执行 `python3 scripts/openclaw/get-employee-status.py --app-key "<AppKey>"`。
5. 将脚本输出的摘要呈现给用户；默认不回显完整 JSON。

## 脚本使用规则（强制）

1. 所有 Open API 调用必须通过 `scripts/` 下 Python 脚本执行。
2. 先读 `references` 再执行脚本。
3. 鉴权统一依赖 `cms-auth-skills`，脚本不实现登录与换 token。
4. 仅允许生产域名，不使用测试地址。
5. 出错时间隔 1 秒、最多重试 3 次。

## 输出规范（对用户）

优先输出：

- 姓名、部门、本周区间（`weekRange`）
- 当前认证档位（`tier` / `tierLabel`）或「未上榜」
- Token 用量（`totalInTokenDisplay`）、使用次数（`totalCnt`）、Skill 命中数
- 若有下一档：摘要 `nextTierRequirements.summary` 及未满足项

不暴露：appKey、完整原始 JSON（除非用户明确要求技术细节）。

## 分档规则速查（与认证榜单一致）

| 等级 | Token（本周） | 附加条件 |
|------|---------------|----------|
| L3 | ≥ 1 亿 | 在 L3 准入名单 |
| L2 | ≥ 2000 万 | 四 Skill 系统 ≥ 2 |
| L1 | ≥ 50 万 | AI 使用次数 > 20（至少 21 次） |
| 未上榜 | 不满足任一档 | — |

统计周期：**本周**（周五 00:00 — 下周四 23:59）。

## 错误处理

| 场景 | 处理 |
|------|------|
| `resultCode != 1` 或 HTTP 401 | 检查 AppKey 是否有效、是否已通过 cms-auth-skills 授权 |
| 400 缺少企业/员工信息 | 确认使用的是**绑定当前用户**的个人 appKey |
| 5xx | 间隔重试，最多 3 次后提示稍后重试 |

## 能力树

```text
cms-openclaw-honor/
├── SKILL.md
├── references/
│   ├── auth.md
│   ├── api-endpoints.md
│   └── employee-status/
│       └── README.md
└── scripts/
    └── openclaw/
        ├── honor_wall_client.py
        └── get-employee-status.py
```
