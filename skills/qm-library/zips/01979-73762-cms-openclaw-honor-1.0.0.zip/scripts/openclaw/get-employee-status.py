#!/usr/bin/env python3
"""
查询当前员工本周 AI 龙虾认证档位、Token 用量、Skill 命中及晋级条件。

Usage:
  python3 scripts/openclaw/get-employee-status.py --app-key "<AppKey>"
  python3 scripts/openclaw/get-employee-status.py --app-key "<AppKey>" --json

环境变量（仅本地调试，Agent 链路应使用 --app-key）:
  XG_BIZ_API_KEY / XG_APP_KEY
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from honor_wall_client import HonorWallClient, make_client


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="AI龙虾认证查询")
    parser.add_argument("--app-key", help="AppKey（由 cms-auth-skills 注入）")
    parser.add_argument("--json", action="store_true", help="输出完整 JSON 响应")
    parser.add_argument("--max-retries", type=int, default=3, help="失败重试次数（默认 3）")
    return parser.parse_args(argv)


def format_summary(data: dict) -> str:
    if not data:
        return "未获取到档位数据。"

    name = data.get("name") or "—"
    dept = data.get("deptDisplay") or "—"
    week = data.get("weekRange") or "—"
    tier_label = data.get("tierLabel")
    is_ranked = data.get("isRanked")
    token_disp = data.get("totalInTokenDisplay") or "—"
    total_cnt = data.get("totalCnt")
    skill_cnt = data.get("skillSystemCount")

    if tier_label:
        tier_line = f"当前档位：{tier_label}（{data.get('tier') or ''}）"
    elif is_ranked is False or data.get("tier") is None:
        tier_line = "当前档位：未上榜"
    else:
        tier_line = "当前档位：—"

    lines = [
        f"【AI龙虾认证】{name} | {dept}",
        f"统计周期：{week}",
        tier_line,
        f"本周输入 Token：{token_disp} | AI 使用次数：{total_cnt if total_cnt is not None else '—'}",
        f"四 Skill 命中数：{skill_cnt if skill_cnt is not None else '—'}",
    ]

    hits = data.get("skillHits") or {}
    labels = data.get("skillSystemLabels") or {}
    if hits and labels:
        hit_names = [labels.get(k, k) for k, v in hits.items() if v]
        if hit_names:
            lines.append("已命中 Skill：" + "、".join(hit_names))

    next_label = data.get("nextTierLabel")
    req = data.get("nextTierRequirements")
    if next_label and req:
        summary = req.get("summary")
        if summary:
            lines.append(f"晋级{next_label}：{summary}")
        elif req.get("allMet"):
            lines.append(f"晋级{next_label}：条件已满足（以本周榜单为准）")
    elif data.get("tier") == "L3":
        lines.append("已达最高档（三级），无下一档。")

    demotion = data.get("demotionTag")
    if demotion and demotion != "none":
        lines.append(f"降档标记：{demotion}")

    return "\n".join(lines)


def call_with_retry(client: HonorWallClient, max_retries: int) -> dict:
    last = None
    for attempt in range(1, max_retries + 1):
        last = client.get_employee_status()
        code = last.get("resultCode")
        if code == 1:
            return last
        if code in (401, 400):
            return last
        if attempt < max_retries:
            time.sleep(1)
    return last or {"resultCode": 0, "resultMsg": "无响应", "data": None}


def main(argv=None) -> int:
    args = parse_args(argv)
    app_key = args.app_key or os.environ.get("XG_BIZ_API_KEY") or os.environ.get("XG_APP_KEY")
    if not app_key:
        print("错误: 缺少 AppKey，请先调用 cms-auth-skills 并通过 --app-key 注入。", file=sys.stderr)
        return 1

    client = make_client(app_key)
    result = call_with_retry(client, args.max_retries)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("resultCode") == 1 else 1

    if result.get("resultCode") != 1:
        msg = result.get("resultMsg") or "请求失败"
        print(f"错误: {msg} (resultCode={result.get('resultCode')})", file=sys.stderr)
        return 1

    print(format_summary(result.get("data") or {}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
