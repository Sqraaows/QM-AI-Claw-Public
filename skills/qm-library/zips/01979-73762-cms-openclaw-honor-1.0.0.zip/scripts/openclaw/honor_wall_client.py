#!/usr/bin/env python3
"""
AI龙虾认证 Open API 客户端。

约束：
- 仅封装只读接口
- appKey 由 cms-auth-skills 经 --app-key 注入，不在代码中硬编码
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from typing import Any, Dict, Optional


def _configure_io_encoding() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


class HonorWallClient:
    """AI龙虾认证 API 客户端"""

    BASE_URL = "https://sg-al-cwork-web.mediportal.com.cn/open-api"

    def __init__(self, app_key: Optional[str] = None, base_url: Optional[str] = None):
        _configure_io_encoding()
        self.app_key = app_key or os.environ.get("XG_BIZ_API_KEY") or os.environ.get("XG_APP_KEY")
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        if not self.app_key:
            raise ValueError("缺少 appKey，请通过 cms-auth-skills 注入 --app-key")

    def _headers(self) -> Dict[str, str]:
        return {"appKey": self.app_key, "Content-Type": "application/json"}

    def _request(self, method: str, path: str) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        req = urllib.request.Request(url, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"resultCode": exc.code, "resultMsg": body or exc.reason, "data": None}
        except Exception as exc:
            return {"resultCode": 0, "resultMsg": str(exc), "data": None}

    def get_employee_status(self) -> Dict[str, Any]:
        """查询当前 appKey 对应员工的本周 AI 龙虾认证档位。"""
        return self._request("GET", "/ai-certification-honor-wall/openclaw/employee-status")


def make_client(app_key: Optional[str] = None) -> HonorWallClient:
    return HonorWallClient(app_key=app_key)
