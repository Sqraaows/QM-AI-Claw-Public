# AI龙虾认证 Open API 端点

**生产基址**: `https://sg-al-cwork-web.mediportal.com.cn/open-api`

**鉴权**: Header `appKey`（由 cms-auth-skills 提供），无需 access-token。

## 已开放（本 Skill）

| 方法 | 路径 | 脚本 | 说明 |
|------|------|------|------|
| GET | `/ai-certification-honor-wall/openclaw/employee-status` | `get-employee-status.py` | 当前员工本周 AI 龙虾认证档位与晋级条件 |

## 下游（认证服务，经 Feign 转发）

open-api 收到请求后转发至 `ai-certification-honor-wall` 服务：

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/openclaw/employee-status` | 员工认证档位查询（内部） |

## 未纳入本 Skill

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/openclaw/honor-wall` | 本周认证/荣誉榜单 |
| GET | `/api/openclaw/honor-wall/history` | 往期榜单 |
