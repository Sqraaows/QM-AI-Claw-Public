# employee-status — AI龙虾认证查询

## 接口

| 项目 | 值 |
|------|-----|
| 方法 | `GET` |
| 开放路径 | `/open-api/ai-certification-honor-wall/openclaw/employee-status` |
| 完整 URL | `https://sg-al-cwork-web.mediportal.com.cn/open-api/ai-certification-honor-wall/openclaw/employee-status` |
| 鉴权 | Header `appKey`（必须） |
| Query / 身份参数 | **无**（corpId、employeeId 由 open-api 根据 appKey 自动解析） |

## 脚本

| 脚本 | 用途 |
|------|------|
| `scripts/openclaw/get-employee-status.py` | 调用上述接口并输出人类可读摘要 |

### 运行示例

```bash
python3 scripts/openclaw/get-employee-status.py --app-key "<AppKey>"
```

可选：

```bash
python3 scripts/openclaw/get-employee-status.py --app-key "<AppKey>" --json
```

`--json` 输出 open-api 原始 `Result` JSON（调试用）。

## 响应（open-api `Result` 包装）

成功时 `resultCode=1`，`data` 为业务对象，主要字段：

| 字段 | 说明 |
|------|------|
| `name` | 姓名 |
| `deptDisplay` | 部门展示 |
| `weekRange` / `dateRange` | 统计周期 |
| `tier` / `tierLabel` | 当前认证档位，未上榜为 null |
| `isRanked` | 是否上榜 |
| `totalInTokenDisplay` | Token 展示 |
| `totalCnt` | 本周 AI 使用次数 |
| `skillSystemCount` / `skillHits` | 四 Skill 命中 |
| `nextTier` / `nextTierLabel` | 下一档 |
| `nextTierRequirements` | 晋级条件（含 `summary`、`items`） |

## Agent 输出建议

1. 先给一句话结论：「您本周 AI 龙虾认证为 X 级 / 未上榜」。
2. 补充 Token、次数、Skill 命中。
3. 若有 `nextTierRequirements.summary`，说明距下一档差距。
4. 不输出 appKey 与冗长 JSON。

## 错误码

| resultCode / HTTP | 说明 |
|-------------------|------|
| 401 | appKey 无效或未鉴权 |
| 400 | 无法从 appKey 解析企业/员工（非个人 appKey） |
| 0 / 5xx | 服务异常，可重试 |
