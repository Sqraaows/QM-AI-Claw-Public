### cms-auth-skills：AppKey 获取与注入（强制）

本 Skill 所有脚本调用前，AppKey 获取必须通过依赖 Skill **`cms-auth-skills`** 完成。

#### 必须做

- 进入执行链路前，**必须先调用** `cms-auth-skills` 获取 AppKey。
- 将返回的 AppKey 以 **`--app-key`** 注入脚本：
  - `python3 scripts/openclaw/get-employee-status.py --app-key "<AppKey>"`
- 若使用 `--params-file`，JSON 中提供 `app_key` 字段。

#### 必须禁止

- 禁止向用户索要 AppKey。
- 禁止在 `cms-auth-skills` 未返回可用 AppKey 时继续执行脚本。
- 禁止在 Header 中附带 `access-token` 替代 appKey（本 Skill 约定仅 appKey）。

#### 请求头

| Header | 必填 | 说明 |
|--------|------|------|
| `appKey` | 是 | 个人 appKey，open-api 据此解析当前员工与企业 |

无需：`access-token`、`corp_id`、`employee_id` 等身份参数（由服务端鉴权后注入）。

#### 失败处理

- `cms-auth-skills` 失败：停止链路，引导用户重新授权后再试。
