## Description: <br>
AI龙虾认证查询：当用户询问龙虾认证、AI龙虾、认证档位、本周 Token、Skill 命中、晋级条件或本人等级时，先通过 cms-auth-skills 获取 AppKey，再查询当前员工本周认证状态；无需 access-token。 <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[spzwin](https://clawhub.ai/user/spzwin) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees use this skill to check their own weekly AI 龙虾 certification tier, token usage, Skill hits, and promotion requirements through a read-only Open API call. Agents use it when the user asks about their current certification status rather than company-wide rankings or another employee's status. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a personal AppKey and calls a production Open API service. <br>
Mitigation: Install only when the Open API service and cms-auth-skills dependency are trusted, pass the AppKey through the documented dependency flow, and avoid exposing the key in user-facing output. <br>
Risk: The skill is intended to read only the current employee's certification status. <br>
Mitigation: Do not supply corpId, employeeId, or other identity overrides; rely on the server to resolve the current employee from the AppKey. <br>
Risk: The skill contacts a documented production domain and does not need broad local privileges. <br>
Mitigation: Allow network access only to the documented production Open API domain and avoid broad filesystem access, background execution, or unrelated environment secrets. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/spzwin/cms-openclaw-honor) <br>
- [Publisher profile](https://clawhub.ai/user/spzwin) <br>
- [Open API homepage](https://github.com/xgjktech/open-api) <br>
- [Authentication reference](references/auth.md) <br>
- [AI 龙虾认证 Open API endpoints](references/api-endpoints.md) <br>
- [Employee status reference](references/employee-status/README.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, json, shell commands, guidance] <br>
**Output Format:** [Markdown summary with optional JSON for debugging] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses AppKey-based read-only API access and should not expose the AppKey or full raw JSON unless explicitly requested.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
