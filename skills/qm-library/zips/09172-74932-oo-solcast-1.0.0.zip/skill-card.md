## Description: <br>
Solcast provides OOMOL-connected access to Solcast irradiance and weather forecast, historical, and live estimated actual data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to retrieve Solcast solar irradiance and weather data for latitude and longitude based workflows. It supports forecasts up to 14 days ahead, historical estimated actuals from 2007 through 7 days ago, and live estimated actuals for the past 7 days. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: First-time setup may require installing the OOMOL CLI from remote installer scripts. <br>
Mitigation: Verify the OOMOL CLI source and install guide before running the installer, and install only when Solcast access through OOMOL is intended. <br>
Risk: The skill requires connecting a Solcast API key or account through OOMOL. <br>
Mitigation: Use a trusted OOMOL account, review the Solcast connection before use, and limit normal operation to the listed read-only Solcast data actions. <br>
Risk: Solcast connector schemas and defaults may change upstream. <br>
Mitigation: Inspect the live connector schema before constructing each payload and use the returned schema as the authority for request data. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-solcast) <br>
- [Solcast Homepage](https://solcast.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses OOMOL oo connector commands to inspect live schemas and run read-only Solcast data actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
