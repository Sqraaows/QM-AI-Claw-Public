---
name: daily-tech-briefing
description: 生成每日科技资讯简报，涵盖AI、网络安全、GitHub趋势、CVE漏洞、免费AI API等9大板块
category: productivity
version: 2.0.0
created: 2026-05-12
updated: 2026-05-13
---

# 📰 每日科技简报生成技能 v2.0

## 触发条件
当用户要求生成"每日科技简报"、"AI资讯汇总"、"网络安全日报"时使用此技能。

## 核心要求（用户偏好）
- **全部中文**：所有英文标题必须翻译为中文
- **每板块10条**：每个板块必须恰好10条，不能多也不能少
- **直接在聊天中发送**：不要只存文件，必须在对话中展示完整内容
- **主动汇报**：遇到问题第一时间告知，不要等用户追问
- **结构化输出**：每条新闻包含标题、详细描述（2-3句话）、来源链接
- **CVE板块必须包含**：CVE编号、CVSS评分、风险级别（🔴Critical/🟠High/🟡Medium/🟢Low）、修复方案

## 工作流程

### 阶段1：数据收集（并行获取所有数据源）

#### 环境限制（重要！）
- `pip install` 会因 PEP 668 失败，不要尝试
- 必须使用 Python 标准库：`urllib.request`、`xml.etree.ElementTree`、`json`、`re`
- 不要使用 `requests`、`feedparser` 等第三方库
- `execute_code` 有 50KB stdout 上限，完整简报必须分块生成或写入文件再读取
- `execute_code` 的 `/tmp` 目录是沙箱隔离的，不同调用间文件可能不可见
- 尽量在单次 `execute_code` 中完成所有逻辑

#### RSS源（用urllib.request获取）
```python
import urllib.request
import xml.etree.ElementTree as ET
import json, re
from datetime import datetime, timedelta

rss_sources = {
    "BBC Tech": "https://feeds.bbci.co.uk/news/technology/rss.xml",
    "The Hacker News": "https://feeds.feedburner.com/TheHackersNews",
    "Wired": "https://www.wired.com/feed/rss",
    "MIT Tech Review": "https://www.technologyreview.com/feed/",
    "Krebs on Security": "https://krebsonsecurity.com/feed/",
}

# 注意：某些RSS可能解析失败，需要regex备用方案
# Krebs返回HTML而非纯XML，需要用正则提取item
```

#### GitHub Trending API
```python
from datetime import datetime, timedelta
two_days_ago = (datetime.utcnow() - timedelta(days=2)).strftime("%Y-%m-%d")
github_url = f"https://api.github.com/search/repositories?q=created:>{two_days_ago}&sort=stars&order=desc&per_page=15"
# 需要Authorization header避免速率限制（如有token）
```

#### NVD CVE API
```python
today = datetime.utcnow().strftime("%Y-%m-%d")
yesterday = (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%d")
nvd_url = f"https://services.nvd.nist.gov/rest/json/cves/2.0/?pubStartDate={yesterday}T00:00:00.000&pubEndDate={today}T23:59:59.999&resultsPerPage=20"
```

#### 免费AI API信息（第9板块）
搜索以下来源获取最新免费AI TOKEN信息：
- GitHub搜索: `free ai api`、`free llm api`
- 已知稳定来源: [cool-ai-stuff](https://github.com/zukixa/cool-ai-stuff)
- 主要免费API提供商（较稳定，可预置）：
  - Google Gemini API、OpenAI体验金、Anthropic Claude、Cloudflare Workers AI
  - Groq、Together AI、Mistral AI、Cerebras、Hugging Face Inference API、zukijourney

### 阶段2：数据分类

#### 分类关键词
```python
ai_keywords = ['ai', 'artificial intelligence', 'machine learning', 'openai', 'chatgpt',
               'gemini', 'claude', 'llm', 'deep learning', 'neural', 'copilot', 'cursor',
               'gpt', 'transformer', 'model', 'training', 'inference', 'deepseek', 'qwen']

security_keywords = ['hack', 'breach', 'vulnerability', 'cyber', 'security', 'ransom',
                    'malware', 'attack', 'exploit', 'cve', 'leak', 'threat',
                    'compromise', 'patch', 'update', 'ddos', 'botnet', 'backdoor']

agent_keywords = ['agent', 'agentic', 'autonomous', 'tool use', 'function calling',
                  'mcp', 'crew', 'autogen', 'langchain', 'autonomous']

programming_keywords = ['code', 'programming', 'developer', 'github', 'npm', 'pypi',
                       'node', 'python', 'rust', 'compiler', 'ide', 'vscode', 'coding']
```

#### 分类逻辑
- 每条新闻只归入最匹配的主分类
- "AI × 安全"板块：同时匹配ai_keywords和security_keywords的新闻
- "AI赋能安全运维"板块：安全新闻中强调运维/防御的
- "AI智能体"板块：匹配agent_keywords；如果不足10条，从ai[]或programming[]中补充
- 免费API板块：独立搜索获取，不从RSS中分类

### 阶段3：简报生成（分块写入避免截断）

**关键**：完整简报约3-4万字符，超过execute_code的50KB输出限制。
解决方案：用execute_code生成并写入文件，然后用read_file读取发送。

```python
# 在execute_code中生成完整简报并写入文件
from hermes_tools import write_file

briefing = generate_full_briefing()  # 生成完整markdown
write_file(f"/tmp/daily_tech_briefing_{date}.md", briefing)
print("简报已生成")
```

然后用 `read_file` 读取文件内容，分段发送给用户。

### 阶段4：简报模板（9大板块）

```markdown
# 📰 每日科技简报 · {YYYY-MM-DD}

---

## 🤖 AI & 科技热点 TOP10
1. **中文标题**
   详细描述（2-3句话，中文）
   来源: [来源名](URL)

## 🔐 网络安全要闻 TOP10
（同上格式）

## 🔥 GitHub 今日 Star 飙升 TOP10
1. **项目名** (语言) ⭐ 星数
   中文描述
   项目URL

## 🤖🔐 AI × 网络安全 TOP10
（同新闻格式）

## 🛡️⚙️ AI赋能安全运维运营新技术 TOP10
（同新闻格式）

## 🦾 AI 智能体（Agent）最新动态 TOP10
（同新闻格式）

## 💻 AI 编程最新动态 TOP10
（同新闻格式）

## 🚨 每日CVE高危漏洞 TOP10
1. 🔴 **CVE编号** (CVSS: 分数 / 级别)
   漏洞描述（中文）
   **修复**: 具体修复方案

## 🆓 AI智能体免费TOKEN API TOP10
1. **API名称 — 免费额度说明**
   申请方法：具体步骤
   支持模型：模型列表
   调用示例：curl或代码示例
   支持Agent：✅ 功能列表

---
*简报自动生成于 {date} | 数据来源: BBC Tech, Hacker News, Krebs on Security, MIT Tech Review, Wired, The Hacker News, GitHub API, NVD API, GitHub Free AI List*
```

### CVE风险级别映射
```python
if cvss >= 9.0: level = "🔴 Critical"
elif cvss >= 7.0: level = "🟠 High"
elif cvss >= 4.0: level = "🟡 Medium"
else: level = "🟢 Low"
```

### CVE修复方案模板
- **Critical/High**: 立即更新补丁，评估影响范围，实施网络隔离
- **Medium**: 计划维护窗口更新，加强监控
- **Low**: 下次维护窗口更新，记录处理过程

## 踩坑记录（v2.0新增）

### 1. PEP 668环境限制
`pip install` 在此环境会失败，必须使用Python标准库。

### 2. execute_code输出截断
完整简报约3-4万字符，超过50KB上限。
**解决方案**：先写入文件，再用read_file读取。

### 3. execute_code沙箱隔离
不同execute_code调用的/tmp目录可能不共享。
**解决方案**：尽量在单次调用中完成所有逻辑。

### 4. RSS解析兼容性
部分RSS源（如Krebs）返回HTML而非标准XML。
**解决方案**：用regex作为XML解析的备用方案。

### 5. 数据不足时的补充策略
某些分类（如AI智能体）可能不足10条。
**解决方案**：从相关分类中选取最接近的新闻补充。

### 6. 中文翻译
没有翻译API，需要在生成时手动翻译英文标题和描述。
**解决方案**：在简报生成逻辑中内联翻译。

## 版本历史
- v1.0.0 (2026-05-12): 初始版本，支持8个板块
- v2.0.0 (2026-05-13): 新增"免费AI TOKEN API"板块（第9板块），新增踩坑记录，完善数据收集和分类逻辑，优化输出截断处理
