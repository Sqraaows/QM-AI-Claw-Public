## Description: <br>
Campaign Cleaner lets agents operate Campaign Cleaner through an OOMOL-connected account to submit email campaign HTML for analysis and manage saved campaign records. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and marketing operators use this skill to submit Campaign Cleaner analyses, inspect campaign status and results, download PDF reports, check credits, and delete saved campaigns when explicitly approved. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses an OOMOL-connected Campaign Cleaner account and requires sensitive credentials managed outside the skill. <br>
Mitigation: Install only when the agent should use that connected account, and review live connector schemas before constructing payloads. <br>
Risk: Sending a campaign or deleting a campaign can change Campaign Cleaner state. <br>
Mitigation: Require explicit user approval for send_campaign and delete_campaign, including the exact target and payload. <br>
Risk: Credit exhaustion can stop Campaign Cleaner operations. <br>
Mitigation: Check available credits before workflows that may consume Campaign Cleaner credits. <br>


## Reference(s): <br>
- [Campaign Cleaner homepage](https://campaigncleaner.com) <br>
- [ClawHub Campaign Cleaner skill page](https://clawhub.ai/oomol/oo-campaign-cleaner) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Files, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Can return Campaign Cleaner analysis data, processing status, credit details, and PDF analysis reports as files.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
