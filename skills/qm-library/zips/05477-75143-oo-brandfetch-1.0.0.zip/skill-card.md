## Description: <br>
Brandfetch lets an agent fetch brand profiles and resolve transaction labels through an OOMOL-connected Brandfetch account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to retrieve Brandfetch brand data or match transaction labels to merchant brands without handling Brandfetch API tokens directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL account connection for Brandfetch access. <br>
Mitigation: Install only in environments where use of OOMOL as the Brandfetch access intermediary is approved. <br>
Risk: First-time setup may require installing and signing in with the oo CLI, which can persist account configuration for future use. <br>
Mitigation: Review or trust the OOMOL CLI installer before setup and use approved accounts for Brandfetch connections. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema before constructing payloads. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-brandfetch) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Brandfetch homepage](https://brandfetch.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_brand action reference](actions/get_brand.md) <br>
- [get_transaction_info action reference](actions/get_transaction_info.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Configuration guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs agents to inspect the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
