## Description: <br>
Default token-efficient assistant discipline with minimal prompts, concise context, and short actionable outputs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[phoenixlucky](https://clawhub.ai/user/phoenixlucky) <br>

### License/Terms of Use: <br>
GPL-3.0 <br>


## Use Case: <br>
Developers and agent users use this skill to keep routine agent work concise: classify tasks, limit context gathering, use compact prompt frames, and return actionable results without unnecessary explanation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Concise-response defaults can be a poor fit for detailed teaching, broad exploration, or high-stakes legal, medical, or financial analysis. <br>
Mitigation: Override or disable the skill when the task needs depth, broad exploration, or high-stakes domain analysis. <br>
Risk: Capability tags in the release evidence include financial-authority and can-make-purchases even though the security summary says they do not reflect actual behavior. <br>
Mitigation: Treat those capability tags as inaccurate metadata and rely on the documented concise-response behavior during review and deployment. <br>
Risk: Aggressive context reduction may skip useful validation if applied mechanically. <br>
Mitigation: Keep the skill's quality baseline: do not omit safety checks, do not turn guesses into facts, and run necessary tests or verification for code changes. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/phoenixlucky/zerotoken-skill) <br>
- [Skill definition](artifact/SKILL.md) <br>
- [README](artifact/README.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Concise Markdown or plain text, with code or shell snippets when the underlying task requires them.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Designed to minimize unnecessary context, tool calls, and explanation while preserving safety and necessary verification.] <br>

## Skill Version(s): <br>
1.3.0 (source: frontmatter, package.json, CHANGELOG) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
