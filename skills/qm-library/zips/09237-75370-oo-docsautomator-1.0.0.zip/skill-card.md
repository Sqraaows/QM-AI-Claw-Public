## Description: <br>
DocsAutomator helps agents inspect workspace automation details and create or track DocsAutomator documents through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and teams with connected DocsAutomator workspaces use this skill to inspect automations, list template placeholders and queue statistics, and generate documents from templates. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Read and list actions can expose DocsAutomator workspace automation details. <br>
Mitigation: Install only for workspaces where the agent is allowed to view automation metadata and template placeholders. <br>
Risk: Document creation actions can change DocsAutomator state and consume service resources. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create_document or create_document_async. <br>
Risk: The skill requires connected service credentials through OOMOL. <br>
Mitigation: Use it only with an intended OOMOL account connection and resolve authentication or scope errors before retrying actions. <br>


## Reference(s): <br>
- [DocsAutomator homepage](https://www.docsautomator.co) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-docsautomator) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
