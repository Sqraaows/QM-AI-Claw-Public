

class InvalidLoginException(Exception):
    pass
