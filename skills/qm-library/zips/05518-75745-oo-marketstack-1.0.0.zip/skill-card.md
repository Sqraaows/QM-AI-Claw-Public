## Description: <br>
Marketstack helps agents retrieve end-of-day market data, ticker profiles, supported exchanges, and supported currencies through an OOMOL-connected Marketstack account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and analysts use this skill to query Marketstack financial market data from an agent workflow without handling raw Marketstack API tokens directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Marketstack credentials could be exposed if users paste API keys into chat or local files. <br>
Mitigation: Use the OOMOL connector configuration for credentials and avoid sharing raw API tokens directly with the agent. <br>
Risk: Connector input or output fields may change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>


## Reference(s): <br>
- [Marketstack homepage](https://marketstack.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-marketstack) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Runs read-oriented Marketstack connector actions and returns JSON data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
