## Description: <br>
Compresses long agent session history into a compact local context capsule before model calls while keeping recent messages verbatim. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[parad0x-labs](https://clawhub.ai/user/parad0x-labs) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill as an OpenClaw context engine to reduce token usage in long-running sessions while retaining recent turns verbatim. It is most appropriate when approximate older-history recall is acceptable and exact transcript fidelity is not required. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Older chat history is summarized rather than preserved exactly, so details, nuance, or exact wording can be lost. <br>
Mitigation: Use this skill only for sessions where approximate older-history recall is acceptable, and keep exact source material outside the compressed context when verbatim fidelity is required. <br>
Risk: Summarized prior history is placed into system context and can influence later model behavior from a privileged prompt position. <br>
Mitigation: Review whether system-context reinjection is appropriate for the workflow and avoid using the skill for sessions where prior untrusted content should not receive elevated prompt authority. <br>
Risk: The built-in redaction is best-effort pattern matching and may not remove all sensitive content. <br>
Mitigation: Do not rely on the skill as the only protection for secrets or highly sensitive data; apply separate data-handling safeguards before use. <br>


## Reference(s): <br>
- [Openclaw Context Capsule on ClawHub](https://clawhub.ai/parad0x-labs/context-capsule) <br>
- [Publisher profile](https://clawhub.ai/user/parad0x-labs) <br>


## Skill Output: <br>
**Output Type(s):** [text, configuration] <br>
**Output Format:** [Agent message context containing a compact system-context capsule plus recent messages kept verbatim.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Configurable message threshold and recent-message retention; older history is summarized and best-effort redacted before compression.] <br>

## Skill Version(s): <br>
1.4.0 (source: server release metadata and package.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
