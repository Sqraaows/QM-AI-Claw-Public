## Description: <br>
Close (close.com). Use this skill for ANY Close request: reading, creating, and updating data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and business teams use this skill to read, create, and update Close CRM leads, contacts, opportunities, and tasks from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can use an OOMOL-connected Close account to read CRM data and create or update Close records. <br>
Mitigation: Install only when this account access is acceptable, and review write payloads before approval. <br>
Risk: Create and update actions can change leads, contacts, opportunities, and tasks in Close. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>


## Reference(s): <br>
- [ClawHub Close Skill](https://clawhub.ai/oomol/oo-close) <br>
- [Close Homepage](https://www.close.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the oo CLI to inspect live connector schemas before running Close actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
