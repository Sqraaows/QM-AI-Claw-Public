## Description: <br>
This skill lets agents operate Razorpay through an OOMOL-connected account by inspecting connector schemas and running order, payment, and refund actions with the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to read Razorpay orders and payments and to create orders or refunds through an already connected OOMOL account. It is intended for payment-account operations where the agent should inspect the live connector schema before executing an action. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create orders and refunds in a live Razorpay account, which may affect payment operations. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create_order, create_refund, or any other write action. <br>
Risk: The skill requires access to an OOMOL-connected Razorpay account and therefore depends on sensitive credentials and account scopes. <br>
Mitigation: Install the oo CLI only from a trusted source, use the intended OOMOL account connection, and review payment, refund, customer, subscription, or deletion actions before execution. <br>
Risk: Connector schemas and upstream fields may change, so stale payload assumptions could cause failed or incorrect operations. <br>
Mitigation: Run oo connector schema for the target Razorpay action before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-razorpay) <br>
- [Razorpay homepage](https://razorpay.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Create order action](actions/create_order.md) <br>
- [Create refund action](actions/create_refund.md) <br>
- [Get order action](actions/get_order.md) <br>
- [Get payment action](actions/get_payment.md) <br>
- [List orders action](actions/list_orders.md) <br>
- [List payments action](actions/list_payments.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, Guidance] <br>
**Output Format:** [Markdown guidance with inline bash commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are JSON objects containing data and meta.executionId when the oo connector command runs.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
