## Description: <br>
Alibaba Cloud STS helps agents inspect schemas and run OOMOL-connected Alibaba Cloud STS actions to request temporary cloud credentials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill when an agent needs to obtain Alibaba Cloud STS temporary credentials through an OOMOL-connected account, including AssumeRole and OIDC federation flows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can mint temporary Alibaba Cloud credentials, and the security scan notes limited confirmation guidance around role, duration, permissions, and payload. <br>
Mitigation: Verify the role, session duration, permissions, and JSON payload before running an action, and treat returned credentials as secrets. <br>
Risk: Live connector schemas and defaults can change upstream. <br>
Mitigation: Fetch the authoritative action schema with `oo connector schema` before constructing each request payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-aliyun-sts) <br>
- [Alibaba Cloud STS homepage](https://www.alibabacloud.com/product/ram) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [assume_role action reference](actions/assume_role.md) <br>
- [get_federated_credentials action reference](actions/get_federated_credentials.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the `oo` CLI connector flow and returns command output that may contain temporary cloud credentials.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence release version and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
