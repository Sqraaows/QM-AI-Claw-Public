## Description: <br>
WebScraper.io lets an agent operate Web Scraper Cloud through OOMOL's webscraper_io connector for sitemap, scraping job, result download, and account-profile workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Web Scraper Cloud sitemaps and scraping jobs, download JSON Lines results, and inspect account information through a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a credentialed OOMOL connection to access WebScraper.io. <br>
Mitigation: Use the OOMOL-connected account flow and avoid handling raw WebScraper.io tokens directly. <br>
Risk: Create and update actions can change WebScraper.io sitemaps or scraping jobs. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>
Risk: Delete actions can remove WebScraper.io sitemaps or scraping jobs. <br>
Mitigation: Confirm the target identifier and get explicit user approval before running destructive actions. <br>
Risk: The optional OOMOL CLI setup path includes an installer command that must be trusted before execution. <br>
Mitigation: Review and trust the installer source first, or use a manually verified installation method where available. <br>


## Reference(s): <br>
- [WebScraper.io homepage](https://webscraper.io/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [OOMOL WebScraper.io connection page](https://console.oomol.com/app-connections?provider=webscraper_io) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing payloads; write and delete actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence release.version and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
