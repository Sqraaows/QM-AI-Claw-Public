## Description: <br>
Story Long Scan helps agents collect and analyze Chinese web-novel ranking data from platforms such as Qidian, Fanqie, JJWXC, Qimao, and Ciweimao to identify genre trends and topic opportunities. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Writers, editors, and market analysts use this skill to scan Chinese web-novel rankings, compare platform signals, and turn observed ranking patterns into topic recommendations and validation steps. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may scrape public ranking pages and drive browser automation against web-novel platforms. <br>
Mitigation: Install and run it only when scraping those public ranking pages is intended; review the selected platform and output directory before collection. <br>
Risk: Browser CDP collection can interact with an existing browser session, including logged-in contexts. <br>
Mitigation: Avoid running CDP against sensitive logged-in browser sessions unless required, and prefer isolated browser profiles for collection. <br>
Risk: The security evidence flags platform-gaming guidance and broad scraping behavior as suspicious. <br>
Mitigation: Do not follow artificial-engagement or ranking-timing tactics when they conflict with platform rules; use the reports as market-analysis inputs that require human review. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/worldwonderer/story-long-scan) <br>
- [OpenClaw source metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [Scan output format](references/scan-output-format.md) <br>
- [Topic decision guide](references/topic-decision.md) <br>
- [Publishing guide](references/publishing-guide.md) <br>
- [Reader profiling](references/reader-profiling.md) <br>
- [Genre trends](references/genre-trends.md) <br>


## Skill Output: <br>
**Output Type(s):** [markdown, shell commands, code, guidance] <br>
**Output Format:** [Markdown reports, Markdown topic-decision files, and shell commands for Node.js scraper scripts.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May write local Markdown scan reports and a topic decision file under the selected output directory.] <br>

## Skill Version(s): <br>
1.1.3 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
