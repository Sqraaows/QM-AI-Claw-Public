## Description: <br>
SatisMeter helps agents search and read SatisMeter customer feedback data through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and analytics users use this skill to retrieve SatisMeter projects, surveys, survey statistics, and response data through an authenticated OOMOL-connected SatisMeter account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The required oo CLI setup includes a user-visible remote installer command. <br>
Mitigation: Prefer the install guide or inspect the installer before execution, and avoid running remote installers automatically in sensitive environments. <br>
Risk: The skill requires an authenticated OOMOL-connected SatisMeter account and may depend on sensitive credentials. <br>
Mitigation: Do not request or handle raw SatisMeter tokens; rely on OOMOL server-side credential injection and only run authentication or connection setup after an actual auth or connection failure. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before building each payload. <br>
Risk: Future or adjacent connector actions that create, update, send, post, delete, or remove data could change SatisMeter state. <br>
Mitigation: Confirm the exact target, payload, and effect with the user before running any state-changing or destructive action. <br>


## Reference(s): <br>
- [SatisMeter homepage](https://satismeter.com) <br>
- [SatisMeter skill page](https://clawhub.ai/oomol/oo-satismeter) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples; connector responses are JSON.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
