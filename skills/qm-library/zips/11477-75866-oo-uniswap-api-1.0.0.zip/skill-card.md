## Description: <br>
Uniswap API helps agents use the OOMOL oo CLI connector to request Uniswap trade quotes, check ERC-20 approval requirements, and create swap transaction calldata. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill to inspect live Uniswap API action schemas and run quote, approval-check, and swap-calldata workflows through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Swap-building behavior could be misunderstood as either only preparing calldata or performing a value-changing operation. <br>
Mitigation: Require explicit user confirmation before any create_swap flow, verify calldata and recipient details before signing, and treat wallet signing/submission as the point where a trade can be executed. <br>
Risk: The skill requires wallet context and sensitive credentials through an OOMOL-connected account. <br>
Mitigation: Use an already connected account, avoid exposing raw credentials, and reconnect only when the connector reports an authentication, scope, or credential-expiration error. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-uniswap-api) <br>
- [Uniswap API Homepage](https://uniswap.org) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload/response expectations] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; action responses are expected as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
