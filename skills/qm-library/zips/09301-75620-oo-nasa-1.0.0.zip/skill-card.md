## Description: <br>
NASA (nasa.gov) helps agents search and retrieve NASA data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to query NASA data through the OOMOL NASA connector, including Astronomy Picture of the Day metadata, near-Earth object data, EPIC imagery metadata, and DONKI space weather events. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL account and NASA API credentials managed outside the skill. <br>
Mitigation: Review the OOMOL connection and CLI installer before first use, and run setup only after an authentication or connection error. <br>
Risk: The skill description broadly routes NASA-related requests through the connector, which may be unnecessary for general background questions. <br>
Mitigation: Prefer invoking the skill for specific NASA data lookups where live connector data is needed. <br>


## Reference(s): <br>
- [ClawHub NASA skill page](https://clawhub.ai/oomol/oo-nasa) <br>
- [NASA homepage](https://www.nasa.gov) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses schema-first connector calls and returns NASA data through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
