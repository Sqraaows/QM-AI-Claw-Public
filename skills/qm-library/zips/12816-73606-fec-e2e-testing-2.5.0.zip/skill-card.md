## Description: <br>
Use when creating, maintaining, debugging, or reviewing real-browser end-to-end tests with Playwright or Cypress, including Page Object models, CI artifacts, traces, flaky tests, cross-page visual regression, and critical user journeys such as login, payment, permissions, or CRUD. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[bovinphang](https://clawhub.ai/user/bovinphang) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and QA engineers use this skill to plan, write, debug, and review Playwright or Cypress end-to-end tests for critical browser user journeys, CI artifacts, flaky failures, visual regression checks, wallet flows, and high-risk payment or financial paths. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: E2E tests for login, payment, wallet, or financial paths can touch sensitive credentials, transaction state, or account data. <br>
Mitigation: Run these tests in staging, mocked, or explicitly skipped environments; avoid real production transactions and isolate test accounts. <br>
Risk: Screenshots, traces, videos, and HTML reports can expose sensitive test data. <br>
Mitigation: Treat generated artifacts as sensitive, limit retention and access, and review artifacts before sharing outside the test team. <br>
Risk: Flaky waits, random data, or order-dependent tests can make CI results misleading. <br>
Mitigation: Use locator auto-waiting, network or visible-state synchronization, repeatable seed data, teardown cleanup, and issue-linked flaky test isolation. <br>


## Reference(s): <br>
- [Playwright / Cypress E2E Patterns](references/playwright-patterns.md) <br>
- [E2E Advanced Testing Details](references/e2e-advanced.md) <br>
- [ClawHub Skill Page](https://clawhub.ai/bovinphang/fec-e2e-testing) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with code, shell command, and configuration examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include test plans, Page Object patterns, CI artifact guidance, failure analysis, and report templates.] <br>

## Skill Version(s): <br>
2.5.0 (source: server release evidence, README.md, metadata.json, package.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
