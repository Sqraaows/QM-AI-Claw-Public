## Description: <br>
Dev.to (dev.to). Use this skill for ANY Dev.to request: reading, creating, and updating data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and content operators use this skill to read Dev.to content, inspect account or organization data, and create or update Dev.to articles through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Dev.to account through OOMOL, which can expose account-related Dev.to data to agent workflows. <br>
Mitigation: Install only when the user is comfortable with that connection and has authorized the relevant Dev.to account in OOMOL. <br>
Risk: Create and update actions can change public Dev.to content. <br>
Mitigation: Confirm the exact article payload and intended effect with the user before running any create or update action. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-devto) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Dev.to homepage](https://dev.to) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, JSON, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions inspect live connector schemas before execution; create and update actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
