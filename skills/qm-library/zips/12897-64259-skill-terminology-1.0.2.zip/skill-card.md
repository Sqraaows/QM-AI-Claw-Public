## Description: <br>
Provides UML sequence-diagram terminology aliases for agents. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[lentiancn](https://clawhub.ai/user/lentiancn) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents and developers use this skill as an always-on reference for UML sequence diagram terminology, abbreviations, and multilingual aliases. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Always-on terminology guidance may affect wording in UML-related agent responses. <br>
Mitigation: Install only when a lightweight UML terminology reference is desired and review generated documentation before relying on it. <br>
Risk: The skill asks agents not to modify its installed skill files. <br>
Mitigation: Manage changes through the documented OpenClaw update flow instead of editing installed files directly. <br>


## Reference(s): <br>
- [UML terminology reference](references/uml.md) <br>
- [ClawHub skill page](https://clawhub.ai/lentiancn/skill-terminology) <br>


## Skill Output: <br>
**Output Type(s):** [text, guidance] <br>
**Output Format:** [Markdown reference text] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [No code execution; terminology reference only.] <br>

## Skill Version(s): <br>
1.0.2 (source: server evidence release.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
