## Description: <br>
Create and manage Volcengine cloud resources using the Volcengine CLI (`ve` command), with guidance for authentication, API discovery, read/write safety, and service-specific operations. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[volc-sdk-team](https://clawhub.ai/user/volc-sdk-team) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and cloud operators use this skill to query, create, modify, and troubleshoot Volcengine resources through the `ve` CLI. It helps agents authenticate safely, locate OpenAPI actions, fetch parameter documentation, and apply confirmation rules before write or destructive operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Authenticated cloud requests may be sent over insecure HTTP or to user- or environment-specified endpoints. <br>
Mitigation: Use trusted Volcengine HTTPS endpoints, avoid `--scheme http`, avoid custom `--host` or `VOLCENGINE_ENDPOINT` unless trusted, and consider enforcing HTTPS plus an allowlist of Volcengine domains. <br>
Risk: The skill requires OAuth tokens or sensitive Volcengine credentials for cloud operations. <br>
Mitigation: Use least-privileged or temporary credentials, do not expose access keys, secret keys, or session tokens, and avoid reading local Volcengine credential files. <br>
Risk: Write or destructive commands can create, modify, stop, delete, or release cloud resources. <br>
Mitigation: Confirm every write or destructive command with the user, prefer DryRun when supported, and show the command plus impact before execution. <br>
Risk: Test-only extension APIs may expose behavior that is not appropriate for normal release usage. <br>
Mitigation: Do not use `--include-test` unless explicitly reviewing test-only APIs in a controlled environment. <br>


## Reference(s): <br>
- [ClawHub Volcengine Cli release page](https://clawhub.ai/volc-sdk-team/volcengine-cli) <br>
- [Volcengine CLI GitHub releases](https://github.com/volcengine/volcengine-cli/releases) <br>
- [Volcengine CLI npm package](https://www.npmjs.com/package/@volcengine/cli) <br>
- [ALB Service Notes](references/alb.md) <br>
- [CLB Service Notes](references/clb.md) <br>
- [CR Service Notes](references/cr.md) <br>
- [DNS and Edge Service Notes](references/dns-edge.md) <br>
- [EBS Service Notes](references/ebs.md) <br>
- [ECS Service Notes](references/ecs.md) <br>
- [Extended APIs](references/extend-apis.md) <br>
- [IAM Service Notes](references/iam.md) <br>
- [KMS Service Notes](references/kms.md) <br>
- [Message Queue Service Notes](references/mq.md) <br>
- [NAT Gateway Service Notes](references/natgateway.md) <br>
- [Observability Service Notes](references/observability.md) <br>
- [RDS Service Notes](references/rds.md) <br>
- [Redis Service Notes](references/redis.md) <br>
- [Storage Service Notes](references/storage.md) <br>
- [veFaaS Service Notes](references/vefaas.md) <br>
- [VKE Service Notes](references/vke.md) <br>
- [VPC Service Notes](references/vpc.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include Volcengine CLI commands, configuration steps, API parameter guidance, and confirmation prompts for write or destructive cloud operations.] <br>

## Skill Version(s): <br>
1.0.9 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
