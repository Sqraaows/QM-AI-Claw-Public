## Description: <br>
ReadMe (readme.com). Use this skill for reading, creating, updating, and deleting ReadMe project data through the OOMOL `readme` connector and `oo` CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and documentation operators use this skill to manage ReadMe projects from an agent, including docs, categories, changelogs, custom pages, versions, API specifications, project metadata, OpenAPI schema retrieval, outbound IPs, doc search, and Owlbot answers. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, and delete ReadMe project content through an OOMOL-connected account. <br>
Mitigation: Review the exact payload before create or update actions, and require explicit approval for the specific item to delete. <br>
Risk: The skill requires sensitive credentials through an OOMOL account connection. <br>
Mitigation: Install and connect it only when the user intends to let an OOMOL-connected account operate the ReadMe project. <br>
Risk: First-time CLI installation or login changes the local agent environment and account session. <br>
Mitigation: Use the oo CLI installer or login flow only when setup is needed and the user trusts OOMOL. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-readme) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [ReadMe Homepage](https://readme.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [First-time setup guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses with data and meta.executionId when run through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
