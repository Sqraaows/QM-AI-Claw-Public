## Description: <br>
Enables agents to operate ChatBotKit through OOMOL's oo CLI, including reading, creating, and updating bots, conversations, datasets, files, and usage data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage ChatBotKit resources from an agent session, including bots, conversations, messages, datasets, dataset records, files, and usage reporting. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a user's ChatBotKit account through OOMOL-connected credentials. <br>
Mitigation: Install only when account-level ChatBotKit access through an agent is intended, and rely on OOMOL's credential connection rather than exposing raw tokens. <br>
Risk: Create, update, upload, sync, and conversation actions can change ChatBotKit state. <br>
Mitigation: Review the exact payload and intended effect before running write actions. <br>
Risk: First-time CLI, authentication, or connection setup can affect the user's local or OOMOL account state. <br>
Mitigation: Run setup steps only after a command fails with the matching authentication, connection, CLI, or billing error. <br>


## Reference(s): <br>
- [ChatBotKit homepage](https://chatbotkit.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub ChatBotKit skill page](https://clawhub.ai/oomol/oo-chatbotkit) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector actions return JSON responses containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
