## Description: <br>
Beaconcha.in lets an agent query Beaconcha.in data through the OOMOL beaconchain connector using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and operators use this skill to retrieve Ethereum beacon chain network performance, staking queue status, validator snapshots, and finalized-epoch consensus reward breakdowns. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Beaconcha.in account and API key, with OOMOL acting as an intermediary for queries. <br>
Mitigation: Install only if that account connection model is acceptable for the intended environment, and review the Beaconcha.in connection before use. <br>
Risk: First-time setup may require installing the external oo CLI before the skill can run connector actions. <br>
Mitigation: Review the oo CLI installation path and install guide before running setup commands. <br>
Risk: Beaconcha.in schemas and live validator or network data can change upstream. <br>
Mitigation: Fetch the live action schema before constructing payloads and treat returned values as current snapshots. <br>


## Reference(s): <br>
- [Beaconcha.in homepage](https://beaconcha.in) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses contain a data object and meta.executionId; action schemas should be fetched live before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact frontmatter, release evidence, target metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
