## Description: <br>
Deploys web-novel writing project infrastructure into a user project, including hooks, rules, agents, project guidance, and writing reference materials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Writers and developers setting up Chinese web-fiction projects use this skill to install and validate Claude Code or OpenClaw project infrastructure for long-form or short-form story workflows while preserving user-owned configuration where possible. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Persistent project files, executable hooks, merged settings, and tracking-directory files can change behavior in a writing workspace. <br>
Mitigation: Review the file-by-file deployment plan before installation and use the skill only in writing projects where persistent state and automation changes are acceptable. <br>
Risk: Prescriptive writing guidance may not match the author's style, genre, or project goals. <br>
Mitigation: Adjust or remove rules, agent references, and guidance that conflict with the project's creative direction. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/worldwonderer/story-setup) <br>
- [OpenClaw source metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [Skill definition](SKILL.md) <br>
- [Upgrade guide](UPGRADING.md) <br>
- [Hook templates](references/templates/hooks/) <br>
- [Agent reference bundle](references/agent-references/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with file deployment plans, shell commands, and configuration changes.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May create or merge project files such as CLAUDE.md, .claude hooks, .claude rules, .claude agents, settings.local.json, and .story-deployed.] <br>

## Skill Version(s): <br>
1.1.4 (source: server release metadata; artifact frontmatter reports 1.1.1) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
