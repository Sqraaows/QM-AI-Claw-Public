---
name: Svelte 前端框架工具包
slug: svelte-wrap
description: Svelte 前端框架工具包 — 简化 Svelte 和 SvelteKit 项目开发和部署的工具集合，提供项目模板、组件库、构建优化脚本等。帮助开发者快速搭建生产级别的 Svelte 应用，包含路由配置、状态管理、API 调用等常用功能的最佳实践封装。 | 来源：https://github.com/q15004040209-creator/svelte-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/svelte-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
