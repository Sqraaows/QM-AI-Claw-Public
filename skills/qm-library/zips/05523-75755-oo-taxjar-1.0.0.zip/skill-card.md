## Description: <br>
TaxJar helps an agent read, calculate, create, update, and delete TaxJar data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate connected TaxJar accounts for sales tax calculations, tax-rate lookup, VAT validation, customer exemption management, and order or refund transaction management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, or delete customers, order transactions, and refund transactions in a connected TaxJar account. <br>
Mitigation: Require a clear user review of the exact payload and intended effect before running write or delete actions. <br>
Risk: The skill requires access to a connected TaxJar account and sensitive credentials managed through OOMOL. <br>
Mitigation: Install and use it only when the agent is intended to operate on that TaxJar account. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-taxjar) <br>
- [TaxJar Homepage](https://www.taxjar.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects with data and execution metadata when actions are run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
