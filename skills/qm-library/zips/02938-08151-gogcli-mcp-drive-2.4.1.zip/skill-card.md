## Description: <br>
Gogcli MCP Drive helps agents browse, upload, download, share, and manage Google Drive files and folders through gogcli-backed MCP tools. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to configure and operate Google Drive MCP access for browsing, transferring, sharing, commenting on, and managing Drive files and folders. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can give an agent access to Google Drive files and sharing state for the configured account. <br>
Mitigation: Install it only for Google accounts whose Drive contents may be accessed by the agent, and use the least-privilege gogcli scopes available. <br>
Risk: Drive operations can change files, folders, comments, sharing, permissions, or locations. <br>
Mitigation: Manually confirm sharing, deletion, moving, replacement, upload, comment, and permission-change requests before allowing them to run. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp-drive) <br>
- [gogcli project](https://github.com/openclaw/gogcli) <br>
- [gogcli MCP project](https://github.com/chrischall/gogcli-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [configuration, shell commands, guidance] <br>
**Output Format:** [Markdown with JSON configuration and command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May invoke gogcli-backed MCP tools that access Google Drive files, folders, comments, sharing, and permissions.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
