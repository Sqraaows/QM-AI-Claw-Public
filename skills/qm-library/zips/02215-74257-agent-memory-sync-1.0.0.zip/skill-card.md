## Description: <br>
Memory Sync synchronizes OpenClaw memory and multi-agent conversation archives into Obsidian/Git as a searchable, portable, user-owned memory layer. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[wildprogrammer](https://clawhub.ai/user/wildprogrammer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to preserve, review, search, and export useful memory across OpenClaw, Codex, Claude, Hermes, OpenCode, and Qoder. It is especially suited for local-first Obsidian/Git memory workflows where the user wants readable archives and portable context for future agent sessions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can copy local agent conversations, profile/rule files, skill inventories, and generated memory summaries into an Obsidian vault. <br>
Mitigation: Install and run it only when that local data movement is intended, and review generated files before treating them as shared memory. <br>
Risk: Optional Git sync can commit or push generated memory data that may contain private information. <br>
Mitigation: Use a private repository, review generated files before syncing, and consider keeping GIT_PUSH_ENABLED=false unless push behavior is explicitly desired. <br>
Risk: Broad conversation scans and project ingestion may process untrusted or sensitive local content. <br>
Mitigation: Avoid conversations scan --all and ingest --project on untrusted repositories unless the data and execution exposure are understood. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/wildprogrammer/agent-memory-sync) <br>
- [Wildprogrammer publisher profile](https://clawhub.ai/user/wildprogrammer) <br>
- [Memory Sync homepage](https://github.com/Wildprogrammer/memory-sync-skill) <br>
- [README](artifact/README.md) <br>
- [Skill instructions](artifact/SKILL.md) <br>
- [Security policy](artifact/SECURITY.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command examples plus generated Markdown and JSON memory artifacts.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Generated files may include Obsidian Markdown pages, source archives, memory indexes, portable context exports, and optional Git commits when configured.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
