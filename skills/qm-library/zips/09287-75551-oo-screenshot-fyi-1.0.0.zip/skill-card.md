## Description: <br>
screenshot.fyi helps agents inspect the live connector schema, run the OOMOL connector, and capture website screenshots that return generated screenshot URLs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, QA teams, and content operators use this skill to create website screenshots through a connected screenshot.fyi account. It is intended for authenticated connector use where the user confirms the target page and understands possible quota, billing, or privacy effects. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create screenshot jobs for user-provided pages, which may capture sensitive content or consume service quota. <br>
Mitigation: Confirm the target URL or page before running, avoid private or sensitive pages unless intended, and monitor quota or billing effects. <br>
Risk: The skill requires an authenticated OOMOL connection for screenshot.fyi. <br>
Mitigation: Use the connected service flow rather than handling raw tokens, and resolve authentication or connection errors through the documented setup steps only when needed. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-screenshot-fyi) <br>
- [screenshot.fyi homepage](https://www.screenshot.fyi) <br>
- [take_screenshot action reference](actions/take_screenshot.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Successful connector runs return data from screenshot.fyi and meta.executionId for the execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
