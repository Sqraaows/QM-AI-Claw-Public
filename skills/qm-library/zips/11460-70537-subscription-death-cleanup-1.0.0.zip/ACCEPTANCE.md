# Acceptance Criteria — subscription-death-cleanup

## Criterion 1: Complete Submission
- [ ] SKILL.md exists in `/Users/jianghaidong/.openclaw/skills/subscription-death-cleanup/`
- [ ] skill.json exists and is valid JSON
- [ ] ACCEPTANCE.md exists

## Criterion 2: Content Requirements
- [ ] SKILL.md is prompt-only (no external credentials, API calls, or network dependencies)
- [ ] All content is English, zero CJK characters
- [ ] Safety boundaries are clearly defined in SKILL.md
- [ ] skill.json contains all required fields (schema, name, version, displayName, description, categories, license, locale, promptOnly, usage)

## Criterion 3: Functional Correctness
- [ ] When a user provides a subscription list, the skill produces a classified audit table
- [ ] The skill outputs cancellation scripts for zombie/ghost/duplicate subscriptions
- [ ] The skill calculates a savings summary
- [ ] The skill includes a follow-up reminder (60-day bank statement check)

## Criterion 4: Safety
- [ ] Never requests or stores financial credentials (credit cards, bank logins, passwords, 2FA codes)
- [ ] Never executes cancellations or sends emails
- [ ] Contains a clear disclaimer that it provides scripts and guidance only

## Criterion 5: Edge Cases
- [ ] Handles lists with fewer than 3 items by prompting user to check hidden sources (credit card, PayPal, app store)
- [ ] When pricing is unknown, prompts user to provide costs before estimating savings
- [ ] Does not fabricate pricing information

## Verification
- [ ] Run `cat skill.json | python3 -m json.tool` confirms valid JSON
- [ ] No API keys, tokens, or URLs present in any file
- [ ] All 3 files are readable and non-empty
