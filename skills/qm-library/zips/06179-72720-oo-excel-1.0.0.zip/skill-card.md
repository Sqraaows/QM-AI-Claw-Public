## Description: <br>
Excel helps agents operate Microsoft Excel through an OOMOL-connected account for workbook discovery, inspection, creation, updates, sorting, filtering, and deletion workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, analysts, and developers use this skill to read, create, organize, and modify Excel workbooks through an OOMOL-managed Excel connector. It is suited for spreadsheet automation tasks that need workbook, worksheet, table, row, column, and range operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read workbook data from an OOMOL-connected Excel account. <br>
Mitigation: Install only when access to the connected account's workbook data is acceptable, and use read actions for inspection before making changes. <br>
Risk: Create, update, sort, filter, merge, clear, and conversion actions can change workbook state. <br>
Mitigation: Fetch the live action schema, confirm the target workbook or range, and review the exact JSON payload before running write actions. <br>
Risk: Delete actions can remove worksheets, table rows, or table columns. <br>
Mitigation: Require explicit user approval for the exact destructive target before running delete actions. <br>
Risk: The security evidence notes that the create_session permission documentation needs clarification. <br>
Mitigation: Treat the permission note as documentation to review, and confirm account scopes if session creation behaves unexpectedly. <br>


## Reference(s): <br>
- [ClawHub Excel skill page](https://clawhub.ai/oomol/oo-excel) <br>
- [Microsoft Excel homepage](https://www.microsoft.com/microsoft-365/excel) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses from the oo CLI, including connector data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
