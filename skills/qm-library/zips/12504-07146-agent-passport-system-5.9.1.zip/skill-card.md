## Description: <br>
Agent Passport provides agent identity, scoped delegation, enforcement, audit receipts, and trust governance for AI agent workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[aeoess](https://clawhub.ai/user/aeoess) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill to create agent passports, delegate authority with limits, enforce policy boundaries, record signed work receipts, and audit multi-agent activity. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated passport key material can authorize agent actions if exposed. <br>
Mitigation: Protect the generated .passport key file like an SSH key and restrict filesystem access to trusted users and runtimes. <br>
Risk: The full MCP profile exposes a broad tool surface. <br>
Mitigation: Use the essential MCP profile unless a workflow explicitly requires the full profile. <br>
Risk: Optional OAuth tokens, GITHUB_TOKEN, and commerce or payment permissions can expand the impact of misuse. <br>
Mitigation: Provide credentials only for intended workflows, scope them narrowly, and avoid granting payment permissions unless required. <br>
Risk: Remote MCP and API use sends workflow activity to external services. <br>
Mitigation: Use remote endpoints only in environments where those network connections and data flows are approved. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/aeoess/agent-passport-system) <br>
- [Publisher profile](https://clawhub.ai/user/aeoess) <br>
- [npm package](https://www.npmjs.com/package/agent-passport-system) <br>
- [MCP npm package](https://www.npmjs.com/package/agent-passport-system-mcp) <br>
- [PyPI package](https://pypi.org/project/agent-passport-system/) <br>
- [Documentation](https://aeoess.com/llms-full.txt) <br>
- [Paper](https://doi.org/10.5281/zenodo.18749779) <br>
- [Remote MCP endpoint](https://mcp.aeoess.com/sse) <br>
- [Intent Network API](https://api.aeoess.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline code, shell commands, JSON-like records, and configuration guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce key material, signed passports, signed delegations, receipts, Merkle proofs, MCP tool calls, and audit summaries.] <br>

## Skill Version(s): <br>
5.9.1 (source: ClawHub release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
