---
name: equal-data-skill
description: equal-data-skill 金融数据服务- 提供覆盖A股5000+家上市公司的行情、财报、基本面、重大事件追踪(高管增减持, 重大合同, 股东变动,大宗交易, 限售解禁,定向增发,分红送转, 业绩预告)等多维度数据、股东分析、基金持仓与变动统计、知名机构动向追踪(包含 国家队,外资,私募基金,公募基金,信托,保险,证券等)、知名牛散持仓数据、资讯、公告、等多形态结构化专业金融数据
author: equaldata
pypi_package: equal-data
install_required: true
install_command: pip install 'equal-data==0.0.12'
required_env_vars:
  - EQUAL_DATA_API_KEY
---

# equal-data-skill

## 概述

### Equal Data skills的核心能力：

### 股票全景信息

为OpenClaw、Workbuddy、QClaw等主流龙虾提供及时全面的行情数据、财务数据、主营业务、高管背景、股东信息、事件驱动以及每日的市场热度相关的全维度数据

### 聪明资金流向（特色数据）

为OpenClaw、Workbuddy、QClaw等主流龙虾提供实时监控 公募、私募、国家队、外资、保险、信托、牛散、游资等主流聪明资金的持仓动向, 成本分析解读等特色数据

### 智能量化选股

为OpenClaw、Workbuddy、QClaw等主流龙虾提供通过行情数据、财务指标、估值指标、盈利能力、事件驱动等多维度的基本面选股能力

### 资讯公告检索

为OpenClaw、Workbuddy、QClaw等主流龙虾提供及时、全面、权威的金融资讯检索能力， 并提供上千家深度专栏文章、机构研报、AI公告数据的搜索

## 快速上手

- 安装python运行环境(推荐python3.6+)，并安装equal-data依赖包。

```bash
python -m venv test_env
source test_env/bin/activate
pip install equal-data==0.0.12
```

**重要提示**：为确保功能正常运行，需要确保 equal_data 版本大于等于 0.0.12

版本检查：

```python
from equal_data import __version__
print(f"当前 equal_data 版本: {__version__}")
```

版本升级：

如果版本过低，请升级到最新版本：

```bash
pip install equal-data==0.0.12
```

- 根据接口文档，使用python代码获取数据。（如**高管增减持金额排行榜**接口）

```python
from equal_data import EqualDataApi 
import os

# 读取环境变量中的API_KEY, 或者读取本地记录的API_KEY
API_KEY = os.getenv('EQUAL_DATA_API_KEY')

api = EqualDataApi(API_KEY)

# 高管持股变动-增减持金额排行榜列表
data = api.query_equal_data(
    interfaceId="B6",
    period=None,  # int  # 默认: 1
    changeType=None,  # int  # 默认:
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
    selfSelected=None,  # bool  # 默认: false
    sortDesc=None,  # str  # 默认: 1-DESC
)
```

## 参数格式说明

| 名称           | 类型      | 必填 | 默认值   | 说明                                                         |
| :------------- | :-------- | :--- | :------- | :----------------------------------------------------------- |
| `interfaceId`  | `str`  | 是   | `B6`     | 接口ID                                                       |
| `period`       | `int` | 否   | `1`      | 1-近1月、2-近3月、3-近半年、4-近1年                          |
| `changeType`   | `int` | 否   | -        | 变动类型（增持：1，减持：-1）                                |
| `pageIndex`    | `int` | 是   | `0`      | 当前页从0开始                                                |
| `pageSize`     | `int` | 是   | `10`     | 每页显示记录数                                               |
| `selfSelected` | `bool` | 否   | `false`  | true: 只看自选 false：全部（默认）                           |
| `sortDesc`     | `str`  | 否   | `1-DESC` | 排序描述 1-ASC/1-DESC 等，1表示增持金额 2增持数量 3占总股本比 4占流通股本比 <br>5净增持股数 6增持均价 |

- 返回格式：json

## 认证方式

本 Skill 需要equaldata  API_KEY (`EQUAL_DATA_API_KEY`)，支持以下两种方式配置：

equaldata官网(https://equal-data.com/)注册，获取API_KEY，

**方式 A：配置环境变量**

```bash
# macOS 添加到 ~/.zshrc，Linux 添加到 ~/.bashrc
export EQUAL_DATA_API_KEY="your_key_here"
# Windows PowerShell
$env:EQUAL_DATA_API_KEY="your_key_here"
# Windows CMD
set EQUAL_DATA_API_KEY=your_key_here
```
然后根据系统执行对应的命令：
**macOS：**

```bash
source ~/.zshrc
```

**Linux：**

```bash
source ~/.bashrc
```

**方式 B：OpenClaw配置文件:**
在 `~/.openclaw/openclaw.json` 中配置：

```json
{
  "skills": {
    "entries": {
      "equal-data-skill": {
        "enabled": true,
        "env": {
          "EQUAL_DATA_API_KEY": "your_actual_API_KEY_here"
        }
      }
    }
  }
}
```

## 触发指令

【A股】【股票】【行情】【K线】【股价】【涨跌幅】【成交量】【市值】
【基金】【净值】【收益率】【持仓】【基金经理】
【财报】【财务指标】【营收】【净利润】【毛利率】【资产负债】
【高管增减持】【董监高】【股东】【持股变动】【增持】【减持】
【机构动向】【机构持仓】【北向资金】【外资】【社保基金】
【龙虎榜】【游资】【营业部】【上榜】【打板】【连板】【市场高度】
【限售解禁】【解禁股】【减持计划】
【大宗交易】【折价】【溢价】
【重大合同】【涨跌概率】
【分红送转】
【机构调研】
【业绩预告】【预增】【预减】【暴雷】
【十大股东】【流通股东】【股东人数】【管理层】【高管】
【快讯】【新闻】【公告】【研报】【资讯】
【热门榜单】

## 数据接口列表

<!-- generated_at: 2026-05-09T13:57:21.543-1778306241543 -->


| Interface ID | Name | Description | Category | Doc path |
|:---:|:---|:---|:---|:---|
| K1 | 全部策略列表 | 获取全部策略列表，返回策略名称、最新净值、收益率、交易日期等信息等。适用于策略浏览和筛选。 | 特色策略 | [All_Strategies_List.md](<reference-en/Featured_Strategies/All_Strategies_List.md>) |
| K2 | 具体的策略详情 | 查询策略完整详情信息，返回策略基础信息、多周期收益、净值表现、持仓交易、创建时间、<br>调仓规则及投资规则等核心数据。适用于策略详情查询 、 策略数据统计（如果不知道策略Id或者策略名称，<br>可以调用K1接口）。 | 特色策略 | [Strategy_Detail.md](<reference-en/Featured_Strategies/Strategy_Detail.md>) |
| K3 | 策略持仓信息 | 查询指定日期具体策略的持仓详情，包含返回持仓股票、持仓比例、买入价格等。适用于跟踪策略的调仓操作 | 特色策略 | [Strategy_Holdings.md](<reference-en/Featured_Strategies/Strategy_Holdings.md>) |
| K4 | 具体策略的走势详细数据 | 获取具体策略的走势详细数据:查询具体策略的净值走势详细数据，返回每日收益率、静态收益率，<br>用于绘制策略收益曲线。适用于评估策略的历史表现 | 特色策略 | [Strategy_Trend_Data.md](<reference-en/Featured_Strategies/Strategy_Trend_Data.md>) |
| S1 | 估值模型选股 | 基于多维度估值指标筛选股票，支持市盈率(PE)、市净率(PB)、市销率(PS)、<br>股息率（DividedYield）、市现率（PCF）等核心估值指标的单条件或多条件组合筛选 | 指标选股 | [Valuation_Model_Screening.md](<reference-en/Indicator_Screening/Valuation_Model_Screening.md>) |
| S3 | 事件驱动选股 | 维护所有个股，基本面事件的最后发生时间，可以用来检测近期是否有基本面事件发生，<br>包括事件类型：“事件类型: 业绩预增 / 暴雷,  限售解禁,  重大合同,  大宗交易,  <br>机构调研,  高管增持 / 减持, 分红送转” | 指标选股 | [Event_Driven_Screening.md](<reference-en/Indicator_Screening/Event_Driven_Screening.md>) |
| S4 | 股东户数变动选股 | 根据股东户数及其变动趋势筛选股票，反映筹码集中度变化。 | 指标选股 | [Shareholder_Count_Screening.md](<reference-en/Indicator_Screening/Shareholder_Count_Screening.md>) |
| S6 | 机构持仓选股 | 机构持仓选股 | 指标选股 | [Institution_Holding_Screening.md](<reference-en/Indicator_Screening/Institution_Holding_Screening.md>) |
| S11 | 财务指标综合选股 | 按照最新财务指标或者历史每一期的财务指标进行单指标或多指标选股 | 指标选股 | [Financial_Indicator_Screening.md](<reference-en/Indicator_Screening/Financial_Indicator_Screening.md>) |
| S12 | 实时基本面综合选股 | 根据财务指标和估值指标如pb、pe、ps、<br>dividendYield以及总市值总股本等条件进行单指标或多指标综合进行选股。<br>注：维护股票最新一期数据，不同股票最新的数据日期可能不一样，<br>例如贵州茅台更新到2025年12月31日而平安银行已经更新到了2026年3月31日。 | 指标选股 | [Realtime_Fundamental_Screening.md](<reference-en/Indicator_Screening/Realtime_Fundamental_Screening.md>) |
| S13 | 股价表现选股 | 股价表现选股，支持按照实时股价选股以及历史股价表现选股，如股票涨跌幅、换手率、成交量等指标进行选股 | 指标选股 | [Price_Performance_Screening.md](<reference-en/Indicator_Screening/Price_Performance_Screening.md>) |
| B6 | 高管增减持金额排行榜 | 查询一段时间内A股上市公司高管增持/减持金额排名榜单，返回股票名称、变动金额、变动股数等。<br>适用于发现高管大规模增减持行为 | 事件驱动 | [Executive_Holding_Amount_Rank.md](<reference-en/Event_Driven/Executive_Holding_Amount_Rank.md>) |
| B7 | 查询所有高管增减持变动数据 | 查询A股所有上市公司的高管增减持变动数据列表，支持按变动类型（增持/减持）和日期范围筛选，<br>返回变动公司、高管姓名、变动数量、变动金额等。适用于全面监控高管增减持动向 | 事件驱动 | [All_Executive_Holding_Changes.md](<reference-en/Event_Driven/All_Executive_Holding_Changes.md>) |
| B8 | 高管增减持计划数据 | 查询近期发布高管增减持计划的上市公司列表及计划详情，返回公司名称、计划增减持数量、价格区间、<br>计划进度等。适用于预判高管的增减持意向 | 事件驱动 | [Executive_Holding_Plans.md](<reference-en/Event_Driven/Executive_Holding_Plans.md>) |
| B9 | 高管单次增减持变动数据 | 查询某高管对某只股票的具体增减持操作明细，返回变动日期、变动股数、变动后持股、成交均价等。<br>适用于追踪特定高管的单笔交易行为 | 事件驱动 | [Executive_Single_Holding_Change.md](<reference-en/Event_Driven/Executive_Single_Holding_Change.md>) |
| B10 | 高管增减持计划详情 | 查询某个具体高管增减持计划的详细数据，返回计划增减持数量、完成进度等。<br>适用于跟踪高管增减持计划的执行情况 | 事件驱动 | [Executive_Plan_Detail.md](<reference-en/Event_Driven/Executive_Plan_Detail.md>) |
| B11 | 高管持股数据分析 |  基于个股高管持股变动数据，统计历史同类事件后的股价表现，计算上涨概率与平均涨幅，<br>辅助判断高管持股对股票涨跌的影响 | 事件驱动 | [Executive_Holding_Data_Analysis.md](<reference-en/Event_Driven/Executive_Holding_Data_Analysis.md>) |
| B12 | 热门榜单基础信息 | 按报告期统计所有机构类型（公募/私募/外资/国家队等）的持股变动排名，<br>返回各机构的买入/卖出操作数量。适用于发现当期最受关注的机构 | 事件驱动 | [Hot_Rank_Basic_Info.md](<reference-en/Event_Driven/Hot_Rank_Basic_Info.md>) |
| B13 | 热门榜单详情数据 | 查询某季度各机构类型的榜单详情，支持买入榜/卖出榜/跌破国家队持仓榜/高管增减持榜等多种榜单类型，<br>返回股票累计变动股数、持股占比、变动比例等。适用于深度分析机构和高管的季度操作 | 事件驱动 | [Hot_Rank_Detail.md](<reference-en/Event_Driven/Hot_Rank_Detail.md>) |
| B14 | 限售解禁数据 | 查询近期即将解禁和历史已解禁的股票列表，返回解禁日期、解禁数量、解禁比例等。<br>适用于预判解禁对股价的潜在压力 | 事件驱动 | [Restricted_Release_List.md](<reference-en/Event_Driven/Restricted_Release_List.md>) |
| B15 | 限售解禁详细数据 | 查询某上市公司的所有限售解禁相关数据，包含历史已解禁和未来待解禁的详细信息（解禁日期、数量、比例、<br>股东名称等）。适用于全面评估个股解禁压力 | 事件驱动 | [Restricted_Release_Detail.md](<reference-en/Event_Driven/Restricted_Release_Detail.md>) |
| B16 | 限售解禁数据分析接口 | 分析上市公司历史限售解禁后的股价表现，返回解禁后最佳上涨概率、平均涨幅等高阶数据。<br>适用于评估解禁事件对股价的历史影响规律 | 事件驱动 | [Restricted_Release_Analysis.md](<reference-en/Event_Driven/Restricted_Release_Analysis.md>) |
| B17 | 大宗交易营业部数据 | 从营业部维度查询大宗交易数据，支持按折价/溢价筛选，返回营业部名称、买入/卖出金额、交易股票等。<br>适用于分析哪些营业部在大宗交易中活跃 | 事件驱动 | [Block_Trade_Broker_Data.md](<reference-en/Event_Driven/Block_Trade_Broker_Data.md>) |
| B18 | 大宗交易股票数据 | 查询发生大宗交易的股票数据，支持按折价/溢价筛选，返回成交均价、折溢率、成交总量、成交总额、<br>上涨概率等。适用于发现大资金的建仓或出货行为 | 事件驱动 | [Block_Trade_Stock_Data.md](<reference-en/Event_Driven/Block_Trade_Stock_Data.md>) |
| B19 | 业绩预告/预披露 | 提供上市公司业绩披露的相关数据, 主要包括 预增、预减、暴雷、预亏, 续盈等 | 事件驱动 | [Performance_Forecast.md](<reference-en/Event_Driven/Performance_Forecast.md>) |
| B20 | 重大合同数据 | 查询近期签署重大合同的上市公司列表及合同详情，返回上市公司股票代码、合同金额、签署主体等。<br>适用于跟踪上市公司重大业务进展 | 事件驱动 | [Major_Contract_List.md](<reference-en/Event_Driven/Major_Contract_List.md>) |
| B21 | 分红送转预案/实施 | 提供上市公司分红预案和分红实施相关的数据 | 事件驱动 | [Dividend_Bonus_List.md](<reference-en/Event_Driven/Dividend_Bonus_List.md>) |
| B22 | 机构调研数据 | 查询上市公司接待机构调研的数据，支持按股票代码或名称查询，返回调研日期、调研机构名称、星标数量等。<br>适用于发现机构重点关注方向 | 事件驱动 | [Institution_Research_List.md](<reference-en/Event_Driven/Institution_Research_List.md>) |
| B23 | 热门榜单持仓榜数据 | 查询各机构类型的最新持仓榜数据，返回持仓股票、持仓市值、持股数量等。适用于了解各类型机构的重仓股分布 | 事件驱动 | [Hot_Rank_Holding_List.md](<reference-en/Event_Driven/Hot_Rank_Holding_List.md>) |
| B24 | 跌破国家队持仓成本排行数据 | 查询当前股价跌破国家队持仓成本的股票排行榜，返回持仓成本、当前股价、跌破幅度等。<br>适用于寻找被国家队重仓但短期被套的潜在价值股票 | 事件驱动 | [Below_National_Team_Cost_Rank.md](<reference-en/Event_Driven/Below_National_Team_Cost_Rank.md>) |
| H1 | 公募基金列表 | 公募基金列表:查询公募基金基本信息列表，支持按基金代码、名称、成立日期、投资类型等条件筛选，<br>分页返回基金规模、净值、收益率等详情。适用于基金筛选和对比分析 | 公募基金 | [Public_Fund_List.md](<reference-en/Public_Offering_Fund/Public_Fund_List.md>) |
| H2 | 公募公司列表 | 公募公司列表:查询公募基金管理公司列表，返回公司名称、管理规模、旗下基金数量等基本信息。<br>适用于了解基金公司整体情况 | 公募基金 | [Fund_Company_List.md](<reference-en/Public_Offering_Fund/Fund_Company_List.md>) |
| H3 | 公募基金经理列表 | 公募基金列表:查询公募基金经理列表，支持按经理名称筛选，返回经理任职年限、个人简历等。<br>适用于评估基金旗下经理能力 | 公募基金 | [Fund_Manager_List.md](<reference-en/Public_Offering_Fund/Fund_Manager_List.md>) |
| H4 | 基金规模数据 | 基金规模数据:查询基金规模数据，主要覆盖上海和深圳ETF基金，返回基金规模、份额等信息 | 公募基金 | [Fund_Scale_Data.md](<reference-en/Public_Offering_Fund/Fund_Scale_Data.md>) |
| H5 | 公募基金净值:获取公募基金净值数据 | 公募基金净值:查询公募基金历史净值数据，返回每日净值、累计净值。适用于基金净值走势分析 | 公募基金 | [Public_Fund_NAV.md](<reference-en/Public_Offering_Fund/Public_Fund_NAV.md>) |
| H6 | 公募基金持仓数据 | 公募基金持仓数据:查询公募基金的持仓明细数据，返回基金持有的股票代码、持仓市值、持仓占比等，<br>季度更新。适用于跟踪基金投资动向 | 公募基金 | [Public_Fund_Holdings.md](<reference-en/Public_Offering_Fund/Public_Fund_Holdings.md>) |
| L1 | 百强牛散榜单 | 查询A股百强牛散排行榜，按持仓市值或收益率排序，返回牛散名称、持仓市值、收益率等。<br>适用于发现高净值个人投资者 | 牛散追击 | [Top_Retail_Whales_Rank.md](<reference-en/Retail_Whale_Tracking/Top_Retail_Whales_Rank.md>) |
| L2 | 牛散历史交易轨迹 | 查询牛散的历史交易记录和操作轨迹，返回买卖股票、交易日期、成交股数等。<br>适用于研究牛散的选股偏好和操作风格 | 牛散追击 | [Whale_History_Track.md](<reference-en/Retail_Whale_Tracking/Whale_History_Track.md>) |
| L3 | 牛散详情 | 获取牛散的详细信息，包含当前持仓股票、持仓市值、历史操作统计（胜率、平均持股周期等）。<br>适用于评估牛散的投资能力 | 牛散追击 | [Whale_Detail.md](<reference-en/Retail_Whale_Tracking/Whale_Detail.md>) |
| L4 | 热门牛散最新操作数据 | 查询近期活跃牛散的最新持仓和操作数据，返回牛散名称、操作股票、持股变动、持仓市值等。<br>适用于跟踪热门牛散的最新动向 | 牛散追击 | [Hot_Whale_Latest_Ops.md](<reference-en/Retail_Whale_Tracking/Hot_Whale_Latest_Ops.md>) |
| L5 | 牛散个股操作周期轨迹 | 查询牛散对某只个股的完整操作周期轨迹，包含建仓、持有、加仓、减仓、清仓的时间节点和价格。<br>适用于复盘牛散在特定股票上的操作节奏 | 牛散追击 | [Whale_Stock_Cycle_Track.md](<reference-en/Retail_Whale_Tracking/Whale_Stock_Cycle_Track.md>) |
| D1 | 上市公司管理层信息 | 查询上市公司管理层信息，支持按股票代码、日期等条件筛选，返回管理层姓名、职务、任职日期、薪酬、<br>持股数量等。适用于了解公司治理结构 | 基础数据 | [Listed_Company_Management.md](<reference-en/Basic_Data/Listed_Company_Management.md>) |
| D2 | 十大股东/十大流通股东 | 查询A股范围内，股票十大股东/流通股东列表数据，可指定股票代码和报告期。 | 基础数据 | [Top_Ten_Shareholders.md](<reference-en/Basic_Data/Top_Ten_Shareholders.md>) |
| D3 | 股东人数列表 | 查询个股股东人数变更记录，支持按股票代码和报告期筛选，按日期倒序返回各期股东人数、人均持股数量等。<br>适用于通过股东人数变化判断筹码集中度 | 基础数据 | [Shareholder_Count_List.md](<reference-en/Basic_Data/Shareholder_Count_List.md>) |
| D4 | 个股股东股本及机构持仓 | 查询个股在某报告期的股东股本及机构持仓数据，返回总股本、流通股本、机构持仓比例等。<br>适用于了解个股的股权结构和机构持仓情况 | 基础数据 | [Share_Structure_Institution_Holding.md](<reference-en/Basic_Data/Share_Structure_Institution_Holding.md>) |
| D5 | 个股资料最新重要指标 | 查询A股范围内，个股的基本财务指标(如果是选股场景，不要调用该接口)。 | 基础数据 | [Latest_Key_Indicators.md](<reference-en/Basic_Data/Latest_Key_Indicators.md>) |
| F1 | 基本股票列表/公司信息 | 基本股票列表/公司信息：按股票代码/名称（可多选）、上市日期、退市日期、交易所、<br>证券类别等条件动态筛选，整体分页返回上市公司基础信息。 | 基础数据 | [Stock_List_and_Company_Info.md](<reference-en/Basic_Data/Stock_List_and_Company_Info.md>) |
| F2 | 交易日历列表 | 获取A股交易日历，包含历史和本年度未来的交易日日期列表，返回交易日日期。<br>适用于判断某日是否为交易日及计算交易日间隔 | 基础数据 | [Trade_Calendar_List.md](<reference-en/Basic_Data/Trade_Calendar_List.md>) |
| F3 | 股票更名列表 | ●  查询个股的股票名称变更历史，支持指定多个股票代码，按日期倒序返回更名前名称、更名后名称、<br>更名日期等。适用于了解股票的历史名称变化 | 基础数据 | [Stock_Name_Change_History.md](<reference-en/Basic_Data/Stock_Name_Change_History.md>) |
| F4 | ST股票列表 | 查询A股所有ST股票列表，返回公司基本信息等。查询A股范围内，所有ST股票，包含公司基本信息，<br>可指定需要查询的公司的股票代码。分页每页最多20条。 | 基础数据 | [ST_Stock_List.md](<reference-en/Basic_Data/ST_Stock_List.md>) |
| F8 | 每日股本数据情况 | 查询股票的每日股本数据，返回总股本、流通股本等，支持查询多只股票。适用于获取个股在特定日期的股本结构 | 基础数据 | [Daily_Share_Structure.md](<reference-en/Basic_Data/Daily_Share_Structure.md>) |
| A1 | 主要财务数据 | 查询股票的主要财务指标，支持指定多只股票和报告期，返回营业收入、净利润、扣非净利润、每股收益、<br>净资产、现金流等35项核心财务数据。适用于基本面分析和财务对比 | 财务数据 | [Major_Financial_Indicators.md](<reference-en/Financial_Data/Major_Financial_Indicators.md>) |
| A2 | 查询股票主营业务 | 查询股票的主营业务历史数据，支持按报告期筛选（年报 / 中报），返回各主营业务的收入利润、毛利率等，<br>用于分析公司业务结构与盈利变化 | 财务数据 | [Main_Business_History.md](<reference-en/Financial_Data/Main_Business_History.md>) |
| F5 | 行业板块-成分股列表 | 查询指定行业板块下的成分股列表，按涨幅从高到低排序，返回股票代码、名称、涨跌幅等。<br>适用于分析行业内个股表现差异 | 行业与题材 | [Industry_Sector_Constituents.md](<reference-en/Industry_and_Themes/Industry_Sector_Constituents.md>) |
| F6 | 概念板块-成分股列表 | 查询指定概念板块下的成分股列表，按涨幅从高到低排序，返回股票代码、名称、涨跌幅等。<br>适用于分析概念炒作中的个股强弱 | 行业与题材 | [Concept_Sector_Constituents.md](<reference-en/Industry_and_Themes/Concept_Sector_Constituents.md>) |
| F7 | 行业板块列表  | 查询指定交易日的行业板块列表，默认查询最新交易日，返回板块名称、涨跌幅等。适用于了解当日行业表现 | 行业与题材 | [Industry_Sector_List.md](<reference-en/Industry_and_Themes/Industry_Sector_List.md>) |
| F9 | 概念板块列表 | 查询指定交易日的概念板块列表，默认查询最新交易日，返回行业代码、板块名称、涨跌幅等。<br>适用于了解当日市场热点概念 | 行业与题材 | [Concept_Sector_List.md](<reference-en/Industry_and_Themes/Concept_Sector_List.md>) |
| I6 | 申万行业列表 | 行业指数信息列表:查询行业指数信息，返回数据包含行业层级、所属分类、指数发布状态等信息。<br>适用于支撑板块归类、行业筛选、行情板块展示等业务场景 | 行业与题材 | [Shenwan_Industry_List.md](<reference-en/Industry_and_Themes/Shenwan_Industry_List.md>) |
| I7 | 申万行业成分股列表 | 行业成分股列表:查询指定成分股票，返回股票所属一级、二级、三级行业。适用于分析行业维度数据 | 行业与题材 | [Shenwan_Industry_Constituents.md](<reference-en/Industry_and_Themes/Shenwan_Industry_Constituents.md>) |
| I8 | 申万行业日线行情 | 行业指数日线行情列表:查询申万行业指数的日线行情数据，返回每日开盘点位、收盘点位、最高点位、<br>最低点位、成交量等。适用于行业走势分析和轮动研究 | 行业与题材 | [Shenwan_Industry_Daily.md](<reference-en/Industry_and_Themes/Shenwan_Industry_Daily.md>) |
| J1 | 机构动向全量数据 | 查询公募、私募、外资、国家队、保险公司、信托公司、证券公司及知名投资机构的最新持股动向，<br>支持按机构类型和变动类型（新进/退出/增持/减持）筛选。适用于全面监控机构资金流向 | 机构动向 | [Institution_Full_Data.md](<reference-en/Institutional_Flow/Institution_Full_Data.md>) |
| J2 | 机构持仓列表 | 查询某机构的历史持仓数据，支持按日期查询最新或历史持仓，返回持仓股票、持股数量、持股比例、<br>增减持变动等。适用于分析机构持仓变化趋势 | 机构动向 | [Institution_Holding_List.md](<reference-en/Institutional_Flow/Institution_Holding_List.md>) |
| J3 | 机构最新持股列表 | 查询具体机构的最新一期持股列表，返回持仓股票代码、名称、持股数量、持股市值、持股比例等详细信息。<br>适用于跟踪单一机构的投资组合 | 机构动向 | [Institution_Latest_Holdings.md](<reference-en/Institutional_Flow/Institution_Latest_Holdings.md>) |
| I0 | 获取所有指数信息 | 获取所有指数信息:查询A股市场指数的指数代码，支持模糊匹配。适用需要指数代码的场景优先调用，<br>而非通过互联网查询，作为其他指数接口的输入参考 | 指数专题 | [All_Index_List.md](<reference-en/Index_Topic/All_Index_List.md>) |
| I1 | 指数基本信息列表-根据交易倒序排序 | 指数基本信息列表:询指数基本信息，返回指数代码、名称。适用于快速浏览市场主要指数代码与全称 | 指数专题 | [Index_Basic_Info_List.md](<reference-en/Index_Topic/Index_Basic_Info_List.md>) |
| I2 | 指数日线行情列表 | 指数日线行情列表:查询指定指数的日线行情数据，支持按指数代码、名称和日期范围筛选，返回每日开盘价、<br>收盘价、最高价、最低价、成交量。适用于指数短期走势分析 | 指数专题 | [Index_Daily_Quotes.md](<reference-en/Index_Topic/Index_Daily_Quotes.md>) |
| I3 | 指数周线行情列表 | 指数周线行情列表:询指定指数的周线行情数据，返回每周开盘价、收盘价、最高价、最低价、成交量等。<br>适用于指数中长期趋势分析 | 指数专题 | [Index_Weekly_Quotes.md](<reference-en/Index_Topic/Index_Weekly_Quotes.md>) |
| I4 | 指数月线行情 | 指数周线行情列表:查询指定指数的月线行情数据，返回每月开盘价、收盘价、最高价、最低价、成交量等。<br>适用于指数长期趋势和周期分析 | 指数专题 | [Index_Monthly_Quotes.md](<reference-en/Index_Topic/Index_Monthly_Quotes.md>) |
| I5 | 指数成分和权重列表 | 指数成分和权重列表:查询指定指数的成分股及其权重列表，返回成分股代码、名称、权重占比、<br>自由流通市值等。适用于了解指数构成和权重分布 | 指数专题 | [Index_Component_Weights.md](<reference-en/Index_Topic/Index_Component_Weights.md>) |
| E1 | 快讯信息 | 查询近一个月的财经快讯信息，返回快讯标题、发布时间、内容等。适用于获取最新的市场动态和财经要闻 | 资讯信息 | [Flash_News.md](<reference-en/News_and_Info/Flash_News.md>) |
| E2 | 文章信息 | 查询近一个月的财经新闻文章，支持按股票名称筛选，按日期倒序返回文章标题、导语、文章链接、发布时间等。<br>适用于跟踪特定股票的相关新闻 | 资讯信息 | [Article_List.md](<reference-en/News_and_Info/Article_List.md>) |
| E3 | 上市公司公告 | 查询上市公司近一年的公告数据，支持按股票代码查询，返回公告标题、公告日期、公告类型等。<br>适用于跟踪公司重大事项和信息披露 | 资讯信息 | [Company_Announcements.md](<reference-en/News_and_Info/Company_Announcements.md>) |
| G1 | 实时行情列表 | 查询个股实时行情数据，支持指定多个股票代码，返回最新价、涨跌幅、成交量、成交额、换手率、振幅等。<br>适用于实时监控个股行情。 | 行情数据 | [Real_Time_Quote_List.md](<reference-en/Market_Quotes/Real_Time_Quote_List.md>) |
| G2 | 历史日K行情数据 | 查询个股历史日K线行情数据，支持指定多只股票和日期范围（最长1年），返回每日开盘价、收盘价、最高价、<br>最低价、成交量、成交额、涨跌幅等。适用于技术分析和历史走势复盘 | 行情数据 | [Historical_Daily_K_Quotes.md](<reference-en/Market_Quotes/Historical_Daily_K_Quotes.md>) |
| C1 | 龙虎榜机构（营业部）-关联席位游资列表 | ● 查询机构营业部关联的游资席位列表，返回游资名称。适用于识别营业部背后的游资势力 | 龙虎榜 | [Broker_Hot_Money_Seats.md](<reference-en/Dragon_Tiger_Board/Broker_Hot_Money_Seats.md>) |
| C2 | 龙虎榜机构（营业部）-操作明细 | 查询指定营业部的历史每日操作明细，返回买入/卖出股票、成交金额等。适用于追踪特定营业部的操作规律 | 龙虎榜 | [Broker_Operation_Details.md](<reference-en/Dragon_Tiger_Board/Broker_Operation_Details.md>) |
| C3 | 龙虎榜-游资特色指标分析 | 分析游资历史操作数据，统计近1年/近1月的买入上涨概率、平均涨幅等指标。<br>适用于评估游资的操作胜率和风格 | 龙虎榜 | [Hot_Money_Special_Analysis.md](<reference-en/Dragon_Tiger_Board/Hot_Money_Special_Analysis.md>) |
| C4 | 游资基本信息 | ● 查询游资的详情信息，包括简介、关联营业部、最近一个交易日的持仓操作记录。适用于了解游资背景| 龙虎榜 | [Hot_Money_Basic_Info.md](<reference-en/Dragon_Tiger_Board/Hot_Money_Basic_Info.md>) |
| C5 | 游资每日操作明细 | 查询游资在指定交易日附近的近期操作明细，返回买入/卖出股票、成交金额等信息。适用于追踪游资短期动向 | 龙虎榜 | [Hot_Money_Daily_Operations.md](<reference-en/Dragon_Tiger_Board/Hot_Money_Daily_Operations.md>) |
| B1 | 龙虎榜-近1月胜率排行 | 查询近一月龙虎榜游资按胜率排序的排行榜，返回游资名称、操作次数、胜率、平均收益率、最大盈利等。<br>适用于筛选近期高胜率游资席位 | 龙虎榜 | [Dragon_Tiger_Win_Rate_Rank.md](<reference-en/Dragon_Tiger_Board/Dragon_Tiger_Win_Rate_Rank.md>) |
| B2 | 龙虎榜-个股榜 | 查询指定交易日上榜龙虎榜的所有股票排行榜，返回股票代码、名称、涨幅、净买入额、知名游资、<br>连续涨停天数等。适用于筛选强势个股和分析资金博弈 | 龙虎榜 | [Dragon_Tiger_Stock_Rank.md](<reference-en/Dragon_Tiger_Board/Dragon_Tiger_Stock_Rank.md>) |
| B3 | 龙虎榜-游资榜 | 查询指定交易日上榜龙虎榜的所有游资排行榜，返回游资名称、买入金额、卖出金额、<br>净买入额及当天操作的股票信息。适用于分析游资当日活跃度和偏好 | 龙虎榜 | [Dragon_Tiger_Hot_Money_Rank.md](<reference-en/Dragon_Tiger_Board/Dragon_Tiger_Hot_Money_Rank.md>) |
| B4 | 龙虎榜-营业部榜 | 查询指定交易日上榜龙虎榜的所有营业部排行榜，返回营业部名称、买入金额、卖出金额、<br>净买入额及当天操作的股票。适用于分析各营业部的资金动向 | 龙虎榜 | [Dragon_Tiger_Broker_Rank.md](<reference-en/Dragon_Tiger_Board/Dragon_Tiger_Broker_Rank.md>) |
| B5 | 龙虎榜-市场高度 | 查询指定交易日上榜龙虎榜且近一月内涨停次数最多的股票列表，返回涨停次数、连板天数等。<br>适用于追踪市场短线龙头和连板股 | 龙虎榜 | [Dragon_Tiger_Market_Height.md](<reference-en/Dragon_Tiger_Board/Dragon_Tiger_Market_Height.md>) |
| M1 | 最新协同数据 | 查询最新股东协同数据，支持按照协同主体查询（如输入不完整，会先调用M4搜索接口匹配最相似的主体） | 股东协同 | [Latest_Synergy_Data.md](<reference-en/Shareholder_Synergy/Latest_Synergy_Data.md>) |
| M2 | 公奔私协同 | 最新协同数据，支持按照协同主体查询（如果输入的协同主体，不完整，会先调用M1搜索接口，<br>根据匹配相似度最高的协同主体，完成检索查询） | 股东协同 | [Public_To_Private_Synergy.md](<reference-en/Shareholder_Synergy/Public_To_Private_Synergy.md>) |
| M3 | 一致预期（多股东协同） | 查询协同行为数据，可按协同方向、时间范围、协同频次筛选，支持自定义排序与分页，返回个股协同日期、<br>行情表现、协同次数、协作类型及亮点说明等信息。 | 股东协同 | [Consensus_Multi_Shareholder.md](<reference-en/Shareholder_Synergy/Consensus_Multi_Shareholder.md>) |
| M4 | 搜索协同主体 |  搜索协同主体（机构名称），支持精确搜索和模糊搜索，返回匹配的机构列表，<br>用作最新协同数据接口的前置查询。适用于不确定完整机构名称时的模糊检索 | 股东协同 | [Search_Synergy_Subject.md](<reference-en/Shareholder_Synergy/Search_Synergy_Subject.md>) |



### 场景调用接口 

详细的应用场景调用：

| 名称                       | 接口描述                                               | 文档路径                                                     |
| -------------------------- | ------------------------------------------------------ | ------------------------------------------------------------ |
| 个股详情分析     | 获取指定股票的详细分析信息，包括实时行情、历史K线、财务指标、股东信息、新闻公告等综合分析结果。   | [individual_stock_detail_analysis.md](<reference-en/Agent/individual_stock_detail_analysis.md>)  |
| 高管增减持详细分析 | 获取上市公司高管的增减持情况，包括近期增持金额、历史变动次数、未来计划数和持股分析等信息。       | [executive_share_change_analysis.md](<reference-en/Agent/executive_share_change_analysis.md>) |


## 分类统计

| 分类 | 接口数量 |
|:---|:---|
| 特色策略 | 4 |
| 指标选股 | 7 |
| 事件驱动 | 19 |
| 公募基金 | 6 |
| 牛散追击 | 5 |
| 基础数据 | 10 |
| 财务数据 | 2 |
| 行业与题材 | 7 |
| 机构动向 | 3 |
| 指数专题 | 6 |
| 资讯信息 | 3 |
| 行情数据 | 2 |
| 龙虎榜 | 10 |
| 股东协同 | 4 |
| **合计** | **88** |

## 数据来源与依赖
- **官方文档**: https://equaldata.kanjiujing.cn/equal/dist/introduction
- **PYPI包地址**: `https://pypi.org/project/equal-data/`
- **官网**: [https://equaldata.kanjiujing.cn](https://equaldata.kanjiujing.cn)
- **数据用途**: 仅用于获取行情数据，不涉及交易操作
- **开源依赖**:
  - requests (Apache 2.0)
  - pandas (BSD 3-Clause)
  - equal-data 

## 依赖验证
本 Skill 依赖的 `equal-data` 包可通过以下方式验证：
- PyPI 页面: https://pypi.org/project/equal-data/
- 源码仓库: https://github.com/kanjiujing/equal-share-skill/

## 权限说明
- **需要环境变量**: `EQUAL_DATA_API_KEY`


