# Article_List

> Category: 资讯信息 | Folder: `News_and_Info` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询近一个月的财经新闻文章，支持按股票名称筛选，按日期倒序返回文章标题、导语、文章链接、发布时间等。适用于跟踪特定股票的相关新闻

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "E2" | 接口ID |
| `page` | `int` | 否 | - | 页码 示例：0 |
| `pageSize` | `int` | 否 | - | 每页条数 示例：10 |
| `keyword` | `str` | 否 | - | 关键词 示例：泡泡玛特 |
| `startTime` | `str` | 否 | - | 开始时间 格式示例：2020-01-01，日期必须是近一月内 |
| `endTime` | `str` | 否 | - | 结束时间 格式示例：2020-01-30，日期必须是近一月内 |

### 返回参数

文章信息列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `publishTime` | `str(datetime)` | 否 | 发布时间 |
| `title` | `str` | 否 | 标题 |
| `url` | `str` | 否 | 文章链接 |
| `description` | `str` | 否 | 导语 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="E2",
    page=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
    keyword=None,  # str  # 默认: 
    startTime=None,  # str  # 默认: 
    endTime=None,  # str  # 默认: 
)
```


