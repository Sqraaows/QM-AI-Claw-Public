# Company_Announcements

> Category: 资讯信息 | Folder: `News_and_Info` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询上市公司近一年的公告数据，支持按股票代码查询，返回公告标题、公告日期、公告类型等。适用于跟踪公司重大事项和信息披露

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "E3" | 接口ID |
| `page` | `int` | 否 | - | 页码 示例：0 |
| `pageSize` | `int` | 否 | - | 每页条数 示例：10 |
| `stockCode` | `str` | 是 | - | 股票代码 示例：000001 |
| `startTime` | `str` | 否 | - | 开始日期 格式示例：2020-01-01，日期必须是近一年内 |
| `endTime` | `str` | 否 | - | 结束日期 格式示例：2020-12-31，日期必须是近一年内 |

### 返回参数

上市公司公告列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `publishTime` | `str(datetime)` | 否 | 发布时间 |
| `title` | `str` | 否 | 标题 |
| `url` | `str` | 否 | 链接 |
| `type` | `int` | 否 | 类型 |
| `announcementType` | `str` | 否 | 公告类型 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="E3",
    page=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
    stockCode=None,  # str  # 默认: 
    startTime=None,  # str  # 默认: 
    endTime=None,  # str  # 默认: 
)
```


