# Strategy_Detail

> Category: 特色策略 | Folder: `Featured_Strategies` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询策略完整详情信息，返回策略基础信息、多周期收益、净值表现、持仓交易、创建时间、调仓规则及投资规则等核心数据。适用于策略详情查询 、 策略数据统计（如果不知道策略Id或者策略名称，可以调用K1接口）。

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "K2" | 接口ID |
| `strategyId` | `str` | 否 | - | 策略ID和策略名称必须传一个 |
| `strategyName` | `str` | 否 | - | 策略名称和策略ID必须传一个 |

### 返回参数

具体的策略详情数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `strategyName` | `str` | 是 | 策略名称 |
| `strategyId` | `str` | 是 | 策略ID |
| `tradingDay` | `str` | 否 | 交易日 |
| `recent1Month` | `float` | 否 | 近1月收益 |
| `recent3Month` | `float` | 否 | 近3月收益 |
| `recent6Month` | `float` | 否 | 近6月收益 |
| `recent1Year` | `float` | 否 | 近1年收益 |
| `recent3Year` | `float` | 否 | 近3年收益 |
| `recent5Year` | `float` | 否 | 近5年收益 |
| `yearToDay` | `float` | 否 | 今年以来收益 |
| `totalRate` | `float` | 否 | 累计收益率 |
| `holdingCount` | `int` | 否 | 持仓个数 0-空仓 |
| `createDateNum` | `int` | 否 | 创建天数 |
| `createDate` | `str` | 否 | 策略创建日期 |
| `unitNetValue` | `float` | 否 | 净值 |
| `dailyReturns` | `float` | 否 | 日收益率（组合） |
| `buyNum` | `int` | 否 | 买入股票数量 |
| `sellNum` | `int` | 否 | 卖出股票数量 |
| `signalDate` | `str` | 否 | 调仓信号最新日期 |
| `bestRatio` | `float` | 否 | 最好看的收益指标 |
| `bestRatioType` | `int` | 否 | 最好看的收益指标类型 |
| `selectedShowStatus` | `int` | 否 | 近3年、近5年展示状态 |
| `rule` | `str` | 否 | 调仓规则 |
| `investRule` | `str` | 否 | 投资规则 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="K2",
    strategyId=None,  # str  # 默认: 
    strategyName=None,  # str  # 默认: 
)
```


