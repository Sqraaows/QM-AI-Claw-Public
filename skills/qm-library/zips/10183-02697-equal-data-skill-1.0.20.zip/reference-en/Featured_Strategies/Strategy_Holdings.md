# Strategy_Holdings

> Category: 特色策略 | Folder: `Featured_Strategies` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询指定日期具体策略的持仓详情，包含返回持仓股票、持仓比例、买入价格等。适用于跟踪策略的调仓操作

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "K3" | 接口ID |
| `strategyId` | `str` | 否 | - | 策略ID和策略名称必须传一个 |
| `strategyName` | `str` | 否 | - | 策略名称和策略ID必须传一个 |
| `tradeDate` | `str` | 否 | - | 交易日期，不传则查询当前最新持仓 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数 |

### 返回参数

策略持仓信息列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `holdingRatio` | `float` | 否 | 持仓比例 |
| `marketValue` | `float` | 否 | 持仓最新市值 |
| `holdingCost` | `float` | 否 | 持仓总成本 |
| `holdingCostNumber` | `float` | 否 | 持仓总成本（未转换） |
| `dailyPnl` | `float` | 否 | 当日盈亏 |
| `quantity` | `int` | 否 | 持仓数量 |
| `quantityNumber` | `int` | 否 | 持仓数量（未转换） |
| `holdingDays` | `int` | 否 | 持仓天数 |
| `holdingAvgPrice` | `float` | 否 | 持仓成本均价 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="K3",
    strategyId=None,  # str  # 默认: 
    strategyName=None,  # str  # 默认: 
    tradeDate=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


