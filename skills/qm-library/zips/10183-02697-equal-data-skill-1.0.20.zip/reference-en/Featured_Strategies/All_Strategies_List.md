# All_Strategies_List

> Category: 特色策略 | Folder: `Featured_Strategies` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

获取全部策略列表，返回策略名称、最新净值、收益率、交易日期等信息等。适用于策略浏览和筛选。

### 请求参数

*无参数*

### 返回参数

全部策略列表数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `strategyName` | `str` | 是 | 策略名称 |
| `strategyId` | `str` | 是 | 策略ID |
| `bestRatio` | `float` | 否 | 最好看的收益指标 |
| `netVal` | `float` | 否 | 最新净值 |
| `buyNum` | `int` | 否 | 购买数量 |
| `sellNum` | `int` | 否 | 卖出数量 |
| `tradingDate` | `str` | 否 | 交易日期 |
| `nextNearestDay` | `str` | 否 | 距离当前跟踪日期最近的一个交易日 |
| `dailyReturns` | `float` | 否 | 当日涨跌 |
| `timeFlag` | `int` | 否 | 时间标记0:今日 1:明日 2:最新 |
| `indexCode` | `str` | 否 | 指标编码 |
| `indexName` | `str` | 否 | 指标名称 |
| `tradeDetialUrl` | `str` | 否 | 交易明细跳转链接 |
| `strategyDetialUrl` | `str` | 否 | 策略详情跳转链接 |
| `trendChartUrl` | `str` | 否 | 走势图地址 |
| `trendDataList` | `list[str]` | 否 | 趋势数据列表 |
| `dealRecordList` | `list[StrategyHoldingDetialVo]` | 否 | 交易明细列表 |

**`dealRecordList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `orderBookId` | `str` | 否 | 订单ID |
| `tradingDay` | `str` | 否 | 交易日 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `side` | `str` | 否 | 交易方向 |
| `avgPrice` | `float` | 否 | 持仓最新市值 |
| `quantity` | `int` | 否 | 持仓数量 |
| `isBonus` | `int` | 否 | 是否分红 |
| `summaryReturns` | `float` | 否 | 累计盈亏 |
| `holdCost` | `float` | 否 | 单笔持仓成本 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="K1",
)
```


