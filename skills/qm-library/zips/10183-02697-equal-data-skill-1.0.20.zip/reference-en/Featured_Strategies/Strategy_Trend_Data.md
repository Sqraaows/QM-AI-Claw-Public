# Strategy_Trend_Data

> Category: 特色策略 | Folder: `Featured_Strategies` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

获取具体策略的走势详细数据:查询具体策略的净值走势详细数据，返回每日收益率、静态收益率，用于绘制策略收益曲线。适用于评估策略的历史表现

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "K4" | 接口ID |
| `strategyId` | `str` | 否 | - | 策略ID |
| `strategyName` | `str` | 否 | - | 策略名称 |
| `periodType` | `int` | 否 | - | 时间范围： 1 表示近1月 2 表示近3月 3 表示近6月 4 表示近1年 5 表示近3年 7 <br>表示成立以来， 默认值为 |

### 返回参数

具体策略的走势详细数据（序列数据）

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `tradingDay` | `str` | 否 | 交易日 |
| `ratio` | `float` | 否 | 收益率 |
| `staticRatio` | `float` | 否 | 静态收益率 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="K4",
    strategyId=None,  # str  # 默认: 
    strategyName=None,  # str  # 默认: 
    periodType=None,  # int  # 默认: 
)
```


