# Latest_Key_Indicators

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询A股范围内，个股的基本财务指标(如果是选股场景，不要调用该接口)。

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "D5" | 接口ID |
| `stockCode` | `str` | 是 | - | 股票代码 示例：000001 |

### 返回参数

ResultData.data 为 ListedCompanyFinanceVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `PE` | `float` | 否 | 市盈率（TTM） |
| `PB` | `float` | 否 | 市净率 |
| `eps` | `float` | 否 | 每股收益 |
| `bps` | `float` | 否 | 每股净资产 |
| `totalRevenue` | `float` | 否 | 总营收 |
| `revenueYoy` | `float` | 否 | 营收同比 |
| `netProfit` | `float` | 否 | 归母净利润 |
| `netProfitYoy` | `float` | 否 | 归母净利润同比 |
| `netProfitDeduct` | `float` | 否 | 扣非净利润 |
| `netProfitDeductYoy` | `float` | 否 | 扣非净利润同比 |
| `grossMargin` | `float` | 否 | 毛利率 |
| `netMargin` | `float` | 否 | 净利率 |
| `roe` | `float` | 否 | 净资产收益率 |
| `debtRatio` | `float` | 否 | 资产负债率 |
| `dividedYield` | `float` | 否 | 股息率 |
| `dividedPayOutRatio` | `float` | 否 | 股利支付率 |
| `reportDate` | `str` | 否 | 报告期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="D5",
    stockCode=None,  # str  # 默认: 
)
```


