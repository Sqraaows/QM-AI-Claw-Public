# Stock_Name_Change_History

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

●  查询个股的股票名称变更历史，支持指定多个股票代码，按日期倒序返回更名前名称、更名后名称、更名日期等。适用于了解股票的历史名称变化

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "F3" | 接口ID |
| `stockCodes` | `str` | 是 | - | 股票代码或公司全称、简称，可多个使用逗号隔开；示例：000001,600519 |
| `pageNum` | `int` | 否 | `0` | 分页偏移量，从 0 开始（第 1 页为 0，第 2 页为 pageSize） 示例：0（第一页） |
| `pageSize` | `int` | 否 | `10` | 每页条数 示例：10（每页10条） |

### 返回参数

ResultData.data 为 List，元素为股票更名

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `companyName` | `str` | 否 | 公司名称 |
| `formername` | `str` | 否 | 曾用名 |
| `foundDate` | `str(datetime)` | 否 | 成立日期 |
| `listingDate` | `str(datetime)` | 否 | 上市日期 |
| `changeReason` | `str` | 否 | 更名原因 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="F3",
    stockCodes=None,  # str  # 默认: 
    pageNum=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


