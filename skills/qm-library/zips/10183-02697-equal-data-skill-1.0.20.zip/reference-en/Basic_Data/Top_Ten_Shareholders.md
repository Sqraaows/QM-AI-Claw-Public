# Top_Ten_Shareholders

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询A股范围内，股票十大股东/流通股东列表数据，可指定股票代码和报告期。

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "D2" | 接口ID |
| `stockCode` | `str` | 是 | - | 股票代码 |
| `startDate` | `str` | 否 | - | 开始日期 如 2025-01-01 |
| `endDate` | `str` | 否 | - | 结束日期 如 2025-12-31 |
| `holderType` | `int` | 是 | - | 股东类型 0-十大股东 1-十大流通股东 |

### 返回参数

ResultData.data 为 List，元素为 TenShareholderVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `shareholderName` | `str` | 否 | 股东名称 |
| `shareholdNum` | `str` | 否 | 持股数 |
| `shareholdRatio` | `str` | 否 | 占总股本比 |
| `changeRatio` | `str` | 否 | 变动比例 |
| `shareholdNumOld` | `str` | 否 | 上期持股数 |
| `reportDate` | `str` | 否 | 报告期 |
| `announcementDate` | `str` | 否 | 公告日期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="D2",
    stockCode=None,  # str  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    holderType=None,  # int  # 默认: 
)
```


