# Share_Structure_Institution_Holding

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询个股在某报告期的股东股本及机构持仓数据，返回总股本、流通股本、机构持仓比例等。适用于了解个股的股权结构和机构持仓情况

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "D4" | 接口ID |
| `stockCode` | `str` | 是 | - | 股票代码 示例：000001 |
| `reportDate` | `str` | 否 | - | 报告期 如 2025-09-30 |

### 返回参数

ResultData.data 为 List，元素为 InstitutionHoldingSummaryVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `reportDate` | `str` | 否 | 报告期 |
| `totalRatioOfCirculate` | `float` | 否 | 占流通股比（绘制图表） |
| `price` | `float` | 否 | 股价（绘制图表） |
| `ratioOfCycleChg` | `float` | 否 | 持股环比变化 |
| `totalQuantity` | `int` | 否 | 累计持股数量 |
| `totalMarketValue` | `float` | 否 | 累计持股市值 |
| `totalInstitutionNum` | `int` | 否 | 累计机构数 |
| `totalListedShares` | `int` | 否 | 总流通股本 |
| `type` | `int` | 否 | 类型： 0-全部 1-其他 2-基金 3-国家队 |
| `detailVoList` | `list[InstitutionHoldingDetailVo]` | 否 | 机构持仓明细数据 |

**`detailVoList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `reportDate` | `str` | 否 | 报告期 |
| `ratioOfCirculate` | `float` | 否 | 占流通股比（绘制图表） |
| `totalQuantity` | `int` | 否 | 累计持股数量 |
| `holdName` | `str` | 否 | 股东名称 |
| `holdCode` | `str` | 否 | 基金代码 |
| `infoId` | `str` | 否 | infoId |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="D4",
    stockCode=None,  # str  # 默认: 
    reportDate=None,  # str  # 默认: 
)
```


