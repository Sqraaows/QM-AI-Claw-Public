# Daily_Share_Structure

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询股票的每日股本数据，返回总股本、流通股本等，支持查询多只股票。适用于获取个股在特定日期的股本结构

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "F8" | 接口ID |
| `stockCodes` | `str` | 是 | - | 股票代码查詢，支持单个，多个使用逗号隔开，示例：'000001,600519' |
| `tradeDate` | `str` | 否 | - | 交易日期,默认今天yyyy-mm-dd格式的日期，示例：2024-03-20 |
| `pageNum` | `int` | 否 | `0` | 分页偏移量，从 0 开始（第 1 页为 0，第 2 页为 pageSize） |
| `pageSize` | `int` | 否 | `10` | 每页条数 |

### 返回参数

ResultData.data 为 List，元素为每日股本数据情况

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `tradeDate` | `str` | 否 | 交易日日期 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `totalShares` | `str` | 否 | 总股本（万股） |
| `unlimitedShares` | `str` | 否 | 已流通股份（万股） |
| `todayUpLimitPrice` | `str` | 否 | 今日涨停价 |
| `todayDownLimitPrice` | `str` | 否 | 今日跌停价 |
| `yesterdayClosePrice` | `str` | 否 | 昨日收盘价 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="F8",
    stockCodes=None,  # str  # 默认: 
    tradeDate=None,  # str  # 默认: 
    pageNum=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


