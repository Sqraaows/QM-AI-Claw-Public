# Shareholder_Count_List

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询个股股东人数变更记录，支持按股票代码和报告期筛选，按日期倒序返回各期股东人数、人均持股数量等。适用于通过股东人数变化判断筹码集中度

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "D3" | 接口ID |
| `stockCode` | `str` | 是 | - | 股票代码 |
| `startDate` | `str` | 否 | - | 开始日期 如 2025-01-01 |
| `endDate` | `str` | 否 | - | 结束日期 如 2025-12-31 |

### 返回参数

ResultData.data 为 List，元素为 HolderNumListVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `dataDate` | `str` | 否 | 数据日期 |
| `holderTotalNum` | `str` | 否 | 股东总户数 |
| `totalNumRatio` | `str` | 否 | 股东总户数增减比例(%) |
| `avgFreeShares` | `str` | 否 | 户均持股数（自由流通股） |
| `avgFreesharesRatio` | `str` | 否 | 户均持股数增减比例(%) |
| `avgHoldAmt` | `str` | 否 | 户均持股市值 |
| `holdRatioTotal` | `str` | 否 | 持股比例合计(%) |
| `freeholdRatioTotal` | `str` | 否 | 自由流通股持股比例合计(%) |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="D3",
    stockCode=None,  # str  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
)
```


