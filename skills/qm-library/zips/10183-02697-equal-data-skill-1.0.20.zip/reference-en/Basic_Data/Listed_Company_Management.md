# Listed_Company_Management

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询上市公司管理层信息，支持按股票代码、日期等条件筛选，返回管理层姓名、职务、任职日期、薪酬、持股数量等。适用于了解公司治理结构

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "D1" | 接口ID |
| `stockCodes` | `str` | 是 | - | 股票代码列表,支持单个和多个,如果是多个，使用逗号隔开 |
| `managerName` | `str` | 否 | - | 高管姓名 |
| `position` | `str` | 否 | - | 职位（董事长、董秘、总经理） |

### 返回参数

ResultData.data 为 List，元素为 ListedCompanyManagerInfoVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `managerName` | `str` | 否 | 高管姓名 |
| `companyName` | `str` | 否 | 公司名称 |
| `position` | `str` | 否 | 职位（董事长、董秘、总经理） |
| `sex` | `str` | 否 | 性别 |
| `age` | `int` | 否 | 年龄 |
| `education` | `str` | 否 | 学历 |
| `introduction` | `str` | 否 | 简介 |
| `salary` | `str` | 否 | 薪资 |
| `workExperienceList` | `list[ManagerExperienceVo]` | 否 | 工作经历列表 |

**`workExperienceList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `startDate` | `str` | 否 | 任职开始时间 |
| `endDate` | `str` | 否 | 任职结束时间 |
| `companyName` | `str` | 否 | 公司名称 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `position` | `str` | 否 | 职位 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="D1",
    stockCodes=None,  # str  # 默认: 
    managerName=None,  # str  # 默认: 
    position=None,  # str  # 默认: 
)
```


