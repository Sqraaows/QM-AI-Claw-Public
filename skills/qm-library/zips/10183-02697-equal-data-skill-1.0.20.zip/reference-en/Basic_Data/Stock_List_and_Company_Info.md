# Stock_List_and_Company_Info

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

基本股票列表/公司信息：按股票代码/名称（可多选）、上市日期、退市日期、交易所、证券类别等条件动态筛选，整体分页返回上市公司基础信息。

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "F1" | 接口ID |
| `stockCodes` | `str` | 否 | - | 股票代码或公司全称、简称，可多个使用逗号隔开；示例：000001,600519 |
| `startListedDate` | `str` | 否 | - | 上市日期起 yyyy-MM-dd，示例：2020-01-01 |
| `endListedDate` | `str` | 否 | - | 上市日期止 yyyy-MM-dd，示例：2024-12-31 |
| `startDelistedDate` | `str` | 否 | - | 退市日期起 yyyy-MM-dd，示例：2023-01-01 |
| `endDelistedDate` | `str` | 否 | - | 退市日期止 yyyy-MM-dd，示例：2025-12-31 |
| `exchange` | `str` | 否 | - | 交易所：SH 上海 / SZ 深圳 / BJ 北交所，不传不限，示例：SZ |
| `pageNum` | `int` | 否 | `0` | 分页偏移，从0开始，默认0，示例：0 |
| `pageSize` | `int` | 否 | `10` | 每页条数，默认10，示例：10 |

### 返回参数

ResultData.data 为 List，元素为上市公司基础字段

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `companyName` | `str` | 否 | 公司全称 |
| `companyShortName` | `str` | 否 | 公司简称 |
| `formername` | `str` | 否 | 曾用名 |
| `industry` | `str` | 否 | 所属行业 |
| `subIndustry` | `str` | 否 | 所属子行业 |
| `establishmentDate` | `str` | 否 | 成立日期 |
| `registrationDate` | `str` | 否 | 注册日期 |
| `registeredCapital` | `str` | 否 | 注册资金（亿） |
| `province` | `str` | 否 | 所属地域 |
| `registeredProvince` | `str` | 否 | 注册地点省 |
| `registeredCity` | `str` | 否 | 注册地点市 |
| `registeredCounty` | `str` | 否 | 注册地点县 |
| `legalRepresentative` | `str` | 否 | 法人代表 |
| `listingDate` | `str` | 否 | 上市时间 |
| `companyType` | `str` | 否 | 公司类型 |
| `businessOverview` | `str` | 否 | 业务概述 |
| `actualController` | `str` | 否 | 实际控制人 |
| `companyIntroduction` | `str` | 否 | 公司简介 |
| `businessRegistrationNumber` | `str` | 否 | 工商注册号 |
| `industryDomain` | `str` | 否 | 行业领域 |
| `stockType` | `str` | 否 | 证券类别 |
| `businessScope` | `str` | 否 | 经营范围 |
| `delistedDate` | `str(datetime)` | 否 | 退市时间 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="F1",
    stockCodes=None,  # str  # 默认: 
    startListedDate=None,  # str  # 默认: 
    endListedDate=None,  # str  # 默认: 
    startDelistedDate=None,  # str  # 默认: 
    endDelistedDate=None,  # str  # 默认: 
    exchange=None,  # str  # 默认: 
    pageNum=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


