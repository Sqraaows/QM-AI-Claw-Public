# Trade_Calendar_List

> Category: 基础数据 | Folder: `Basic_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

获取A股交易日历，包含历史和本年度未来的交易日日期列表，返回交易日日期。适用于判断某日是否为交易日及计算交易日间隔

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "F2" | 接口ID |
| `period` | `int` | 否 | - | 日期列表范围 0：近1年（默认） 1：近1月 2:近3月 3:近6月 4:近1年 5:近2年 <br>6:近3年 7:近5年 示例：0 |
| `startDate` | `str` | 否 | - | 开始日期，示例：2020-01-01 |
| `endDate` | `str` | 否 | - | 结束日期，示例：2024-12-31 |

### 返回参数

ResultData.data 为 List，元素为交易日期

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `tradeDate` | `str` | 否 | 交易日期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="F2",
    period=None,  # int  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
)
```


