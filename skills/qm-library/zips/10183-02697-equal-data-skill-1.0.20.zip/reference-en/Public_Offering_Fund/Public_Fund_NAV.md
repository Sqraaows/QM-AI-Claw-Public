# Public_Fund_NAV

> Category: 公募基金 | Folder: `Public_Offering_Fund` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

公募基金净值:查询公募基金历史净值数据，返回每日净值、累计净值。适用于基金净值走势分析

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "H5" | 接口ID |
| `fundCodeArray` | `str` | 否 | - | 基金代码列表-多个用逗号隔开 示例：'510300','510301' |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，公募基金净值:获取公募基金净值数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `fundCode` | `str` | 否 | 基金代码 |
| `unitNetValueDate` | `str` | 否 | 净值日期 |
| `unitNetValueAdd` | `str` | 否 | 单位净值 |
| `cumulNetValue` | `str` | 否 | 累计净值 |
| `accumulatedDividend` | `str` | 否 | 累计分红 |
| `adjustedUnitNav` | `str` | 否 | 复权单位净值 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="H5",
    fundCodeArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


