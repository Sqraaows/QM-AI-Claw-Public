# Fund_Company_List

> Category: 公募基金 | Folder: `Public_Offering_Fund` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

公募公司列表:查询公募基金管理公司列表，返回公司名称、管理规模、旗下基金数量等基本信息。适用于了解基金公司整体情况

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "H2" | 接口ID |
| `companyNameArray` | `str` | 否 | - | 基金公司名称-多个用逗号隔开-最多不要超过5个, 示例：易方达基金管理有限公司 |
| `companyIdArray` | `str` | 否 | - | 公司Id-多个用逗号隔开 示例：80010229,80000229 |
| `fundTimeStart` | `str` | 否 | - | 公司成立时间-开始区间 示例：2001-01-01 |
| `fundTimeEnd` | `str` | 否 | - | 公司成立时间-结束区间 示例：2001-01-02 |
| `pageIndex` | `int` | 是 | `0` | 当前页从 0 开始：不填系统默认 0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数，最大不能超过 200，不填系统默认 10 |

### 返回参数

ResultData.data 为 List，公募公司列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `companyId` | `int` | 否 | 公司 Id |
| `companyName` | `str` | 否 | 基金公司名称 |
| `shortName` | `str` | 否 | 公司简称 |
| `foundTime` | `str(datetime)` | 否 | 成立时间 |
| `scale` | `float` | 否 | 管理规模（亿元） |
| `fundNum` | `int` | 否 | 全部基金数 |
| `managerNum` | `int` | 否 | 全部基金经理数 |
| `registeredAddress` | `str` | 否 | 注册地址 |
| `officeAddress` | `str` | 否 | 办公地址 |
| `phone` | `str` | 否 | 电话 |
| `businessScope` | `str` | 否 | 营业范围 |
| `legalPerson` | `str` | 否 | 法定代表人 |
| `registeredCapital` | `str` | 否 | 注册资本 |
| `generalManager` | `str` | 否 | 总经理 |
| `registerCapital` | `str` | 否 | 注册资本 |
| `legalName` | `str` | 否 | 公司法定名称 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="H2",
    companyNameArray=None,  # str  # 默认: 
    companyIdArray=None,  # str  # 默认: 
    fundTimeStart=None,  # str  # 默认: 
    fundTimeEnd=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


