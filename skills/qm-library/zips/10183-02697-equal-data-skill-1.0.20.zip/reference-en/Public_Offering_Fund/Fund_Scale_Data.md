# Fund_Scale_Data

> Category: 公募基金 | Folder: `Public_Offering_Fund` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

基金规模数据:查询基金规模数据，主要覆盖上海和深圳ETF基金，返回基金规模、份额等信息

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "H4" | 接口ID |
| `fundCodeArray` | `str` | 否 | - | 基金代码列表-多个用逗号隔开 示例：510300,159915 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，基金规模数据列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `fundCode` | `str` | 否 | 基金代码 |
| `tradeDate` | `str` | 否 | 交易(变动)日期，格式YYYYMMDD |
| `fundShare` | `float` | 否 | 基金份额(万) |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="H4",
    fundCodeArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


