# Public_Fund_Holdings

> Category: 公募基金 | Folder: `Public_Offering_Fund` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

公募基金持仓数据:查询公募基金的持仓明细数据，返回基金持有的股票代码、持仓市值、持仓占比等，季度更新。适用于跟踪基金投资动向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "H6" | 接口ID |
| `fundCodeArray` | `str` | 否 | - | 基金代码-多个用逗号隔开 示例：005802,565821 |
| `stockCodeArray` | `str` | 否 | - | 股票代码-多个用逗号隔开 示例：600519,800512 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，公募基金持仓数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `fundCode` | `str` | 否 | 基金代码 |
| `announcementDate` | `str(datetime)` | 否 | 公告日期 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `HolderValue` | `float` | 否 | 持有股票市值（元） |
| `HolderNum` | `float` | 否 | 持有股票数量（股） |
| `positionRatio` | `str` | 否 | 占股票市值比 |
| `circulationRatio` | `str` | 否 | 占流通股本比例 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="H6",
    fundCodeArray=None,  # str  # 默认: 
    stockCodeArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


