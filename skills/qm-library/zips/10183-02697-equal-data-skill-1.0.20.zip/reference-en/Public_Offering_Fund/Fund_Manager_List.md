# Fund_Manager_List

> Category: 公募基金 | Folder: `Public_Offering_Fund` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

公募基金列表:查询公募基金经理列表，支持按经理名称筛选，返回经理任职年限、个人简历等。适用于评估基金旗下经理能力

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "H3" | 接口ID |
| `fundCodeArray` | `str` | 否 | - | 公募基金,多个用逗号隔开 示例：005802,506006 |
| `fundManagerNameArray` | `str` | 否 | - | 基金姓名-多个用逗号隔开,最多不要超过5个,示例:玄天武,孙大物 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，公募基金经理列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `fundCode` | `str` | 否 | 基金代码:返回示例: '007685',说明:基金经理管理的基金代码列表 |
| `announcementDate` | `str(datetime)` | 否 | 公告日期 |
| `fundManagerName` | `str` | 否 | 基金经理姓名 |
| `gender` | `str` | 否 | 性别 |
| `education` | `str` | 否 | 学历 |
| `appointmentDate` | `str(datetime)` | 否 | 任职日期 |
| `departureDate` | `str(datetime)` | 否 | 离任日期 |
| `resume` | `str` | 否 | 个人简历 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="H3",
    fundCodeArray=None,  # str  # 默认: 
    fundManagerNameArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


