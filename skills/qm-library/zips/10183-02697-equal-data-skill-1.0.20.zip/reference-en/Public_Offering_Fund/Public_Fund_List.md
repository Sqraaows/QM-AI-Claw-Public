# Public_Fund_List

> Category: 公募基金 | Folder: `Public_Offering_Fund` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

公募基金列表:查询公募基金基本信息列表，支持按基金代码、名称、成立日期、投资类型等条件筛选，分页返回基金规模、净值、收益率等详情。适用于基金筛选和对比分析

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "H1" | 接口ID |
| `fundCodeArray` | `str` | 否 | - | 公募基金代码-多个用逗号隔开 示例：005802, 506006 |
| `fundNameArray` | `str` | 否 | - | 基金名称-逗号隔开-不要输入太多,如果有很多的话建议每次5个,分批次来拿,最好通过基金代码来查询, <br>示例:鹏扬景泰成长混合A,鹏扬景泰成长混合B |
| `fundDateStart` | `str` | 否 | - | 成立日期-开始区间 示例:2024-01-01 |
| `fundDateEnd` | `str` | 否 | - | 成立日期-结束区间  示例:2024-01-02 |
| `sort` | `int` | 否 | - | 排序 1-基金规模排序 2-投资类型 3-预期收益率 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，公募基金列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `fundCode` | `str` | 否 | 基金代码 |
| `fundName` | `str` | 否 | 基金名称 |
| `shortName` | `str` | 否 | 简称 |
| `trustee` | `str` | 否 | 托管人 |
| `investmentType` | `str` | 否 | 投资类型（股票型、债券型、混合型、货币型等） |
| `fundDate` | `str` | 否 | 成立日期 |
| `issueDate` | `str(datetime)` | 否 | 发行日期 |
| `issueShare` | `str` | 否 | 发行份额 (亿) |
| `managementFee` | `str` | 否 | 管理费 |
| `trusteeFee` | `str` | 否 | 托管费 |
| `duration` | `str` | 否 | 存续期 |
| `faceValue` | `str` | 否 | 面值 |
| `minAmount` | `str` | 否 | 起点金额 (万元) |
| `expectedReturn` | `str` | 否 | 预期收益率 |
| `benchmark` | `str` | 否 | 业绩比较基准 |
| `fundType` | `str` | 否 | 基金类型 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="H1",
    fundCodeArray=None,  # str  # 默认: 
    fundNameArray=None,  # str  # 默认: 
    fundDateStart=None,  # str  # 默认: 
    fundDateEnd=None,  # str  # 默认: 
    sort=None,  # int  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


