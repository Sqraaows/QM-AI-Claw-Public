# Latest_Synergy_Data

> Category: 股东协同 | Folder: `Shareholder_Synergy` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询最新股东协同数据，支持按照协同主体查询（如输入不完整，会先调用M4搜索接口匹配最相似的主体）

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "M1" | 接口ID |
| `keyWord` | `str` | 否 | - | 协同主体，支持精确搜索和模糊搜索 |
| `shareholderTypeCode` | `str` | 否 | - | 协同股东类型，3001-公募 1003-私募 1006-信托公司 1007-证券公司 <br>1009-保险公司 1015-外资 8000-国家队、养老基金、社保基金 1201-知名机构 <br>全部不传值 |
| `parterStates` | `str` | 否 | - | 协同方向 1-同时买入 2-同时卖出 3-一买一卖，多个用“,”隔开，默认全部查询  |
| `dateType` | `int` | 否 | `2` | 协同的时间范围 1-近一个月 2-近3个月 3-近6个月 4-近一月 5-近3年 6-近5年,<br>默认2，表示近3个月  |
| `parterNum` | `int` | 否 | `3` | 协同总数 几次以上就传几，默认3次以上  |
| `sortType` | `int` | 否 | - | 排序字段 1-协同总数 2-同类协同总数,默认 1 |
| `sortDirect` | `int` | 否 | - | 排序方向 1-倒序 -1-正序，默认1  |
| `pageIndex` | `int` | 否 | `0` | 当前页 从0开始 |
| `pageSize` | `int` | 否 | `10` | 每页容量 |

### 返回参数

ResultData.data 为 List，元素为 SubjectParterListResponseVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `dataDate` | `str` | 是 | 协同日期 |
| `publicDate` | `str` | 是 | 公告日期 |
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 是 | 股票简称 |
| `trackDayNum` | `int` | 是 | 跟踪天数 |
| `riseRatio` | `float` | 是 | 上涨占比 |
| `sameParterNum` | `int` | 是 | 同类协同总数 |
| `parterNumTotal` | `int` | 是 | 协同总次数 |
| `parterState` | `int` | 是 | 协作类型 |
| `md5Str` | `str` | 是 | MD5值 |
| `lightsDesc` | `str` | 是 | 协同亮点描述 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="M1",
    keyWord=None,  # str  # 默认: 
    shareholderTypeCode=None,  # str  # 默认: 
    parterStates=None,  # str  # 默认: 
    dateType=None,  # int  # 默认: 2
    parterNum=None,  # int  # 默认: 3
    sortType=None,  # int  # 默认: 
    sortDirect=None,  # int  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


