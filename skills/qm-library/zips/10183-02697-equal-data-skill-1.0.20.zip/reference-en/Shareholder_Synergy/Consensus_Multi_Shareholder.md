# Consensus_Multi_Shareholder

> Category: 股东协同 | Folder: `Shareholder_Synergy` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询协同行为数据，可按协同方向、时间范围、协同频次筛选，支持自定义排序与分页，返回个股协同日期、行情表现、协同次数、协作类型及亮点说明等信息。

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "M3" | 接口ID |
| `parterStates` | `str` | 否 | - | 协同方向 1-同时买入 2-同时卖出 3-一买一卖，多个用“,”隔开，默认全部查询  |
| `dateType` | `int` | 否 | `2` | 协同的时间范围 1-近一个月 2-近3个月 3-近6个月 4-近一月 5-近3年 6-近5年,<br>默认2，表示近3个月  |
| `parterNum` | `int` | 否 | `3` | 协同总数 几次以上就传几，默认3次以上  |
| `sortType` | `int` | 否 | - | 排序字段 1-协同总数 2-同类协同总数,默认 1 |
| `sortDirect` | `int` | 否 | - | 排序方向 1-倒序 -1-正序，默认1  |
| `pageIndex` | `int` | 否 | `0` | 当前页 从0开始 |
| `pageSize` | `int` | 否 | `10` | 每页容量 |

### 返回参数

ResultData.data 为 List，元素为 SubjectParterListResponseVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `dataDate` | `str` | 是 | 协同日期 |
| `publicDate` | `str` | 是 | 公告日期 |
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 是 | 股票简称 |
| `trackDayNum` | `int` | 是 | 跟踪天数 |
| `riseRatio` | `float` | 是 | 上涨占比 |
| `sameParterNum` | `int` | 是 | 同类协同总数 |
| `parterNumTotal` | `int` | 是 | 协同总次数 |
| `parterState` | `int` | 是 | 协作类型 |
| `md5Str` | `str` | 是 | MD5值 |
| `lightsDesc` | `str` | 是 | 协同亮点描述 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="M3",
    parterStates=None,  # str  # 默认: 
    dateType=None,  # int  # 默认: 2
    parterNum=None,  # int  # 默认: 3
    sortType=None,  # int  # 默认: 
    sortDirect=None,  # int  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


