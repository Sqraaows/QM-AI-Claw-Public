# Executive_Holding_Amount_Rank

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询一段时间内A股上市公司高管增持/减持金额排名榜单，返回股票名称、变动金额、变动股数等。适用于发现高管大规模增减持行为

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B6" | 接口ID |
| `period` | `int` | 否 | `1` | 1-近1月、2-近3月、3-近半年、4-近1年 |
| `changeType` | `int` | 否 | `0` | 变动类型（增持：1，减持：-1），0或不传表示全部 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数 |

### 返回参数

高管持股-增减持金额排行榜

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `totalQuantity` | `int` | 否 | 增减持数量 |
| `totalAmount` | `float` | 否 | 总金额 |
| `ratioOfTotal` | `float` | 否 | 占总股本比 |
| `ratioOfCirculate` | `float` | 否 | 占流通股比 |
| `actualChangeQuantity` | `int` | 否 | 净增持/减持数量 |
| `avgPrice` | `float` | 否 | 增减持均价 |
| `chgPct` | `float` | 否 | 当日涨跌幅 |
| `changeType` | `str` | 否 | 持股变动类型 增持/减持 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B6",
    period=None,  # int  # 默认: 1
    changeType=None,  # int  # 默认: 0
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


