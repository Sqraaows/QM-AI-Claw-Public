# Executive_Plan_Detail

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询某个具体高管增减持计划的详细数据，返回计划增减持数量、完成进度等。适用于跟踪高管增减持计划的执行情况

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B10" | 接口ID |
| `pageIndex` | `int` | 是 | - | 当前页从0开始 |
| `pageSize` | `int` | 是 | - | 每页显示记录数 |
| `stockCode` | `str` | 是 | - | 股票代码 |
| `managerName` | `str` | 否 | - | 高管名称 |

### 返回参数

高管单条增减持计划详情

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `companyName` | `str` | 否 | 公司全称 |
| `type` | `str` | 否 | 类型：增持/减持 |
| `announcementDate` | `str` | 否 | 公告日期 |
| `pdfUrl` | `str` | 否 | 公告链接 |
| `progress` | `str` | 否 | 进度(进行中、已完成) |
| `holderPositionDesc` | `str` | 否 | 股东名称以及职位 |
| `transactionRatio` | `float` | 否 | 增减持数量占总股本比例 |
| `managerInfoList` | `list[ManagerSharesPlanDetailVo.ManagerInfo]` | 否 | 计划涉及的高管信息列表 |

**`managerInfoList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `personEsId` | `int` | 否 | 高管ESId |
| `personInfoId` | `str` | 否 | 高管InfoId |
| `managerName` | `str` | 否 | 高管姓名 |
| `position` | `str` | 否 | 职务 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B10",
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
    stockCode=None,  # str  # 默认: 
    managerName=None,  # str  # 默认: 
)
```


