# Performance_Forecast

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

提供上市公司业绩披露的相关数据, 主要包括 预增、预减、暴雷、预亏, 续盈等

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B19" | 接口ID |
| `preType` | `int` | 否 | - | 预告类型 0-预减 1-预增(默认为0) |
| `currentPage` | `int` | 是 | - | 当前页 从0开始 |
| `pageSize` | `int` | 是 | - | 每页容量 |

### 返回参数

业绩预告-业绩暴雷、业绩预增

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `label` | `list[str]` | 否 | 标签列表 |
| `predictAmtMin` | `int` | 否 | 预测数值最小 |
| `predictAmtMax` | `int` | 否 | 预测数值最大 |
| `addAmpMin` | `float` | 否 | 业绩变动同比最小 |
| `addAmpMax` | `float` | 否 | 业绩变动同比最大 |
| `predictType` | `str` | 否 | 预告类型 |
| `publicDate` | `str` | 否 | 预告日期 |
| `lossNum` | `int` | 否 | 亏损事件数量 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `odds` | `float` | 否 | 上涨下跌概率 |
| `zdfAvg` | `float` | 否 | 平均涨跌幅 |
| `zdfAvgMax` | `float` | 否 | 平均最高涨跌幅 |
| `desc` | `str` | 否 | 描述 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B19",
    preType=None,  # int  # 默认: 
    currentPage=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
)
```


