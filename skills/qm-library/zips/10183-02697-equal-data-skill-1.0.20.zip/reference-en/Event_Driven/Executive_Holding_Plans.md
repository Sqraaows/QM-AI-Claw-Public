# Executive_Holding_Plans

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询近期发布高管增减持计划的上市公司列表及计划详情，返回公司名称、计划增减持数量、价格区间、计划进度等。适用于预判高管的增减持意向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B8" | 接口ID |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数  |
| `changeType` | `int` | 否 | - | 变动类型（增持：1，减持：-1， 增减持  0,默认）  |
| `startDate` | `str` | 否 | - | 开始时间 示例：2020-01-01 |
| `endDate` | `str` | 否 | - | 结束时间 示例：2024-12-31 |

### 返回参数

高管增减持计划列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `companyName` | `str` | 否 | 公司全称 |
| `type` | `str` | 否 | 类型：增持/减持 |
| `announcementDate` | `str` | 否 | 公告日期 |
| `pdfUrl` | `str` | 否 | 公告链接 |
| `progress` | `str` | 否 | 进度(进行中、已完成) |
| `holderPositionDesc` | `str` | 否 | 股东名称以及职位 |
| `transactionRatio` | `float` | 否 | 增减持数量占总股本比例 |
| `managerInfoList` | `list[ManagerSharesPlanDetailVo.ManagerInfo]` | 否 | 计划涉及的高管信息列表 |

**`managerInfoList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `personEsId` | `int` | 否 | 高管ESId |
| `personInfoId` | `str` | 否 | 高管InfoId |
| `managerName` | `str` | 否 | 高管姓名 |
| `position` | `str` | 否 | 职务 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B8",
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
    changeType=None,  # int  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
)
```


