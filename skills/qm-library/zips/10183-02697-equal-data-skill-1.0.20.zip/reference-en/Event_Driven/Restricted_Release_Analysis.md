# Restricted_Release_Analysis

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

分析上市公司历史限售解禁后的股价表现，返回解禁后最佳上涨概率、平均涨幅等高阶数据。适用于评估解禁事件对股价的历史影响规律

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B16" | 接口ID |
| `stockCode` | `str` | 是 | - | 股票代码 |

### 返回参数

限售解禁数据分析接口

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `oddsStrackDayNum` | `int` | 否 | 上涨概率跟踪天数 |
| `zdfAvgStrackDayNum` | `int` | 否 | 平均涨幅跟踪天数 |
| `zdfOdds` | `float` | 否 | 上涨概率 |
| `zdfAvg` | `float` | 否 | 平均涨幅 |
| `historyNum` | `int` | 否 | 历史发生次数 |
| `statisticDate` | `str` | 否 | 统计日期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B16",
    stockCode=None,  # str  # 默认: 
)
```


