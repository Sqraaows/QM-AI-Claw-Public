# Block_Trade_Broker_Data

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

从营业部维度查询大宗交易数据，支持按折价/溢价筛选，返回营业部名称、买入/卖出金额、交易股票等。适用于分析哪些营业部在大宗交易中活跃

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B17" | 接口ID |
| `dataType` | `int` | 否 | `1` | 数据类型 1-大宗溢价 2-大宗折价 |
| `startDate` | `str` | 否 | - | 开始日期，格式： 2025-09-01，开始日期不能大于结束日期 |
| `endDate` | `str` | 否 | - | 结束日期，格式： 2025-09-01，结束日期不能小于开始日期 |
| `pageIndex` | `int` | 否 | `0` | 当前页 从0开始 |
| `pageSize` | `int` | 否 | `10` | 每页容量 |

### 返回参数

大宗数据-活跃营业部

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `buyerDeptName` | `str` | 否 | 营业部名称 |
| `dateStr` | `str` | 否 | 交易日期 |
| `odds` | `float` | 否 | 上涨或下跌概率 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `num` | `int` | 否 | 近10年折价或溢价次数 |
| `zdfAvg` | `float` | 否 | 平均涨幅 |
| `dealAmount` | `int` | 否 | 平均涨幅 |
| `stockCodes` | `str` | 否 | 股票代码列表 |
| `stockList` | `list[Stock]` | 否 | 操作过的股票列表（股票代码、股票名称） |

**`stockList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B17",
    dataType=None,  # int  # 默认: 1
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


