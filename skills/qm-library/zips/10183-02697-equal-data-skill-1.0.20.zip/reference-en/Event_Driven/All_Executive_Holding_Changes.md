# All_Executive_Holding_Changes

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询A股所有上市公司的高管增减持变动数据列表，支持按变动类型（增持/减持）和日期范围筛选，返回变动公司、高管姓名、变动数量、变动金额等。适用于全面监控高管增减持动向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B7" | 接口ID |
| `pageIndex` | `int` | 是 | - | 当前页从0开始 |
| `pageSize` | `int` | 是 | - | 每页显示记录数 |
| `changeType` | `int` | 否 | - | 变动类型（增持：1，减持：-1, 0：全部 默认） |
| `startDate` | `str` | 否 | - | 开始时间，如果开始时间和结束时间都不传，默认按照日期倒序，给最新的20条；<br>(格式为yyyy-MM-dd，可指定查询具体日期) |
| `endDate` | `str` | 否 | - | 结束时间 如果开始时间和结束时间都不传，默认按照日期倒序，给最新的20条；<br>(格式为yyyy-MM-dd，可指定查询具体日期) |

### 返回参数

所有高管增减持变动数据列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `totalQuantity` | `int` | 否 | 增减持数量 |
| `totalAmount` | `float` | 否 | 总金额 |
| `ratioOfTotal` | `float` | 否 | 占总股本比 |
| `ratioOfCirculate` | `float` | 否 | 占流通股比 |
| `actualChangeQuantity` | `int` | 否 | 净增持/减持数量 |
| `avgPrice` | `float` | 否 | 增减持均价 |
| `chgPct` | `float` | 否 | 当日涨跌幅 |
| `changeType` | `str` | 否 | 持股变动类型 增持/减持 |
| `mangerName` | `str` | 否 | 高管姓名 |
| `changeName` | `str` | 否 | 变动人姓名 |
| `position` | `str` | 否 | 高管职位 |
| `relationDesc` | `str` | 否 | 变动人与高管关系 |
| `zdOdds` | `float` | 否 | 上涨概率 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `changeDate` | `str` | 否 | 变动日期 |
| `changeReason` | `str` | 否 | 变动原因（增减持方式） |
| `kinshipNum` | `int` | 否 | 是否有人物关系图 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B7",
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
    changeType=None,  # int  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
)
```


