# Hot_Rank_Detail

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询某季度各机构类型的榜单详情，支持买入榜/卖出榜/跌破国家队持仓榜/高管增减持榜等多种榜单类型，返回股票累计变动股数、持股占比、变动比例等。适用于深度分析机构和高管的季度操作

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B13" | 接口ID |
| `pageIndex` | `int` | 是 | - | 当前页从0开始 |
| `pageSize` | `int` | 是 | - | 每页显示记录数 |
| `agencyType` | `int` | 是 | - | 机构类型 2007-牛散 3001-公募 1003-私募 1006-信托公司 1007-证券公司 <br>1009-保险公司 1015-外资 8000-国家队 1201-知名机构  9999-热门榜单  |
| `reportDate` | `str` | 是 | - | 报告期 yyyy-MM-dd格式，如 2025-09-30 |
| `direc` | `int` | 是 | `1` | 榜单类型 1-买入榜 2-卖出榜 34-跌破国家队持仓榜 35-高管增持榜 36-高管减持榜 |
| `sortDesc` | `int` | 是 | `0` | 变动比例排序  0-降序 1-升序 |

### 返回参数

机构风云榜榜单详情数据 返回数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `productNum` | `int` | 否 | 基金数/私募家数... |
| `changeQuantity` | `int` | 否 | 累计变动股数 |
| `holdRatio` | `float` | 否 | 当前持股占比 |
| `thisChangeRatio` | `float` | 否 | 持股变动比例 |
| `changeDire` | `str` | 否 | 持股变动方向 |
| `changeDireLabel` | `str` | 否 | 是否含新进/退出标签 |
| `changeMarketValue` | `float` | 否 | 持股变动市值 |
| `reportDateFormat` | `str` | 否 | 格式化后的报告期 |
| `reportDate` | `str` | 否 | 报告期 |
| `totalShareHoldNum` | `int` | 否 | 本期持股总数 |
| `totalShareHoldNumOld` | `int` | 否 | 上期末持股总数 |
| `cycleRatio` | `str` | 否 | 环比变动 |
| `changeMoney` | `float` | 否 | 变动金额 |
| `secIndustryName` | `str` | 否 | 二级行业 |
| `industryCode` | `str` | 否 | 二级板块Id |
| `concept` | `str` | 否 | 概念 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B13",
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
    agencyType=None,  # int  # 默认: 
    reportDate=None,  # str  # 默认: 
    direc=None,  # int  # 默认: 1
    sortDesc=None,  # int  # 默认: 0
)
```


