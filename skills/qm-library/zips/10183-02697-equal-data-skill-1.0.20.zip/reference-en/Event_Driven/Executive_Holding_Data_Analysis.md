# Executive_Holding_Data_Analysis

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

 基于个股高管持股变动数据，统计历史同类事件后的股价表现，计算上涨概率与平均涨幅，辅助判断高管持股对股票涨跌的影响

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B11" | 接口ID |
| `stockCode` | `str` | 是 | - | 股票代码 |

### 返回参数

高管持股数据分析

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `companyName` | `str` | 否 | 公司全称 |
| `kinshipNum` | `int` | 否 | 是否有人物关系图 |
| `scaleType` | `int` | 否 | 上市公司标签  '市值、管理规模类型 1-千亿公募 2-百亿私募 3-500亿市值上市公司,' |
| `totalShares` | `int` | 否 | 总股本 |
| `circulateShares` | `int` | 否 | 流通股本 |
| `oddsStrackDayNum` | `int` | 否 | 上涨概率跟踪天数 |
| `zdfAvgStrackDayNum` | `int` | 否 | 平均涨幅跟踪天数 |
| `zdfOdds` | `float` | 否 | 上涨概率 |
| `zdfAvg` | `float` | 否 | 平均涨幅 |
| `historyNum` | `int` | 否 | 历史发生次数 |
| `statisticDate` | `str` | 否 | 统计日期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B11",
    stockCode=None,  # str  # 默认: 
)
```


