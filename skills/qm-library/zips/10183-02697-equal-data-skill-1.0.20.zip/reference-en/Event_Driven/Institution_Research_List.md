# Institution_Research_List

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询上市公司接待机构调研的数据，支持按股票代码或名称查询，返回调研日期、调研机构名称、星标数量等。适用于发现机构重点关注方向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B22" | 接口ID |
| `stockCode` | `str` | 否 | - | 股票代码 |
| `dateStr` | `str` | 否 | - | 公告日期 |
| `pageIndex` | `int` | 是 | - | 当前页 从0开始 |
| `pageSize` | `int` | 是 | - | 每页容量 |

### 返回参数

机构调研列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `researchDate` | `str` | 否 | 调研日期 |
| `reportDate` | `str` | 否 | 公告日期 |
| `researchFirstTradeDate` | `str` | 否 | 调研后第一个交易日 |
| `starNum` | `int` | 否 | 星标数量 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B22",
    stockCode=None,  # str  # 默认: 
    dateStr=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
)
```


