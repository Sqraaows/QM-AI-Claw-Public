# Restricted_Release_Detail

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询某上市公司的所有限售解禁相关数据，包含历史已解禁和未来待解禁的详细信息（解禁日期、数量、比例、股东名称等）。适用于全面评估个股解禁压力

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B15" | 接口ID |
| `stockCode` | `str` | 是 | - | 股票代码 |

### 返回参数

限售解禁详情页

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `scaleType` | `int` | 否 | 公司标签  市值、管理规模类型 1-千亿公募 2-百亿私募 3-500亿市值上市公司 |
| `totalShares` | `int` | 否 | 公司总股本 |
| `circulateShares` | `int` | 否 | 流通股本 |
| `planTotalQuantity` | `int` | 否 | 预告解禁总数量 |
| `historyTotalQuantity` | `int` | 否 | 历史解禁总数量 |
| `historyNum` | `int` | 否 | 近10年历史发生次数 |
| `detailList` | `list[FreeBatchDetailDataVo]` | 否 | 解禁明细 |

**`detailList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `freeDate` | `str` | 否 | 解禁日期 |
| `managerNum` | `int` | 否 | 涉及股东数量 |
| `totalQuantity` | `int` | 否 | 本次解禁总股数 |
| `dataType` | `int` | 否 | 1-解禁预告 ; 2-历史解禁 |
| `ratioOfTotal` | `float` | 否 | 解禁数量占总股本比 |
| `totalMarketValue` | `float` | 否 | 预计解禁市值 |
| `label` | `str` | 否 | 是否今日解禁 |
| `totalShares` | `int` | 否 | 总股本 |
| `managerInfoList` | `list[FreeBatchManagerInfoVo]` | 否 | 涉及股东明细 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B15",
    stockCode=None,  # str  # 默认: 
)
```


