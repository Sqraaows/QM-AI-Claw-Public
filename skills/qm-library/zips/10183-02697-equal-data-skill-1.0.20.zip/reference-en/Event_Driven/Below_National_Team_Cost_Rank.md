# Below_National_Team_Cost_Rank

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询当前股价跌破国家队持仓成本的股票排行榜，返回持仓成本、当前股价、跌破幅度等。适用于寻找被国家队重仓但短期被套的潜在价值股票

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B24" | 接口ID |
| `sortName` | `int` | 否 | - |  排序字段 1-跌破日期（默认）  2-收益率 |
| `sortDirect` | `int` | 否 | - | 排序 1-倒序 2-正序  |
| `pageIndex` | `int` | 否 | - | 当前页从0开始，默认0 |
| `pageSize` | `int` | 否 | - | 每页显示记录数，默认30条 |

### 返回参数

跌破国家队持仓成本排行数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `holderName` | `str` | 否 | 股东名称 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `industry` | `str` | 否 | 申万二级行业 |
| `lastFallDate` | `str` | 否 | 最近跌破成本日期 |
| `shareholdNum` | `int` | 否 | 持股数 |
| `costPrice` | `float` | 否 | 持仓成本价 |
| `newPrice` | `float` | 否 | 最新价 |
| `yieldRate` | `float` | 否 | 预估收益率 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B24",
    sortName=None,  # int  # 默认: 
    sortDirect=None,  # int  # 默认: 
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
)
```


