# Hot_Rank_Holding_List

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询各机构类型的最新持仓榜数据，返回持仓股票、持仓市值、持股数量等。适用于了解各类型机构的重仓股分布

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B23" | 接口ID |
| `agencyType` | `int` | 否 | - | 机构类型 2007-牛散 3001-公募 1003-私募 1006-信托公司 1007-证券公司 <br>1009-保险公司 1015-外资 8000-国家队 1201-知名机构   |
| `dateStr` | `str` | 否 | - | 报告期  |
| `sortDirect` | `int` | 否 | - | 排序 1-倒序 2-正序  |
| `pageIndex` | `int` | 否 | - | 当前页从0开始,默认0 |
| `pageSize` | `int` | 否 | - | 每页显示记录数,默认30 |

### 返回参数

热门榜单持仓榜数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `publicDate` | `str` | 否 | 更新日期 |
| `industry` | `str` | 否 | 申万二级行业 |
| `shareholdNum` | `int` | 否 | 持股数 |
| `shareholdRatio` | `str` | 否 | 持股数比例(%) |
| `currentMarketValue` | `str` | 否 | 持股市值（单位：元） |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B23",
    agencyType=None,  # int  # 默认: 
    dateStr=None,  # str  # 默认: 
    sortDirect=None,  # int  # 默认: 
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
)
```


