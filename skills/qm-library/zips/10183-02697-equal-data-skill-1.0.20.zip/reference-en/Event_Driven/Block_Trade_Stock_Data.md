# Block_Trade_Stock_Data

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询发生大宗交易的股票数据，支持按折价/溢价筛选，返回成交均价、折溢率、成交总量、成交总额、上涨概率等。适用于发现大资金的建仓或出货行为

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B18" | 接口ID |
| `type` | `int` | 是 | `1` | 异动类型 1-大宗溢价 2-大宗折价 |
| `startDate` | `str` | 否 | - | 开始日期，格式： 2025-09-01，开始日期不能大于结束日期 |
| `endDate` | `str` | 否 | - | 结束日期，格式： 2025-09-01，结束日期不能小于开始日期 |
| `currentPage` | `int` | 否 | `0` | 当前页 从0开始 |
| `pageSize` | `int` | 否 | `10` | 每页容量 |

### 返回参数

大宗数据-活跃个股

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `dateStr` | `str` | 否 | 交易日期 |
| `dealType` | `int` | 否 | 交易类型 0-折价 1-溢价 |
| `avgPrice` | `float` | 否 | 成交均价（元） |
| `premiumRatio` | `float` | 否 | 折溢率（%） |
| `dealVolume` | `float` | 否 | 成交总量（万股） |
| `dealAmount` | `float` | 否 | 成交总额（万元） |
| `riseFallOdds` | `float` | 否 | 上涨或下跌概率 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `riseFallNum` | `int` | 否 | 折价或溢价次数 |
| `isTop` | `int` | 否 | 是否龙头 0-否，1-是 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B18",
    type=None,  # int  # 默认: 1
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    currentPage=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


