# Hot_Rank_Basic_Info

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

按报告期统计所有机构类型（公募/私募/外资/国家队等）的持股变动排名，返回各机构的买入/卖出操作数量。适用于发现当期最受关注的机构

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B12" | 接口ID |
| `agencyType` | `int` | 否 | - | 机构类型 2007-牛散（默认） 3001-公募 1003-私募 1006-信托公司 <br>1007-证券公司 1009-保险公司 1015-外资 8000-国家队 1201-知名机构  <br>全部不传值  |
| `reportDate` | `str` | 否 | - | 报告期 yyyy-MM-dd格式，如 2025-09-30 |
| `direc` | `int` | 是 | `1` | 榜单类型 1-买入榜 2-卖出榜 |

### 返回参数

机构风云榜榜单列表 返回数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `agencyId` | `int` | 是 | 机构ID |
| `agencyType` | `int` | 是 | 榜单机构类型 |
| `agencyName` | `str` | 是 | 机构名称 |
| `reportDate` | `str` | 是 | 报告期 yyyy-MM-dd |
| `transDirect` | `int` | 是 | 操作类型  1-买入榜单 2-卖出榜单 |
| `reportYear` | `str` | 否 | 报告期年 |
| `reportQuarter` | `str` | 否 | 报告期季度 |
| `staticPicUrl` | `str` | 否 | 静态图片地址 |
| `sourceId` | `int` | 否 | 来源 1-机构动向 2-股东协同 |
| `firstCategory` | `int` | 否 | 一级分类 0-热门榜单 1-买入榜 2-卖出榜 3-协同榜 |
| `title` | `str` | 否 | 类型标题 |
| `iconUrl` | `str` | 否 | 榜单类型对应的 icon地址 |
| `jumpUrl` | `str` | 否 | 跳转页面地址（已拼接参数） |
| `updateDate` | `str` | 否 | 数据更新日期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B12",
    agencyType=None,  # int  # 默认: 
    reportDate=None,  # str  # 默认: 
    direc=None,  # int  # 默认: 1
)
```


