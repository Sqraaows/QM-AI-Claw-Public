# Restricted_Release_List

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询近期即将解禁和历史已解禁的股票列表，返回解禁日期、解禁数量、解禁比例等。适用于预判解禁对股价的潜在压力

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B14" | 接口ID |
| `pageIndex` | `int` | 是 | - | 当前页从0开始 |
| `pageSize` | `int` | 是 | - | 每页显示记录数 |
| `startDate` | `str` | 否 | - | 开始日期，格式： 2025-09，开始日期不能大于结束日期 |
| `endDate` | `str` | 否 | - | 结束日期，格式： 2025-09，结束日期不能小于开始日期 |
| `dataType` | `int` | 否 | `1` | 1-解禁预告 2-历史解禁 |

### 返回参数

限售解禁-解禁数据列表（历史解禁/预告/仅自选）

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `odds` | `float` | 否 | 上涨概率 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `historyNum` | `int` | 否 | 历史发生次数 |
| `freeDate` | `str` | 否 | 解禁日期 |
| `scaleType` | `int` | 否 | 公司标签 ， 3-表示 500以上市值 |
| `totalQuantity` | `int` | 否 | 解禁数量 |
| `totalShares` | `int` | 否 | 公司总股本 |
| `circulateShares` | `int` | 否 | 流通股本 |
| `totalMarketValue` | `float` | 否 | 预计解禁市值 |
| `actualMarketValue` | `float` | 否 | 实际解禁市值 |
| `ratioOfTotal` | `float` | 否 | 解禁数量占总股本比 |
| `sharesType` | `str` | 否 | 解禁股份来源 |
| `label` | `str` | 否 | 是否今日解禁 |
| `managerName` | `str` | 否 | 股东名称 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B14",
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    dataType=None,  # int  # 默认: 1
)
```


