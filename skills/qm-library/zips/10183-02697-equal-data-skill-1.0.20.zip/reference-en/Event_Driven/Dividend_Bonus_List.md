# Dividend_Bonus_List

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

提供上市公司分红预案和分红实施相关的数据

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B21" | 接口ID |
| `startDate` | `str` | 否 | - | 开始日期，格式： 2025-09-01，开始日期不能大于结束日期 |
| `endDate` | `str` | 否 | - | 结束日期，格式： 2025-09-01，结束日期不能小于开始日期 |
| `scheduleType` | `int` | 是 | - | 实施进度 1-分红预案 2-实施完成 |
| `currentPage` | `int` | 是 | - | 当前页 从0开始 |
| `pageSize` | `int` | 是 | - | 每页容量 |

### 返回参数

分红送转预案/实施

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `odds` | `float` | 否 | 上涨下跌概率 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `plan` | `str` | 否 | 分配方案 |
| `schedule` | `str` | 否 | 实施进度 |
| `depriveRightsDate` | `str` | 否 | 除权除息日 |
| `equityRegistDate` | `str` | 否 | 股权登记日 |
| `reportDate` | `str` | 否 | 报告期 |
| `publicDate` | `str` | 否 | 预案公告日期 |
| `implPublicDate` | `str` | 否 | 实施公告日期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B21",
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    scheduleType=None,  # int  # 默认: 
    currentPage=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
)
```


