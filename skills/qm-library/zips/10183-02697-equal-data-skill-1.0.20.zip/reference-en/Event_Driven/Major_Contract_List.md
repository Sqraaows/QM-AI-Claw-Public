# Major_Contract_List

> Category: 事件驱动 | Folder: `Event_Driven` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询近期签署重大合同的上市公司列表及合同详情，返回上市公司股票代码、合同金额、签署主体等。适用于跟踪上市公司重大业务进展

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B20" | 接口ID |
| `pageIndex` | `int` | 是 | - | 当前页 从0开始 |
| `pageSize` | `int` | 是 | - | 每页容量 |
| `startDate` | `str` | 否 | - | 开始日期，格式： 2025-09-01，开始日期不能大于结束日期 |
| `endDate` | `str` | 否 | - | 结束日期，格式： 2025-09-01，结束日期不能小于开始日期 |

### 返回参数

重大合同-数据列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `publicTime` | `str` | 否 | 发布时间 |
| `odds` | `float` | 否 | 上涨下跌概率 |
| `contractAmount` | `float` | 否 | 合同金额 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `signBody` | `str` | 否 | 签署主体 |
| `signBodyRelative` | `str` | 否 | 签署主体与上市公司关系 |
| `otherSigner` | `str` | 否 | 其他签署方 |
| `contractNum` | `int` | 否 | 历史合同数 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B20",
    pageIndex=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
)
```


