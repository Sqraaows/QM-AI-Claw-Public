# Broker_Hot_Money_Seats

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

● 查询机构营业部关联的游资席位列表，返回游资名称。适用于识别营业部背后的游资势力主要财务指标

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "C1" | 接口ID |
| `deptName` | `str` | 是 | - | 营业部名称，支持模糊查询 |

### 返回参数

机构营业部关联的游资列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `hotMoneyNames` | `list[str]` | 是 | 游资席位名称列表 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="C1",
    deptName=None,  # str  # 默认: 
)
```


