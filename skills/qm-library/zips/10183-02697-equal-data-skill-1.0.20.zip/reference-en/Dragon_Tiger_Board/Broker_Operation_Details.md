# Broker_Operation_Details

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询指定营业部的历史每日操作明细，返回买入/卖出股票、成交金额等。适用于追踪特定营业部的操作规律

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "C2" | 接口ID |
| `deptName` | `str` | 是 | - | 营业部全称 |
| `sortName` | `int` | 否 | - | 排序字段 1-交易日期 2-净买额，默认按照交易日期倒序 |
| `sortType` | `int` | 否 | - | 排序类型 1-倒序 2-正序，默认按照倒序 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数,单次查询最大20条,默认20条 |

### 返回参数

营业部操作明细列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `tradeDate` | `str` | 否 | 交易日期 |
| `buyAmount` | `float` | 否 | 买入金额 |
| `sellAmount` | `float` | 否 | 卖出金额 |
| `buyAmountClean` | `float` | 否 | 净买入金额 |
| `periodDays` | `int` | 否 | 连续N个交易日 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="C2",
    deptName=None,  # str  # 默认: 
    sortName=None,  # int  # 默认: 
    sortType=None,  # int  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


