# Dragon_Tiger_Broker_Rank

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询指定交易日上榜龙虎榜的所有营业部排行榜，返回营业部名称、买入金额、卖出金额、净买入额及当天操作的股票。适用于分析各营业部的资金动向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B4" | 接口ID |
| `tradeDate` | `str` | 是 | - | 交易日期(格式为yyyy-MM-dd，可指定查询具体日期) |

### 返回参数

龙虎榜-营业部榜数据列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `deptName` | `str` | 是 | 营业部名称 |
| `hotMoneyNames` | `list[str]` | 否 | 关联游资名称列表 |
| `buyStockList` | `list[DeptListVo.StockInfo]` | 否 | 买入股票列表 |
| `sellStockList` | `list[DeptListVo.StockInfo]` | 否 | 卖出股票列表 |
| `buyNum` | `int` | 否 | 买入个股数量 |
| `sellNum` | `int` | 否 | 卖出个股数量 |
| `buyAmount` | `float` | 否 | 买入金额 |
| `sellAmount` | `float` | 否 | 卖出金额 |
| `buyAmountClean` | `float` | 否 | 净买入金额 |

**`buyStockList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 买入股票代码 |
| `stockName` | `str` | 否 | 买入股票名称 |
| `periodDays` | `int` | 否 | 买入连续N日标签 |

**`sellStockList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 卖出股票代码 |
| `stockName` | `str` | 否 | 卖出股票名称 |
| `periodDays` | `int` | 否 | 卖出连续N日标签 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B4",
    tradeDate=None,  # str  # 默认: 
)
```


