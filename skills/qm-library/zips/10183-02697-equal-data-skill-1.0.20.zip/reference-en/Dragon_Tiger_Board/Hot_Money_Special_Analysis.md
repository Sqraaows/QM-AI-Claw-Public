# Hot_Money_Special_Analysis

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

分析游资历史操作数据，统计近1年/近1月的买入上涨概率、平均涨幅等指标。适用于评估游资的操作胜率和风格

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "C3" | 接口ID |
| `hotMoney` | `str` | 是 | - | 游资名称 |

### 返回参数

龙虎榜-游资特色指标分析（近1年/近1月）数据列表,含最佳上涨概率、最佳平均涨幅及图表数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `odds` | `float` | 否 | 最佳上涨概率 |
| `zdfAvg` | `float` | 否 | 最佳平均涨幅 |
| `riseTrackDay` | `int` | 否 | 上涨概率跟踪天数 |
| `zdfAvgTrackDay` | `int` | 否 | 涨跌幅跟踪天数 |
| `listNum` | `int` | 否 | 上买榜次数 |
| `chartDataList` | `list[DragonTradeAnalysisVO.AnalysisChartData]` | 否 | 图表数据列表 |

**`chartDataList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `tradeDateDesc` | `str` | 否 | 交易日描述（如T、T+1等） |
| `riseRatio` | `float` | 否 | 上涨概率 |
| `riseNum` | `int` | 否 | 上升个股数 |
| `fallNum` | `int` | 否 | 下跌个股数 |
| `zdfAvg` | `float` | 否 | 平均涨幅 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="C3",
    hotMoney=None,  # str  # 默认: 
)
```


