# Dragon_Tiger_Market_Height

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询指定交易日上榜龙虎榜且近一月内涨停次数最多的股票列表，返回涨停次数、连板天数等。适用于追踪市场短线龙头和连板股

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B5" | 接口ID |
| `tradeDate` | `str` | 是 | - | 交易日期 (格式为yyyy-MM-dd，可指定查询具体日期) |
| `sortField` | `int` | 否 | `0` | 排序字段  0-几天几板(默认)  1-净买入 |
| `sortDirec` | `int` | 否 | `1` | 排序方向  0-正序 1-降序(默认) |

### 返回参数

龙虎榜-市场高度榜数据列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `jumpUrl` | `str` | 否 | 跳转链接 |
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `pctChg` | `float` | 否 | 今日涨幅 |
| `buyMoneyClean` | `float` | 否 | 净买入额 |
| `tradeDay` | `str` | 否 | 交易日 |
| `hotMoneyNameDesc` | `str` | 否 | 知名游资(空格隔开) |
| `periodDays` | `int` | 否 | 连续N日标签 |
| `totalCount` | `int` | 否 | 统计总交易日数 |
| `limitUpCount` | `int` | 否 | 涨停交易日数量 |
| `hotMoneyList` | `list[str]` | 否 | 游资相关信息列表 |

**`hotMoneyList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `hotMoneyName` | `str` | 否 | 游资名称 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B5",
    tradeDate=None,  # str  # 默认: 
    sortField=None,  # int  # 默认: 0
    sortDirec=None,  # int  # 默认: 1
)
```


