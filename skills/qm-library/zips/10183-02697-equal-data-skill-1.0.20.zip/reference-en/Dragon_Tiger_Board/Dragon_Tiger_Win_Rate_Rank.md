# Dragon_Tiger_Win_Rate_Rank

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询近一月龙虎榜游资按胜率排序的排行榜，返回游资名称、操作次数、胜率、平均收益率、最大盈利等。适用于筛选近期高胜率游资席位

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B1" | 接口ID |
| `sortFlag` | `int` | 否 | `0` | 排序标记（0 降序（默认） 1-升序） |
| `listNum` | `int` | 否 | `10` | 榜单数量，默认10 |
| `isNew` | `int` | 否 | `0` | 是否仅看新上榜（1-是 0 否） |

### 返回参数

龙虎榜-游资胜率排行榜列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `infoId` | `str` | 否 | 游资infoId |
| `infoType` | `int` | 否 | 信息类型 |
| `hotMoney` | `str` | 是 | 游资名称 |
| `sort` | `int` | 否 | 排序序号 |
| `riseOdds` | `float` | 否 | 上涨概率 |
| `avgOdds` | `float` | 否 | 平均涨幅 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `traceMonth` | `int` | 否 | 跟踪月数 |
| `listNum` | `int` | 否 | 上榜次数 |
| `tradeDay` | `str` | 否 | 交易日期 |
| `tradeDayDesc` | `str` | 否 | 交易日描述（今日/昨日/具体日期） |
| `tradeRecordList` | `list[HotMoneyListSearchVo]` | 否 | 操作买入的股票信息列表 |

**`tradeRecordList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `hotMoneyName` | `str` | 否 | 游资名称 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `buyAmount` | `float` | 否 | 买入金额 |
| `sellAmount` | `float` | 否 | 卖出金额 |
| `buyAmountClean` | `float` | 否 | 净买入金额 |
| `pctChg` | `float` | 否 | 当日涨跌幅 |
| `periodDays` | `int` | 否 | 连续上榜标签 |
| `tradeDate` | `str` | 否 | 交易日期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B1",
    sortFlag=None,  # int  # 默认: 0
    listNum=None,  # int  # 默认: 10
    isNew=None,  # int  # 默认: 0
)
```


