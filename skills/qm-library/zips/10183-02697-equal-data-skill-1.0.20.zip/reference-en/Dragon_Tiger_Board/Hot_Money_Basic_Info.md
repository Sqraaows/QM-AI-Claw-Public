# Hot_Money_Basic_Info

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

● 查询游资的详情信息，包括简介、关联营业部、最近一个交易日的持仓操作记录。适用于了解游资背景1. 游资名称    支持模糊查询吗？ 用户说 别名，游资席位，简称怎么识别？

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "C4" | 接口ID |
| `hotMoneyName` | `str` | 是 | - | 游资名称 |

### 返回参数

游资详情数据，包含游资统计与相关营业部信息

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `hotMoneyName` | `str` | 是 | 游资名称 |
| `synopsis` | `str` | 否 | 游资简介 |
| `listNum` | `int` | 否 | 上榜次数 |
| `buyNum` | `int` | 否 | 买入次数 |
| `zdfAvg` | `float` | 否 | 平均涨幅 |
| `zdfAvgMax` | `float` | 否 | 平均最大涨幅 |
| `deptNameList` | `list[str]` | 否 | 相关营业部名称列表 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |

**`deptNameList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `deptName` | `str` | 否 | 营业部名称 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="C4",
    hotMoneyName=None,  # str  # 默认: 
)
```


