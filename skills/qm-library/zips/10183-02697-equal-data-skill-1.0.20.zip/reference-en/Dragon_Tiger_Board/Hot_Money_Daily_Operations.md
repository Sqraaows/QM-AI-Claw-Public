# Hot_Money_Daily_Operations

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询游资在指定交易日附近的近期操作明细，返回买入/卖出股票、成交金额等信息。适用于追踪游资短期动向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "C5" | 接口ID |
| `hotMoneyName` | `str` | 是 | - | 游资名称 |
| `tradeDate` | `str` | 否 | - | 交易日期(默认查询最新有龙虎榜数据的日期) |

### 返回参数

游资每日操作明细数据列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `hotMoneyName` | `str` | 是 | 游资名称 |
| `listNum` | `int` | 否 | 上榜次数 |
| `buyNum` | `int` | 否 | 买入个股数量 |
| `sellNum` | `int` | 否 | 卖出个股数量 |
| `buyAmountClean` | `float` | 否 | 净买入金额 |
| `children` | `list[HotMoneyOperateVo.DataVo]` | 否 | 近期操作个股明细列表 |

**`children`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `buyAmount` | `float` | 否 | 买入金额 |
| `sellAmount` | `float` | 否 | 卖出金额 |
| `buyAmountClean` | `float` | 否 | 净买入金额 |
| `pctChg` | `float` | 否 | 当日涨跌幅 |
| `periodDays` | `int` | 否 | 连续N个交易日 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="C5",
    hotMoneyName=None,  # str  # 默认: 
    tradeDate=None,  # str  # 默认: 
)
```


