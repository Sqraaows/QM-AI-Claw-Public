# Dragon_Tiger_Hot_Money_Rank

> Category: 龙虎榜 | Folder: `Dragon_Tiger_Board` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询指定交易日上榜龙虎榜的所有游资排行榜，返回游资名称、买入金额、卖出金额、净买入额及当天操作的股票信息。适用于分析游资当日活跃度和偏好

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "B3" | 接口ID |
| `tradeDate` | `str` | 是 | - | 交易日期(格式为yyyy-MM-dd，可指定查询具体日期) |

### 返回参数

龙虎榜-游资榜数据列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `hotMoneyName` | `str` | 是 | 游资名称 |
| `buyAmountClean` | `float` | 否 | 净买入额 |
| `children` | `list[HotMoneyListVo.DataVo]` | 否 | 游资操作个股明细 |
| `jumpUrl` | `str` | 否 | 跳转URL |

**`children`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 个股代码 |
| `stockName` | `str` | 否 | 个股名称 |
| `pctChg` | `float` | 否 | 个股涨跌幅 |
| `buyAmount` | `float` | 否 | 买入金额 |
| `sellAmount` | `float` | 否 | 卖出金额 |
| `buyAmountClean` | `float` | 否 | 净买入金额 |
| `buyAmountCleanNumber` | `float` | 否 | 净买入金额原始值 |
| `periodDays` | `int` | 否 | 连续N个交易日 |
| `hotMoneyList` | `list[str]` | 否 | 该股票其他游资操作列表 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="B3",
    tradeDate=None,  # str  # 默认: 
)
```


