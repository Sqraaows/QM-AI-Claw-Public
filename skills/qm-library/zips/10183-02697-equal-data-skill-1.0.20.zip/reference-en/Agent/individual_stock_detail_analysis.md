# 个股详情分析

## 1. 综合股票分析 API

### 1.1 描述

综合股票分析：获取指定股票的详细分析信息，包括实时行情、历史K线、财务指标、股东信息、新闻公告等综合分析结果。

### 1.2 版本要求

**重要提示**：使用此功能需要确保 equal_data 版本大于等于 0.0.12

版本检查：

```python
from equal_data import __version__
print(f"当前 equal_data 版本: {__version__}")
```

版本升级：

如果版本过低，请升级到最新版本：

```bash
pip install equal-data==0.0.12
```


### 1.3 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY')
# 调用接口
data = api.comprehensive_stock_analysis("000001", "平安银行")
```

### 1.4 参数说明

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `stock_code` | `str` | 是 | - | 股票代码，示例："000001" |
| `stock_name` | `str` | 是 | - | 股票名称，示例："平安银行" |

### 1.5 返回示例

```python
{
    'stock_code': '000001',
    'stock_name': '平安银行',
    'analysis_time': '2026-04-17 15:30',
    'realtime': {
        'price': 10.25,
        'change_pct': 0.29,
        'volume': '120000000',
        'market_cap': '200300000000'
    },
    'kline': [
        # K线数据...
    ],
    'finance': [
        # 财务数据...
    ],
    'shareholders': [
        # 股东数据...
    ],
    'holder_count_trend': [
        # 股东人数数据...
    ],
    'recent_news': [
        # 新闻...
    ],
    'announcements': [
        # 公告...
    ],
    'institution_holding': [

        # 股东股本及机构持仓...
    ],
    'basic_finance': [

        # 个股基本财务指标...
    ],
    'executive_transactions': [

        # 高管增减持变动数据...
    ]
}
```

### 1.6 返回参数说明

| 名称 | 类型 | 说明 |
|:---|:---|:---|
| `stock_code` | `str` | 股票代码 |
| `stock_name` | `str` | 股票名称 |
| `analysis_time` | `str` | 分析时间 |
| `realtime` | `dict` | 实时行情数据 |
| `kline` | `list` | 历史K线数据（近3个月） |
| `finance` | `list` | 财务指标数据（最近4个季度） |
| `shareholders` | `list` | 十大流通股东数据 |
| `holder_count_trend` | `list` | 股东人数变化趋势（近1年） |
| `recent_news` | `list` | 近期新闻（近1周，最多5条） |
| `announcements` | `list` | 近期公告（近1月，最多5条） |
| `institution_holding` | `list` | 股东股本及机构持仓 |
| `basic_finance` | `list` | 个股基本财务指标 |
| `executive_transactions` | `list` | 高管增减持变动数据 |


###  1.7 应用场景

- **个股研究**：快速获取股票的全面分析信息，辅助投资决策
- **投资组合管理**：对投资组合中的个股进行定期分析
- **市场监控**：监控特定股票的基本面和市场表现变化
- **行业对比**：与同行业其他股票进行对比分析
- **风险评估**：通过多维度数据评估股票投资风险
