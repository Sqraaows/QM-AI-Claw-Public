# 高管增减持详细分析

## 1. 高管增减持分析 API

### 1.1 描述

高管增减持分析：获取上市公司高管的增减持情况，包括近期增持金额、历史变动次数、未来计划数和持股分析等信息。

### 1.2 版本要求

**重要提示**：使用此功能需要确保 equal_data 版本大于等于 0.0.12

版本检查：

```python
from equal_data import __version__
print(f"当前 equal_data 版本: {__version__}")
```

版本升级：

如果版本过低，请升级到最新版本：

```bash
pip install equal-data==0.0.12
```

### 1.3 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY')
# 调用接口
data = api.executive_change_analysis()
```

### 1.4 参数说明

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `period` | `int` | 否 | `1` | 周期，默认近1月 |
| `change_type` | `int` | 否 | `1` | 变动类型，1为增持 |
| `page_index` | `int` | 否 | `0` | 页码 |
| `page_size` | `int` | 否 | `20` | 每页数量 |

### 1.5 返回示例

```python
[
    {
        'future_plan_count': 10, 
        'historical_change_count': 50, 
        'holding_analysis': {
            'circulateShares': '18.89亿', 
            'companyName': '恺英网络股份有限公司', 
            'esId': 973, 
            'historyNum': 25, 
            'kinshipNum': 0, 
            'oddsStrackDayNum': 4, 
            'scaleType': None, 
            'statisticDate': '2026-03-19', 
            'stockCode': '002517', 
            'stockName': '恺英网络', 
            'totalShares': '21.36亿', 
            'zdfAvg': 6.42, 
            'zdfAvgStrackDayNum': 18, 
            'zdfOdds': 68.0
        }, 
        'recent_increase_amount': '1.1亿', 
        'stock_code': '002517', 
        'stock_name': '恺英网络'
    }
]
```

### 1.6 返回参数说明

| 名称 | 类型 | 说明 |
|:---|:---|:---|
| `stock_code` | `str` | 股票代码 |
| `stock_name` | `str` | 股票名称 |
| `recent_increase_amount` | `str` | 近期增持金额 |
| `historical_change_count` | `int` | 历史变动次数 |
| `future_plan_count` | `int` | 未来计划数 |
| `holding_analysis` | `dict` | 持股分析详情 |

### 1.7 应用场景

- **投资决策参考**：通过分析高管增减持情况，了解公司内部人对公司未来发展的信心
- **市场趋势分析**：通过批量分析多个股票的高管增减持情况，发现市场整体趋势
- **风险预警**：及时发现高管大规模减持的情况，提前预警投资风险
- **价值投资**：结合高管增持情况，寻找被低估的优质股票