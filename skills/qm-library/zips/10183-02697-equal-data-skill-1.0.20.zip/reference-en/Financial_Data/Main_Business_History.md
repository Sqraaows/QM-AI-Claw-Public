# Main_Business_History

> Category: 财务数据 | Folder: `Financial_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询股票的主营业务历史数据，支持按报告期筛选（年报 / 中报），返回各主营业务的收入利润、毛利率等，用于分析公司业务结构与盈利变化

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "A2" | 接口ID |
| `stockCodes` | `str` | 是 | - | 可指定单个股票代码或多个股票代码，如果是多个股票代码，以逗号隔开 示例：'000001,<br>000002' |
| `reportDate` | `str` | 否 | - | 报告期,如 2025-12-31，默认为最新一期 |
| `filterType` | `int` | 否 | `1` | 筛选方式 1-按年报 2-按中报 示例：1 |

### 返回参数

ResultData.data 为 List，元素为主营业务分析历史数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `dateStr` | `str` | 否 | 报告期 |
| `list` | `list[EastStockBusinessAnalysisVo]` | 否 | 主营业务分析列表 |

**`list`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `reportTime` | `str` | 否 | 报告期 |
| `classType` | `str` | 否 | 分类类型 |
| `rank` | `int` | 否 | 排名 |
| `value` | `str` | 否 | 值 |
| `change` | `str` | 否 | 变化 |
| `changeRate` | `str` | 否 | 变化率 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="A2",
    stockCodes=None,  # str  # 默认: 
    reportDate=None,  # str  # 默认: 
    filterType=None,  # int  # 默认: 1
)
```


