# Major_Financial_Indicators

> Category: 财务数据 | Folder: `Financial_Data` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询股票的主要财务指标，支持指定多只股票和报告期，返回营业收入、净利润、扣非净利润、每股收益、净资产、现金流等35项核心财务数据。适用于基本面分析和财务对比

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "A1" | 接口ID |
| `stockCodes` | `str` | 是 | - | 可指定单个股票代码或多个股票代码，如果是多个股票代码，以逗号隔开 示例：'000001,<br>000002' |
| `startDate` | `str` | 否 | - | 开始日期 示例：2025-01-01 |
| `endDate` | `str` | 否 | - | 结束日期 示例：2025-12-31 |
| `reportType` | `int` | 否 | `1` | 1-合并报表（反映公司整体情况）； 2-单季度报表（反映公司单个季度情况） |

### 返回参数

ResultData.data 为 List，元素为主要财务指标

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `dateStr` | `str` | 否 | 报告期 |
| `publicDate` | `str` | 否 | 公告发布时间 |
| `eps` | `float` | 否 | 基本每股收益（元） |
| `epsYoy` | `float` | 否 | 每股收益同比 |
| `epsDeduct` | `float` | 否 | 扣非每股收益（元） |
| `epsDiluted` | `float` | 否 | 稀释每股收益（元） |
| `bps` | `float` | 否 | 每股净资产（元） |
| `bpsTb` | `float` | 否 | 每股净资产同比 |
| `epsCapital` | `float` | 否 | 每股资本公积（元） |
| `epsUnallocatedProfit` | `float` | 否 | 每股未分配利润（元） |
| `epsOperatingCashFlow` | `float` | 否 | 每股经营现金流（元） |
| `returnOnEquity` | `float` | 否 | 净资产收益率（加权） |
| `returnOnEquityDeduct` | `float` | 否 | 净资产收益率（扣非/加权） |
| `returnOnAssets` | `float` | 否 | 总资产收益率（加权） |
| `returnOnCapital` | `float` | 否 | 投入资本回报率 |
| `grossProfitMargin` | `float` | 否 | 毛利率 |
| `netProfitMargin` | `float` | 否 | 净利率 |
| `netCashFlowRatio` | `float` | 否 | 销售净现金流/营业收入 |
| `operatingCashFlowRatio` | `float` | 否 | 经营净现金流/营业收入 |
| `actualTaxRate` | `float` | 否 | 实际税率 |
| `currentRatio` | `float` | 否 | 流动比率 |
| `quickRatio` | `float` | 否 | 速动比率 |
| `cashFlowRatio` | `float` | 否 | 现金流量比率 |
| `debtRatio` | `float` | 否 | 资产负债率 |
| `debtRatioYoy` | `float` | 否 | 资产负债率同比 |
| `equityMultiplier` | `float` | 否 | 权益乘数 |
| `equityDebtRatio` | `float` | 否 | 产权比率 |
| `totalAssetsTurnoverDays` | `float` | 否 | 总资产周转天数 |
| `inventoryTurnoverDays` | `float` | 否 | 存货周转天数 |
| `receivablesTurnoverDays` | `float` | 否 | 应收账款周转天数 |
| `totalAssetsTurnover` | `float` | 否 | 总资产周转率 |
| `inventoryTurnover` | `float` | 否 | 存货周转率 |
| `receivablesTurnover` | `float` | 否 | 应收账款周转率 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="A1",
    stockCodes=None,  # str  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    reportType=None,  # int  # 默认: 1
)
```


