# Index_Basic_Info_List

> Category: 指数专题 | Folder: `Index_Topic` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

指数基本信息列表:询指数基本信息，返回指数代码、名称。适用于快速浏览市场主要指数代码与全称

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "I1" | 接口ID |
| `indexCodeArray` | `str` | 否 | - | 指数代码,多个用逗号隔开 示例:000001,000133 |
| `indexNameArray` | `str` | 否 | - | 指数名称,多个用逗号隔开-精确匹配, 示例:'上证指数','深证成指' |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，指数基本信息列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `indexCode` | `str` | 否 | 指数代码 |
| `indexFullName` | `str` | 否 | 指数全称 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="I1",
    indexCodeArray=None,  # str  # 默认: 
    indexNameArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


