# Index_Component_Weights

> Category: 指数专题 | Folder: `Index_Topic` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

指数成分和权重列表:查询指定指数的成分股及其权重列表，返回成分股代码、名称、权重占比、自由流通市值等。适用于了解指数构成和权重分布

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "I5" | 接口ID |
| `indexCodeArray` | `str` | 否 | - | 指数代码,多个用逗号隔开, 示例:000300,000133 |
| `componentCodeArray` | `str` | 否 | - | 成分代码,多个用逗号隔开,示例:600519,300033 |
| `stockName` | `str` | 否 | - | 股票代码名称-单查,模糊匹配,示例:同花顺,贵州茅台 |
| `tradeDateStart` | `str` | 否 | - | 交易日期开始 示例:2024-12-31 |
| `tradeDateEnd` | `str` | 否 | - | 交易日期结束 示例:2024-12-31 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，指数成分和权重列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `indexCode` | `str` | 否 | 指数代码 |
| `componentCode` | `str` | 否 | 成分代码 |
| `stockName` | `str` | 否 | 股票代码名称 |
| `tradeDate` | `str(datetime)` | 否 | 交易日期 |
| `weight` | `float` | 否 | 权重 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="I5",
    indexCodeArray=None,  # str  # 默认: 
    componentCodeArray=None,  # str  # 默认: 
    stockName=None,  # str  # 默认: 
    tradeDateStart=None,  # str  # 默认: 
    tradeDateEnd=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


