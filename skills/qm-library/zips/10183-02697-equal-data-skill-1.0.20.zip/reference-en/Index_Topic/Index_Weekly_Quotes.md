# Index_Weekly_Quotes

> Category: 指数专题 | Folder: `Index_Topic` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

指数周线行情列表:询指定指数的周线行情数据，返回每周开盘价、收盘价、最高价、最低价、成交量等。适用于指数中长期趋势分析

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "I3" | 接口ID |
| `indexCodeArray` | `str` | 否 | - | 指数代码,多个用逗号隔开 示例:000001,000133 |
| `indexNameArray` | `str` | 否 | - | 指数名称,多个有逗号隔开 示例:上证指数 |
| `startDate` | `str(datetime)` | 否 | - | 开始日期-不包含当天-开始时间和结束时间不能同时为空 示例:2024-01-01 |
| `endDate` | `str(datetime)` | 否 | - | 结束日期-不包含当天-开始时间和结束时间不能同时为空 示例:2024-07-01 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，指数周线行情列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `indexCode` | `str` | 否 | 指数代码 |
| `tradeDate` | `str(datetime)` | 否 | 交易日 |
| `indexName` | `str` | 否 | 指数名称 |
| `closePoint` | `float` | 否 | 收盘点位 |
| `openPoint` | `float` | 否 | 开盘点位 |
| `highPoint` | `float` | 否 | 最高点位 |
| `lowPoint` | `float` | 否 | 最低点位 |
| `prevClosePoint` | `float` | 否 | 昨日收盘点 |
| `changePoint` | `float` | 否 | 涨跌点位 |
| `changePercent` | `float` | 否 | 涨跌幅 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="I3",
    indexCodeArray=None,  # str  # 默认: 
    indexNameArray=None,  # str  # 默认: 
    startDate=None,  # str(datetime)  # 默认: 
    endDate=None,  # str(datetime)  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


