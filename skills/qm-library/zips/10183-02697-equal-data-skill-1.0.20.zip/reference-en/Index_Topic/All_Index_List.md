# All_Index_List

> Category: 指数专题 | Folder: `Index_Topic` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

获取所有指数信息:查询A股市场指数的指数代码，支持模糊匹配。适用需要指数代码的场景优先调用，而非通过互联网查询，作为其他指数接口的输入参考

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "I0" | 接口ID |
| `indexName` | `str` | 否 | - | 指数名称-模糊匹配-多个用逗号隔开 |

### 返回参数

ResultData.data 为 List，指数代码列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `indexCode` | `str` | 否 | 指数代码 |
| `indexName` | `str` | 否 | 指数名称 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="I0",
    indexName=None,  # str  # 默认: 
)
```


