# Valuation_Model_Screening

> Category: 指标选股 | Folder: `Indicator_Screening` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

基于多维度估值指标筛选股票，支持市盈率(PE)、市净率(PB)、市销率(PS)、股息率（DividedYield）、市现率（PCF）等核心估值指标的单条件或多条件组合筛选

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "S1" | 接口ID |
| `stockCodeArray` | `str` | 否 | - | 股票代码列表，多个用逗号隔开，此参数用于查询具体股票的一些信息，选股的话可以不传入。传入格式,<br>例如：600519,300033 |
| `startDate` | `str` | 否 | - | 开始日期，开始时间和结束时间如果都为空，会给已有数据时间的最大日期，格式：yyyy-MM-dd，<br>例如：2024-01-01 |
| `endDate` | `str` | 否 | - | 结束日期，开始时间和结束时间如果都为空，会给已有数据时间的最大日期，格式：yyyy-MM-dd，<br>例如：2024-12-31 |
| `closePriceStart` | `float` | 否 | - | 收盘价-结果区间是大于等于输入值 |
| `closePriceEnd` | `float` | 否 | - | 收盘价-结果区间是小于等于输入值 |
| `totalSharesStart` | `int` | 否 | - | 总股本-结果大于等于输入值 |
| `totalSharesEnd` | `int` | 否 | - | 总股本-结果小于等于输入值 |
| `totalMarketValueStart` | `float` | 否 | - | 总市值-结果大于等于输入值 |
| `totalMarketValueEnd` | `float` | 否 | - | 总市值-结果小于等于输入值 |
| `circulateMarketValueStart` | `float` | 否 | - | 流通市值-结果大于等于输入值 |
| `circulateMarketValueEnd` | `float` | 否 | - | 流通市值-结果小于于输入值 |
| `peTTMStart` | `float` | 否 | - | 市盈率TTM-结果大于等于输入值 |
| `peTTMEnd` | `float` | 否 | - | 市盈率TTM-结果小于等于输入值 |
| `pbTTMStart` | `float` | 否 | - | 市净率TTM-结果大于等于输入值 |
| `pbTTMEnd` | `float` | 否 | - | 市净率TTM-结果小于等于输入值 |
| `pcfTTMStart` | `float` | 否 | - | 市现率TTM-结果大于等于输入值 |
| `pcfTTMEnd` | `float` | 否 | - | 市现率TTM-结果小于等于输入值 |
| `psTTMStart` | `float` | 否 | - | 市销率TTM-结果大于等于输入值 |
| `psTTMEnd` | `float` | 否 | - | 市销率TTM-结果小于等于输入值 |
| `dividendYieldTTMStart` | `float` | 否 | - | 股息率TTM-结果大于等于输入值 |
| `dividendYieldTTMEnd` | `float` | 否 | - | 股息率TTM-结果小于等于输入值 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

Result.data 为 List数据-多维度数据

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `dateStr` | `str` | 否 | 日期 |
| `closePrice` | `float` | 否 | 收盘价（不复权） |
| `totalShares` | `int` | 否 | 总股本 |
| `listedAShares` | `int` | 否 | 流通上市A股 |
| `totalMarketValue` | `float` | 否 | 总市值 |
| `circulateMarketValue` | `float` | 否 | 流通市值 |
| `peTTM` | `float` | 否 | 市盈率TTM |
| `pbTTM` | `float` | 否 | 市净率TTM |
| `pcfTTM` | `float` | 否 | 市现率TTM |
| `psTTM` | `float` | 否 | 市销率TTM |
| `dividendYieldTTM` | `float` | 否 | 股息率TTM |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="S1",
    stockCodeArray=None,  # str  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    closePriceStart=None,  # float  # 默认: 
    closePriceEnd=None,  # float  # 默认: 
    totalSharesStart=None,  # int  # 默认: 
    totalSharesEnd=None,  # int  # 默认: 
    totalMarketValueStart=None,  # float  # 默认: 
    totalMarketValueEnd=None,  # float  # 默认: 
    circulateMarketValueStart=None,  # float  # 默认: 
    circulateMarketValueEnd=None,  # float  # 默认: 
    peTTMStart=None,  # float  # 默认: 
    peTTMEnd=None,  # float  # 默认: 
    pbTTMStart=None,  # float  # 默认: 
    pbTTMEnd=None,  # float  # 默认: 
    pcfTTMStart=None,  # float  # 默认: 
    pcfTTMEnd=None,  # float  # 默认: 
    psTTMStart=None,  # float  # 默认: 
    psTTMEnd=None,  # float  # 默认: 
    dividendYieldTTMStart=None,  # float  # 默认: 
    dividendYieldTTMEnd=None,  # float  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


