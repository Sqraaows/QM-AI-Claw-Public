# Shareholder_Count_Screening

> Category: 指标选股 | Folder: `Indicator_Screening` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

根据股东户数及其变动趋势筛选股票，反映筹码集中度变化。

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "S4" | 接口ID |
| `stockCodeArray` | `str` | 否 | - | 股票代码列表，多个用逗号隔开，此参数用于查询具体股票的一些信息，选股的话不传入。传入格式,<br>例如：600519,300033 |
| `startDate` | `str` | 否 | - | 开始日期，开始时间和结束时间如果都为空，会给已有数据时间的最大日期，<br>开始时间和结束时间每次入参不要超过3年,格式：yyyy-MM-dd，例如：2024-01-01 |
| `endDate` | `str` | 否 | - | 结束日期，开始时间和结束时间如果都为空，会给已有数据时间的最大日期，<br>开始时间和结束时间每次入参不要超过3年,格式：yyyy-MM-dd，例如：2024-12-31 |
| `holderTotalCount` | `str` | 否 | - | 股东总户数（户），固定季频，会穿插临时公告 |
| `holderCountGrowthRate` | `str` | 否 | - | 股东户数增长率（%） |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

Result.data 为 List数据-股东户数指标列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `dateStr` | `str` | 否 | 报告期，格式：yyyy-MM-dd |
| `holderTotalCount` | `int` | 否 | 股东总户数（户），固定季频，会穿插临时公告 |
| `holderCountGrowthRate` | `float` | 否 | 股东户数增长率（%） |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="S4",
    stockCodeArray=None,  # str  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    holderTotalCount=None,  # str  # 默认: 
    holderCountGrowthRate=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


