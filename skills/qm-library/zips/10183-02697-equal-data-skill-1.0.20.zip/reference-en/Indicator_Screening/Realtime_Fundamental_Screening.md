# Realtime_Fundamental_Screening

> Category: 指标选股 | Folder: `Indicator_Screening` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

根据财务指标和估值指标如pb、pe、ps、dividendYield以及总市值总股本等条件进行单指标或多指标综合进行选股。注：维护股票最新一期数据，不同股票最新的数据日期可能不一样，例如贵州茅台更新到2025年12月31日而平安银行已经更新到了2026年3月31日。

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "S12" | 接口ID |
| `listedCompanyIndicatorsSummaryParam` | `ListedCompanyIndicatorsSummaryParam` | 是 | - | 股票最新一期指标数据多维度选股 |
| `stockCodeArray` | `str` | 否 | - | 支持传入股票代码，如果是多个以逗号隔开，如 000001,000002 |
| `pbMin` | `str` | 否 | - | 市净率（PB）最小值 |
| `pbMax` | `str` | 否 | - | 市净率（PB）最大值 |
| `peMin` | `str` | 否 | - | 市盈率（PE）最小值 |
| `peMax` | `str` | 否 | - | 市盈率（PE）最大值 |
| `psMin` | `str` | 否 | - | 市销率（PS）最小值 |
| `psMax` | `str` | 否 | - | 市销率（PS）最大值 |
| `dividendYieldMin` | `str` | 否 | - | 股息率（Dividend Yield）最小值 |
| `dividendYieldMax` | `str` | 否 | - | 股息率（Dividend Yield）最大值 |
| `pcfMin` | `str` | 否 | - | 市现率（PCF）最小值 |
| `pcfMax` | `str` | 否 | - | 市现率（PCF）最大值 |
| `netProfitMin` | `str` | 否 | - | 归母净利润最小值 |
| `netProfitMax` | `str` | 否 | - | 归母净利润最大值 |
| `netProfitDeductMin` | `str` | 否 | - | 扣非净利润最小值 |
| `netProfitDeductMax` | `str` | 否 | - | 扣非净利润最大值 |
| `revenueMin` | `str` | 否 | - | 营业总收入最小值 |
| `revenueMax` | `str` | 否 | - | 营业总收入最大值 |
| `roeMin` | `str` | 否 | - | 净资产收益率（ROE）最小值 |
| `roeMax` | `str` | 否 | - | 净资产收益率（ROE）最大值 |
| `roicMin` | `str` | 否 | - | 投入资本回报率最小值 |
| `roicMax` | `str` | 否 | - | 投入资本回报率最大值 |
| `grossMarginMin` | `str` | 否 | - | 毛利率最小值 |
| `grossMarginMax` | `str` | 否 | - | 毛利率最大值 |
| `netProfitMarginMin` | `str` | 否 | - | 净利率最小值 |
| `netProfitMarginMax` | `str` | 否 | - | 净利率最大值 |
| `debtRatioMin` | `str` | 否 | - | 资产负债率最小值 |
| `debtRatioMax` | `str` | 否 | - | 资产负债率最大值 |
| `cashFlowRatioMin` | `str` | 否 | - | 现金流量比率最小值 |
| `cashFlowRatioMax` | `str` | 否 | - | 现金流量比率最大值 |
| `currentRatioMin` | `str` | 否 | - | 流动比率最小值 |
| `currentRatioMax` | `str` | 否 | - | 流动比率最大值 |
| `quickRatioMin` | `str` | 否 | - | 速动比率最小值 |
| `quickRatioMax` | `str` | 否 | - | 速动比率最大值 |
| `bpsMin` | `str` | 否 | - | 每股净资产最小值 |
| `bpsMax` | `str` | 否 | - | 每股净资产最大值 |
| `epsMin` | `str` | 否 | - | 每股收益最小值 |
| `epsMax` | `str` | 否 | - | 每股收益最大值 |
| `ocfpsMin` | `str` | 否 | - | 每股经营现金流最小值 |
| `ocfpsMax` | `str` | 否 | - | 每股经营现金流最大值 |
| `fcfpsMin` | `str` | 否 | - | 每股自由现金流最小值 |
| `fcfpsMax` | `str` | 否 | - | 每股自由现金流最大值 |
| `undistributedProfitPerShareMin` | `str` | 否 | - | 每股未分配利润最小值 |
| `undistributedProfitPerShareMax` | `str` | 否 | - | 每股未分配利润最大值 |
| `capitalReservePerShareMin` | `str` | 否 | - | 每股资本公积最小值 |
| `capitalReservePerShareMax` | `str` | 否 | - | 每股资本公积最大值 |
| `netProfitYoyMin` | `str` | 否 | - | 归母净利润同比最小值 |
| `netProfitYoyMax` | `str` | 否 | - | 归母净利润同比最大值 |
| `netProfitDeductYoyMin` | `str` | 否 | - | 扣非净利润同比最小值 |
| `netProfitDeductYoyMax` | `str` | 否 | - | 扣非净利润同比最大值 |
| `epsYoyMin` | `str` | 否 | - | 每股收益同比最小值 |
| `epsYoyMax` | `str` | 否 | - | 每股收益同比最大值 |
| `totalSharesMin` | `str` | 否 | - | 总股本最小值 |
| `totalSharesMax` | `str` | 否 | - | 总股本最大值 |
| `totalMarketValueMin` | `str` | 否 | - | 总市值最小值 |
| `totalMarketValueMax` | `str` | 否 | - | 总市值最大值 |
| `sortName` | `str` | 否 | - | 排序字段（如果有多个排序字段，以逗号隔开，字符串顺序决定排序优先级） <br>pb_ttm：市净率（TTM）； pe_ttm：市盈率（TTM）； ps：市销率； <br>dividend_yield：股息率； pcf：市现率； net_profit：归母净利润； <br>net_profit_deduct：扣非净利润； revenue：营业总收入； <br>roe：净资产收益率； roic：投入资本回报率； gross_margin：毛利率； <br>net_profit_margin：净利率； debt_ratio：资产负债率； <br>cash_flow_ratio：现金流量比率； current_ratio：流动比率； <br>quick_ratio：速动比率； eps：每股收益； bps：每股净资产； <br>ocfps：每股经营现金流； fcfps：每股自由现金流； <br>undistributed_profit_per_share：每股未分配利润； <br>capital_reserve_per_share：每股资本公积金； <br>net_profit_yoy：净利润增长率； <br>net_profit_deduct_yoy：扣非净利润增长率； eps_yoy：每股收益增长率； <br>total_shares：总股本； total_market_value：总市值； <br>circulate_shares：流通股本； <br>circulate_market_value：流通市值； <br>circulate_of_total_ratio：占总股本比； hold_num：股东户数； <br>hold_num_cycle_ratio：股东户数增长率； <br>ten_share_holder_ratio：十大流通股东持股比例合计； <br>ten_circulate_share_holder_ratio：十大流通股东持股合计； |
| `sortDirect` | `str` | 否 | - | 排序方向 ASC: 升序 DESC：降序（如果有多个排序字段，以逗号隔开，需要和排序字段一一对应，<br>字符串顺序决定排序方向优先级） |
| `pageNum` | `int` | 否 | `0` | 页码，从0开始，默认0 |
| `pageSize` | `int` | 否 | `10` | 每页条数，默认10 |

### 返回参数

ResultData.data 为 List，元素为 ListedCompanyIndicatorsSummaryVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 是 | 股票名称 |
| `pbTtm` | `float` | 是 | 市净率（TTM） |
| `peTtm` | `float` | 是 | 市盈率（TTM） |
| `ps` | `float` | 是 | 市销率 |
| `dividendYield` | `float` | 是 | 股息率 |
| `pcf` | `float` | 是 | 市现率 |
| `netProfit` | `float` | 是 | 归母净利润 |
| `netProfitDeduct` | `float` | 是 | 扣非净利润 |
| `revenue` | `float` | 是 | 营业总收入 |
| `roe` | `float` | 是 | 净资产收益率 |
| `roic` | `float` | 是 | 投入资本回报率 |
| `grossMargin` | `float` | 是 | 毛利率 |
| `netProfitMargin` | `float` | 是 | 净利率 |
| `debtRatio` | `float` | 是 | 资产负债率 |
| `cashFlowRatio` | `float` | 是 | 现金流量比率 |
| `currentRatio` | `float` | 是 | 流动比率 |
| `quickRatio` | `float` | 是 | 速动比率 |
| `bps` | `float` | 是 | 每股净资产 |
| `eps` | `float` | 是 | 每股收益 |
| `ocfps` | `float` | 是 | 每股经营现金流 |
| `fcfps` | `float` | 是 | 每股自由现金流 |
| `undistributedProfitPerShare` | `float` | 是 | 每股未分配利润 |
| `capitalReservePerShare` | `float` | 是 | 每股资本公积 |
| `netProfitYoy` | `float` | 是 | 归母净利润同比 |
| `netProfitDeductYoy` | `float` | 是 | 扣非净利润同比 |
| `epsYoy` | `float` | 是 | 每股收益同比 |
| `totalShares` | `float` | 是 | 总股本 |
| `totalMarketValue` | `float` | 是 | 总市值 |
| `circulateShares` | `float` | 是 | 流通股本 |
| `circulateMarketValue` | `float` | 是 | 流通市值 |
| `circulateOfTotalRatio` | `float` | 是 | 占总股本比 |
| `holdNum` | `float` | 是 | 股东户数 |
| `holdNumCycleRatio` | `float` | 是 | 股东户数增长率 |
| `tenShareHolderRatio` | `float` | 是 | 十大流通股东持股比例合计 |
| `tenCirculateShareHolderRatio` | `float` | 是 | 十大流通股东持股合计 |
| `institutionHoldNameArr` | `str` | 是 | 持仓的机构名称（机构类型分为：国家队、外资、牛散）；如果被多个机构持仓，以逗号分隔 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="S12",
    listedCompanyIndicatorsSummaryParam=None,  # ListedCompanyIndicatorsSummaryParam  # 默认: 
    stockCodeArray=None,  # str  # 默认: 
    pbMin=None,  # str  # 默认: 
    pbMax=None,  # str  # 默认: 
    peMin=None,  # str  # 默认: 
    peMax=None,  # str  # 默认: 
    psMin=None,  # str  # 默认: 
    psMax=None,  # str  # 默认: 
    dividendYieldMin=None,  # str  # 默认: 
    dividendYieldMax=None,  # str  # 默认: 
    pcfMin=None,  # str  # 默认: 
    pcfMax=None,  # str  # 默认: 
    netProfitMin=None,  # str  # 默认: 
    netProfitMax=None,  # str  # 默认: 
    netProfitDeductMin=None,  # str  # 默认: 
    netProfitDeductMax=None,  # str  # 默认: 
    revenueMin=None,  # str  # 默认: 
    revenueMax=None,  # str  # 默认: 
    roeMin=None,  # str  # 默认: 
    roeMax=None,  # str  # 默认: 
    roicMin=None,  # str  # 默认: 
    roicMax=None,  # str  # 默认: 
    grossMarginMin=None,  # str  # 默认: 
    grossMarginMax=None,  # str  # 默认: 
    netProfitMarginMin=None,  # str  # 默认: 
    netProfitMarginMax=None,  # str  # 默认: 
    debtRatioMin=None,  # str  # 默认: 
    debtRatioMax=None,  # str  # 默认: 
    cashFlowRatioMin=None,  # str  # 默认: 
    cashFlowRatioMax=None,  # str  # 默认: 
    currentRatioMin=None,  # str  # 默认: 
    currentRatioMax=None,  # str  # 默认: 
    quickRatioMin=None,  # str  # 默认: 
    quickRatioMax=None,  # str  # 默认: 
    bpsMin=None,  # str  # 默认: 
    bpsMax=None,  # str  # 默认: 
    epsMin=None,  # str  # 默认: 
    epsMax=None,  # str  # 默认: 
    ocfpsMin=None,  # str  # 默认: 
    ocfpsMax=None,  # str  # 默认: 
    fcfpsMin=None,  # str  # 默认: 
    fcfpsMax=None,  # str  # 默认: 
    undistributedProfitPerShareMin=None,  # str  # 默认: 
    undistributedProfitPerShareMax=None,  # str  # 默认: 
    capitalReservePerShareMin=None,  # str  # 默认: 
    capitalReservePerShareMax=None,  # str  # 默认: 
    netProfitYoyMin=None,  # str  # 默认: 
    netProfitYoyMax=None,  # str  # 默认: 
    netProfitDeductYoyMin=None,  # str  # 默认: 
    netProfitDeductYoyMax=None,  # str  # 默认: 
    epsYoyMin=None,  # str  # 默认: 
    epsYoyMax=None,  # str  # 默认: 
    totalSharesMin=None,  # str  # 默认: 
    totalSharesMax=None,  # str  # 默认: 
    totalMarketValueMin=None,  # str  # 默认: 
    totalMarketValueMax=None,  # str  # 默认: 
    sortName=None,  # str  # 默认: 
    sortDirect=None,  # str  # 默认: 
    pageNum=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


