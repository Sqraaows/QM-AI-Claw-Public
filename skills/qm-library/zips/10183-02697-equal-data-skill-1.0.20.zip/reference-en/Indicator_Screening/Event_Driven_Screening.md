# Event_Driven_Screening

> Category: 指标选股 | Folder: `Indicator_Screening` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

维护所有个股，基本面事件的最后发生时间，可以用来检测近期是否有基本面事件发生，包括事件类型：“事件类型: 业绩预增 / 暴雷,  限售解禁,  重大合同,  大宗交易,  机构调研,  高管增持 / 减持, 分红送转”

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "S3" | 接口ID |
| `stockCodeArray` | `str` | 否 | - | 股票代码,多个用逗号隔开 示例:600519,300033 |
| `stockNameArray` | `str` | 否 | - | 股票名称,多个用逗号隔开, 示例:：同花顺,贵州茅台 |
| `eventType` | `int` | 否 | - | 事件类型:1-业绩预增 / 暴雷, 2-限售解禁, 3-重大合同, 4-大宗交易, 5-机构调研, <br>6-高管增持 / 减持, 7-分红送转 |
| `eventStartTime` | `str(datetime)` | 否 | - | 事件发生开始时间:2023-01-01 |
| `eventEndTime` | `str(datetime)` | 否 | - | 事件发生结束时间:2024-01-01 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，事件驱动日频

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `eventType` | `int` | 否 | 事件类型:1-业绩预增 / 暴雷, 2-限售解禁, 3-重大合同, 4-大宗交易, 5-机构调研, <br>6-高管增持 / 减持, 7-分红送转 |
| `eventTime` | `str(datetime)` | 否 | 事件发生时间 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="S3",
    stockCodeArray=None,  # str  # 默认: 
    stockNameArray=None,  # str  # 默认: 
    eventType=None,  # int  # 默认: 
    eventStartTime=None,  # str(datetime)  # 默认: 
    eventEndTime=None,  # str(datetime)  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


