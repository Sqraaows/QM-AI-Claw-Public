# Price_Performance_Screening

> Category: 指标选股 | Folder: `Indicator_Screening` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

股价表现选股，支持按照实时股价选股以及历史股价表现选股，如股票涨跌幅、换手率、成交量等指标进行选股

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "S13" | 接口ID |
| `startDate` | `str` | 否 | - | 开始日期，格式：yyyy-MM-dd，例如：2024-01-01 |
| `endDate` | `str` | 否 | - | 结束日期，格式：yyyy-MM-dd，例如：2024-12-31，开始日期和结束日期如果都为空，<br>会给已有数据时间的最大日期 |
| `chgMin` | `str` | 否 | - | 股票涨跌幅最小值 |
| `chgMax` | `str` | 否 | - | 股票涨跌幅最大值 |
| `closePriceMin` | `str` | 否 | - | 收盘价最小值 |
| `closePriceMax` | `str` | 否 | - | 收盘价最大值 |
| `maxPriceMin` | `str` | 否 | - | 最高价最小值 |
| `maxPriceMax` | `str` | 否 | - | 最高价最大值 |
| `minPriceMin` | `str` | 否 | - | 最低价最小值 |
| `minPriceMax` | `str` | 否 | - | 最低价最大值 |
| `openPriceMin` | `str` | 否 | - | 开盘价最小值 |
| `openPriceMax` | `str` | 否 | - | 开盘价最大值 |
| `turnoverMin` | `str` | 否 | - | 股票换手率最小值 |
| `turnoverMax` | `str` | 否 | - | 股票换手率最大值 |
| `volumnMin` | `str` | 否 | - | 股票成交量最小值 |
| `volumnMax` | `str` | 否 | - | 股票成交量最大值 |
| `pageNum` | `int` | 否 | `0` | 页码，从0开始，默认0 |
| `pageSize` | `int` | 否 | `500` | 每页条数，默认500 |

### 返回参数

ResultData.data 为 List，元素为 StockQuoteDataVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `tradeDate` | `str` | 否 | 交易日 |
| `newPrice` | `float` | 否 | 最新价 |
| `maxPrice` | `float` | 否 | 最高价 |
| `minPrice` | `float` | 否 | 最低价 |
| `openPrice` | `float` | 否 | 开盘价 |
| `yesterdayClosePrice` | `float` | 否 | 昨收价 |
| `chg` | `float` | 否 | 涨跌幅 |
| `chgMoney` | `float` | 否 | 涨跌额 |
| `volume` | `int` | 否 | 成交量 |
| `tradeMoney` | `float` | 否 | 成交额 |
| `turnoverRate` | `float` | 否 | 换手率 |
| `quantityRelative` | `float` | 否 | 量比 |
| `marketValue` | `float` | 否 | 市值 |
| `circulateMarketValue` | `float` | 否 | 流通市值 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="S13",
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    chgMin=None,  # str  # 默认: 
    chgMax=None,  # str  # 默认: 
    closePriceMin=None,  # str  # 默认: 
    closePriceMax=None,  # str  # 默认: 
    maxPriceMin=None,  # str  # 默认: 
    maxPriceMax=None,  # str  # 默认: 
    minPriceMin=None,  # str  # 默认: 
    minPriceMax=None,  # str  # 默认: 
    openPriceMin=None,  # str  # 默认: 
    openPriceMax=None,  # str  # 默认: 
    turnoverMin=None,  # str  # 默认: 
    turnoverMax=None,  # str  # 默认: 
    volumnMin=None,  # str  # 默认: 
    volumnMax=None,  # str  # 默认: 
    pageNum=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 500
)
```


