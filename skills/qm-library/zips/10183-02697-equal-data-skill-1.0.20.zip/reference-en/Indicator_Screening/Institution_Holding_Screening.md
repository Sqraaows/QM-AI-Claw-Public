# Institution_Holding_Screening

> Category: 指标选股 | Folder: `Indicator_Screening` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述



### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "S6" | 接口ID |
| `stockCodeArray` | `str` | 否 | - | 根据机构持仓类型筛选股票，支持8000-国家队、1015-外资、3001-公募基金、<br>1003-私募基金/私募公司、1006-信托公司、1007-证券公司 1009-保险公司等机构类型，<br>返回被上述机构重仓或新进的股票列表 |
| `startDate` | `str` | 否 | - | 开始日期，开始时间和结束时间如果都为空，会给已有数据时间的最大日期，格式：yyyy-MM-dd，<br>例如：2024-01-01 |
| `endDate` | `str` | 否 | - | 结束日期，开始时间和结束时间如果都为空，会给已有数据时间的最大日期，格式：yyyy-MM-dd，<br>例如：2024-12-31 |
| `shareholderTypeCodeArray` | `str` | 否 | - | 支持单个或多个机构类型筛选，如果是多个，以逗号隔开；2007-牛散、8000-国家队、<br>1015-外资、3001-公募基金、1003-私募基金/私募公司、1006-信托公司、<br>1007-证券公司 1009-保险公司，示例2007,8000 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

Result.data 为 List数据-股东变动信息列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `shareholderName` | `str` | 否 | 股东名称 |
| `shareholderTypeCode` | `int` | 否 | 股东类型编码：8000-国家队，2007-牛散，1015-外资 |
| `shareholderTypeDesc` | `str` | 否 | 股东类型描述 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `dataDate` | `str` | 否 | 数据日期-产生数据的日期，格式：yyyy-MM-dd |
| `announcementDate` | `str` | 否 | 公告日期，格式：yyyy-MM-dd |
| `changeDirection` | `int` | 否 | 变动方向：1-新进，2-退出，3-增加，4-减少，5-不变 |
| `changeDirectionDesc` | `str` | 否 | 变动方向描述 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="S6",
    stockCodeArray=None,  # str  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    shareholderTypeCodeArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


