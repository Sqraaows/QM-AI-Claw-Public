# Financial_Indicator_Screening

> Category: 指标选股 | Folder: `Indicator_Screening` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

按照最新财务指标或者历史每一期的财务指标进行单指标或多指标选股

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "S11" | 接口ID |
| `financeIndexParam` | `FinanceIndexParam` | 是 | - | 财务指标参数 |
| `stockCodeArray` | `str` | 否 | - | 支持传入股票代码，如果是多个以逗号隔开，如 000001,000002 |
| `startDate` | `str` | 否 | - | 开始日期，yyyy-MM-dd格式，示例：2025-01-01 |
| `endDate` | `str` | 否 | - | 结束日期，yyyy-MM-dd格式，示例：2025-12-31 |
| `dateType` | `int` | 否 | - | 数据统计类型： 1-按年统计； 2-按季度统计；示例：近3年 或 2025年-2026年，则传入1，<br>表示按年统计；如今年最近两个季度或 2025年3季度，则传入 2，表示按季度统计 |
| `netProfitToParentMin` | `str` | 否 | - | 归母净利润（注意要和净利润区分开）最小值 |
| `netProfitToParentMax` | `str` | 否 | - | 归母净利润（注意要和净利润区分开）最大值 |
| `netProfitDeductMin` | `str` | 否 | - | 扣非净利润最小 |
| `netProfitDeductMax` | `str` | 否 | - | 扣非净利润最大 |
| `totalRevenueMin` | `str` | 否 | - | 营业总收入（营收）最小值 |
| `totalRevenueMax` | `str` | 否 | - | 营业总收入（营收）最大值 |
| `grossMarginMin` | `str` | 否 | - | 毛利率最小值 |
| `grossMarginMax` | `str` | 否 | - | 毛利率最大值 |
| `netMarginMin` | `str` | 否 | - | 净利率最小值 |
| `netMarginMax` | `str` | 否 | - | 净利率最大值 |
| `roeMin` | `str` | 否 | - | 净资产收益率（ROE）最小值  |
| `roeMax` | `str` | 否 | - | 净资产收益率（ROE）最大值 |
| `returnOnCapitalMin` | `str` | 否 | - | 投入资本回报率最小值 |
| `returnOnCapitalMax` | `str` | 否 | - | 投入资本回报率最大值 |
| `debtRatioMin` | `str` | 否 | - | 资产负债率最小值 |
| `debtRatioMax` | `str` | 否 | - | 资产负债率最大值 |
| `cashFlowRatioMin` | `str` | 否 | - | 现金流量比率最小值 |
| `cashFlowRatioMax` | `str` | 否 | - | 现金流量比率最大值 |
| `currentRatioMin` | `str` | 否 | - | 流动比率最小值 |
| `currentRatioMax` | `str` | 否 | - | 流动比率最大值 |
| `quickRatioMin` | `str` | 否 | - | 速动比率最小值 |
| `quickRatioMax` | `str` | 否 | - | 速动比率最大值 |
| `bpsMin` | `str` | 否 | - | 每股净资产最小值 |
| `bpsMax` | `str` | 否 | - | 每股净资产最大值 |
| `epsCapitalMin` | `str` | 否 | - | 每股资本公积最小值 |
| `epsCapitalMax` | `str` | 否 | - | 每股资本公积最大值 |
| `epsUnallocatedProfitMin` | `str` | 否 | - | 每股未分配利润最小值 |
| `epsUnallocatedProfitMax` | `str` | 否 | - | 每股未分配利润最大值 |
| `epsOperatingCashFlowMin` | `str` | 否 | - | 每股经营现金流最小值 |
| `epsOperatingCashFlowMax` | `str` | 否 | - | 每股经营现金流最大值 |
| `netProfitYoyMin` | `str` | 否 | - | 归母净利润同比最小值 |
| `netProfitYoyMax` | `str` | 否 | - | 归母净利润同比最大值 |
| `revenueYoyMin` | `str` | 否 | - | 营收同比最小值 |
| `revenueYoyMax` | `str` | 否 | - | 营收同比最大值 |
| `epsYoyMin` | `str` | 否 | - | 每股收益同比最小值 |
| `epsYoyMax` | `str` | 否 | - | 每股收益同比最大值 |
| `sortName` | `str` | 否 | - | 排序字段 gsjlr：归母净利润； kfjlr：扣非净利润； yyzsr：营业总收入； <br>kfjlr：营业利润；trzbhbl：投入资本回报率  mll：毛利率； jll：净利率； <br>roe：净资产收益率； trzbhbl：投入资本回报率； zcfzl：资产负债率； <br>xjllbl：现金流量比率； ldbl：流动比率； sdbl：速动比率； epsjb：每股收益； <br>bps：每股净资产； mgzbgj：每股资本公积； mgwfplr：每股未分配利润； <br>mgjyxjje：每股经营现金流" |
| `sortDirect` | `str` | 否 | - | 排序方向 ASC: 升序 DESC：降序 |
| `pageNum` | `int` | 否 | - | 页码，从0开始，默认0 |
| `pageSize` | `int` | 否 | - | 每页条数，默认10 |

### 返回参数

ResultData.data 为 List，元素为 ListedCompanyFinanceVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 是 | 股票代码 |
| `stockName` | `str` | 是 | 股票名称 |
| `reportDate` | `str` | 是 | 报告期 |
| `publicDate` | `str` | 是 | 公告发布时间 |
| `eps` | `float` | 是 | 基本每股收益（元） |
| `epsYoy` | `float` | 是 | 每股收益同比 |
| `epsDeduct` | `float` | 是 | 扣非每股收益（元） |
| `epsDiluted` | `float` | 是 | 稀释每股收益（元） |
| `bps` | `float` | 是 | 每股净资产（元） |
| `bpsTb` | `float` | 是 | 每股净资产同比 |
| `epsCapital` | `float` | 是 | 每股资本公积（元） |
| `epsUnallocatedProfit` | `float` | 是 | 每股未分配利润（元） |
| `epsOperatingCashFlow` | `float` | 是 | 每股经营现金流（元） |
| `totalRevenue` | `float` | 是 | 营业总收入（元） |
| `grossProfit` | `float` | 是 | 毛利润（元） |
| `netProfit` | `float` | 是 | 归属净利润（元） |
| `netProfitDeduct` | `float` | 是 | 扣非净利润（元） |
| `totalRevenueYoy` | `float` | 是 | 营业总收入同比增长 |
| `netProfitYoyGrowth` | `float` | 是 | 归属净利润同比增长 |
| `netProfitDeductYoyGrowth` | `float` | 是 | 扣非净利润同比增长 |
| `quarterRevenueYoyGrowth` | `float` | 是 | 单季度营业总收入同比 |
| `quarterNetProfitYoyGrowth` | `float` | 是 | 单季度归属净利润同比 |
| `quarterNetProfitDeductYoyGrowth` | `float` | 是 | 单季度扣非净利润同比 |
| `quarterRevenueYoy` | `float` | 是 | 单季度营业总收入环比 |
| `quarterNetProfitCircleRate` | `float` | 是 | 单季度归属净利润环比 |
| `quarterNetProfitDeductCircleRate` | `float` | 是 | 单季度扣非净利润环比 |
| `roeWeighted` | `float` | 是 | 净资产收益率（加权） |
| `roeWeightedDeduct` | `float` | 是 | 净资产收益率（扣非/加权） |
| `roaWeighted` | `float` | 是 | 总资产收益率（加权） |
| `roic` | `float` | 是 | 投入资本回报率 |
| `grossProfitMargin` | `float` | 是 | 毛利率 |
| `netProfitMargin` | `float` | 是 | 净利率 |
| `netCashFlowToRevenue` | `float` | 是 | 销售净现金流/营业收入 |
| `operatingCashFlowToRevenue` | `float` | 是 | 经营净现金流/营业收入 |
| `actualTaxRate` | `float` | 是 | 实际税率 |
| `currentRatio` | `float` | 是 | 流动比率 |
| `quickRatio` | `float` | 是 | 速动比率 |
| `cashFlowRatio` | `float` | 是 | 现金流量比率 |
| `debtToAssetRatio` | `float` | 是 | 资产负债率 |
| `debtToAssetRatioYoy` | `float` | 是 | 资产负债率同比 |
| `equityMultiplier` | `float` | 是 | 权益乘数 |
| `equityDebtRatio` | `float` | 是 | 产权比率 |
| `totalAssetsTurnoverDays` | `float` | 是 | 总资产周转天数 |
| `inventoryTurnoverDays` | `float` | 是 | 存货周转天数 |
| `receivablesTurnoverDays` | `float` | 是 | 应收账款周转天数 |
| `totalAssetsTurnover` | `float` | 是 | 总资产周转率 |
| `inventoryTurnover` | `float` | 是 | 存货周转率 |
| `receivablesTurnover` | `float` | 是 | 应收账款周转率 |
| `createTime` | `str(datetime)` | 是 | 创建时间 |
| `status` | `int` | 是 | 状态 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="S11",
    financeIndexParam=None,  # FinanceIndexParam  # 默认: 
    stockCodeArray=None,  # str  # 默认: 
    startDate=None,  # str  # 默认: 
    endDate=None,  # str  # 默认: 
    dateType=None,  # int  # 默认: 
    netProfitToParentMin=None,  # str  # 默认: 
    netProfitToParentMax=None,  # str  # 默认: 
    netProfitDeductMin=None,  # str  # 默认: 
    netProfitDeductMax=None,  # str  # 默认: 
    totalRevenueMin=None,  # str  # 默认: 
    totalRevenueMax=None,  # str  # 默认: 
    grossMarginMin=None,  # str  # 默认: 
    grossMarginMax=None,  # str  # 默认: 
    netMarginMin=None,  # str  # 默认: 
    netMarginMax=None,  # str  # 默认: 
    roeMin=None,  # str  # 默认: 
    roeMax=None,  # str  # 默认: 
    returnOnCapitalMin=None,  # str  # 默认: 
    returnOnCapitalMax=None,  # str  # 默认: 
    debtRatioMin=None,  # str  # 默认: 
    debtRatioMax=None,  # str  # 默认: 
    cashFlowRatioMin=None,  # str  # 默认: 
    cashFlowRatioMax=None,  # str  # 默认: 
    currentRatioMin=None,  # str  # 默认: 
    currentRatioMax=None,  # str  # 默认: 
    quickRatioMin=None,  # str  # 默认: 
    quickRatioMax=None,  # str  # 默认: 
    bpsMin=None,  # str  # 默认: 
    bpsMax=None,  # str  # 默认: 
    epsCapitalMin=None,  # str  # 默认: 
    epsCapitalMax=None,  # str  # 默认: 
    epsUnallocatedProfitMin=None,  # str  # 默认: 
    epsUnallocatedProfitMax=None,  # str  # 默认: 
    epsOperatingCashFlowMin=None,  # str  # 默认: 
    epsOperatingCashFlowMax=None,  # str  # 默认: 
    netProfitYoyMin=None,  # str  # 默认: 
    netProfitYoyMax=None,  # str  # 默认: 
    revenueYoyMin=None,  # str  # 默认: 
    revenueYoyMax=None,  # str  # 默认: 
    epsYoyMin=None,  # str  # 默认: 
    epsYoyMax=None,  # str  # 默认: 
    sortName=None,  # str  # 默认: 
    sortDirect=None,  # str  # 默认: 
    pageNum=None,  # int  # 默认: 
    pageSize=None,  # int  # 默认: 
)
```


