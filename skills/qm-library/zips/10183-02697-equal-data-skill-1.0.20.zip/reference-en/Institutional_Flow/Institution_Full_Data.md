# Institution_Full_Data

> Category: 机构动向 | Folder: `Institutional_Flow` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询公募、私募、外资、国家队、保险公司、信托公司、证券公司及知名投资机构的最新持股动向，支持按机构类型和变动类型（新进/退出/增持/减持）筛选。适用于全面监控机构资金流向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "J1" | 接口ID |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始，默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数，默认10 |
| `agencyType` | `int` | 否 | - | 机构类型 3001-公募 1003-私募 1006-信托公司 1007-证券公司 <br>1009-保险公司 1015-外资 8000-国家队 1201-知名机构，不传不限 |
| `changeDirect` | `int` | 否 | - | 持股变动类型 1-新进 2-退出 3-增持 4-减持，不传为全部 |

### 返回参数

ResultData.data 为 List，元素为 AgencyTrendListNewVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `agencyName` | `str` | 否 | 机构名称 |
| `showAgencyName` | `str` | 否 | 展示的机构名称 |
| `fundCompany` | `str` | 否 | 基金公司名称 |
| `companyShortName` | `str` | 否 | 机构所属公司简称 |
| `agencyOnlyId` | `str` | 否 | 机构唯一标识 |
| `agencyType` | `int` | 否 | 机构类型 |
| `changeDirect` | `int` | 否 | 持股变动类型 |
| `publicDate` | `str` | 否 | 公告日期 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `holderNum` | `int` | 否 | 现持股数 |
| `changeNum` | `int` | 否 | 变动股数 |
| `type` | `int` | 否 | 持股比例类型 |
| `ratio` | `float` | 否 | 持股比例 |
| `dataDate` | `str` | 否 | 数据日期 |
| `holderOnlyStr` | `str` | 否 | 股东唯一标识 |
| `typesArr` | `list` | 否 | 标签 |
| `agencyPublicDate` | `str` | 否 | 机构公告日期 |
| `marketValue` | `float` | 否 | 持股市值 |
| `isAdvantage` | `bool` | 否 | 是否亮点 |
| `holderCode` | `str` | 否 | 股东代码 |
| `holderName` | `str` | 否 | 原始股东名称 |
| `showHolderName` | `str` | 否 | 展示的股东名称 |
| `holderInfoId` | `str` | 否 | 股东infoId |
| `fundStockQuarter` | `str` | 否 | 基金持仓季度 |
| `fundPositionRatio` | `str` | 否 | 基金持仓比例（占净值比例） |
| `holderNumOld` | `int` | 否 | 原持股数 |
| `activeChangeNum` | `int` | 否 | 主动变动股数 |
| `bonusSharesTotal` | `int` | 否 | 分红股数 |
| `profitLossRatio` | `float` | 否 | 变动盈亏比例 |
| `rateRatio` | `float` | 否 | 预估收益率 |
| `cycleRatio` | `float` | 否 | 环比变动比例 |
| `cyclePriceAvg` | `float` | 否 | 全周期持仓均价（总持仓成本） |
| `priceAvg` | `float` | 否 | 单周期持仓均价(变动价格) |
| `newPrice` | `float` | 否 | 今日收盘价（最新价） |
| `reportDate` | `str` | 否 | 报告期 |
| `endTermPrice` | `float` | 否 | 期末价格 |
| `holdingCost` | `float` | 否 | 持仓成本 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="J1",
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
    agencyType=None,  # int  # 默认: 
    changeDirect=None,  # int  # 默认: 
)
```


