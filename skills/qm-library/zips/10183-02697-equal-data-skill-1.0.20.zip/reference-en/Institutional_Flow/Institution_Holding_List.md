# Institution_Holding_List

> Category: 机构动向 | Folder: `Institutional_Flow` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询某机构的历史持仓数据，支持按日期查询最新或历史持仓，返回持仓股票、持股数量、持股比例、增减持变动等。适用于分析机构持仓变化趋势

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "J2" | 接口ID |
| `agencyName` | `str` | 是 | - | 机构名称（支持精确匹配和模糊匹配,该字段为必传字段） |
| `dateStr` | `str` | 否 | - | 交易日期，不传默认最新一个交易日 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始，默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数，默认10 |

### 返回参数

ResultData.data 为 List，元素为 AgencyTrendIncomeToolVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `companyInfoId` | `str` | 否 | 公司infoid |
| `id` | `int` | 否 | 主键 |
| `holderName` | `str` | 否 | 股东名称 |
| `holderNameReduce` | `str` | 否 | 股东名称 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 公司名称 |
| `type` | `int` | 否 | 类型 0：十大股东 1：十大流通股东 |
| `holderType` | `int` | 否 | 类型 0：十大股东 1：十大流通股东 |
| `holderNum` | `float` | 否 | 持股数量 |
| `holderNumOld` | `float` | 否 | 上一期持股数量 |
| `ratio` | `float` | 否 | 比例 |
| `ratioOld` | `float` | 否 | 上一期比例 |
| `compareDataDate` | `str` | 否 | 数据日期 |
| `bonusSharesNum` | `float` | 否 | 分红送转股数（每10股分红股数） |
| `bonusSharesTotal` | `float` | 否 | 分红送转总股数 |
| `bonusMoney` | `float` | 否 | 分红派息（每10股派息金额） |
| `bonusMoneyTotal` | `float` | 否 | 分红收益 |
| `equityXdDate` | `str` | 否 | 除权除息日 |
| `activeChangeNum` | `float` | 否 | 主动持股变动 |
| `activeChangeMoney` | `float` | 否 | 主动变动金额 |
| `priceAvg` | `float` | 否 | 均价 |
| `endTermPrice` | `float` | 否 | 期末价格 |
| `marketValue` | `float` | 否 | 期末持股市值 |
| `changeDirect` | `int` | 否 | 变动方向 1-新进 2-退出 3-增加 4-减少 5-不变 |
| `isBeforeList` | `int` | 否 | 是否上市前就持有公司股票 0-否 1-是 |
| `esOnlyId` | `str` | 否 | esOnlyId |
| `infoId` | `str` | 否 | infoId |
| `dataDate` | `str` | 否 | 数据日期 |
| `publicDate` | `str` | 否 | 公告日期 |
| `dataType` | `int` | 否 | 是否本期 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="J2",
    agencyName=None,  # str  # 默认: 
    dateStr=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


