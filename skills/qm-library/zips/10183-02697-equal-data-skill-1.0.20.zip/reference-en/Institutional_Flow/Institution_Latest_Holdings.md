# Institution_Latest_Holdings

> Category: 机构动向 | Folder: `Institutional_Flow` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询具体机构的最新一期持股列表，返回持仓股票代码、名称、持股数量、持股市值、持股比例等详细信息。适用于跟踪单一机构的投资组合

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "J3" | 接口ID |
| `agencyName` | `str` | 是 | - | 机构名称（支持精确匹配和模糊匹配，为必传字段） |
| `holderName` | `str` | 否 | - | 分支机构-股东名称 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始，默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数，默认10 |

### 返回参数

ResultData.data 为 List，元素为 AgencyTrendCurrentListVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `marketValue` | `float` | 否 | 现市值 |
| `holderNum` | `int` | 否 | 现持股数 |
| `holderNumOld` | `int` | 否 | 原持股数 |
| `changeNum` | `int` | 否 | 主动变动股数 |
| `changeNumStr` | `str` | 否 | 变动股数（单位自适应） |
| `holderNumStr` | `str` | 否 | 现持股数（单位自适应） |
| `holdingCost` | `float` | 否 | 持股成本 |
| `endTermPrice` | `float` | 否 | 期末价格 |
| `priceAvg` | `float` | 否 | 均价 |
| `reportDate` | `str` | 否 | 变动期（自匹配 季度） |
| `rateRatio` | `float` | 否 | 预估收益率 |
| `isBeforeList` | `int` | 否 | 是否上市前就持有公司股票 0-否 1-是 |
| `holdingAvgPrice` | `float` | 否 | 持仓成本均价 |
| `publicDate` | `str` | 否 | 公告日期 |
| `changeDirect` | `int` | 否 | 持股变动类型 |
| `dataDate` | `str` | 否 | 数据日期 |
| `holderName` | `str` | 否 | 股东名称 |
| `agencyOnlyId` | `str` | 否 | 机构唯一标识 |
| `holderOnlyStr` | `str` | 否 | 股东唯一标识 |
| `agencyType` | `int` | 否 | 机构类型 |
| `type` | `int` | 否 | 持股比例类型 |
| `ratio` | `float` | 否 | 持股比例 |
| `holderCode` | `str` | 否 | 股东代码 |
| `showHolderName` | `str` | 否 | 展示的股东名称 |
| `holderInfoId` | `str` | 否 | 股东infoId |
| `fundStockQuarter` | `str` | 否 | 基金持仓季度 |
| `fundPositionRatio` | `str` | 否 | 基金持仓比例（占净值比例） |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="J3",
    agencyName=None,  # str  # 默认: 
    holderName=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


