# Shenwan_Industry_Daily

> Category: 行业与题材 | Folder: `Industry_and_Themes` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

行业指数日线行情列表:查询申万行业指数的日线行情数据，返回每日开盘点位、收盘点位、最高点位、最低点位、成交量等。适用于行业走势分析和轮动研究

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "I8" | 接口ID |
| `industryCodeArray` | `str` | 否 | - | 行业代码,多个用逗号隔开 示例:801010,801020 |
| `industryNameArray` | `str` | 否 | - | 行业名称,多个用逗号隔开 示例:美容护理,环保 |
| `startDate` | `str(datetime)` | 否 | - | 开始日期-不包含当天 示例:2024-01-01 |
| `endDate` | `str(datetime)` | 否 | - | 结束日期-不包含当天 示例:2024-07-01 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，申万行业日线行情

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `industryCode` | `str` | 否 | 行业代码 |
| `tradeDate` | `str(datetime)` | 否 | 交易日期 |
| `industryName` | `str` | 否 | 行业名称 |
| `openPoint` | `float` | 否 | 开盘点位 |
| `lowPoint` | `float` | 否 | 最低点位 |
| `highPoint` | `float` | 否 | 最高点位 |
| `closePoint` | `float` | 否 | 收盘点位 |
| `changePoint` | `float` | 否 | 涨跌点位 |
| `changePercent` | `float` | 否 | 涨跌幅 |
| `volume` | `float` | 否 | 成交量(万股) |
| `amount` | `float` | 否 | 成交额(万元) |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="I8",
    industryCodeArray=None,  # str  # 默认: 
    industryNameArray=None,  # str  # 默认: 
    startDate=None,  # str(datetime)  # 默认: 
    endDate=None,  # str(datetime)  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


