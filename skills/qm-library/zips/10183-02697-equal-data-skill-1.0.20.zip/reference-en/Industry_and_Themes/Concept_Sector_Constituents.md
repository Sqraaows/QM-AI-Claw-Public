# Concept_Sector_Constituents

> Category: 行业与题材 | Folder: `Industry_and_Themes` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询指定概念板块下的成分股列表，按涨幅从高到低排序，返回股票代码、名称、涨跌幅等。适用于分析概念炒作中的个股强弱

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "F6" | 接口ID |
| `tradeDate` | `str` | 否 | - | 交易日期，示例：2024-03-20 |
| `themeName` | `str` | 是 | - | 板块名称（来自概念板块列表） |
| `themeLevel` | `int` | 否 | - | 概念板块级别（1：一级板块, 2：二级板块, 3：三级板块, 默认） 示例：3 |
| `pageNum` | `int` | 否 | `0` | 分页偏移量，从 0 开始（第 1 页为 0，第 2 页为 pageSize） 示例：0 |
| `pageSize` | `int` | 否 | `10` | 每页条数 示例：10 |
| `sortDirection` | `int` | 否 | - | 排序方向,按照涨跌幅排序，支持定义排序方向（1：升序, 2：降序, 默认） |

### 返回参数

ResultData.data 为 List，元素为热门概念板块-股票列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `nameLevelOne` | `str` | 否 | 板块/概念名称 |
| `nameLevelTwo` | `str` | 否 | 所属板块/概念二级分类 |
| `nameLevelThree` | `str` | 否 | 所属板块/概念三级分类 |
| `industryChgPct` | `str` | 否 | 板块/概念涨跌幅(%) |
| `stockName` | `str` | 否 | 股票名称 |
| `stockCode` | `str` | 否 | 股票代码 |
| `latestChgPct` | `str` | 否 | 最新涨跌幅(%) |
| `themeIntroduction` | `str` | 否 | 概念板块简介 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="F6",
    tradeDate=None,  # str  # 默认: 
    themeName=None,  # str  # 默认: 
    themeLevel=None,  # int  # 默认: 
    pageNum=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
    sortDirection=None,  # int  # 默认: 
)
```


