# Shenwan_Industry_Constituents

> Category: 行业与题材 | Folder: `Industry_and_Themes` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

行业成分股列表:查询指定成分股票，返回股票所属一级、二级、三级行业。适用于分析行业维度数据

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "I7" | 接口ID |
| `componentCodeArray` | `str` | 否 | - | 成分股票代码,多个用逗号隔开 示例:002271,300715 |
| `componentNameArray` | `str` | 否 | - | 成分股票名称,多个用逗号隔开,模糊匹配 示例:东方雨虹,科顺股份 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，行业成分股列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `levelOneCode` | `str` | 否 | 一级行业代码 |
| `levelOneName` | `str` | 否 | 一级行业名称 |
| `levelTwoCode` | `str` | 否 | 二级行业代码 |
| `levelTwoName` | `str` | 否 | 二级行业名称 |
| `levelThreeCode` | `str` | 否 | 三级行业代码 |
| `levelThreeName` | `str` | 否 | 三级行业名称 |
| `componentCode` | `str` | 否 | 成分股票代码 |
| `componentName` | `str` | 否 | 成分股票名称 |
| `includeDate` | `str(datetime)` | 否 | 纳入日期 |
| `excludeDate` | `str(datetime)` | 否 | 剔除日期 |
| `isLatest` | `str` | 否 | 是否最新(Y是N否) |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="I7",
    componentCodeArray=None,  # str  # 默认: 
    componentNameArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


