# Shenwan_Industry_List

> Category: 行业与题材 | Folder: `Industry_and_Themes` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

行业指数信息列表:查询行业指数信息，返回数据包含行业层级、所属分类、指数发布状态等信息。适用于支撑板块归类、行业筛选、、行情板块展示等业务场景

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "I6" | 接口ID |
| `indexCodeArray` | `str` | 否 | - | 指数代码,多个用逗号隔开 示例:801010,801020 |
| `industryNameArray` | `str` | 否 | - | 行业名称,多个用逗号隔开,模糊匹配 示例:农林牧渔 |
| `industryCodeArray` | `str` | 否 | - | 行业代码,多个用逗号隔开: 110000,110001 |
| `pageIndex` | `int` | 是 | `0` | 当前页从0开始:不填系统默认0 |
| `pageSize` | `int` | 是 | `10` | 每页显示记录数,最大不能超过200,不填系统默认10 |

### 返回参数

ResultData.data 为 List，申万行业列表

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `indexCode` | `str` | 否 | 指数代码 |
| `industryName` | `str` | 否 | 行业名称 |
| `parentCode` | `str` | 否 | 父级代码 |
| `industryLevel` | `int` | 否 | 行业层级 |
| `industryCode` | `str` | 否 | 行业代码 |
| `hasIndex` | `int` | 否 | 是否发布了指数 1-已发 0-未发 |
| `levelType` | `str` | 否 | 行业等级类型 |
| `nameLevelOne` | `str` | 否 | 一级行业名称 |
| `nameLevelTwo` | `str` | 否 | 二级行业名称 |
| `nameLevelThree` | `str` | 否 | 三级行业名称 |
| `industryClassification` | `str` | 否 | 行业分类(SW申万) |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="I6",
    indexCodeArray=None,  # str  # 默认: 
    industryNameArray=None,  # str  # 默认: 
    industryCodeArray=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


