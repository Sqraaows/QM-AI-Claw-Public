# Top_Retail_Whales_Rank

> Category: 牛散追击 | Folder: `Retail_Whale_Tracking` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询A股百强牛散排行榜，按持仓市值或收益率排序，返回牛散名称、持仓市值、收益率等。适用于发现高净值个人投资者

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "L1" | 接口ID |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始，默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数，默认10 |

### 返回参数

ResultData.data 为 List，元素为 NiuSanSuperRankVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `rank` | `int` | 否 | 排名 |
| `holderName` | `str` | 否 | 股东名称 |
| `esOnlyId` | `str` | 否 | 牛散es_only_id |
| `currentMarketValue` | `float` | 否 | 本期持股市值 |
| `winRatio` | `float` | 否 | 持股胜率 |
| `estimateIncome` | `float` | 否 | 历史盈亏 |
| `uptDate` | `str` | 否 | 数据更新日期 |
| `infoId` | `str` | 否 | 牛散InfoId |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="L1",
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


