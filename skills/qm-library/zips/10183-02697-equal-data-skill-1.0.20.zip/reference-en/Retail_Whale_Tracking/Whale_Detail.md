# Whale_Detail

> Category: 牛散追击 | Folder: `Retail_Whale_Tracking` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

获取牛散的详细信息，包含当前持仓股票、持仓市值、历史操作统计（胜率、平均持股周期等）。适用于评估牛散的投资能力

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "L3" | 接口ID |
| `personName` | `str` | 是 | - | 牛散姓名 |

### 返回参数

ResultData.data 为 NiusanToolDetailVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `holderName` | `str` | 否 | 股东名称 |
| `sort` | `int` | 否 | 排行 |
| `synopsis` | `str` | 否 | 简介 |
| `stockCodeNameMap` | `dict[str, str]` | 否 | 股票代码和名称的映射 |
| `niusanRank` | `int` | 否 | 百强牛散排名 |
| `totalHoldingsHitoryMaxDate` | `str` | 否 | 历史最高持股总额日期 |
| `winRatio` | `float` | 否 | 历史胜率 |
| `winRatioOld` | `float` | 否 | 历史胜率上一期 |
| `cycleWinNum` | `int` | 否 | 盈利期数 |
| `cycleLossNum` | `int` | 否 | 亏损期数 |
| `cycleNumTotal` | `int` | 否 | 交易总期数 |
| `incrMoneySum` | `float` | 否 | 买入金额 |
| `reduceMoneySum` | `float` | 否 | 减持金额 |
| `bonusMoneyTotal` | `float` | 否 | 分红金额 |
| `currentMarketValue` | `float` | 否 | 本期持股市值 |
| `estimateIncome` | `float` | 否 | 预估盈亏 |
| `estimateIncomeRatio` | `float` | 否 | 预估收益率 |
| `totalHoldingsHitoryMax` | `float` | 否 | 历史最高持股总额 |
| `updateTime` | `str(datetime)` | 否 | 数据更新时间 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="L3",
    personName=None,  # str  # 默认: 
)
```


