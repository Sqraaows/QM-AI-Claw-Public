# Hot_Whale_Latest_Ops

> Category: 牛散追击 | Folder: `Retail_Whale_Tracking` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询近期活跃牛散的最新持仓和操作数据，返回牛散名称、操作股票、持股变动、持仓市值等。适用于跟踪热门牛散的最新动向

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "L4" | 接口ID |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始,默认0 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数,默认10 |
| `cycleNum` | `int` | 否 | `0` | 交易期数，查多少次以上的就填几，示例1，表示查询历史交易1次及以上，示例2，<br>表示查询历史交易2次及以上，默认为0，表示查询全部 |
| `sortName` | `str` | 否 | `currentMarketValue` | 排序字段名称，currentMarketValue： 本次持股市值 <br>estimateIncome:预估收益率 winRatio：操作胜率 <br>totalHoldingsHitoryMax：历史持仓最高市值  |
| `sortDirection` | `int` | 否 | - | 排序方向（-1倒序,1正序） |

### 返回参数

ResultData.data 为 List，元素为 NiusanToolListResponseVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `holderName` | `str` | 否 | 股东名称 |
| `winRatio` | `str` | 否 | 历史胜率 |
| `currentMarketValue` | `str` | 否 | 本期持股市值 |
| `totalHoldingsHitoryMax` | `str` | 否 | 历史最高持股总额 |
| `estimateIncome` | `str` | 否 | 历史盈亏 |
| `highlightsDesc` | `str` | 否 | 亮点描述 |
| `holdingList` | `list[HoldingVo]` | 否 | 持股记录 |

**`holdingList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `publicDate` | `str` | 否 | 公告日期 |
| `dataDate` | `str` | 否 | 数据日期 |
| `stockList` | `list[StockVo]` | 否 | 股票列表 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="L4",
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
    cycleNum=None,  # int  # 默认: 0
    sortName=None,  # str  # 默认: currentMarketValue
    sortDirection=None,  # int  # 默认: 
)
```


