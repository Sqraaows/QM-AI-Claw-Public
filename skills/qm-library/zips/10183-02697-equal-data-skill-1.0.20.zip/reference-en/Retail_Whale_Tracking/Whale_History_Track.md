# Whale_History_Track

> Category: 牛散追击 | Folder: `Retail_Whale_Tracking` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询牛散的历史交易记录和操作轨迹，返回买卖股票、交易日期、成交股数等。适用于研究牛散的选股偏好和操作风格

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "L2" | 接口ID |
| `personName` | `str` | 是 | - | 牛散姓名 |

### 返回参数

ResultData.data 为 List，元素为 NiusanHoldingTrackApiNewVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `changeDirect` | `int` | 否 | 持股变动方向 1-新进 2-退出 3-增加 4-减少 5-重仓 |
| `num` | `int` | 否 | 历史交易次数 |
| `trackDayNum` | `int` | 否 | 跟踪天数 |
| `riseRatio` | `float` | 否 | 上涨或下跌概率 |
| `zdfAvg` | `float` | 否 | 平均涨跌幅 |
| `riseNumTwenty` | `int` | 否 | 跟踪20天上涨个股数 |
| `riseNumForty` | `int` | 否 | 跟踪40天上涨个股数 |
| `riseNumSixty` | `int` | 否 | 跟踪60天上涨个股数 |
| `fallNumTwenty` | `int` | 否 | 跟踪20天下跌个股数 |
| `fallNumForty` | `int` | 否 | 跟踪40天下跌个股数 |
| `fallNumSixty` | `int` | 否 | 跟踪60天下跌个股数 |
| `zdfAvgTwenty` | `float` | 否 | 跟踪20天平均涨跌幅 |
| `zdfAvgForty` | `float` | 否 | 跟踪40天平均涨跌幅 |
| `zdfAvgSixty` | `float` | 否 | 跟踪60天平均涨跌幅 |
| `riseRatioTwenty` | `float` | 否 | 跟踪20天上涨下跌概率 |
| `riseRatioForty` | `float` | 否 | 跟踪40天上涨下跌概率 |
| `riseRatioSixty` | `float` | 否 | 跟踪60天上涨下跌概率 |
| `updateTime` | `str(datetime)` | 否 | 更新时间 |
| `stockList` | `list[stockInfo]` | 否 | 股票列表 |
| `trackDataList` | `list` | 否 | 跟踪数据列表 |

**`stockList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `publicDate` | `str` | 否 | 最新公告日期 |
| `dataDate` | `str` | 否 | 交易日期 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |

**`trackDataList`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `riseNum` | `int` | 否 | 上涨个股数 |
| `fallNum` | `int` | 否 | 下跌个股数 |
| `riseRatio` | `float` | 否 | 上涨下跌概率 |
| `zdfAvg` | `float` | 否 | 平均涨跌幅 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="L2",
    personName=None,  # str  # 默认: 
)
```


