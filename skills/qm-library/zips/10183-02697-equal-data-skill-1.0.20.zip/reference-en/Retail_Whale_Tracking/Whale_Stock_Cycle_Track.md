# Whale_Stock_Cycle_Track

> Category: 牛散追击 | Folder: `Retail_Whale_Tracking` | Index: `SKILL_EN.md`

<!-- generated_at: 2026-05-08T17:36:14.630-1778232974639 -->


### 描述

查询牛散对某只个股的完整操作周期轨迹，包含建仓、持有、加仓、减仓、清仓的时间节点和价格。适用于复盘牛散在特定股票上的操作节奏

### 请求参数

| 名称 | 类型 | 必填 | 默认值 | 说明 |
|:---|:---|:---|:---|:---|
| `interfaceId` | `str` | 是 | "L5" | 接口ID |
| `personName` | `str` | 是 | - | 牛散名称 |
| `stockCode` | `str` | 是 | - | 股票代码 |
| `pageIndex` | `int` | 否 | `0` | 当前页从0开始 |
| `pageSize` | `int` | 否 | `10` | 每页显示记录数 |

### 返回参数

ResultData.data 为 List，元素为 ListedCompanyShareholderIncomeCycleToolDetailVo

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `holderName` | `str` | 否 | 股东名称 |
| `inDate` | `str` | 否 | 新进日期 |
| `lastDate` | `str` | 否 | 当前数据日期 |
| `holdingMonthNum` | `int` | 否 | 持有月数 |
| `outDate` | `str` | 否 | 退出日期 |
| `isExit` | `int` | 否 | 是否退出 |
| `incrMoneySum` | `float` | 否 | 买入金额 |
| `reduceMoneySum` | `float` | 否 | 减持金额 |
| `bonusMoneyTotal` | `float` | 否 | 分红金额 |
| `currentMarketValue` | `float` | 否 | 本期持股市值 |
| `estimateIncome` | `float` | 否 | 预估盈亏 |
| `estimateIncomeRatio` | `float` | 否 | 预估收益率 |
| `cycleEndHolderNum` | `float` | 否 | 期末股数 |
| `holdingAvgPrice` | `float` | 否 | 平均持仓成本 |
| `incomeItems` | `list[ListedCompanyShareholderIncomeToolVo]` | 否 | 操作详情列表 |

**`incomeItems`** 数组元素结构：

| 名称 | 类型 | 是否必返回 | 说明 |
|:---|:---|:---|:---|
| `publicDate` | `str` | 否 | 公告日期 |
| `dataDate` | `str` | 否 | 数据日期 |
| `stockCode` | `str` | 否 | 股票代码 |
| `stockName` | `str` | 否 | 股票名称 |
| `changeDirect` | `int` | 否 | 持股变动方向 |
| `marketValue` | `str` | 否 | 持股市值 |
| `activeChangeNum` | `str` | 否 | 主动持股变动 |
| `activeChangeMoney` | `str` | 否 | 主动变动金额 |
| `priceAvg` | `float` | 否 | 均价 |
| `endTermPrice` | `float` | 否 | 期末价格 |
| `marketValue` | `str` | 否 | 期末持股市值 |
| `changeDirect` | `int` | 否 | 变动方向 |
| `isBeforeList` | `int` | 否 | 是否上市前就持有公司股票 |
| `infoId` | `str` | 否 | infoId |
| `dataDate` | `str` | 否 | 数据日期 |
| `publicDate` | `str` | 否 | 公告日期 |
| `dataType` | `int` | 否 | 是否本期 |
| `isIssue` | `int` | 否 | 是否本期 |
| `isExitCycle` | `int` | 否 | 是否还在操作周期内 |
| `createTime` | `str(datetime)` | 否 | 创建时间 |
| `updateTime` | `str(datetime)` | 否 | 更新时间 |
| `companyInfoId` | `str` | 否 | 公司infoid |
| `cycleId` | `int` | 否 | 操作周期id |
| `holdingRatio` | `float` | 否 | 持仓比例 |
| `isHighFloatIncome` | `int` | 否 | 高浮盈 |
| `isLowFloatIncome` | `int` | 否 | 高浮亏 |
| `isBigHold` | `int` | 否 | 重仓 |
| `currentMarketValue` | `float` | 否 | 本期持股市值 |
| `estimateIncome` | `float` | 否 | 预估盈亏 |
| `estimateIncomeRatio` | `float` | 否 | 预估收益率 |

### 调用示例

```python
from equal_data import EqualDataApi  
api = EqualDataApi('your API_KEY') 
# 调用接口
data = api.query_equal_data(
    interfaceId="L5",
    personName=None,  # str  # 默认: 
    stockCode=None,  # str  # 默认: 
    pageIndex=None,  # int  # 默认: 0
    pageSize=None,  # int  # 默认: 10
)
```


