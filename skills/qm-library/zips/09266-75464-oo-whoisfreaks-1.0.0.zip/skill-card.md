## Description: <br>
WhoisFreaks helps agents retrieve WHOIS, ASN, IP, domain availability, and subdomain data through an OOMOL-connected WhoisFreaks account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, security analysts, and operations teams use this skill to inspect live WhoisFreaks schemas and run credentialed WHOIS, domain availability, ASN, IP, and subdomain lookups from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected WhoisFreaks account and sensitive credential access through OOMOL. <br>
Mitigation: Install and use it only when the user has authority to access the WhoisFreaks account; rely on OOMOL credential injection rather than requesting raw API tokens. <br>
Risk: Live WhoisFreaks actions may return sensitive domain, IP, ASN, or subdomain intelligence and can consume account credits. <br>
Mitigation: Fetch the action schema before each run, send only the user-requested payload, and avoid retrying billing or connection failures without user direction. <br>


## Reference(s): <br>
- [WhoisFreaks homepage](https://whoisfreaks.com) <br>
- [WhoisFreaks ClawHub skill page](https://clawhub.ai/oomol/oo-whoisfreaks) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown instructions with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing payloads; command responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
