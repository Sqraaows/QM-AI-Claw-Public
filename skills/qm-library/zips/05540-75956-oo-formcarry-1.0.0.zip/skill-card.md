## Description: <br>
Formcarry helps an agent manage Formcarry forms and submissions through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to create and delete Formcarry forms and list form submissions from an OOMOL-connected Formcarry account. It is suited for agents that need to operate Formcarry without constructing direct API calls. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can delete Formcarry forms or otherwise change Formcarry state. <br>
Mitigation: Confirm the exact payload, target form ID, and intended effect with the user before running create, update, or delete actions. <br>
Risk: Listed form submissions can contain sensitive data. <br>
Mitigation: Treat returned submissions as sensitive and share, store, or transform them only as needed for the user's request. <br>
Risk: First-time setup may require installing the oo CLI from an external installer. <br>
Mitigation: Review OOMOL's installer before running the curl or PowerShell install command. <br>


## Reference(s): <br>
- [Formcarry homepage](https://formcarry.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-formcarry) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands fetch the live connector schema before execution and return JSON responses from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and SKILL.md metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
