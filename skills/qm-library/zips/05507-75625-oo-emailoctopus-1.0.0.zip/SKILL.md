---
name: oo-emailoctopus
description: "EmailOctopus (emailoctopus.com). Use this skill for ANY EmailOctopus request — reading, creating, updating, and deleting data. Whenever a task involves EmailOctopus, use this skill instead of calling the API directly."
allowed-tools: [Bash(oo *)]
metadata:
  title: "EmailOctopus"
  author: "OOMOL"
  version: "1.0.0"
  service: "emailoctopus"
  categories: "Communication, Marketing"
  homepage: "https://emailoctopus.com"
  icon: "https://static.oomol.com/logo/third-party/EmailOctopus.svg"
---

# EmailOctopus

Operate **EmailOctopus** through your OOMOL-connected account. This skill calls the `emailoctopus` connector with the [oo CLI](https://github.com/oomol-lab/oo-cli); OOMOL injects credentials server-side, so you never handle raw tokens.

Category: Communication, Marketing. Exposes 9 action(s).

## Running an action

Assume the user has already installed the oo CLI, signed in, and connected EmailOctopus. **Do not run `oo auth login` or open the connection URL proactively — just run the action.** Fall back to [First-time setup](#first-time-setup) only when a command actually fails with an auth or connection error.

**1. Inspect the contract** to get the authoritative input/output schema before building a payload:

```bash
oo connector schema "emailoctopus" --action "<action_name>"
```

**2. Run the action** with a JSON payload that matches the input schema:

```bash
oo connector run "emailoctopus" --action "<action_name>" --data '<json>' --json
```

- `--data` takes a JSON object string or `@path/to/file.json`; omit it to send `{}`.
- The response is `{ "data": ..., "meta": { "executionId": "..." } }`; the execution id lives under `meta.executionId`.

Each action below links to a reference file with its purpose and exact commands. Read the linked file, then fetch the live schema with `oo connector schema` before constructing `--data`.

## Available actions

- [`create_list_contact`](actions/create_list_contact.md) — Create a contact in an EmailOctopus mailing list.
- [`delete_list_contact`](actions/delete_list_contact.md) — Delete a contact from an EmailOctopus mailing list.
- [`get_campaign`](actions/get_campaign.md) — Fetch a single EmailOctopus campaign by ID.
- [`get_list`](actions/get_list.md) — Fetch a single EmailOctopus mailing list by ID.
- [`get_list_contact`](actions/get_list_contact.md) — Fetch a single contact from an EmailOctopus mailing list.
- [`list_campaigns`](actions/list_campaigns.md) — List EmailOctopus campaigns available to the current API key.
- [`list_list_contacts`](actions/list_list_contacts.md) — List contacts in a specific EmailOctopus mailing list.
- [`list_lists`](actions/list_lists.md) — List EmailOctopus mailing lists available to the current API key.
- [`update_list_contact`](actions/update_list_contact.md) — Update a contact in an EmailOctopus mailing list.

## Safety

- Read actions (get / list / search) are safe to run directly.
- **Create, update, send, or post actions change EmailOctopus state — confirm the exact payload and effect with the user before running.**
- **Delete or remove actions are destructive — always confirm the target and get explicit approval first.**

## First-time setup

These are **one-time** steps — do not repeat them on every call. Run a step only when a command fails for the matching reason.

- **`oo: command not found`** — install the oo CLI (other platforms: <https://cli.oomol.com/install-guide.md>):

  ```bash
  curl -fsSL https://cli.oomol.com/install.sh | bash    # macOS / Linux
  ```

  ```powershell
  irm https://cli.oomol.com/install.ps1 | iex           # Windows PowerShell
  ```

- **Not signed in / authentication error** — sign in to your OOMOL account once:

  ```bash
  oo auth login
  ```

- **`scope_missing` / `credential_expired` / `app_not_ready` / `app_not_found`** — EmailOctopus is not connected, or the connection expired or lacks a scope. Connect once (auth type: API key) at:

  ```text
  https://console.oomol.com/app-connections?provider=emailoctopus
  ```

- **HTTP 402 / `OOMOL_INSUFFICIENT_CREDIT`** — billing stop. Recharge at `https://console.oomol.com/billing/token-recharge` before retrying.

## Resources

- EmailOctopus homepage: https://emailoctopus.com
