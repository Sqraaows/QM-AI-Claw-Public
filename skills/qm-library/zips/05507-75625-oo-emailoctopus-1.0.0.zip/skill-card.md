## Description: <br>
EmailOctopus (emailoctopus.com). Use this skill for EmailOctopus requests that read, create, update, or delete campaigns, mailing lists, and contacts through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate EmailOctopus from an agent workflow through the oo CLI. It supports listing and fetching campaigns, mailing lists, and contacts, plus creating, updating, and deleting list contacts after schema inspection and user confirmation for state-changing actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected EmailOctopus account and can act on sensitive marketing data through delegated credentials. <br>
Mitigation: Use an account with the minimum needed EmailOctopus access, review requested permissions during setup, and avoid exposing raw credentials in prompts or files. <br>
Risk: Create, update, and delete actions can change or remove EmailOctopus contacts. <br>
Mitigation: Inspect the live action schema, confirm the exact payload and target with the user, and require explicit approval before state-changing or destructive commands. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-emailoctopus) <br>
- [EmailOctopus homepage](https://emailoctopus.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands should inspect the live connector schema before constructing payloads; write and destructive actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
