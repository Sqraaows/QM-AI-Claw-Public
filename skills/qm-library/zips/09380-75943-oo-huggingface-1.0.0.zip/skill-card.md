## Description: <br>
Operate Hugging Face through an OOMOL-connected account for model, dataset, Space, endpoint, repository, account, embedding, and chat-completion workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to discover Hugging Face models, datasets, Spaces, repository files, and inference endpoints, then run Hugging Face inference actions through an OOMOL-connected account. It is suited for search, metadata lookup, dataset inspection, embeddings, and chat-completion tasks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Inference prompts, embedding inputs, dataset queries, and account lookups may pass through the OOMOL connector to Hugging Face. <br>
Mitigation: Install only when OOMOL is trusted as the intermediary, review requested Hugging Face scopes during connection, and avoid sending sensitive content unless that routing is acceptable. <br>
Risk: Connector schemas and upstream Hugging Face defaults can change over time. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>
Risk: Some actions require account, repository, or inference scopes. <br>
Mitigation: Review Hugging Face scopes during setup and run only actions whose requested access matches the intended task. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-huggingface) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Hugging Face homepage](https://huggingface.co) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Hugging Face connector setup](https://console.oomol.com/app-connections?provider=huggingface) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions inspect live connector schemas before execution; responses include data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
