## Description: <br>
Operates Cloudflare R2 through an OOMOL-connected account for reading, creating, updating, and deleting bucket resources. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Cloudflare R2 buckets and bucket CORS policies through the oo CLI with OOMOL-connected credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Automated security evidence is a low-confidence clean result. <br>
Mitigation: Review the displayed actions, requested credentials, and install commands before installing or running the skill. <br>
Risk: Create, update, and delete actions can change or remove Cloudflare R2 bucket state. <br>
Mitigation: Confirm the exact action, target bucket, payload, and intended effect with the user before running write or destructive commands. <br>
Risk: Connector schemas can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing or submitting any payload. <br>


## Reference(s): <br>
- [Cloudflare R2 homepage](https://www.cloudflare.com) <br>
- [ClawHub listing](https://clawhub.ai/oomol/oo-cloudflare-r2) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce JSON responses from oo connector commands when actions are executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
