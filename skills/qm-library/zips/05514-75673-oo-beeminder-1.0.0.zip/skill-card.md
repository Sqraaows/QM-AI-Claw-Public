## Description: <br>
Operates Beeminder through OOMOL's oo CLI so an agent can read user and goal data and create, update, list, or delete goal datapoints. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent operate a connected Beeminder account through OOMOL, including reading goals and managing goal datapoints after schema inspection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates a connected Beeminder account through OOMOL credentials. <br>
Mitigation: Install only when agent access to the Beeminder account is intended, and avoid exposing raw account credentials in prompts or logs. <br>
Risk: Create and update actions can change Beeminder datapoints. <br>
Mitigation: Inspect the live connector schema and confirm the exact target goal and payload before running write actions. <br>
Risk: Delete actions can remove Beeminder datapoints. <br>
Mitigation: Confirm the datapoint ID and get explicit user approval before running destructive actions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-beeminder) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [Beeminder homepage](https://www.beeminder.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an OOMOL-connected Beeminder account; write and delete actions should be confirmed before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
