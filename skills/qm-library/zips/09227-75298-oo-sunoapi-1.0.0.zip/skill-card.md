## Description: <br>
SunoAPI helps agents run SunoAPI music generation, lyrics, audio transformation, task lookup, and account credit actions through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External developers and agent users use this skill to inspect SunoAPI action schemas, submit music or audio generation and transformation tasks, retrieve asynchronous task results, and check account credits. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Create, upload, and transformation actions can send prompts or audio to SunoAPI and may consume account credits. <br>
Mitigation: Review the action schema, exact payload, and intended effect with the user before approving state-changing or upload actions. <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected SunoAPI account. <br>
Mitigation: Use the server-managed connection flow and avoid handling raw SunoAPI credentials in prompts, files, or shell history. <br>
Risk: The documented first-time setup can install OOMOL's oo CLI from a remote script. <br>
Mitigation: Install the CLI only when needed and only after trusting the OOMOL CLI source. <br>


## Reference(s): <br>
- [SunoAPI homepage](https://sunoapi.org) <br>
- [SunoAPI ClawHub listing](https://clawhub.ai/oomol/oo-sunoapi) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
