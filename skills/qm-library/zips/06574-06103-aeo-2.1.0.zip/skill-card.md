## Description: <br>
Run AEO audits, fix site issues, validate schema, generate llms.txt, and compare sites. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[arberx](https://clawhub.ai/user/arberx) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, site owners, and SEO/AEO practitioners use this skill to audit websites or static build output, prioritize answer-engine optimization fixes, validate schema, generate AI-readable content files, and compare sites over time. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill runs the @ainyc/aeo-audit npm package against websites or local static build output, and optional PageSpeed credentials may be exposed to that package. <br>
Mitigation: Use the optional PageSpeed API key only when the package is trusted with that credential, and run audits only against targets the user is authorized to inspect. <br>
Risk: The skill can write llms.txt, llms-full.txt, or robots.txt, which can affect how agents and crawlers consume a site. <br>
Mitigation: Review generated or modified files before publishing them and confirm they match the site's intended crawler and AI-readable content policy. <br>
Risk: Shell command construction can become unsafe if raw user input is passed directly into audit commands. <br>
Mitigation: Validate URL or filesystem-path inputs, reject shell metacharacters, quote each argument, and pass flags as separate literal tokens. <br>


## Reference(s): <br>
- [Aeo on ClawHub](https://clawhub.ai/arberx/aeo) <br>
- [Aeo homepage](https://ainyc.ai) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance, Files] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON audit summaries.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May write llms.txt, llms-full.txt, or robots.txt when requested.] <br>

## Skill Version(s): <br>
2.1.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
