## Description: <br>
Budget enforcement and token metering for OpenClaw agents using the Revenium platform. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[johndemic](https://clawhub.ai/user/johndemic) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to meter OpenClaw agent usage, configure Revenium budget guardrails, and warn or halt agent activity when configured budget thresholds are reached. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send prompt, response, system prompt, token, timing, and model metadata to Revenium. <br>
Mitigation: Review data-sharing requirements before installation and use only in workspaces where sending conversation content to Revenium is acceptable. <br>
Risk: The setup changes OpenClaw configuration, installs cron execution, and injects Revenium credentials into the sandbox environment. <br>
Mitigation: Set credentials outside chat, review post-install.sh before running it, and re-run setup only after confirming the intended sandbox and credential changes. <br>
Risk: Guardrail enforcement depends on periodic local status updates, so spending can continue until the next cron check and failures may fail open. <br>
Mitigation: Choose an appropriate cron interval, monitor guardrail-status.json or metering logs after setup, and avoid relying on the skill as a hard real-time spending cutoff. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/johndemic/revenium) <br>
- [Revenium for AI agents documentation](https://docs.revenium.io/for-ai-agents) <br>
- [Revenium CLI](https://github.com/revenium/revenium-cli) <br>
- [OpenClaw documentation](https://docs.openclaw.ai) <br>
- [Agents metering directives](references/agents-metering-directives.md) <br>
- [Task classification](references/task-classification.md) <br>
- [Job declaration](references/job-declaration.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON configuration examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces guardrail status guidance, setup instructions, marker-writing commands, and Revenium metering configuration.] <br>

## Skill Version(s): <br>
0.6.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
