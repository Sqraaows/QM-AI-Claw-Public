## Description: <br>
Gladia helps agents manage pre-recorded Gladia transcription jobs and audio files through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to start, list, inspect, download, upload, and delete Gladia pre-recorded transcription jobs from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access, upload, download, and process sensitive audio or video files through a connected Gladia account. <br>
Mitigation: Use it only with a trusted OOMOL/oo CLI connection, confirm media-related actions before execution, and clean up transit-stored audio when it is no longer needed. <br>
Risk: Delete actions can remove Gladia transcription jobs and associated data. <br>
Mitigation: Require explicit user approval for the exact transcription target before running destructive actions. <br>
Risk: Connector schemas and upstream fields can change, which can make stale payload assumptions unreliable. <br>
Mitigation: Inspect the live connector schema before each action and verify payloads and identifiers against that schema. <br>


## Reference(s): <br>
- [Gladia homepage](https://app.gladia.io/) <br>
- [ClawHub Gladia skill page](https://clawhub.ai/oomol/oo-gladia) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, json, guidance, configuration] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema checks before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
