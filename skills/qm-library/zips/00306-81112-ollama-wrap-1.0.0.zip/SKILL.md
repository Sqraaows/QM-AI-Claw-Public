---
name: Ollama 本地 LLM 部署工具
slug: ollama-wrap
description: Ollama 本地 LLM 部署工具 — 在本地机器一键部署和运行大语言模型的工具，支持 Llama 2、Mixtral、Mistral、Gemma 等主流开源模型。提供简洁的命令行界面和 API 接口，支持模型热加载、显存管理和多并发请求处理。适用于开发者、研究者、数据分析师等需要本地运行 AI 模型但不想依赖云端服务的用户，部署门槛低，配置简单。 | 来源：https://github.com/q15004040209-creator/ollama-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/ollama-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
