# Ollama Wrapper - 本地大模型运行工具封装

[English](#english) | [中文](#中文)

---

## 📌 中文

### 项目简介

**Ollama** 是一个开源的本地大语言模型 (LLM) 运行工具，支持一键部署和运行各类开源模型（如 Llama 3、Gemma 3、Mistral 等）。本项目 (`ollama-wrap`) 提供 Python 和 curl 调用封装，方便快速集成到各类应用中。

> ⭐ GitHub 星标 82,000+，本地 LLM 运行标杆工具

### 核心特性

- 🖥️ **跨平台**：支持 macOS、Windows、Linux、Docker
- 🚀 **一键运行**：一条命令即可启动模型
- 🌐 **REST API**：轻量级 API 接口，方便集成
- 📦 **模型市场**：内置模型库，持续更新
- 💻 **终端聊天**：直接在终端与模型对话

### 快速开始

#### 1. 安装 Ollama

```powershell
# Windows
irm https://ollama.com/install.ps1 | iex

# macOS / Linux
curl -fsSL https://ollama.com/install.sh | sh

# Docker
docker run -d -p 11434:11434 ollama/ollama
```

#### 2. 运行模型

```powershell
# 拉取并运行 Gemma 3
ollama run gemma3

# 拉取并运行 Llama 3
ollama run llama3

# 拉取并运行 Mistral
ollama run mistral
```

#### 3. API 调用示例

**Python 调用：**

```python
import requests

url = "http://localhost:11434/api/chat"
headers = {"Content-Type": "application/json"}
data = {
    "model": "gemma3",
    "messages": [
        {"role": "user", "content": "为什么天空是蓝色的？"}
    ],
    "stream": False
}

response = requests.post(url, json=data, headers=headers)
print(response.json()["message"]["content"])
```

**curl 调用：**

```bash
curl http://localhost:11434/api/chat -d '{
  "model": "gemma3",
  "messages": [{"role": "user", "content": "为什么天空是蓝色的？"}],
  "stream": false
}'
```

### API 端点一览

| 端点 | 方法 | 说明 |
|------|------|------|
| `/api/chat` | POST | 对话生成 |
| `/api/generate` | POST | 文本生成 |
| `/api/tags` | GET | 列出已下载模型 |
| `/api/show` | POST | 模型信息 |
| `/api/create` | POST | 创建模型 |
| `/api/pull` | POST | 拉取模型 |
| `/api/push` | POST | 推送模型 |
| `/api/delete` | DELETE | 删除模型 |
| `/api/embeddings` | POST | 向量嵌入 |

### 模型库推荐

| 模型 | 命令 | 参数量 |
|------|------|--------|
| Llama 3 | `ollama run llama3` | 8B |
| Gemma 3 | `ollama run gemma3` | 12B |
| Mistral | `ollama run mistral` | 7B |
| Qwen 2.5 | `ollama run qwen2.5` | 7B |
| DeepSeek Coder | `ollama run deepseek-coder` | 6.7B |

### 项目结构

```
ollama-wrap/
├── README.md           # 本文件
├── demo/
│   ├── demo.py         # Python 调用示例
│   └── demo.sh         # curl 调用示例
└── docs/
    └── api_reference.md # API 参考文档
```

### 相关资源

- 🌐 官网：https://ollama.com
- 📚 文档：https://docs.ollama.com
- 💬 Discord：https://discord.gg/ollama
- 🐙 GitHub：https://github.com/ollama/ollama

---

## 📌 English

### Project Introduction

**Ollama** is an open-source local large language model (LLM) runtime that supports one-command deployment and running of various open-source models (such as Llama 3, Gemma 3, Mistral, etc.). This project (`ollama-wrap`) provides Python and curl call wrappers for easy integration into various applications.

> ⭐ 82,000+ GitHub stars, the benchmark for local LLM runtime

### Key Features

- 🖥️ **Cross-platform**: Supports macOS, Windows, Linux, Docker
- 🚀 **One-command run**: Start a model with a single command
- 🌐 **REST API**: Lightweight API for easy integration
- 📦 **Model Library**: Built-in model hub with regular updates
- 💻 **Terminal Chat**: Chat with models directly in terminal

### Quick Start

#### 1. Install Ollama

```bash
# macOS / Linux
curl -fsSL https://ollama.com/install.sh | sh

# Windows
irm https://ollama.com/install.ps1 | iex

# Docker
docker run -d -p 11434:11434 ollama/ollama
```

#### 2. Run a Model

```bash
# Pull and run Gemma 3
ollama run gemma3

# Pull and run Llama 3
ollama run llama3

# Pull and run Mistral
ollama run mistral
```

#### 3. API Call Examples

**Python:**

```python
import requests

url = "http://localhost:11434/api/chat"
headers = {"Content-Type": "application/json"}
data = {
    "model": "gemma3",
    "messages": [
        {"role": "user", "content": "Why is the sky blue?"}
    ],
    "stream": False
}

response = requests.post(url, json=data, headers=headers)
print(response.json()["message"]["content"])
```

**curl:**

```bash
curl http://localhost:11434/api/chat -d '{
  "model": "gemma3",
  "messages": [{"role": "user", "content": "Why is the sky blue?"}],
  "stream": false
}'
```

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chat` | POST | Chat completion |
| `/api/generate` | POST | Text generation |
| `/api/tags` | GET | List downloaded models |
| `/api/show` | POST | Model info |
| `/api/create` | POST | Create model |
| `/api/pull` | POST | Pull model |
| `/api/push` | POST | Push model |
| `/api/delete` | DELETE | Delete model |
| `/api/embeddings` | POST | Text embeddings |

### Recommended Models

| Model | Command | Parameters |
|-------|---------|------------|
| Llama 3 | `ollama run llama3` | 8B |
| Gemma 3 | `ollama run gemma3` | 12B |
| Mistral | `ollama run mistral` | 7B |
| Qwen 2.5 | `ollama run qwen2.5` | 7B |
| DeepSeek Coder | `ollama run deepseek-coder` | 6.7B |

### Project Structure

```
ollama-wrap/
├── README.md           # This file
├── demo/
│   ├── demo.py         # Python demo
│   └── demo.sh         # curl demo
└── docs/
    └── api_reference.md # API reference
```

### Resources

- 🌐 Website：https://ollama.com
- 📚 Docs：https://docs.ollama.com
- 💬 Discord：https://discord.gg/ollama
- 🐙 GitHub：https://github.com/ollama/ollama

---

## License

MIT License - See [Ollama](https://github.com/ollama/ollama) for original project.