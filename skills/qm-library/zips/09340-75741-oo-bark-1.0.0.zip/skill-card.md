## Description: <br>
Bark (bark.day.app) helps an agent inspect a connected Bark server and send Bark notifications through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and end users use this skill to operate Bark via OOMOL, including reading server information and sending single, batch, or pre-encrypted notifications after inspecting the live action schema. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an authenticated OOMOL-connected Bark account and can send notifications. <br>
Mitigation: Install only when Bark access through OOMOL is intended, and confirm notification payloads before send or batch-send actions. <br>
Risk: The one-time oo CLI installer executes a remote install script. <br>
Mitigation: Review the installer or obtain it from OOMOL's official install guide before running it. <br>
Risk: Bark action schemas and defaults may change upstream. <br>
Mitigation: Inspect the live action schema before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub Bark skill page](https://clawhub.ai/oomol/oo-bark) <br>
- [Bark homepage](https://bark.day.app) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
