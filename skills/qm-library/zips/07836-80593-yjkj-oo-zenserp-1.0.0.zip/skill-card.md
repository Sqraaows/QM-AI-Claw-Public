## Description: <br>
Zenserp helps agents run Google Search, Image Search, Maps local search, and News search through an OOMOL-connected Zenserp account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to query Zenserp-backed search surfaces through the oo CLI without handling raw API credentials. It is suited for retrieving search, image, maps, and news results after inspecting the live connector schema. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Search terms and query context are sent to a third-party Zenserp service. <br>
Mitigation: Do not include secrets, private customer data, unreleased project names, or sensitive internal research terms unless that disclosure is acceptable. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live action schema with the oo CLI before constructing payloads. <br>


## Reference(s): <br>
- [Zenserp homepage](https://zenserp.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-zenserp) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown instructions with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses are returned by the oo CLI as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
