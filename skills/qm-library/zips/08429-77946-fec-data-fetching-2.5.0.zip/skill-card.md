## Description: <br>
Use when implementing or reviewing TanStack Query/React Query server-state flows: typed queries, query keys, caching, invalidation, mutations, optimistic updates, infinite queries, prefetch, SSR hydration, or API-layer integration. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[bovinphang](https://clawhub.ai/user/bovinphang) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to implement or review server-state data fetching in React applications with TanStack Query/React Query. It helps structure query keys, caching, invalidation, mutations, optimistic updates, infinite queries, prefetching, SSR hydration, and API-layer boundaries. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated TanStack Query code can use query keys, cache invalidation, or optimistic updates that do not match product-specific API behavior. <br>
Mitigation: Review generated changes against the application's API contracts, cache lifecycle, and rollback requirements before merging. <br>


## Reference(s): <br>
- [TanStack Query advanced patterns](references/query-patterns.md) <br>
- [ClawHub skill page](https://clawhub.ai/bovinphang/fec-data-fetching) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Configuration, Guidance] <br>
**Output Format:** [Markdown with TypeScript/TSX code examples and implementation guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only skill; it guides agent-generated application code and review comments.] <br>

## Skill Version(s): <br>
2.5.0 (source: server release metadata, package.json, metadata.json, README.md) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
