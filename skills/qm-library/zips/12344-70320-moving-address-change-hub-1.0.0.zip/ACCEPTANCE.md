# Acceptance Criteria — moving-address-change-hub

## Criterion 1: Complete Submission
- [ ] SKILL.md exists in `/Users/jianghaidong/.openclaw/skills/moving-address-change-hub/`
- [ ] skill.json exists and is valid JSON
- [ ] ACCEPTANCE.md exists

## Criterion 2: Content Requirements
- [ ] SKILL.md is prompt-only (no external credentials, API calls, or network dependencies)
- [ ] All content is English, zero CJK characters
- [ ] Safety boundaries are clearly defined in SKILL.md
- [ ] skill.json contains all required fields (schema, name, version, displayName, description, categories, license, locale, promptOnly, usage)

## Criterion 3: Functional Correctness
- [ ] Produces a categorized institution checklist from user-provided move details
- [ ] Generates a chronological timeline sorted relative to move date
- [ ] Includes missed-item detection (asks about specific services the user might forget)
- [ ] Provides a 90-day post-move review plan

## Criterion 4: Safety
- [ ] Never requests or stores sensitive personal information (passwords, SSN, PINs, bank account numbers)
- [ ] Never executes address changes on the user's behalf
- [ ] Recommends official .gov domains and warns against third-party fee-charging services
- [ ] Contains a clear disclaimer that it provides checklists and guidance only

## Criterion 5: Edge Cases
- [ ] Handles international moves with additional categories (visa, customs, international bank notification)
- [ ] When user provides minimal information, prompts for missing address details and move date
- [ ] Detects user life context (pets, vehicles, children) and prompts for relevant updates

## Verification
- [ ] Run `cat skill.json | python3 -m json.tool` confirms valid JSON
- [ ] No API keys, tokens, or URLs present in any file
- [ ] All 3 files are readable and non-empty
