## Description: <br>
Eventzilla lets agents search and read Eventzilla events, attendees, tickets, transactions, and organizer records through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and event teams use this skill to inspect Eventzilla account data, including events, attendees, ticket categories, transactions, and organizer users. It is intended for read-oriented Eventzilla workflows through an authenticated OOMOL connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Review before execution as proposals could introduce incorrect or misleading guidance into skills. <br>
Mitigation: Review and scan skill before deployment. <br>

## Reference(s): <br>
- [ClawHub Eventzilla skill page](https://clawhub.ai/oomol/oo-eventzilla) <br>
- [Eventzilla homepage](https://www.eventzilla.net) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses oo connector schema before execution and oo connector run with JSON payloads. Security evidence is clean but notes a real supply-chain risk from the remote OOMOL CLI installer; review setup commands and trust OOMOL before installation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
