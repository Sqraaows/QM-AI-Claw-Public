## Description: <br>
OpenCage lets agents run OOMOL-backed OpenCage geocoding actions for forward, reverse, and GeoJSON location lookup. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents use this skill to convert addresses, place names, latitude and longitude coordinates, or geocoding results into OpenCage JSON and GeoJSON outputs through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Geocoding queries and coordinates are sent through the OOMOL/OpenCage connector. <br>
Mitigation: Use the skill only when the user intends to send that location data to the connected service. <br>
Risk: The skill depends on the OOMOL oo CLI and an OOMOL-connected OpenCage account. <br>
Mitigation: Install the oo CLI only from OOMOL-controlled sources and sign in or connect OpenCage only after an auth or connection error requires setup. <br>
Risk: Action schemas and defaults can change upstream. <br>
Mitigation: Run oo connector schema for the selected OpenCage action before building each payload. <br>


## Reference(s): <br>
- [ClawHub OpenCage skill page](https://clawhub.ai/oomol/oo-opencage) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [OpenCage homepage](https://opencagedata.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, JSON, GeoJSON, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON or GeoJSON connector responses.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId; live action schemas should be inspected before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
