## Description: <br>
Celigo (celigo.com). Use this skill for Celigo requests that read integration metadata through the OOMOL connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to inspect Celigo flows, imports, exports, connections, and token metadata from an OOMOL-connected Celigo account. It is intended for schema-first connector execution where the agent checks the live action contract before sending JSON payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill connects to a Celigo account through OOMOL and can expose integration metadata to the agent. <br>
Mitigation: Install only when that account access is appropriate, keep credentials managed through OOMOL, and verify the live schema before each connector run. <br>
Risk: Security guidance notes a documentation inconsistency for get_import that may make its side effects unclear. <br>
Mitigation: Treat get_import cautiously until corrected: inspect the live schema and require user confirmation if the action appears to change Celigo state. <br>


## Reference(s): <br>
- [Celigo homepage](https://www.celigo.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-celigo) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses server-side credential injection through OOMOL; agents should fetch the live connector schema before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
