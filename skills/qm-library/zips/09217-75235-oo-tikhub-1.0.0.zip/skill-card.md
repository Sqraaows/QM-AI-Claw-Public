## Description: <br>
TikHub enables agents to access TikHub through an OOMOL-connected account for public TikTok, Douyin, and Xiaohongshu data plus TikHub account usage and endpoint metadata. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and analysts use this skill to ask an agent to fetch public TikTok, Douyin, and Xiaohongshu profiles, posts, comments, tags, hot lists, and search results through TikHub. It also helps inspect TikHub endpoint metadata, pricing, daily usage, and account details when the user has an OOMOL-connected TikHub account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access through an OOMOL-connected TikHub account and may use sensitive account context. <br>
Mitigation: Install it only when TikHub access is intended, and approve setup, login, connection, or billing steps only when explicitly requested. <br>
Risk: The get_user_info action may reveal account or API key details. <br>
Mitigation: Run account-detail actions only for user-requested account checks, and treat returned account data as sensitive. <br>
Risk: Some actions may change TikHub state or have effects that depend on the live connector contract. <br>
Mitigation: Inspect the live action schema before constructing payloads and confirm the exact payload and intended effect before any create, update, send, post, delete, or remove action. <br>


## Reference(s): <br>
- [TikHub homepage](https://tikhub.io/) <br>
- [ClawHub TikHub skill listing](https://clawhub.ai/oomol/oo-tikhub) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Skill source artifact](artifact/SKILL.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; action responses are JSON from the oo connector.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
