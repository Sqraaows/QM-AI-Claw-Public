## Description: <br>
Yelp helps an agent search Yelp businesses, find businesses by exact phone number, and retrieve business details through an OOMOL-connected Yelp account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and agents use this skill to search and read Yelp business data without calling the Yelp API directly. It is suited for location research, business lookup, and data retrieval workflows that need Yelp results through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive Yelp credentials through an OOMOL-connected account. <br>
Mitigation: Install and use it only when the user trusts OOMOL and is comfortable connecting a Yelp API key through OOMOL. <br>
Risk: The setup path includes an optional remote installer for the oo CLI. <br>
Mitigation: Verify OOMOL's official installation instructions before running the installer. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live action schema with the oo CLI before constructing payloads. <br>


## Reference(s): <br>
- [Yelp homepage](https://www.yelp.com) <br>
- [ClawHub Yelp skill](https://clawhub.ai/oomol/oo-yelp) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses read-oriented Yelp connector actions and returns connector responses as JSON data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
