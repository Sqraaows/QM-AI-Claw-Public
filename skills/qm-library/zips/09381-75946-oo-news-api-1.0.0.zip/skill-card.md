## Description: <br>
News API (newsapi.org). Use this skill for ANY News API request - searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to search News API articles, list available sources, and retrieve current top or breaking headlines through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to sensitive News API or OOMOL account credentials. <br>
Mitigation: Provide only the API key or account access needed for the task and use the OOMOL-managed credential flow instead of exposing raw tokens to the agent. <br>
Risk: The skill includes an optional curl-to-bash CLI installer path if the oo CLI is missing. <br>
Mitigation: Prefer official installation instructions and inspect the installer before running it. <br>
Risk: The skill has a broad trigger for News API requests and can send live API queries. <br>
Mitigation: Inspect the action schema before building payloads and review each request before sending it. <br>


## Reference(s): <br>
- [News API homepage](https://newsapi.org) <br>
- [Skill page](https://clawhub.ai/oomol/oo-news-api) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON command output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the oo CLI to inspect live connector schemas and run read-oriented News API actions; responses include data and an execution ID.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
