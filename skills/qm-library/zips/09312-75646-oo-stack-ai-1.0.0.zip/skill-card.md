## Description: <br>
StackAI (stack-ai.com). Use this skill for ANY StackAI request, including searching, reading data, running deployed flows, and fetching run metadata through the OOMOL StackAI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to operate StackAI through an OOMOL-connected account, including running deployed StackAI flows with JSON variables and checking metadata for prior runs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Running StackAI flows may do more than read data and can trigger state-changing behavior in connected systems. <br>
Mitigation: Inspect the live action schema, confirm the exact flow and JSON payload, and get explicit user approval before actions that create, update, send, post, delete, or remove data. <br>
Risk: The first-time setup instructions include remote pipe-to-shell installer commands. <br>
Mitigation: Prefer a safer installation path or verify the installer source and integrity before executing remote installation commands. <br>
Risk: The security verdict is suspicious because the skill combines flow execution with a read-oriented description. <br>
Mitigation: Install only when the OOMOL publisher is trusted, review the skill behavior before use, and avoid running unexpected StackAI flows. <br>


## Reference(s): <br>
- [StackAI homepage](https://www.stack-ai.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-stack-ai) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, json, guidance] <br>
**Output Format:** [Markdown instructions with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses can include StackAI connector data and a meta.executionId value.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
