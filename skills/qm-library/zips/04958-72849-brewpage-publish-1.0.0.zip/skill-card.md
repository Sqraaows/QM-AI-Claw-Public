## Description: <br>
Publishes text, markdown, local files, ZIP archives, or built static sites to brewpage.app and returns a public URL. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[kochetkov-ma](https://clawhub.ai/user/kochetkov-ma) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creators use this skill to publish selected content or static-site output from an agent session to BrewPage for sharing, with optional namespace, TTL, and password protection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can unintentionally expose local text, files, ZIP archives, or site output through public upload behavior. <br>
Mitigation: Verify the exact content being uploaded, avoid secrets or personal data, and use password protection when the link should not be public. <br>
Risk: ./brewpage-history.md stores owner tokens that can delete published content. <br>
Mitigation: Keep ./brewpage-history.md private and out of version control. <br>
Risk: Publishing an unbuilt source tree could expose source files or development artifacts. <br>
Mitigation: Publish built static output only and rely on the documented built-static guard and archive exclusions before upload. <br>


## Reference(s): <br>
- [BrewPage homepage](https://brewpage.app) <br>
- [ClawHub skill page](https://clawhub.ai/kochetkov-ma/brewpage-publish) <br>
- [OpenClaw AgentSkills documentation](https://docs.openclaw.ai/tools/skills) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command blocks and short status messages.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May create ./brewpage-history.md containing deletion owner tokens; requires curl, jq, and zip for publish workflows.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
