## Description: <br>
Streamtime lets an agent read, create, and update Streamtime data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees and operations teams use this skill to work with Streamtime organisation data, companies, contacts, jobs, branches, users, and rate cards from an agent session. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update Streamtime business records through a connected account. <br>
Mitigation: Review write payloads and confirm the intended effect with the user before approving create or update actions. <br>
Risk: The skill depends on OOMOL account credentials and CLI setup. <br>
Mitigation: Install and authenticate the oo CLI only when the user trusts OOMOL tooling and needs first-time setup. <br>


## Reference(s): <br>
- [Streamtime homepage](https://www.streamtime.net) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-streamtime) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution and returns connector responses that include data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
