## Description: <br>
Provides a Windows intranet installation and troubleshooting guide for node-llama-cpp in OpenClaw memorySearch, including remote embedding configuration as an alternative. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[paudyyin](https://clawhub.ai/user/paudyyin) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to install or troubleshoot node-llama-cpp for OpenClaw memorySearch in Windows network-restricted environments and to configure a remote embedding fallback when local installation is not practical. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The guide includes persistent changes to installed OpenClaw files and removal of a whitelist, which can affect supportability and security if applied without scope or rollback planning. <br>
Mitigation: Prefer supported OpenClaw configuration mechanisms, obtain approval for managed environments, and document a rollback plan before editing installed files or changing whitelist behavior. <br>
Risk: The remote embedding option can route memorySearch data to a remote endpoint and requires careful credential handling. <br>
Mitigation: Confirm the endpoint is approved for the data being processed, store API keys through approved secret handling, and avoid committing or sharing credentials in configuration examples. <br>


## Reference(s): <br>
- [node-llama-cpp documentation](https://node-llama-cpp.withcat.ai) <br>
- [OpenClaw memorySearch configuration](https://docs.openclaw.ai/reference/memory-config) <br>


## Skill Output: <br>
**Output Type(s):** [Markdown, Shell commands, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown with inline shell, batch, and JSON code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Includes Windows paths, installation commands, troubleshooting checks, and configuration examples.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release metadata and package.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
