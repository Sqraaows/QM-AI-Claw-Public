## Description: <br>
Oomol Fusion API lets agents inspect schemas and run OOMOL Fusion API actions for reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill to inspect Oomol Fusion API action schemas and run connector actions for media generation, speech, document conversion, web reading, file upload, and related API workflows through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate an OOMOL Fusion API account through the oo CLI, including uploads, media generation, edits, and delete-style actions. <br>
Mitigation: Review live action schemas, payloads, and intended effects before approving state-changing or destructive API actions. <br>
Risk: First-time setup documentation may direct users to run a remote oo CLI installer when the CLI is missing. <br>
Mitigation: Install the CLI only from the documented OOMOL source and review the installer path before running it. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-fusion-api) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [Oomol Fusion API homepage](https://www.oomol.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are JSON from the oo CLI and may include execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
