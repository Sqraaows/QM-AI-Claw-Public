## Description: <br>
ipstack (ipstack.com). Use this skill for ANY ipstack request - searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect the live OOMOL connector schema and run ipstack geolocation lookups for a single IP address, the requester IP address, or multiple IPv4/IPv6 addresses. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires trust in OOMOL's oo CLI and an OOMOL-connected ipstack account. <br>
Mitigation: Install and use it only in environments where OOMOL's CLI and account connection model are approved. <br>
Risk: Queried IP addresses and returned geolocation data may be sensitive. <br>
Mitigation: Avoid submitting IP addresses that should not be shared with the connector, and treat returned location data according to the user's data-handling requirements. <br>


## Reference(s): <br>
- [ipstack homepage](https://ipstack.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ipstack) <br>
- [ClawHub publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown with inline bash commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill directs agents to fetch the live connector schema before constructing action payloads and returns ipstack data through the OOMOL oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
