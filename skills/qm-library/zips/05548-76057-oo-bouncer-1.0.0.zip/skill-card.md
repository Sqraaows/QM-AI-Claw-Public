## Description: <br>
Bouncer is an OOMOL-published connector skill for reading, creating, updating, and deleting email and domain verification data through an OOMOL-connected Bouncer account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Bouncer email verification workflows from an agent, including single email checks, batch verification, domain checks, toxicity list jobs, result retrieval, and account credit lookup. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses an OOMOL-connected Bouncer account and may process email addresses, domains, job identifiers, and verification results through OOMOL and Bouncer. <br>
Mitigation: Install it only for intended Bouncer use, review email lists and domains before execution, and avoid submitting data the user has not approved for processing. <br>
Risk: Create and batch actions can change Bouncer state or consume account credits. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>
Risk: Delete actions can remove batch verification or toxicity list job results. <br>
Mitigation: Confirm the target job or batch identifier and require explicit user approval before deletion. <br>


## Reference(s): <br>
- [Bouncer homepage](https://www.usebouncer.com/) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-bouncer) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with oo CLI shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
