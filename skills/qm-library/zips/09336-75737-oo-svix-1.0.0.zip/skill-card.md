## Description: <br>
Svix (svix.com). Use this skill for ANY Svix request - reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Svix applications, endpoints, event types, and messages through an OOMOL-connected account. It supports reading account data and, with user confirmation, creating, updating, dispatching, or deleting live Svix resources. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: State-changing actions can create, update, dispatch, or delete live Svix resources. <br>
Mitigation: Confirm the exact action, target resource, and payload with the user before running create, update, message dispatch, or delete commands. <br>
Risk: The skill requires access to a connected Svix account through OOMOL. <br>
Mitigation: Install and use it only when the agent is intended to operate that Svix account, and rely on OOMOL-managed credentials rather than exposing raw tokens. <br>


## Reference(s): <br>
- [Svix homepage](https://www.svix.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-svix) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Markdown, Configuration guidance, API calls] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
