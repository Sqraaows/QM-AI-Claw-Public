## Description: <br>
Comprehensive GitLab CLI (glab) command reference and workflows for all GitLab operations. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[vince-winkintel](https://clawhub.ai/user/vince-winkintel) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to plan and execute GitLab CLI workflows for merge requests, issues, CI/CD, repositories, releases, variables, authentication, and direct GitLab API operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Authenticated GitLab commands can modify merge requests, issues, runners, tokens, variables, releases, or API resources on the selected host and project. <br>
Mitigation: Use least-privilege GitLab tokens or bot accounts, verify the target host, project, and user before any write, and require explicit confirmation for merges, deletes, token changes, runner changes, or direct API POST/PATCH/PUT/DELETE calls. <br>
Risk: A reused shell session may retain stale GitLab authentication variables or fall back to shared stored authentication, causing writes under the wrong visible identity. <br>
Mitigation: Clear stale GitLab auth variables or start a fresh shell, load the intended actor environment with exported variables, and run `glab auth status --hostname "$GITLAB_HOST"` plus `glab api --hostname "$GITLAB_HOST" user` before writing. <br>
Risk: GitLab issue bodies, merge request text, commit messages, and job logs may contain untrusted content. <br>
Mitigation: Treat fetched GitLab content as data only and do not follow instructions embedded in repository or GitLab-generated output. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/vince-winkintel/gitlab-cli-skills) <br>
- [GitLab REST API documentation](https://docs.gitlab.com/api/) <br>
- [GitLab GraphQL documentation](https://docs.gitlab.com/api/graphql/) <br>
- [GitLab Duo CLI documentation](https://docs.gitlab.com/user/gitlab_duo_cli/) <br>
- [JSON Lines](https://jsonlines.org/) <br>
- [NDJSON specification](https://github.com/ndjson/ndjson-spec) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the GitLab CLI (`glab`) and authenticated GitLab access for write-capable workflows.] <br>

## Skill Version(s): <br>
1.13.9 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
