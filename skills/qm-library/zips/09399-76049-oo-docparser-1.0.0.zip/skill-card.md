## Description: <br>
Docparser lets an agent operate a Docparser account through OOMOL's oo CLI for parser discovery, document ingestion, status checks, parsed result retrieval, and reprocessing workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operations teams, and document-processing users use this skill to run Docparser workflows from an agent through an OOMOL-connected account. Review payloads before uploads, imports, reparsing, or integration retries because those actions can change Docparser state and may process sensitive document contents. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Review before execution as proposals could introduce incorrect or misleading guidance into skills. <br>
Mitigation: Review and scan skill before deployment. <br>

## Reference(s): <br>
- [ClawHub Docparser skill](https://clawhub.ai/oomol/oo-docparser) <br>
- [Docparser homepage](https://docparser.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or results.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the OOMOL oo CLI, checks the live connector schema before action payloads, and relies on OOMOL-managed Docparser credentials.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence release and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
