## Description: <br>
Use this skill for Jira requests involving reading, creating, and updating data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, support teams, and project operators use this skill to read Jira projects and issues, search with JQL, create issues, and add comments through an OOMOL-connected Jira account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill runs authenticated Jira operations through local CLI credentials. <br>
Mitigation: Install it only in trusted workspaces and review commands before execution, as recommended by the security guidance. <br>
Risk: Creating issues and adding comments can change Jira state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-jira) <br>
- [Jira homepage](https://www.atlassian.com/software/jira) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON data from the Jira connector when executed with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
