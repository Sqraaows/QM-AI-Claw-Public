## Description: <br>
Klangio lets an agent operate Klangio through an OOMOL-connected account to create audio analysis jobs, check job status, and retrieve generated results. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to run Klangio audio-processing workflows through OOMOL, including transcription, beat tracking, chord recognition, source separation, job status checks, and result downloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create Klangio processing jobs and send audio inputs through an OOMOL-connected account. <br>
Mitigation: Confirm job-creation payloads, audio sources, and intended effects with the user before running create actions. <br>
Risk: Result and source-separation downloads are transfers into OOMOL OSS transit storage, not purely local retrieval. <br>
Mitigation: Treat downloaded outputs as data transfers and confirm the target file or stem before initiating download actions. <br>
Risk: The connector requires an authenticated OOMOL account with Klangio connected. <br>
Mitigation: Install only when the user intends to let OOMOL operate the connected Klangio account and resolve authentication or connection setup only after a command fails for that reason. <br>


## Reference(s): <br>
- [Klangio homepage](https://klang.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-klangio) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration guidance, Text, JSON] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload or response details] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; downloads are transferred through OOMOL OSS transit storage.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
