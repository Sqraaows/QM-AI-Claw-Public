## Description: <br>
Dida365 lets an agent read, create, update, complete, move, filter, and delete Dida365 tasks, projects, habits, and habit check-ins through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent operate a connected Dida365 account for task, project, and habit workflows. It supports both read-only retrieval and account-changing actions when the user authorizes the exact target and payload. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Creating, updating, moving, completing, or deleting Dida365 tasks and projects can change or remove account data. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write or destructive actions. <br>
Risk: Account access depends on OOMOL-managed Dida365 credentials and connector scopes. <br>
Mitigation: Install only when the user intends to let the agent operate their Dida365 account through OOMOL, and retry setup only after an authentication or connection error. <br>


## Reference(s): <br>
- [Dida365 homepage](https://dida365.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-dida365) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return connector JSON responses containing Dida365 account data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.1 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
