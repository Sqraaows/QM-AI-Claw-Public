## Description: <br>
VectorShift lets an agent operate VectorShift through an OOMOL-connected account to list, fetch, and run pipelines with JSON-safe inputs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect available VectorShift pipelines, retrieve pipeline details, and run single or batched pipeline executions from an agent through the OOMOL oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Review before execution as proposals could introduce incorrect or misleading guidance into skills. <br>
Mitigation: Review and scan skill before deployment. <br>

## Reference(s): <br>
- [ClawHub VectorShift Skill](https://clawhub.ai/oomol/oo-vectorshift) <br>
- [VectorShift homepage](https://vectorshift.ai) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed and authenticated oo CLI plus a connected VectorShift account. Security evidence is clean, but listing or fetching pipelines may reveal account data, and running pipelines may consume credits or trigger pipeline-defined effects; confirm pipeline identifiers, names, and inputs before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: metadata and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
