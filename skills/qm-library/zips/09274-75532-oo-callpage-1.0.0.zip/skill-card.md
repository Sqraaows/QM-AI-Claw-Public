## Description: <br>
CallPage (callpage.io). Use this skill for CallPage requests that read call, widget, and user data or create widget callback requests through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and operators use this skill to work with CallPage records through OOMOL's CallPage connector, including listing or retrieving calls, widgets, and users and creating callback requests for selected widgets. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive CallPage credentials through an OOMOL-connected account. <br>
Mitigation: Install only when the publisher is trusted and the user is comfortable connecting a CallPage account or API key through OOMOL. <br>
Risk: Read actions can expose CallPage call, user, and widget data. <br>
Mitigation: Limit use to authorized requests and review returned data before sharing it outside the intended workflow. <br>
Risk: The create_widget_call action can initiate a CallPage callback request. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running the write action. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/oomol/oo-callpage) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [CallPage homepage](https://www.callpage.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return JSON from CallPage connector actions when commands are executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
