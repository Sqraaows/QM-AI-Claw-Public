## Description: <br>
Use when the user asks to interact with Google Workspace services, including Google Sheets, Docs, Gmail, Calendar, Drive, Tasks, Contacts, and Auth. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, developers, and agent operators use this skill to let an agent work with Google Workspace services through an authenticated gogcli MCP server. It supports reading, creating, updating, sending, sharing, deleting, and searching user data across the listed Google services. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can affect Google Workspace data through OAuth-authorized actions. <br>
Mitigation: Install it only when that access is intended, use the narrowest Google scopes and account possible, and confirm before send, share, delete, or update actions. <br>
Risk: OAuth access can remain available after the immediate task is complete. <br>
Mitigation: Revoke or log out of OAuth access when the skill is no longer needed. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp) <br>
- [gogcli](https://github.com/openclaw/gogcli) <br>
- [gogcli-mcp source](https://github.com/chrischall/gogcli-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown, JSON configuration, and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include MCP server setup details and Google Workspace tool-use guidance.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
