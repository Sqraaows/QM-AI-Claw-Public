## Description: <br>
This skill helps agents work with HoneyBook client-portal data for wedding-vendor contracts, invoices, proposals, brochures, and payment-related requests. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to inspect HoneyBook portal status across vendors, summarize shared contracts and invoices, and return browser deep links for signing or payment when explicitly confirmed. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Authenticated HoneyBook sessions can expose contract, invoice, workspace, and saved payment-method details to the agent. <br>
Mitigation: Install only for HoneyBook portals you own or are authorized to access, paste magic links only when you intend to grant access, and review outputs before sharing them. <br>
Risk: Captured portal sessions are retained locally and can continue to provide access until removed or expired. <br>
Mitigation: Delete ~/.honeybook-mcp/sessions.json when access is no longer needed, and refresh sessions only with current vendor magic links. <br>
Risk: Signing and payment actions involve financial authority even when the skill returns browser deep links rather than completing the action directly. <br>
Mitigation: Require explicit confirmation before requesting sign or payment links, and complete final signing or payment steps in the browser after verifying the vendor, document, amount, and due date. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/chrischall/honeybook-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return HoneyBook portal status, file details, saved payment-method details, active session summaries, and browser deep links for signing or payment.] <br>

## Skill Version(s): <br>
0.3.2 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
