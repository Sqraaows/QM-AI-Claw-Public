## Description: <br>
Lessonspace (thelessonspace.com). Use this skill for ANY Lessonspace request - reading, creating, and updating data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Lessonspace through an OOMOL-connected account, including creating or retrieving spaces, listing organisation sessions, reading session details, and getting recording playback URLs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an OOMOL-connected Lessonspace account and may expose sensitive session details or recording URLs. <br>
Mitigation: Install only for intended Lessonspace account use, treat session and recording data as sensitive, and avoid sharing returned URLs outside authorized workflows. <br>
Risk: The create_unified_space action can change Lessonspace state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create actions. <br>
Risk: First-time setup may require installing the oo CLI. <br>
Mitigation: Review the oo CLI installer before running it and only perform setup when an action fails due to missing CLI, authentication, connection, or billing state. <br>


## Reference(s): <br>
- [Lessonspace homepage](https://www.thelessonspace.com) <br>
- [ClawHub Lessonspace skill](https://clawhub.ai/oomol/oo-lessonspace) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses oo CLI connector responses that include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
