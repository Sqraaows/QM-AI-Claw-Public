## Description: <br>
Skyfire lets agents inspect Skyfire marketplace services and create buyer tokens through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to discover Skyfire marketplace services and retrieve service details. With explicit confirmation, they can create buyer tokens for seller services or seller domains through their connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Creating buyer tokens can change Skyfire state and may create funded or identity-carrying tokens. <br>
Mitigation: Confirm the exact create_token payload and intended effect with the user before running the action. <br>
Risk: The skill requires connection to a Skyfire account through OOMOL and is tagged as requiring sensitive credentials. <br>
Mitigation: Install it only when intending to use OOMOL as a bridge to Skyfire, and rely on server-side credential injection instead of handling raw tokens. <br>
Risk: The oo CLI installer is fetched from OOMOL distribution URLs. <br>
Mitigation: Run the installer only if the user trusts OOMOL's distribution channel. <br>


## Reference(s): <br>
- [Skyfire homepage](https://skyfire.xyz) <br>
- [Skyfire skill on ClawHub](https://clawhub.ai/oomol/oo-skyfire) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, json, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON CLI responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires live schema inspection before constructing action payloads] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
