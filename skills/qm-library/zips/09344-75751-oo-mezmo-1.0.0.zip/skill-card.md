## Description: <br>
Mezmo (mezmo.com). Use this skill for Mezmo requests that involve searching, reading, or reviewing data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and support teams use this skill to inspect Mezmo ingestion status and usage data through the oo CLI without handling raw Mezmo credentials directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup path can ask the agent to install the oo CLI through an unpinned remote installer script. <br>
Mitigation: Use a verified, pinned, or separately reviewed installation method for the oo CLI before enabling the skill. <br>
Risk: The connected Mezmo account may expose sensitive log, analytics, or usage data. <br>
Mitigation: Confirm the account, scopes, requested action, and time window before running commands that read Mezmo data. <br>


## Reference(s): <br>
- [Mezmo homepage](https://www.mezmo.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_ingestion_status action](actions/get_ingestion_status.md) <br>
- [get_usage_summary action](actions/get_usage_summary.md) <br>
- [list_app_usages action](actions/list_app_usages.md) <br>
- [list_host_usages action](actions/list_host_usages.md) <br>
- [list_tag_usages action](actions/list_tag_usages.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, Guidance, API calls] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are JSON objects with data and meta.executionId; live schemas should be fetched before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
