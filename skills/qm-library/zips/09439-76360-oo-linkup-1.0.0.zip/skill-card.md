## Description: <br>
Linkup (linkup.so) lets agents search the web, fetch webpages, return sourced answers, produce structured search data, and check Linkup credits through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Linkup through the oo CLI for web search, sourced answer generation, webpage fetching, schema-normalized search results, and credit-balance checks without directly handling raw Linkup API tokens. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on OOMOL's oo CLI and an OOMOL-connected Linkup API key. <br>
Mitigation: Install only after reviewing the oo CLI installation route and connect Linkup credentials through the user's OOMOL account. <br>
Risk: Live connector schemas and upstream defaults can change. <br>
Mitigation: Inspect the action schema with oo connector schema before constructing each payload. <br>
Risk: Billing or credential state can block Linkup actions. <br>
Mitigation: Use the documented authentication, connection, and credit-balance checks when commands return auth, scope, expiration, or billing errors. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-linkup) <br>
- [Linkup homepage](https://www.linkup.so) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill requires an installed and authenticated oo CLI plus a connected Linkup API key; action schemas should be inspected before sending payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
