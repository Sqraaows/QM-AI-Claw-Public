## Description: <br>
Provides read-only Unsplash photo and topic search, listing, and retrieval through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to search, list, and retrieve Unsplash photos and curated topic data without calling the Unsplash API directly. It is intended for read-only media discovery workflows through an OOMOL-connected Unsplash account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Unsplash account and allows the agent to run oo connector commands. <br>
Mitigation: Install and authenticate the OOMOL CLI only from trusted sources, connect the intended Unsplash account, and run the disclosed read-only actions. <br>
Risk: Connector schemas and upstream Unsplash fields can change. <br>
Mitigation: Fetch the live action schema with oo connector schema before building each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-unsplash) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Unsplash homepage](https://unsplash.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON data, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before constructing JSON payloads; available actions are read-only get, list, and search operations.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
