## Description: <br>
sevdesk helps an agent read, create, update, and delete sevdesk contact data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and finance teams use this skill to manage sevdesk contacts from an agent workflow. It supports read-only contact lookup/listing and state-changing create, update, and delete actions with confirmation guidance. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected sevdesk account and trusted OOMOL credential brokerage. <br>
Mitigation: Install only if OOMOL is trusted for this connection and grant the minimum sevdesk permissions appropriate for the intended tasks. <br>
Risk: Create and update actions can change sevdesk contact records, and delete actions can remove contact data. <br>
Mitigation: Review payloads before create or update operations and require explicit user approval before destructive delete operations. <br>
Risk: First-time setup may involve installing the oo CLI through platform-specific installer commands. <br>
Mitigation: Review OOMOL's official installation instructions or installer script before running curl-to-shell or PowerShell installer commands. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-sevdesk) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [sevdesk homepage](https://sevdesk.com) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and a connected sevdesk account; action schemas are inspected before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
