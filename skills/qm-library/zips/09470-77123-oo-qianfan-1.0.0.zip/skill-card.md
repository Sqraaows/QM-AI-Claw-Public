## Description: <br>
Baidu Qianfan lets an agent operate Baidu Qianfan for model discovery, generation, embeddings, reranking, OCR, files, batches, and stored responses through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to access Baidu Qianfan AI workflows from an agent, including chat and completion calls, image and video generation, embeddings, reranking, OCR, file handling, and batch prediction. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can perform account-scoped, billable Baidu Qianfan actions, including uploads, generation, batch creation, cancellation, and deletion. <br>
Mitigation: Review payloads, targets, and expected effects before approving write, cancel, delete, upload, generation, OCR, or batch actions. <br>
Risk: Generation, batch, OCR, and file workflows may submit user-provided content to Baidu Qianfan. <br>
Mitigation: Send only content that is authorized for the connected account and appropriate for the provider workflow. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-qianfan) <br>
- [Baidu Qianfan homepage](https://qianfan.cloud.baidu.com) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an OOMOL-connected Baidu Qianfan account; live connector schemas should be checked before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
