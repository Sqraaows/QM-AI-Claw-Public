## Description: <br>
Outlook (microsoft.com). Use this skill for ANY Outlook request: reading, creating, and updating data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees and external users use this skill to operate an OOMOL-connected Outlook mailbox from an agent, including reading messages, managing drafts, sending email, and updating mailbox settings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a brokered Outlook connection that can access mailbox data through granted scopes. <br>
Mitigation: Install only if you trust OOMOL to broker the Outlook connection and review requested scopes during connection. <br>
Risk: State-changing actions can send email, modify drafts, or update mailbox settings. <br>
Mitigation: Require explicit user confirmation of the exact payload and intended effect before running create, update, send, reply, or settings-write actions. <br>


## Reference(s): <br>
- [ClawHub Outlook Skill](https://clawhub.ai/oomol/oo-outlook) <br>
- [Outlook Homepage](https://www.microsoft.com/microsoft-365/outlook/email-and-calendar-software-microsoft-outlook) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing Outlook action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence metadata and release) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
