## Description: <br>
Fireflies lets an agent operate a connected Fireflies account to read, create, update, and delete meeting, transcript, AskFred, bite, user, channel, and workspace data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external collaborators, and developers use this skill to work with Fireflies meeting data from an agent, including transcript lookup, AskFred conversations, bite creation, channel and privacy updates, and workspace administration. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Fireflies meeting transcripts, user information, channels, bites, AskFred threads, and AI app outputs when authorized. <br>
Mitigation: Install only when the user trusts OOMOL's connector path and intends the agent to access the connected Fireflies account. <br>
Risk: Create, update, delete, privacy, channel, and user-role actions can alter or remove Fireflies workspace data. <br>
Mitigation: Confirm the exact action, target, payload, and intended effect with the user before write actions, and require explicit approval before destructive or administrative changes. <br>
Risk: The skill requires sensitive credentials through the connected Fireflies account. <br>
Mitigation: Use the connected-account flow rather than exposing raw API tokens, and only reconnect or refresh credentials when an auth or connection error requires it. <br>


## Reference(s): <br>
- [ClawHub Fireflies skill page](https://clawhub.ai/oomol/oo-fireflies) <br>
- [Fireflies homepage](https://www.fireflies.ai) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an authenticated OOMOL-connected Fireflies account; live action schemas should be inspected before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
