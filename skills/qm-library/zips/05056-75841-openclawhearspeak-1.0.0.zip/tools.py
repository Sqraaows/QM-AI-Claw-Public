#!/usr/bin/env python3
# encoding: utf-8
"""
小右语音助手工具脚本
支持：重新创建会话、重新检测麦克风、重新校准底噪
"""

import json
import os
import sys

CONFIG_FILE = os.path.expanduser("~/.kws_config.json")


def load_config():
    """加载配置文件"""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {}


def save_config(config):
    """保存配置文件"""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    print(f"✅ 配置已保存到 {CONFIG_FILE}")


def reset_session():
    """重新创建会话：删除当前会话Key，下次启动自动创建新会话"""
    config = load_config()
    if "openclaw_session_key" in config:
        old_key = config["openclaw_session_key"]
        del config["openclaw_session_key"]
        save_config(config)
        print(f"✅ 已删除旧会话: {old_key}")
        print("🔄 下次启动时会自动创建新会话")
    else:
        print("ℹ️  当前没有保存的会话")
    return 0


def reset_microphone():
    """重新检测麦克风：删除麦克风配置，下次启动自动重新检测"""
    config = load_config()
    keys_to_remove = ["device", "auto_detect_done", "noise_threshold"]
    removed = []
    for key in keys_to_remove:
        if key in config:
            del config[key]
            removed.append(key)
    save_config(config)
    if removed:
        print(f"✅ 已清除麦克风配置: {', '.join(removed)}")
        print("🔄 下次启动时会自动重新检测和校准麦克风")
    else:
        print("ℹ️  当前没有麦克风配置")
    return 0


def show_config():
    """显示当前配置"""
    config = load_config()
    print("📋 当前配置:")
    print(json.dumps(config, indent=2, ensure_ascii=False))
    return 0


def print_help():
    """显示帮助"""
    print("""小右语音助手工具脚本

用法: python tools.py <命令>

可用命令:
  reset-session      重新创建会话（删除旧会话，下次启动自动创建新会话）
  reset-microphone   重新检测麦克风（清除麦克风配置，下次启动自动重新检测校准）
  config             显示当前配置
  help               显示此帮助

示例:
  python tools.py reset-session      # 重置会话
  python tools.py reset-microphone   # 重置麦克风
""")


def main():
    if len(sys.argv) < 2:
        print_help()
        return 1

    cmd = sys.argv[1].lower()

    if cmd == "reset-session":
        return reset_session()
    elif cmd == "reset-microphone":
        return reset_microphone()
    elif cmd == "config":
        return show_config()
    elif cmd == "help":
        print_help()
        return 0
    else:
        print(f"❌ 未知命令: {cmd}")
        print()
        print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
