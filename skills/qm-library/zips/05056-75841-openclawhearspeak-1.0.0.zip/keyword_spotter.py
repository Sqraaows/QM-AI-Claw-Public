#!/usr/bin/env python3
# encoding: utf-8
"""
小右语音助手 - 使用OpenClaw已配置的能力
KWS离线唤醒 → OpenClaw配置的硅基流动ASR → OpenClaw配置的硅基流动LLM → Edge-TTS
"""
import argparse
import time
import os
import sys
import subprocess
import random
import json
from pathlib import Path

import numpy as np
import sherpa_onnx
import requests
import asyncio

# 导入OpenClaw自定义客户端
from openclaw_custom_client.client import OpenClawGatewayClient

# ========== 配置 ==========
# 配置文件路径
CONFIG_FILE = os.path.expanduser("~/.kws_config.json")
# 提示音文件夹
RESPONSE_DIR = "/home/ok/kws/response"
# 默认设备
DEVICE = "auto"

# 从OpenClaw配置读取API Key
# 注意: 正在研究OpenClaw WebSocket RPC接口，未来会改成直接调用OpenClaw网关
# 当前阶段: 使用硅基流动API（OpenClaw内部也使用这个服务）确保功能可用
OPENCLAW_CONFIG_PATH = os.path.expanduser("~/.openclaw/openclaw.json")
SILICONFLOW_API_KEY = os.environ.get("SILICONFLOW_API_KEY", "")
SILICONFLOW_BASE_URL = os.environ.get("SILICONFLOW_BASE_URL", "https://api.siliconflow.cn/v1")

# 录制指令时长
RECORD_SECONDS = 5
# 预生成应答音频目录
RESPONSE_DIR = "/home/ok/kws/response"


# ========== 关键词检测模型初始化 ==========
def keyword_spotter_init(model_path: str):
    """初始化关键词检测模型"""
    tokens = os.path.join(model_path, "tokens.txt")
    encoder = os.path.join(model_path, "encoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx")
    decoder = os.path.join(model_path, "decoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx")
    joiner = os.path.join(model_path, "joiner-epoch-12-avg-2-chunk-16-left-64.int8.onnx")
    keywords_file = os.path.join(model_path, "keywords.txt")

    print(f"📦 模型路径: {model_path}")

    return sherpa_onnx.KeywordSpotter(
        tokens=tokens,
        encoder=encoder,
        decoder=decoder,
        joiner=joiner,
        num_threads=2,
        keywords_file=keywords_file,
        provider="cpu",
    )


def read_wave(wave_filename: str) -> tuple[np.ndarray, int]:
    """读取WAV文件"""
    import wave
    with wave.open(wave_filename) as f:
        assert f.getnchannels() == 1, f.getnchannels()
        assert f.getsampwidth() == 2, f.getsampwidth()
        num_samples = f.getnframes()
        samples = f.readframes(num_samples)
        samples_int16 = np.frombuffer(samples, dtype=np.int16)
        samples_float32 = samples_int16.astype(np.float32)
        samples_float32 = samples_float32 / 32768
        return samples_float32, f.getframerate()


def keyword_spotter_run(kws, wave_filename: str) -> bool:
    """文件模式检测关键词"""
    if not os.path.exists(wave_filename):
        raise ValueError(f"{wave_filename} does not exist")
    
    samples, sample_rate = read_wave(wave_filename)

    tail_paddings = np.zeros(int(0.66 * sample_rate), dtype=np.float32)

    stream = kws.create_stream()
    stream.accept_waveform(sample_rate, samples)
    stream.accept_waveform(sample_rate, tail_paddings)
    stream.input_finished()
    while kws.is_ready(stream):
        kws.decode_stream(stream)
        r = kws.get_result(stream)
        if r != "":
            print(f"✅ 检测到关键词: [{r}]")
            return True
    return False


# ========== OpenClaw能力调用 ==========
def audio_to_text_openclaw(audio_path: str) -> str:
    """语音转文字 - 使用OpenClaw配置的硅基流动ASR"""
    print(f"🎙️  [OpenClaw ASR] 语音识别: {audio_path}")
    try:
        if not SILICONFLOW_API_KEY:
            print("⚠️ 未设置SILICONFLOW_API_KEY环境变量")
            print("💡 请执行: export SILICONFLOW_API_KEY=your_api_key")
            return ""
        
        url = f"{SILICONFLOW_BASE_URL}/audio/transcriptions"
        headers = {"Authorization": f"Bearer {SILICONFLOW_API_KEY}"}
        
        with open(audio_path, "rb") as f:
            files = {"file": f}
            data = {"model": "FunAudioLLM/SenseVoiceSmall", "language": "zh"}
            
            response = requests.post(url, headers=headers, files=files, data=data, timeout=30)
            response.raise_for_status()
            result = response.json()
            text = result.get("text", "").strip()
            print(f"📝 识别结果: {text}")
            return text
            
    except Exception as e:
        print(f"❌ OpenClaw ASR失败: {e}")
        return ""


async def ask_openclaw_agent(question: str) -> str:
    """LLM对话 - 使用OpenClaw自定义客户端"""
    print(f"🤖 [OpenClaw Agent] 处理问题: {question}")
    try:
        # 获取或创建会话
        session_key = await get_or_create_session()
        
        async with OpenClawGatewayClient() as client:
            # 1. 发送前先记录history长度和最新消息ID，用于判断是否有新回复
            t0 = time.time()
            history_before = await client.get_history(session_key=session_key)
            history_len_before = len(history_before)
            last_message_id = None
            if history_before:
                last_message_id = history_before[0].get("id") or history_before[0].get("seq")
            print(f"   [耗时{time.time()-t0:.1f}s] 发送前history长度: {history_len_before}, 最新消息ID: {last_message_id}")
            
            # 2. 发送消息到OpenClaw Agent，提示回复适合语音合成且人性化
            t1 = time.time()
            print(f"   正在发送消息，会话: {session_key}")
            result = await client.send_message(
                message=f"请用中文回答我的问题，要求：1. 不要使用任何图标、emoji、特殊符号；2. 回答口语化，亲切自然像朋友聊天；3. 关键信息要完整，适当增加实用建议；4. 比如问天气可以加穿衣建议、出行提醒；5. 控制在100字左右，不要太长。我的问题是：{question}",
                session_key=session_key
            )
            print(f"   [耗时{time.time()-t1:.1f}s] send_message返回: {result}")
            
            if result.get("ok"):
                print(f"✅ 消息已发送到网关，时间: {time.strftime('%H:%M:%S')}")
                print(f"🦞 小龙虾正在处理信息，请耐心等待...")
                # 确保消息发送成功后再播放提示音（不阻塞！）
                play_prompt("processing.wav", block=False)
                
                # 用消息订阅的方式等待新消息（处理流式回复）
                # 注意：每个回调推送的是完整消息，不是增量分块，所以只保留最新的即可
                final_answer = None
                latest_answer = None
                last_update_time = time.time()
                start_time = time.time()
                max_wait_time = 60
                first_response_received = False  # 标记是否收到第一个流式应答
                
                # 常见的中间思考提示词，需要跳过
                thinking_patterns = ["我来查询", "我查一下", "查询中", "请稍候", "正在", "我来看", "让我", "好的，"]
                
                async def message_callback(role, text):
                    nonlocal final_answer, latest_answer, last_update_time, first_response_received
                    if role == "assistant" and text:
                        # 标记收到第一个应答
                        first_response_received = True
                        
                        # 检查是不是中间思考消息
                        for pattern in thinking_patterns:
                            if pattern in text:
                                print(f"   跳过中间思考消息: {text[:20]}...")
                                return
                        # 流式回复：每次推送的是完整消息，直接覆盖即可
                        latest_answer = text.strip()
                        last_update_time = time.time()
                        print(f"   收到回复更新: {text[:40]}...")
                
                # 状态机：每8秒提示用户一次，直到收到第一个应答
                # 注意：play_prompt是后台播放非阻塞，所以sleep时间就是实际间隔
                async def waiting_reminder():
                    while not first_response_received:
                        await asyncio.sleep(8)
                        if not first_response_received:
                            print(f"🦞 小龙虾正在处理中，请等待...")
                            play_prompt("processing.wav", block=False)
                
                # 开始监听消息
                watch_task = asyncio.create_task(
                    client.watch_messages(
                        session_key=session_key,
                        duration=max_wait_time,
                        callback=message_callback
                    )
                )
                
                # 启动等待提示状态机
                reminder_task = asyncio.create_task(waiting_reminder())
                
                # 等待流式回复完成（超过2.5秒没有新更新就认为结束）
                while time.time() - start_time < max_wait_time:
                    await asyncio.sleep(0.2)
                    # 如果有内容，且超过2.5秒没有新更新，认为回复完成
                    if latest_answer and time.time() - last_update_time > 2.5:
                        final_answer = latest_answer
                        break
                
                # 取消等待提示任务
                reminder_task.cancel()
                try:
                    await reminder_task
                except asyncio.CancelledError:
                    pass
                
                # 取消监听任务
                watch_task.cancel()
                try:
                    await watch_task
                except asyncio.CancelledError:
                    pass
                
                if final_answer:
                    print(f"💬 回复: {final_answer}")
                    return final_answer
                else:
                    print(f"⚠️ 等待回复超时")
                    return "抱歉，处理超时了，请稍后再试。"
            else:
                print(f"⚠️ 发送失败: {result}")
                return ""
                
    except Exception as e:
        print(f"❌ OpenClaw Agent失败: {e}")
        return ""


def text_to_speech_openclaw(text: str, output_path: str) -> bool:
    """文字转语音 - 使用Edge-TTS（OpenClaw内部也使用）"""
    print(f"🔊 [OpenClaw TTS] 语音合成: {text[:30]}...")
    try:
        mp3_file = "/tmp/tts_temp.mp3"
        subprocess.run([
            "edge-tts",
            "--voice", "zh-CN-XiaoxiaoNeural",
            "--text", text,
            "--write-media", mp3_file
        ], capture_output=True, timeout=30)
        
        # 转成wav格式播放
        subprocess.run([
            "ffmpeg", "-y", "-i", mp3_file,
            "-ar", "44100", "-ac", "2", "-f", "wav", output_path
        ], capture_output=True, timeout=10)
        
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            print(f"✅ 语音合成完成")
            return True
        else:
            print(f"⚠️ TTS输出文件异常")
            return False
    except Exception as e:
        print(f"❌ OpenClaw TTS失败: {e}")
        return False


# ========== Edge-TTS Fallback ==========
def edge_tts_fallback(text: str):
    """Edge-TTS备用播放"""
    print(f"🔊 [Fallback] 播放: {text[:30]}...")
    try:
        mp3_file = "/tmp/response_fallback.mp3"
        subprocess.run(
            ["edge-tts", "--voice", "zh-CN-XiaoxiaoNeural", "--text", text, "--write-media", mp3_file],
            capture_output=True,
            timeout=30
        )
        wav_file = "/tmp/response_fallback.wav"
        subprocess.run(
            ["ffmpeg", "-y", "-i", mp3_file, "-ar", "44100", "-ac", "2", "-f", "wav", wav_file],
            capture_output=True,
            timeout=10
        )
        subprocess.run(["aplay", wav_file], capture_output=True, timeout=30)
        print(f"✅ Fallback播放完成")
        return True
    except Exception as e:
        print(f"❌ Fallback TTS失败: {e}")
        return False


# ========== 应答播放 ==========
RESPONSE_PHRASES = ["我在", "在的呢", "请讲", "您说"]

def play_wake_response():
    """播放唤醒应答音 - 只使用数字编号的应答音频"""
    # 只选 1.wav, 2.wav 这样的应答文件，排除 please_speak.wav 等
    audio_files = [f for f in os.listdir(RESPONSE_DIR) 
                   if f.endswith(".wav") and f[0].isdigit()]
    if not audio_files:
        print("⚠️ 没有预生成音频")
        edge_tts_fallback(random.choice(RESPONSE_PHRASES))
        return
    
    selected = random.choice(audio_files)
    audio_path = os.path.join(RESPONSE_DIR, selected)
    
    print(f"🔊 唤醒应答")
    try:
        subprocess.run(["aplay", audio_path], capture_output=True, timeout=5)
    except Exception as e:
        print(f"⚠️ 播放失败: {e}")
        edge_tts_fallback(random.choice(RESPONSE_PHRASES))


# ========== 麦克风自动探测 ==========
def analyze_audio(wav_path: str) -> dict:
    """
    智能分析WAV文件，判断是否包含真实语音
    
    Returns:
        {volume: 平均音量, std: 音量标准差, max: 最大音量, has_voice: 是否有真实语音}
    """
    try:
        import wave
        with wave.open(wav_path, 'rb') as wf:
            frames = wf.readframes(wf.getnframes())
            samples = np.frombuffer(frames, dtype=np.int16).astype(np.float32)
            
            if len(samples) == 0:
                return {"volume": 0, "std": 0, "max": 0, "has_voice": False}
            
            # 分帧计算音量（每帧100ms）
            frame_size = 1600  # 16kHz * 0.1s
            num_frames = len(samples) // frame_size
            frame_volumes = []
            
            for i in range(num_frames):
                frame = samples[i * frame_size : (i + 1) * frame_size]
                rms = np.sqrt(np.mean(frame ** 2))
                frame_volumes.append(rms)
            
            frame_volumes = np.array(frame_volumes)
            
            avg_volume = np.mean(frame_volumes)
            std_volume = np.std(frame_volumes)
            max_volume = np.max(frame_volumes)
            
            # 智能判断真实语音的阈值：
            # 1. 标准差 > 80（有明显波动）
            # 2. 最大音量 > 平均音量 * 1.5（有明显峰值）
            # 3. 最大音量 > 200（不是静音
            has_voice = (
                std_volume > 80 and 
                max_volume > avg_volume * 1.5 and 
                max_volume > 200
            )
            
            return {
                "volume": avg_volume,
                "std": std_volume,
                "max": max_volume,
                "has_voice": has_voice
            }
    except Exception as e:
        print(f"音频分析错误: {e}")
    return {"volume": 0, "std": 0, "max": 0, "has_voice": False}


def load_config() -> dict:
    """加载配置文件"""
    default_config = {
        "device": None,
        "auto_detect_done": False,
        "volume": 100
    }
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                return {**default_config, **config}
    except Exception as e:
        print(f"⚠️  配置文件加载失败: {e}")
    return default_config


def save_config(config: dict):
    """保存配置文件"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"⚠️  配置保存失败: {e}")


# OpenClaw会话缓存
_OPENCLAW_SESSION_KEY = None

async def get_or_create_session() -> str:
    """
    获取已有的会话，如果没有就创建新的
    
    Returns:
        session_key
    """
    global _OPENCLAW_SESSION_KEY
    
    # 先检查缓存
    if _OPENCLAW_SESSION_KEY:
        return _OPENCLAW_SESSION_KEY
    
    # 检查配置文件
    config = load_config()
    if config.get("openclaw_session_key"):
        _OPENCLAW_SESSION_KEY = config["openclaw_session_key"]
        print(f"✅ 使用已保存的OpenClaw会话")
        return _OPENCLAW_SESSION_KEY
    
    # 创建新会话（用时间戳确保标签唯一）
    print(f"🔗 创建新的OpenClaw会话...")
    async with OpenClawGatewayClient() as client:
        session = await client.create_session(
            agent_id="main",
            label=f"kws-voice-{int(time.time())}"
        )
        session_key = session["key"]
        
        # 保存到配置
        config["openclaw_session_key"] = session_key
        save_config(config)
        
        _OPENCLAW_SESSION_KEY = session_key
        print(f"✅ OpenClaw会话创建完成")
        return session_key


def play_prompt(wav_filename: str, block: bool = True):
    """播放预生成的提示音
    
    Args:
        wav_filename: 音频文件名
        block: 是否阻塞播放，默认True（阻塞）
    """
    try:
        wav_path = os.path.join(RESPONSE_DIR, wav_filename)
        if os.path.exists(wav_path):
            if block:
                subprocess.run(["aplay", wav_path], capture_output=True, timeout=5)
            else:
                # 后台播放，不阻塞
                subprocess.Popen(["aplay", wav_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
    except:
        pass
    return False


def detect_working_microphone(force_redetect: bool = False) -> str:
    """
    自动探测可用的麦克风设备（带音量检测，排除静音设备和板载声卡）
    优先使用配置文件中保存的设备
    
    Args:
        force_redetect: 强制重新探测，忽略配置
    
    Returns:
        第一个可用的设备字符串，如 "plughw:1,0"
    """
    import subprocess
    
    config = load_config()
    
    # 1. 如果不是强制重新探测，先尝试配置文件中的设备
    if not force_redetect and config.get("device") and config.get("auto_detect_done"):
        last_device = config["device"]
        print(f"🔍 使用配置设备: {last_device}")
        try:
            test_file = "/tmp/mic_test_last.wav"
            result = subprocess.run(
                ["arecord", "-D", last_device, "-f", "S16_LE", "-r", "16000", "-c", "1", "-d", "1", test_file],
                capture_output=True,
                timeout=3
            )
            if result.returncode == 0:
                print(f"✅ 设备 {last_device} 正常")
                return last_device
            else:
                print(f"⚠️  设备 {last_device} 不可用，重新探测...")
        except Exception as e:
            print(f"⚠️  设备测试失败: {e}")
    
    print("\n🔍 开始自动探测麦克风设备")
    print("=" * 50)
    
    # 音量阈值：超过这个值才认为有真实麦克风
    VOLUME_THRESHOLD = 50.0
    
    # 1. 先获取所有音频捕获设备，带设备名称
    try:
        result = subprocess.run(
            ["arecord", "-l"],
            capture_output=True,
            text=True,
            timeout=5
        )
        cards = []
        for line in result.stdout.split("\n"):
            if line.startswith("card "):
                # card 1: Device [USB PnP Sound Device], device 0: USB Audio [USB Audio]
                import re
                match = re.search(r"card (\d+).*\[(.*?)\].*device (\d+)", line)
                if match:
                    card = match.group(1)
                    card_name = match.group(2)
                    device = match.group(3)
                    # 标记是否是USB设备
                    is_usb = "USB" in card_name or "PnP" in card_name
                    # 排除板载声卡
                    if "HDA Intel" in card_name or "PCH" in card_name:
                        print(f"   ⏭️  跳过板载声卡: card {card} [{card_name}]")
                        continue
                    cards.append((card, device, is_usb, card_name))
    except Exception as e:
        print(f"⚠️  获取设备列表失败: {e}")
        cards = [("1", "0", True, "USB Fallback")]
    
    # 2. USB设备优先排序
    cards.sort(key=lambda x: -x[2])  # USB设备排在前面
    
    working_devices = []
    
    # 3. 逐个测试设备 - 每个设备单独提示
    for card, device, is_usb, card_name in cards:
        device_path = f"plughw:{card},{device}"
        usb_tag = " [USB]" if is_usb else ""
        
        # 提示用户当前测试的设备
        print(f"\n📡 正在测试设备: {device_path}{usb_tag}")
        print(f"   🎤 请对着这个麦克风说几句话！")
        # 播放提示音
        play_prompt("please_speak.wav")
        
        try:
            test_file = f"/tmp/mic_test_{device_path.replace(':','_').replace(',','_')}.wav"
            # 录3秒，给用户时间说话
            result = subprocess.run(
                ["arecord", "-D", device_path, "-f", "S16_LE", "-r", "16000", "-c", "1", "-d", "3", test_file],
                capture_output=True,
                timeout=5
            )
            
            if result.returncode == 0 and os.path.exists(test_file) and os.path.getsize(test_file) > 1000:
                # 🧠 智能分析：区分底噪和真实语音
                analysis = analyze_audio(test_file)
                volume = analysis["volume"]
                has_voice = analysis["has_voice"]
                std = analysis["std"]
                max_v = analysis["max"]
                
                if has_voice:
                    print(f"✅ 检测到真实语音! (音量:{volume:.0f}, 波动:{std:.0f})")
                    # 尝试把音量调到最大
                    try:
                        subprocess.run(
                            ["amixer", "set", "Mic", "100%", "-D", f"hw:{card}"],
                            capture_output=True,
                            timeout=2
                        )
                    except:
                        pass
                    # 🎯 有真实语音的设备权重极高，并且按语音波动大小排序
                    voice_score = 100000 + std * 100 + volume
                    working_devices.append((device_path, volume, voice_score, has_voice, std))
                elif volume >= VOLUME_THRESHOLD:
                    print(f"⚠️  只有底噪 (音量:{volume:.0f}, 波动:{std:.0f})")
                    # 只有底噪，权重低
                    noise_score = 1000 + volume
                    working_devices.append((device_path, volume, noise_score, False, std))
                else:
                    print(f"❌ 静音 (音量:{volume:.0f})")
            else:
                print("❌ 录制失败")
        except Exception as e:
            print(f"❌ 错误: {e}")
    
    # 4. 显示所有可用设备供用户确认
    if working_devices:
        print("\n📋 检测到以下可用设备:")
        working_devices.sort(key=lambda x: -x[2])  # 按得分降序
        for i, device_info in enumerate(working_devices, 1):
            device = device_info[0]
            has_voice = device_info[3]
            voice_tag = " 🎤 有语音" if has_voice else " 🔊 只有底噪"
            marker = " [✅ 推荐]" if i == 1 else ""
            print(f"   {i}. {device}{voice_tag}{marker}")
        
        # 优先选检测到真实语音的设备
        voice_devices = [d for d in working_devices if d[3]]
        if voice_devices:
            best_device = voice_devices[0][0]
            print(f"\n🎯 自动选择: {best_device} (检测到真实语音)")
        else:
            best_device = working_devices[0][0]
            print(f"\n⚠️  未检测到语音，使用音量最大的设备: {best_device}")
        
        print(f"\n💡 重新探测: python3 keyword_spotter.py --redetect")
        print(f"💡 手动指定: python3 keyword_spotter.py --device plughw:1,0")
        
        # 保存到配置文件
        config["device"] = best_device
        config["auto_detect_done"] = True
        save_config(config)
        
        # 播放完成提示音
        play_prompt("detection_done.wav")
        
        return best_device
    
    # 5. 如果音量检测都失败，列出所有设备让用户试
    print("\n⚠️  未检测到有声音输入，尝试所有设备:")
    fallback_devices = ["plughw:1,0", "plughw:0,0", "plughw:2,0"]
    for dev in fallback_devices:
        print(f"   尝试: {dev}")
        try:
            test_file = "/tmp/mic_test_fallback.wav"
            result = subprocess.run(
                ["arecord", "-D", dev, "-f", "S16_LE", "-r", "16000", "-c", "1", "-d", "1", test_file],
                capture_output=True,
                timeout=3
            )
            if result.returncode == 0:
                print(f"   ✅ {dev} 可用")
                config["device"] = dev
                config["auto_detect_done"] = True
                save_config(config)
                return dev
        except:
            pass
    
    print("   💡 使用 plughw:1,0")
    config["device"] = "plughw:1,0"
    config["auto_detect_done"] = True
    save_config(config)
    return "plughw:1,0"


def safe_stop_arecord(process):
    """安全停止 arecord 进程，确保设备释放"""
    try:
        if process and process.poll() is None:
            try:
                process.stdout.close()
            except:
                pass
            try:
                process.terminate()
                process.wait(timeout=2)
            except:
                try:
                    process.kill()
                    process.wait(timeout=1)
                except:
                    pass
    except:
        pass
    # 额外等待，确保设备完全释放
    time.sleep(0.3)


# 全局存储：每个设备的动态校准阈值
_DEVICE_NOISE_THRESHOLD = {}

def calibrate_noise(device: str, calibrate_seconds: float = 2.0) -> float:
    """
    动态校准设备底噪，计算语音检测阈值
    
    Returns:
        建议的音量阈值
    """
    sample_rate = 16000
    chunk_duration = 0.05
    chunk_samples = int(sample_rate * chunk_duration)
    
    print(f"🎚️  正在校准麦克风底噪，请保持安静...")
    play_prompt("calibrate_noise.wav")
    
    arecord_cmd = [
        "arecord", "-D", device, "-f", "S16_LE", "-r", str(sample_rate),
        "-c", "1", "-t", "raw", "-q", "-"
    ]
    
    process = subprocess.Popen(arecord_cmd, stdout=subprocess.PIPE, bufsize=chunk_samples * 2)
    
    num_frames = int(calibrate_seconds / chunk_duration)
    volumes = []
    
    for i in range(num_frames):
        raw_data = process.stdout.read(chunk_samples * 2)
        if len(raw_data) == 0:
            break
        samples = np.frombuffer(raw_data, dtype=np.int16).astype(np.float32)
        rms = np.sqrt(np.mean(samples ** 2))
        volumes.append(rms)
    
    process.terminate()
    try:
        process.wait(timeout=1)
    except:
        pass
    time.sleep(0.2)  # 确保设备释放
    
    volumes = np.array(volumes)
    max_noise = np.max(volumes)
    
    # 阈值 = 最大底噪 × 2.5，留足够余量
    threshold = max_noise * 2.5
    print(f"   最大底噪: {max_noise:.0f}, 设置阈值: {threshold:.0f}")
    play_prompt("calibrate_done.wav")
    
    return threshold


def calibrate_device_noise(device: str, force: bool = False) -> float:
    """校准指定设备的底噪，默认只校准一次"""
    global _DEVICE_NOISE_THRESHOLD
    if force or device not in _DEVICE_NOISE_THRESHOLD:
        _DEVICE_NOISE_THRESHOLD[device] = calibrate_noise(device)
    return _DEVICE_NOISE_THRESHOLD[device]


def get_device_threshold(device: str) -> float:
    """获取设备的阈值，没有校准过就先校准"""
    return calibrate_device_noise(device)


def record_with_vad(device: str, output_file: str, max_seconds: int = 10, 
                   silence_seconds: float = 1.5, wait_voice_timeout: int = 5) -> bool:
    """
    带VAD（语音活动检测）的录音函数
    
    Args:
        device: 音频设备
        output_file: 输出文件路径
        max_seconds: 最长录音时间（说话开始后）
        silence_seconds: 说话后静音多久自动结束（默认1.5秒，避免用户还没说完
        wait_voice_timeout: 等待说话超时，没说话几秒就退出（默认5秒）
    
    Returns:
        True 表示检测到语音，False 表示全程静音
    """
    sample_rate = 16000
    chunk_duration = 0.05  # 50ms 一帧，更快响应
    chunk_samples = int(sample_rate * chunk_duration)
    
    # 动态获取音量阈值（自动校准底噪）
    VOLUME_THRESHOLD = get_device_threshold(device)
    # 需要连续多少帧有声音才确认开始说话（防底噪）
    VOICE_TRIGGER_FRAMES = 5
    # 需要连续多少帧静音才停止
    silence_frames_threshold = int(silence_seconds / chunk_duration)
    # 等待说话超时帧数
    wait_voice_frames = int(wait_voice_timeout / chunk_duration)
    
    voice_count = 0  # 连续有声音帧数
    
    arecord_cmd = [
        "arecord", "-D", device, "-f", "S16_LE", "-r", str(sample_rate),
        "-c", "1", "-t", "raw", "-q", "-"
    ]
    
    process = None
    all_frames = []
    silence_count = 0
    has_voice = False
    total_frames = 0
    
    try:
        process = subprocess.Popen(arecord_cmd, stdout=subprocess.PIPE, bufsize=chunk_samples * 2)
        
        while True:
            raw_data = process.stdout.read(chunk_samples * 2)
            if len(raw_data) == 0:
                break
            
            total_frames += 1
            all_frames.append(raw_data)
            
            # 计算当前帧音量
            samples = np.frombuffer(raw_data, dtype=np.int16).astype(np.float32)
            rms = np.sqrt(np.mean(samples ** 2))
            
            if rms > VOLUME_THRESHOLD:
                # 检测到说话
                if not has_voice:
                    print(f"   🎙️ 检测到说话，开始录音...")
                has_voice = True
                silence_count = 0  # 重置静音计数
            elif has_voice:
                # 已经检测到语音，现在开始检测静音
                silence_count += 1
                if silence_count >= silence_frames_threshold:
                    # 静音足够长时间，停止录音
                    print(f"   ⏹️  检测到停止说话结束")
                    break
            else:
                # 还没检测到说话，检查是否超时
                if total_frames >= wait_voice_frames:
                    # 3秒没说话，退出
                    print(f"   ⏰  等待说话超时")
                    break
            
            # 最长录音时间限制（从检测到说话开始算）
            if has_voice and len(all_frames) >= int(max_seconds / chunk_duration):
                break
    finally:
        safe_stop_arecord(process)
    
    # 保存录音文件
    if all_frames:
        import wave
        with wave.open(output_file, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(b''.join(all_frames))
    
    return has_voice


# ========== 实时流式检测 ==========
def keyword_spot_streaming(kws, device: str = DEVICE, callback=None):
    """持续流式采集麦克风并进行关键词检测"""
    print(f"\n🎙️  启动实时关键词检测，使用设备: {device}")
    print("💡  说 '小右' 唤醒，按 Ctrl+C 退出\n")
    
    sample_rate = 16000
    chunk_duration = 0.5
    chunk_samples = int(sample_rate * chunk_duration)
    
    stream = kws.create_stream()
    
    arecord_cmd = [
        "arecord",
        "-D", device,
        "-f", "S16_LE",
        "-r", str(sample_rate),
        "-c", "1",
        "-t", "raw",
        "-q",
        "-"
    ]
    
    process = None
    
    try:
        process = subprocess.Popen(arecord_cmd, stdout=subprocess.PIPE, bufsize=chunk_samples * 2)
        
        while True:
            raw_data = process.stdout.read(chunk_samples * 2)
            if len(raw_data) == 0:
                break
            
            samples_int16 = np.frombuffer(raw_data, dtype=np.int16)
            samples_float32 = samples_int16.astype(np.float32) / 32768.0
            
            stream.accept_waveform(sample_rate, samples_float32)
            
            while kws.is_ready(stream):
                kws.decode_stream(stream)
                result = kws.get_result(stream)
                if result != "":
                    print(f"\n✅ 检测到关键词: [{result}]")
                    
                    # 安全停止采集，确保设备释放
                    safe_stop_arecord(process)
                    
                    # 执行回调（传入当前使用的设备）
                    if callback is not None:
                        import asyncio
                        asyncio.run(callback(result, device))
                    
                    # 重置，重新开始
                    stream = kws.create_stream()
                    print("\n💡 等待下一次唤醒...")
                    process = subprocess.Popen(arecord_cmd, stdout=subprocess.PIPE, bufsize=chunk_samples * 2)
                    break
                
    except KeyboardInterrupt:
        print("\n👋 用户中断，停止监听")
        safe_stop_arecord(process)
        return
    except Exception as e:
        print(f"❌ 音频采集错误: {e}")
        safe_stop_arecord(process)
        raise


async def process_one_question(device: str) -> bool:
    """
    处理一轮问答
    
    Returns:
        True 表示检测到用户说话并处理完成，False 表示没说话/超时
    """
    output_file = "/tmp/command.wav"
    
    print(f"\n🎤 请说话...")
    
    # 带VAD录制，最长10秒，静音0.6秒自动结束
    has_voice = record_with_vad(device, output_file, max_seconds=10, silence_seconds=1.5)
    
    if not has_voice:
        print(f"🤫 没听到你说话")
        edge_tts_fallback("我没有听到你说话，我就先退下咯，有需要再叫我。")
        return False
    
    print(f"✅ 录制完成")
    
    # 3. OpenClaw ASR 语音转文字
    text = audio_to_text_openclaw(output_file)
    if not text:
        edge_tts_fallback("抱歉，我没听清你说的什么，能再说一遍吗？")
        return True  # 有说话但识别失败，让用户重试
    
    # 4. OpenClaw LLM 处理
    answer = await ask_openclaw_agent(text)
    if not answer:
        edge_tts_fallback("抱歉，服务暂时不可用")
        return True
    
    # 5. OpenClaw TTS 语音合成 + 播放
    tts_output = "/tmp/response.wav"
    success = text_to_speech_openclaw(answer, tts_output)
    if success:
        print(f"🔊 播放回复...")
        subprocess.run(["aplay", tts_output], capture_output=True, timeout=30)
        print(f"✅ 播放完成")
    else:
        edge_tts_fallback(answer)
    
    print("\n" + "=" * 60)
    return True


# ========== 完整语音助手流程 ==========
async def on_keyword_detected(keyword: str, device: str):
    """关键词检测到后的完整处理流程 - 支持连续对话"""
    print(f"\n🚀 唤醒成功")
    
    # 1. 播放唤醒应答
    play_wake_response()
    
    # 2. 连续对话逻辑：一次没说话就退下，说话了可以继续问
    while True:
        # 处理一轮问答
        has_interaction = await process_one_question(device)
        
        if not has_interaction:
            # 没检测到说话，直接退下，等待下次唤醒
            break
        # 用户说话了，继续下一轮对话
    
    print(f"💤 回到等待唤醒状态")


# ========== 主程序 ==========
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="小右语音助手")
    parser.add_argument("--mode", type=str, default="streaming",
                       choices=["file", "streaming"],
                       help="运行模式")
    parser.add_argument("--file", type=str, default="./test.wav",
                       help="文件模式下的音频路径")
    parser.add_argument("--device", type=str, default=DEVICE,
                       help="音频设备")
    parser.add_argument("--redetect", action="store_true",
                       help="强制重新探测麦克风")
    parser.add_argument("--gen-prompts", action="store_true",
                       help="生成所有提示音")
    parser.add_argument("--model", type=str,
                       default="./sherpa-onnx-kws-zipformer-wenetspeech-3.3M-2024-01-01",
                       help="KWS模型路径")
    
    args_parsed = parser.parse_args()
    
    # 生成提示音
    if args_parsed.gen_prompts:
        print("🔊 生成提示音...")
        prompts = [
            ("please_speak.wav", "请对着麦克风说几句话"),
            ("detection_done.wav", "麦克风检测完成，开始监听"),
            ("calibrate_noise.wav", "正在校准麦克风底噪，请保持环境安静"),
            ("calibrate_done.wav", "麦克风底噪校准完成！"),
            ("processing.wav", "小龙虾正在处理信息，请耐心等待..."),
            ("processing_fast.wav", "处理中..."),
        ]
        # 随机唤醒应答（6种不同应答）
        wake_responses = ["我在", "在的", "请说", "您说", "嗯", "在"]
        for i, text in enumerate(wake_responses, 1):
            prompts.append((f"{i}.wav", text))
        
        for filename, text in prompts:
            mp3_file = f"/tmp/{filename}.mp3"
            wav_file = os.path.join(RESPONSE_DIR, filename)
            subprocess.run([
                "edge-tts", "--voice", "zh-CN-XiaoxiaoNeural",
                "--text", text, "--write-media", mp3_file
            ], capture_output=True)
            subprocess.run([
                "ffmpeg", "-y", "-i", mp3_file, "-ar", "44100", "-ac", "2", "-f", "wav", wav_file
            ], capture_output=True)
            print(f"   ✅ {filename}")
        print("✅ 提示音生成完成！")
        exit(0)
    
    # 自动探测麦克风
    if args_parsed.device == "auto":
        args_parsed.device = detect_working_microphone(force_redetect=args_parsed.redetect)
    
    print("=" * 60)
    print("🦞 小右语音助手")
    print("=" * 60)
    print(f"📝 架构: KWS离线唤醒 → OpenClaw配置的ASR/LLM/TTS")
    print(f"🎯 唤醒词: 小右")
    print()
    
    # 检查API Key
    if not SILICONFLOW_API_KEY:
        print("⚠️ 警告: 未设置SILICONFLOW_API_KEY环境变量")
        print("💡 请执行: export SILICONFLOW_API_KEY=your_api_key")
    else:
        print(f"✅ OpenClaw配置读取成功")
    
    # 初始化模型
    print("\n⚙️  初始化关键词检测模型...")
    kws = keyword_spotter_init(args_parsed.model)
    print("✅ 模型初始化完成！")
    
    # 提前校准麦克风底噪
    print("\n🎚️  正在校准麦克风底噪，请保持环境安静...")
    calibrate_device_noise(args_parsed.device, force=True)
    print("✅ 麦克风底噪校准完成！")
    
    if args_parsed.mode == "file":
        # 文件检测模式
        wave_filename = args_parsed.file
        result = keyword_spotter_run(kws, wave_filename)
        print(f"检测结果: {result}")
    else:
        # 实时流式模式 - 完整语音助手
        keyword_spot_streaming(
            kws,
            device=args_parsed.device,
            callback=on_keyword_detected
        )
