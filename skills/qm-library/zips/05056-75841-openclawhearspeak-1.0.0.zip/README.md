# 小右语音助手 V1.0.0

基于OpenClaw的离线唤醒语音助手，支持完整的语音对话功能。

## 🚀 快速开始

### 1. 硬件要求

**必备硬件：**
- ✅ USB麦克风（推荐免驱USB麦克风，不推荐3.5mm接口）
- ✅ USB扬声器/耳机（或USB声卡 + 3.5mm音箱）

**测试硬件：**
```bash
# 查看录音设备
arecord -l

# 查看播放设备
aplay -l
```

### 2. 安装依赖

```bash
# Python依赖
pip install -r requirements.txt

# 系统依赖
sudo apt install alsa-utils sox ffmpeg
pip install edge-tts
```

### 3. 配置API Key

```bash
export SILICONFLOW_API_KEY=your_api_key_here
```

建议写入 `~/.bashrc` 或 `~/.zshrc` 永久生效。

### 4. 自动下载模型和生成提示音

首次启动时会自动完成：
- ✅ 下载KWS唤醒模型 (~5MB)
- ✅ 生成所有提示音文件

### 5. 自定义唤醒词

默认唤醒词：**小右**

```bash
# 设置自定义唤醒词
./start.sh set-keyword 小爱同学
./start.sh set-keyword 小龙小龙
```

修改后需要重启服务生效。

### 6. 启动语音助手

#### 前台运行（可以看到实时日志）
```bash
./start.sh
# 或
./start.sh start
```

#### 后台运行（守护进程，关闭终端也不会退出）
```bash
./start.sh start -d
```

#### 查看运行状态
```bash
./start.sh status
```

#### 查看实时日志
```bash
./start.sh logs
```

#### 停止后台服务
```bash
./start.sh stop
```

#### 重启服务
```bash
./start.sh restart
```

#### 查看帮助
```bash
./start.sh help
```

## 🎯 功能特性

- ✅ 离线关键词唤醒（唤醒词：小右）
- ✅ VAD语音端点检测，自动开始/结束录音
- ✅ OpenClaw硅基流动ASR语音识别
- ✅ OpenClaw Agent智能对话，流式回复
- ✅ 等待提示状态机（每8秒播放一次提示音）
- ✅ Edge-TTS语音合成，自然语音播放
- ✅ 麦克风自动校准和底噪检测
- ✅ 独立干净会话，不和Web UI冲突
- ✅ 人性化提示词，带穿衣/出行等实用建议
- ✅ 支持重新创建会话、重新检测麦克风、重新校准底噪

## 📖 使用方法

### 基本使用

1. 说"小右"唤醒语音助手
2. 听到提示音后开始提问
3. 说完后会自动结束录音并处理
4. 听到AI语音回答后可继续提问

### 管理工具

```bash
# 查看当前配置
python3 tools.py config

# 重新创建会话
python3 tools.py reset-session

# 重新检测麦克风
python3 tools.py reset-microphone

# 查看帮助
python3 tools.py help
```

### 命令行参数

```bash
# 指定麦克风设备
python3 keyword_spotter.py --device plughw:1,0

# 强制重新检测麦克风
python3 keyword_spotter.py --redetect

# 生成提示音文件
python3 keyword_spotter.py --gen-prompts
```

## 📁 目录结构

```
kws/
├── keyword_spotter.py          # 主程序
├── tools.py                   # 管理工具
├── start.sh                   # 启动脚本
├── SKILL.md                   # 详细功能文档
├── README.md                  # 本文档
├── requirements.txt           # Python依赖
├── openclaw_custom_client/    # OpenClaw网关客户端
├── response/                  # 预生成提示音
└── sherpa-onnx-kws-zipformer-wenetspeech-3.3M-2024-01-01/  # KWS模型
```

## ⚙️ 环境变量

| 变量名 | 说明 | 必填 |
|--------|------|------|
| `SILICONFLOW_API_KEY` | 硅基流动API Key | ✅ |
| `SILICONFLOW_BASE_URL` | API地址（默认 https://api.siliconflow.cn/v1） | ❌ |

## 🔧 常见问题

**Q: 提示"未设置SILICONFLOW_API_KEY环境变量"**

A: 执行 `export SILICONFLOW_API_KEY=your_api_key`

**Q: 无法识别麦克风**

A: 执行 `python3 keyword_spotter.py --redetect` 重新检测

**Q: 录音总是提前结束**

A: 调整 `keyword_spotter.py` 中的 `silence_seconds` 参数，调大到2.0或更高

**Q: 唤醒不灵敏**

A: 确保环境安静，离麦克风不要太远，说话清晰

## 📄 详细文档

详见 [SKILL.md](./SKILL.md)

## 📝 注意事项

- 首次运行会自动检测麦克风和校准底噪，请保持环境安静
- 唤醒后请在5秒内开始说话，超时会自动退出
- 说话时请保持环境安静，避免背景噪音干扰
- 网关处理中每8秒会有一次语音提示，请耐心等待
