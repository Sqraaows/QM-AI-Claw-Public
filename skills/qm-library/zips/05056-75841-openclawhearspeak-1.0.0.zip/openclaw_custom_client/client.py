"""
OpenClaw Gateway WebSocket 客户端核心实现
"""

import asyncio
import json
import time
import base64
import os
from typing import Optional, Dict, Any, List
import websockets
from cryptography.hazmat.primitives import serialization


class OpenClawGatewayClient:
    """
    OpenClaw Gateway WebSocket 客户端
    
    自动从本地 OpenClaw 配置加载设备认证信息，开箱即用。
    
    示例:
        >>> client = OpenClawGatewayClient()
        >>> await client.connect()
        >>> await client.send_message("你好！")
        >>> await client.close()
    """
    
    def __init__(self, host: str = "localhost", port: int = 18789, 
                 identity_path: Optional[str] = None):
        """
        初始化客户端
        
        Args:
            host: Gateway 主机地址
            port: Gateway 端口
            identity_path: 设备认证配置目录（默认: ~/.openclaw/identity/）
        """
        self.host = host
        self.port = port
        self.ws = None
        self.request_id_counter = 0
        self.connected = False
        
        # 设备认证路径
        if identity_path is None:
            identity_path = os.path.expanduser("~/.openclaw/identity/")
        self.identity_path = identity_path
        
        # 加载本地设备认证
        self.device_auth = self._load_device_auth()
        self.device_keys = self._load_device_keys()
    
    def _load_device_auth(self) -> Dict[str, Any]:
        """从 device-auth.json 加载设备认证"""
        path = os.path.join(self.identity_path, "device-auth.json")
        with open(path) as f:
            return json.load(f)
    
    def _load_device_keys(self) -> Dict[str, Any]:
        """从 device.json 加载设备密钥"""
        path = os.path.join(self.identity_path, "device.json")
        with open(path) as f:
            return json.load(f)
    
    def get_next_request_id(self) -> str:
        """生成下一个请求 ID"""
        self.request_id_counter += 1
        return str(self.request_id_counter)
    
    async def connect(self) -> bool:
        """
        建立 WebSocket 连接并完成握手认证
        
        Returns:
            True 表示连接成功
        """
        uri = f"ws://{self.host}:{self.port}/ws"
        
        self.ws = await websockets.connect(uri)
        
        # 1. 等待挑战事件
        nonce = None
        while True:
            msg = await self.ws.recv()
            data = json.loads(msg)
            if data.get("event") == "connect.challenge":
                nonce = data["payload"]["nonce"]
                break
        
        # 2. 准备认证签名
        signed_at_ms = int(time.time() * 1000)
        device_id = self.device_auth["deviceId"]
        device_token = self.device_auth["tokens"]["operator"]["token"]
        
        private_key = serialization.load_pem_private_key(
            self.device_keys["privateKeyPem"].encode(),
            password=None
        )
        public_key = private_key.public_key()
        public_key_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        public_key_b64 = base64.urlsafe_b64encode(public_key_bytes).decode().rstrip("=")
        
        # 3. 构建 Ed25519 签名 (v2 格式)
        scopes = [
            "operator.admin",
            "operator.read",
            "operator.write",
            "operator.approvals",
            "operator.pairing",
            "operator.talk.secrets"
        ]
        
        payload = "|".join([
            "v2",
            device_id,
            "cli",
            "cli",
            "operator",
            ",".join(scopes),
            str(signed_at_ms),
            device_token,
            nonce
        ])
        
        signature = private_key.sign(payload.encode())
        signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip("=")
        
        # 4. 发送 connect RPC 请求
        connect_request = {
            "type": "req",
            "id": self.get_next_request_id(),
            "method": "connect",
            "params": {
                "minProtocol": 3,
                "maxProtocol": 3,
                "client": {
                    "id": "cli",
                    "displayName": "Python Custom Client",
                    "version": "1.0.0",
                    "platform": "linux",
                    "mode": "cli"
                },
                "role": "operator",
                "scopes": scopes,
                "caps": [],
                "device": {
                    "id": device_id,
                    "publicKey": public_key_b64,
                    "signature": signature_b64,
                    "signedAt": signed_at_ms,
                    "nonce": nonce
                },
                "auth": {
                    "deviceToken": device_token
                }
            }
        }
        
        await self.ws.send(json.dumps(connect_request))
        
        # 5. 等待连接响应
        while True:
            msg = await self.ws.recv()
            data = json.loads(msg)
            if data.get("type") == "res" and data.get("id") == connect_request["id"]:
                if data.get("ok"):
                    self.connected = True
                    return True
                else:
                    error = data.get("error", {})
                    raise Exception(f"连接失败: {error.get('message')} (code: {error.get('code')})")
    
    async def call_method(self, method: str, params: Optional[Dict[str, Any]] = None,
                          timeout: int = 30) -> Dict[str, Any]:
        """
        调用 Gateway RPC 方法
        
        Args:
            method: 方法名，如 sessions.send、sessions.list
            params: 参数字典
            timeout: 超时时间（秒）
        
        Returns:
            RPC 响应
        """
        if not self.ws or not self.connected:
            raise Exception("未连接到 Gateway")
        
        request_id = self.get_next_request_id()
        request = {
            "type": "req",
            "id": request_id,
            "method": method,
            "params": params or {}
        }
        
        await self.ws.send(json.dumps(request))
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                msg = await asyncio.wait_for(self.ws.recv(), timeout=1.0)
                data = json.loads(msg)
            except asyncio.TimeoutError:
                continue
            
            if data.get("id") == request_id:
                return data
        
        raise TimeoutError(f"调用 {method} 超时")
    
    async def list_sessions(self) -> List[Dict[str, Any]]:
        """
        列出所有会话
        
        Returns:
            会话列表
        """
        result = await self.call_method("sessions.list")
        if result.get("ok"):
            return result.get("payload", {}).get("sessions", [])
        raise Exception(f"获取会话列表失败: {result.get('error')}")
    
    async def create_session(self, agent_id: str = "main", label: Optional[str] = None) -> Dict[str, Any]:
        """
        创建新的独立会话
        
        Args:
            agent_id: Agent ID（默认 main）
            label: 会话标签（可选）
        
        Returns:
            新会话信息，包含 key、sessionId 等
        """
        params = {"agentId": agent_id}
        if label:
            params["label"] = label
        
        result = await self.call_method("sessions.create", params)
        if result.get("ok"):
            return result.get("payload", {})
        raise Exception(f"创建会话失败: {result.get('error')}")
    
    async def send_message(self, message: str, session_key: str = "agent:main:main") -> Dict[str, Any]:
        """
        发送消息到指定会话
        
        Args:
            message: 消息文本
            session_key: 会话 Key（默认主会话 agent:main:main）
        
        Returns:
            发送结果
        """
        return await self.call_method("sessions.send", {
            "key": session_key,
            "message": message
        })
    
    async def get_history(self, session_key: str = "agent:main:main") -> List[Dict[str, Any]]:
        """
        获取会话历史消息
        
        Args:
            session_key: 会话 Key
        
        Returns:
            消息列表
        """
        result = await self.call_method("chat.history", {
            "sessionKey": session_key
        })
        if result.get("ok"):
            return result.get("payload", {}).get("messages", [])
        raise Exception(f"获取历史失败: {result.get('error')}")
    
    async def get_run_status(self, run_id: str, session_key: str = "agent:main:main") -> Dict[str, Any]:
        """
        获取指定 run 的运行状态
        
        Args:
            run_id: 运行 ID（从 send_message 返回值中获取）
            session_key: 会话 Key
        
        Returns:
            运行状态信息，包含 status 等字段
        """
        result = await self.call_method("sessions.run.status", {
            "sessionKey": session_key,
            "runId": run_id
        })
        if result.get("ok"):
            return result.get("payload", {})
        raise Exception(f"获取run状态失败: {result.get('error')}")
    
    async def subscribe_messages(self, session_key: str = "agent:main:main") -> bool:
        """
        订阅会话消息事件
        
        Args:
            session_key: 会话 Key
        """
        result = await self.call_method("sessions.messages.subscribe", {
            "key": session_key
        })
        return result.get("ok", False)
    
    async def watch_messages(self, session_key: str = "agent:main:main", 
                             duration: int = 30, callback=None):
        """
        监听新消息
        
        Args:
            session_key: 会话 Key
            duration: 监听时长（秒）
            callback: 消息回调函数，接收 (role, text) 参数
        """
        await self.subscribe_messages(session_key)
        
        start_time = time.time()
        while time.time() - start_time < duration:
            try:
                msg = await asyncio.wait_for(self.ws.recv(), timeout=1.0)
                data = json.loads(msg)
                
                if data.get("type") == "event":
                    event_type = data.get("event")
                    
                    if event_type in ["session.message", "chat"]:
                        payload = data.get("payload", {})
                        message = payload.get("message", {}) or payload
                        
                        role = message.get("role")
                        content = message.get("content", "")
                        
                        if isinstance(content, list):
                            text = "".join([c.get("text", "") for c in content if c.get("type") == "text"])
                        else:
                            text = str(content)
                        
                        if callback and role and text:
                            await callback(role, text) if asyncio.iscoroutinefunction(callback) else callback(role, text)
            
            except asyncio.TimeoutError:
                continue
    
    async def close(self):
        """关闭连接"""
        if self.ws:
            await self.ws.close()
            self.connected = False
    
    async def __aenter__(self):
        """异步上下文管理器支持"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器支持"""
        await self.close()
