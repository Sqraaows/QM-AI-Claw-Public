#!/usr/bin/env python3
"""
openclaw_custom_client 命令行入口

直接运行包来启动交互式客户端：
    python -m openclaw_custom_client
"""

import asyncio
import argparse
from .client import OpenClawGatewayClient


async def interactive_shell(client: OpenClawGatewayClient):
    """交互式命令行"""
    print("\\n📟 OpenClaw 自定义客户端 - 交互式 Shell (输入 exit 退出)")
    print("可用命令:")
    print("  sessions              - 列出所有会话")
    print("  send <消息>           - 发送消息到主会话")
    print("  history               - 查看最近 10 条消息历史")
    print("  watch                 - 监听 30 秒新消息")
    print("  create <标签>         - 创建新会话")
    print("  call <方法名> [JSON]  - 调用任意 RPC 方法")
    print()
    
    while True:
        try:
            line = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\\n👋 再见!")
            break
        
        if not line:
            continue
            
        if line.lower() in ["exit", "quit", "q"]:
            print("👋 再见!")
            break
        
        # 列出会话
        if line == "sessions":
            sessions = await client.list_sessions()
            print(f"📋 共 {len(sessions)} 个会话:")
            for s in sessions:
                print(f"   - {s.get('key')}")
            continue
        
        # 发送消息
        if line.startswith("send "):
            msg = line[5:].strip()
            result = await client.send_message(msg)
            if result.get("ok"):
                print("✅ 发送成功")
            else:
                print(f"❌ 失败: {result.get('error')}")
            continue
        
        # 查看历史
        if line == "history":
            history = await client.get_history()
            print(f"📋 最近 {len(history[-10:])} 条消息:")
            for i, msg in enumerate(history[-10:], 1):
                content = msg.get("content", "")
                if isinstance(content, list):
                    text = "".join([c.get("text", "") for c in content if c.get("type") == "text"])[:80]
                else:
                    text = str(content)[:80]
                print(f"   {i:2d}. [{msg.get('role')}] {text}")
            continue
        
        # 监听消息
        if line == "watch":
            print("👀 开始监听消息 (30秒)... 按 Ctrl+C 停止")
            try:
                def callback(role, text):
                    print(f"📩 [{role}]: {text[:80]}")
                await client.watch_messages(duration=30, callback=callback)
            except KeyboardInterrupt:
                pass
            continue
        
        # 创建会话
        if line.startswith("create "):
            label = line[7:].strip()
            result = await client.create_session(label=label)
            print(f"✅ 会话创建成功!")
            print(f"   Session Key: {result.get('key')}")
            print(f"   Session ID: {result.get('sessionId')}")
            continue
        
        # 调用任意方法
        if line.startswith("call "):
            parts = line[5:].strip().split(maxsplit=1)
            method = parts[0]
            params = {}
            if len(parts) > 1:
                try:
                    import json
                    params = json.loads(parts[1])
                except Exception as e:
                    print(f"❌ JSON 解析错误: {e}")
                    continue
            
            import json
            result = await client.call_method(method, params)
            if result.get("ok"):
                print(f"✅ 调用成功")
                print(json.dumps(result.get("payload", {}), indent=2, ensure_ascii=False)[:500])
            else:
                print(f"❌ 调用失败")
                print(json.dumps(result.get("error", {}), indent=2, ensure_ascii=False))
            continue
        
        print("❓ 未知命令，输入 help 查看帮助")


async def main():
    parser = argparse.ArgumentParser(
        description="OpenClaw 自定义客户端 - 命令行工具"
    )
    parser.add_argument("--host", default="localhost", help="Gateway 主机")
    parser.add_argument("--port", type=int, default=18789, help="Gateway 端口")
    parser.add_argument("--message", help="发送消息后退出")
    parser.add_argument("--list-sessions", action="store_true", help="列出所有会话后退出")
    parser.add_argument("--history", action="store_true", help="查看消息历史后退出")
    parser.add_argument("--shell", action="store_true", help="启动交互式 Shell（默认）")
    
    args = parser.parse_args()
    
    try:
        client = OpenClawGatewayClient(host=args.host, port=args.port)
        await client.connect()
        print("✅ 已连接到 OpenClaw Gateway")
        
        if args.message:
            result = await client.send_message(args.message)
            if result.get("ok"):
                print("✅ 消息发送成功")
            else:
                print(f"❌ 发送失败: {result.get('error')}")
            return
        
        if args.list_sessions:
            sessions = await client.list_sessions()
            print(f"📋 共 {len(sessions)} 个会话:")
            for s in sessions:
                print(f"   - {s.get('key')}")
            return
        
        if args.history:
            history = await client.get_history()
            print(f"📋 最近 {len(history[-10:])} 条消息:")
            for i, msg in enumerate(history[-10:], 1):
                content = msg.get("content", "")
                if isinstance(content, list):
                    text = "".join([c.get("text", "") for c in content if c.get("type") == "text"])[:80]
                else:
                    text = str(content)[:80]
                print(f"   {i:2d}. [{msg.get('role')}] {text}")
            return
        
        # 默认启动交互式 Shell
        await interactive_shell(client)
        
    except Exception as e:
        print(f"\\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if 'client' in locals():
            await client.close()
            print("\\n🔌 连接已关闭")


if __name__ == "__main__":
    asyncio.run(main())
