"""
OpenClaw 自定义客户端库 - openclaw_custom_client

完整的 OpenClaw Gateway WebSocket 客户端，支持：
- 自动设备认证
- 会话管理
- 消息收发
- 事件监听
- 任意 RPC 方法调用
"""

from .client import OpenClawGatewayClient

__version__ = "1.0.0"
__author__ = "ClawX"
__all__ = ["OpenClawGatewayClient"]
