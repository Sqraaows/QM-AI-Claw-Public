#!/bin/bash

# 小右语音助手启动脚本

cd "$(dirname "$0")"

PID_FILE="/tmp/xiaoyou_kws.pid"
LOG_FILE="/tmp/xiaoyou_kws.log"
MODEL_DIR="sherpa-onnx-kws-zipformer-wenetspeech-3.3M-2024-01-01"
RESPONSE_DIR="response"

show_help() {
    echo "🦞 小右语音助手 V1.0.0"
    echo "========================"
    echo ""
    echo "用法: ./start.sh [选项]"
    echo ""
    echo "选项:"
    echo "  start              前台启动(默认)"
    echo "  start -d           后台启动(守护进程)"
    echo "  stop               停止后台运行"
    echo "  restart            重启后台服务"
    echo "  status             查看运行状态"
    echo "  logs               查看实时日志"
    echo "  set-keyword <词>    设置自定义唤醒词"
    echo ""
    echo "示例:"
    echo "  ./start.sh                    # 前台运行"
    echo "  ./start.sh start -d           # 后台运行"
    echo "  ./start.sh stop               # 停止后台"
    echo "  ./start.sh set-keyword 小爱同学  # 设置唤醒词"
    exit 0
}

check_env() {
    # 检查环境变量
    if [ -z "$SILICONFLOW_API_KEY" ]; then
        echo "⚠️  未设置SILICONFLOW_API_KEY环境变量"
        echo "💡 请执行: export SILICONFLOW_API_KEY=your_api_key"
    fi

    # 检查并下载模型（从 Gitee 仓库克隆）
    if [ ! -d "$MODEL_DIR" ] || [ ! -f "$MODEL_DIR/encoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx" ]; then
        echo "📥 下载KWS唤醒模型（从 Gitee 克隆）..."

        # 删除可能不完整的旧目录
        rm -rf "$MODEL_DIR"

        # 检查必要命令
        if ! command -v git &> /dev/null; then
            echo "❌ 需要 git 命令，请先安装 git"
            exit 1
        fi
        if ! command -v unzip &> /dev/null; then
            echo "❌ 需要 unzip 命令，请先安装 unzip"
            exit 1
        fi

        # Gitee 仓库地址（浅克隆）
        REPO_URL="https://gitee.com/myplease514/sherpa-onnx-kws-zipformer-wenetspeech-3.3-m-2024-01-01.git"
        TEMP_DIR="temp_repo_$$"

        echo "   克隆仓库（浅克隆）..."
        if ! git clone --depth 1 "$REPO_URL" "$TEMP_DIR"; then
            echo "❌ git clone 失败，请检查网络连接"
            rm -rf "$TEMP_DIR"
            exit 1
        fi

        echo "   移除 .gitignore 和 LICENSE 文件..."
        rm -f "$TEMP_DIR/.gitignore" "$TEMP_DIR/LICENSE"

        # 查找 ZIP 文件（假设仓库根目录下只有一个 .zip 文件）
        ZIP_FILE=$(find "$TEMP_DIR" -maxdepth 1 -name "*.zip" | head -n 1)
        if [ -z "$ZIP_FILE" ]; then
            echo "❌ 未找到 ZIP 文件，请检查仓库内容"
            rm -rf "$TEMP_DIR"
            exit 1
        fi

        echo "   解压模型到当前目录..."
        if ! unzip -q "$ZIP_FILE" -d .; then
            echo "❌ 解压失败"
            rm -rf "$TEMP_DIR"
            exit 1
        fi

        # 删除临时目录
        rm -rf "$TEMP_DIR"

        # 验证模型目录是否生成且包含关键文件
        if [ ! -d "$MODEL_DIR" ] || [ ! -f "$MODEL_DIR/encoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx" ]; then
            echo "❌ 模型文件不完整，请检查仓库中的 ZIP 文件内容"
            exit 1
        fi

        echo "✅ 模型下载完成"
    fi

    # 检查提示音是否存在,不存在则自动生成
    if [ ! -f "$RESPONSE_DIR/processing.wav" ]; then
        echo "🔊 生成提示音文件..."
        mkdir -p "$RESPONSE_DIR"
        python3 keyword_spotter.py --gen-prompts
    fi
}

# 设置唤醒词
set_keyword() {
    if [ -z "$1" ]; then
        echo "用法: ./start.sh set-keyword <唤醒词>"
        echo "示例: ./start.sh set-keyword 小右"
        echo "示例: ./start.sh set-keyword 小爱同学"
        exit 1
    fi

    KEYWORD="$1"
    echo "🔧 设置唤醒词为: $KEYWORD"

    # 写入keywords.txt
    echo "$KEYWORD" > "$MODEL_DIR/keywords.txt"

    # 更新keywords_raw.txt(多唤醒词支持)
    echo "$KEYWORD 1.0" > "$MODEL_DIR/keywords_raw.txt"

    echo "✅ 唤醒词已更新为: $KEYWORD"
    echo "💡 重启服务生效: ./start.sh restart(如果正在运行)"
}

start_foreground() {
    echo "🦞 小右语音助手 V1.0.0"
    echo "========================"
    check_env
    echo "🚀 启动语音助手(前台模式)..."
    echo "💡 请说 '小右' 唤醒"
    echo ""
    python3 keyword_spotter.py
}

start_background() {
    echo "🦞 小右语音助手 V1.0.0"
    echo "========================"
    check_env

    # 检查是否已经在运行
    if [ -f "$PID_FILE" ]; then
        OLD_PID=$(cat "$PID_FILE")
        if kill -0 "$OLD_PID" 2>/dev/null; then
            echo "⚠️  语音助手已经在运行 (PID: $OLD_PID)"
            exit 1
        else
            rm -f "$PID_FILE"
        fi
    fi

    echo "🚀 启动语音助手(后台模式)..."
    nohup python3 -u keyword_spotter.py > "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    echo "✅ 启动成功,PID: $(cat $PID_FILE)"
    echo "📝 日志文件: $LOG_FILE"
    echo "💡 查看日志: ./start.sh logs"
    echo "💡 停止服务: ./start.sh stop"
}

stop_service() {
    if [ ! -f "$PID_FILE" ]; then
        echo "⚠️  未找到PID文件,服务可能未启动"
        exit 1
    fi

    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "🛑 停止语音助手 (PID: $PID)..."
        kill "$PID"
        rm -f "$PID_FILE"
        echo "✅ 已停止"
    else
        echo "⚠️  进程 $PID 不存在,清理PID文件"
        rm -f "$PID_FILE"
    fi
}

show_status() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if kill -0 "$PID" 2>/dev/null; then
            echo "✅ 语音助手正在运行 (PID: $PID)"
            echo "📝 日志文件: $LOG_FILE"
            exit 0
        fi
    fi
    echo "❌ 语音助手未运行"
    exit 1
}

show_logs() {
    if [ -f "$LOG_FILE" ]; then
        tail -f "$LOG_FILE"
    else
        echo "⚠️  日志文件不存在"
    fi
}

# 主逻辑
case "${1:-start}" in
    start)
        if [ "$2" = "-d" ]; then
            start_background
        else
            start_foreground
        fi
        ;;
    stop)
        stop_service
        ;;
    restart)
        stop_service
        sleep 1
        start_background
        ;;
    status)
        show_status
        ;;
    logs)
        show_logs
        ;;
    set-keyword)
        set_keyword "$2"
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo "❌ 未知命令: $1"
        echo ""
        show_help
        ;;
esac
