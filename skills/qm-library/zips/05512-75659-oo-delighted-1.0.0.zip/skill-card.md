## Description: <br>
Use this skill to read, create, update, unsubscribe, delete, and retrieve metrics for Delighted account data through an OOMOL-connected Delighted connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Marketing, customer experience, and support operations users can use this skill to inspect Delighted people, survey responses, bounced or unsubscribed contacts, and NPS metrics. With confirmation, the same skill can create or update people, unsubscribe people, or delete a person and related survey history. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected Delighted account and access account data. <br>
Mitigation: Install only when the agent is intended to work with that Delighted account, and keep account connection and CLI setup in a trusted environment. <br>
Risk: Create, update, and unsubscribe actions can change Delighted contact or survey workflow state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running any write action. <br>
Risk: The delete action removes a person and related survey history. <br>
Mitigation: Confirm the target and get explicit user approval before running delete_person. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-delighted) <br>
- [Delighted homepage](https://delighted.com) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Delighted action references](actions/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON data and execution metadata from the OOMOL connector.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
