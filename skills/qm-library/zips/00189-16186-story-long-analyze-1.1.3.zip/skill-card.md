## Description: <br>
Analyzes long-form web novels through a staged workflow that backs up source text, examines opening chapters, summarizes chapters, aggregates plot, setting, character, and style findings, and writes Markdown reports. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Writers, editors, and story-development agents use this skill to deconstruct long-form web novels into reusable analysis of openings, plot structure, character systems, worldbuilding, pacing, and prose style. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill saves the novel text and derived analysis on disk under `拆文库/{书名}/`. <br>
Mitigation: Use a dedicated workspace for confidential or copyrighted drafts and avoid providing material that should not be persisted locally. <br>
Risk: The skill may update a matching pending entry in an existing `选题决策.md` after analysis. <br>
Mitigation: Review `选题决策.md` before running and keep the workspace under version control or otherwise backed up. <br>


## Reference(s): <br>
- [Story Long Analyze on ClawHub](https://clawhub.ai/worldwonderer/story-long-analyze) <br>
- [Publisher profile](https://clawhub.ai/user/worldwonderer) <br>
- [Material decomposition reference](references/material-decomposition.md) <br>
- [Output templates reference](references/output-templates.md) <br>
- [Pipeline operations reference](references/pipeline-ops.md) <br>
- [Style profile protocol reference](references/style-profile-protocol.md) <br>
- [Style profile generator reference](references/style-profile-generator.md) <br>
- [Deconstruction notes reference](references/deconstruction-notes.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, guidance] <br>
**Output Format:** [Markdown analysis files and concise conversational prompts] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Writes local analysis under `拆文库/{书名}/`; backs up provided source text; may update a matching pending entry in `选题决策.md` when that file exists.] <br>

## Skill Version(s): <br>
1.1.3 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
