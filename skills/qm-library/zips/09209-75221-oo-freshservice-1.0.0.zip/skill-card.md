## Description: <br>
Freshservice helps an agent read Freshservice data, create tickets and service requests, and discover locations and service catalog items through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, service desk teams, and operations users can use this skill to inspect Freshservice tickets, create new tickets or service requests, and look up service catalog and location data. It is suited for agents that need structured Freshservice actions instead of manual portal navigation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Broad Freshservice-related prompts may activate a credentialed skill that can create records. <br>
Mitigation: Install it only for agents expected to work with the connected Freshservice tenant, and review any create, update, or delete action before execution. <br>
Risk: Create ticket and create service request actions change Freshservice state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>


## Reference(s): <br>
- [ClawHub Freshservice Skill](https://clawhub.ai/oomol/oo-freshservice) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Freshservice Homepage](https://www.freshworks.com/freshservice/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Reads live connector schemas before constructing action payloads; connector responses are JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
