## Description: <br>
Canva (canva.com). Use this skill for ANY Canva request - reading, creating, and updating data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to operate Canva through an OOMOL-connected account, including creating designs, exporting designs, managing folders, and working with Canva assets. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or move Canva resources and start asset upload or export workflows, which may change Canva account state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running Canva-mutating actions. <br>
Risk: The release evidence notes a minor documentation mismatch around one status-check action being described too cautiously as write-changing. <br>
Mitigation: Review Canva-mutating actions separately and rely on live connector schemas before constructing payloads. <br>
Risk: The skill requires OAuth-connected Canva credentials through OOMOL. <br>
Mitigation: Use it only with an intended connected account and avoid exposing raw tokens or credentials in prompts, logs, or command payloads. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-canva) <br>
- [Canva homepage](https://www.canva.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Can emit Canva connector command guidance and JSON responses from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
