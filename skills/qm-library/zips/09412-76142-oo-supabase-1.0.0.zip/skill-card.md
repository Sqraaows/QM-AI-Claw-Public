## Description: <br>
Operate Supabase through an OOMOL-connected account for project discovery, project metadata lookup, and project API key management. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect Supabase organizations and projects, fetch project metadata, and list, retrieve, or create project API keys through the oo CLI connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can retrieve and create Supabase project API keys. <br>
Mitigation: Confirm the exact project, key type, and need before API-key actions, and avoid printing or storing returned keys in transcripts or logs. <br>
Risk: The oo CLI installer is presented as a pipe-to-shell command for first-time setup. <br>
Mitigation: Inspect or verify the installer before running it, and only install the CLI when the command actually fails because oo is unavailable. <br>
Risk: Write actions can change Supabase state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create, update, send, or post actions. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-supabase) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Supabase Homepage](https://supabase.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include a data payload and meta.executionId when actions run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
