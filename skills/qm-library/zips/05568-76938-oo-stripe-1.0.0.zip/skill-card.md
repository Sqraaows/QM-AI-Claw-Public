## Description: <br>
Stripe helps agents inspect live connector schemas and operate Stripe customer, product, and price workflows through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to read and manage Stripe account, customer, product, and price data from an agent while confirming write and delete operations before execution. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a Stripe account using sensitive credentials. <br>
Mitigation: Install it only for accounts the user intends an agent to access, and keep the OOMOL connection limited to the Stripe permissions actually needed. <br>
Risk: Create, update, and delete actions can change billing-related Stripe data. <br>
Mitigation: Verify the exact account, target object, and JSON payload before approving write or destructive actions. <br>


## Reference(s): <br>
- [Stripe homepage](https://stripe.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-stripe) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, JSON, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and a connected Stripe credential; payloads should be built from the live connector schema.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
