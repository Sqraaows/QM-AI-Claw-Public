## Description: <br>
Ragie lets an agent read, create, update, retrieve, and delete Ragie data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent work with Ragie documents, retrieval, connections, and partitions through the OOMOL connector while using their connected Ragie account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected Ragie account and uses sensitive credentials through OOMOL. <br>
Mitigation: Install only when you trust OOMOL and intend to grant an agent access to the connected Ragie account. <br>
Risk: Create, update, and delete actions can change or remove Ragie documents and partitions. <br>
Mitigation: Review write payloads before execution and require explicit approval for exact delete targets. <br>
Risk: Embedded source connections such as Google Drive or Notion may make synced content available through Ragie retrieval. <br>
Mitigation: Authorize only intended sources and confirm partition or connection scope before syncing or retrieving content. <br>


## Reference(s): <br>
- [Ragie homepage](https://www.ragie.ai) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ragie) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs the agent to inspect live action schemas before building JSON payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
