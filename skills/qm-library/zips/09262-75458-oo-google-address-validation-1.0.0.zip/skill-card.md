## Description: <br>
Google Address Validation helps agents validate and standardize postal addresses through the OOMOL `google_address_validation` connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to validate, parse, and standardize postal addresses with Google Address Validation, then optionally submit validation feedback for a completed sequence. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses sensitive address data and requires connected Google Address Validation credentials. <br>
Mitigation: Send addresses only when the user's Google API project and data-handling requirements allow it. <br>
Risk: Validation feedback changes service state after an address validation sequence. <br>
Mitigation: Confirm the exact payload and intended effect with the user before submitting feedback. <br>
Risk: The setup guidance includes an unpinned remote installer command for the oo CLI. <br>
Mitigation: Review the installer source first and prefer a pinned or package-manager installation when available. <br>


## Reference(s): <br>
- [Google Address Validation documentation](https://developers.google.com/maps/documentation/address-validation) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-google-address-validation) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution; connector responses are JSON with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
