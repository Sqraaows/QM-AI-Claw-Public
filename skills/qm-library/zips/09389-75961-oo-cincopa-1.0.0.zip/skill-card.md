## Description: <br>
Cincopa (cincopa.com). Use this skill for Cincopa requests that search, list, and read account data through the OOMOL oo CLI instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and media operations teams use this skill to let an agent inspect Cincopa account assets, galleries, gallery items, and asset tags through a connected OOMOL account. It supports read-only discovery and listing workflows for media library management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Cincopa account through OOMOL and can read media, gallery, and tag metadata. <br>
Mitigation: Install only when that account access is acceptable, and review the connected OOMOL/Cincopa scopes before use. <br>
Risk: The setup path may install or rely on the remote oo CLI as a third-party tool. <br>
Mitigation: Treat the CLI installer as a normal third-party setup step and verify the installation source before running connector commands. <br>
Risk: Future connector actions could mutate Cincopa state even though this release documents only read/list actions. <br>
Mitigation: Confirm any create, update, post, delete, or remove action and its exact payload with the user before execution. <br>


## Reference(s): <br>
- [Cincopa homepage](https://www.cincopa.com/) <br>
- [Cincopa skill on ClawHub](https://clawhub.ai/oomol/oo-cincopa) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads; actions documented in this version are read/list operations.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
