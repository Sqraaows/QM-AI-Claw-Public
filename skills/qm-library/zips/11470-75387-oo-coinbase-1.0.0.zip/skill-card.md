## Description: <br>
Operate Coinbase through an OOMOL-connected account to list accessible Coinbase Advanced Trade brokerage accounts and retrieve an account by UUID. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect the live Coinbase connector schema, then run read-oriented account lookup commands through an already connected OOMOL account. It is intended for Coinbase account metadata access, not as authorization for trading, transfers, or other state-changing Coinbase operations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive Coinbase credentials through a connected OOMOL account and can expose financial account metadata. <br>
Mitigation: Install only when the agent should access Coinbase account metadata, treat returned data as sensitive financial information, and confirm the exact account lookup being requested. <br>
Risk: Broad Coinbase routing language could be misunderstood as permission for trading, transfers, or other state-changing operations. <br>
Mitigation: Use this release for the disclosed read-oriented account actions and do not treat it as blanket authorization for state-changing Coinbase operations. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>


## Reference(s): <br>
- [Coinbase Skill Page](https://clawhub.ai/oomol/oo-coinbase) <br>
- [Coinbase Homepage](https://www.coinbase.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration guidance, JSON, Markdown] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands may return sensitive financial account metadata and an executionId in the response metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
