## Description: <br>
Hacker News helps agents search, read, and inspect public Hacker News stories, comments, updates, and user profiles through the OOMOL Hacker News connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and agents use this skill to retrieve public Hacker News story lists, search posts, inspect individual items and comment trees, and look up public user profiles. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on the local oo CLI and OOMOL account state, so actions may fail if the CLI is missing or the user is not signed in. <br>
Mitigation: Install the oo CLI or sign in only after an action fails with the matching setup or authentication error. <br>
Risk: Fetched Hacker News content is public user-generated content and may be incomplete, stale, misleading, or inappropriate for the user's task. <br>
Mitigation: Treat returned content as source material to review, summarize, or cite rather than as verified factual guidance. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-hackernews) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Hacker News](https://news.ycombinator.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON data from public Hacker News read and search operations.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
