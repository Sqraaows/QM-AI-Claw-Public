## Description: <br>
GTmetrix connector for running website performance tests and reading account, page, test, report, location, browser, and device data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and site operators use this skill to ask an agent to inspect GTmetrix account resources, list available testing options, start GTmetrix performance tests, and retrieve completed reports through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Starting a GTmetrix test can change account state and may consume GTmetrix credits. <br>
Mitigation: Confirm the URL, payload, and expected cost with the user before allowing start_test to run. <br>
Risk: The skill requires access to a connected GTmetrix account through OOMOL. <br>
Mitigation: Install only when the agent should use that connected account, and retry setup steps only after an authentication or connection error. <br>
Risk: Connector input and output schemas may change upstream. <br>
Mitigation: Fetch the live connector schema for the selected action before constructing the JSON payload. <br>


## Reference(s): <br>
- [ClawHub GTmetrix skill](https://clawhub.ai/oomol/oo-gtmetrix) <br>
- [GTmetrix homepage](https://gtmetrix.com) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before execution; start_test is state-changing and may consume GTmetrix credits.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
