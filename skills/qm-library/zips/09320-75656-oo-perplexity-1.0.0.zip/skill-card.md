## Description: <br>
Perplexity is an OOMOL connector skill that lets an agent use a connected Perplexity account for chat completions, embeddings, model discovery, and web search. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use this skill to operate Perplexity through the OOMOL oo CLI for Sonar chat completions, vector embeddings, model listing, and raw web search results. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Prompts, search queries, and embedding inputs may be sent to Perplexity under the user's connected API key. <br>
Mitigation: Confirm the user is comfortable sharing the requested content with Perplexity and avoid sending secrets unless explicitly intended. <br>
Risk: Some action documents label chat completion and embedding calls as write actions even though the security review identifies this as documentation inconsistency rather than harmful behavior. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create actions, and inspect the live connector schema first. <br>


## Reference(s): <br>
- [Perplexity homepage](https://www.perplexity.ai) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-perplexity) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
