## Description: <br>
Helps an agent use an OOMOL-connected Resend account to inspect the live connector schema and send email through Resend. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent send email through a connected Resend account while checking the current connector schema before payload construction. It is suited for communication and marketing workflows that require explicit review before sending messages. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send email through a connected Resend account. <br>
Mitigation: Review and confirm the exact recipient, subject, body, sending domain, and intended effect before approving any send action. <br>
Risk: The skill requires a trusted connector provider and connected Resend credentials. <br>
Mitigation: Install only when OOMOL is trusted as the connector provider and the agent is intended to send email through the user's connected account. <br>
Risk: Connector schemas and accepted payload fields can change upstream. <br>
Mitigation: Inspect the live Resend connector schema before constructing each payload. <br>


## Reference(s): <br>
- [Resend homepage](https://resend.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-resend) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Prompts the agent to inspect the live connector schema before constructing JSON payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
