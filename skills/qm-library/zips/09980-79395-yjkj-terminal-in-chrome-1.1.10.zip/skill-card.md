## Description: <br>
Manages the Web Terminal Chrome Extension local backend server. Use this skill to start, stop, or check the status of the local terminal server running on port 8989. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[yayayahei](https://clawhub.ai/user/yayayahei) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and technical users use this skill to manage a local backend that lets a Chrome extension expose a resizable shell terminal inside browser pages. It supports starting, stopping, checking, and configuring the local terminal server. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill exposes a powerful local shell through a Chrome extension with broad site access and weak access controls. <br>
Mitigation: Install only when a browser-accessible local shell is intended, restrict the extension to trusted sites, protect the local backend, add authentication or an unguessable token with WebSocket Origin checks, avoid entering secrets, and stop the server when it is not needed. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/yayayahei/terminal-in-chrome) <br>
- [Source Repository](https://github.com/yayayahei/skills/tree/main/terminal-in-chrome) <br>
- [README](README.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown with inline bash code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Provides local server operation steps and Chrome extension setup guidance.] <br>

## Skill Version(s): <br>
1.1.16 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
