## Description: <br>
CraftMyPDF lets agents read account and template data and create PDFs through an OOMOL-connected CraftMyPDF account instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to work with CraftMyPDF templates and account data from an agent workflow. It supports listing templates, retrieving template details, inspecting account information, and creating hosted PDFs with transaction metadata. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected CraftMyPDF account and can access account or template data through OOMOL. <br>
Mitigation: Install only when the user expects this account access, keep credentials managed through the connected account flow, and avoid exposing raw API keys in prompts or files. <br>
Risk: Creating a PDF may change CraftMyPDF service state or consume account credits. <br>
Mitigation: Confirm the exact create_pdf payload and intended effect with the user before running the action. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Fetch the live action schema before constructing each payload and match the current input contract. <br>


## Reference(s): <br>
- [CraftMyPDF homepage](https://craftmypdf.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, API calls, JSON, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an OOMOL sign-in, and a connected CraftMyPDF API key; PDF creation can change service state or consume account credits.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
