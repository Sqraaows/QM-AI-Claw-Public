## Description: <br>
Fillout (fillout.com). Use this skill for Fillout requests that read, create, update, or delete data through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations users use this skill to interact with authenticated Fillout forms and submissions from an agent workflow, including listing forms, inspecting metadata, reading submissions, creating submissions, and deleting submissions with confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup path can execute remote installer scripts for the oo CLI. <br>
Mitigation: Install the oo CLI through a reviewed or vendor-documented path before using the skill. <br>
Risk: The skill uses authenticated Fillout access and can read, create, and delete submissions. <br>
Mitigation: Connect a Fillout API key with only the permissions needed for the task and confirm every create or delete request before execution. <br>
Risk: Deleting a submission removes Fillout data. <br>
Mitigation: Verify the form and submission ID with the user and require explicit approval before running the delete action. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-fillout) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [Fillout homepage](https://www.fillout.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and a connected Fillout API key with appropriate permissions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and SKILL.md metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
