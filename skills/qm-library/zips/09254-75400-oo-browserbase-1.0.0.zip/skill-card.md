## Description: <br>
Browserbase helps an agent operate Browserbase through an OOMOL-connected account for project, session, usage, and context actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and automation teams use this skill to inspect Browserbase schemas and run project, session, usage, and context operations through the oo CLI with their connected Browserbase account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, release, refresh credentials for, or delete Browserbase resources. <br>
Mitigation: Confirm the exact payload, target resource, and intended effect with the user before write or destructive actions. <br>
Risk: The skill requires an OOMOL-connected Browserbase account and may rely on sensitive account credentials handled by the connector. <br>
Mitigation: Use the connected-account flow and avoid exposing raw tokens in prompts, command arguments, logs, or files. <br>
Risk: First-time oo CLI installation instructions include curl-to-shell or PowerShell install commands. <br>
Mitigation: Run installation only when the CLI is missing and review the installer source or use an approved installation path before execution. <br>


## Reference(s): <br>
- [Browserbase homepage](https://www.browserbase.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Browserbase skill](https://clawhub.ai/oomol/oo-browserbase) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [API Calls, Shell commands, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs may include oo CLI command responses with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
