## Description: <br>
Story Deslop detects and rewrites Chinese web-novel text to reduce AI-like phrasing, template-like rhythm, and overly polished prose. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External writers and editors use this skill to detect and reduce AI-like phrasing in Chinese web-novel drafts while preserving plot, characters, timeline, and key details. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Broad casual phrases such as saying a passage feels AI-written may activate the skill and produce edits. <br>
Mitigation: Use explicit detection-only requests when no edits are desired, and review changes before accepting them. <br>
Risk: Style rewrites can remove nuance, clues, or intentional wording from fiction drafts. <br>
Mitigation: Review revised passages against the original and preserve the skill's review markers for uncertain or over-limit edits. <br>
Risk: File-path inputs may cause the agent to modify local draft files. <br>
Mitigation: Inspect file diffs before accepting changes, especially when processing paths rather than pasted text. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/worldwonderer/story-deslop) <br>
- [OpenClaw Source Metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [Anti-AI Writing Reference](references/anti-ai-writing.md) <br>
- [Banned Words and Sentence Patterns](references/banned-words.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, guidance] <br>
**Output Format:** [Markdown reports with rewritten prose, issue tables, and before/after comparisons.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May edit files when the input is a file path; otherwise returns detection and revision output in chat.] <br>

## Skill Version(s): <br>
1.1.2 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
