## Description: <br>
Crustdata (crustdata.com). Use this skill for any Crustdata request involving company search, identification, autocomplete, or enrichment through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and business users use this skill to run Crustdata company lookup, search, autocomplete, and enrichment actions through OOMOL without handling raw API credentials directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL account connected to Crustdata, so requests can fail when credentials are missing, expired, or lack required scope. <br>
Mitigation: Install and use it only with an intended OOMOL-connected Crustdata account, and reconnect or refresh credentials only after an authentication or connection error. <br>
Risk: The first-time setup path includes CLI installation commands and sends company identifiers or enrichment requests to the connected service. <br>
Mitigation: Verify the OOMOL install URL before running installer commands, inspect live connector schemas, and review payloads before sending company data. <br>


## Reference(s): <br>
- [Crustdata homepage](https://crustdata.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-crustdata) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [autocomplete_companies action reference](actions/autocomplete_companies.md) <br>
- [enrich_companies action reference](actions/enrich_companies.md) <br>
- [identify_companies action reference](actions/identify_companies.md) <br>
- [search_companies action reference](actions/search_companies.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
