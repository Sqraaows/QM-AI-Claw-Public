## Description: <br>
Rollbar (rollbar.com). Use this skill for ANY Rollbar request -- searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect Rollbar projects, items, occurrences, deploys, and environments through an OOMOL-connected Rollbar account. It supports read-only investigation workflows while relying on the live connector schema before each action. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL account with Rollbar access, so action results may expose sensitive project, deploy, item, or occurrence data. <br>
Mitigation: Use the skill only in environments where OOMOL and Rollbar access are approved, and limit requests to the data needed for the user's task. <br>
Risk: The reviewed actions are read-only, but future live connector schemas could expose create, update, or delete behavior. <br>
Mitigation: Inspect the live connector schema before execution and confirm exact payloads and effects with the user before any state-changing or destructive action. <br>


## Reference(s): <br>
- [Rollbar homepage](https://rollbar.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Rollbar skill page](https://clawhub.ai/oomol/oo-rollbar) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON from the oo CLI when actions are executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
