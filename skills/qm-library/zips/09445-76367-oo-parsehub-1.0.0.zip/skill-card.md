## Description: <br>
ParseHub helps an agent list and retrieve ParseHub project information through an OOMOL-connected ParseHub account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to inspect ParseHub connector schemas and run read-only ParseHub project listing or lookup actions from an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can expose ParseHub project information visible to the connected API key. <br>
Mitigation: Use a ParseHub API key scoped to the projects the agent is intended to access. <br>
Risk: Connector schemas and upstream defaults can change. <br>
Mitigation: Review the live connector schema before each action and build payloads from that schema. <br>


## Reference(s): <br>
- [ParseHub homepage](https://www.parsehub.com) <br>
- [ClawHub ParseHub skill page](https://clawhub.ai/oomol/oo-parsehub) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON CLI responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON data and execution metadata from the oo CLI when run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence release and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
