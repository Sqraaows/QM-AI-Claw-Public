## Description: <br>
Use this skill for Coda requests that read, create, or update data through an OOMOL-connected Coda account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to inspect Coda schemas and operate Coda docs, pages, tables, columns, and rows through the oo CLI. It supports read operations and selected write operations such as page creation and row upserts. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Read actions can expose Coda documents, tables, rows, and account information accessible to the connected account. <br>
Mitigation: Install and use the skill only when the connected OOMOL and Coda account access is appropriate for the agent task. <br>
Risk: Write actions can change Coda pages or rows. <br>
Mitigation: Confirm the exact target document, table, action, and payload before allowing create_page or upsert_rows operations. <br>


## Reference(s): <br>
- [Coda homepage](https://coda.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Coda skill on ClawHub](https://clawhub.ai/oomol/oo-coda) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration guidance, JSON, Text] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payload or response examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release metadata and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
