#!/usr/bin/env python3
"""
tbs-scene-validate.py

四模式校验工具（均不访问远端 HTTP，无需 access-token）：

- --mode step2       ：Step2 基础信息名称校验
                       校验用户填写的「业务领域/科室/品种」是否在 Step1 主数据列表中命中。
                       需同时提供 --names-json 与 --state-json 两个参数。
                       返回每个字段的匹配状态：exact / multiple / zero。

- --mode topics      ：[deprecated] 旧版本地主题匹配，主路径改用 suggestKnowledge
                       校验用户提供的主题名称是否在 state.productKnowledges 中命中。
                       需同时提供 --topics-json 与 --state-json，可附加 --drug-id 按品种过滤。
                       返回每条主题的匹配状态：exact / contains / multiple / zero。

- --mode step3      ：校验 Step3 已采集字段（地点/医生担忧点/代表目标/医生画像/最佳实践要点）
                      是否齐全，供进入 Step4 前做门禁。
                      Step3 推荐 JSON 形态见：references/step3/draft-schema.md

- --mode createScene：校验提交 `POST /scene/sceneAudit/createSxkDraftAndSubmitAudit` 前上游拼装的 scene 是否满足门禁（与 `tbs-scene-create.py` 组装逻辑对齐；部分字段以接口文档为准可为空）。
"""

import argparse
import json
import os
import sys
from typing import Any, Dict, List

_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)
from question_boundary_assemble import validate_question_boundary  # noqa: E402


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def require_non_empty(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    if isinstance(value, list):
        return len(value) > 0
    if isinstance(value, dict):
        return len(value) > 0
    return True


def _first_non_empty(d: Dict[str, Any], keys: List[str]) -> Any:
    for k in keys:
        if k in d and require_non_empty(d.get(k)):
            return d.get(k)
    return None


def _norm(s: str) -> str:
    """Normalize string for matching: strip whitespace and lowercase."""
    return s.strip().lower() if s else ""


def _match_name(
    input_name: str,
    candidates: List[Dict[str, str]],
    name_key: str = "name",
    id_key: str = "id",
    allow_contains: bool = False,
    max_candidates: int = 50,
) -> Dict[str, Any]:
    """
    Match input_name against a list of {id, name} candidates.

    Matching strategy (step2 default, allow_contains=False):
      - exact: normalized input == normalized candidate name → auto-accept
      - multiple: 2+ exact matches, or 0 exact but 1+ contains → user must select
      - zero: no match at all

    For topics (allow_contains=True):
      - exact: one exact match → matched
      - contains: exactly one candidate whose name contains input (or vice versa) → matched (相近)
      - multiple: 2+ contains matches → user must select
      - zero: no match

    Candidates with empty names are always excluded from matching and output.

    Output hygiene:
      - In `multiple` / `zero` cases, `candidates` may otherwise become very large.
        We truncate to at most `max_candidates` display names, and also return:
          - candidatesTotal: total candidate count (after empty-name filtering)
          - candidatesTruncated: whether truncation happened
    """
    norm_input = _norm(input_name)

    # Exclude candidates whose name is empty — they must never be surfaced to users
    candidates = [c for c in candidates if c.get(name_key, "").strip()]

    exact_hits = [c for c in candidates if _norm(c.get(name_key, "")) == norm_input]
    def _names_only(items: List[Dict]) -> List[str]:
        """Return only display names — never expose internal IDs to callers."""
        return [c.get(name_key, "") for c in items]

    def _truncate(names: List[str]) -> Dict[str, Any]:
        total = len(names)
        if max_candidates and max_candidates > 0 and total > max_candidates:
            return {
                "candidates": names[:max_candidates],
                "candidatesTotal": total,
                "candidatesTruncated": True,
            }
        return {
            "candidates": names,
            "candidatesTotal": total,
            "candidatesTruncated": False,
        }

    if len(exact_hits) == 1:
        return {
            "status": "exact",
            "matchedId": exact_hits[0].get(id_key, ""),
            "matchedName": exact_hits[0].get(name_key, ""),
            **_truncate([]),
        }
    if len(exact_hits) > 1:
        cand_names = _names_only(exact_hits)
        return {
            "status": "multiple",
            "matchedId": "",
            "matchedName": "",
            **_truncate(cand_names),
        }

    # No exact match — try contains
    contains_hits = [
        c
        for c in candidates
        if norm_input and (
            norm_input in _norm(c.get(name_key, ""))
            or _norm(c.get(name_key, "")) in norm_input
        )
    ]

    if allow_contains:
        if len(contains_hits) == 1:
            return {
                "status": "contains",
                "matchedId": contains_hits[0].get(id_key, ""),
                "matchedName": contains_hits[0].get(name_key, ""),
                **_truncate([]),
            }
        if len(contains_hits) > 1:
            cand_names = _names_only(contains_hits)
            return {
                "status": "multiple",
                "matchedId": "",
                "matchedName": "",
                **_truncate(cand_names),
            }
    else:
        # step2 mode: any contains hit → multiple (requires user confirmation)
        if contains_hits:
            cand_names = _names_only(contains_hits)
            return {
                "status": "multiple",
                "matchedId": "",
                "matchedName": "",
                **_truncate(cand_names),
            }

    # Zero match — return full list as guidance (names only)
    cand_names = _names_only(candidates)
    return {
        "status": "zero",
        "matchedId": "",
        "matchedName": "",
        **_truncate(cand_names),
    }


def _validate_step2(
    names: Dict[str, str],
    state: Dict[str, Any],
    max_candidates: int = 50,
) -> Dict[str, Any]:
    """
    Step2 基础信息名称校验。

    names:  {"businessDomain": "临床推广", "department": "心内科", "drug": "新活素"}
    state:  {"businessDomains": [...], "departments": [...], "drugs": [...]}

    对每个字段做精确/包含/零命中匹配；全部 exact 才 passed=true。
    """
    field_map = [
        ("businessDomain", "businessDomains"),
        ("department", "departments"),
        ("drug", "drugs"),
    ]

    results: Dict[str, Any] = {}
    all_exact = True

    for name_key, state_key in field_map:
        input_name = names.get(name_key, "")
        candidates: List[Dict[str, str]] = state.get(state_key, [])

        if not input_name:
            # Field not provided — skip validation for this field
            results[name_key] = {
                "status": "skipped",
                "matchedId": "",
                "matchedName": "",
                "candidates": [],
                "candidatesTotal": 0,
                "candidatesTruncated": False,
            }
            continue

        result = _match_name(input_name, candidates, allow_contains=False, max_candidates=max_candidates)
        result["input"] = input_name
        results[name_key] = result

        if result["status"] != "exact":
            all_exact = False

    return {
        "success": True,
        "passed": all_exact,
        "mode": "step2",
        "results": results,
    }


def _validate_topics(
    topics: List[str],
    state: Dict[str, Any],
    drug_id: str = "",
    max_candidates: int = 50,
) -> Dict[str, Any]:
    """
    Step4 品种知识主题校验。

    topics:   ["新活素使用场景", "新活素作用机制"]
    state:    {"productKnowledges": [{"knowledgeId": "937", "title": "...", "drugId": "124", "category": "..."}, ...]}
              注意：productKnowledges 使用 title（主题名）和 knowledgeId，不是 name/id。
    drug_id:  可选；非空时只在该品种下的主题中匹配

    每条主题返回：exact / contains / multiple / zero
    passed=true 表示所有主题至少命中一条（exact 或 contains）。
    """
    knowledge_list: List[Dict[str, Any]] = state.get("productKnowledges", [])

    if drug_id:
        scoped = [k for k in knowledge_list if str(k.get("drugId", "")) == str(drug_id)]
    else:
        scoped = knowledge_list

    results = []
    all_matched = True

    for topic in topics:
        # productKnowledges 用 title 作为主题名，knowledgeId 作为 ID
        result = _match_name(
            topic,
            scoped,
            name_key="title",
            id_key="knowledgeId",
            allow_contains=True,
            max_candidates=max_candidates,
        )
        result["input"] = topic
        results.append(result)
        if result["status"] in ("multiple", "zero"):
            all_matched = False

    return {
        "success": True,
        "passed": all_matched,
        "mode": "topics",
        "results": results,
    }


def _validate_step3(scene: Dict[str, Any]) -> Dict[str, Any]:
    """
    Step3 只收集并确认：
      - 地点
      - 医生担忧点
      - 代表目标
      - 医生画像（人设配置/简介描述/姓氏/职称）
      - 最佳实践要点（开场话术/回应问题话术/推荐建议）

    因为 draftJson 的中间形态可能不同，这里做"结构优先、兜底次之"的校验：
    1) 优先从 scene.scenarioBase / scene.doctorPersona / scene.bestPracticePoints 校验结构化字段
    2) 若结构化子对象不存在，则在扁平 scene 对象（scenarioBase 或根层）里按别名列表做兜底校验
    """
    # 结构化容器（优先）
    scenario_base = scene.get("scenarioBase") if isinstance(scene.get("scenarioBase"), dict) else scene
    doctor_persona = scene.get("doctorPersona") if isinstance(scene.get("doctorPersona"), dict) else {}
    best_practice_points = scene.get("bestPracticePoints") if isinstance(scene.get("bestPracticePoints"), dict) else {}

    # 兼容：doctorPersona/bestPracticePoints 可能也在 scenarioBase 内
    if not doctor_persona and isinstance(scenario_base.get("doctorPersona"), dict):
        doctor_persona = scenario_base["doctorPersona"]
    if not best_practice_points and isinstance(scenario_base.get("bestPracticePoints"), dict):
        best_practice_points = scenario_base["bestPracticePoints"]
    # 兼容：部分草稿使用 bestPractice（与 bestPracticePoints 同义）
    if not best_practice_points and isinstance(scene.get("bestPractice"), dict):
        best_practice_points = scene["bestPractice"]
    if not best_practice_points and isinstance(scenario_base.get("bestPractice"), dict):
        best_practice_points = scenario_base["bestPractice"]
    # 兼容：doctorPersona/bestPracticePoints 的四要素/三项也可能直接挂在 scenarioBase 上
    if not doctor_persona:
        if any(
            k in scenario_base
            for k in [
                "personaConfig",
                "humanSetting",
                "profileConfig",
                "人设配置",
                "personality",
                "communicationStyle",
                "behaviorTendency",
                "introDescription",
                "intro",
                "简介描述",
                "description",
                "surname",
                "姓氏",
                "title",
                "职称",
            ]
        ):
            doctor_persona = scenario_base
    if not best_practice_points:
        if any(
            k in scenario_base
            for k in [
                "openingScript",
                "openingTalk",
                "openingStatement",
                "开场话术",
                "questionResponseScript",
                "responseTalk",
                "responseStatement",
                "回应问题话术",
                "recommendation",
                "recommendationAdvice",
                "推荐建议",
            ]
        ):
            best_practice_points = scenario_base

    missing: List[str] = []

    # 地点
    time_place = _first_non_empty(
        scenario_base,
        [
            "location",
            "timePlace",
            "timeLocation",
            "地点",
            "时间地点",
        ],
    )
    if not require_non_empty(time_place):
        missing.append("地点")

    # 医生担忧点
    doctor_concerns = _first_non_empty(
        scenario_base,
        [
            "doctorConcerns",
            "doctorConcernPoints",
            "doctorConcernsText",
            "医生担忧点",
        ],
    )
    if not require_non_empty(doctor_concerns):
        missing.append("医生担忧点")

    # 代表目标（注意：repBriefing 是落库阶段字段，与 sceneBackground 同源，不用于 Step3 草稿中的「代表目标」语义）
    rep_goal = _first_non_empty(
        scenario_base,
        [
            "repGoal",
            "representativeGoal",
            "代表目标",
        ],
    )
    if not require_non_empty(rep_goal):
        missing.append("代表目标")

    # 医生画像（四要素 / 或拆分为 personality+communicationStyle+behaviorTendency + description 等）
    persona_config = _first_non_empty(
        doctor_persona,
        [
            "personaConfig",
            "humanSetting",
            "profileConfig",
            "人设配置",
            "personality",
            "性格特征",
        ],
    )
    if not require_non_empty(persona_config):
        p1 = doctor_persona.get("personality")
        p2 = doctor_persona.get("communicationStyle")
        p3 = doctor_persona.get("behaviorTendency")
        if require_non_empty(p1) and require_non_empty(p2) and require_non_empty(p3):
            persona_config = f"{p1}\n{p2}\n{p3}"
    persona_intro = _first_non_empty(
        doctor_persona,
        ["introDescription", "intro", "简介描述", "description", "描述"],
    )
    persona_surname = _first_non_empty(
        doctor_persona,
        ["surname", "姓氏"],
    )
    persona_title = _first_non_empty(
        doctor_persona,
        ["title", "职称"],
    )

    if not (
        require_non_empty(persona_config)
        and require_non_empty(persona_intro)
        and require_non_empty(persona_surname)
        and require_non_empty(persona_title)
    ):
        # 兜底：若上游已完成 personaId 映射，则 personaIds 非空也视为医生画像已齐全
        persona_ids = scene.get("personaIds", [])
        if not (isinstance(persona_ids, list) and len(persona_ids) > 0):
            missing.append("医生画像")

    # 最佳实践要点（三项）
    opening_script = _first_non_empty(
        best_practice_points,
        ["openingScript", "openingTalk", "openingStatement", "开场话术"],
    )
    question_response_script = _first_non_empty(
        best_practice_points,
        [
            "questionResponseScript",
            "responseTalk",
            "responseStatement",
            "回应问题话术",
        ],
    )
    recommendation = _first_non_empty(
        best_practice_points,
        ["recommendation", "recommendationAdvice", "推荐建议"],
    )

    best_practice_ok = (
        require_non_empty(opening_script)
        and require_non_empty(question_response_script)
        and require_non_empty(recommendation)
    )
    if not best_practice_ok:
        missing.append("最佳实践要点")

    passed = len(missing) == 0
    out: Dict[str, Any] = {
        "success": True,
        "passed": passed,
        "missingFields": missing,
        "mode": "step3",
        "snapshot": {
            "location": time_place,
            "hasRepBriefing": require_non_empty(scene.get("repBriefing")),
        },
    }
    if passed:
        out["nextStep"] = {
            "action": "generateTitleAndBackground",
            "userVisibleHint": "草稿校验已通过，正在生成场景标题与场景背景，请稍候…",
            "skipRepeatFullChecklist": True,
            "mustWaitForUserConfirm": True,
            "forbiddenBeforeG4": [
                "tbs-scene-suggest-knowledge.py",
                "Step4.1",
                "Step4.2",
                "contextPayload",
            ],
            "userVisiblePromptAfterGenerate": (
                "请核对场景标题与场景背景；确认无误后回复「确认」或「继续」，"
                "我们再为您推荐产品知识。"
            ),
            "generationRules": {
                "refDoc": "references/step3/title-and-scene-background.md",
                "hardConstraints": [
                    "【禁止姓氏】背景和标题中严禁出现任何具体姓氏（如「李主任」「王主任」）；"
                    "只允许使用职称/角色称谓（如「主任医师」「药剂科主任」「医师」）",
                    "【背景三块】仅含①现状（location/department/drug）②张力（doctorConcerns）"
                    "③训练目的（repGoal 改写）；禁止开场建议、动作镜头、编造数据",
                    "【生成后自检】输出前必须逐条确认 title-and-scene-background.md §5 自检清单，"
                    "全部通过方可输出；禁止跳过自检直接展示",
                    "【忠实性】不得引入 draft 与用户确认清单中未出现的具体数据或政策条文",
                ],
            },
        }
    return out


def _cp_get(cp: Dict[str, Any], side: str, key: str) -> Any:
    block = cp.get(side)
    return block.get(key) if isinstance(block, dict) else None


def _normalize_scene_for_validate(scene: Dict[str, Any]) -> Dict[str, Any]:
    """
    与 tbs-scene-create.py normalize_scene 保持一致：
    从 scenarioBase 提升 department/businessDomain 名称到顶层（幂等，不覆盖已有值）。
    draft.json 只存名称；validate 与 create 均接受名称作为 departmentId/businessDomainId。
    """
    sb = scene.get("scenarioBase")
    if isinstance(sb, dict):
        if not scene.get("departmentId") and sb.get("department"):
            scene["departmentId"] = sb["department"]
        if not scene.get("businessDomainId") and sb.get("businessDomain"):
            scene["businessDomainId"] = sb["businessDomain"]
    return scene


def _validate_create_scene(scene: Dict[str, Any]) -> Dict[str, Any]:
    """落库前组装防呆（业务合法性由创建接口终检）。"""
    scene = _normalize_scene_for_validate(scene)
    missing: List[str] = []

    for k in ("title", "departmentId", "businessDomainId", "repBriefing"):
        if not require_non_empty(scene.get(k)):
            missing.append(k)

    drug_name = str(scene.get("drugName") or "").strip()
    if not drug_name:
        legacy = scene.get("drugId")
        if legacy is not None and not str(legacy).strip().isdigit():
            drug_name = str(legacy).strip()
    if not drug_name:
        missing.append("drugName")

    scene_background = scene.get("sceneBackground")
    if not require_non_empty(scene_background):
        missing.append("sceneBackground")
    elif require_non_empty(scene.get("repBriefing")):
        if str(scene_background).strip() != str(scene.get("repBriefing")).strip():
            missing.append("repBriefing!=sceneBackground")

    if not isinstance(scene.get("doctorPersona"), dict) or not require_non_empty(scene.get("doctorPersona")):
        missing.append("doctorPersona")

    cp = scene.get("contextPayload")
    if not isinstance(cp, dict):
        missing.append("contextPayload")
    else:
        for side, key in (
            ("doctor", "known_background"),
            ("doctor", "core_concerns"),
            ("doctor", "today_status"),
            ("doctor", "question_boundary"),
            ("doctor", "termination_rules"),
            ("coach", "expected_behaviors"),
            ("coach", "termination_rules"),
            ("coach", "best_practices"),
        ):
            if not require_non_empty(_cp_get(cp, side, key)):
                missing.append(f"contextPayload.{side}.{key}")

        qb = _cp_get(cp, "doctor", "question_boundary")
        if require_non_empty(qb):
            qb_check = validate_question_boundary(str(qb), strict_layer1=True)
            if not qb_check.get("passed"):
                for issue in qb_check.get("issues") or []:
                    missing.append(f"contextPayload.doctor.question_boundary:{issue}")

    k_ids = scene.get("knowledgeIds")
    if not isinstance(k_ids, list) or len(k_ids) == 0:
        missing.append("knowledgeIds")

    passed = len(missing) == 0
    return {
        "success": True,
        "passed": passed,
        "missingFields": missing,
        "mode": "createScene",
        "sceneSnapshot": {
            "title": scene.get("title"),
            "drugName": drug_name or scene.get("drugName"),
            "hasContextPayload": isinstance(cp, dict),
            "knowledgeIdsCount": len(k_ids) if isinstance(k_ids, list) else 0,
        },
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    # --- step2 / topics 专用参数 ---
    ap.add_argument("--names-json", required=False, help="(step2) JSON: {businessDomain, department, drug}")
    ap.add_argument("--state-json", required=False, help="(step2/topics) JSON: state object from Step1 output")
    ap.add_argument("--topics-json", required=False, help="(topics) JSON array of topic name strings")
    ap.add_argument("--drug-id", required=False, default="", help="(topics) Optional drugId to scope knowledge list")
    ap.add_argument("--max-candidates", required=False, type=int, default=50, help="(step2/topics) Truncate candidates list size")
    # --- step3 / createScene 专用参数 ---
    ap.add_argument("--params-file", required=False, help="Path to draft.json")
    ap.add_argument("--params-json", required=False, help="Draft JSON string (optional)")
    ap.add_argument(
        "--mode",
        required=False,
        choices=["step2", "topics", "step3", "createScene"],
        default="step3",
        help=(
            "step2=基础信息名称校验；"
            "topics=[deprecated]；"
            "step3=Step3 收集字段门禁；"
            "createScene=落库前字段门禁"
        ),
    )
    args = ap.parse_args()

    try:
        if args.mode == "step2":
            if not args.names_json or not args.state_json:
                raise ValueError("--mode step2 requires both --names-json and --state-json")
            names = json.loads(args.names_json)
            state = json.loads(args.state_json)
            out = _validate_step2(names, state, max_candidates=args.max_candidates)

        elif args.mode == "topics":
            if not args.topics_json or not args.state_json:
                raise ValueError("--mode topics requires both --topics-json and --state-json")
            topics = json.loads(args.topics_json)
            state = json.loads(args.state_json)
            out = _validate_topics(topics, state, drug_id=args.drug_id or "", max_candidates=args.max_candidates)

        else:
            # step3 / createScene — load from params-json or params-file
            if args.params_json:
                payload = json.loads(args.params_json)
            else:
                if not args.params_file:
                    raise ValueError("either --params-file or --params-json is required")
                payload = load_json(args.params_file)

            scene = payload.get("scene") or payload.get("draft") or payload
            if not isinstance(scene, dict):
                raise ValueError("scene must be an object")

            if args.mode == "createScene":
                out = _validate_create_scene(scene)
            else:
                out = _validate_step3(scene)

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}), file=sys.stderr)
        return 2

    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
