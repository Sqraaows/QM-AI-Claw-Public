#!/usr/bin/env python3
"""
tbs-scene-suggest-knowledge.py

POST /dialogue/scene/suggestKnowledge
  --mode suggest   : call API; fail if empty suggestions
  --mode finalize  : build knowledgeIds + knowledgeSuggestionState from acceptance
"""

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Optional

import tbs_base
from tbs_base import http_post_json


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def norm(s: Any) -> str:
    if s is None:
        return ""
    return str(s).strip().lower()


def match_drug_id(drug_name: str, drugs: List[Dict[str, Any]]) -> Optional[str]:
    t = norm(drug_name)
    if not t:
        return None
    for d in drugs:
        for key in ("name", "drugName", "title"):
            if norm(d.get(key)) == t:
                for id_key in ("id", "drugId"):
                    v = d.get(id_key)
                    if v is not None and str(v).strip():
                        return str(v)
    return None


def scene_semantic_payload(scene: Dict[str, Any]) -> Dict[str, Any]:
    rep = str(scene.get("repBriefing") or scene.get("sceneBackground") or "").strip()
    body: Dict[str, Any] = {}
    if scene.get("title"):
        body["title"] = scene["title"]
    if scene.get("location"):
        body["location"] = scene["location"]
    if rep:
        body["repBriefing"] = rep
    cp = scene.get("contextPayload")
    if isinstance(cp, dict) and cp:
        body["contextPayload"] = cp
    return body


def mode_suggest(scene: Dict[str, Any], state: Dict[str, Any], headers: Dict[str, str], base_url: str, timeout: int) -> Dict[str, Any]:
    drug_name = str(scene.get("drugName") or scene.get("drug") or "").strip()
    if not drug_name and isinstance(scene.get("drugId"), str) and not str(scene.get("drugId")).strip().isdigit():
        drug_name = str(scene.get("drugId")).strip()

    drugs = state.get("drugs") or []
    if not isinstance(drugs, list):
        drugs = []
    drug_id = match_drug_id(drug_name, drugs)
    if not drug_id:
        return {"success": False, "error": f"cannot resolve drugId from drugName={drug_name!r}"}

    api_body = {"drugId": int(drug_id) if str(drug_id).isdigit() else drug_id}
    api_body.update(scene_semantic_payload(scene))

    url = base_url.rstrip("/") + "/dialogue/scene/suggestKnowledge"
    res = http_post_json(url, headers, api_body, timeout=timeout)
    if res.get("resultCode") != 1:
        return {"success": False, "error": res.get("resultMsg", "suggestKnowledge failed"), "apiRaw": res}

    data = res.get("data") or {}
    suggestions = data.get("knowledgeSuggestions") if isinstance(data, dict) else []
    if not isinstance(suggestions, list):
        suggestions = []

    if len(suggestions) == 0:
        return {
            "success": False,
            "error": "当前场景无法推荐产品知识，无法创建场景",
            "knowledgeSuggestions": [],
        }

    by_status: Dict[str, List[Dict[str, Any]]] = {"auto-linked": [], "suggested": [], "create": []}
    for item in suggestions:
        if isinstance(item, dict):
            st = str(item.get("status") or "suggested")
            by_status.setdefault(st, []).append(item)

    def _display_row(item: Dict[str, Any]) -> Dict[str, str]:
        return {
            "topic": str(item.get("topic") or "").strip(),
            "reason": str(item.get("reason") or "").strip(),
        }

    user_display: Dict[str, Any] = {
        "autoLinked": [_display_row(x) for x in by_status.get("auto-linked", []) if isinstance(x, dict)],
        "pendingConfirm": [_display_row(x) for x in by_status.get("suggested", []) if isinstance(x, dict)],
        "suppressedCreateCount": len(by_status.get("create", [])),
    }
    if user_display["suppressedCreateCount"]:
        user_display["policyNote"] = (
            "部分主题库内暂无匹配；本创建流程不展示「建议新建」，无法在此新建产品知识。"
        )

    return {
        "success": True,
        "drugId": drug_id,
        "drugName": data.get("drugName") if isinstance(data, dict) else drug_name,
        "knowledgeSuggestions": suggestions,
        "byStatus": by_status,
        "userDisplay": user_display,
        "nextStep": {
            "parallelRequired": "Step4.2 contextPayload (scenario-parse.md)",
            "mustStartInSameTurn": True,
            "forbidden": [
                "tbs-scene-create.py before G6",
                "finalize then create without contextPayload",
            ],
            "userVisibleHint": "正在推荐产品知识并准备场景内容，请稍候…",
        },
        "apiRaw": res,
    }


def mode_finalize(scene: Dict[str, Any], suggestions: List[Dict[str, Any]]) -> Dict[str, Any]:
    acceptance = scene.get("knowledgeAcceptance") or {}
    if not isinstance(acceptance, dict):
        acceptance = {}

    accepted_ids = {str(x) for x in (acceptance.get("acceptedMatchedIds") or [])}
    rejected_ids = {str(x) for x in (acceptance.get("rejectedMatchedIds") or acceptance.get("rejectedAutoLinkedIds") or [])}

    knowledge_ids: List[str] = []
    items: List[Dict[str, Any]] = []

    for i, sug in enumerate(suggestions):
        if not isinstance(sug, dict):
            continue
        status = str(sug.get("status") or "")
        mid = sug.get("matchedKnowledgeId")
        mid_str = str(mid) if mid is not None and str(mid).strip() else ""

        include = False
        action = "dismissed"
        if status == "auto-linked" and mid_str:
            if mid_str not in rejected_ids:
                include = True
                action = "accepted"
        elif status == "suggested" and mid_str and mid_str in accepted_ids:
            include = True
            action = "accepted"
        elif status == "create":
            action = "dismissed"

        if include and mid_str and mid_str not in knowledge_ids:
            knowledge_ids.append(mid_str)

        items.append(
            {
                "id": f"sug-{i + 1:03d}",
                "title": sug.get("topic") or "",
                "description": sug.get("reason") or "",
                "status": status,
                "confidence": sug.get("confidence"),
                "matchedKnowledgeId": mid,
                "matchedKnowledgeTitle": sug.get("matchedKnowledgeTitle"),
                "actionStatus": action,
            }
        )

    state_out = {"hidden": False, "collapsed": False, "items": items}

    if not knowledge_ids:
        return {
            "success": False,
            "error": "未确认任何可关联的产品知识，无法创建场景",
            "knowledgeIds": [],
            "knowledgeSuggestionState": state_out,
        }

    return {
        "success": True,
        "knowledgeIds": knowledge_ids,
        "knowledgeSuggestionState": state_out,
        "nextStep": {
            "mustPassG6BeforeCreate": True,
            "forbiddenUntilG6": [
                "tbs-scene-create.py",
                "展示「场景创建成功」",
            ],
            "recoveryIfG6Missing": (
                "立即按 scenario-parse.md 生成完整 contextPayload（doctor 5 键 + coach 3 键），"
                "再 tbs-scene-validate.py --mode createScene"
            ),
            "then": "展示最终业务清单，等待用户「确认提交」",
        },
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--params-json", required=False)
    ap.add_argument("--params-file", required=False)
    ap.add_argument("--access-token", required=False, default="")
    ap.add_argument("--base-url", default=os.getenv("TBS_BASE_URL", tbs_base.BASE_URL))
    ap.add_argument("--timeout-sec", type=int, default=int(os.getenv("TBS_TIMEOUT_SEC", "60")))
    ap.add_argument("--mode", choices=["suggest", "finalize"], default="suggest")
    args = ap.parse_args()

    try:
        if args.params_json:
            payload = json.loads(args.params_json)
        elif args.params_file:
            payload = load_json(args.params_file)
        else:
            raise ValueError("need --params-json or --params-file")
    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}), file=sys.stderr)
        return 2

    scene = payload.get("scene") or payload
    state = payload.get("state") or {}
    if not isinstance(scene, dict):
        print(json.dumps({"success": False, "error": "scene must be object"}), file=sys.stderr)
        return 2

    headers = {"access-token": args.access_token, "Content-Type": "application/json"}

    try:
        if args.mode == "suggest":
            if not args.access_token:
                print(json.dumps({"success": False, "error": "suggest mode requires --access-token"}), file=sys.stderr)
                return 2
            out = mode_suggest(scene, state, headers, args.base_url, max(1, args.timeout_sec))
        else:
            suggestions = scene.get("knowledgeSuggestions") or payload.get("knowledgeSuggestions") or []
            if not isinstance(suggestions, list):
                suggestions = []
            out = mode_finalize(scene, suggestions)
    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}), file=sys.stderr)
        return 1

    print(json.dumps(out, ensure_ascii=False))
    return 0 if out.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(main())
