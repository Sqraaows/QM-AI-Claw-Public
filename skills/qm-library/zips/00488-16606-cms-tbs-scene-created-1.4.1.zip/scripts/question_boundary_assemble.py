#!/usr/bin/env python3
"""
question_boundary_assemble.py

提问边界第一层（固定）由脚本逐字拼接；模型/Agent 仅提供第二层 3～5 条。

用法：
  # contextPayload 落库形态（## 提问边界）
  python3 scripts/question_boundary_assemble.py assemble --format context --layer2-file layer2.txt

  # doctor_context 解析形态（## 提问边界（强制））
  python3 scripts/question_boundary_assemble.py assemble --format doctor_context --layer2-file layer2.txt

  python3 scripts/question_boundary_assemble.py patch-draft --draft-file draft.json --layer2-file layer2.txt

  python3 scripts/question_boundary_assemble.py patch-doctor-context --json-file parsed.json --layer2-file layer2.txt

  python3 scripts/question_boundary_assemble.py validate --text-file qb.txt
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

ROOT_CONTEXT = "## 提问边界"
ROOT_DOCTOR_CONTEXT = "## 提问边界（强制）"

_LAYER1_AND_LAYER2_HEADERS = (
    "### 第一层：永远禁止（所有场景通用）\n"
    "- 禁止询问患者病历、诊断、隐私\n"
    "- 禁止要求代表推导产品知识中没有的数据\n"
    "- 禁止编造任何数值\n"
    '- 资料/文献/交付物：全场至多确认 1 次（"嗯，知道了"），后续双方不得再提交付形式（放哪、带什么、发您、有空看看等）\n\n'
    "### 第二层：本场景允许问的方向\n"
)

# 兼容旧 import
QUESTION_BOUNDARY_PREFIX = ROOT_CONTEXT + "\n\n" + _LAYER1_AND_LAYER2_HEADERS

_LAYER2_HEADER = "### 第二层：本场景允许问的方向"
_QB_SECTION_RE = re.compile(
    r"## 提问边界(?:（强制）)?\s*\n[\s\S]*?(?=\n## |\Z)"
)
_ASKABLE_RE = re.compile(
    r"^- 可问：(.+?)（基于产品知识中已有内容）\s*$"
)
_MIN_LAYER2 = 3
_MAX_LAYER2 = 5


def question_boundary_prefix(fmt: str = "context") -> str:
    root = ROOT_DOCTOR_CONTEXT if fmt == "doctor_context" else ROOT_CONTEXT
    return root + "\n\n" + _LAYER1_AND_LAYER2_HEADERS


def normalize_layer2_line(line: str) -> Optional[str]:
    s = line.strip()
    if not s:
        return None
    if s.startswith("- 可问：") and "（基于产品知识中已有内容）" in s:
        return s
    if s.startswith("- 可问："):
        body = s[len("- 可问：") :].strip()
        if body.endswith("（基于产品知识中已有内容）"):
            return s
        return f"- 可问：{body}（基于产品知识中已有内容）"
    if s.startswith("-"):
        body = s.lstrip("-").strip()
        return f"- 可问：{body}（基于产品知识中已有内容）"
    return f"- 可问：{s}（基于产品知识中已有内容）"


def parse_layer2_input(text: str) -> List[str]:
    """从模型输出或完整 question_boundary 中提取第二层 bullet 行。"""
    raw = (text or "").strip()
    if not raw:
        return []

    if _LAYER2_HEADER in raw:
        _, _, tail = raw.partition(_LAYER2_HEADER)
        raw = tail.strip()

    lines: List[str] = []
    for line in raw.splitlines():
        if _LAYER2_HEADER in line or line.strip().startswith("### 第一层"):
            continue
        if line.strip().startswith("## 提问边界"):
            continue
        norm = normalize_layer2_line(line)
        if norm:
            lines.append(norm)
    return lines


def assemble_question_boundary(layer2_input: str, fmt: str = "context") -> str:
    """拼接完整字符串。fmt: context | doctor_context"""
    lines = parse_layer2_input(layer2_input)
    if not lines:
        raise ValueError("第二层为空：至少需要 3 条「- 可问：…（基于产品知识中已有内容）」")
    body = "\n".join(lines)
    return question_boundary_prefix(fmt) + body + "\n"


def detect_question_boundary_format(full_text: str) -> str:
    t = (full_text or "").lstrip()
    if t.startswith(ROOT_DOCTOR_CONTEXT):
        return "doctor_context"
    return "context"


def split_question_boundary(full_text: str) -> Tuple[str, List[str], str]:
    text = (full_text or "").strip() + "\n"
    fmt = detect_question_boundary_format(text)
    prefix = question_boundary_prefix(fmt)
    if text.startswith(prefix):
        tail = text[len(prefix) :]
        return prefix, parse_layer2_input(tail), fmt
    return "", parse_layer2_input(full_text), fmt


def _direction_char_len(direction: str) -> int:
    return len(direction.strip())


def validate_layer2_lines(lines: List[str]) -> List[str]:
    issues: List[str] = []
    n = len(lines)
    if n < _MIN_LAYER2:
        issues.append(f"layer2_count_lt_{_MIN_LAYER2}:got_{n}")
    elif n > _MAX_LAYER2:
        issues.append(f"layer2_count_gt_{_MAX_LAYER2}:got_{n}")

    for i, line in enumerate(lines, 1):
        m = _ASKABLE_RE.match(line)
        if not m:
            issues.append(f"layer2_line_{i}_format_invalid")
            continue
        dlen = _direction_char_len(m.group(1))
        if dlen < 6 or dlen > 16:
            issues.append(f"layer2_line_{i}_direction_len_{dlen}_not_6_16")
    return issues


def validate_question_boundary(full_text: str, *, strict_layer1: bool = True) -> Dict[str, Any]:
    text = (full_text or "").strip()
    if not text:
        return {"passed": False, "issues": ["empty"]}

    issues: List[str] = []
    fmt = detect_question_boundary_format(text)
    expected_prefix = question_boundary_prefix(fmt)

    if strict_layer1:
        if not text.startswith("## 提问边界"):
            issues.append("missing_root_header")
        if not text.startswith(expected_prefix):
            issues.append("layer1_not_script_canonical")

    prefix, lines, _ = split_question_boundary(text + "\n")
    if strict_layer1 and not prefix:
        issues.append("layer1_prefix_mismatch")

    issues.extend(validate_layer2_lines(lines))
    return {
        "passed": len(issues) == 0,
        "issues": issues,
        "format": fmt,
        "layer2Count": len(lines),
        "layer2Lines": lines,
    }


def merge_doctor_context_question_boundary(doctor_context: str, layer2_input: str) -> str:
    """将 doctor_context 内提问边界节替换为脚本拼接后的完整两层结构。"""
    assembled = assemble_question_boundary(layer2_input, fmt="doctor_context").strip()
    dc = doctor_context or ""
    if _QB_SECTION_RE.search(dc):
        return _QB_SECTION_RE.sub(assembled + "\n\n", dc, count=1).rstrip() + "\n"
    marker = "## 终止条件（医生结束对话）"
    if marker in dc:
        return dc.replace(marker, assembled + "\n\n" + marker, 1)
    return dc.rstrip() + "\n\n" + assembled + "\n"


def patch_draft_question_boundary(draft: Dict[str, Any], layer2_input: str) -> Dict[str, Any]:
    scene = draft.get("scene")
    if not isinstance(scene, dict):
        scene = draft
    cp = scene.get("contextPayload")
    if not isinstance(cp, dict):
        cp = {}
    doctor = cp.get("doctor")
    if not isinstance(doctor, dict):
        doctor = {}
    doctor["question_boundary"] = assemble_question_boundary(layer2_input, fmt="context")
    cp["doctor"] = doctor
    scene["contextPayload"] = cp
    if "scene" in draft:
        draft["scene"] = scene
    else:
        draft.update(scene)
    return draft


def patch_parsed_doctor_context(payload: Dict[str, Any], layer2_input: str) -> Dict[str, Any]:
    """写入解析 JSON 的 ai_roles.doctor_context。"""
    ai = payload.get("ai_roles")
    if not isinstance(ai, dict):
        ai = {}
    dc = str(ai.get("doctor_context") or "")
    ai["doctor_context"] = merge_doctor_context_question_boundary(dc, layer2_input)
    payload["ai_roles"] = ai
    return payload


def _load_text(path: Optional[str], inline: Optional[str]) -> str:
    if inline is not None and inline != "":
        return inline
    if not path:
        raise ValueError("需要 --layer2-text / --text 或对应 --*-file")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def main() -> int:
    ap = argparse.ArgumentParser(description="提问边界第一层脚本拼接")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add_layer2_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--layer2-text", default="", help="第二层多行文本")
        p.add_argument("--layer2-file", default="", help="第二层文件路径")

    p_asm = sub.add_parser("assemble", help="第二层 → 完整提问边界")
    add_layer2_args(p_asm)
    p_asm.add_argument(
        "--format",
        choices=["context", "doctor_context"],
        default="context",
        help="context=contextPayload；doctor_context=解析 doctor_context 节",
    )
    p_asm.add_argument("--json", action="store_true", help="输出 JSON")

    p_patch = sub.add_parser("patch-draft", help="写入 draft.contextPayload.doctor.question_boundary")
    p_patch.add_argument("--draft-file", required=True)
    add_layer2_args(p_patch)

    p_pdc = sub.add_parser("patch-doctor-context", help="写入解析 JSON 的 doctor_context 提问边界节")
    p_pdc.add_argument("--json-file", required=True)
    add_layer2_args(p_pdc)

    p_val = sub.add_parser("validate", help="校验完整提问边界")
    p_val.add_argument("--text", default="")
    p_val.add_argument("--text-file", default="")
    p_val.add_argument("--draft-file", default="")
    p_val.add_argument("--allow-noncanonical-layer1", action="store_true")

    args = ap.parse_args()

    try:
        if args.cmd == "assemble":
            layer2 = _load_text(args.layer2_file or None, args.layer2_text or None)
            qb = assemble_question_boundary(layer2, fmt=args.format)
            if args.json:
                key = "doctor_context_section" if args.format == "doctor_context" else "question_boundary"
                print(json.dumps({key: qb}, ensure_ascii=False))
            else:
                print(qb, end="")
            return 0

        if args.cmd == "patch-draft":
            layer2 = _load_text(args.layer2_file or None, args.layer2_text or None)
            with open(args.draft_file, "r", encoding="utf-8") as f:
                draft = json.load(f)
            draft = patch_draft_question_boundary(draft, layer2)
            with open(args.draft_file, "w", encoding="utf-8") as f:
                json.dump(draft, f, ensure_ascii=False, indent=2)
                f.write("\n")
            out = validate_question_boundary(
                _cp_question_boundary(draft), strict_layer1=True
            )
            print(
                json.dumps(
                    {"success": True, "draftFile": args.draft_file, "validation": out},
                    ensure_ascii=False,
                )
            )
            return 0 if out["passed"] else 1

        if args.cmd == "patch-doctor-context":
            layer2 = _load_text(args.layer2_file or None, args.layer2_text or None)
            with open(args.json_file, "r", encoding="utf-8") as f:
                payload = json.load(f)
            payload = patch_parsed_doctor_context(payload, layer2)
            with open(args.json_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
                f.write("\n")
            dc = str((payload.get("ai_roles") or {}).get("doctor_context") or "")
            out = validate_question_boundary(dc, strict_layer1=True)
            print(
                json.dumps(
                    {"success": True, "jsonFile": args.json_file, "validation": out},
                    ensure_ascii=False,
                )
            )
            return 0 if out["passed"] else 1

        if args.cmd == "validate":
            if args.draft_file:
                with open(args.draft_file, "r", encoding="utf-8") as f:
                    payload = json.load(f)
                text = _cp_question_boundary(payload)
            else:
                text = _load_text(args.text_file or None, args.text or None)
            out = validate_question_boundary(
                text, strict_layer1=not args.allow_noncanonical_layer1
            )
            print(json.dumps({"success": True, **out}, ensure_ascii=False))
            return 0 if out["passed"] else 1

    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 2

    return 2


def _cp_question_boundary(payload: Dict[str, Any]) -> str:
    scene = payload.get("scene") or payload.get("draft") or payload
    if not isinstance(scene, dict):
        return ""
    cp = scene.get("contextPayload") or {}
    doctor = cp.get("doctor") or {}
    return str(doctor.get("question_boundary") or "")


if __name__ == "__main__":
    raise SystemExit(main())
