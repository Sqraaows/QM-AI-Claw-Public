#!/usr/bin/env python3
"""
tbs-scene-fetch-config.py

Best-effort resolver for Step1:
Resolve businessDomainId/departmentId/drugId from names by calling:
 - POST /businessDomain/listBusinessDomains
 - POST /department/listDepartments
 - POST /drug/listDrugs

Because TBS list endpoints request/response payloads may differ by backend,
this script tries a few common request bodies and response shapes.
"""

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

import tbs_base
from tbs_base import http_post_json, http_get_json


def pick_list(data: Any) -> List[Dict[str, Any]]:
    """
    Try to normalize various response shapes into a list of objects.
    Common shapes:
    - data: [{...}]
    - data: { list/records/items: [{...}] }
    """
    if data is None:
        return []
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict):
        for key in ("records", "list", "items", "data"):
            v = data.get(key)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
    return []


def norm(s: Any) -> str:
    if s is None:
        return ""
    return str(s).strip().lower()


_STEP2_GREETING_FALLBACK = (
    "你好，我来帮你创建场景。\n"
    "先一句话说下你要创建的场景就行（不完整没关系）。\n"
    "比如：心内科 + 新活素 + 病房拜访，医生担心安全性。\n"
    "我会先整理成确认清单，再每次补问 1–2 个缺口。"
)


def load_step2_greeting() -> str:
    """
    Load Step2 opening message from references/step2/default-input-template.md
    (```text``` fence). Single source of truth for warm greeting after Step1.
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    template_path = os.path.join(
        script_dir, "..", "references", "step2", "default-input-template.md"
    )
    try:
        with open(template_path, "r", encoding="utf-8") as f:
            content = f.read()
    except OSError:
        return _STEP2_GREETING_FALLBACK

    marker = "```text"
    start = content.find(marker)
    if start < 0:
        return _STEP2_GREETING_FALLBACK
    start = content.find("\n", start)
    if start < 0:
        return _STEP2_GREETING_FALLBACK
    start += 1
    end = content.find("```", start)
    if end < 0:
        return _STEP2_GREETING_FALLBACK
    text = content[start:end].strip("\n")
    return text if text else _STEP2_GREETING_FALLBACK


def match_by_name(items: List[Dict[str, Any]], target_name: str) -> Optional[Dict[str, Any]]:
    t = norm(target_name)
    if not t:
        return None

    # 1) exact match on common name keys
    name_keys = ("name", "title", "drugName", "departmentName", "businessDomainName")
    for it in items:
        for k in name_keys:
            if norm(it.get(k)) == t:
                return it

    # 2) contains match
    for it in items:
        for k in name_keys:
            v = norm(it.get(k))
            if v and (t in v or v in t):
                return it

    return None


def resolve_one_list(
    url: str,
    headers: Dict[str, str],
    items: List[Dict[str, Any]],
    target_name: str,
) -> Tuple[Optional[str], Optional[str]]:
    hit = match_by_name(items, target_name)
    if not hit:
        return None, None

    # Common id keys
    for id_key in ("id", "code", "drugId", "departmentId", "businessDomainId"):
        v = hit.get(id_key)
        if v is not None and str(v).strip() != "":
            return str(v), hit.get("name") or hit.get("title") or hit.get(id_key)
    return None, None


def resolve_name_by_id(items: List[Dict[str, Any]], id_value: Optional[str]) -> str:
    if not id_value:
        return ""
    for it in items:
        for id_key in ("id", "code", "drugId", "departmentId", "businessDomainId"):
            v = it.get(id_key)
            if v is not None and str(v).strip() == str(id_value):
                for name_key in ("name", "title", "drugName", "departmentName", "businessDomainName"):
                    nv = it.get(name_key)
                    if nv is not None and str(nv).strip() != "":
                        return str(nv)
    return ""


def normalize_knowledge_item(it: Dict[str, Any]) -> Optional[Dict[str, str]]:
    knowledge_id = it.get("knowledgeId")
    if knowledge_id is None or str(knowledge_id).strip() == "":
        knowledge_id = it.get("id") or it.get("ID")
    drug_id = it.get("drugId")
    if drug_id is None or str(drug_id).strip() == "":
        drug_id = it.get("drugID")
    category = it.get("category")
    if category is None or str(category).strip() == "":
        category = it.get("type")
    title = it.get("title")
    if title is None or str(title).strip() == "":
        title = it.get("name")

    if knowledge_id is None or str(knowledge_id).strip() == "":
        return None

    return {
        "knowledgeId": str(knowledge_id),
        "drugId": "" if drug_id is None else str(drug_id),
        "category": "" if category is None else str(category),
        "title": "" if title is None else str(title),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--access-token", required=True, help="TBS access-token")
    ap.add_argument("--base-url", default=os.getenv("TBS_BASE_URL", tbs_base.BASE_URL))
    ap.add_argument("--timeout-sec", type=int, default=int(os.getenv("TBS_TIMEOUT_SEC", "60")))
    ap.add_argument("--retries", type=int, default=int(os.getenv("TBS_HTTP_RETRIES", "1")))
    ap.add_argument("--business-domain-name", required=False, default="")
    ap.add_argument("--department-name", required=False, default="")
    ap.add_argument("--drug-name", required=False, default="")
    ap.add_argument("--params-json", required=False, help="Optional JSON for names")
    ap.add_argument(
        "--debug",
        action="store_true",
        default=str(os.getenv("TBS_DEBUG", "")).strip().lower() in ("1", "true", "yes", "y", "on"),
        help="Include debug section in stdout (default: off).",
    )
    ap.add_argument(
        "--knowledge-scope",
        required=False,
        choices=["auto", "none", "all"],
        default=os.getenv("TBS_KNOWLEDGE_SCOPE", "none"),
        help=(
            "How to fetch product knowledge list. "
            "auto=only fetch when drugId is resolved (recommended); "
            "none=never fetch; "
            "all=allow broader fetch (may be large)."
        ),
    )
    args = ap.parse_args()

    names = {
        "businessDomainName": args.business_domain_name,
        "departmentName": args.department_name,
        "drugName": args.drug_name,
    }
    if args.params_json:
        try:
            pj = json.loads(args.params_json)
            names.update(pj)
        except Exception:
            print(json.dumps({"success": False, "error": "params-json is not valid json"}), file=sys.stderr)
            return 2

    business_name = names.get("businessDomainName", "")
    dept_name = names.get("departmentName", "")
    drug_name = names.get("drugName", "")

    headers = {
        "access-token": args.access_token,
        "Content-Type": "application/json",
    }
    base = args.base_url.rstrip("/")
    timeout_sec = max(1, args.timeout_sec)
    retries = max(0, args.retries)

    # Common request body candidates
    bodies_to_try = [{}, {"pageNum": 1, "pageSize": 50}, {"pageIndex": 1, "pageSize": 50}]

    def fetch_list(path: str) -> List[Dict[str, Any]]:
        url = base + path
        last_err = None
        for body in bodies_to_try:
            try:
                res = http_post_json(url, headers, body, timeout=timeout_sec, retries=retries)
                # admin list APIs usually wrap: {resultCode,resultMsg,data}
                data = res.get("data")
                return pick_list(data)
            except Exception as e:
                last_err = e
                continue
        raise RuntimeError(f"fetch_list failed for {path}: {last_err}")

    try:
        domains = fetch_list("/businessDomain/listBusinessDomains")
        depts = fetch_list("/department/listDepartments")
        drugs = fetch_list("/drug/listDrugs")
    except Exception as e:
        print(json.dumps({"success": False, "error": f"fetch config failed: {e}"}), file=sys.stderr)
        return 1

    businessDomainId, _ = resolve_one_list("", headers, domains, business_name)
    departmentId, _ = resolve_one_list("", headers, depts, dept_name)
    drugId, _ = resolve_one_list("", headers, drugs, drug_name)
    selected_business_name = business_name or resolve_name_by_id(domains, businessDomainId)
    selected_dept_name = dept_name or resolve_name_by_id(depts, departmentId)
    selected_drug_name = drug_name or resolve_name_by_id(drugs, drugId)

    # Step1 also needs product knowledge master data for Step4 topic matching.
    knowledge_candidates: List[Dict[str, Any]] = []
    knowledge_fetch_error = ""
    knowledge_endpoints_tried: List[str] = []

    # 3.1: Avoid fetching a huge global knowledge list.
    # Default behavior is to only fetch knowledge after drugId is resolved (knowledge-scope=auto).
    scope = (args.knowledge_scope or "auto").strip().lower()
    if scope == "none":
        knowledge_endpoints_tried.append("SKIP knowledge fetch (knowledge-scope=none)")
    elif scope == "auto" and not drugId:
        knowledge_endpoints_tried.append("SKIP knowledge fetch (knowledge-scope=auto, drugId unresolved)")
    else:
        # First try admin list endpoint (POST). Prefer drug-scoped queries first.
        knowledge_bodies: List[Dict[str, Any]] = []
        if drugId:
            knowledge_bodies.extend(
                [
                    {"drugId": drugId, "pageNum": 1, "pageSize": 200},
                    {"drugId": drugId, "pageIndex": 1, "pageSize": 200},
                    {"drugId": drugId},
                ]
            )
        # Only allow broader fetch when explicitly requested.
        if scope == "all":
            knowledge_bodies.extend(
                [
                    {"pageNum": 1, "pageSize": 200},
                    {"pageIndex": 1, "pageSize": 200},
                    {},
                ]
            )

        for body in knowledge_bodies:
            knowledge_endpoints_tried.append(f"POST /knowledge/listProductKnowledge body={body}")
            try:
                res = http_post_json(
                    base + "/knowledge/listProductKnowledge",
                    headers,
                    body,
                    timeout=timeout_sec,
                    retries=retries,
                )
                rows = pick_list(res.get("data"))
                if rows:
                    knowledge_candidates = rows
                    break
            except Exception as e:
                knowledge_fetch_error = str(e)

        # Fallback to resource select endpoint (GET), commonly used by select/dropdown.
        if not knowledge_candidates:
            try:
                knowledge_endpoints_tried.append("GET /knowledge/forResourceSelect")
                res = http_get_json(
                    base + "/knowledge/forResourceSelect",
                    headers,
                    query={"drugId": drugId or ""},
                    timeout=timeout_sec,
                    retries=retries,
                )
                knowledge_candidates = pick_list(res.get("data"))
            except Exception as e:
                knowledge_fetch_error = str(e)

    knowledge_list: List[Dict[str, str]] = []
    seen_knowledge_ids = set()
    for raw in knowledge_candidates:
        if not isinstance(raw, dict):
            continue
        item = normalize_knowledge_item(raw)
        if not item:
            continue
        kid = item["knowledgeId"]
        if kid in seen_knowledge_ids:
            continue
        seen_knowledge_ids.add(kid)
        knowledge_list.append(item)

    def norm_list(items: List[Dict[str, Any]], id_keys: List[str], name_keys: List[str]) -> List[Dict[str, str]]:
        """Normalize a raw API list to [{id, name}] for state storage."""
        result = []
        seen = set()
        for it in items:
            item_id = ""
            for k in id_keys:
                v = it.get(k)
                if v is not None and str(v).strip():
                    item_id = str(v).strip()
                    break
            item_name = ""
            for k in name_keys:
                v = it.get(k)
                if v is not None and str(v).strip():
                    item_name = str(v).strip()
                    break
            if not item_id:
                continue
            if item_id in seen:
                continue
            if not item_name:
                # Skip entries with empty names — they cannot be presented to users
                continue
            seen.add(item_id)
            result.append({"id": item_id, "name": item_name})
        return result

    domains_list = norm_list(
        domains,
        id_keys=["id", "businessDomainId", "code"],
        name_keys=["name", "businessDomainName", "title"],
    )
    depts_list = norm_list(
        depts,
        id_keys=["id", "departmentId", "code"],
        name_keys=["name", "departmentName", "title"],
    )
    drugs_list = norm_list(
        drugs,
        id_keys=["id", "drugId", "code"],
        name_keys=["name", "drugName", "title"],
    )

    g2_ready = bool(domains_list and depts_list and drugs_list)

    out: Dict[str, Any] = {
        "success": True,
        "resolved": {
            "businessDomainId": businessDomainId,
            "departmentId": departmentId,
            "drugId": drugId,
        },
        "masterData": {
            "knowledgeList": knowledge_list,
        },
        "state": {
            "businessDomains": domains_list,
            "departments": depts_list,
            "drugs": drugs_list,
            "productKnowledges": knowledge_list,
        },
        "gate": {
            "g2Passed": g2_ready,
        },
    }
    if g2_ready:
        out["nextStep"] = {
            "step": 2,
            "userVisibleMessage": load_step2_greeting(),
            "mustDisplayVerbatim": True,
            "forbiddenOnFirstTurn": [
                "enumerateAllBusinessDomains",
                "enumerateAllDepartments",
                "enumerateAllDrugs",
                "questionnaireStylePickOne",
            ],
        }
    if args.debug:
        out["debug"] = {
            "matchedNames": {
                "businessDomainName": business_name,
                "departmentName": dept_name,
                "drugName": drug_name,
            },
            "counts": {
                "domains": len(domains),
                "departments": len(depts),
                "drugs": len(drugs),
                "productKnowledges": len(knowledge_list),
            },
            "knowledgeFetch": {
                "endpointsTried": knowledge_endpoints_tried,
                "lastError": knowledge_fetch_error,
            },
        }
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

