#!/usr/bin/env python3
"""
tbs-scene-create.py

Call POST /scene/sceneAudit/createSxkDraftAndSubmitAudit with prepared scene draft.
Replaces the old /scene/createScene endpoint for 深西康一线案例输入 scenes.
"""

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

import tbs_base
from tbs_base import http_post_json, http_get_json

_AI_SUFFIX_RE = re.compile(r"^（AI生成，可修改）\s*")


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def pick_list(data: Any) -> List[Dict[str, Any]]:
    """
    Normalize various response shapes into a list of dict items.
    """
    if data is None:
        return []
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict):
        for key in ("records", "list", "items", "data"):
            v = data.get(key)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
    return []


def norm(s: Any) -> str:
    if s is None:
        return ""
    return str(s).strip().lower()


def match_by_name(items: List[Dict[str, Any]], target_name: str) -> Optional[Dict[str, Any]]:
    t = norm(target_name)
    if not t:
        return None

    name_keys = ("name", "title", "drugName", "departmentName", "businessDomainName")
    for it in items:
        for k in name_keys:
            if norm(it.get(k)) == t:
                return it

    for it in items:
        for k in name_keys:
            v = norm(it.get(k))
            if v and (t in v or v in t):
                return it

    return None


def resolve_one_list(items: List[Dict[str, Any]], target_name: str) -> Tuple[Optional[str], Optional[str]]:
    hit = match_by_name(items, target_name)
    if not hit:
        return None, None

    for id_key in ("id", "code", "drugId", "departmentId", "businessDomainId"):
        v = hit.get(id_key)
        if v is not None and str(v).strip() != "":
            return str(v), hit.get("name") or hit.get("title") or hit.get(id_key)
    return None, None


def is_numeric_id(v: Any) -> bool:
    if v is None:
        return False
    s = str(v).strip()
    return s.isdigit()


def _strip_ai_tag(value: Any) -> str:
    if not isinstance(value, str):
        return str(value or "").strip()
    s = value.strip()
    while True:
        m = _AI_SUFFIX_RE.match(s)
        if not m:
            break
        s = s[m.end() :].strip()
    if s.startswith("（AI生成，可修改）"):
        s = s.replace("（AI生成，可修改）", "", 1).strip()
    return s


def _best_practice_points_from_scene(scene: Dict[str, Any]) -> Dict[str, Any]:
    for key in ("bestPracticePoints", "bestPractice"):
        v = scene.get(key)
        if isinstance(v, dict):
            return v
    sb = scene.get("scenarioBase")
    if isinstance(sb, dict):
        for key in ("bestPracticePoints", "bestPractice"):
            v = sb.get(key)
            if isinstance(v, dict):
                return v
    return {}


def best_practices_markdown_from_points(bp: Dict[str, Any]) -> str:
    """Step2 三项 → contextPayload.coach.best_practices（3 条 - 要点）。"""
    lines: List[str] = []
    for src_key in ("openingScript", "questionResponseScript", "recommendation"):
        val = _strip_ai_tag(bp.get(src_key))
        if val:
            lines.append(f"- {val}")
    return "\n".join(lines)


_CONTEXT_PAYLOAD_REQUIRED: Tuple[Tuple[str, str], ...] = (
    ("doctor", "known_background"),
    ("doctor", "core_concerns"),
    ("doctor", "today_status"),
    ("doctor", "question_boundary"),
    ("doctor", "termination_rules"),
    ("coach", "expected_behaviors"),
    ("coach", "termination_rules"),
    ("coach", "best_practices"),
)


def _cp_get(cp: Dict[str, Any], side: str, key: str) -> Any:
    block = cp.get(side)
    return block.get(key) if isinstance(block, dict) else None


def missing_context_payload_fields(scene: Dict[str, Any]) -> List[str]:
    """G6：落库前 doctor 5 键 + coach 3 键均须非空（与 tbs-scene-validate createScene 一致）。"""
    missing: List[str] = []
    cp = scene.get("contextPayload")
    if not isinstance(cp, dict):
        return ["contextPayload"]
    for side, key in _CONTEXT_PAYLOAD_REQUIRED:
        val = _cp_get(cp, side, key)
        if val is None or not str(val).strip():
            missing.append(f"contextPayload.{side}.{key}")
    return missing


def ensure_coach_best_practices(scene: Dict[str, Any]) -> Dict[str, Any]:
    """
    落库前兜底：若 coach.best_practices 为空，从 scene.bestPracticePoints 映射。
    Agent 漏做 coach.best_practices 映射（见 scenario-parse.md ③ 生成顺序）时仍可带上最佳实践。
    """
    cp = scene.get("contextPayload")
    if not isinstance(cp, dict):
        cp = {"version": 1}
    coach = cp.get("coach")
    if not isinstance(coach, dict):
        coach = {}
        cp["coach"] = coach
    if str(coach.get("best_practices") or "").strip():
        scene["contextPayload"] = cp
        return scene
    md = best_practices_markdown_from_points(_best_practice_points_from_scene(scene))
    if md:
        coach["best_practices"] = md
    scene["contextPayload"] = cp
    return scene


def sanitize_context(text: Any) -> str:
    """
    Best-effort sanitation for context fields.

    Replace half-width double quotes (") with Chinese corner quotes (「」) to reduce
    the chance of downstream JSON/transport issues when upstream data is edited externally
    or generated with occasional violations.

    Contract: doctorOnlyContext/coachOnlyContext should NOT contain half-width double quotes.
    If a future scenario requires preserving '"', revisit this function and the docs together.
    """
    if text is None:
        return ""
    s = str(text)
    if '"' not in s:
        return s
    # Replace ASCII quotes with paired Chinese corner quotes to keep readability.
    # If quotes are unbalanced, the last one will be treated as an opening quote.
    out: List[str] = []
    in_quote = False
    for ch in s:
        if ch == '"':
            out.append("「" if not in_quote else "」")
            in_quote = not in_quote
        else:
            out.append(ch)
    return "".join(out)


def normalize_scene(scene: Dict[str, Any]) -> Dict[str, Any]:
    """
    将 Step3 草稿嵌套结构规整为落库所需扁平结构。
    幂等：字段已存在时不覆盖。
    规整内容：
      1. scenarioBase.location → 顶层 location
      2. scenarioBase.department → 顶层 departmentId（名称字符串，供 maybe_resolve_dept_domain_ids 解析）
      3. scenarioBase.businessDomain → 顶层 businessDomainId（名称字符串，同上）
      4. knowledgeIds 元素归一化为字符串
    draft.json 仅存名称；name→ID 解析由 maybe_resolve_dept_domain_ids 在落库前完成，
    不在此处写入数值 ID，避免 Agent 猜错 ID。
    """
    sb = scene.get("scenarioBase")
    if isinstance(sb, dict):
        if not scene.get("location") and sb.get("location"):
            scene["location"] = sb["location"]
        # 提升科室/业务领域名称到顶层，供 maybe_resolve_dept_domain_ids 做 name→id 解析
        if not scene.get("departmentId") and sb.get("department"):
            scene["departmentId"] = sb["department"]
        if not scene.get("businessDomainId") and sb.get("businessDomain"):
            scene["businessDomainId"] = sb["businessDomain"]

    k_ids = scene.get("knowledgeIds")
    if isinstance(k_ids, list):
        scene["knowledgeIds"] = [str(k) for k in k_ids]

    return scene


def fetch_list(base: str, path: str, headers: Dict[str, str], timeout_sec: int, retries: int) -> List[Dict[str, Any]]:
    url = base + path
    bodies_to_try = [{}, {"pageNum": 1, "pageSize": 50}, {"pageIndex": 1, "pageSize": 50}]
    last_err: Optional[Exception] = None
    for body in bodies_to_try:
        try:
            res = http_post_json(url, headers, body, timeout=timeout_sec, retries=retries)
            return pick_list(res.get("data"))
        except Exception as e:
            last_err = e
            continue
    raise RuntimeError(f"fetch_list failed for {path}: {last_err}")


def resolve_drug_name(scene: Dict[str, Any]) -> str:
    """Create API uses drugName only; do not resolve to drugId for落库."""
    name = str(scene.get("drugName") or "").strip()
    if name:
        return name
    legacy = scene.get("drugId")
    if legacy is not None and not is_numeric_id(legacy):
        return str(legacy).strip()
    return ""


def maybe_resolve_dept_domain_ids(
    scene: Dict[str, Any],
    headers: Dict[str, str],
    base_url: str,
    timeout_sec: int,
    retries: int,
) -> Dict[str, Any]:
    """Resolve departmentId / businessDomainId only. drugName is passed through to API."""
    base = base_url.rstrip("/")
    dept_val = scene.get("departmentId")
    domain_val = scene.get("businessDomainId")

    need_resolve = (not is_numeric_id(dept_val)) or (not is_numeric_id(domain_val))
    if not need_resolve:
        return scene

    domains = fetch_list(base, "/businessDomain/listBusinessDomains", headers, timeout_sec, retries)
    depts = fetch_list(base, "/department/listDepartments", headers, timeout_sec, retries)

    domain_id, _ = resolve_one_list(domains, domain_val) if not is_numeric_id(domain_val) else (str(domain_val), None)
    department_id, _ = resolve_one_list(depts, dept_val) if not is_numeric_id(dept_val) else (str(dept_val), None)

    if not domain_id or not department_id:
        raise RuntimeError(
            f"resolve ids failed (domainId={domain_id}, departmentId={department_id}) "
            f"from (domain='{domain_val}', dept='{dept_val}')"
        )

    scene["businessDomainId"] = domain_id
    scene["departmentId"] = department_id
    return scene


def resolve_persona(
    scene: Dict[str, Any],
    headers: Dict[str, str],
    base_url: str,
    timeout_sec: int,
    retries: int,
) -> Dict[str, Any]:
    """
    组装 scene.personas（新接口格式）。
    - 若能在已有画像列表中精确/模糊命中 → mode: "reuse" + personaId
    - 未命中 → mode: "scene_private" + personaDraft 内联（无需单独调用 createRolePersona）
    禁止向用户提问；失败时抛出异常由调用方处理。
    """
    base = base_url.rstrip("/")

    # 从 scene 中提取画像四要素
    doctor_persona = scene.get("doctorPersona") or {}
    surname = str(doctor_persona.get("surname") or scene.get("surname") or "").strip()
    title = str(doctor_persona.get("title") or scene.get("doctorTitle") or "").strip()
    description = str(doctor_persona.get("description") or doctor_persona.get("introDescription") or "").strip()
    persona_config_raw = doctor_persona.get("personaConfig") or doctor_persona.get("personality") or ""
    if not isinstance(persona_config_raw, str):
        persona_config_raw = ""
    comm_style = str(doctor_persona.get("communicationStyle") or "").strip()
    behavior = str(doctor_persona.get("behaviorTendency") or "").strip()
    if comm_style or behavior:
        persona_config = persona_config_raw.strip()
        if comm_style:
            persona_config += f"\n沟通风格：{comm_style}"
        if behavior:
            persona_config += f"\n行为倾向：{behavior}"
    else:
        persona_config = persona_config_raw.strip()

    name = f"{surname}{title}" if (surname or title) else "医生画像"

    # 优先级约束：
    # - 只要本次会话已提供较完整画像信息（描述/配置/沟通风格/行为倾向任一存在），必须以内联草稿 scene_private 落库，
    #   即便上游入参已带 personas（例如 reuse + personaId），也要覆盖，避免“会话输入 vs 落库画像”不一致。
    # - 仅在画像信息极简（只提供姓氏+职称）时，才允许尝试复用；复用规则为「职称完全匹配 + 姓氏可模糊匹配」兜底。
    has_rich_persona = bool(description or persona_config or comm_style or behavior)
    should_try_reuse = bool(surname and title) and (not has_rich_persona)

    # 尝试查找已有画像（精确匹配：姓氏 + 职称）
    matched_id: Optional[str] = None
    try:
        if should_try_reuse:
            res = http_get_json(base + "/rolePersona/forResourceSelect", headers, timeout=timeout_sec, retries=retries)
            existing_list: List[Dict[str, Any]] = pick_list(res.get("data") if isinstance(res, dict) else res)

            for p in existing_list:
                p_surname = norm(p.get("surname") or p.get("name") or "")
                p_title = norm(p.get("title") or "")
                if norm(surname) == p_surname and norm(title) == p_title:
                    matched_id = str(p.get("id") or p.get("personaId") or "")
                    break
            # 兜底：职称完全匹配 + 姓氏模糊匹配（避免仅凭姓氏误命中）
            if not matched_id:
                t_title = norm(title)
                t_surname = norm(surname)
                for p in existing_list:
                    p_title = norm(p.get("title") or "")
                    if not p_title or p_title != t_title:
                        continue
                    p_surname = norm(p.get("surname") or p.get("name") or "")
                    if p_surname and (t_surname in p_surname or p_surname in t_surname):
                        matched_id = str(p.get("id") or p.get("personaId") or "")
                        break
    except Exception:
        # 拉取失败时降级为 scene_private
        matched_id = None

    # 若本次画像信息丰富，强制以内联草稿落库（不复用）
    if has_rich_persona:
        matched_id = None

    if matched_id:
        # 复用已有画像
        persona_entry: Dict[str, Any] = {
            "mode": "reuse",
            "personaId": matched_id,
            "difficulty": "medium",
            "isDefault": True,
            "rounds": 5,
        }
    else:
        # 内联私有画像草稿（新接口支持，无需单独创建）
        persona_draft: Dict[str, Any] = {"name": name}
        if surname:
            persona_draft["surname"] = surname
        if title:
            persona_draft["title"] = title
        if description:
            persona_draft["description"] = description
        if persona_config:
            persona_draft["personaConfig"] = persona_config
        persona_draft["trustInitial"] = 50
        persona_draft["patienceInitial"] = 60

        persona_entry = {
            "mode": "scene_private",
            "difficulty": "medium",
            "isDefault": True,
            "rounds": 5,
            "personaDraft": persona_draft,
        }

    scene["personas"] = [persona_entry]
    return scene


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--params-file", required=False, help="Path to draft.json")
    ap.add_argument("--params-json", required=False, help="Draft JSON string (optional)")
    ap.add_argument("--access-token", required=True, help="TBS access-token")
    ap.add_argument("--base-url", default=os.getenv("TBS_BASE_URL", tbs_base.BASE_URL))
    ap.add_argument("--timeout-sec", type=int, default=int(os.getenv("TBS_TIMEOUT_SEC", "60")))
    ap.add_argument("--retries", type=int, default=int(os.getenv("TBS_HTTP_RETRIES", "1")))
    ap.add_argument("--dry-run", action="store_true", help="Print final request body and exit (no HTTP request)")
    args = ap.parse_args()
    timeout_sec = max(1, args.timeout_sec)
    retries = max(0, args.retries)

    try:
        if args.params_json:
            payload = json.loads(args.params_json)
        else:
            if not args.params_file:
                raise ValueError("either --params-file or --params-json is required")
            payload = load_json(args.params_file)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"load_json failed: {e}"}), file=sys.stderr)
        return 2

    scene = payload.get("scene") or payload.get("draft") or payload
    if not isinstance(scene, dict):
        print(json.dumps({"success": False, "error": "scene must be an object"}), file=sys.stderr)
        return 2

    # 与接口文档一致：仅需 access-token + Content-Type（提交人/企业由登录态解析）
    headers = {
        "access-token": args.access_token,
        "Content-Type": "application/json",
    }

    # 规整草稿嵌套字段：提升 scenarioBase.location、归一化 knowledgeIds 类型
    scene = normalize_scene(scene)

    # Best-effort name -> id resolve (Step2 已做主校验，此处为兜底)
    try:
        if not args.dry_run:
            scene = maybe_resolve_dept_domain_ids(scene, headers, args.base_url, timeout_sec, retries)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"resolve ids failed: {e}"}), file=sys.stderr)
        return 1

    # 自动组装 personas（reuse 已有画像 或 scene_private 内联草稿）
    try:
        if not args.dry_run:
            scene = resolve_persona(scene, headers, args.base_url, timeout_sec, retries)
        else:
            # Dry-run: still allow the caller to pass prebuilt personas; otherwise skip persona lookup
            if not (isinstance(scene.get("personas"), list) and len(scene.get("personas")) > 0):
                scene["personas"] = []
    except Exception as e:
        print(json.dumps({"success": False, "error": f"resolve persona failed: {e}"}), file=sys.stderr)
        return 1

    # repBriefing 同时作为 sceneScript（新接口必填）
    # For this skill, repBriefing must be the user-confirmed scene background text.
    # Always map from sceneBackground as the single source of truth (final confirmed version).
    # Assumption/contract: sceneBackground and repBriefing must be identical in content.
    # If a future scenario requires a shorter/different repBriefing, this mapping logic must be revisited
    # (otherwise any upstream change to repBriefing may be overridden here).
    scene_background = scene.get("sceneBackground") or ""
    rep_briefing = str(scene_background).strip() if str(scene_background).strip() else str(scene.get("repBriefing") or "").strip()
    scene_script = str(scene.get("sceneScript") or "").strip() or rep_briefing

    drug_name = resolve_drug_name(scene)
    if not drug_name:
        print(json.dumps({"success": False, "error": "drugName is required for create API"}), file=sys.stderr)
        return 1

    scene = ensure_coach_best_practices(scene)
    cp_missing = missing_context_payload_fields(scene)
    if cp_missing:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": (
                        "contextPayload 不完整，禁止落库（doctor/coach 将为空）。"
                        "须在 G4 后与 suggest 同步启动完成 Step4.2（scenario-parse.md），"
                        "或 finalize 后补跑 4.2，再 --mode createScene 校验通过。"
                    ),
                    "missingContextPayloadFields": cp_missing,
                    "hint": "run tbs-scene-validate.py --mode createScene before create",
                },
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 1

    context_payload = scene.get("contextPayload")
    if not isinstance(context_payload, dict):
        context_payload = {}
    coach_bp = ""
    coach_block = context_payload.get("coach")
    if isinstance(coach_block, dict):
        coach_bp = str(coach_block.get("best_practices") or "").strip()

    body: Dict[str, Any] = {
        "title": scene.get("title"),
        "drugName": drug_name,
        "departmentId": scene.get("departmentId"),
        "businessDomainId": scene.get("businessDomainId"),
        "location": scene.get("location"),
        "sceneScript": scene_script,
        "repBriefing": rep_briefing,
        "contextPayload": context_payload,
        "personas": scene.get("personas", []),
        "knowledgeIds": scene.get("knowledgeIds", []),
    }
    kss = scene.get("knowledgeSuggestionState")
    if isinstance(kss, dict) and kss:
        body["knowledgeSuggestionState"] = kss

    url = args.base_url.rstrip("/") + "/scene/sceneAudit/createSxkDraftAndSubmitAudit"

    if args.dry_run:
        # Do not print access-token or any headers in stdout
        out = {
            "success": True,
            "dryRun": True,
            "note": "IDs may be unresolved names; personas may be empty. Actual request body may differ.",
            "personasNote": (
                "dry-run 跳过 resolve_persona()，personas 固定为 []；"
                "实际 create 会调用 resolve_persona() 从 doctorPersona 组装，"
                "请勿以 dry-run 的 personas 字段判断落库结果。"
                "健康性检查请以 diagnostics.coachBestPracticesPresent 为准。"
            ),
            "url": url,
            "body": body,
            "diagnostics": {
                "coachBestPracticesLen": len(coach_bp),
                "coachBestPracticesPresent": bool(coach_bp),
            },
        }
        print(json.dumps(out, ensure_ascii=False))
        return 0

    try:
        res = http_post_json(url, headers=headers, body=body, timeout=timeout_sec, retries=retries)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"request failed: {e}"}), file=sys.stderr)
        return 1

    # 新响应结构：{ resultCode, resultMsg, data: { sceneId, reportId, businessType, auditStatus } }
    result_code = res.get("resultCode")
    if result_code != 1:
        print(json.dumps({"success": False, "error": res.get("resultMsg", "unknown error"), "apiRaw": res}), file=sys.stderr)
        return 1

    data = res.get("data") or {}
    scene_id = data.get("sceneId") if isinstance(data, dict) else data
    title_out = str(body.get("title") or "").strip()
    background_out = str(body.get("repBriefing") or "").strip()
    out = {
        "success": True,
        "diagnostics": {
            "coachBestPracticesLen": len(coach_bp),
            "coachBestPracticesPresent": bool(coach_bp),
        },
        "userDisplay": {
            "headline": "场景创建成功，已提交审核",
            "title": title_out,
            "sceneBackground": background_out,
            "userVisibleMessage": (
                "✅ 您的场景信息已录入成功，已提交审核。\n"
                "审核结果将通过**钉钉消息通知**同步告知您，通常 **1～3 个工作日** 内完成。\n\n"
                "---\n\n"
                f"**场景标题**\n{title_out}\n\n"
                f"**场景背景**\n{background_out}"
            ),
            "mustDisplayVerbatim": True,
        },
        "sceneDbId": scene_id,
        "reportId": data.get("reportId") if isinstance(data, dict) else None,
        "businessType": data.get("businessType") if isinstance(data, dict) else None,
        "auditStatus": data.get("auditStatus") if isinstance(data, dict) else None,
        "apiRaw": res,
    }
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

