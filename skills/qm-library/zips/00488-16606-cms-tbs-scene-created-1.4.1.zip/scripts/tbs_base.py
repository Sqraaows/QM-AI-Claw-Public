"""
tbs_base.py

Shared HTTP layer for TBS scene-creation scripts.

Prefers the `requests` library (connection pooling, automatic gzip/deflate
decompression, error response bodies preserved). Falls back to stdlib urllib
when `requests` is not installed, so the scripts keep working with zero
third-party dependencies.

Public surface (kept stable for all scripts):
- BASE_URL
- http_post_json(url, headers, body, timeout=60, retries=1, backoff_sec=0.8)
- http_get_json(url, headers, query=None, timeout=60, retries=1, backoff_sec=0.8)
"""

import json
import os
import time
from typing import Any, Dict, Optional
from urllib.parse import urlencode

BASE_URL = "https://sg-al-cwork-web.mediportal.com.cn/tbs-admin"

try:
    import requests  # type: ignore

    _HAS_REQUESTS = True
except Exception:  # pragma: no cover - environment without requests
    requests = None  # type: ignore
    _HAS_REQUESTS = False


class HTTPStatusError(Exception):
    """Non-2xx response. Carries the response body so callers can surface
    the server's error message (e.g. resultMsg) instead of a bare status."""

    def __init__(self, status_code: int, body_text: str):
        self.status_code = status_code
        self.body_text = body_text or ""
        snippet = self.body_text[:500]
        super().__init__(f"HTTP {status_code}: {snippet}")


def _build_full_url(url: str, query: Optional[Dict[str, Any]]) -> str:
    if not query:
        return url
    qs = urlencode({k: v for k, v in query.items() if v is not None and str(v) != ""})
    return f"{url}?{qs}" if qs else url


# ---------------------------------------------------------------------------
# requests-based implementation (preferred)
# ---------------------------------------------------------------------------

_session = None


def _get_session():
    """Lazily build a pooled Session so repeated calls reuse TCP/TLS
    connections instead of re-handshaking on every request."""
    global _session
    if _session is None:
        _session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=10, pool_maxsize=10)
        _session.mount("https://", adapter)
        _session.mount("http://", adapter)
    return _session


def _should_retry_requests(exc: Exception) -> bool:
    if isinstance(exc, HTTPStatusError):
        return 500 <= exc.status_code < 600
    if isinstance(exc, (requests.ConnectionError, requests.Timeout)):
        return True
    return False


def _request_json_requests(
    method: str,
    url: str,
    headers: Dict[str, str],
    data: Optional[bytes],
    timeout: int,
    retries: int,
    backoff_sec: float,
) -> Dict[str, Any]:
    last_err: Optional[Exception] = None
    for attempt in range(retries + 1):
        try:
            resp = _get_session().request(
                method, url, data=data, headers=headers, timeout=timeout
            )
            if resp.status_code >= 400:
                raise HTTPStatusError(resp.status_code, resp.text)
            return resp.json()
        except Exception as exc:
            last_err = exc
            if attempt >= retries or not _should_retry_requests(exc):
                raise
            time.sleep(backoff_sec * (2**attempt))
    raise RuntimeError(f"request failed: {last_err}")


# ---------------------------------------------------------------------------
# urllib fallback (zero dependency)
# ---------------------------------------------------------------------------


def _resp_text(resp) -> str:
    raw = resp.read()
    enc = resp.headers.get("Content-Encoding")
    if enc == "gzip":
        import gzip

        raw = gzip.decompress(raw)
    elif enc == "deflate":
        import zlib

        raw = zlib.decompress(raw)
    charset = resp.headers.get_content_charset() or "utf-8"
    return raw.decode(charset)


def _should_retry_urllib(exc: Exception) -> bool:
    import urllib.error

    if isinstance(exc, urllib.error.HTTPError):
        return 500 <= exc.code < 600
    if isinstance(exc, (urllib.error.URLError, TimeoutError)):
        return True
    return False


def _request_json_urllib(
    method: str,
    url: str,
    headers: Dict[str, str],
    data: Optional[bytes],
    timeout: int,
    retries: int,
    backoff_sec: float,
) -> Dict[str, Any]:
    import urllib.request

    last_err: Optional[Exception] = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                text = _resp_text(resp)
            return json.loads(text)
        except Exception as exc:
            last_err = exc
            if attempt >= retries or not _should_retry_urllib(exc):
                raise
            time.sleep(backoff_sec * (2**attempt))
    raise RuntimeError(f"request failed: {last_err}")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def http_post_json(
    url: str,
    headers: Dict[str, str],
    body: Dict[str, Any],
    timeout: int = 60,
    retries: int = 1,
    backoff_sec: float = 0.8,
) -> Dict[str, Any]:
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    if _HAS_REQUESTS:
        return _request_json_requests("POST", url, headers, data, timeout, retries, backoff_sec)
    return _request_json_urllib("POST", url, headers, data, timeout, retries, backoff_sec)


def http_get_json(
    url: str,
    headers: Dict[str, str],
    query: Optional[Dict[str, Any]] = None,
    timeout: int = 60,
    retries: int = 1,
    backoff_sec: float = 0.8,
) -> Dict[str, Any]:
    full_url = _build_full_url(url, query)
    if _HAS_REQUESTS:
        return _request_json_requests("GET", full_url, headers, None, timeout, retries, backoff_sec)
    return _request_json_urllib("GET", full_url, headers, None, timeout, retries, backoff_sec)
