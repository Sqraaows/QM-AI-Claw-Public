#!/usr/bin/env python3
"""
tbs-scene-draft.py

将 Step2 confirmedFields 同步为 canonical draft.json（供 Step3+ 只读 --params-file）。

用法：
  python3 scripts/tbs-scene-draft.py sync \
    --confirmed-json '{"businessDomain":"临床推广",...}' \
    --draft-file .tbs-scene-work/draft.json

  python3 scripts/tbs-scene-draft.py sync --confirmed-file confirmed.json --draft-file draft.json
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, Optional


_AI_SUFFIX_RE = re.compile(r"^（AI生成，可修改）\s*")


def _strip_ai_tag(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    s = value.strip()
    while True:
        m = _AI_SUFFIX_RE.match(s)
        if not m:
            break
        s = s[m.end() :].strip()
    if s.startswith("（AI生成，可修改）"):
        s = s.replace("（AI生成，可修改）", "", 1).strip()
    return s


def _pick(d: Dict[str, Any], *keys: str) -> str:
    for k in keys:
        if k not in d:
            continue
        v = _strip_ai_tag(d.get(k))
        if v is None:
            continue
        if isinstance(v, str) and v.strip():
            return v.strip()
        if v is not None and not isinstance(v, (dict, list)):
            return str(v).strip()
    return ""


def _sub_object(d: Dict[str, Any], *aliases: str) -> Dict[str, Any]:
    for a in aliases:
        v = d.get(a)
        if isinstance(v, dict):
            return v
    return {}


def load_confirmed(*, confirmed_json: Optional[str], confirmed_file: Optional[str]) -> Dict[str, Any]:
    if confirmed_json:
        return json.loads(confirmed_json)
    if confirmed_file:
        with open(confirmed_file, "r", encoding="utf-8") as f:
            return json.load(f)
    raise ValueError("need --confirmed-json or --confirmed-file")


def build_scene(confirmed: Dict[str, Any]) -> Dict[str, Any]:
    """Map Step2 confirmedFields → draft-schema canonical scene."""
    persona_in = _sub_object(confirmed, "doctorPersona", "医生画像")
    bp_in = _sub_object(confirmed, "bestPracticePoints", "bestPractice", "最佳实践要点")

    scenario_base: Dict[str, Any] = {}
    for src_key, dst_key, keys in (
        ("businessDomain", "businessDomain", ["businessDomain", "业务领域"]),
        ("department", "department", ["department", "科室"]),
        ("drug", "drug", ["drug", "drugName", "品种"]),
        ("location", "location", ["location", "场景地点", "地点"]),
        ("timeBackground", "timeBackground", ["timeBackground", "时间背景"]),
        ("visitTarget", "visitTarget", ["visitTarget", "拜访对象"]),
        ("atmosphere", "atmosphere", ["atmosphere", "当前诊室氛围", "诊室氛围"]),
        ("doctorConcerns", "doctorConcerns", ["doctorConcerns", "医生核心顾虑", "医生担忧点"]),
        ("repGoal", "repGoal", ["repGoal", "代表目标"]),
    ):
        val = _pick(confirmed, *keys)
        if val:
            scenario_base[dst_key] = val

    doctor_persona: Dict[str, Any] = {}
    p = _pick(persona_in, "personality", "性格特征")
    c = _pick(persona_in, "communicationStyle", "沟通风格")
    b = _pick(persona_in, "behaviorTendency", "行为倾向")
    if p:
        doctor_persona["personality"] = p
    if c:
        doctor_persona["communicationStyle"] = c
    if b:
        doctor_persona["behaviorTendency"] = b
    desc = _pick(persona_in, "description", "introDescription", "简介描述", "描述")
    if desc:
        doctor_persona["description"] = desc
    surname = _pick(persona_in, "surname", "姓氏")
    if surname:
        doctor_persona["surname"] = surname
    title = _pick(persona_in, "title", "职称")
    if title:
        doctor_persona["title"] = title

    best_practice: Dict[str, Any] = {}
    o = _pick(bp_in, "openingScript", "开场话术")
    q = _pick(bp_in, "questionResponseScript", "回应问题话术")
    r = _pick(bp_in, "recommendation", "推荐建议")
    if o:
        best_practice["openingScript"] = o
    if q:
        best_practice["questionResponseScript"] = q
    if r:
        best_practice["recommendation"] = r

    scene: Dict[str, Any] = {"scenarioBase": scenario_base}
    if doctor_persona:
        scene["doctorPersona"] = doctor_persona
    if best_practice:
        scene["bestPracticePoints"] = best_practice

    if scenario_base.get("drug"):
        scene["drugName"] = scenario_base["drug"]

    return scene


def cmd_sync(args: argparse.Namespace) -> int:
    try:
        confirmed = load_confirmed(
            confirmed_json=args.confirmed_json,
            confirmed_file=args.confirmed_file,
        )
    except Exception as e:
        print(json.dumps({"success": False, "error": f"load confirmed: {e}"}), file=sys.stderr)
        return 2

    scene = build_scene(confirmed)
    draft_path = os.path.abspath(args.draft_file)
    os.makedirs(os.path.dirname(draft_path) or ".", exist_ok=True)

    payload: Dict[str, Any] = {
        "version": 1,
        "scene": scene,
        "meta": {
            "userConfirmed": bool(args.user_confirmed),
        },
    }

    with open(draft_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")

    out = {
        "success": True,
        "draftFile": draft_path,
        "sceneFieldCount": len(scene),
    }
    print(json.dumps(out, ensure_ascii=False))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Sync Step2 confirmedFields to draft.json")
    sub = ap.add_subparsers(dest="command", required=True)

    sync = sub.add_parser("sync", help="Write canonical draft.json from confirmedFields")
    sync.add_argument("--confirmed-json", help="confirmedFields JSON string")
    sync.add_argument("--confirmed-file", help="Path to confirmedFields JSON file")
    sync.add_argument(
        "--draft-file",
        default=os.getenv("TBS_SCENE_DRAFT_FILE", ".tbs-scene-work/draft.json"),
        help="Output draft.json path (default: .tbs-scene-work/draft.json)",
    )
    sync.add_argument(
        "--user-confirmed",
        action="store_true",
        help="Mark meta.userConfirmed=true (call after user 确认清单)",
    )

    args = ap.parse_args()
    if args.command == "sync":
        return cmd_sync(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
