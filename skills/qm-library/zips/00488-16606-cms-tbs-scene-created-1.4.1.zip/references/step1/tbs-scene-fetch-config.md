# Step1：拉主数据

| | |
|--|--|
| **本步目标** | 拉取用户可选的业务领域、科室、品种三列表，供 Step2 按名称匹配 |
| **本步产出** | `state.businessDomains`、`state.departments`、`state.drugs`（`{id,name}`） |
| **下一步** | Step2 采集与回显（**不**在本步向用户展示清单外的技术信息） |

## A. Step 职责（强制）

Step1 **仅负责**：
- 鉴权（注入有效 `access-token`）
- 拉取主数据（业务领域/科室/品种三列表）
- 写入 `state`
- 输出 Step2 开场白（`nextStep.userVisibleMessage` 或兜底开场白）

Step1 **不得**执行任何用户侧采集/补问/回显清单。

**触发**：创建意图后，**不向用户输出任何信息**，直接鉴权并执行脚本（避免用户停留在“加载中”提示而无后续动作）。

## B. Tool 执行（强制）

```bash
python3 scripts/tbs-scene-fetch-config.py --access-token "$ACCESS_TOKEN"
```

写入 `state`：
- `businessDomains`、`departments`、`drugs`
- `productKnowledges`：恒 `[]`，**不拉取、不依赖**

默认 `--knowledge-scope none`。

stdout 字段（G2 通过后）：

| 字段 | 说明 |
|------|------|
| `gate.g2Passed` | `true` 表示三列表非空 |
| `nextStep.userVisibleMessage` | Step2 固定开场白，**逐字展示** |
| `nextStep.mustDisplayVerbatim` | 恒为 `true`，禁止改写或替换为问卷 |
| `nextStep.forbiddenOnFirstTurn` | （可选）编排器用的禁止项列表；首轮不得问卷式「请选一个」 |

> OpenClaw 等编排器：解析 `fetch-config` 返回后，**下一条对用户的消息应仅为** `userVisibleMessage`（**禁止**添加任何前缀/后缀，**不得**插入业务领域/科室/品种长列表）。
>
> `nextStep.forbiddenOnFirstTurn` 的消费方式：这是给**编排器**的元数据，格式建议为 `string[]`（例如：`["questionnaire","enumerate_options"]`）。**Agent 无需处理**该字段；“禁止首轮问卷式/枚举选项”的约束已在本文与 `interaction-echo-confirmation.md` 中以自然语言重复定义。

## C. 用户输出协议（强制）

- Step1 对用户**最多只允许发送 1 条消息**。
- 该消息**只能是**：
  - stdout 的 `nextStep.userVisibleMessage`（G2 通过后，逐字展示），或
  - 下方兜底开场白（仅当 `nextStep.userVisibleMessage` 缺失/为空时）
- **禁止**附加任何前缀/后缀/解释/选项列表；**禁止**发送“加载中/请稍候”等提示。
- 三列表名称仅在 Step2 **补问/零命中/多命中**时出现，**禁止**在首轮问候中枚举全部选项，**禁止**展示 ID。

### 兜底开场白（仅当 `nextStep.userVisibleMessage` 缺失/为空时使用）

```text
你好，我来帮你创建场景。
先一句话说下你要创建的场景就行（不完整没关系）。
比如：心内科 + 新活素 + 病房拜访，医生担心安全性。
我会先整理成确认清单，再每次补问 1–2 个缺口。
```

## D. 门禁 / 失败（强制）

门禁（G2）：

`success=true` 且 `gate.g2Passed=true`（三列表均非空）→ 展示 `nextStep.userVisibleMessage` 后进 Step2 采集；否则排障（见 `auth.md`），禁止 Step2。

失败规则：

失败（`success=false` 或 G2 未过）后：
- **禁止**进入 Step2
- **禁止**输出暖场白（含 `nextStep.userVisibleMessage` 与兜底开场白）
- **禁止**对用户发起任何采集/补问

对用户仅提示主数据加载失败，并引导检查 token/网络（不展示采集模板）。
