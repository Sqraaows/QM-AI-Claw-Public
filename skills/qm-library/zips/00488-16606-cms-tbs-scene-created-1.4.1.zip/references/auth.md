### cms-tbs-scene-create：access-token 获取与注入（强制）

| | |
|--|--|
| **在流程中的位置** | **Step1 之前**（进入创建链路时执行一次）；Step4 **不**重复鉴权 |
| **本步目标** | 取得有效 TBS `access-token`，供 `fetch-config` / `suggest-knowledge` / `create` 使用 |

这份规则用于约束 Agent：任何需要执行本 Skill 的 `scripts/*.py` 的链路，access-token 获取必须通过依赖 Skill `cms-auth-skills` 完成。

#### 必须做
- 只要确定要进入本 Skill 的执行链路（`exec python3 scripts/<name>.py`），在调用目标脚本之前，**必须先调用** `cms-auth-skills` 获取有效的 **TBS** `access-token`。
- 将 `cms-auth-skills` 返回的 access-token **以 `--access-token` 注入**到后续执行命令中（例如：`python3 scripts/tbs-scene-create.py ... --access-token "<ACCESS_TOKEN>"`）。
  - 注意：`tbs-scene-validate.py` 不依赖 access-token；access-token 在 `tbs-scene-fetch-config.py` 与 `tbs-scene-create.py`（调用 API）时必需。

#### 必须禁止
- 禁止自行从环境变量读取 access-token（例如：`TBS_ACCESS_TOKEN` 等）。
- 禁止按某种“自动解析逻辑”（如根据 businessDomain/department/drug 文本推断 token）去获取 access-token。
- 禁止向用户索要 access-token（不要问“把 token 发我/让我用哪个键”这类问题）。
- 禁止在 `cms-auth-skills` 未返回可用 access-token 时继续调用 `scripts/*.py`（尤其是 `tbs-scene-fetch-config.py` / `tbs-scene-create.py`）。

#### 失败处理
- `cms-auth-skills` 获取失败或无可用 access-token：必须停止当前链路，并引导用户重新完成授权/登录；然后再重新尝试进入执行链路。

---

### 环境变量与脚本参数

| 变量 / 参数 | 含义 | 涉及脚本 |
|-------------|------|----------|
| `TBS_BASE_URL` / `--base-url` | TBS Admin 基地址 | `tbs-scene-fetch-config.py`、`tbs-scene-suggest-knowledge.py`、`tbs-scene-create.py` |
| `TBS_TIMEOUT_SEC` / `--timeout-sec` | HTTP 超时（秒） | 同上 |
| `TBS_HTTP_RETRIES` / `--retries` | HTTP 重试次数 | 同上 |
| `--access-token` | 由 `cms-auth-skills` 取得后注入 | 同上 |

说明：环境变量**不得**用于注入 access-token；token 仅通过 `cms-auth-skills` 与 `--access-token` 传递。`tbs-scene-validate.py` 不访问上述 URL 与 token。

---

### 环境前置自检（Smoke-Check，建议在进入完整流程前执行）

在取得 `access-token` 后，执行以下命令验证环境连通性与 token 有效性：

```bash
python3 scripts/tbs-scene-fetch-config.py \
  --access-token "$ACCESS_TOKEN" \
  --base-url "$TBS_BASE_URL"
```

**通过标准**：`success=true`，且 `departments`、`drugs`、`businessDomains` 均非空（不校验 `productKnowledges`）。

**失败处理**：

| 现象 | 可能原因 | 处理方式 |
|------|---------|---------|
| `success=false` + HTTP 401/403 | token 已过期或环境不匹配 | 重新通过 `cms-auth-skills` 获取 token |
| `success=false` + 连接超时 | `TBS_BASE_URL` 不可达 / 网络问题 | 检查环境变量值与网络状态 |
| `success=true` 但列表为空 | 该账号下无主数据 / 权限不足 | 联系业务管理员确认账号权限 |

> Smoke-Check 失败时，**不得**进入 Step1-4 编排链路；须先解决环境问题。

