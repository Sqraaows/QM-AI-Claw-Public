# 常见坑（按 Step 索引）

> 主流程：`SKILL.md` + 各 `step*/`。排障样例：`failure-examples.md`。

## 鉴权 / 环境（G1）
- **token 来源**：仅 `cms-auth-skills` + `--access-token`；禁止环境变量 token、禁止向用户索要。
- **环境一致**：`TBS_BASE_URL` 与 token 所属环境一致；401 先 smoke-check（`auth.md`），勿进 Step1。

## Step1（G2）
- **不拉知识**：`productKnowledges` 恒空；知识只来自 Step4.1 推荐接口。
- **列表为空**：不进入 Step2；查账号权限或环境，勿用空 state 做名称匹配。

## Step2（G3）
- **业务领域默认**：`confirmed` 恒为 `临床推广`；禁止向用户补问/解析其它领域；step2 只匹配科室+品种。
- **首轮问候来源**：G2 后须展示脚本 `nextStep.userVisibleMessage`，禁止跳过脚本输出、自行拼「四项问卷」或枚举全部三列表。
- **draft**：只维护 `confirmed.json`；**仅** `tbs-scene-draft.py sync` 写 draft；**禁止** `write`/手改 `draft.json`（见 `tbs-scene-draft.md`）。
- **确认后**：`sync --user-confirmed` 再 step3；禁止对用户说「JSON 格式问题」。
- **名称校验顺序**：先 `--mode step2`，再回显「已确认」；禁止 Agent 自行模糊匹配。
- **多命中 / 零命中**：须让用户选或阻断；禁止静默选第一条、禁止自定义名称。
- **C 层与 AI**：拜访对象/氛围/医生顾虑/代表目标齐后才 AI 画像与最佳实践；禁止索要全文；须用户整体确认后再 `step3`。
- **回显勿截断**：画像与最佳实践在清单中须**全文**；禁止 `……`/`...` 省略（见 `interaction-echo-confirmation.md` 回显规则第 6 条「全文回显」）。
- **品种**：确认的是**名称**；落库只传 `drugName`，勿在 scene 里写数值 `drugId`。

## Step3（G4）
- **只读 draft**：`--params-file draft.json`；禁止 `--params-json`。
- **写回标题/背景**：只合并 `title`/`sceneBackground`，禁止整文件覆盖丢失 `bestPracticePoints`。
- **确认后勿重复清单**：用户刚确认 Step2 清单后，Step3 仅展示标题+背景（除非用户改字段）。
- **标题/背景须停步**：生成后**必须等用户确认**再 Step4.1；禁止同轮展示标题后立即 `suggest` 或说「进入 Step4.1」。
- **`repGoal` ≠ `repBriefing`**：代表目标是采集字段；场景背景是 `sceneBackground`，落库同源 `repBriefing`。
- **标题/背景文案**：须按 `step3/title-and-scene-background.md` 生成；禁止把开场话术、`openingScript` 写入 `sceneBackground`。
- **输出顺序**：先完整清单，再标题+背景；禁止跳过清单。
- **字段别名**：地点等用 `location` / `draft-schema.md` 推荐键，避免 step3 误报缺失。
- **改顾虑/目标**：须重生成 title/background，并**重跑 suggest + 重生成 contextPayload**。

## Step4.1（G5）+ Step4.2 同步启动
- **G4 后同步启动**：suggest HTTP 与 contextPayload 生成，互不等待；勿串行「先 4.1 全部结束再 4.2」。
- **零推荐阻断**：`suggest` 空列表不得 finalize / 落库。
- **勿跳过 4.2**：G4 后**必须**同步启动生成 `contextPayload`；finalize 后若 G6 未过**必须补跑** 4.2，禁止直接 create（doctor/coach 会空）。
- **勿重复 4.2**：G6 **已满足** 时，用户确认知识后只 `finalize`；禁止再完整生成（除非改了顾虑/目标/背景）。
- **「待确认都可以」**：finalize 前须把所有 `suggested` 的 `matchedKnowledgeId` 写入 `acceptedMatchedIds`。
- **finalize 非 API**：`--mode finalize` 本地 <1s。
- **`suggested`**：须用户接受后才 `finalize`；`auto-linked` 可被 reject。
- **`create` 不展示**：API 的 `status=create` **禁止**以「建议新建」等形式对用户展示或询问是否新建；本 Skill 不能新建产品知识。
- **展示**：只主题名+理由；用脚本 `userDisplay`；禁止 `knowledgeId`、匹配日志。

## Step4.2（G6）
- **保密**：不展示 `contextPayload` 正文与键名。
- **生成范围**：doctor 5 键 + coach 3 键（含 `best_practices`）；终止规则=固定合规+场景条（`scenario-parse.md`）。
- **与 suggest 同步启动**：G4 后即开始，互不等待；落库前完成即可。
- **提问边界**：必须两层结构（`## 提问边界` + 第一层固定四条 + 第二层 3～5 条），禁止单层概括；第一层由 `question_boundary_assemble.py` 拼接，模型只出第二层。

## Step4.3（G7–G8）
- **`personas`**：脚本从 `doctorPersona` 组装；禁止问用户选画像。
- **口令**：须 **「确认提交」**；单独「确认」不算 G8。
- **清单**：落库前展示最终业务清单（见 `tbs-scene-create.md`）。
- **成功输出**：原样 `userDisplay.userVisibleMessage`（成功句+**场景标题**+**场景背景**全文）；禁止 `sceneDbId`/ID/接口名。
- **成功后清 work**：create 成功 → 删 `.tbs-scene-work/` 整目录；勿只删 `draft.json`；失败/放弃不删。

## 横切
- **科室/领域 ID**：可名称入参、脚本解析；**不对用户展示**任何 ID。
- **`knowledgeIds`**：string[]，非 number。
