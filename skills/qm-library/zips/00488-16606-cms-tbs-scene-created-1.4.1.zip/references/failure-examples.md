# 失败样例（按 Step 索引）

格式：**现象 → 原因 → 处理**。对应坑点见 `pitfalls.md`。

## 鉴权 / Step1
| # | 现象 | 处理 |
|---|------|------|
| A1 | Step1 401 / 连接失败 | 重取 token；核对 `TBS_BASE_URL`；跑 `auth.md` smoke-check |
| A2 | 三列表为空 | 查账号权限；勿进 Step2 |

## Step2
| # | 现象 | 处理 |
|---|------|------|
| B0 | G2 后输出「四项问卷」或枚举全部三列表 | 改发 stdout `nextStep.userVisibleMessage` 原文；勿自行读 md 拼表单 |
| B1 | 未跑 step2 就回显「已确认」 | 先 `--mode step2`，再更新清单 |
| B2 | 零命中无限追问 | 同字段 2 次零命中后输出阻断提示 |
| B3 | 用户未确认清单就 step3 | 展示完整清单并等整体确认后再 `sync --user-confirmed` |
| B4 | Step3 一直等待 | 勿用超长 `--params-json`；先 `sync` 再 `--params-file draft.json` |
| B5 | Agent `write` 改 draft.json | 删 draft → 从 `confirmed.json` 重跑 `sync`；见 `tbs-scene-draft.md` |
| B6 | step2/create 报业务领域无法解析 | token 权限须含「临床推广」；`names-json` 中 `businessDomain` 固定 `"临床推广"`，勿用用户口述其它领域名 |
| B7 | 最佳实践/画像回显带 `……` 被截断 | 须全文回显 `confirmedFields` 内正文；禁止摘要或省略号 |

## Step3
| # | 现象 | 处理 |
|---|------|------|
| C0 | 要求用户「整理成 JSON」 | `sync`，用户无感 |
| C1 | 报缺地点/画像/最佳实践 | 勿手写 draft；`confirmed` 齐全后 `sync --user-confirmed` |
| C4 | 对用户说 draft.json 格式错误 | 禁止暴露；静默 `sync` 重试 |
| C5 | step3 后 draft 无 bestPracticePoints | 写回时只 patch 标题/背景，勿整文件覆盖 |
| C2 | 用户刚确认又贴一整份清单 | 校验通过后只输出标题+背景 |
| C6 | 展示标题/背景后立刻 Step4.1 | 须等用户「确认/继续」→ 写回 draft → 再 `suggest`；禁止同轮进 4.1 |
| C3 | `draft.json` 不存在 | 先 Step2 `sync`，再 step3 |

## Step4.1
| # | 现象 | 处理 |
|---|------|------|
| D1 | 推荐为空仍往下走 | 阻断；调整描述后重试 suggest |
| D2 | 用户看到 knowledgeId | 只展示主题名与接受状态 |
| D2b | 出现「建议新建」/ 询问是否新建项 | 仅展示 `userDisplay` 两节；`create` 过滤；见 `tbs-scene-suggest-knowledge.md` |
| D3 | finalize 后 ids 为空 | 检查 `suggested` 是否已接受 |
| D4 | 确认知识后才跑 contextPayload，耗时长 | G4 后应与 suggest **同步启动** 生成；确认知识后仅 finalize |
| D5 | 用户「待确认都可以」后立刻「场景创建成功」，doctor/coach 空 | **未做 Step4.2**：G4 后须同步启动生成 `contextPayload`；finalize 后须过 G6 再 4.3 清单与「确认提交」。补跑 `scenario-parse.md` 后重 create |
| D6 | finalize 后同轮 create，跳过最终清单 | 须：finalize → G6 → **最终业务清单** → 用户 **「确认提交」** → `createScene` 校验 → create |

## Step4.2
| # | 现象 | 处理 |
|---|------|------|
| E1 | 向用户展示 contextPayload | 仅「正在生成场景内容…」 |
| E2 | 提问边界单层 bullet、仍含第三层、或第一层非脚本 canonical | 模型只出第二层 → `question_boundary_assemble.py patch-draft` 或 `patch-doctor-context` |
| E2b | 落库后最佳实践为空 | **执行类回溯**：当时 `create` 的 JSON 是否含 `coach.best_practices`；dry-run 与真落库是否同 payload。排障类可查详情接口 `contextPayload.coach.best_practices`（非顶层 `bestPracticePoints`） |
| E3 | 落库后 doctor/coach 各键全空 | Agent 未跑 4.2 或未写入 create JSON；`tbs-scene-create.py` 现会在 G6 不满足时拒绝。OpenClaw 拉 skill ≥1.3.0 后重试 |

## Step4.3
| # | 现象 | 处理 |
|---|------|------|
| F1 | 落库 400 科室/领域非法 | 用 Step1 state 解析 ID；品种只传 `drugName` |
| F2 | `knowledgeIds` 类型错误 | 使用 string[] |
| F3 | 询问用户选 persona | 保留 `doctorPersona`，由脚本组装 |
| F4 | 单独「确认」就 create | 须 **「确认提交」** + 先展示最终业务清单 |
| F5 | 成功输出 sceneDbId/ID/接口名 | 原样发 `userDisplay.userVisibleMessage`（标题+场景背景） |
| F6 | 同会话再建仍带上一场景字段 | 上一场 create 成功后应已删 `.tbs-scene-work/`；再建前先删目录 |
