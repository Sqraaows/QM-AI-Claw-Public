# 术语与字段（按 Step 索引）

| Step | 用户侧 | 内部字段 | 备注 |
|------|--------|----------|------|
| 3 | 场景标题 | `title` | Step3 生成并确认；句式见 `step3/title-and-scene-background.md` §1 |
| 3→4.3 | 场景背景 | `sceneBackground` / `repBriefing` | **同源**；落库用 `repBriefing`；三块结构（现状/张力/训练目的），**不含开场建议**，见同文档 §2 |
| 2 | 地点 | `location` | 可由 `scenarioBase` 提升 |
| 1→4.3 | 科室 / 业务领域 | `departmentId` / `businessDomainId` | 科室用户选；领域固定「临床推广」→ID；**不对用户展示** |
| 2→4.3 | 品种 | `drugName` | 只传名称，不传 `drugId` |
| 4.1 | 产品知识 | `knowledgeIds` | `finalize` 后；string[] |
| 2→4.3 | 医生画像 / 最佳实践 | `doctorPersona` / `bestPracticePoints` | C 层齐后 AI 生成；`personas[]` 脚本组装 |
| 4.2 | （无用户词） | `contextPayload.coach.best_practices` | 由 `bestPracticePoints` 三项映射；见 `scenario-parse.md` |
| 4.2 | （无用户词） | `contextPayload` | **不对用户展示** |
| 2 | 代表目标 | `repGoal` | 采集用；≠ `repBriefing` |

**易混**：`repGoal`（采集）≠ `repBriefing`（落库背景）；`knowledgeIds` 须字符串数组。

**禁止对用户展示**：`contextPayload`、`knowledgeId`、`drugId`、`departmentId`、`businessDomainId`、`doctorOnlyContext`、`coachOnlyContext`、`createScene`、`sceneDbId` 等内部名/ID。
