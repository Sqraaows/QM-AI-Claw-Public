# QA 闭环（按 Step 索引）

> 落库前按序自检。未通过：修正 → 重跑该 Step 校验 → 再继续。退出条件：`createScene` 通过且 G8 已满足。

## 鉴权（G1）
- [ ] 已通过 `cms-auth-skills` 取得 token
- [ ] Smoke-check：`fetch-config` 成功且三列表非空（`auth.md`）

## Step1（G2）
- [ ] `state.businessDomains` / `departments` / `drugs` 均非空
- [ ] 未依赖 `productKnowledges`

## Step2（G3）
- [ ] `confirmed.businessDomain` = `临床推广`（系统默认，非用户解析）
- [ ] `--mode step2`：**科室、品种**为 `exact`（`businessDomain` 固定传「临床推广」且 exact）
- [ ] 拜访对象、诊室氛围、医生核心顾虑、代表目标已用户确认
- [ ] 画像+最佳实践已生成（或用户修改）且用户整体确认清单
- [ ] `drugName` = Step2 确认品种名
- [ ] `draft.json` **仅由** `sync` 写入（未手改）；含 `doctorPersona`、`bestPracticePoints`

## Step3（G4）
- [ ] `sync --user-confirmed` 后 `--mode step3` → `passed=true`
- [ ] 写回标题/背景时未整文件覆盖 draft
- [ ] `title`、`sceneBackground` 已生成且用户确认
- [ ] `sceneBackground` 与将用于落库的 `repBriefing` 文案一致（或仅保留 `sceneBackground` 由脚本映射）
- [ ] 标题符合 `step3/title-and-scene-background.md` §1（品种/主题+场合/科室+核心议题）
- [ ] 背景为一段中文，含现状/张力/训练目的，**无**开场建议，且未把 `repGoal` 原样当背景全文

## Step4（G4 后同步启动）
- [ ] G4 后**同步启动** `suggest` 与 `contextPayload` 生成，互不等待（非「确认知识后再 4.2」）
- [ ] suggest 成功后才展示推荐列表

## Step4.1（G5）
- [ ] `suggest` 非空；用户已确认接受项
- [ ] `finalize` 成功；`knowledgeIds` 非空
- [ ] `knowledgeSuggestionState` 与 finalize 一致
- [ ] 用户侧未出现任何 knowledgeId
- [ ] 未展示「建议新建」/`status=create` 条目（仅用 `userDisplay` 两节）

## Step4.2（G6）
- [ ] `contextPayload.version=1`
- [ ] doctor：`known_background`、`core_concerns`、`today_status`、`question_boundary`、`termination_rules` 均非空
- [ ] `question_boundary` 第一层为脚本 canonical 前缀（`question_boundary_assemble.py validate` 通过）
- [ ] coach：`expected_behaviors`、`termination_rules`、`best_practices` 均非空（`best_practices` 来自 Step2 三项最佳实践）
- [ ] 终止规则含固定合规条（Agent 拼接，非仅模型场景条）
- [ ] 未向用户展示 payload

## Step4.3（G7–G8）
- [ ] 已展示最终业务清单（`tbs-scene-create.md`）
- [ ] 用户回复 **「确认提交」**
- [ ] `--mode createScene` → `passed=true`
- [ ] `tbs-scene-create.py` 成功
- [ ] 用户可见输出为 `userDisplay.userVisibleMessage` 原文（成功句 + 标题 + 场景背景全文）；无 ID
- [ ] create 成功后已删除 `.tbs-scene-work/`（含 `confirmed.json`）

## 输出纯净（全流程）
- [ ] 无内部 ID、无 `contextPayload` 正文、无技术字段名
- [ ] 脚本 stderr/API 原文未朗读给用户

## 字段来源速查

| 字段 | 产生 Step |
|------|-----------|
| `state.*` | Step1 |
| 草稿采集字段 | Step2 |
| `title` / `sceneBackground` | Step3 |
| `knowledgeIds` | Step4.1 |
| `contextPayload` | Step4.2 |
| HTTP body 组装 | Step4.3 脚本 |

术语：`glossary.md`。
