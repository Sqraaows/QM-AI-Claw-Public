# Step4.2 `contextPayload` Schema Guide（字段规范）

> 本文只定义 **字段契约/硬约束**（字段长什么样、必须包含什么、禁止什么）。  
> 主流程（何时生成、如何编排、写入哪里）见 `scenario-parse.md`。  
> 写作模板/正反例/固定 A/B 见 `contextPayload-generator-spec.md`。  
> 提问边界生成任务见 `question-boundary-generator.md`。

## 1) 结构与键（固定）

- 根：`version`（固定 `1`）、`doctor`、`coach`
- `doctor` 必须包含 5 键：
  - `known_background`
  - `core_concerns`
  - `today_status`
  - `question_boundary`
  - `termination_rules`
- `coach` 必须包含 3 键：
  - `expected_behaviors`
  - `termination_rules`
  - `best_practices`
- 各键值均为 **纯正文字符串**；禁止写 `## 已知背景` 等节标题（例外：`question_boundary` 内部强制含 `## 提问边界` 及 `### 第一层/第二层`）。

## 2) 字段职责最小化（强制）

- `known_background`：仅事实与情境（不写策略/话术/规则）
- `core_concerns`：仅顾虑要点（不夹带解决方案或教练评价）
- `today_status`：仅可观察状态线索与节奏约束（不写心理/动机/人格评判）
- `question_boundary`：仅两层「提问边界」正文（不混入其它沟通建议）
- `doctor.termination_rules`：仅医生侧终止触发条件（基于代表可观察行为）
- `expected_behaviors`：仅代表可观察行为（不复述 `best_practices` 话术全文）
- `coach.termination_rules`：仅教练侧终止触发条件（基于代表输出质量/合规可观察不足）
- `best_practices`：仅 3 条话术正文（不写额外解释）

## 3) `best_practices` / `expected_behaviors` 去重（强制）

- `best_practices` 负责“说什么”（三条话术正文）
- `expected_behaviors` 负责“做到什么”（动作/质量标准）
- 两者禁止同义重复：若某点已在 `best_practices` 体现为具体话术，则 `expected_behaviors` 只保留动作层要求，不复述话术内容。

## 4) `question_boundary`（强制）

### 4.1 结构（必须逐字一致）

`question_boundary` 必须是一个字符串，以 `## 提问边界` 开头，且内部包含 2 个 `###` 标题，顺序不可变：

```text
## 提问边界

### 第一层：永远禁止（所有场景通用）
（固定四条）

### 第二层：本场景允许问的方向
（3～5 条）
```

### 4.2 第一层（固定四条，逐字）

- 禁止询问患者病历、诊断、隐私
- 禁止要求代表推导产品知识中没有的数据
- 禁止编造任何数值
- 资料/文献/交付物：全场至多确认 1 次（"嗯，知道了"），后续双方不得再提交付形式（放哪、带什么、发您、有空看看等）

### 4.3 第二层（3～5 条）

- 格式：`- 可问：[方向]（基于产品知识中已有内容）`
- 每条 `[方向]` 6～16 字
- `[方向]` 必须能从【医生核心顾虑】或【医药代表目标】直接找到依据
- `[方向]` 须在顾虑/目标一级关键词基础上追加本场景限定词（优先品种名，其次患者群/症状/疗程/费用等）；禁止将顾虑/目标关键词原词直接作为方向；换到其他场景仍成立则过泛
- 禁止抽象方向词（如「进一步了解」「详细说明」「展开讲讲」「综合评估」）
- 禁止写具体问题/具体数据/研究名/产品知识原文

## 5) 类型与缺失语义（强制）

- canonical 类型固定：上述字段均为字符串（`best_practices` 也是字符串，内部用换行与 `-` 组织）
- `null`、`""`、仅空白字符串均视为缺失；不得用其占位绕过校验

## 6) 长度上限（建议，避免 payload 膨胀）

- `known_background` ≤ 220 字
- `today_status` ≤ 120 字
- `core_concerns`：1～2 条，每条 ≤ 40 字
- `expected_behaviors`：3～5 条，每条 ≤ 40 字，总计 ≤ 220 字
- `doctor.termination_rules` / `coach.termination_rules`：总计 ≤ 260 字（含固定条）
- `best_practices`：3 条，每条 ≤ 220 字
