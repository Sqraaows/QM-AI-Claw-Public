# Step4.3：落库

| | |
|--|--|
| **本步目标** | 向用户展示最终业务清单；口令确认后校验并调用创建接口 |
| **本步产出** | 场景创建成功（对用户仅标题+背景）；内部 `sceneId` 不展示 |
| **流程结束** | 落库成功 → 清理 `.tbs-scene-work/`；失败/放弃不清理 |

接口：`POST /scene/sceneAudit/createSxkDraftAndSubmitAudit`（深西康场景创建；勿用 `/scene/createScene`）

---

## 落库前：最终业务清单（G8 前必做）

在调用 `createScene` / `tbs-scene-create.py` **之前**，向用户展示（**禁止** ID、`contextPayload` 正文、技术字段名）：

1. **完整已确认清单**（Step2 全部业务字段，同 Step3 第 1 步样式）
2. **场景标题**、**场景背景**（Step3 已确认值）
3. **已关联产品知识**（仅主题名称列表）
4. 引导语：请核对无误后回复 **「确认提交」** 以创建场景（单独「确认/好的」**不算** G8）

用户修改任一项 → 更新 scene → 若动到知识/顾虑/目标等，按各 Step 文档回退重跑对应子步。

落库**无**顶层 `bestPracticePoints`；最佳实践须写入 **`contextPayload.coach.best_practices`**（Step2 三项 → 3 条 `-` 要点，模板见 `contextPayload-generator-spec.md`）。组装前勿删掉 draft 内 `bestPracticePoints`。

---

## 门禁
G7 `createScene` 通过 + 用户 **「确认提交」** + 有效 token。

## create 执行顺序约束（Prompt 侧最小规则）

- **「确认提交」完全等于**：将「确认提交」视为唯一且充分的落库授权口令；除该口令外的任何表达（含「确认」「继续」「都可以」）均**不等价**，不得触发 create。
- **禁止自动重试**：create 任何失败（**含 503 / 404 / 超时 / 无回包**）时，**禁止**自动变换参数重试，**禁止**绕过脚本直接发 HTTP，**禁止**修改 payload 后再提交；必须立即停下，向用户报告当前状态（错误码 + 错误信息），等待用户指示。
- **create freeze（最小）**：等待口令与发起 create 之间，`scene JSON` 不得被 Agent 改写；用户若要改，必须回到"最终业务清单"重新确认后才允许再次触发「确认提交」。
- **UNKNOWN 时禁止宣称成功**：结果不确定时禁止输出「开始创建」「创建成功」等话术；不得清理 `.tbs-scene-work/`。
- **`resultCode` 语义（注意）**：API 响应中 `resultCode=1` 表示**成功**，`resultCode=0` 表示失败（与常见 HTTP/REST 惯例相反）；脚本按此处理，编排器判断成功/失败**以脚本 exit code + stdout.success 为准**，不得自行解读 `resultCode`。

## create 应由脚本/编排层保证的工程能力（要求）

- **幂等（建议）**：编排层/脚本应提供幂等键或去重机制，避免重复提交导致重复创建（Prompt 仅负责“禁止自动重试”）。
- **freeze 后禁止自动 normalize/fallback（工程侧）**：进入等待口令后，编排层不得再对 payload 做 normalize/fallback；需要的补全必须在 freeze 前固化到同一份 payload。
- **dry-run 后字段变更必须重校验（工程侧）**：dry-run 之后任何字段变化都必须重新 `--mode createScene` 校验 + 重新 dry-run，才能允许 create。
- **persona resolve 固化（工程侧）**：`personas[]` 的解析结果应固化在 payload 中，失败重试复用同一份 payload（避免重复 resolve 导致不一致）。
- **可观测性（工程侧）**：当前脚本 `diagnostics` 已输出 `coachBestPracticesPresent`/`coachBestPracticesLen`（create dry-run/real）与 `missingContextPayloadFields`（`--mode createScene`），编排层据此判断 payload 完整性；Prompt 不向用户展示该信息。
- **fallbackUsed（待实现，建议）**：若后续脚本引入任何兜底/归一化，应在 `diagnostics` 中显式输出 `fallbackUsed`（及原因）供编排层记录。**当前脚本未实现该字段**，编排层勿依赖其存在。
- **UNKNOWN 恢复动作（工程侧）**：编排层必须能判定 SUCCESS/FAILED/UNKNOWN（基于 exit code + 结构化 stdout），UNKNOWN 时进入排障确认，不得自动重试。

## 校验
```bash
python3 scripts/tbs-scene-validate.py --params-json '<scene JSON>' --mode createScene
```

## 落库
```bash
python3 scripts/tbs-scene-create.py --params-json '<scene JSON>' --access-token "$ACCESS_TOKEN"
```

Dry-run（只看 body，不发 HTTP）：
```bash
python3 scripts/tbs-scene-create.py --params-json '<scene JSON>' --access-token "$ACCESS_TOKEN" --dry-run
```

---

## 传给脚本的 `scene`（入参）

| 字段 | 说明 |
|------|------|
| `title` | Step3 确认 |
| `sceneBackground` | 场景背景（**唯一文案源**） |
| `repBriefing` | 宜与 `sceneBackground` 同源；缺则脚本用 `sceneBackground` 填充 |
| `drugName` | Step2 品种名；**禁止**传数值 `drugId` |
| `departmentId` / `businessDomainId` | 名称或 ID；非数字时脚本 name→id |
| `location` | 地点；可从 `scenarioBase.location` 提升 |
| `contextPayload` | Step4.2：doctor 5 键 + coach 3 键（含 `best_practices`，见 `scenario-parse.md`） |
| `knowledgeIds` | Step4.1 `finalize` 后，非空 string[] |
| `knowledgeSuggestionState` | 与 finalize 一致，建议传 |
| `doctorPersona` | Step2 画像；脚本组装 `personas[]`，**勿问用户** |

**Skill 不传（接口亦不要求本链路传）**：`reviewConfig`、`doctorOnlyContext`、`coachOnlyContext`、`drugId`、`businessType`、`auditStatus`

---

## HTTP 请求体（`tbs-scene-create.py` 实际发出）

`tbs-scene-create.py` 发出的 body 字段：

| 字段 | 接口 | 脚本 |
|------|------|------|
| `title` | 必填 | `scene.title` |
| `drugName` | 与 `drugId` 二选一；本 Skill **只传此项** | `scene.drugName`（或 legacy 非数字 `drugId` 当名称） |
| `departmentId` | 必填 | 解析后 ID |
| `businessDomainId` | 必填 | 解析后 ID |
| `sceneScript` | 必填 | `scene.sceneScript`，空则 **= `repBriefing`** |
| `repBriefing` | 必填 | **= `sceneBackground`**（trim 后；空则 fallback `repBriefing`） |
| `location` | 否 | `scene.location` |
| `contextPayload` | 推荐 | `scene.contextPayload` |
| `personas` | 必填，≥1 且 `isDefault=true` | `resolve_persona()` 从 `doctorPersona` 组装 |
| `knowledgeIds` | 否（接口可选） | 非空；Skill **G5 要求必传** |
| `knowledgeSuggestionState` | 否 | 有则传 |

**脚本不传**：`drugId`、`reviewConfig`、legacy 上下文字段、`openingSide`（用后端默认）

---

## scene → body 映射

| scene 入参 | HTTP body |
|------------|-----------|
| `sceneBackground` | `repBriefing`；且无 `sceneScript` 时同时作为 `sceneScript` |
| `doctorPersona` | `personas[]`（`reuse` 或 `scene_private`，默认 `rounds: 5`） |
| `scenarioBase.location` | `location`（`normalize_scene` 提升） |
| 其余同名字段 | 同名落位 |

落库前建议：`repBriefing = sceneBackground`，避免 `createScene` 报 `repBriefing!=sceneBackground`。

---

## personas 组装（脚本内部，禁止打扰用户）

- 画像信息较全（描述/人设/沟通/行为任一）→ `scene_private` + `personaDraft`
- 仅姓氏+职称且能命中库 → `reuse` + `personaId`
- 失败则 stderr 报错并停止，**不**让用户选手动填 `personas`

---

## 成功展示（G8 通过后仅此）

`tbs-scene-create.py` 成功时 stdout 含 **`userDisplay.userVisibleMessage`**：编排器**必须原样**作为下一条用户可见消息（与 G2 的 `nextStep.userVisibleMessage` 同级规则）。

固定结构（由脚本组装，Agent **禁止**改写；**禁止**在审核告知句后自行追加任何内容）：

```
✅ 您的场景信息已录入成功，已提交审核。
审核结果将通过**钉钉消息通知**同步告知您，通常 **1～3 个工作日** 内完成。

---

**场景标题**
{title}

**场景背景**
{sceneBackground 全文}
```

> 审核告知行必须在最上方，场景内容在分隔线下方；两部分均不得拆分或重排。

**禁止对用户展示**：`sceneDbId`、`sceneId`、`reportId`、`auditStatus`、`apiRaw`、`diagnostics`、接口名、脚本 stdout 其它字段。

---

## 调用 create 前（编排器自检）

按序执行，**禁止**跳过：

1. Step4.2 已在 G4 后与 suggest **同步启动**并完成（或用户确认知识前已完成）：`scene.contextPayload.coach` 含非空 **`best_practices`**；**禁止**只写进 `expected_behaviors`。
2. `--mode createScene` → `passed=true`（会校验 `coach.best_practices`）。
3. 建议先 dry-run，确认 body 含 `contextPayload.coach.best_practices`：

```bash
python3 scripts/tbs-scene-create.py --params-json '<scene JSON>' --access-token "$ACCESS_TOKEN" --dry-run
```

4. 编排器读 stdout：`diagnostics.coachBestPracticesPresent` 须为 `true`；为 `false` 时回到 Step4.2 补写后再 create。

> **dry-run `personas` 不可信**：dry-run 跳过 `resolve_persona()`，`personas` 固定输出 `[]`（同时附带 `personasNote` 说明）。实际 create 会调用 `resolve_persona()` 自动组装；编排器**不得**以 dry-run 中 `personas: []` 判断 create 会失败。健康性检查**仅以** `diagnostics.coachBestPracticesPresent` 为准。
5. 用户 **「确认提交」** 后，用**同一份** `scene JSON` 调 create（勿 dry-run 与真落库各用不同 payload）。

**脚本硬门禁（G6）**：`contextPayload` 缺任一键或 doctor/coach 为空时，`tbs-scene-create.py` **退出码 1** 且 stderr 含 `missingContextPayloadFields`；须先 Step4.2 + `createScene` 校验，**禁止**对用户先说「场景创建成功」。

脚本会在发 HTTP 前从 `bestPracticePoints` **兜底**映射 `best_practices`；Prompt 侧仍须在 Step4.2 主动写入，不得依赖兜底作为常规路径。

---

## 落库成功后（G8 + create 成功）

对用户展示成功文案后，**删除整个** `.tbs-scene-work/`（含 `draft.json`、`confirmed.json` 及 Step4 会话缓存文件）。下一场景 Step2 会 `mkdir` 后重新 `sync`。

| 时机 | 是否清理 |
|------|----------|
| create **成功** | **是**（删目录） |
| create 失败、dry-run、用户放弃 | **否**（便于重试/排障） |
| 同会话再建 / 用户「重新创建」 | 若目录仍在，先删再 Step1 |

**勿**只删 `draft.json` 而保留 `confirmed.json`（下次 `sync` 会写回旧场景）。
