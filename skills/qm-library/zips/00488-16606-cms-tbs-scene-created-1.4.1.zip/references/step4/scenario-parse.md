# Step4.2：生成 contextPayload（主流程）

| | |
|--|--|
| **本步目标** | 根据已确认场景信息生成医生/教练侧结构化上下文，供创建接口 merge |
| **本步产出** | `scene.contextPayload`（`version:1`，doctor 5 键 + coach 3 键） |
| **下一步** | 用户确认知识 → finalize 后，Step4.3 清单 → 落库 |

> 落库只传 `contextPayload`（不传 legacy 上下文）。各键值为纯正文；禁止写 `## 已知背景` 等节标题。`question_boundary` 内**必须**含 `## 提问边界` 及 `### 第一层` / `### 第二层`（两层结构，见 `question-boundary-generator.md`）。

## 文档分层（必读）

- **主流程（本文）**：生成什么 / 什么时候生成 / 写入哪里 / 基本边界
- **字段规范（Schema Guide）**：`contextPayload-schema-guide.md`（结构/类型/长度）
- **生成模板（Generator Spec）**：`contextPayload-generator-spec.md`（固定 A/B、正反例、措辞）
- **提问边界生成**：`question-boundary-generator.md`

## ① 生成什么（固定）

- 根：`version`（固定 `1`）、`doctor`、`coach`
- `doctor` 5 键：`known_background`、`core_concerns`、`today_status`、`question_boundary`、`termination_rules`
- `coach` 3 键：`expected_behaviors`、`termination_rules`、`best_practices`
- **不传（后端模板补全）**：`reply_format_rules`、`dialogue_pace_rules`、`dialogue_end_rules`、`output_rules`
- **无**请求体顶层 `bestPracticePoints`；Step2 草稿的 camelCase `bestPracticePoints` 落库前须映射到 `coach.best_practices`

## ② 什么时候生成（固定）

- G4 通过（`title`/`sceneBackground` 已确认并写回 `draft.json`）后**立即启动**本步
- 与 Step4.1 `suggest`（HTTP）**同步启动、互不等待**；suggest 仍需成功后才展示推荐
- 落库前（G6）必须完成；G6 未满足时不得进入 Step4.3 / create
- **首调 suggest** 通常尚无完整 `contextPayload`（可不带或带部分）；禁止为等本步完成再调 suggest

**用户确认知识后**：仅 `finalize`（本地，<1s）→ **先检 G6**：
- **G6 已满足**（doctor 5 + coach 3 键均已写入）→ 进 4.3 最终清单 → 等「确认提交」→ create
- **G6 未满足**（典型：G4 后未同步生成本步就 finalize，或超时/截断未完成）→ **立即补跑**本步并写入 `scene.contextPayload` → `--mode createScene` 通过后再进 4.3；禁止直接 create

**禁止误解**：「确认知识后勿重跑 4.2」= 勿在 **G6 已满足** 时重复生成；**不是**可以跳过本步。除非用户改了顾虑/目标/背景/标题，否则 G6 已满足后勿再完整重跑。

## ③ 生成顺序（写入位置）

1. **doctor**（一次模型调用，5 键）：`known_background` → `core_concerns` → `today_status` → `question_boundary`（**模型仅输出第二层 3～5 条**；第一层由 `question_boundary_assemble.py` 拼接，见 `contextPayload-generator-spec.md` 固定 C）→ `termination_rules`（模型仅写场景条；固定 A 由 Agent 拼接）
2. **coach**（一次模型调用，2 键）：`expected_behaviors` → `termination_rules`（模型仅写场景条；固定 B 由 Agent 拼接，见 `contextPayload-generator-spec.md`）
3. **`coach.best_practices`**（Agent 映射）：由 `bestPracticePoints` 三项映射，模板见 `contextPayload-generator-spec.md`
4. 写入 `draft`/`scene` 的 `contextPayload`；落库前 `tbs-scene-validate.py --mode createScene`（见 `tbs-scene-create.md`）

字段硬约束（结构/长度/类型）统一见 `contextPayload-schema-guide.md`。

## ④ 局部修复原则（强制）

- 仅当某键缺失/不合规时，允许只重生成该键（或该侧一次模型调用内的键集），其余键保持不变；禁止无意义全量重跑本步。
- 用户改动顾虑/目标/标题/背景等上游输入时，按影响面重生成相关键（至少含 `question_boundary` 与相关 `termination_rules`）。

## ⑤ 基本边界（保密）

- 禁止向用户展示 `contextPayload` 正文、键名、生成依据
- 催问仅答：「正在生成场景内容，请稍候…」

---

## 落位示例

```json
{
  "version": 1,
  "doctor": {
    "known_background": "…",
    "core_concerns": "- …\n- …",
    "today_status": "…",
    "question_boundary": "## 提问边界\n\n### 第一层：永远禁止（所有场景通用）\n- 禁止询问患者病历、诊断、隐私\n- 禁止要求代表推导产品知识中没有的数据\n- 禁止编造任何数值\n- 资料/文献/交付物：全场至多确认 1 次（\"嗯，知道了\"），后续双方不得再提交付形式（放哪、带什么、发您、有空看看等）\n\n### 第二层：本场景允许问的方向\n- 可问：…（基于产品知识中已有内容）",
    "termination_rules": "- 出现无依据的…\n- 代表编造…\n- 代表两次以上回避…"
  },
  "coach": {
    "expected_behaviors": "- …",
    "termination_rules": "- 出现编造…\n- 未就「…」给出具体数据…",
    "best_practices": "- …\n- …\n- …"
  }
}
```

完成后进入 `tbs-scene-create.md`。
