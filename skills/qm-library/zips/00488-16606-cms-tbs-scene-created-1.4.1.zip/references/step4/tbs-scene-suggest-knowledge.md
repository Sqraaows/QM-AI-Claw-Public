# Step4.1：产品知识推荐

| | |
|--|--|
| **本步目标** | 按场景信息调用推荐接口，让用户确认要关联的产品知识 |
| **本步产出** | `knowledgeIds`、`knowledgeSuggestionState`（及缓存 `knowledgeSuggestions` 供 finalize） |
| **下一步** | 用户确认知识 → `finalize` → Step4.3（`contextPayload` 与 suggest 同步启动，见 `scenario-parse.md`） |

**时机**：G4 通过（`title`/`sceneBackground` 已确认并写回 `draft`）后**立即**进入本阶段。  
**禁止**：与「展示标题/背景请确认」同一轮调用 suggest；未 G4 不得推荐知识点。

## Step4.1 执行顺序约束（强制）

G4 达成后（本阶段开始）：
- 必须立即启动 suggest（本脚本，HTTP）
- 必须立即启动 contextPayload 生成（Step4.2，见 `scenario-parse.md`）
- 两者互不等待

闸门（必须同时满足）：
- suggest 完成前：不得展示推荐列表（仅可用 `userVisibleHint` 类进度提示）
- contextPayload 未完成前：不得进入 Step4.3（G6 必须先满足）
- finalize 后：必须检查 G6（`contextPayload` 完整）后才允许进入 Step4.3

执行顺序（固定）：
1) suggest
2) 仅展示 `userDisplay`
3) 用户确认知识
4) finalize
5) 检查 G6
6) 进入 Step4.3

## 与 Step4.2 同步启动（G4 后，互不等待）

```
同步启动 ─┬─ suggest（本脚本，HTTP）
          └─ contextPayload（scenario-parse.md，模型）
              ↓ suggest 成功
展示【产品知识推荐】（须 userDisplay 两节）
              ↓ 用户确认采纳
finalize（本地）→ 4.3（此时 G6 应已完成）
```

- **须等 suggest 成功**再展示推荐；4.2 可在用户阅读推荐时继续完成。
- `finalize` **无 HTTP**；勿将 `--mode finalize` 耗时误判为 API。

## 脚本

### suggest（默认）
```bash
python3 scripts/tbs-scene-suggest-knowledge.py \
  --access-token "$ACCESS_TOKEN" \
  --params-json '{"scene":{...},"state":<Step1 state>}'
```
- `scene` 需含：`drugName`、`title`、`location`、`repBriefing`（或 `sceneBackground`），可选 `contextPayload`
- `state.drugs` 供 `drugName`→`drugId` 精确匹配（仅脚本内部，不落库）
- **空列表（无任何可展示条目）→ 阻断**：不得进入 `finalize` / Step4.3 / create。对用户使用下方固定提示（见「无可用推荐」）。
  - **suggest 失败（HTTP/超时/解析失败）→ 阻断**：不得进入 `finalize` / Step4.3 / create。对用户统一提示：「产品知识推荐暂时失败，请稍后重试。」

### finalize
```bash
python3 scripts/tbs-scene-suggest-knowledge.py \
  --mode finalize \
  --params-json '{"scene":{"knowledgeSuggestions":[...],"knowledgeAcceptance":{...}}}'
```

`knowledgeAcceptance`：
```json
{
  "acceptedMatchedIds": ["..."],
  "rejectedMatchedIds": ["..."]
}
```
- `auto-linked`：默认纳入，除非 `rejectedMatchedIds`
- `suggested`：仅 `acceptedMatchedIds` 纳入
- `create`：不纳入
- **finalize 后 `knowledgeIds` 为空 → 阻断**

### 用户口语 → `knowledgeAcceptance`（finalize 前由 Agent 写入 scene）

| 用户说法 | 解析结果 |
|----------|----------------------|
| 「采纳待确认 1、2」（含旧式「采纳 1、2」） | `acceptedMatchedIds`：「待您确认」列表中**对应序号**条目的 `matchedKnowledgeId` |
| **「待确认都可以」** / 「都可以」 | `acceptedMatchedIds`：**全部** `status=suggested` 条目的 `matchedKnowledgeId` |
| 「都不要」 | `acceptedMatchedIds` 为空（不纳入任何 suggested 条目） |
| 「去掉自动关联 3」（含旧式「拒绝自动关联 1、3」） | `rejectedMatchedIds`：「已自动关联」列表中**对应序号**条目的 `matchedKnowledgeId` |

> 序号一律按其**所属列表**（「待您确认」或「已自动关联」）解析；两个列表序号独立，禁止跨列表套用。

## finalize 行为边界（硬阻断）

**finalize ≠ create**。finalize 仅用于：
- 计算最终 `knowledgeIds`
- 更新 `knowledgeSuggestionState`

finalize 后：
- 禁止调用 create
- 禁止输出「开始创建」「正在创建场景」「场景创建成功」
- 禁止进入 Step4.3，**除非** G6 已完成（`contextPayload` 完整）

编排器/脚本 stdout 的 **`nextStep`** 仅用于指导下一条用户可见输出与闸门检查；finalize 成功后 **须 G6** 再展示最终业务清单；**禁止** finalize 后同轮直接 `create` 或输出「场景创建成功」。

## 用户可见

1. 完整已确认清单（Step2 字段）
2. 推荐列表**仅两类**（见下方模板；数据以脚本 stdout 的 `userDisplay` 为准）：
   - **已自动关联**（`status=auto-linked`）
   - **待您确认**（`status=suggested`）
3. 用户操作指引（必须清晰、可执行；**序号必须锚定到所属列表名**，避免两套编号撞号）：
   - 若存在「🤔 待您确认」：用户回复 **「待确认都可以」**（全部纳入）/ **「采纳待确认 1、2」**（部分纳入）/ **「都不要」**（都不纳入）；如要去掉某条自动关联项，回复 **「去掉自动关联 3」**（序号对应「已自动关联」列表）。
   - 若**只有**「✅ 已自动关联」且「🤔 待您确认」为空：用户只需回复 **「确认知识」** 或 **「继续」** 表示接受当前关联并进入下一步；不得让用户猜测是否要选序号。
4. 用户确认知识后：无论是否存在 suggested 条目，均必须先执行 `finalize`；不得跳过 finalize 直接进入 Step4.3。
5. finalize 后 → **检查 G6**（`contextPayload` 完整）→ 展示「已关联产品知识」仅主题名 + ✅ → **再** 进 4.3 最终清单（**不是** 直接 create）

### 无可用推荐（必须固定处理）

当推荐列表两类都为空（既无「已自动关联」，也无「待您确认」）时：

- **定义**：脚本返回可展示的 `userDisplay` 为空，或展示结果为「已自动关联：无」「待确认：无」。
- **动作**：**阻断流程**，不得进入 `finalize`，不得进入 Step4.3，更不得 create。
- **对用户固定提示文案**（必须原样或仅做极轻微同义改写，保持指令清晰）：

```text
【产品知识推荐】
当前知识库中没有可关联的匹配条目，因此本流程无法继续创建场景。

你可以选择：
1）调整场景信息（例如品种/科室/医生顾虑/代表目标/场景地点）后我再为你重新推荐；
2）回复「放弃创建」结束本次创建。
```

- **禁止**：询问用户「是否继续使用这条建议创建的知识内容」或「是否新建产品知识」等选择题（本流程不支持新建知识，且无知识无法创建）。

### 禁止对用户展示（违反即为执行错误）

- **`status=create` 的任意条目**（API 可能返回，但本 Skill **不能**在产品知识库新建知识）
- 整块 **「建议新建」** / **「是否新建项 N」** / 引导用户在本流程内补充新知识
- `knowledgeId`、`matchedKnowledgeId`、匹配日志、接口字段名

推荐列表**只能**基于 stdout 的 `userDisplay` 展示；Agent **禁止**：
- 从 `knowledgeSuggestions` 原始内容自行生成展示
- 自行推断/脑补推荐条目或“建议新建/create 项”
- 将任何非 `userDisplay` 的内容展示给用户（含内部字段拼接、泄露 matchedKnowledgeId 等）

若 API 返回了 `create` 项：脚本 `userDisplay` 已过滤；Agent **不得**自行从 `knowledgeSuggestions` 全文补展示。

库内暂无匹配时：可一句说明「该主题需由管理员在产品知识库维护，本创建流程无法新建」；**不得**把 `create` 当待办问用户。

### 推荐列表展示模板（仅两节）

```text
【产品知识推荐】

✅ 已自动关联（将默认纳入）：
1. <主题名> — <理由，可选>
…

🤔 待您确认：
1. <主题名> — <理由>
…

「✅ 已自动关联」默认全部纳入，无需操作。
请告诉我「🤔 待您确认」里要纳入哪些：
· 全部纳入 → 回复「待确认都可以」
· 部分纳入 → 回复「采纳待确认 1、2」（序号对应「待您确认」列表）
· 都不纳入 → 回复「都不要」
（如需去掉某条已自动关联，回复「去掉自动关联 3」，序号对应「已自动关联」列表。）
```

> 「🤔 待您确认」为空时，**不展示**上面的三选一指引，改用单行：「本次没有需要你确认的条目，「✅ 已自动关联」将全部纳入。回复「继续」即可进入下一步。」

**禁止**出现第三节「建议新建」或询问是否新建。

Step4.1 的「确认」仅指知识采纳，**不是**落库口令；落库须 Step4.3 的 **「确认提交」**。

### 禁止歧义指令（必须）

- 禁止在推荐列表下对用户说「请回复确认/继续，我开始创建场景」这类不区分“确认知识”与“确认提交”的话术。
- 推荐列表场景中，「确认/继续」必须被解释为**确认知识采纳**（进入 finalize），不得暗示已进入落库。

### 口令阶段绑定（强制）

- Step4.1：用户「确认」「继续」「确认知识」= 确认知识采纳（触发 finalize）
- Step4.3：用户「确认提交」= 允许 create
- 除 Step4.3 外：单独出现「确认」绝不允许触发 create

## 阻断规则（集中）

以下任一情况必须阻断（不得 finalize / 不得进入 Step4.3 / 不得 create）：
- suggest 调用失败（HTTP/解析/超时）
- 无可展示推荐（`userDisplay` 为空或两类均无）
- finalize 后 `knowledgeIds` 为空
- G6 未完成（`contextPayload` 不完整）

## 写入 scene
- `knowledgeIds`
- `knowledgeSuggestionState`
- `knowledgeSuggestions`（供 finalize）
