# 提问边界生成任务

> Agent 生成 `doctor.question_boundary` 时使用本文。落库契约见 `contextPayload-schema-guide.md` §4。

## 任务

根据【品种】、【医生核心顾虑】和【医药代表目标】，**仅生成第二层** 3～5 条「可问」方向；**禁止**模型输出第一层或 `## 提问边界` 标题。落库前由脚本拼接完整正文。

## 输入

- 品种：来自 `draft.json` 已确认的 `drug` / `drugName`（场景推广品种全名）
- 医生核心顾虑：来自 `draft.json` 的 `doctorConcerns` / `core_concerns` 已确认内容
- 医药代表目标：来自 `draft.json` 的 `repGoal`

---

## 模型输出范围（强制）

**只输出**下列格式的 3～5 行（纯文本，无标题、无解释）：

```text
- 可问：[方向]（基于产品知识中已有内容）
```

**禁止输出**：`## 提问边界`、`### 第一层`、`### 第二层`、第一层四条固定 bullet。

---

## 第二层生成规则

约束：

- `[方向]` 必须能从【医生核心顾虑】或【医药代表目标】直接找到依据
- `[方向]` 须在顾虑/目标一级关键词基础上，追加可从输入文本中直接识别的本场景限定词（优先使用【品种】名称，其次是患者群特征、症状维度、疗程/费用类别等），禁止将顾虑/目标关键词原词直接作为方向
- 自检：把 `[方向]` 替换到任何其他场景仍成立 → 说明过泛，需加场景限定词改写
- 不写具体问题
- 不写具体数据
- 不写研究名称
- 不写产品知识原文
- 每条控制在 6-16 字
- 禁止抽象方向词（如「进一步了解」「详细说明」「展开讲讲」「综合评估」）

---

## 脚本拼接（Agent 必须执行，禁止手写第一层）

第一层固定四条由 `scripts/question_boundary_assemble.py` 逐字拼接（与 `contextPayload-generator-spec.md` **固定 C** 一致）。

### 1）拼接并写入 draft

将模型输出的第二层保存为 `layer2.txt`（或 `--layer2-text`），执行：

```bash
python3 scripts/question_boundary_assemble.py patch-draft \
  --draft-file .tbs-scene-work/draft.json \
  --layer2-file layer2.txt
```

### 2）仅生成完整字符串（调试）

```bash
python3 scripts/question_boundary_assemble.py assemble --layer2-file layer2.txt
```

### 3）解析 JSON 写入 `doctor_context`（`## 提问边界（强制）`）

```bash
python3 scripts/question_boundary_assemble.py patch-doctor-context \
  --json-file parsed.json --layer2-file layer2.txt
```

### 4）落库前校验

`createScene` 时 `tbs-scene-validate.py` 会校验 `question_boundary` 第一层是否为脚本 canonical 前缀且第二层 3～5 条合规。亦可单独：

```bash
python3 scripts/question_boundary_assemble.py validate --draft-file .tbs-scene-work/draft.json
```

---

## 第一层固定条文（脚本内置，模型勿输出）

- 禁止询问患者病历、诊断、隐私
- 禁止要求代表推导产品知识中没有的数据
- 禁止编造任何数值
- 资料/文献/交付物：全场至多确认 1 次（"嗯，知道了"），后续双方不得再提交付形式（放哪、带什么、发您、有空看看等）

## 落库形态（脚本 `assemble` 完成后）

```text
## 提问边界

### 第一层：永远禁止（所有场景通用）
（固定四条，见上）

### 第二层：本场景允许问的方向
（模型生成的 3～5 条）
```
