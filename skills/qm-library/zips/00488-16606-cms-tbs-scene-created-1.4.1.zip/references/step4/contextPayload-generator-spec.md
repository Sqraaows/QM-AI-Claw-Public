# Step4.2 `contextPayload` Generator Spec（模板/风格/固定条）

> 本文只定义 **生成器写作规范**（固定条、正反例、措辞与风格禁令）。  
> 主流程（何时生成、如何编排、写入哪里）见 `scenario-parse.md`。  
> 字段契约（结构/长度等）见 `contextPayload-schema-guide.md`。  
> 提问边界生成任务见 `question-boundary-generator.md`。

## 固定合规（Agent 逐字拼接，禁止模型改写）

### 固定 A — doctor（拼在 `doctor.termination_rules` 最前）

```text
- 出现无依据的疗效或准入承诺，或声称有数据但说不清来源
- 代表编造数据/证据，或引用来源不清、前后矛盾
```

### 固定 B — coach（拼在 `coach.termination_rules` 最前）

```text
- 出现编造或前后矛盾的临床/经济数据；对安全性做无依据保证
- 出现无依据的绝对化承诺，或隐瞒重大限制与风险
```

### 固定 C — `doctor.question_boundary` 第一层（脚本拼接，禁止模型输出）

由 `scripts/question_boundary_assemble.py` 将模型**仅输出的第二层** 3～5 条与下列前缀逐字合并。Agent **禁止**手写第一层或完整 `## 提问边界` 后直接落库。

合并后前缀（至「第二层」标题行止）与 `contextPayload-schema-guide.md` §4.2 一致；第二层 bullet 由模型按 `question-boundary-generator.md` 生成。

落库前执行：

```bash
python3 scripts/question_boundary_assemble.py patch-draft --draft-file <draft.json> --layer2-file <layer2.txt>
```

## 语言与风格禁令（强制）

- 禁止第一/二人称（我/我们/你/您）
- 禁止医生心理/动机/人格评判与台词（例：其实很反感、只是敷衍、主任说今天先到这里）
- termination 只能写“代表可观察行为/明显越界行为/输出质量不足”
- 禁止在 `contextPayload` 任意键里写节标题（例外：`question_boundary` 内固定 `## 提问边界` 及 `### 第一层/第二层`）

## `best_practices` 输出模板（强制）

必须为 **恰好 3 条** `-` 开头，用换行连接，顺序固定：

```text
- {openingScript}
- {questionResponseScript}
- {recommendation}
```

## `expected_behaviors` 写作模板（建议）

- 3～5 条 `-`，每条都是“代表可观察行为”
- 只写动作/质量标准，不复述 `best_practices` 话术全文

## 反例（用于自检，不要照抄）

- doctor 写成教练视角：`代表未能有效沟通时医生失去耐心`（混写医生心理 + 教练评价）
- coach 写医生离场：`医生不想再谈就结束`（不允许）
- 第二层抽象方向：`进一步了解` / `详细说明`（不允许）
- 第二层复述一级词：`疗效` / `费用` / `依从性` 等未加品种或场景限定词的方向（不允许）
- 第二层过泛方向：换到其他品种/场景仍成立的 `[方向]`（不允许）
