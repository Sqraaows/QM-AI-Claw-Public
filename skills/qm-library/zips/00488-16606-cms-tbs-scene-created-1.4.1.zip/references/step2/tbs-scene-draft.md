# Step2 → draft.json 同步（必读）

> 用户只见自然语言清单；机器侧维护 `.tbs-scene-work/draft.json`。**Step3 校验只读** `--params-file draft.json`，禁止手拼 `--params-json`（超长转义易卡）。（Step4.3 create/createScene 校验传 in-session 组装的 scene，允许 `--params-json`。）

## Agent 硬约束

| 规则 | 说明 |
|------|------|
| 唯一写入 | **仅** `tbs-scene-draft.py sync` 生成/更新 draft；**禁止** `write`/编辑器手改 `draft.json` |
| 唯一源 | 会话只维护 `confirmed.json`（中英文键均可）；**禁止**按业务中文键直接写 draft（如顶层 `"地点"`、`"医生画像"`） |
| 业务领域 | 进入 Step2 即在 `confirmed` 写入 **`businessDomain`: `"临床推广"`**；不向用户采集 |
| 对用户 | 禁止说「JSON 格式问题」；失败则静默重跑 `sync` |
| Step3 后 | 只**合并**写入 `title`、`sceneBackground`；**禁止**整文件覆盖（会丢 `bestPracticePoints` 等） |

## 数据流规则（最高优先级）

- 会话只维护 `confirmed.json`
- `draft.json` **只能**通过 `tbs-scene-draft.py sync` 生成
- 禁止手写/编辑 `draft.json`
- **Step3 校验**只能读取 `--params-file draft.json`，禁止 `--params-json`
- （Step4.3 create/createScene 例外：传 in-session 组装的 scene，允许 `--params-json`）

## 时序规则

- `confirmed.json` 任意变更后，必须立即重新 `sync`
- 未完成最新 `sync` 前，禁止进入 Step3/Step4
- 仅当用户对“完整已确认清单”作出整体同意继续时，才允许执行 `sync --user-confirmed` 并进入 Step3
- **「用户提供新内容 / 修改字段」一律视为内容变更，不等于确认**：该轮必须以回显完整清单收尾、停步等待用户确认；**禁止**在同一轮内既写入变更又 `sync --user-confirmed` + step3

## Step3 后锁定

Step3 `passed=true` 后：
- 仅允许修改：`scene.title`、`scene.sceneBackground`（合并写回）
- 若修改任何其它 Step2 字段：必须回到 Step2 → 修改 `confirmed` → `sync` → 用户重新确认 → `sync --user-confirmed` → 重跑 Step3

## 文件与命令

| 项 | 约定 |
|----|------|
| 路径 | `.tbs-scene-work/draft.json`（可用 `TBS_SCENE_DRAFT_FILE` / `--draft-file`） |
| 每轮回显后 | `sync`（无 `--user-confirmed`） |
| 用户确认清单后 | `sync --user-confirmed` → 再 `step3` |

```bash
mkdir -p .tbs-scene-work

python3 scripts/tbs-scene-draft.py sync \
  --confirmed-file .tbs-scene-work/confirmed.json \
  --draft-file .tbs-scene-work/draft.json

# 用户「确认/继续」后：
python3 scripts/tbs-scene-draft.py sync \
  --confirmed-file .tbs-scene-work/confirmed.json \
  --draft-file .tbs-scene-work/draft.json \
  --user-confirmed

python3 scripts/tbs-scene-validate.py --mode step3 \
  --params-file .tbs-scene-work/draft.json
```

`sync` 会把 `confirmed` 归一为 canonical（见下）；**不要**手写下列结构。

### canonical `draft.json`（脚本输出）

```json
{
  "version": 1,
  "meta": { "userConfirmed": true },
  "scene": {
    "scenarioBase": {
      "location": "门诊",
      "doctorConcerns": "…",
      "repGoal": "…",
      "businessDomain": "…",
      "department": "…",
      "drug": "…"
    },
    "doctorPersona": {
      "personality": "…",
      "communicationStyle": "…",
      "behaviorTendency": "…",
      "description": "…",
      "surname": "程",
      "title": "主任"
    },
    "bestPracticePoints": {
      "openingScript": "…",
      "questionResponseScript": "…",
      "recommendation": "…"
    },
    "drugName": "美泰彤"
  }
}
```

字段语义见 `references/step3/draft-schema.md`。

### `confirmed.json`（Agent 维护，示例）

```json
{
  "businessDomain": "临床推广",
  "department": "风湿科",
  "drug": "美泰彤",
  "location": "门诊",
  "doctorConcerns": "价格偏高",
  "repGoal": "告知RA新适应症",
  "doctorPersona": { "personality": "…", "communicationStyle": "…", "behaviorTendency": "…", "description": "…", "surname": "程", "title": "主任" },
  "bestPracticePoints": { "openingScript": "…", "questionResponseScript": "…", "recommendation": "…" }
}
```

同步会去掉 `（AI生成，可修改）` 前缀。

## 用户说「继续 / 继续下一步」

1. 对用户：**不输出任何信息**（避免用户停留在“请稍候/校验中”提示而无后续可见进展）
2. 执行上表 `sync --user-confirmed` → `step3`
3. `passed=true` 后按 `step3/title-and-scene-background.md` 生成标题/背景 → **展示并请用户确认**（见 `step3/tbs-scene-validate.md`）→ 用户确认后**仅合并** `scene.title`、`scene.sceneBackground` 写回 draft → **再** Step4.1

## Step4 与 `bestPracticePoints`

- Step2～落库前：**保留** `scene.bestPracticePoints`（勿在 Step3/4 重写 draft 时删掉）
- Step4.2：映射为 `contextPayload.coach.best_practices`（3 条 `-`）；落库无顶层 `bestPracticePoints`，draft 内保留原 object 供排障

## 工作区生命周期

| 时机 | 动作 |
|------|------|
| 落库成功 | 删 `.tbs-scene-work/` 全部（勿只删 draft） |
| 落库失败 / dry-run | 保留 |
| 同会话再建、用户「重新创建」 | 先删目录，再从 Step1 |

## 禁止

- 跳过 `sync`、手搓 `--params-json`、要求用户「整理 JSON」
- 用顶层中文键名写 draft（`"地点"`、`"医生画像":{ "性格特征" }` 等）— 会导致 step3 报缺字段
