# Step3：校验草稿 + 生成标题/背景

| | |
|--|--|
| **本步目标** | 确认 Step2 草稿必填项齐全；生成并让用户确认场景标题与场景背景 |
| **本步产出** | `title`、`sceneBackground`（与落库 `repBriefing` 同源） |
| **下一步** | Step4.1 产品知识推荐 |

脚本：`tbs-scene-validate.py`（**无 token**）

**标题/背景文案规则（必读）**：`title-and-scene-background.md`（标题句式、背景三块结构、示例、禁止开场建议）。

## ① Step3 目标

- 校验 Step2 草稿是否完整（地点/顾虑/目标/画像/最佳实践）
- 按 `title-and-scene-background.md` 生成 `title` 与 `sceneBackground`
- 等待用户确认

## ② 输入规则（最重要）

- Step3 **仅允许读取** `--params-file .tbs-scene-work/draft.json`
- `draft.json` **必须**来自 `tbs-scene-draft.py sync --user-confirmed`（见 `step2/tbs-scene-draft.md`）
- Step3 期间 `draft.json` 视为**冻结快照**：从调用 Step3 到用户确认 title/background 并写回前，禁止重跑 `sync` 覆盖 `draft.json`
- 若用户修改任一 Step2 字段：返回 Step2 → 改 `confirmed` → `sync` → 用户重新确认 → `sync --user-confirmed` → 重跑 Step3
- 禁止使用 `--params-json`

```bash
python3 scripts/tbs-scene-validate.py \
  --mode step3 \
  --params-file .tbs-scene-work/draft.json
```

## ③ 校验结果分流

- `passed=false`：返回 Step2 补 `missingFields`（不重复整段问候模板）
- `passed=true`：
  1. 读取 `nextStep.generationRules.hardConstraints` 中的生成约束（禁止姓氏等），**生成前加载到上下文**
  2. 生成 `title` + `sceneBackground`，生成完毕后对照 `title-and-scene-background.md §5` 自检，通过后展示给用户
  3. 用户确认后，**必须**将 `title`、`sceneBackground`、`repBriefing`（= `sceneBackground`）合并写回 `draft.json`（`scene` 层），再进 G4/Step4.1

> **写回方式**：直接更新 `.tbs-scene-work/draft.json` 的 `scene.title`、`scene.sceneBackground`、`scene.repBriefing` 三个字段；写回后 G7/createScene 校验才能通过（validate `--mode createScene` 要求 `repBriefing` 非空）。

## ④ G4 门禁（保留）

用户未明确确认 `title` + `sceneBackground` 前，禁止进入 Step4（`passed=true` **不等于** G4 已过）。

## ⑤ 失效重算规则（保留）

若修改「医生核心顾虑（doctorConcerns）」或「代表目标（repGoal）」：
- 必须重生成：`title` / `sceneBackground`
- 必须重新执行：Step4.1 suggest
- 必须重生成：Step4.2 `contextPayload`
