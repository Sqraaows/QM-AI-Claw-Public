### Step3 草稿 JSON 契约（数据形态，非流程）

> **说明**：本文只定义 `scene` 语义；**写入**见 `step2/tbs-scene-draft.md`（`sync`）；**Step3**见 `tbs-scene-validate.md`。

本文定义：**`.tbs-scene-work/draft.json`** 中 `scene`（或包裹在 `{"scene": …}` / `{"draft": …}` 内）应满足的语义与推荐字段形态。Step3 **只读**该文件：`tbs-scene-validate.py --params-file .tbs-scene-work/draft.json`。

---

#### 1. 根结构

- 脚本读取顺序：`payload.scene` → `payload.draft` → `payload` 本身（须为 object）。
- **推荐**：显式使用 `{ "scene": { … } }`，便于与会话其它元数据并存。

---

#### 2. Step3 必填语义（五类）

| 语义（`missingFields` 中文名） | 含义 | 推荐挂载位置 |
|-------------------------------|------|----------------|
| 地点 | 场景发生地点 | `scenarioBase` 或根层：`location` / `地点` / `timePlace` / `timeLocation` |
| 医生担忧点 | 医生核心顾虑 | `scenarioBase` 或根层：`doctorConcerns` 等 |
| 代表目标 | 代表拜访目标 | `scenarioBase` 或根层：`repGoal` 等；注意 `repBriefing` 是落库阶段字段（场景背景），语义不同，**禁止**用 `repBriefing` 的值充当代表目标写入此处 |
| 医生画像 | 人设 + 简介 + 姓氏 + 职称（或等价拆分） | 优先 **`doctorPersona` object** |
| 最佳实践要点 | 开场 / 回应 / 推荐 三项齐全 | 优先 **`bestPracticePoints` object** |

若上游使用 `scenarioBase`，请将上述「基础采集」字段放在该 object 内；**画像与最佳实践**仍推荐独立子对象，避免扁平混淆。

---

#### 3. 推荐 canonical 形态（归一化目标）

在调用校验前，建议以 `step2/tbs-scene-draft.md` 中的 `sync` 产物为准（字段名稳定，便于测试与排错）。

规则（强约束）：

- **canonical > alias 优先级**：同一语义若同时出现 canonical 与 alias（别名字段），以 canonical 值为准；alias 仅用于读取兼容。
- **alias 禁止持久化回写**：任何 alias 字段（如 `bestPractice`、中文键等）不得写回/落盘到 `draft.json`；持久化输出只允许 canonical 键。
- **canonical 类型固定**：canonical 字段类型必须固定，禁止「字符串或数组」这类多态。Step3/Step4 需要稳定的数据形态以避免分支歧义。
- **null/空字符串语义**：`null`、`""`、仅空白字符串均视为“缺失”；不得用它们占位以绕过校验。
- **sync 是唯一 canonicalizer**：canonical 归一化只允许通过 `tbs-scene-draft.py sync` 完成；Agent/编排器禁止手工归一化或“脑补 canonical”（包括从对话/回显清单拼装 params）。

```json
{
  "scene": {
    "scenarioBase": {
      "location": "……",
      "doctorConcerns": "……",
      "repGoal": "……"
    },
    "doctorPersona": {
      "personality": "……",
      "communicationStyle": "……",
      "behaviorTendency": "……",
      "description": "……",
      "surname": "……",
      "title": "……"
    },
    "bestPracticePoints": {
      "openingScript": "……",
      "questionResponseScript": "……",
      "recommendation": "……"
    }
  }
}
```

说明：

- **医生画像**：`personality` + `communicationStyle` + `behaviorTendency` 与合并字段 `personaConfig` / `人设配置` **二选一**满足「人设」语义即可（脚本逻辑见 `tbs-scene-validate.py`）；**简介**可用 `description` 或 `introDescription` / `简介描述`。
- **最佳实践**：容器名推荐 **`bestPracticePoints`**；与业务常用别名 **`bestPractice`** 在校验脚本中等价。
- **已解析 persona**：若上游已通过其他链路写入合法 `personas[]`（含默认画像），脚本可将「医生画像」视为已满足（兜底分支），无需再检查 `doctorPersona` 字段。

---

#### 4. 与校验脚本的关系

- **契约主文档**：本文（给人 / Agent 对齐字段）。
- **实现与别名全集**：以仓库内 `scripts/tbs-scene-validate.py` 中 `_validate_step3` 为准；历史草稿可出现多套字段名，脚本为兼容会保留别名列表。
- 若团队约定 **「一律先归一化为第 3 节 canonical 再校验」**，可减少别名歧义；未归一化时仍以脚本实际支持的键为准。

---

#### 5. Step2 C 层（进 step3 前须用户确认）

拜访对象、诊室氛围、医生核心顾虑、代表目标——齐备后触发 AI 生成画像与最佳实践（见 `step2/interaction-echo-confirmation.md`）。

#### 6. 显式非目标

- 不定义 `title` / `sceneBackground`（Step3 生成，见 `tbs-scene-validate.md`、`title-and-scene-background.md`）。
- 不定义 `contextPayload` / `knowledgeIds`（Step4，见 `step4/` 文档）。
