---
name: cms-tbs-scene-created
description: TBS 场景创建编排。创建/新建/生成场景→走 Step1-4；问流程/规则→只解释；报错/异常→排障文档。按 references 推进至落库。
skillcode: cms-tbs-scene-created
github: https://github.com/xgjk/tbs-skills/tree/main/cms-tbs-scene-created
dependencies:
  - cms-auth-skills
version: 1.4.1
---

# cms-tbs-scene-created

## 任务分流（进链路前先判意图）

| 用户意图 | 判断依据（满足任一即可） | 处理方式 |
|----------|--------------------------|----------|
| **执行类**（创建场景） | 「创建/新建/开始/生成/训战/对练」+ 场景；或咨询后明确要开始创建 | 走下方 **步骤与文档** 主表，Step1→4.3，不得跳步 |
| **咨询类**（了解规则/流程） | 「怎么用」「流程是什么」「为什么要…」「某字段什么意思」；**无**具体报错、**无**要求立刻创建 | **不执行任何脚本**；仅用本 Skill + 相关 `references/` 解释 |
| **排障类**（失败/异常） | 具体报错、字段不对、输出不符、某步卡住 | 先 `references/pitfalls.md`（按 Step）；未覆盖再 `failure-examples.md`；定向到对应 step 文档；**不重置**已通过的前置步骤 |

**切换规则**：同一会话先咨询、后表达创建意图 → 再切执行类。排障不自动从头跑 Step1。

---

## 步骤与文档（执行类主表）

| 步 | 做什么 | 产出 | 过门禁 | 必读文档 |
|----|--------|------|--------|----------|
| 鉴权 | `cms-auth-skills` | `access-token` | G1 | `references/auth.md` |
| Step1 | `tbs-scene-fetch-config.py` | `state` 三列表 + `nextStep.userVisibleMessage` | G2 | `references/step1/tbs-scene-fetch-config.md` |
| Step2 | 采集、回显、`sync`→`.tbs-scene-work/draft.json`、`--mode step2` | `draft.json`、`drugName` | G3 | `step2/interaction-echo-confirmation.md`、`step2/tbs-scene-draft.md`、`default-input-template.md` |
| Step3 | 只读 `draft.json` 校验、生成并确认标题/背景 | `title`、`sceneBackground` | G4 | `step3/tbs-scene-validate.md`、`step3/title-and-scene-background.md` |
| Step4.1 | suggest → 用户确认知识 → `finalize`（本地） | `knowledgeIds`、`knowledgeSuggestionState` | G5 | `references/step4/tbs-scene-suggest-knowledge.md` |
| Step4.2 | 生成 `contextPayload`（对用户不可见） | `contextPayload` | G6 | `references/step4/scenario-parse.md` |
| Step4.3 | 最终业务清单 → `createScene` → create | 创建成功 | G7–G8 | `references/step4/tbs-scene-create.md` |

**Step4 编排（G4 通过后）**：**同一轮同步启动** Step4.1 `suggest`（HTTP）与 Step4.2 `contextPayload`（模型），两者互不等待；须等 suggest 成功再展示推荐；用户确认知识后 **仅** `finalize` → **G6 必过** → 4.3 清单 →「确认提交」→ create。**禁止**未生成 `contextPayload` 就 create（会导致 doctor/coach 为空）。用户确认知识后**禁止**再完整重跑 4.2，**除非** G6 未满足则**必须立即补跑** 4.2（G6 未满足的典型情形：4.2 在同步生成期间因超时/截断未完成生成）。详见 `scenario-parse.md` §② 什么时候生成。

**执行要点**（不重复各 step 细则）：
- Step1 触发后**不向用户输出任何信息** → 鉴权 → fetch-config。
- **G2 通过后（确定性，不依赖 Agent 读 md）**：将脚本 stdout 的 **`nextStep.userVisibleMessage` 原样**作为下一条用户可见消息；**禁止**首轮枚举三列表或问卷式「请选一个」。
- 需 token：`fetch-config`、`suggest-knowledge`、`create`；`tbs-scene-validate.py` 不需。
- 落库口令：仅 **「确认提交」**；Step4.1/4.2 的「确认」不算落库授权。
- **create 成功**：将 `tbs-scene-create.py` stdout 的 **`userDisplay.userVisibleMessage` 原样**发给用户（含标题+场景背景）；**禁止**展示 `sceneDbId`/ID。

**业务领域**：全程固定 **`临床推广`** 写入 `confirmed`/`draft`；仅科室+品种做 step2 名称匹配（见 `step2/interaction-echo-confirmation.md`）。
**落库成功后**：删除整个 `.tbs-scene-work/`（见 `step4/tbs-scene-create.md`）；失败/放弃不删。

---

## 按需查阅（咨询/排障/异常时才读）

| 场景 | 文档 |
|------|------|
| Step3 标题/背景怎么写 | `references/step3/title-and-scene-background.md` |
| 落库前自检、校验失败 | `references/qa.md` |
| 字段名 / 用户展示词 | `references/glossary.md` |
| 常见坑 | `references/pitfalls.md` |
| 现象 → 处理 | `references/failure-examples.md` |

正常执行路径**不必**先读 qa/pitfalls；排障优先 pitfalls。

---

## 门禁（G#）

| # | 通过条件 | 未过 |
|---|----------|------|
| G1 | 有效 token；全流程鉴权一次 | `auth.md` |
| G2 | 三列表非空；stdout 含 `nextStep.userVisibleMessage` 且已原样展示；**不**拉/不依赖 `productKnowledges` | 不进 Step2 |
| G3 | `businessDomain` 固定「临床推广」；`step2` 下 **科室+品种** exact；C 层（拜访对象/氛围/医生顾虑/代表目标）齐；清单确认后 **`sync --user-confirmed`** | 不进 Step3 |
| G4 | `step3` 通过；用户**已确认** `title`+`sceneBackground` 后写回 draft；**未确认前禁止** Step4.1 | 不进 Step4 |
| G5 | `suggest` 成功并已展示；用户确认知识；`finalize` 后 `knowledgeIds` 非空；**不**展示 `create`/建议新建 | 不进 finalize / 4.3 |
| G6 | `contextPayload` 完整（doctor 5 + coach 3 键非空；可与 4.1 **同步启动**，**finalize 后、4.3 前**必完成）；`create` 脚本会拒绝空 payload | 不进 4.3 / 禁止 create |
| G7 | `--mode createScene` 通过 | 不调 create |
| G8 | 用户 **「确认提交」**；create 成功后清理 `.tbs-scene-work/` | 不调 create |

---

## 全局约束（全流程）

- **保密**：禁止对用户展示内部 ID、`contextPayload` 正文/键名、推荐日志、脚本/API 原文（排障在会话内处理，见 failure-examples）。
- **同源**：`sceneBackground` = 落库 `repBriefing`（`glossary.md`）。
- **草稿**：`confirmed.json`（Agent 维护）→ **仅** `tbs-scene-draft.py sync` 写 `draft.json`；禁止手改 draft。见 `step2/tbs-scene-draft.md`、`step3/draft-schema.md`。
- **create 禁止自动重试**：create 任何失败（503 / 404 / 超时 / 无回包）时，**禁止**自动变换参数/绕脚本直接发 HTTP/修改 payload 后再提交；必须立即向用户报告错误并等待指示。详见 `step4/tbs-scene-create.md §create 执行顺序约束`。
- **禁止姓氏**：生成场景标题与背景时，**严禁**出现任何具体姓氏（如「李主任」「王主任」）；只允许职称/角色称谓。详见 `step3/title-and-scene-background.md §5`。
