## Description: <br>
Orchestrates TBS scene creation by routing creation requests through Steps 1-4, answering process questions, and guiding troubleshooting from bundled references. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[spzwin](https://clawhub.ai/user/spzwin) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents assisting TBS operators use this skill to fetch configuration, collect and validate scene inputs, generate scene title/background/content, suggest product knowledge, and submit the final scene after explicit confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Authenticated remote TBS API calls can create or modify business workflow state. <br>
Mitigation: Require a valid access token from the dependent auth skill, run the documented validation gates, and obtain the explicit final confirmation phrase before creation. <br>
Risk: Post-confirmation changes or incomplete context generation could submit a scene that differs from the reviewed business checklist. <br>
Mitigation: Show the final business checklist before submission, avoid changes after confirmation, and rerun createScene validation if any field changes after dry-run. <br>
Risk: Local workflow cleanup can remove draft state after successful scene creation. <br>
Mitigation: Clean only the .tbs-scene-work files created for the current session and only after a confirmed successful create response. <br>


## Reference(s): <br>
- [Access-token authentication](references/auth.md) <br>
- [Step1: fetch configuration](references/step1/tbs-scene-fetch-config.md) <br>
- [Step2: draft synchronization](references/step2/tbs-scene-draft.md) <br>
- [Step3: validate draft and generate title/background](references/step3/tbs-scene-validate.md) <br>
- [Step4.1: suggest product knowledge](references/step4/tbs-scene-suggest-knowledge.md) <br>
- [Step4.2: generate contextPayload](references/step4/scenario-parse.md) <br>
- [Step4.3: create scene](references/step4/tbs-scene-create.md) <br>
- [Common pitfalls](references/pitfalls.md) <br>
- [Failure examples](references/failure-examples.md) <br>
- [Glossary](references/glossary.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, JSON, Files, API calls] <br>
**Output Format:** [Markdown guidance with shell commands and JSON script outputs] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Maintains local draft state under .tbs-scene-work and submits remote TBS scene creation requests only after required validation and confirmation gates.] <br>

## Skill Version(s): <br>
1.4.1 (source: evidence release and artifact frontmatter/version.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
