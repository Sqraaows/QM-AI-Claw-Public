## Description: <br>
OpenWeather lets an agent use an OOMOL-connected OpenWeather account for weather, forecast, geocoding, air-pollution, UV-index, map-tile, and weather-station actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to retrieve OpenWeather data and manage OpenWeather weather-station resources through the oo CLI. It is suited for weather lookup, location resolution, air-quality context, UV-index checks, map-tile retrieval, and station administration. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, submit measurements for, or delete OpenWeather weather-station data. <br>
Mitigation: Confirm the exact payload, target resource, and intended effect with the user before running write actions; require explicit approval before delete actions. <br>
Risk: Using the connector requires an OOMOL account connected to OpenWeather credentials. <br>
Mitigation: Install and use the skill only when that account connection is intended, and resolve authentication or connection errors through the documented setup flow. <br>
Risk: OpenWeather action schemas and defaults can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing action payloads. <br>


## Reference(s): <br>
- [OpenWeather homepage](https://openweathermap.org) <br>
- [OpenWeather skill on ClawHub](https://clawhub.ai/oomol/oo-openweather-api) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON API responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses containing data and execution metadata; weather map tiles are returned as Base64 PNG bytes.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact metadata and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
