## Description: <br>
v0 (v0.dev). Use this skill for ANY v0 request - reading, creating, updating, and deleting data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to operate a connected v0 workspace from an agent, including chats, messages, versions, projects, deployments, environment variables, webhooks, billing, usage, and workspace scope checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and modify connected v0 workspace data, including projects, deployments, environment variables, hooks, billing, usage, and user scope information. <br>
Mitigation: Install it only for agents that should operate the connected v0 workspace, and review proposed payloads before approving state-changing actions. <br>
Risk: Delete and remove actions can permanently remove v0 chats, projects, hooks, or environment variables. <br>
Mitigation: Confirm the exact target identifier and require explicit approval before running destructive actions. <br>
Risk: Environment-variable, webhook, deployment, visibility, and Vercel-linking changes can expose data or alter production behavior. <br>
Mitigation: Inspect the live action schema and review the intended effect before approving these operations. <br>


## Reference(s): <br>
- [ClawHub v0 Skill](https://clawhub.ai/oomol/oo-v0) <br>
- [v0 Homepage](https://v0.dev) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown and JSON-oriented command guidance for oo CLI connector actions] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are expected as JSON objects containing data and meta.executionId when commands are run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
