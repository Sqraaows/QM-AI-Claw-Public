## Description: <br>
Pexels helps agents search and retrieve Pexels photos, videos, collections, and account collection metadata through OOMOL's Pexels connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to query Pexels media and collection data through the oo CLI, including keyword searches, curated or popular feeds, featured collections, and metadata lookup by ID. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL/Pexels account and may read account-specific collection data. <br>
Mitigation: Use it only with an intended connected account, and review account-scoped requests before running them. <br>
Risk: First-time CLI installation and authentication steps involve external setup commands and connection URLs. <br>
Mitigation: Run setup only from trusted sources and only when an auth, connection, or missing-CLI error requires it. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-pexels) <br>
- [Pexels Homepage](https://www.pexels.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses from executed connector actions are JSON objects containing data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
