## Description: <br>
Eventee helps agents search and read Eventee event data through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and event operations teams use this skill to inspect Eventee event content, attendee groups, participants, registrations, and session reviews from an authenticated Eventee connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Eventee account and may access event participant, registration, and review data. <br>
Mitigation: Use it only with the intended OOMOL account and Eventee connection, and handle returned event data according to the user's privacy and access policies. <br>
Risk: Eventee connector schemas can change upstream, which can make stale payload assumptions incorrect. <br>
Mitigation: Inspect the live connector schema before each action and build payloads from that schema. <br>
Risk: The available security evidence reports a clean scan but advises confirming visible files and requested tools before installation. <br>
Mitigation: Review the artifact files, install instructions, required credentials, and allowed oo CLI usage before deploying the skill. <br>


## Reference(s): <br>
- [ClawHub Eventee release page](https://clawhub.ai/oomol/oo-eventee) <br>
- [Eventee homepage](https://eventee.co) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_event_content action](actions/get_event_content.md) <br>
- [list_groups action](actions/list_groups.md) <br>
- [list_participants action](actions/list_participants.md) <br>
- [list_registrations action](actions/list_registrations.md) <br>
- [list_reviews action](actions/list_reviews.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, json] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and a connected Eventee API key.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
