## Description: <br>
SerpApi lets an agent search and read Google web, news, and maps data through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to run Google Search, Google News, and Google Maps queries through SerpApi via an OOMOL-connected account. The skill guides the agent to inspect the live connector schema before constructing JSON payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup instructions include remote installer commands for the oo CLI. <br>
Mitigation: Review the official install guide and verify the source before running installer commands. <br>
Risk: The skill requires connecting a SerpApi account through OOMOL and therefore depends on sensitive account credentials. <br>
Mitigation: Use an OOMOL-connected account intentionally, avoid automatic first-time setup, and only authenticate or reconnect after explicit user approval. <br>
Risk: Live connector schemas and upstream defaults can change. <br>
Mitigation: Inspect the authoritative connector schema before constructing each payload. <br>


## Reference(s): <br>
- [SerpApi homepage](https://serpapi.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [google_maps_search action](actions/google_maps_search.md) <br>
- [google_news_search action](actions/google_news_search.md) <br>
- [google_search action](actions/google_search.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
