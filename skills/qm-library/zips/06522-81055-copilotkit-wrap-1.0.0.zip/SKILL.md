---
name: CopilotKit 前端集成框架
slug: copilotkit-wrap
description: CopilotKit 前端集成框架 — 只需 30 行代码，即可将 AI 助手集成到 React、Next.js、Vite 等现代前端应用中。基于开源 CopilotKit 二次封装，保留全部原生能力的同时增加了快速启动模板和生产级部署指南。支持 AG-UI 协议、内置 Agent、多模型兼容等功能。适用于需要快速落地 AI Agent 产品的开发团队，相比原生集成方式可节省 80% 的开发时间。 | 来源：https://github.com/q15004040209-creator/copilotkit-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/copilotkit-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
