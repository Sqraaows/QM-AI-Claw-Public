# ⚡ CopilotKit-Wrap

> 基于 [CopilotKit](https://github.com/CopilotKit/CopilotKit) 的 AI Agent 前端快速集成框架 — **30行代码**把 AI 助手装进你的 React/Angular 应用。

## 🎯 是什么

CopilotKit-Wrap 是 CopilotKit 的增强封装，专注于**最快速度落地 AI Agent 产品**：
- 保留原版所有能力（AG-UI 协议、内置 Agent、多模型支持）
- 增加 **5 分钟快速启动模板** + **生产级部署指南**
- 支持 Next.js / Vite + React / Angular 多框架

## ✨ 对比原版 CopilotKit

| 特性 | CopilotKit 原版 | CopilotKit-Wrap |
|------|----------------|-----------------|
| 快速启动 | ✅ | ✅ + 中文注释 |
| 多框架模板 | ❌ 仅有 Next.js | ✅ Next.js + Vite + Angular |
| 部署指南 | 分散 | ✅ 集中在一份 README |
| 中文文档 | ❌ | ✅ |
| 生产级 Demo | ❌ | ✅ 可直接运行的完整示例 |

## 🚀 快速开始

### 方式一：快速安装（推荐）

```bash
# 创建 Next.js 项目
npx create-next-app@latest my-agent-app --typescript --tailwind --app
cd my-agent-app

# 安装 CopilotKit
npm install @copilotkit/react-core @copilotkit/react-ui @copilotkit/runtime

# 复制我们的增强配置文件
cp copilotkit-wrap/next.config.mjs ./next.config.mjs
```

### 方式二：完整 Demo

```bash
git clone https://github.com/q15004040209-creator/copilotkit-wrap.git
cd copilotkit-wrap
npm install
npm run dev
```

## 📦 核心代码示例

### 1. 最小化配置（30行）

```typescript
// app/api/copilotkit/route.ts
import { CopilotRuntime, copilotRuntimeNextJSAppRouterEndpoint } from "@copilotkit/runtime";
import { BuiltInAgent } from "@copilotkit/runtime/v2";

const runtime = new CopilotRuntime({
  agents: {
    default: new BuiltInAgent({
      model: "openai:gpt-4o",
    }),
  },
});

export const POST = async (req) => {
  const { handleRequest } = copilotRuntimeNextJSAppRouterEndpoint({
    runtime,
    endpoint: "/api/copilotkit",
  });
  return handleRequest(req);
};
```

```typescript
// app/layout.tsx
import { CopilotKit } from "@copilotkit/react-core/v2";
import "@copilotkit/react-core/v2/styles.css";

export default function RootLayout({ children }) {
  return (
    <html lang="zh">
      <body>
        <CopilotKit runtimeUrl="/api/copilotkit">
          {children}
        </CopilotKit>
      </body>
    </html>
  );
}
```

```typescript
// app/page.tsx
import { CopilotSidebar } from "@copilotkit/react-core/v2";

export default function Home() {
  return (
    <main>
      <h1>我的 AI 应用</h1>
      <CopilotSidebar /> {/* 侧边栏 AI 助手 */}
    </main>
  );
}
```

### 2. 多 Agent 路由

```typescript
// app/api/copilotkit/route.ts
const runtime = new CopilotRuntime({
  agents: {
    default: new BuiltInAgent({ model: "openai:gpt-4o" }),
    coder: new BuiltInAgent({
      model: "anthropic:claude-3-5-sonnet",
      instructions: "你是一个专业的高级工程师，擅长代码审查和重构..."
    }),
    analyst: new BuiltInAgent({
      model: "openai:gpt-4o",
      instructions: "你是一个数据分析专家，擅长从数据中发现趋势和洞察..."
    }),
  },
});
```

### 3. 工具调用（自定义 Action）

```typescript
// 定义自定义工具
const tools = [
  {
    name: "getWeather",
    description: "获取指定城市的天气信息",
    parameters: {
      type: "object",
      properties: {
        city: { type: "string", description: "城市名称" },
      },
      required: ["city"],
    },
    handler: async ({ city }) => {
      const res = await fetch(`/api/weather?city=${city}`);
      return res.json();
    },
  },
];

const runtime = new CopilotRuntime({ agents: { default: builtInAgent }, tools });
```

## 🌐 支持的模型

| 提供商 | 模型 | 配置方式 |
|--------|------|---------|
| OpenAI | GPT-4o, GPT-4o-mini, GPT-4-turbo | `openai:gpt-4o` |
| Anthropic | Claude 3.5 Sonnet, Claude 3 Opus | `anthropic:claude-3-5-sonnet` |
| Google | Gemini Pro, Gemini Flash | `google:gemini-pro` |
| 本地模型 | Llama, Mistral 等 OpenAI-compatible | `openai-compatible:http://localhost:11434/v1` |

## 📁 项目结构

```
copilotkit-wrap/
├── README.md              # 本文件
├── demo/                  # 完整可运行 Demo
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── api/
│   │       └── copilotkit/
│   │           └── route.ts
│   ├── components/
│   │   ├── CopilotSidebar.tsx
│   │   └── WeatherWidget.tsx
│   ├── .env.local.example
│   ├── next.config.mjs
│   ├── package.json
│   └── tsconfig.json
└── docs/
    ├── DEPLOY.md          # 部署指南
    └── AGENTS.md          # 多 Agent 配置详解
```

## 🚢 部署

### Vercel（推荐）

```bash
npm i -g vercel
vercel --prod
```

环境变量：
```
OPENAI_API_KEY=sk-xxxxx
```

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 📄 许可证

基于 AG-UI 协议和 CopilotKit 开源协议，商用友好。

## 🔗 链接

- CopilotKit 官方：https://github.com/CopilotKit/CopilotKit
- AG-UI 协议：https://www.ag-ui.org/
- 官方文档：https://docs.copilotkit.ai/
