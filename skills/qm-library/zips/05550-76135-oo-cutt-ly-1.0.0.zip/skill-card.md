## Description: <br>
Cuttly (cutt.ly) helps an agent operate Cuttly through an OOMOL-connected account for URL shortening and link analytics. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to create Cuttly short URLs and retrieve click analytics through the oo CLI connector. The skill requires a connected Cuttly account and live schema inspection before action payloads are built. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Review before execution as proposals could introduce incorrect or misleading guidance into skills. <br>
Mitigation: Review and scan skill before deployment. <br>

## Reference(s): <br>
- [Cuttly homepage](https://cutt.ly) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [shorten_url action](actions/shorten_url.md) <br>
- [get_link_analytics action](actions/get_link_analytics.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs are oo CLI connector calls that return JSON data and metadata, including execution IDs.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
