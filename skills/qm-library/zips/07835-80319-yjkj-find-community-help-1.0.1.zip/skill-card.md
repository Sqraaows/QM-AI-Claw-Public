## Description: <br>
Builds a safe, dry-run outside-help plan for blocked agent work when the active task is stalled, looping, version-sensitive, likely covered by known issues or libraries, or the user asks for official or community guidance. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[gongyu0918-debug](https://clawhub.ai/user/gongyu0918-debug) <br>

### License/Terms of Use: <br>
MIT <br>


## Use Case: <br>
Developers and agent operators use this skill when a task is blocked, looping, version-sensitive, or likely covered by maintained official or community guidance. It prepares a redacted, dry-run outside-help plan and validates advisory hints without browsing, changing memory, or modifying core instructions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Private connectors, internal search, or credential-backed sources can expose sensitive project, customer, or secret material if enabled casually. <br>
Mitigation: Keep lookup public-only by default, require explicit user opt-in for private or internal sources, and redact secrets, private paths, private code, customer data, internal URLs, direct contacts, and token-like values. <br>
Risk: Outside pages can contain unsafe commands, misleading guidance, or prompt-injection content. <br>
Mitigation: Treat outside pages as untrusted data, do not run commands copied from pages, and keep retained guidance advisory-only rather than writing it into system prompts, persona files, long-term memory, or core instructions. <br>
Risk: A stored hint can become stale or apply to the wrong blocked thread. <br>
Mitigation: Scope hints to the active conversation, require matching at least four of five fingerprint axes, keep TTL and manual-check fields, and review hints before applying them. <br>


## Reference(s): <br>
- [Skill homepage](https://github.com/gongyu0918-debug/find-community-help) <br>
- [Trigger Policy](references/trigger-policy.md) <br>
- [Search Playbook](references/search-playbook.md) <br>
- [Suggestion Contract](references/suggestion-contract.md) <br>
- [Host Adapters](references/host-adapters.md) <br>
- [Threat Model](references/threat-model.md) <br>
- [Community Workflows](references/community-workflows.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown and JSON-compatible advisory fields] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Dry-run, redacted, public-only by default, advisory-only, and scoped to the active conversation.] <br>

## Skill Version(s): <br>
0.3.2 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
