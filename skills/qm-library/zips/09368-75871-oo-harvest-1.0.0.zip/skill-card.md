## Description: <br>
Harvest lets an agent read, create, update, and delete Harvest data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and teams who track time in Harvest use this skill to look up clients, projects, tasks, users, and time entries and to manage time-entry lifecycle actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, stop, restart, or delete Harvest time entries in a connected account. <br>
Mitigation: Confirm the exact payload, intended effect, and target with the user before write or delete actions. <br>
Risk: The skill requires access to a connected Harvest account through OOMOL-managed credentials. <br>
Mitigation: Install only when you intend to let OOMOL/Codex operate the connected Harvest account, and review write and delete requests carefully before approval. <br>


## Reference(s): <br>
- [Harvest homepage](https://www.getharvest.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action payloads; write and delete actions require explicit user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
