## Description: <br>
WhatsApp (whatsapp.com). Use this skill for WhatsApp requests that read, create, update, or delete data through a connected WhatsApp Business account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and business operators use this skill to operate a WhatsApp Business account through OOMOL, including sending messages, managing media, reviewing phone-number and profile details, and creating or deleting message templates. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send messages, upload media, create templates, or delete WhatsApp template variants through a connected WhatsApp Business account. <br>
Mitigation: Review the exact payload and intended effect before approving write actions, and require explicit approval for destructive template deletion. <br>
Risk: The skill requires sensitive account access through the OOMOL connection and oo CLI. <br>
Mitigation: Install and connect it only from trusted OOMOL sources, and use it only when the agent is intended to operate the associated WhatsApp Business account. <br>
Risk: Connector schemas and upstream WhatsApp fields can change over time. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-whatsapp) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [WhatsApp homepage](https://www.whatsapp.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL WhatsApp connection](https://console.oomol.com/app-connections?provider=whatsapp) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Runs OOMOL oo CLI connector actions and returns JSON responses from the connector when actions are executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
