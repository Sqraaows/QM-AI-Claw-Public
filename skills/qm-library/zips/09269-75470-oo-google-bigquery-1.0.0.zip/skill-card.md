## Description: <br>
Enables an agent to operate Google BigQuery through OOMOL's google_bigquery connector for reading, querying, creating, updating, deleting, importing, and exporting BigQuery resources. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, data engineers, and analytics teams use this skill to let an agent inspect BigQuery resources, run SQL, manage datasets, tables, routines, models, and jobs, and move data through Google Cloud Storage when the connected account permits it. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Write, delete, extract, load, insert, or job-cancel actions can change or remove BigQuery resources. <br>
Mitigation: Confirm the exact project, dataset, table, job ID, query, and payload with the user before running those actions. <br>
Risk: The skill depends on the oo CLI and an OOMOL-connected BigQuery account. <br>
Mitigation: Use a trusted oo CLI installation path and connect or refresh Google BigQuery credentials only when an auth or connection error requires it. <br>
Risk: Input schemas can change upstream, causing stale payloads to fail or affect unintended fields. <br>
Mitigation: Inspect the live connector schema before constructing payloads for each action. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-google-bigquery) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [Google BigQuery homepage](https://cloud.google.com/bigquery) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May return BigQuery query results, metadata, job status, or connector execution identifiers as JSON from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
