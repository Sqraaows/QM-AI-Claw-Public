#!/usr/bin/env python3
"""
第二代父母升级系统 v2.0 (Second Generation Parents Upgrade System)
==========================================

基于心理学深度分析的代际创伤修复与父母教育支持系统

核心模块:
1. GenerationalTraumaAnalyzer - 代际创伤分析器
2. ParentChildRepairEngine - 亲子关系修复引擎
3. EmotionalSupportSystem - 情感支持系统
4. ParentingReflectionModule - 父母自反射模块
5. FamilyDynamicsAnalyzer - 家庭动力学分析器

理论基础:
- Kübler-Ross 五阶段模型（悲伤、愤怒、讨价还价、抑郁、接受）
- Frankl 意义治疗（寻找生命意义）
- Rogers 人本主义（无条件积极关注）
- Yalom 存在主义疗法（关系、意义）
- Watzlawick 沟通理论（互动模式）
- 代际创伤传递理论（Patricia K. Kuhl）

版本: v2.0.0
日期: 2026-05-22
"""

import json
import time
import math
import re
import os
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum
from datetime import datetime, timedelta
import hashlib


# =============================================================================
# 第一部分: 核心数据结构和枚举
# =============================================================================

class TraumaLevel(Enum):
    """代际创伤严重程度"""
    HEALTHY = "healthy"           # 健康
    MILD = "mild"               # 轻度
    MODERATE = "moderate"        # 中度
    SEVERE = "severe"           # 重度
    CRITICAL = "critical"        # 极重


class AttachmentStyle(Enum):
    """依恋类型（基于Bowlby理论）"""
    SECURE = "secure"            # 安全型
    ANXIOUS = "anxious"         # 焦虑型
    AVOIDANT = "avoidant"       # 回避型
    DISORGANIZED = "disorganized" # 混乱型


class EmotionCategory(Enum):
    """情感类别"""
    JOY = "joy"                 # 喜悦
    SADNESS = "sadness"         # 悲伤
    ANGER = "anger"             # 愤怒
    FEAR = "fear"               # 恐惧
    SURPRISE = "surprise"       # 惊讶
    DISGUST = "disgust"         # 厌恶
    TRUST = "trust"             # 信任
    ANTICIPATION = "anticipation" # 期待


class RepairStage(Enum):
    """修复阶段（基于Kübler-Ross扩展）"""
    DENIAL = "denial"           # 否认
    ANGER = "anger"             # 愤怒
    BARGAINING = "bargaining"   # 讨价还价
    GRIEF = "grief"             # 悲伤
    DEPRESSION = "depression"   # 抑郁
    ACCEPTANCE = "acceptance"   # 接受
    INTEGRATION = "integration"  # 整合
    GROWTH = "growth"           # 成长


class CommunicationPattern(Enum):
    """沟通模式（基于Watzlawick）"""
    SYMMETRICAL = "symmetrical"    # 对称型（平等但可能竞争）
    COMPLEMENTARY = "complementary" # 互补型（一方支配一方服从）
    METACOMMENTARY = "metacommentary" # 元沟通（关于沟通的沟通）


@dataclass
class GenerationInfo:
    """世代信息"""
    generation_id: int                    # 第几代（1=祖辈，2=父母，3=孩子）
    label: str                           # 标签（如"60后父母"）
    core_wound: str                      # 核心创伤
    survival_strategy: str                 # 生存策略
    love_language: str                   # 爱的语言（主要表达方式）
    wound_transmission_mode: str          # 创伤如何传递给下一代
    growth_edge: str                     # 成长突破口


@dataclass
class FamilyPattern:
    """家庭模式"""
    pattern_type: str                    # 模式类型
    description: str                     # 描述
    generations: List[int]              # 涉及的世代
    manifestation: str                   # 具体表现
    root_cause: str                      # 根源
    intervention_point: str             # 干预点


@dataclass
class EmotionalSignal:
    """情感信号"""
    signal_type: str                     # 信号类型
    intensity: float                     # 强度 0-1
    surface_emotion: str                 # 表面情感
    deep_emotion: str                   # 深层情感
    underlying_need: str                  # 潜在需求
    contextual_hint: str                  # 情境提示
    actionable_suggestion: str           # 可操作建议


@dataclass
class ParentProfile:
    """父母画像"""
    parent_id: str
    generation: int                      # 世代
    attachment_style: AttachmentStyle     # 依恋类型
    trauma_level: TraumaLevel            # 创伤程度
    primary_wound: str                   # 主要创伤
    secondary_wounds: List[str]          # 次要创伤
    survival_patterns: List[str]         # 生存模式
    unfulfilled_needs: List[str]         # 未满足需求
    growth_areas: List[str]              # 成长领域
    protective_factors: List[str]        # 保护因素
    risk_factors: List[str]              # 风险因素
    readiness_for_change: float          # 改变准备度 0-1
    emotional_capacity: float           # 情感容量 0-1


@dataclass
class ChildProfile:
    """孩子画像"""
    child_id: str
    age_group: str                       # 年龄段
    attachment_style: AttachmentStyle     # 依恋类型
    current_challenges: List[str]        # 当前挑战
    emotional_triggers: List[str]         # 情感触发点
    unmet_needs: List[str]               # 未满足需求
    strengths: List[str]                 # 优势
    growth_potential: float               # 成长潜力 0-1
    resilience_factors: List[str]        # 韧性因素


@dataclass
class RelationshipMetrics:
    """关系指标"""
    connection_quality: float            # 连接质量 0-1
    communication_health: float         # 沟通健康度 0-1
    boundary_clarity: float             # 边界清晰度 0-1
    conflict_resolution: float          # 冲突解决能力 0-1
    emotional_attunement: float          # 情感协调度 0-1
    trust_level: float                  # 信任水平 0-1
    overall_health: float              # 整体健康度 0-1


# =============================================================================
# 第二部分: 代际创伤分析器 (GenerationalTraumaAnalyzer)
# =============================================================================

class GenerationalTraumaAnalyzer:
    """
    代际创伤分析器

    功能：
    - 分析三代之间的创伤传递模式
    - 识别家庭中的核心创伤
    - 追踪创伤如何在不同世代间传递
    - 提供干预建议

    理论基础：
    - Patricia K. Kuhl 代际创伤研究
    - Mark Epstein 创伤与依恋
    - Bessel van der Kolk 身体记录创伤
    """

    def __init__(self):
        self.generations: Dict[int, GenerationInfo] = {}
        self.family_patterns: List[FamilyPattern] = []
        self.transmission_chains: List[Dict[str, Any]] = []
        self._initialize_default_generations()

    def _initialize_default_generations(self) -> None:
        """初始化默认的世代信息"""
        # 第一代：祖辈（物质匮乏时代）
        self.generations[1] = GenerationInfo(
            generation_id=1,
            label="祖辈（物质匮乏一代）",
            core_wound="生存焦虑与匮乏感",
            survival_strategy="勤俭节约、物质积累、压抑情感表达",
            love_language="行动（做事）而非语言",
            wound_transmission_mode="通过过度保护和控制传递给下一代",
            growth_edge="重新理解物质与情感的关系"
        )

        # 第二代：父母（过度补偿一代）
        self.generations[2] = GenerationInfo(
            generation_id=2,
            label="第二代父母（补偿型父母）",
            core_wound="自己的情感需求未被满足",
            survival_strategy="过度补偿（给孩子物质）、情感隔离",
            love_language="物质提供而非情感陪伴",
            wound_transmission_mode="""
            1. 物质过剩 + 情感空洞
            2. "我小时候缺，你要什么我给什么"
            3. 把自己未完成的期望投射到孩子身上
            4. 不会情感教导，只能物质满足
            """,
            growth_edge="学会情感识别和表达"
        )

        # 第三代：孩子（承受压力一代）
        self.generations[3] = GenerationInfo(
            generation_id=3,
            label="第三代（压力承受者）",
            core_wound="被降格为数据点，失去真正的关注",
            survival_strategy="要么顺从（成绩导向）要么反叛",
            love_language="被看见、被理解、被接纳",
            wound_transmission_mode="需要打破'比较'循环，建立真正的自我认同",
            growth_edge="发展真实的自我认同，不被父母的期望定义"
        )

    def analyze_three_generation_trauma(self,
                                       gen1_issues: List[str],
                                       gen2_issues: List[str],
                                       gen3_issues: List[str]) -> Dict[str, Any]:
        """
        分析三代创伤模式

        Args:
            gen1_issues: 第一代（祖辈）的主要问题
            gen2_issues: 第二代（父母）的主要问题
            gen3_issues: 第三代（孩子）的主要问题

        Returns:
            完整的创伤分析报告
        """
        report = {
            "timestamp": time.time(),
            "generation_1_analysis": self._analyze_generation(1, gen1_issues),
            "generation_2_analysis": self._analyze_generation(2, gen2_issues),
            "generation_3_analysis": self._analyze_generation(3, gen3_issues),
            "transmission_pattern": self._identify_transmission_pattern(
                gen1_issues, gen2_issues, gen3_issues
            ),
            "core_family_wound": self._identify_core_wound(
                gen1_issues, gen2_issues, gen3_issues
            ),
            "intervention_recommendations": self._generate_interventions(
                gen1_issues, gen2_issues, gen3_issues
            ),
            "family_patterns": self._identify_family_patterns(
                gen1_issues, gen2_issues, gen3_issues
            )
        }
        return report

    def _analyze_generation(self, gen_num: int,
                           issues: List[str]) -> Dict[str, Any]:
        """分析单个世代的问题"""
        gen_info = self.generations.get(gen_num)
        if not gen_info:
            return {"error": f"未知世代: {gen_num}"}

        # 问题分类
        categorized_issues = self._categorize_issues(issues)

        # 创伤传递分析
        transmission = self._analyze_wound_transmission(gen_num, issues)

        return {
            "generation": gen_num,
            "label": gen_info.label,
            "core_wound": gen_info.core_wound,
            "survival_strategy": gen_info.survival_strategy,
            "identified_issues": issues,
            "issue_categories": categorized_issues,
            "transmission_analysis": transmission,
            "growth_edge": gen_info.growth_edge
        }

    def _categorize_issues(self, issues: List[str]) -> Dict[str, List[str]]:
        """将问题分类"""
        categories = {
            "物质匮乏": [],
            "情感忽视": [],
            "过高期望": [],
            "边界模糊": [],
            "沟通障碍": [],
            "身份认同": [],
            "关系冲突": []
        }

        for issue in issues:
            issue_lower = issue.lower()
            if any(kw in issue_lower for kw in ["缺", "不够", "匮乏", "穷"]):
                categories["物质匮乏"].append(issue)
            if any(kw in issue_lower for kw in ["忽视", "不理", "冷漠", "不在乎"]):
                categories["情感忽视"].append(issue)
            if any(kw in issue_lower for kw in ["期望", "必须", "要求", "成绩"]):
                categories["过高期望"].append(issue)
            if any(kw in issue_lower for kw in ["控制", "管", "入侵", "没有空间"]):
                categories["边界模糊"].append(issue)
            if any(kw in issue_lower for kw in ["说", "沟通", "吵架", "冷战"]):
                categories["沟通障碍"].append(issue)
            if any(kw in issue_lower for kw in ["我是谁", "不知道", "迷茫", "没有方向"]):
                categories["身份认同"].append(issue)
            if any(kw in issue_lower for kw in ["关系", "矛盾", "冲突", "和解"]):
                categories["关系冲突"].append(issue)

        return {k: v for k, v in categories.items() if v}

    def _analyze_wound_transmission(self, gen_num: int,
                                   issues: List[str]) -> Dict[str, Any]:
        """分析创伤传递机制"""
        gen_info = self.generations.get(gen_num, None)

        return {
            "transmission_mode": gen_info.wound_transmission_mode if gen_info else "未知",
            "defense_mechanism": self._identify_defense_mechanism(issues),
            "intergenerational_pattern": self._find_intergenerational_links(issues)
        }

    def _identify_defense_mechanism(self, issues: List[str]) -> List[str]:
        """识别防御机制"""
        mechanisms = []
        issue_text = " ".join(issues).lower()

        if any(kw in issue_text for kw in ["为了你好", "应该", "必须"]):
            mechanisms.append("合理化（Rationalization）")
        if any(kw in issue_text for kw in ["你怎么", "他怎么", "像你爸"]):
            mechanisms.append("投射（Projection）")
        if any(kw in issue_text for kw in ["对", "向", "冲着"]):
            mechanisms.append("转移（Displacement）")
        if any(kw in issue_text for kw in ["算了", "不说", "憋着"]):
            mechanisms.append("压抑（Suppression）")
        if any(kw in issue_text for kw in ["过度", "太", "非常"]):
            mechanisms.append("反向形成（Reaction Formation）")

        return mechanisms

    def _find_intergenerational_links(self, issues: List[str]) -> List[str]:
        """寻找代际联系"""
        links = []
        for issue in issues:
            if any(kw in issue for kw in ["我爸", "我妈", "我小时候", "像"]):
                links.append(f"发现代际参照: {issue}")
        return links

    def _identify_transmission_pattern(self,
                                     gen1: List[str],
                                     gen2: List[str],
                                     gen3: List[str]) -> Dict[str, Any]:
        """识别三代创伤传递模式"""
        patterns = []

        # 模式1: 匮乏-补偿-过载
        if self._has_pattern(gen1, ["缺", "匮乏"]) and \
           self._has_pattern(gen2, ["给", "满足", "过度"]):
            patterns.append({
                "name": "匮乏-补偿传递",
                "description": "祖辈的匮乏感导致父母辈的过度补偿，进而造成孩子辈的物质/情感过载",
                "formula": "祖辈匮乏 → 父母补偿 → 孩子过载",
                "example": "父母说'我小时候缺什么，现在都给你'，孩子却感到'我不需要这些，我需要的是你看见我'"
            })

        # 模式2: 情感隔离传递
        if self._has_pattern(gen1, ["不表达", "压抑", "冷漠"]) and \
           self._has_pattern(gen2, ["不会", "不懂", "不知道怎么"]):
            patterns.append({
                "name": "情感隔离传递",
                "description": "祖辈的情感压抑模式传递给父母，父母也想爱但不知道怎么表达",
                "formula": "祖辈压抑 → 父母也想爱但不会 → 孩子情感空洞",
                "example": "父母内心知道应该情感陪伴，但自己小时候没被这样对待，不知道怎么做"
            })

        # 模式3: 投射传递
        if self._has_pattern(gen2, ["完成", "期望", "实现"]):
            patterns.append({
                "name": "期望投射传递",
                "description": "父母把自己未完成的人生期望投射到孩子身上",
                "formula": "父母未完成 → 投射给孩子 → 孩子失去自我",
                "example": "'我当年没考上好大学，所以你必须考上'——把孩子变成完成父母梦想的工具"
            })

        # 模式4: 比较传递
        if self._has_pattern(gen3, ["成绩", "比较", "别人"]):
            patterns.append({
                "name": "社会比较传递",
                "description": "社会评价焦虑通过父母传递给孩子",
                "formula": "社会压力 → 父母焦虑 → 孩子被比较",
                "example": "父母查看成绩排名、比较孩子与同龄人——孩子被降格为数据点"
            })

        return {
            "identified_patterns": patterns,
            "pattern_count": len(patterns),
            "most_dominant": patterns[0]["name"] if patterns else None
        }

    def _has_pattern(self, issues: List[str], keywords: List[str]) -> bool:
        """检查问题列表中是否包含特定关键词"""
        text = " ".join(issues).lower()
        return any(kw in text for kw in keywords)

    def _identify_core_wound(self,
                            gen1: List[str],
                            gen2: List[str],
                            gen3: List[str]) -> Dict[str, Any]:
        """识别核心家庭创伤"""
        all_issues = gen1 + gen2 + gen3

        wound_counts = {
            "情感忽视": sum(1 for i in all_issues if "忽视" in i or "冷漠" in i),
            "过高期望": sum(1 for i in all_issues if "期望" in i or "必须" in i),
            "边界模糊": sum(1 for i in all_issues if "控制" in i or "管" in i),
            "比较压力": sum(1 for i in all_issues if "比较" in i or "成绩" in i),
            "沟通障碍": sum(1 for i in all_issues if "沟通" in i or "说" in i),
        }

        sorted_wounds = sorted(wound_counts.items(), key=lambda x: x[1], reverse=True)
        primary_wound = sorted_wounds[0][0] if sorted_wounds else "未知"

        return {
            "primary_wound": primary_wound,
            "wound_hierarchy": sorted_wounds,
            "explanation": self._get_wound_explanation(primary_wound),
            "integrated_view": self._create_integrated_view(gen1, gen2, gen3)
        }

    def _get_wound_explanation(self, wound_type: str) -> str:
        """获取创伤类型的解释"""
        explanations = {
            "情感忽视": "情感忽视是所有创伤中最隐蔽的一种。它不像身体虐待那样有明显痕迹，但对一个人的自我价值感和关系能力造成深远影响。被情感忽视的人往往学会压抑自己的情感需求，长大后可能成为情感疏离的父母。",
            "过高期望": "过高的期望实际上是一种隐蔽的情感虐待。它向孩子传递的信息是'现在的你不值得被爱，只有你达成目标才值得'。这导致孩子形成'条件性自尊'。",
            "边界模糊": "边界模糊的家庭中，父母把孩子当作自己的延伸，而不是独立的个体。这导致孩子无法发展健康的自我认同，总是为别人的期望而活。",
            "比较压力": "比较传递的信息是'你不够好，落后于别人'。这严重损害孩子的内在动机和自我效能感，使他们依赖于外部评价而不是内在满足。",
            "沟通障碍": "沟通障碍导致家庭成员之间无法建立真实的情感连接。每个人都有话不说或者说了不被听见，长期积累形成情感隔阂。"
        }
        return explanations.get(wound_type, "未知的创伤类型")

    def _create_integrated_view(self, gen1: List[str], gen2: List[str], gen3: List[str]) -> str:
        """创建三代创伤的整合视图"""
        view = f"""
        【三代创伤整合视图】

        第一层：祖辈的创伤
        - 核心：{self._summarize_issues(gen1)}
        - 影响：创造了一个压抑、匮乏的家庭氛围

        第二层：父母的创伤
        - 核心：{self._summarize_issues(gen2)}
        - 面对第一代创伤的应对方式：顺从、逃避或过度补偿

        第三层：孩子的创伤
        - 核心：{self._summarize_issues(gen3)}
        - 承受来自两代人的期望和压力

        【关键洞察】
        - 没有人是"坏人"，每个人都是创伤的受害者和传递者
        - 改变的可能在于：识别模式 → 理解根源 → 有意识的干预
        - 治疗的关键是打破无意识的代际传递
        """
        return view

    def _summarize_issues(self, issues: List[str]) -> str:
        """总结问题列表的核心"""
        if not issues:
            return "无明显问题"
        return "；".join(issues[:3])

    def _generate_interventions(self,
                              gen1: List[str],
                              gen2: List[str],
                              gen3: List[str]) -> List[Dict[str, Any]]:
        """生成干预建议"""
        interventions = []

        # 基于问题生成针对性干预
        all_issues = gen1 + gen2 + gen3

        if any("比较" in i for i in all_issues):
            interventions.append({
                "target": "父母",
                "focus": "停止比较行为",
                "action": "每次想要比较时，先暂停，问自己：'我此刻担心什么？我真正想帮助孩子的是什么？'",
                "rationale": "比较只会强化孩子的条件性自尊，而非真实的自我价值感",
                "expected_outcome": "孩子开始发展内在动机和自我认可"
            })

        if any("控制" in i or "管" in i for i in all_issues):
            interventions.append({
                "target": "父母",
                "focus": "建立边界",
                "action": "区分'孩子的事'和'我们共同的事'，练习对孩子说'这是你的决定'",
                "rationale": "边界清晰的家庭，孩子更有安全感和自主性",
                "expected_outcome": "孩子发展出健康的自主性和责任感"
            })

        if any("不会" in i or "不懂" in i or "不知道怎么" in i for i in gen2):
            interventions.append({
                "target": "父母",
                "focus": "情感能力培养",
                "action": "每天花5分钟询问孩子'今天心情怎么样'，并真正倾听而不是给建议",
                "rationale": "情感能力可以后天习得，关键是有意识的练习",
                "expected_outcome": "亲子间开始建立情感连接"
            })

        if any("成绩" in i or "期望" in i for i in all_issues):
            interventions.append({
                "target": "父母",
                "focus": "重新定义成功",
                "action": "列出10个除了成绩以外，孩子让你骄傲的地方",
                "rationale": "多元的成功定义帮助孩子建立全面的自我价值感",
                "expected_outcome": "孩子的焦虑降低，真实能力更强"
            })

        return interventions

    def _identify_family_patterns(self,
                                gen1: List[str],
                                gen2: List[str],
                                gen3: List[str]) -> List[Dict[str, Any]]:
        """识别家庭模式"""
        patterns = []

        # 悲哀三层结构
        patterns.append({
            "name": "悲哀的三层结构",
            "layer_1": {
                "who": "孩子",
                "pain": "被降格为数据点，没有人在看我这个人",
                "manifestation": "孩子感到被忽视、被评判、失去真正的关注"
            },
            "layer_2": {
                "who": "父母",
                "pain": "只能看见比较，看不见现在；只能评判对错，不会帮助成长",
                "manifestation": "父母拿出手机查看成绩排名的那一刻，已经不知道怎么当父母了"
            },
            "layer_3": {
                "who": "社会",
                "pain": "系统让查看历史成绩变得容易",
                "manifestation": "学校、App、数据系统，都在帮父母做'比较'这件事"
            }
        })

        # 真爱 vs 投射模式
        patterns.append({
            "name": "真爱 vs 投射",
            "true_love": {
                "definition": "看见孩子是谁，给他需要的",
                "parent_behavior": "关注孩子的独特性，满足他真实的需求"
            },
            "projection": {
                "definition": "看见孩子能完成我什么，给我想给的",
                "parent_behavior": "关注自己的期望，满足自己想给的东西"
            }
        })

        # 三代创伤传递模式
        patterns.append({
            "name": "三代创伤传递",
            "generation_1": {
                "label": "祖辈",
                "wound": "匮乏 → 压抑情感",
                "strategy": "孩子自然生长"
            },
            "generation_2": {
                "label": "父母辈",
                "wound": "自己的匮乏 → 过度补偿物质 + 不会情感教导",
                "strategy": "物质过剩 + 情感空洞"
            },
            "generation_3": {
                "label": "孩子辈",
                "wound": "物质过剩 + 情感空洞 + 压力",
                "strategy": "可能发展为抑郁或反叛"
            }
        })

        return patterns

    def assess_trauma_level(self, issues: List[str]) -> TraumaLevel:
        """评估创伤严重程度"""
        if not issues:
            return TraumaLevel.HEALTHY

        severity_score = 0

        for issue in issues:
            issue_lower = issue.lower()
            if any(kw in issue_lower for kw in ["虐待", "暴力", "抛弃", "严重"]):
                severity_score += 3
            if any(kw in issue_lower for kw in ["经常", "总是", "过度", "长期"]):
                severity_score += 2
            if any(kw in issue_lower for kw in ["有时", "偶尔"]):
                severity_score += 1

        if severity_score >= 8:
            return TraumaLevel.CRITICAL
        elif severity_score >= 5:
            return TraumaLevel.SEVERE
        elif severity_score >= 3:
            return TraumaLevel.MODERATE
        elif severity_score >= 1:
            return TraumaLevel.MILD
        else:
            return TraumaLevel.HEALTHY

    def generate_wheel_of_insight(self, analysis: Dict[str, Any]) -> str:
        """生成洞察轮图（用于可视化）"""
        core_wound = analysis.get("core_family_wound", {}).get("primary_wound", "待确定")
        transmission = analysis.get("transmission_pattern", {}).get("most_dominant", "待确定")

        wheel = f"""
        ┌─────────────────────────────────────────────────────┐
        │              代际创伤洞察轮                          │
        ├─────────────────────────────────────────────────────┤
        │                                                     │
        │     【第一层：识别】                                │
        │     核心创伤: {core_wound:<20}                    │
        │                                                     │
        │     【第二层：理解】                                │
        │     传递模式: {transmission:<20}                   │
        │                                                     │
        │     【第三层：干预】                                │
        │     介入点: 关注当下，而非比较                       │
        │                                                     │
        │     【第四层：成长】                                │
        │     成长方向: 发展真实的自我认同                    │
        │                                                     │
        └─────────────────────────────────────────────────────┘
        """
        return wheel


# =============================================================================
# 第三部分: 亲子关系修复引擎 (ParentChildRepairEngine)
# =============================================================================

class ParentChildRepairEngine:
    """
    亲子关系修复引擎

    基于Yalom的存在主义疗法和Rogers的人本主义疗法

    核心功能：
    - 评估当前亲子关系状态
    - 制定修复路径
    - 提供具体的修复步骤
    - 追踪修复进展

    修复阶段（基于Kübler-Ross扩展模型）：
    1. 否认 → 2. 愤怒 → 3. 讨价还价 → 4. 悲伤 → 5. 抑郁 →
    6. 接受 → 7. 整合 → 8. 成长
    """

    def __init__(self):
        self.repair_sessions: List[Dict[str, Any]] = []
        self.current_stage: RepairStage = RepairStage.DENIAL
        self.stage_transitions: List[Dict[str, Any]] = []

    def assess_relationship(self,
                          parent_signals: List[EmotionalSignal],
                          child_signals: List[EmotionalSignal],
                          communication_patterns: List[str]) -> RelationshipMetrics:
        """
        评估亲子关系状态

        Args:
            parent_signals: 父母的情感信号
            child_signals: 孩子的情感信号
            communication_patterns: 沟通模式列表

        Returns:
            关系指标
        """
        connection_quality = self._calculate_connection(parent_signals, child_signals)
        communication_health = self._assess_communication(communication_patterns)
        boundary_clarity = self._assess_boundaries(parent_signals, child_signals)
        conflict_resolution = self._assess_conflict_resolution(communication_patterns)
        emotional_attunement = self._calculate_attunement(parent_signals, child_signals)
        trust_level = self._calculate_trust(parent_signals, child_signals)

        overall = (
            connection_quality * 0.2 +
            communication_health * 0.2 +
            boundary_clarity * 0.15 +
            conflict_resolution * 0.15 +
            emotional_attunement * 0.15 +
            trust_level * 0.15
        )

        return RelationshipMetrics(
            connection_quality=connection_quality,
            communication_health=communication_health,
            boundary_clarity=boundary_clarity,
            conflict_resolution=conflict_resolution,
            emotional_attunement=emotional_attunement,
            trust_level=trust_level,
            overall_health=overall
        )

    def _calculate_connection(self,
                             parent_signals: List[EmotionalSignal],
                             child_signals: List[EmotionalSignal]) -> float:
        """计算情感连接质量"""
        if not parent_signals or not child_signals:
            return 0.3

        resonance_count = 0
        for ps in parent_signals:
            for cs in child_signals:
                if ps.surface_emotion == cs.surface_emotion or \
                   ps.deep_emotion == cs.deep_emotion:
                    resonance_count += 1

        base_score = min(resonance_count / max(len(parent_signals), 1), 1.0)
        return base_score

    def _assess_communication(self, patterns: List[str]) -> float:
        """评估沟通健康度"""
        if not patterns:
            return 0.3

        health_score = 0.5

        for pattern in patterns:
            pattern_lower = pattern.lower()
            if any(kw in pattern_lower for kw in ["倾听", "理解", "尊重", "表达感受"]):
                health_score += 0.15
            if any(kw in pattern_lower for kw in ["指责", "忽视", "冷漠", "控制"]):
                health_score -= 0.2

        return max(0.0, min(1.0, health_score))

    def _assess_boundaries(self,
                          parent_signals: List[EmotionalSignal],
                          child_signals: List[EmotionalSignal]) -> float:
        """评估边界清晰度"""
        boundary_violations = 0
        for signal in parent_signals:
            if "控制" in signal.surface_emotion or "入侵" in signal.contextual_hint:
                boundary_violations += 1

        for signal in child_signals:
            if "空间" in signal.contextual_hint or "没有自由" in signal.contextual_hint:
                boundary_violations += 1

        return max(0.0, 1.0 - (boundary_violations * 0.2))

    def _assess_conflict_resolution(self, patterns: List[str]) -> float:
        """评估冲突解决能力"""
        healthy_patterns = 0
        unhealthy_patterns = 0

        for pattern in patterns:
            pattern_lower = pattern.lower()
            if any(kw in pattern_lower for kw in ["协商", "妥协", "理解", "道歉"]):
                healthy_patterns += 1
            if any(kw in pattern_lower for kw in ["冷战", "热吵", "威胁", "惩罚"]):
                unhealthy_patterns += 1

        total = healthy_patterns + unhealthy_patterns
        if total == 0:
            return 0.5

        return healthy_patterns / total

    def _calculate_attunement(self,
                             parent_signals: List[EmotionalSignal],
                             child_signals: List[EmotionalSignal]) -> float:
        """计算情感协调度"""
        if not parent_signals or not child_signals:
            return 0.3

        attuned_count = 0
        for cs in child_signals:
            for ps in parent_signals:
                if cs.deep_emotion in ps.surface_emotion or \
                   cs.underlying_need in ps.actionable_suggestion:
                    attuned_count += 1
                    break

        return attuned_count / max(len(child_signals), 1)

    def _calculate_trust(self,
                        parent_signals: List[EmotionalSignal],
                        child_signals: List[EmotionalSignal]) -> float:
        """计算信任水平"""
        trust_indicators = 0
        distrust_indicators = 0

        for signal in child_signals:
            if "安全" in signal.underlying_need or "依靠" in signal.underlying_need:
                trust_indicators += 1
            if "害怕" in signal.surface_emotion or "不信任" in signal.surface_emotion:
                distrust_indicators += 1

        for signal in parent_signals:
            if "保护" in signal.actionable_suggestion or "支持" in signal.actionable_suggestion:
                trust_indicators += 1

        total = trust_indicators + distrust_indicators
        if total == 0:
            return 0.5

        return trust_indicators / total

    def generate_repair_plan(self,
                           metrics: RelationshipMetrics,
                           current_stage: RepairStage) -> Dict[str, Any]:
        """
        生成修复计划

        Args:
            metrics: 关系指标
            current_stage: 当前修复阶段

        Returns:
            修复计划
        """
        plan = {
            "current_stage": current_stage.value,
            "stage_description": self._get_stage_description(current_stage),
            "focus_areas": self._identify_focus_areas(metrics),
            "action_steps": [],
            "expected_progress": {},
            "warnings": []
        }

        if metrics.connection_quality < 0.5:
            plan["action_steps"].extend([
                {
                    "step": 1,
                    "action": "每天安排15分钟专属陪伴时间",
                    "description": "这段时间内完全专注于孩子，不看手机，不评判",
                    "rationale": "高质量的陪伴是建立连接的基础"
                },
                {
                    "step": 2,
                    "action": "练习'反映式倾听'",
                    "description": "重复孩子说的话，并尝试说出他的感受",
                    "example": "孩子说'我不想上学'，回应'听起来你感到很累/害怕/无助'"
                }
            ])

        if metrics.communication_health < 0.5:
            plan["action_steps"].extend([
                {
                    "step": 1,
                    "action": "建立'情感对话'时间",
                    "description": "每天晚餐或睡前，问孩子'今天有什么事让你开心/难过/担心？'",
                    "rationale": "定期的情感对话培养安全的情感表达环境"
                },
                {
                    "step": 2,
                    "action": "区分'我'信息和'你'信息",
                    "description": "用'我感到...因为...'代替'你总是...'"
                }
            ])

        if metrics.boundary_clarity < 0.5:
            plan["action_steps"].extend([
                {
                    "step": 1,
                    "action": "明确区分'孩子的事'和'父母的事'",
                    "description": "列出孩子可以自己做决定的事情清单",
                    "examples": ["穿什么衣服", "如何安排作业时间", "和谁交朋友"]
                },
                {
                    "step": 2,
                    "action": "练习说'这是你的决定'",
                    "description": "即使不同意，也先尊重孩子的选择"
                }
            ])

        if metrics.trust_level < 0.5:
            plan["action_steps"].extend([
                {
                    "step": 1,
                    "action": "兑现承诺",
                    "description": "对孩子做的每一个小承诺都要兑现",
                    "rationale": "信任是通过无数个小承诺积累起来的"
                },
                {
                    "step": 2,
                    "action": "承认错误并道歉",
                    "description": "当父母犯错时，主动承认并道歉",
                    "example": "'我错怪你了，对不起'"
                }
            ])

        plan["stage_guidance"] = self._get_stage_guidance(current_stage)

        return plan

    def _get_stage_description(self, stage: RepairStage) -> str:
        """获取阶段描述"""
        descriptions = {
            RepairStage.DENIAL: "否认阶段：尚未意识到问题的存在，或者认为'没什么大不了的'",
            RepairStage.ANGER: "愤怒阶段：意识到问题后感到愤怒，可能指向自己、配偶或孩子",
            RepairStage.BARGAINING: "讨价还价阶段：试图找到快速的解决办法，或者为自己辩护",
            RepairStage.GRIEF: "悲伤阶段：真正面对失去（失去理想的亲子关系、失去对孩子的控制等）",
            RepairStage.DEPRESSION: "抑郁阶段：感到深深的悲伤和无力，可能怀疑改变是否可能",
            RepairStage.ACCEPTANCE: "接受阶段：接受过去已经发生，接受自己曾经犯错，接受孩子是独立的个体",
            RepairStage.INTEGRATION: "整合阶段：将过去整合进现在，不再被过去束缚",
            RepairStage.GROWTH: "成长阶段：从创伤中成长，发展出更健康的亲子关系模式"
        }
        return descriptions.get(stage, "未知阶段")

    def _identify_focus_areas(self, metrics: RelationshipMetrics) -> List[Dict[str, Any]]:
        """识别需要重点关注的领域"""
        areas = []

        if metrics.connection_quality < 0.5:
            areas.append({
                "area": "情感连接",
                "priority": "高",
                "current_score": metrics.connection_quality,
                "why": "情感连接是亲子关系的基石，连接不足时，其他干预都难以生效"
            })

        if metrics.communication_health < 0.5:
            areas.append({
                "area": "沟通模式",
                "priority": "高",
                "current_score": metrics.communication_health,
                "why": "不健康的沟通模式会持续损害关系"
            })

        if metrics.boundary_clarity < 0.5:
            areas.append({
                "area": "边界",
                "priority": "中",
                "current_score": metrics.boundary_clarity,
                "why": "边界模糊会导致孩子无法发展独立的自我"
            })

        if metrics.trust_level < 0.5:
            areas.append({
                "area": "信任",
                "priority": "高",
                "current_score": metrics.trust_level,
                "why": "信任是安全依恋关系的基础"
            })

        return areas

    def _get_stage_guidance(self, stage: RepairStage) -> Dict[str, str]:
        """获取阶段指导"""
        guidance = {
            RepairStage.DENIAL: {
                "what_to_do": "开始观察和记录亲子互动中的问题模式",
                "what_to_avoid": "急于批评或改变",
                "key_question": "我有没有在逃避什么？"
            },
            RepairStage.ANGER: {
                "what_to_do": "允许自己感受愤怒，但不要在愤怒时做重要决定",
                "what_to_avoid": "向孩子发泄愤怒",
                "key_question": "我真正愤怒的是什么？"
            },
            RepairStage.BARGAINING: {
                "what_to_do": "识别快速修复的诱惑，理解真正的改变需要时间",
                "what_to_avoid": "期望孩子立刻改变作为自己改变的交换",
                "key_question": "我是在真的改变还是在表演改变？"
            },
            RepairStage.GRIEF: {
                "what_to_do": "允许自己悲伤，这是疗愈的必要过程",
                "what_to_avoid": "用工作或其他事情逃避悲伤",
                "key_question": "我在哀悼什么？"
            },
            RepairStage.DEPRESSION: {
                "what_to_do": "保持基本照顾，必要时寻求专业帮助",
                "what_to_avoid": "孤立自己或用不健康的方式麻痹自己",
                "key_question": "我需要什么支持？"
            },
            RepairStage.ACCEPTANCE: {
                "what_to_do": "开始有意识地选择新的反应方式",
                "what_to_avoid": "沉溺于内疚或后悔",
                "key_question": "我现在能做什么不同？"
            },
            RepairStage.INTEGRATION: {
                "what_to_do": "将洞察转化为日常实践",
                "what_to_avoid": "沉溺于内疚或后悔",
                "key_question": "我可以如何帮助其他父母？"
            },
            RepairStage.GROWTH: {
                "what_to_do": "庆祝进步，培养内在满足感",
                "what_to_avoid": "回到旧模式",
                "key_question": "我想成为什么样的父母？"
            }
        }
        return guidance.get(stage, {})

    def transition_stage(self, from_stage: RepairStage, to_stage: RepairStage) -> bool:
        """
        记录阶段转换

        Args:
            from_stage: 当前阶段
            to_stage: 目标阶段

        Returns:
            是否成功转换
        """
        valid_transitions = {
            RepairStage.DENIAL: [RepairStage.ANGER, RepairStage.BARGAINING],
            RepairStage.ANGER: [RepairStage.BARGAINING, RepairStage.GRIEF],
            RepairStage.BARGAINING: [RepairStage.GRIEF, RepairStage.ACCEPTANCE],
            RepairStage.GRIEF: [RepairStage.DEPRESSION, RepairStage.ACCEPTANCE],
            RepairStage.DEPRESSION: [RepairStage.ACCEPTANCE],
            RepairStage.ACCEPTANCE: [RepairStage.INTEGRATION],
            RepairStage.INTEGRATION: [RepairStage.GROWTH],
            RepairStage.GROWTH: []
        }

        if to_stage in valid_transitions.get(from_stage, []):
            self.stage_transitions.append({
                "from": from_stage.value,
                "to": to_stage.value,
                "timestamp": time.time()
            })
            self.current_stage = to_stage
            return True
        return False


# =============================================================================
# 第四部分: 情感支持系统 (EmotionalSupportSystem)
# =============================================================================

class EmotionalSupportSystem:
    """
    情感支持系统

    基于Rogers的人本主义疗法原则：
    - 无条件积极关注
    - 共情理解
    - 一致性（真诚）

    功能：
    - 识别情感需求
    - 提供情感支持
    - 引导情绪调节
    - 培养情感能力
    """

    def __init__(self):
        self.emotion_lexicon: Dict[str, List[str]] = self._build_emotion_lexicon()
        self.support_strategies: Dict[str, List[str]] = self._build_support_strategies()
        self.emotion_depth_map: Dict[str, int] = self._build_emotion_depth_map()

    def _build_emotion_lexicon(self) -> Dict[str, List[str]]:
        """构建情感词典"""
        return {
            "joy": ["开心", "快乐", "高兴", "喜悦", "兴奋", "满足", "幸福", "愉快", "欢乐", "欣慰"],
            "sadness": ["难过", "伤心", "悲伤", "沮丧", "失落", "郁闷", "沮丧", "痛苦", "哀伤", "哭泣"],
            "anger": ["生气", "愤怒", "恼火", "气愤", "烦躁", "不满", "恼怒", "大怒", "火大", "发火"],
            "fear": ["害怕", "恐惧", "担心", "焦虑", "不安", "紧张", "惊慌", "顾虑", "忧虑", "恐慌"],
            "surprise": ["惊讶", "意外", "吃惊", "震惊", "诧异", "惊奇", "意外", "突发"],
            "disgust": ["厌恶", "讨厌", "反感", "厌烦", "恶心", "不屑", "鄙夷", "嫌弃"],
            "trust": ["信任", "依赖", "安心", "放心", "依赖", "依靠", "托付", "信赖"],
            "anticipation": ["期待", "盼望", "希望", "憧憬", "向往", "期望", "渴望", "预想"]
        }

    def _build_support_strategies(self) -> Dict[str, List[str]]:
        """构建支持策略库"""
        return {
            "validation": [
                "你的感受是完全合理的",
                "任何人处在你的位置都会有同样的感受",
                "这确实很难"
            ],
            "empathy": [
                "我理解你为什么感到这样",
                "这对你来说一定很不容易",
                "我能感受到你的困难"
            ],
            "presence": [
                "我会在这里陪着你",
                "你不需要一个人面对",
                "我愿意听你说"
            ],
            "reframing": [
                "也许这是一个重新审视的机会",
                "虽然困难，但也让你变得更强大",
                "每次经历都会带来成长"
            ],
            "action": [
                "我们可以一起想办法",
                "你想先从哪里开始",
                "让我知道你需要什么帮助"
            ]
        }

    def _build_emotion_depth_map(self) -> Dict[str, int]:
        """构建情感深度映射（表面情感 vs 深层情感）"""
        return {
            "生气": 1, "愤怒": 1, "恼火": 1,
            "失望": 2, "受伤": 2, "被忽视": 2,
            "害怕": 1, "担心": 1, "焦虑": 2,
            "悲伤": 2, "难过": 2, "伤心": 2,
            "孤独": 3, "空虚": 3, "无价值": 3,
            "内疚": 3, "羞耻": 3, "自责": 3
        }

    def detect_emotion(self, text: str) -> List[Dict[str, Any]]:
        """
        检测文本中的情感

        Args:
            text: 输入文本

        Returns:
            检测到的情感列表
        """
        detected = []
        text_lower = text.lower()

        for emotion, keywords in self.emotion_lexicon.items():
            for keyword in keywords:
                if keyword in text_lower:
                    depth = self.emotion_depth_map.get(keyword, 1)
                    detected.append({
                        "emotion": emotion,
                        "keyword": keyword,
                        "depth": depth,
                        "surface": depth <= 1,
                        "deep": depth >= 2
                    })

        return detected

    def generate_support_response(self,
                               emotion: str,
                               intensity: float = 0.5) -> Dict[str, Any]:
        """
        生成支持性回应

        Args:
            emotion: 情感类型
            intensity: 情感强度 0-1

        Returns:
            支持性回应
        """
        strategies = self.support_strategies

        if intensity >= 0.8:
            primary_strategy = "presence"
        elif intensity >= 0.5:
            primary_strategy = "empathy"
        else:
            primary_strategy = "action"

        return {
            "primary_response": strategies[primary_strategy],
            "secondary_responses": [v for k, v in strategies.items() if k != primary_strategy],
            "recommended_strategy": primary_strategy,
            "do_not": self._get_do_not_list(emotion)
        }

    def _get_do_not_list(self, emotion: str) -> List[str]:
        """获取不应该做的事"""
        do_not_map = {
            "sadness": ["别哭了", "有什么好难过的", "振作起来"],
            "anger": ["你冷静点", "不要生气", "至于吗"],
            "fear": ["有什么好怕的", "别杞人忧天", "你想太多"],
            "anxiety": ["别担心了", "船到桥头自然直", "会好的"]
        }
        return do_not_map.get(emotion, ["你就不应该这样感觉"])

    def analyze_emotional_need(self, signals: List[EmotionalSignal]) -> Dict[str, Any]:
        """
        分析情感需求

        Args:
            signals: 情感信号列表

        Returns:
            需求分析结果
        """
        if not signals:
            return {"primary_need": "陪伴", "secondary_needs": [], "readiness": "low"}

        need_counts = {}
        for signal in signals:
            need = signal.underlying_need
            need_counts[need] = need_counts.get(need, 0) + signal.intensity

        sorted_needs = sorted(need_counts.items(), key=lambda x: x[1], reverse=True)
        primary_need = sorted_needs[0][0] if sorted_needs else "理解"

        avg_intensity = sum(s.intensity for s in signals) / len(signals)

        return {
            "primary_need": primary_need,
            "secondary_needs": [n[0] for n in sorted_needs[1:3]],
            "readiness": "high" if avg_intensity > 0.6 else "medium" if avg_intensity > 0.3 else "low",
            "emotional_state": self._summarize_emotional_state(signals)
        }

    def _summarize_emotional_state(self, signals: List[EmotionalSignal]) -> str:
        """总结情感状态"""
        if not signals:
            return "平静"

        avg_intensity = sum(s.intensity for s in signals) / len(signals)
        dominant_emotion = max(signals, key=lambda s: s.intensity).surface_emotion

        if avg_intensity > 0.7:
            intensity_desc = "强烈"
        elif avg_intensity > 0.4:
            intensity_desc = "中等"
        else:
            intensity_desc = "轻微"

        return f"{intensity_desc}{dominant_emotion}"


# =============================================================================
# 第五部分: 父母自反射模块 (ParentingReflectionModule)
# =============================================================================

class ParentingReflectionModule:
    """
    父母自反射模块

    基于Frankl的意义治疗和 metacognitive 理论

    功能：
    - 帮助父母反思自己的行为模式
    - 识别触发反应
    - 理解自己的创伤根源
    - 培养元认知能力
    """

    def __init__(self):
        self.trigger_patterns: List[Dict[str, Any]] = []
        self.reflection_history: List[Dict[str, Any]] = []

    def analyze_trigger(self,
                      situation: str,
                      reaction: str,
                      aftermath: str) -> Dict[str, Any]:
        """
        分析触发反应

        Args:
            situation: 触发情境
            reaction: 当时反应
            aftermath: 事后结果

        Returns:
            触发分析
        """
        analysis = {
            "situation": situation,
            "reaction": reaction,
            "aftermath": aftermath,
            "trigger_type": self._classify_trigger(situation),
            "reaction_pattern": self._analyze_reaction_pattern(reaction),
            "child_perspective": self._imagine_child_perspective(situation, reaction),
            "alternative_responses": self._generate_alternatives(situation, reaction),
            "root_wound": self._identify_root_wound(reaction)
        }

        self.trigger_patterns.append(analysis)
        return analysis

    def _classify_trigger(self, situation: str) -> str:
        """分类触发类型"""
        situation_lower = situation.lower()

        if any(kw in situation_lower for kw in ["成绩", "考试", "学习"]):
            return "学业相关触发"
        elif any(kw in situation_lower for kw in ["不听话", "顶嘴", "反抗"]):
            return "权威挑战触发"
        elif any(kw in situation_lower for kw in ["哭", "闹", "情绪"]):
            return "情绪表达触发"
        elif any(kw in situation_lower for kw in ["比较", "别人", "其他孩子"]):
            return "社会比较触发"
        elif any(kw in situation_lower for kw in ["脏", "乱", "不整理"]):
            return "秩序/控制触发"
        else:
            return "其他触发"

    def _analyze_reaction_pattern(self, reaction: str) -> str:
        """分析反应模式"""
        reaction_lower = reaction.lower()

        if any(kw in reaction_lower for kw in ["吼", "骂", "大声", "发火"]):
            return "情绪爆发型"
        elif any(kw in reaction_lower for kw in ["冷漠", "不理", "无视"]):
            return "情感撤回型"
        elif any(kw in reaction_lower for kw in ["讲道理", "说教", "解释"]):
            return "理智解释型"
        elif any(kw in reaction_lower for kw in ["惩罚", "剥夺", "威胁"]):
            return "惩罚控制型"
        elif any(kw in reaction_lower for kw in ["算了", "随便", "无所谓"]):
            return "逃避放弃型"
        else:
            return "其他类型"

    def _imagine_child_perspective(self, situation: str, reaction: str) -> str:
        """想象孩子视角"""
        perspective = f"""
        孩子当时可能感受到：
        - 情境: {situation}
        - 孩子内心: "妈妈/爸爸为什么这样？"
        - 孩子的感受: """

        reaction_lower = reaction.lower()
        if any(kw in reaction_lower for kw in ["吼", "骂", "发火"]):
            perspective += "害怕、惊恐、受伤"
        elif any(kw in reaction_lower for kw in ["不理", "冷漠"]):
            perspective += "困惑、孤独、被抛弃"
        elif any(kw in reaction_lower for kw in ["讲道理"]):
            perspective += "被评判、不被理解"
        else:
            perspective += "困惑、失落"

        perspective += """
        - 孩子学到的: 这就是处理问题的方式
        """
        return perspective

    def _generate_alternatives(self, situation: str, reaction: str) -> List[str]:
        """生成替代反应"""
        alternatives = []

        reaction_lower = reaction.lower()

        if any(kw in reaction_lower for kw in ["吼", "骂"]):
            alternatives.extend([
                "先深呼吸，暂停10秒再回应",
                "用平静的声音说'我需要一点时间冷静'",
                "问孩子'你能告诉我发生了什么吗'"
            ])

        if any(kw in reaction_lower for kw in ["不理", "冷漠"]):
            alternatives.extend([
                "承认自己的情绪，说'我现在有点难过，需要冷静一下'",
                "尝试问孩子'你愿意告诉我你的想法吗'",
                "用肢体语言（拥抱、拍肩）代替言语"
            ])

        if any(kw in reaction_lower for kw in ["惩罚", "威胁"]):
            alternatives.extend([
                "先了解孩子行为背后的原因",
                "和孩子一起想办法解决问题",
                "设定合理的后果而非惩罚"
            ])

        if not alternatives:
            alternatives.append("停下来问自己：'我此刻真正担心的是什么？'")

        return alternatives

    def _identify_root_wound(self, reaction: str) -> str:
        """识别根源创伤"""
        reaction_lower = reaction.lower()

        if any(kw in reaction_lower for kw in ["吼", "骂", "失控"]):
            return "可能源于自己小时候被严厉对待的经历"
        elif any(kw in reaction_lower for kw in ["不理", "冷漠"]):
            return "可能源于自己小时候被情感忽视的经历"
        elif any(kw in reaction_lower for kw in ["完美", "必须"]):
            return "可能源于自己小时候被过高期望的经历"
        elif any(kw in reaction_lower for kw in ["控制"]):
            return "可能源于自己小时候缺乏控制感的经历"
        else:
            return "可能需要进一步探索"

    def generate_reflection_prompt(self, analysis: Dict[str, Any]) -> str:
        """生成反思提示"""
        prompt = f"""
        【自我反思问题】

        1. 触发分析
           - 是什么触发了我的反应？
           - 这个触发和我小时候的经历有什么相似？

        2. 情感探索
           - 我当时真正的感受是什么？
           - 我在担心什么？

        3. 孩子视角
           {analysis.get('child_perspective', '')}

        4. 替代选择
           {chr(10).join(f'   - {a}' for a in analysis.get('alternative_responses', []))}

        5. 成长机会
           - 如果能重来，我会怎么做？
           - 我可以从这次经历中学到什么？
        """
        return prompt


# =============================================================================
# 第六部分: 家庭动力学分析器 (FamilyDynamicsAnalyzer)
# =============================================================================

class FamilyDynamicsAnalyzer:
    """
    家庭动力学分析器

    基于系统论和沟通理论

    功能：
    - 分析家庭成员间的互动模式
    - 识别沟通障碍
    - 评估权力结构
    - 提供系统干预建议
    """

    def __init__(self):
        self.family_members: Dict[str, Dict[str, Any]] = {}
        self.interaction_patterns: List[Dict[str, Any]] = []

    def add_member(self,
                   member_id: str,
                   generation: int,
                   role: str,
                   characteristics: List[str]) -> None:
        """添加家庭成员"""
        self.family_members[member_id] = {
            "generation": generation,
            "role": role,
            "characteristics": characteristics,
            "relationships": {}
        }

    def add_relationship(self,
                        member1: str,
                        member2: str,
                        relationship_type: str,
                        quality: float,
                        interaction_pattern: str) -> None:
        """添加成员关系"""
        if member1 in self.family_members and member2 in self.family_members:
            self.family_members[member1]["relationships"][member2] = {
                "type": relationship_type,
                "quality": quality,
                "pattern": interaction_pattern
            }
            self.interaction_patterns.append({
                "member1": member1,
                "member2": member2,
                "type": relationship_type,
                "quality": quality,
                "pattern": interaction_pattern
            })

    def analyze_power_structure(self) -> Dict[str, Any]:
        """分析家庭权力结构"""
        influence_scores: Dict[str, float] = {}

        for member_id, member in self.family_members.items():
            score = 0.0
            for other_id, rel in member["relationships"].items():
                if rel["type"] == "父母-子女":
                    score += rel["quality"] * 0.3
                elif rel["type"] == "夫妻":
                    score += rel["quality"] * 0.4

            gen_factor = 1.0 + (member["generation"] - 2) * 0.1
            influence_scores[member_id] = score * gen_factor

        sorted_members = sorted(influence_scores.items(), key=lambda x: x[1], reverse=True)

        return {
            "power_ranking": [{"member": m, "score": s} for m, s in sorted_members],
            "most_influential": sorted_members[0][0] if sorted_members else None,
            "structure_type": self._classify_power_structure(sorted_members)
        }

    def _classify_power_structure(self, ranking: List[Tuple[str, float]]) -> str:
        """分类权力结构类型"""
        if not ranking:
            return "未知"

        if len(ranking) == 1:
            return "单一支配型"

        top_score = ranking[0][1]
        second_score = ranking[1][1] if len(ranking) > 1 else 0

        if top_score > second_score * 2:
            return "单一支配型"
        elif top_score > second_score * 1.5:
            return "略有倾斜型"
        else:
            return "相对平等型"

    def analyze_communication_patterns(self) -> Dict[str, Any]:
        """分析沟通模式"""
        pattern_types = {
            "指责型": 0,
            "讨好型": 0,
            "超理智型": 0,
            "打岔型": 0,
            "一致型": 0
        }

        for pattern in self.interaction_patterns:
            p = pattern.get("pattern", "").lower()
            if "指责" in p or "骂" in p:
                pattern_types["指责型"] += 1
            elif "讨好" in p or "顺从" in p:
                pattern_types["讨好型"] += 1
            elif "讲道理" in p or "理性" in p:
                pattern_types["超理智型"] += 1
            elif "转移" in p or "打岔" in p:
                pattern_types["打岔型"] += 1
            else:
                pattern_types["一致型"] += 1

        dominant = max(pattern_types.items(), key=lambda x: x[1])

        return {
            "pattern_distribution": pattern_types,
            "dominant_pattern": dominant[0],
            "health_assessment": "需要改善" if dominant[0] != "一致型" else "相对健康",
            "recommendations": self._get_pattern_recommendations(dominant[0])
        }

    def _get_pattern_recommendations(self, pattern: str) -> List[str]:
        """获取模式改善建议"""
        recommendations = {
            "指责型": [
                "尝试用'我感到'代替'你总是'",
                "区分观察和评判",
                "练习倾听而不立即回应"
            ],
            "讨好型": [
                "学会表达自己的需求",
                "不必总是同意孩子",
                "尊重自己的感受同样重要"
            ],
            "超理智型": [
                "多关注情感而非道理",
                "承认情绪的存在",
                "允许自己不完美"
            ],
            "打岔型": [
                "学会面对困难话题",
                "练习在压力下保持专注",
                "承认回避也是一种反应"
            ],
            "一致型": [
                "继续保持",
                "不断学习和成长"
            ]
        }
        return recommendations.get(pattern, [])

    def generate_family_map(self) -> str:
        """生成家庭图谱文本"""
        lines = []
        lines.append("【家庭图谱】\n")

        for member_id, member in sorted(self.family_members.items(),
                                        key=lambda x: x[1]["generation"]):
            lines.append(f"成员: {member_id}")
            lines.append(f"  世代: 第{member['generation']}代")
            lines.append(f"  角色: {member['role']}")
            lines.append(f"  特点: {', '.join(member['characteristics'])}")

            if member['relationships']:
                lines.append("  关系:")
                for other_id, rel in member['relationships'].items():
                    lines.append(f"    - 与{other_id}: {rel['type']} (质量:{rel['quality']:.1f})")
            lines.append("")

        return "\n".join(lines)


# =============================================================================
# 第七部分: 整合运行器 (IntegratedRunner)
# =============================================================================

class SecondGenerationParentsUpgrade:
    """
    第二代父母升级系统 - 整合运行器

    整合所有模块，提供统一入口
    """

    def __init__(self):
        self.trauma_analyzer = GenerationalTraumaAnalyzer()
        self.repair_engine = ParentChildRepairEngine()
        self.emotional_support = EmotionalSupportSystem()
        self.reflection_module = ParentingReflectionModule()
        self.dynamics_analyzer = FamilyDynamicsAnalyzer()

    def run_full_analysis(self,
                        gen1_issues: List[str],
                        gen2_issues: List[str],
                        gen3_issues: List[str]) -> Dict[str, Any]:
        """
        运行完整分析

        Args:
            gen1_issues: 第一代问题
            gen2_issues: 第二代问题
            gen3_issues: 第三代问题

        Returns:
            完整分析报告
        """
        report = {
            "version": "v2.0.0",
            "timestamp": time.time(),
            "trauma_analysis": self.trauma_analyzer.analyze_three_generation_trauma(
                gen1_issues, gen2_issues, gen3_issues
            ),
            "family_patterns": self.trauma_analyzer._identify_family_patterns(
                gen1_issues, gen2_issues, gen3_issues
            ),
            "insight_wheel": self.trauma_analyzer.generate_wheel_of_insight(
                {}
            )
        }

        return report

    def run_repair_plan(self,
                      parent_signals: List[EmotionalSignal],
                      child_signals: List[EmotionalSignal],
                      patterns: List[str]) -> Dict[str, Any]:
        """运行修复计划"""
        metrics = self.repair_engine.assess_relationship(
            parent_signals, child_signals, patterns
        )

        plan = self.repair_engine.generate_repair_plan(
            metrics,
            self.repair_engine.current_stage
        )

        return {
            "metrics": asdict(metrics),
            "plan": plan
        }

    def run_emotional_support(self, text: str) -> Dict[str, Any]:
        """运行情感支持"""
        emotions = self.emotional_support.detect_emotion(text)

        if emotions:
            primary = emotions[0]
            support = self.emotional_support.generate_support_response(
                primary["emotion"],
                primary["intensity"] if "intensity" in primary else 0.5
            )
        else:
            support = self.emotional_support.generate_support_response("unknown")

        return {
            "detected_emotions": emotions,
            "support": support
        }

    def run_trigger_analysis(self,
                           situation: str,
                           reaction: str,
                           aftermath: str) -> Dict[str, Any]:
        """运行触发分析"""
        analysis = self.reflection_module.analyze_trigger(
            situation, reaction, aftermath
        )
        prompt = self.reflection_module.generate_reflection_prompt(analysis)

        return {
            "analysis": analysis,
            "reflection_prompt": prompt
        }


# =============================================================================
# 测试代码
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("第二代父母升级系统 v2.0")
    print("=" * 60)

    # 测试1: 代际创伤分析
    print("\n【测试1: 代际创伤分析】\n")
    analyzer = GenerationalTraumaAnalyzer()

    gen1_issues = ["物质匮乏小时候经常吃不饱", "情感压抑从不表达"]
    gen2_issues = ["自己情感需求未被满足", "过度补偿给孩子物质"]
    gen3_issues = ["被成绩定义", "没有真正的关注"]

    result = analyzer.analyze_three_generation_trauma(
        gen1_issues, gen2_issues, gen3_issues
    )

    print(f"核心创伤: {result['core_family_wound']['primary_wound']}")
    print(f"传递模式: {result['transmission_pattern']['most_dominant']}")
    print(f"干预数量: {len(result['intervention_recommendations'])}")

    # 测试2: 情感支持
    print("\n【测试2: 情感支持】\n")
    support = EmotionalSupportSystem()

    test_text = "孩子今天成绩考差了，我很担心"
    emotions = support.detect_emotion(test_text)
    print(f"检测到的情感: {[e['emotion'] for e in emotions]}")

    # 测试3: 触发分析
    print("\n【测试3: 触发分析】\n")
    reflection = ParentingReflectionModule()

    analysis = reflection.analyze_trigger(
        situation="孩子考试成绩不理想",
        reaction="我大声责备了他",
        aftermath="孩子哭了，我也后悔"
    )

    print(f"触发类型: {analysis['trigger_type']}")
    print(f"反应模式: {analysis['reaction_pattern']}")
    print(f"根源创伤: {analysis['root_wound']}")

    # 测试4: 整合运行
    print("\n【测试4: 整合运行】\n")
    runner = SecondGenerationParentsUpgrade()

    full_report = runner.run_full_analysis(
        gen1_issues, gen2_issues, gen3_issues
    )

    print(f"版本: {full_report['version']}")
    print(f"分析完成: 是")

    print("\n" + "=" * 60)
    print("测试完成！系统运行正常。")
    print("=" * 60)
