# still-growing 家庭教育技能

## 简介

still-growing 是一个基于心理学研究的家庭教育辅助系统，整合多种工具帮助父母提升教养能力。

## 目录结构

```
still-growing/
├── SKILL.md          # 技能定义文件
├── README.md         # 本文件
├── scripts/          # 可运行代码模块
│   ├── main.py                      # 主入口
│   ├── parenting_assessment.py       # 教养风格评估
│   ├── mood_tracker.py              # 情绪追踪
│   ├── goal_tracker.py              # 目标追踪
│   └── communication_analyzer.py     # 沟通分析
├── data/             # 数据存储目录
│   ├── assessment_responses.json     # 评估历史
│   ├── mood_records.json            # 情绪记录
│   ├── goals.json                  # 目标数据
│   └── communication_records.json    # 沟通记录
└── templates/        # 模板文件（待添加）
```

## 快速开始

### 运行主程序

```bash
cd ~/.jvs/.openclaw/skills/skills/still-growing/scripts
python3 main.py
```

### 单独运行各模块

```bash
# 教养风格评估
python3 scripts/parenting_assessment.py

# 情绪追踪
python3 scripts/mood_tracker.py

# 目标追踪
python3 scripts/goal_tracker.py

# 沟通分析
python3 scripts/communication_analyzer.py
```

## 功能模块

### 1. 父母教养风格评估

基于心理学研究开发的自我评估工具，帮助父母了解自己的教养风格。

**支持的风格类型：**
- 专制型：高要求、低回应
- 权威型：高要求、高回应（最理想）
- 溺爱型：低要求、高回应
- 忽视型：低要求、低回应

**使用方法：**
```python
from parenting_assessment import ParentingAssessment

assessor = ParentingAssessment()
scores = assessor.run_questionnaire()
results = assessor.calculate_results(scores)
assessor.print_results(results)
```

### 2. 亲子互动情绪追踪

追踪和记录亲子互动中的情绪变化，帮助识别模式和触发因素。

**功能：**
- 记录每日情绪
- 追踪触发因素
- 分析情绪模式
- 生成周报/月报

**使用方法：**
```python
from mood_tracker import MoodTracker

tracker = MoodTracker()
tracker.interactive_add()
analysis = tracker.analyze_patterns(days=30)
tracker.print_analysis(analysis)
```

### 3. 教育目标追踪

帮助家庭设定、追踪和达成教育目标。

**功能：**
- 创建和管理目标
- 设置里程碑
- 追踪进度
- 查看仪表板

**使用方法：**
```python
from goal_tracker import GoalTracker

tracker = GoalTracker()
tracker.interactive_create()
summary = tracker.get_dashboard_summary()
tracker.print_dashboard(summary)
```

### 4. 沟通分析器

分析亲子对话模式，识别沟通问题并提供改进建议。

**功能：**
- 分析对话文本
- 识别负面模式（批评、轻蔑、防御、冷战）
- 识别正面模式（共情、肯定、解决问题）
- 生成沟通健康度评分

**使用方法：**
```python
from communication_analyzer import CommunicationAnalyzer

analyzer = CommunicationAnalyzer()
analyzer.interactive_analyze()
```

## 数据存储

所有数据存储在 `data/` 目录，包含 JSON 格式的历史记录：

- `assessment_responses.json` - 评估问卷回答和结果
- `mood_records.json` - 情绪追踪记录
- `goals.json` - 目标数据
- `goal_progress.json` - 目标进度

## 技术栈

- Python 3.6+
- 标准库（json, os, datetime, collections）
- 无外部依赖

## 依赖 GitHub 项目

### AI Agent 框架（推荐集成）

| 项目 | Stars | 描述 | 集成状态 |
|------|-------|------|---------|
| [LangGraph](https://github.com/langchain-ai/langgraph) | 32k | 构建弹性AI Agent | ✅ 已集成 |
| [OpenAI Agents SDK](https://github.com/openai/openai-agents-python) | 26k | 多Agent工作流 | ✅ 已集成 |
| [PydanticAI](https://github.com/pydantic/pydantic-ai) | 17k | 类型安全Agent框架 | ✅ 已集成 |
| [Microsoft Agent](https://github.com/microsoft/agent-framework) | 10k | 多Agent编排 | 待集成 |

### AI Agent 集成模块

本技能包含 `ai_agent_integration.py`，实现了：

- **多Agent协调器** - `MultiAgentCoordinator`
- **父母教养评估Agent** - `ParentingAssessmentAgent`
- **情绪追踪Agent** - `MoodTrackingAgent`
- **目标追踪Agent** - `GoalTrackingAgent`

### 安装依赖

```bash
# 安装 AI Agent 框架
pip install openai-agents pydantic-ai langgraph

# 或安装所有依赖
pip install openai anthropic
```

### 使用示例

```python
from ai_agent_integration import create_coordinator
import asyncio

async def main():
    coordinator = create_coordinator()
    
    # 评估请求
    result = await coordinator.process_request({
        "type": "assessment",
        "text": "我的回答"
    })
    print(result)

asyncio.run(main())
```

### 理论框架来源

- [萨提亚家庭治疗](https://zh.wikipedia.org/wiki/%E7%BB%B4%E5%90%89%E5%B0%BC%E4%BA%9A%C2%B7%E8%90%A8%E6%8F%9B%E4%BA%9A) - 家庭治疗理论
- [正面管教](https://www.positivediscipline.com/) - 积极教养方法
- [阿德勒心理学](https://zh.wikipedia.org/wiki/%E9%98%BF%E5%B0%94%E5%BC%80%E9%9B%86%C2%B7%E9%98%BF%E5%BE%B7%E5%8B%92) - 个体心理学

## 版本历史

- v0.6.89 - 代码模块重构，添加可运行脚本
- v0.5.8-v0.6.0 - 内容扩充期
- v0.5.7 - 萨提亚家庭治疗理论
- v0.5.6 - 积极养育研究

## 许可证

MIT License

## 作者

still-growing Team

## 贡献

欢迎提交 Issue 和 Pull Request！
