#!/usr/bin/env python3
"""
家庭教育系统 - 整合版
Family Education System - Integrated

每个模块都基于"人性底层逻辑"运行：
- 慈悲是体，爱是用
- 恨比爱更原始
- 错位是桥梁的断裂

不再有单独的引擎，每个功能都内嵌这个逻辑。
"""

from core_logic import HumanNature, CompassionAnalyzer, full_analysis

# ========================
# 整合分析器（所有输入都走这里）
# ========================

class IntegratedAnalyzer:
    """
    整合分析器
    
    所有输入（父母的话、孩子的话、行为、情绪）
    都经过人性底层逻辑分析
    """
    
    def __init__(self):
        self.nature = HumanNature()
        self.compassion = CompassionAnalyzer()
    
    def analyze(self, text: str) -> str:
        """
        分析任何输入
        自动判断是父母话语还是孩子行为
        """
        # 父母话语特征词
        parent_words = ["你", "我", "必须", "不准", "不许", "听话", "应该", "不要", "给我", "看你"]
        # 孩子行为特征词
        child_words = ["孩子", "他", "她", "不", "打", "哭", "闹", "说谎", "发脾气", "沉迷", "不听话"]
        
        # 简单判断
        parent_score = sum(1 for w in parent_words if w in text)
        child_score = sum(1 for w in child_words if w in text)
        
        speaker = "parent" if parent_score > child_score else "child"
        
        return full_analysis(text, speaker)


# ========================
# 教养的慈悲分析
# ========================

class ParentingCompassion:
    """
    教养的慈悲分析
    
    所有教养问题，先分析父母的恨，再找到爱
    """
    
    @staticmethod
    def analyze_parent_statement(statement: str) -> str:
        """
        分析父母话语背后的恨与爱
        """
        return full_analysis(statement, "parent")
    
    @staticmethod
    def analyze_child_behavior(behavior: str) -> str:
        """
        分析孩子行为背后的需求
        """
        return full_analysis(behavior, "child")
    
    @staticmethod
    def the_bridge() -> str:
        """
        桥梁分析
        """
        return HumanNature.the_bridge_analysis()


# ========================
# 情绪追踪的慈悲视角
# ========================

class EmotionalCompassion:
    """
    情绪追踪的慈悲视角
    
    看见情绪背后的恨与需求
    """
    
    EMOTION_PATTERNS = {
        "愤怒": {
            "parent_reason": "父母感到失控、无力、恐惧——这些都是恨的变形",
            "child_reason": "孩子感到挫败、恐惧、不被理解",
            "compassion": "愤怒是伤痛的呼喊"
        },
        "焦虑": {
            "parent_reason": "父母害怕自己不够好，害怕孩子失败，害怕失控",
            "child_reason": "孩子承受了父母的焦虑，不知道如何应对",
            "compassion": "焦虑背后是对安全的渴望"
        },
        "悲伤": {
            "parent_reason": "父母可能感到失败、失望、失去",
            "child_reason": "孩子可能感到被拒绝、不被理解",
            "compassion": "悲伤是爱失去的哀鸣"
        },
        "恐惧": {
            "parent_reason": "父母害怕自己的童年在孩子身上重演",
            "child_reason": "孩子害怕让父母失望，害怕被抛弃",
            "compassion": "恐惧是对安全的渴望"
        }
    }
    
    @classmethod
    def analyze_emotion(cls, emotion: str) -> dict:
        """分析情绪背后的真相"""
        analysis = cls.EMOTION_PATTERNS.get(emotion, {
            "parent_reason": "需要更多情境",
            "child_reason": "需要更多情境",
            "compassion": "所有情绪都值得被看见"
        })
        
        return {
            "emotion": emotion,
            "parent_reason": analysis["parent_reason"],
            "child_reason": analysis["child_reason"],
            "compassion": analysis["compassion"]
        }


# ========================
# 沟通的桥梁分析
# ========================

class CommunicationBridge:
    """
    沟通的桥梁分析
    
    每一句话都连接或断开亲子关系
    """
    
    @staticmethod
    def analyze_words(words: str) -> str:
        """
        分析话语对桥梁的影响
        """
        # 断桥的话
        bridge_breakers = [
            "你必须", "你从来不", "你就是", "笨蛋", "废物",
            "不要你了", "我不管你了", "随便你", "滚"
        ]
        
        # 连桥的话
        bridge_builders = [
            "我理解你", "我听到你了", "我们来想办法", 
            "你的感受很重要", "我爱你", "我需要你告诉我"
        ]
        
        breakers_found = [w for w in bridge_breakers if w in words]
        builders_found = [w for w in bridge_builders if w in words]
        
        result = []
        result.append("")
        result.append("="*50)
        result.append("沟通的桥梁分析")
        result.append("="*50)
        
        if breakers_found:
            result.append("\n⚠️ 断桥的话语：")
            for w in breakers_found:
                result.append(f"   • '{w}'")
            result.append("\n这些话语会让孩子关闭心门")
        
        if builders_found:
            result.append("\n✅ 连桥的话语：")
            for w in builders_found:
                result.append(f"   • '{w}'")
            result.append("\n这些话让孩子感到被理解")
        
        if not breakers_found and not builders_found:
            result.append("\n这些话语对桥梁的影响不明显")
        
        result.append("")
        
        return "".join(result)


# ========================
# 代际传递分析
# ========================

class GenerationalCycle:
    """
    代际传递分析
    
    为什么我们会用父母对待我们的方式对待孩子
    """
    
    @staticmethod
    def analyze_cycle(parent_behavior: str) -> str:
        """
        分析代际传递
        """
        return f"""
代际传递分析

【父母的这句话】
"{parent_behavior}"

【父母小时候可能听到的】
...""" + f"""
"{parent_behavior.replace('你', '我')}"

【传递的逻辑】
父母小时候被这样对待，现在无意识地用同样的方式对待孩子
——不是不爱，是不知道还有其他方式

【打破循环的第一步】
看见：意识到自己在重复童年的模式
理解：理解父母当年也是这样被对待的
选择：我可以不同

【桥梁修复】
不是责怪父母，而是看见他们也曾是受伤的孩子
不是重复传递，而是从我开始打破循环
        """


# ========================
# 主入口
# ========================

def main():
    """主入口"""
    print("="*50)
    print("家庭教育系统 - 整合版")
    print("底层逻辑：慈悲是体，爱是用；恨比爱更原始")
    print("="*50)
    
    analyzer = IntegratedAnalyzer()
    
    print("\n请输入一句话或行为，我来帮你分析：")
    print("示例：")
    print("  父母：你再不听话就不要你了")
    print("  孩子：发脾气、说谎、不听话")
    print("  输入 'bridge' 查看桥梁分析")
    print("  输入 'cycle' 分析代际传递")
    print("  输入 'quit' 退出\n")
    
    while True:
        user_input = input("输入: ").strip()
        
        if user_input.lower() == "quit":
            break
        
        if user_input.lower() == "bridge":
            print(CommunicationBridge.analyze_words(""))
            continue
        
        if user_input.lower() == "cycle":
            print(GenerationalCycle.analyze_cycle("你必须听我的话"))
            continue
        
        if user_input:
            result = analyzer.analyze(user_input)
            print(result)


if __name__ == "__main__":
    main()
