#!/usr/bin/env python3
"""
still-growing 家庭教育技能主入口
Main Entry Point for Still-Growing Family Education Skill

整合所有模块，提供统一的命令行界面。
"""

import sys
import os

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from parenting_assessment import ParentingAssessment
from mood_tracker import MoodTracker
from goal_tracker import GoalTracker
from communication_analyzer import CommunicationAnalyzer

def print_banner():
    """打印横幅"""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║          still-growing 家庭教育技能系统 v1.0                 ║
║                                                              ║
║   整合心理学评估、情绪追踪、目标管理、沟通分析               ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def print_menu():
    """打印菜单"""
    menu = """
请选择功能模块：

  1. 📋 父母教养风格评估
     - 基于心理学研究的自我评估问卷
     - 了解自己的教养风格类型

  2. 💭 亲子互动情绪追踪
     - 记录每日情绪变化
     - 识别触发因素和模式

  3. 🎯 教育目标追踪
     - 设定和追踪家庭教育目标
     - 记录里程碑和进度

  4. 💬 沟通分析器
     - 分析亲子对话模式
     - 识别沟通问题并给出建议

  5. 📊 查看仪表板
     - 查看所有模块的汇总数据

  0. 🚪 退出
"""
    print(menu)

def run_assessment():
    """运行评估模块"""
    print("\n" + "="*50)
    print("启动父母教养风格评估模块...")
    print("="*50)
    
    assessor = ParentingAssessment()
    history = assessor.get_history()
    
    if history:
        print(f"\n发现 {len(history)} 条历史评估记录")
        compare = assessor.compare_progress()
        if "message" not in compare:
            print("\n与上次评估比较：")
            for style, data in compare['changes'].items():
                print(f"  {data['name']}: {data['direction']} ({data['change']:+d}分)")
    
    # 运行评估
    scores = assessor.run_questionnaire()
    results = assessor.calculate_results(scores)
    assessor.print_results(results)
    
    # 保存结果
    filepath = assessor.save_results(results)
    print(f"\n✅ 评估结果已保存: {filepath}")
    
    return results

def run_mood_tracker():
    """运行情绪追踪模块"""
    print("\n" + "="*50)
    print("启动亲子互动情绪追踪模块...")
    print("="*50)
    
    tracker = MoodTracker()
    
    # 显示今日摘要
    summary = tracker.get_daily_summary()
    print(f"\n今日状态: {summary}")
    
    # 添加记录
    tracker.interactive_add()
    
    # 分析模式
    analysis = tracker.analyze_patterns(days=30)
    if "message" not in analysis:
        tracker.print_analysis(analysis)
    
    return tracker

def run_goal_tracker():
    """运行目标追踪模块"""
    print("\n" + "="*50)
    print("启动教育目标追踪模块...")
    print("="*50)
    
    tracker = GoalTracker()
    
    # 显示仪表板
    summary = tracker.get_dashboard_summary()
    tracker.print_dashboard(summary)
    
    # 询问操作
    print("\n" + "-"*40)
    print("可选操作:")
    print("  1. 创建新目标")
    print("  2. 查看目标列表")
    print("  3. 更新目标进度")
    print("  4. 返回主菜单")
    
    choice = input("\n请选择(1-4): ").strip()
    
    if choice == "1":
        tracker.interactive_create()
    elif choice == "2":
        goals = tracker.load_goals()
        print("\n【所有目标】:")
        for goal in goals:
            status_icon = "✅" if goal['status'] == "已完成" else "⏳" if goal['status'] == "进行中" else "❌"
            print(f"  {status_icon} [{goal['status']}] {goal['title']} - {goal['progress']}%")
    elif choice == "3":
        goals = tracker.load_goals()
        if goals:
            print("\n【选择要更新的目标】:")
            for i, goal in enumerate(goals, 1):
                print(f"  {i}. {goal['title']}")
            try:
                idx = int(input("\n请选择(1-" + str(len(goals)) + "): ").strip())
                if 1 <= idx <= len(goals):
                    goal = goals[idx-1]
                    delta = int(input("进度变化(+/-): ").strip())
                    notes = input("备注: ").strip()
                    tracker.add_progress(goal['id'], delta, notes)
                    print("✅ 进度已更新")
            except ValueError:
                print("无效选择")
    elif choice == "4":
        return
    
    return tracker

def run_communication_analyzer():
    """运行沟通分析模块"""
    print("\n" + "="*50)
    print("启动沟通分析模块...")
    print("="*50)
    
    analyzer = CommunicationAnalyzer()
    return analyzer.interactive_analyze()

def show_dashboard():
    """显示仪表板"""
    print("\n" + "="*50)
    print("家庭教育技能系统 - 综合仪表板")
    print("="*50)
    
    # 评估数据
    assessor = ParentingAssessment()
    assessment_history = assessor.get_history()
    if assessment_history:
        latest = assessment_history[-1]
        print(f"\n📋 最新教养风格评估: {latest.get('dominant_name', 'N/A')}")
        print(f"   评估时间: {latest.get('timestamp', 'N/A')[:10]}")
    
    # 情绪追踪数据
    tracker = MoodTracker()
    today_summary = tracker.get_daily_summary()
    print(f"\n💭 今日情绪追踪: {today_summary}")
    
    analysis = tracker.analyze_patterns(days=7)
    if "message" not in analysis:
        print(f"   本周记录: {analysis.get('total_records', 0)}条")
        print(f"   平均强度: {analysis.get('avg_intensity', 0)}/10")
    
    # 目标数据
    goal_tracker = GoalTracker()
    goal_summary = goal_tracker.get_dashboard_summary()
    print(f"\n🎯 目标进度:")
    print(f"   总目标数: {goal_summary.get('total', 0)}")
    print(f"   平均进度: {goal_summary.get('avg_progress', 0)}%")
    if goal_summary.get('upcoming_deadlines'):
        print(f"   即将到期: {len(goal_summary['upcoming_deadlines'])}个")
    
    print()

def main():
    """主函数"""
    print_banner()
    
    while True:
        print_menu()
        choice = input("请选择(0-5): ").strip()
        
        if choice == "1":
            run_assessment()
        elif choice == "2":
            run_mood_tracker()
        elif choice == "3":
            run_goal_tracker()
        elif choice == "4":
            run_communication_analyzer()
        elif choice == "5":
            show_dashboard()
        elif choice == "0":
            print("\n感谢使用！再见！👋\n")
            break
        else:
            print("\n无效选择，请重试")
        
        input("\n按回车继续...")

if __name__ == "__main__":
    main()
