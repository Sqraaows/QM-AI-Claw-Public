#!/usr/bin/env python3
"""
家庭教育核心引擎
Family Education Core Engine

底层逻辑：
- 慈悲是体，爱是用
- 恨比爱更原始
- 错位是桥梁的断裂
- 这个系统本身是桥梁

所有模块都基于这个核心运行。
"""

# ========================
# 人性底层逻辑
# ========================

class HumanNature:
    """
    人性底层逻辑
    
    核心：恨比爱更原始
    - 爱需要学习，恨是本能
    - 父母打骂孩子，不是因为不爱，是因为恨
    - 恨自己小时候被这样对待
    - 恨自己没有选择
    - 恨这个系统让他们不得不这样
    """
    
    @staticmethod
    def why_parent_hurts(behavior: str) -> dict:
        """
        分析父母伤害行为背后的恨
        
        Args:
            behavior: 父母的行为描述
            
        Returns:
            分析结果
        """
        # 恨的来源分析
        hate_sources = {
            "打骂": [
                "恨自己小时候也被打骂",
                "恨自己失控",
                "恨生活压力无处发泄",
                "恨自己不是好父母"
            ],
            "忽视": [
                "恨自己小时候也被忽视",
                "恨自己不知道怎么做",
                "恨自己的情感需求从未被满足",
                "恨生活压力让他们没时间"
            ],
            "控制": [
                "恨自己没有选择",
                "恨自己无法保护孩子",
                "恨这个只看结果的社会",
                "恨自己童年被控制"
            ],
            "比较": [
                "恨自己不够好",
                "恨自己没能实现的梦想",
                "恨社会只看成就",
                "恨自己无法接受孩子的平凡"
            ]
        }
        
        # 找到匹配的恨源
        matched_hates = []
        for key, hates in hate_sources.items():
            if key in behavior:
                matched_hates.extend(hates)
        
        if not matched_hates:
            matched_hates = ["恨的来源不明，需要更多情境"]
        
        return {
            "core_truth": "父母打骂孩子，不是因为不爱，是因为恨。恨比爱更原始。",
            "hate_sources": matched_hates,
            "bridge_broken": "父母传递的是自己的饥饿，不是孩子的需求",
            "cycle": "第一代传给第二代，第二代传给第三代——除非有人看见并打破它"
        }
    
    @staticmethod
    def why_child_behaves_badtly(behavior: str) -> dict:
        """
        分析孩子问题行为背后的原因
        
        Args:
            behavior: 孩子的行为描述
            
        Returns:
            分析结果
        """
        # 孩子行为的功能
        behavior_functions = {
            "发脾气": [
                "这是唯一能让大人听见的方式",
                "情绪太强烈，无法用语言表达",
                "在测试界限和爱的边界"
            ],
            "说谎": [
                "真话会带来惩罚，假话带来安全",
                "真话不被接受，假话至少能保护自己",
                "在保护自己不受伤害"
            ],
            "不听话": [
                "在发展自主性",
                "父母的规则不符合他的逻辑",
                "用反抗来证明自己是独立的个体"
            ],
            "沉迷手机": [
                "现实太痛苦/无聊/被否定",
                "手机是逃避现实的唯一出口",
                "在寻找现实生活中找不到的成就感"
            ],
            "打小朋友": [
                "这是他知道的唯一表达方式",
                "他在模仿家里的互动模式",
                "他在寻求权力或关注"
            ]
        }
        
        matched_functions = []
        for key, functions in behavior_functions.items():
            if key in behavior:
                matched_functions.extend(functions)
        
        if not matched_functions:
            matched_functions = ["行为背后总有原因，需要更多情境来理解"]
        
        return {
            "core_truth": "每个问题行为背后都有一个未被满足的需求",
            "unmet_needs": matched_functions,
            "child_logic": "孩子不是有问题，孩子是在用他能用的方式生存",
            "parent_view": "问题不是孩子本身，而是亲子之间的连接断了"
        }
    
    @staticmethod
    def the_bridge_analysis() -> str:
        """
        桥梁分析——错位是桥梁的断裂
        
        Returns:
            桥梁分析
        """
        return """
错位是桥梁的断裂。

父母和孩子的世界之间，有一座桥。

这座桥本来应该传递：
- 父母的爱 → 孩子感受到被爱
- 孩子的需求 → 父母理解孩子的需求

但这座桥断了。

断在：
- 父母传递的是自己的饥饿，而不是食物
- 孩子收到的是父母的匮乏，而不是满足
- 孩子表达的需求被忽略，因为父母的桥上只传输自己的需求

桥梁断裂的信号：
- 孩子说"没有人理解我"
- 父母说"我为他付出了这么多"
- 亲子对话总是鸡同鸭讲
- 孩子越来越不愿意和父母说话

修复桥梁的方法：
- 看见对方的真实存在
- 听到对方话语背后的情感
- 承认自己的有限和错位
- 不再传递自己未曾得到的
        """

# ========================
# 慈悲分析器
# ========================

class CompassionAnalyzer:
    """
    慈悲分析器
    
    慈悲是体，爱是用。
    - 先看见恨，才能理解爱
    - 不谴责父母，理解他们也曾是受伤的孩子
    - 帮助用户看见自己的模式
    """
    
    def __init__(self):
        self.nature = HumanNature()
    
    def analyze(self, statement: str, speaker: str = "parent") -> dict:
        """
        分析一句话背后的真相
        
        Args:
            statement: 话语
            speaker: 说话者 ("parent" 或 "child")
            
        Returns:
            完整的分析
        """
        if speaker == "parent":
            hate_analysis = self.nature.why_parent_hurts(statement)
            return {
                "speaker": "父母",
                "statement": statement,
                "layer1_hate": hate_analysis["core_truth"],
                "hate_sources": hate_analysis["hate_sources"],
                "bridge": "父母传递的是自己的饥饿，不是孩子的需求",
                "compassion": self._generate_compassion(hate_analysis["hate_sources"]),
                "cycle": hate_analysis["cycle"],
                "question": "父母小时候也有过类似的经历吗？"
            }
        else:
            behavior_analysis = self.nature.why_child_behaves_badtly(statement)
            return {
                "speaker": "孩子",
                "statement": statement,
                "layer1_behavior": behavior_analysis["core_truth"],
                "unmet_needs": behavior_analysis["unmet_needs"],
                "bridge": "问题不是孩子本身，而是连接断了",
                "compassion": "孩子不是有问题，孩子是在用他能用的方式生存",
                "question": "孩子真正需要的是什么？他通过这个行为在表达什么？"
            }
    
    def _generate_compassion(self, hate_sources: list) -> str:
        """生成慈悲的理解"""
        compassion = "理解父母：\n"
        compassion += "- 他们也曾是受伤的孩子\n"
        for source in hate_sources[:2]:
            compassion += f"- {source}\n"
        compassion += "\n他们不知道还有其他方式。"
        return compassion

# ========================
# 整合分析输出
# ========================

def full_analysis(statement: str, speaker: str = "parent") -> str:
    """
    完整分析输出
    
    Args:
        statement: 话语或行为描述
        speaker: 说话者 ("parent" 或 "child")
    """
    analyzer = CompassionAnalyzer()
    result = analyzer.analyze(statement, speaker)
    
    output = []
    output.append("")
    output.append("="*50)
    output.append(f"【{result['speaker']}】")
    output.append(f'"{result["statement"]}"')
    output.append("="*50)
    
    if speaker == "parent":
        output.append("\n🔍 第一层：恨")
        output.append(f"   {result['layer1_hate']}")
        
        output.append("\n恨的来源：")
        for h in result['hate_sources']:
            output.append(f"   • {h}")
        
        output.append("\n🌉 桥梁分析")
        output.append(f"   {result['bridge']}")
        
        output.append("\n💚 慈悲的理解")
        output.append(result['compassion'])
        
        output.append("\n🔄 代际传递")
        output.append(f"   {result['cycle']}")
    else:
        output.append("\n🔍 第一层：行为功能")
        output.append(f"   {result['layer1_behavior']}")
        
        output.append("\n未被满足的需求：")
        for n in result['unmet_needs']:
            output.append(f"   • {n}")
        
        output.append("\n🌉 桥梁分析")
        output.append(f"   {result['bridge']}")
        
        output.append("\n💚 慈悲的理解")
        output.append(f"   {result['compassion']}")
    
    output.append("\n❓ 反思问题")
    output.append(f"   {result['question']}")
    
    output.append("")
    
    return "".join(output)


# ========================
# 演示
# ========================

if __name__ == "__main__":
    print("="*50)
    print("家庭教育核心引擎 - 演示")
    print("="*50)
    print("\n底层逻辑：慈悲是体，爱是用；恨比爱更原始")
    
    print("\n" + "-"*50)
    print("示例1：父母说'你再不听话就不要你了'")
    print(full_analysis("你再不听话就不要你了", "parent"))
    
    print("\n" + "-"*50)
    print("示例2：孩子说谎")
    print(full_analysis("说谎", "child"))
