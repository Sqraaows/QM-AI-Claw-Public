#!/usr/bin/env python3
"""
父母的功课 v0.7.0
"""

PATTERNS = [
    ("情感勒索", ["我si给你看", "我不活了"], "🔴高危"),
    ("威胁遗弃", ["我不要你", "我不管你"], "🔴高危"),
    ("受害者诉苦", ["对不起", "我很惨", "我容易吗"], "🟡警告"),
    ("控制要求", ["你必须", "你要是", "你给我"], "🟡警告"),
    ("道德裹挟", ["你不理我", "你不爱我"], "🟡警告"),
]

def analyze(text):
    for name, keywords, level in PATTERNS:
        for kw in keywords:
            if kw in text:
                return name, level
    return None, "🟢正常"

def main():
    print("父母的功课 v0.7.0")
    while True:
        t = input("\n请输入：").strip()
        if t == "quit":
            break
        name, level = analyze(t)
        if name:
            print(f"\n{level} {name}")
        else:
            print("\n🟢正常，继续保持")

if __name__ == "__main__":
    main()
