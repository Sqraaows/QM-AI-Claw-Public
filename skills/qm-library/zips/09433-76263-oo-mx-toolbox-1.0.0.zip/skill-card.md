## Description: <br>
MxToolbox helps agents run DNS, mail, and network diagnostics through an OOMOL-connected MxToolbox account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and support teams use this skill to check DNS, mail authentication, SMTP, HTTP, ping, blacklist, monitor status, and MxToolbox API usage data from an authenticated account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an authenticated OOMOL connector for a MxToolbox account. <br>
Mitigation: Use it only after reviewing the oo CLI login flow and confirming that OOMOL is acceptable as the connector layer for the account. <br>
Risk: Lookup targets and account status or usage results may pass through connected services. <br>
Mitigation: Avoid submitting sensitive internal domains, IP addresses, or account data unless that disclosure is approved for the environment. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>


## Reference(s): <br>
- [MxToolbox Skill on ClawHub](https://clawhub.ai/oomol/oo-mx-toolbox) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [MxToolbox Icon](https://static.oomol.com/logo/third-party/mx_toolbox.svg) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON response guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
