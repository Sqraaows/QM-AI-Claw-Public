## Description: <br>
TPR Framework helps agents use a Think / Probe / Review loop and a three-layer, four-stage workflow to turn complex problems into traceable decisions, GRV plans, reviews, and implementation outputs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[spzwin](https://clawhub.ai/user/spzwin) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, engineers, and agent operators use this skill to structure complex analysis, project planning, GRV drafting, adversarial review, and implementation handoff workflows. It is most useful when a task needs explicit assumptions, recorded disagreements, decision-ready outputs, and traceable reasoning. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The workflow may write project records to disk and persist session history in a way that exposes unrelated private material. <br>
Mitigation: Use a dedicated project directory that does not contain secrets or unrelated private files, and review generated records before sharing them. <br>
Risk: The workflow may pass transcripts or context to sub-agents and recommends external execution tooling. <br>
Mitigation: Use trusted agent runtimes only, review sub-agent prompts and Ralph Loop scripts before running them, and avoid providing sensitive credentials unless required and approved. <br>
Risk: Update-daemon and reset-hook behavior may change expected workflow behavior. <br>
Mitigation: Disable or ignore update-daemon and reset-hook behavior unless explicitly reviewed, and pin trusted versions where possible. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/spzwin/tpr-framework-main) <br>
- [TPR definition](references/definition.md) <br>
- [TPR cognitive loop](references/tpr-cognitive.md) <br>
- [TPR execution workflow](references/tpr-execution.md) <br>
- [GRV standard](references/grv-standard.md) <br>
- [Battle protocol](references/battle-protocol.md) <br>
- [Orchestrator operations](references/orchestrator-ops.md) <br>
- [Output delivery](references/output-delivery.md) <br>
- [Setup](references/setup.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown documents and structured text, sometimes with shell command blocks and local project files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May create or update local project records and workflow outputs during full-process use.] <br>

## Skill Version(s): <br>
2.0.2 (source: server release metadata; artifact changelog lists 3.0.0) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
