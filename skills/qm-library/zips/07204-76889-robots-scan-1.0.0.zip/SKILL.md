---
name: robots-scan
description: C段域名扫描 - 从网站JS文件中快速提取URL和子域名，支持AI安全建议。通过开放模型分析扫描结果，自动识别安全风险并提供针对性的渗透测试建议。
license: MIT
compatibility: opencode
metadata:
  category: security
  tool: script/Robots_Scan.py
  entrypoint: python script/Robots_Scan.py -i
---

# robots-scan - C段域名扫描

从网站JS文件中快速提取URL和子域名的安全信息收集工具。基于正则匹配从内联脚本和外部JS文件中提取所有链接，自动汇聚关联子域名，并可通过大模型生成安全测试建议。

## 功能

| 功能 | 说明 |
|------|------|
| URL提取 | 从网页内联JS和外部JS文件中提取所有URL |
| 子域名提取 | 基于提取的URL自动识别关联子域名 |
| 深度爬取 | 递归爬取页面链接进行更深层提取 |
| AI安全分析 | 接入大模型生成安全测试建议 |
| GUI界面 | Tkinter图形界面，Markdown渲染结果 |
| 批量处理 | 从文件批量读取URL/JS链接扫描 |

## 交互式模式 (OpenCode专属)

在 OpenCode 中直接执行即可进入交互式问答模式：

```
python script/Robots_Scan.py -i
```

也可以通过 OpenCode agent 直接触发：

```
用 JSFinder 扫描 https://target.com
```

### 交互流程

脚本会自动引导你完成以下配置：

1. **[?] 是否启用大模型AI安全建议？** — (y/n) 选择是否生成AI安全分析
2. **[?] 选择LLM厂商** — 1=Ollama(本地) / 2=aliyun_silicon(云API)
3. **[?] 选择模型** — 列出厂商可用模型，或输入自定义名称
4. **[?] API Key** (仅云厂商) — 输入硅基流动的API Key
5. **[?] 输入目标URL** — 必须包含 `http://` 或 `https://`
6. **[?] 深度爬取？** — (y/n) 递归爬取子页面
7. **[?] Cookie** — 可选，认证Cookie
8. **[?] 输出文件路径** — 默认输出到 `output_urls.txt` / `output_subdomains.txt`
9. 确认配置摘要 → 执行扫描 → 显示/AI结果
10. **[?] 保存AI建议** — 默认保存到 `ai_suggestion.md`

## 命令行模式

```bash
# 简单爬取
python script/Robots_Scan.py -u http://www.example.com

# 深度爬取 + 输出文件
python script/Robots_Scan.py -u http://www.example.com -d -ou urls.txt -os subs.txt

# 启用AI建议
python script/Robots_Scan.py -u http://www.example.com -ai -llm ollama

# 批量处理
python script/Robots_Scan.py -f urls.txt

# 解析JS文件列表
python script/Robots_Scan.py -f js_files.txt -j

# GUI模式
python script/Robots_Scan.py -gui
```

## 支持的AI模型

### Ollama (本地部署)
`llama3` `llama3:8b` `llama3:70b` `mistral` `qwen2` `gemma2` `deepseek-r1` `codellama` `phi3`

### 阿里云硅基流动 (云API)
`qwen-plus` `qwen-max` `qwen-turbo` `deepseek-v3` `deepseek-r1` `glm-4` `llama3.1-70b` `mixtral-8x7b`

## 依赖安装

```bash
pip install requests beautifulsoup4 urllib3 tkinterweb
```

Ollama 本地部署：
```bash
ollama pull llama3
```
