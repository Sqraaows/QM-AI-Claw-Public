import os
import re
import sys
import json
import argparse
import urllib3
import requests
from typing import List, Dict, Optional
from urllib.parse import urlparse
from bs4 import BeautifulSoup
from requests.packages import urllib3
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog
import tkinterweb

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class LLMConfig:
    def __init__(self):
        self.config = {
            "ollama": {
                "base_url": "http://localhost:11434",
                "model": "llama3",
                "timeout": 30
            },
            "aliyun_silicon": {
                "api_key": "",
                "secret_key": "",
                "endpoint": "https://siliconflow.cn/api/v1/chat/completions",
                "model": "qwen-plus",
                "timeout": 30
            }
        }

    def get_config(self, vendor: str) -> Dict:
        if vendor not in self.config:
            raise ValueError(f"不支持的厂商：{vendor}，支持的厂商：{list(self.config.keys())}")
        return self.config[vendor]

    def update_config(self, vendor: str, key: str, value: str):
        if vendor in self.config and key in self.config[vendor]:
            self.config[vendor][key] = value

# ===================== LLM客户端模块 =====================
class LLMClient:
    def __init__(self, vendor: str = "ollama", config: LLMConfig = None):
        self.vendor = vendor
        self.config = config or LLMConfig()
        self.client_config = self.config.get_config(vendor)

    def call_ollama(self, prompt: str) -> Optional[str]:
        try:
            resp = requests.post(
                f"{self.client_config['base_url']}/api/generate",
                json={
                    "model": self.client_config["model"],
                    "prompt": prompt,
                    "stream": False
                },
                timeout=self.client_config["timeout"]
            )
            resp.raise_for_status()
            return resp.json().get("response", "").strip()
        except Exception as e:
            return f"Ollama调用失败：{str(e)}"

    def call_aliyun_silicon(self, prompt: str) -> Optional[str]:
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.client_config['api_key']}"
            }
            data = {
                "model": self.client_config["model"],
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7
            }
            resp = requests.post(
                self.client_config["endpoint"],
                headers=headers,
                json=data,
                timeout=self.client_config["timeout"]
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            return f"阿里云硅基流动调用失败：{str(e)}"

    def get_ai_suggestion(self, urls: List[str], subdomains: List[str], target_url: str) -> str:
        prompt = f"""
        请分析以下从 {target_url} 提取到的URL和子域名，给出安全测试建议：
        ## 提取结果
        - URL数量：{len(urls)}
        - 子域名数量：{len(subdomains)}
        - 关键URL示例：{urls[:10] if len(urls) > 10 else urls}
        - 关键子域名示例：{subdomains[:10] if len(subdomains) > 10 else subdomains}
        
        ## 分析要求
        1. 指出可能存在的安全风险点（如未授权访问、接口泄露、子域名接管等）
        2. 给出针对性的测试建议（如目录扫描、参数注入、子域名存活检测等）
        3. 输出格式为Markdown
        """

        if self.vendor == "ollama":
            return self.call_ollama(prompt)
        elif self.vendor == "aliyun_silicon":
            return self.call_aliyun_silicon(prompt)
        else:
            return f"不支持的LLM厂商：{self.vendor}"


class BaseSkill:
    def __init__(self):
        self.name = "BaseSkill"
        self.description = "基础技能接口"

    def execute(self, *args, **kwargs) -> Dict:
        raise NotImplementedError("子类必须实现execute方法")

class ExtractUrlSkill(BaseSkill):
    def __init__(self):
        super().__init__()
        self.name = "ExtractUrlSkill"
        self.description = "从指定URL/JS文件中提取URL和子域名"

    def extract_url(self, js_content: str) -> List[str]:
        pattern_raw = r"""
          (?:"|')
          (
            ((?:[a-zA-Z]{1,10}://|//)
            [^"'/]{1,}\.
            [a-zA-Z]{2,}[^"']{0,})
            |
            ((?:/|\.\./|\./)
            [^"'><,;| *()(%%$^/\\\[\]]
            [^"'><,;|()]{1,})
            |
            ([a-zA-Z0-9_\-/]{1,}/
            [a-zA-Z0-9_\-/]{1,}
            \.(?:[a-zA-Z]{1,4}|action)
            (?:[\?|/][^"|']{0,}|))
            |
            ([a-zA-Z0-9_\-]{1,}
            \.(?:php|asp|aspx|jsp|json|
                 action|html|js|txt|xml)
            (?:\?[^"|']{0,}|))
          )
          (?:"|')
        """
        pattern = re.compile(pattern_raw, re.VERBOSE)
        matches = re.finditer(pattern, str(js_content))
        return [match.group().strip('"').strip("'") for match in matches]

    def get_html_content(self, url: str, cookie: str = "") -> Optional[str]:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Cookie": cookie
        }
        try:
            resp = requests.get(url, headers=headers, timeout=3, verify=False)
            return resp.content.decode("utf-8", "ignore")
        except Exception:
            return None

    def process_url(self, base_url: str, raw_url: str) -> str:
        black_url = ["javascript:"]
        if raw_url in black_url:
            return base_url

        url_parsed = urlparse(base_url)
        scheme = url_parsed.scheme
        netloc = url_parsed.netloc

        if raw_url.startswith("//"):
            return f"{scheme}:{raw_url}"
        elif raw_url.startswith("http"):
            return raw_url
        elif raw_url.startswith("/"):
            return f"{scheme}://{netloc}{raw_url}"
        elif raw_url.startswith("./"):
            return f"{scheme}://{netloc}{raw_url[1:]}"
        elif raw_url.startswith("../"):
            return f"{scheme}://{netloc}{raw_url[2:]}"
        else:
            return f"{scheme}://{netloc}/{raw_url}"

    def find_last(self, string: str, substr: str) -> List[int]:
        positions = []
        last_pos = -1
        while True:
            pos = string.find(substr, last_pos + 1)
            if pos == -1:
                break
            last_pos = pos
            positions.append(pos)
        return positions

    def extract_from_single_url(self, url: str, cookie: str = "") -> List[str]:
        html_content = self.get_html_content(url, cookie)
        if not html_content:
            return []

        soup = BeautifulSoup(html_content, "html.parser")
        scripts = soup.findAll("script")
        script_map = {}
        inline_script = ""

        for script in scripts:
            script_src = script.get("src")
            if not script_src:
                inline_script += script.get_text() + "\n"
            else:
                full_src = self.process_url(url, script_src)
                script_map[full_src] = self.get_html_content(full_src, cookie)

        script_map[url] = inline_script
        all_urls = []

        for script_url, script_content in script_map.items():
            if not script_content:
                continue
            raw_urls = self.extract_url(script_content)
            for raw_url in raw_urls:
                full_url = self.process_url(script_url, raw_url)
                all_urls.append(full_url)

        unique_urls = []
        url_parsed = urlparse(url)
        main_domain = url_parsed.netloc
        positions = self.find_last(main_domain, ".")
        if len(positions) > 1:
            main_domain = main_domain[positions[-2] + 1:]

        for full_url in set(all_urls):
            sub_parsed = urlparse(full_url)
            if main_domain in sub_parsed.netloc or not sub_parsed.netloc:
                if full_url not in unique_urls:
                    unique_urls.append(full_url)

        return unique_urls

    def extract_deep(self, url: str, cookie: str = "") -> List[str]:
        html_content = self.get_html_content(url, cookie)
        if not html_content:
            return []

        soup = BeautifulSoup(html_content, "html.parser")
        links = []
        for a_tag in soup.findAll("a"):
            href = a_tag.get("href")
            if not href:
                continue
            full_href = self.process_url(url, href)
            if full_href not in links:
                links.append(full_href)

        all_urls = []
        for link in links:
            link_urls = self.extract_from_single_url(link, cookie)
            all_urls.extend(link_urls)

        return list(set(all_urls))

    def extract_subdomain(self, urls: List[str], main_url: str) -> List[str]:
        subdomains = []
        main_parsed = urlparse(main_url)
        main_domain = main_parsed.netloc
        positions = self.find_last(main_domain, ".")

        if len(positions) > 1:
            main_domain = main_domain[positions[-2] + 1:]

        for url in urls:
            parsed = urlparse(url)
            subdomain = parsed.netloc
            if not subdomain:
                continue
            if main_domain in subdomain and subdomain not in subdomains:
                subdomains.append(subdomain)

        return subdomains

    def execute(self, url: str, cookie: str = "", deep: bool = False, file_path: str = "", is_js: bool = False) -> Dict:
        try:
            if file_path:
                with open(file_path, "r", encoding="utf-8") as f:
                    links = [line.strip() for line in f if line.strip()]

                all_urls = []
                for link in links:
                    if is_js:
                        js_content = self.get_html_content(link, cookie)
                        raw_urls = self.extract_url(js_content) if js_content else []
                        urls = [self.process_url(link, u) for u in raw_urls]
                    else:
                        urls = self.extract_from_single_url(link, cookie)
                    all_urls.extend(urls)
            else:
                if deep:
                    all_urls = self.extract_deep(url, cookie)
                else:
                    all_urls = self.extract_from_single_url(url, cookie)

            main_url_target = url if not file_path else links[0] if links else ""
            subdomains = self.extract_subdomain(all_urls, main_url_target)

            return {
                "status": "success",
                "urls": all_urls,
                "subdomains": subdomains,
                "message": f"提取完成：URL({len(all_urls)})，子域名({len(subdomains)})"
            }
        except Exception as e:
            return {
                "status": "failed",
                "urls": [],
                "subdomains": [],
                "message": f"提取失败：{str(e)}"
            }

class AIAnalyzeSkill(BaseSkill):
    def __init__(self, llm_vendor: str = "ollama"):
        super().__init__()
        self.name = "AIAnalyzeSkill"
        self.description = "基于大模型分析提取结果并给出安全建议"
        self.llm_client = LLMClient(vendor=llm_vendor)

    def execute(self, urls: List[str], subdomains: List[str], target_url: str) -> Dict:
        try:
            suggestion = self.llm_client.get_ai_suggestion(urls, subdomains, target_url)
            return {
                "status": "success",
                "suggestion": suggestion,
                "message": "AI建议生成完成"
            }
        except Exception as e:
            return {
                "status": "failed",
                "suggestion": "",
                "message": f"AI分析失败：{str(e)}"
            }

# ===================== GUI模块 =====================
class JSFinderGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("JSFinder Pro - 28.7")
        self.root.geometry("1200x800")

        self.extract_skill = ExtractUrlSkill()
        self.llm_config = LLMConfig()

        self.current_result = {"urls": [], "subdomains": []}

        self._create_widgets()

    def _create_widgets(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        config_frame = ttk.LabelFrame(main_frame, text="配置", padding="5")
        config_frame.pack(fill=tk.X, pady=5)

        ttk.Label(config_frame, text="目标:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.url_entry = ttk.Entry(config_frame, width=50)
        self.url_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        self.file_btn = ttk.Button(config_frame, text="选择文件", command=self._select_file)
        self.file_btn.grid(row=0, column=2, padx=5, pady=5)

        ttk.Label(config_frame, text="Cookie:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.cookie_entry = ttk.Entry(config_frame, width=50)
        self.cookie_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)

        self.deep_var = tk.BooleanVar()
        self.deep_check = ttk.Checkbutton(config_frame, text="深度爬取", variable=self.deep_var)
        self.deep_check.grid(row=1, column=2, padx=5, pady=5)

        self.js_var = tk.BooleanVar()
        self.js_check = ttk.Checkbutton(config_frame, text="仅解析JS文件", variable=self.js_var)
        self.js_check.grid(row=1, column=3, padx=5, pady=5)

        llm_frame = ttk.LabelFrame(config_frame, text="大模型配置", padding="5")
        llm_frame.grid(row=0, column=3, rowspan=2, padx=10, pady=5, sticky=tk.NS)

        ttk.Label(llm_frame, text="厂商:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.llm_vendor = ttk.Combobox(llm_frame, values=["ollama", "aliyun_silicon"], width=15)
        self.llm_vendor.set("ollama")
        self.llm_vendor.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(llm_frame, text="模型:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.llm_model = ttk.Entry(llm_frame, width=15)
        self.llm_model.insert(0, "llama3")
        self.llm_model.grid(row=1, column=1, padx=5, pady=5)

        self.ai_switch = tk.BooleanVar(value=True)
        self.ai_check = ttk.Checkbutton(llm_frame, text="启用AI建议", variable=self.ai_switch)
        self.ai_check.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=5)

        self.extract_btn = ttk.Button(btn_frame, text="开始提取", command=self._extract)
        self.extract_btn.pack(side=tk.LEFT, padx=5)

        self.save_btn = ttk.Button(btn_frame, text="保存结果", command=self._save_result)
        self.save_btn.pack(side=tk.LEFT, padx=5)

        self.clear_btn = ttk.Button(btn_frame, text="清空", command=self._clear)
        self.clear_btn.pack(side=tk.LEFT, padx=5)

        tab_control = ttk.Notebook(main_frame)

        self.url_tab = tkinterweb.HtmlFrame(tab_control, messages_enabled=False)
        tab_control.add(self.url_tab, text="URL列表")

        self.subdomain_tab = tkinterweb.HtmlFrame(tab_control, messages_enabled=False)
        tab_control.add(self.subdomain_tab, text="子域名列表")

        self.ai_tab = tkinterweb.HtmlFrame(tab_control, messages_enabled=False)
        tab_control.add(self.ai_tab, text="AI安全建议")

        tab_control.pack(fill=tk.BOTH, expand=True, pady=5)

    def _select_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")])
        if file_path:
            self.url_entry.delete(0, tk.END)
            self.url_entry.insert(0, file_path)

    def _render_markdown(self, frame, content):
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <style>
                body {{ font-family: Consolas, monospace; font-size: 12px; line-height: 1.5; }}
                h1 {{ font-size: 16px; color: #2c3e50; }}
                h2 {{ font-size: 14px; color: #34495e; }}
                ul {{ margin: 5px 0; padding-left: 20px; }}
                li {{ margin: 3px 0; }}
            </style>
        </head>
        <body>
            {self._markdown_to_html(content)}
        </body>
        </html>
        """
        frame.load_html(html_content)

    def _markdown_to_html(self, md_text):
        md_text = md_text.replace("\n", "<br>")
        md_text = re.sub(r"^## (.*)", r"<h2>\1</h2>", md_text, flags=re.M)
        md_text = re.sub(r"^# (.*)", r"<h1>\1</h1>", md_text, flags=re.M)
        md_text = re.sub(r"^- (.*)", r"<li>\1</li>", md_text, flags=re.M)
        md_text = re.sub(r"<li>.*</li>", r"<ul>\g<0></ul>", md_text)
        return md_text

    def _extract(self):
        target = self.url_entry.get().strip()
        if not target:
            self._render_markdown(self.url_tab, "# 错误\n- 请输入目标URL或选择文件")
            return

        cookie = self.cookie_entry.get().strip()
        deep = self.deep_var.get()
        is_js = self.js_var.get()
        is_file = os.path.isfile(target)

        extract_result = self.extract_skill.execute(
            url=target if not is_file else "",
            cookie=cookie,
            deep=deep,
            file_path=target if is_file else "",
            is_js=is_js
        )

        if extract_result["status"] == "failed":
            self._render_markdown(self.url_tab, f"# 提取失败\n- {extract_result['message']}")
            return

        self.current_result = extract_result

        url_md = f"# URL提取结果（{len(extract_result['urls'])}）\n" + "\n".join([f"- {url}" for url in extract_result['urls']])
        self._render_markdown(self.url_tab, url_md)

        subdomain_md = f"# 子域名提取结果（{len(extract_result['subdomains'])}）\n" + "\n".join([f"- {domain}" for domain in extract_result['subdomains']])
        self._render_markdown(self.subdomain_tab, subdomain_md)

        if self.ai_switch.get():
            ai_skill = AIAnalyzeSkill(llm_vendor=self.llm_vendor.get())
            ai_result = ai_skill.execute(
                urls=extract_result['urls'],
                subdomains=extract_result['subdomains'],
                target_url=target
            )
            ai_md = ai_result['suggestion'] if ai_result['status'] == "success" else f"# AI分析失败\n- {ai_result['message']}"
            self._render_markdown(self.ai_tab, ai_md)

    def _save_result(self):
        if not self.current_result["urls"]:
            self._render_markdown(self.url_tab, "# 错误\n- 暂无提取结果可保存")
            return

        save_dir = filedialog.askdirectory(title="选择保存目录")
        if not save_dir:
            return

        url_path = os.path.join(save_dir, "jsfinder_urls.txt")
        with open(url_path, "w", encoding="utf-8") as f:
            f.write("\n".join(self.current_result["urls"]))

        subdomain_path = os.path.join(save_dir, "jsfinder_subdomains.txt")
        with open(subdomain_path, "w", encoding="utf-8") as f:
            f.write("\n".join(self.current_result["subdomains"]))

        ai_html = self.ai_tab.get_html()
        if ai_html and "AI安全建议" in ai_html:
            ai_path = os.path.join(save_dir, "jsfinder_ai_suggestion.md")
            with open(ai_path, "w", encoding="utf-8") as f:
                ai_text = ai_html.replace("<br>", "\n").replace("<h1>", "# ").replace("</h1>", "").replace("<h2>", "## ").replace("</h2>", "")
                ai_text = re.sub(r"<li>(.*?)</li>", r"- \1", ai_text)
                ai_text = re.sub(r"</?ul>", "", ai_text)
                f.write(ai_text)

        self._render_markdown(self.url_tab, f"# 保存成功\n- URL: {url_path}\n- 子域名: {subdomain_path}\n- AI建议: {ai_path if 'ai_path' in locals() else '无'}")

    def _clear(self):
        self.url_entry.delete(0, tk.END)
        self.cookie_entry.delete(0, tk.END)
        self.deep_var.set(False)
        self.js_var.set(False)
        self._render_markdown(self.url_tab, "")
        self._render_markdown(self.subdomain_tab, "")
        self._render_markdown(self.ai_tab, "")
        self.current_result = {"urls": [], "subdomains": []}

# ===================== 交互式CLI模式 =====================
INTERACTIVE_BANNER = r"""
=============================================
   JSFinder Pro - 交互式C段域名扫描
=============================================
"""

LLM_MODELS = {
    "ollama": ["llama3", "llama3:8b", "llama3:70b", "mistral", "qwen2", "gemma2", "deepseek-r1", "codellama", "phi3"],
    "aliyun_silicon": ["qwen-plus", "qwen-max", "qwen-turbo", "deepseek-v3", "deepseek-r1", "glm-4", "llama3.1-70b", "mixtral-8x7b"]
}

def interactive_mode():
    print(INTERACTIVE_BANNER)

    # ===== 1. 是否启用AI =====
    while True:
        enable_ai = input("[?] 是否启用大模型AI安全建议？(y/n, 默认=n): ").strip().lower()
        if enable_ai == "":
            enable_ai = "n"
        if enable_ai in ("y", "n", "yes", "no"):
            enable_ai = enable_ai in ("y", "yes")
            break
        print("[!] 请输入 y 或 n")

    ai_vendor = "ollama"
    ai_model = "llama3"

    if enable_ai:
        # ===== 2. 选择LLM厂商 =====
        print("\n[+] 可用LLM厂商:")
        print("    1. ollama (本地部署)")
        print("    2. aliyun_silicon (阿里云硅基流动API)")
        while True:
            vendor_choice = input("[?] 请选择厂商 (1/2, 默认=1): ").strip()
            if vendor_choice == "":
                vendor_choice = "1"
            if vendor_choice in ("1", "2"):
                ai_vendor = "ollama" if vendor_choice == "1" else "aliyun_silicon"
                break
            print("[!] 请输入 1 或 2")

        # ===== 3. 选择模型 =====
        print(f"\n[+] [{ai_vendor}] 可用模型:")
        models = LLM_MODELS.get(ai_vendor, [])
        for i, m in enumerate(models, 1):
            print(f"    {i}. {m}")
        print(f"    0. 自定义模型名称")

        while True:
            model_choice = input(f"[?] 请选择模型 (1-{len(models)} 或 0, 默认=1): ").strip()
            if model_choice == "":
                model_choice = "1"
            try:
                choice_num = int(model_choice)
                if choice_num == 0:
                    ai_model = input("[?] 请输入自定义模型名称: ").strip()
                    if ai_model:
                        break
                    print("[!] 模型名称不能为空")
                elif 1 <= choice_num <= len(models):
                    ai_model = models[choice_num - 1]
                    break
                else:
                    print(f"[!] 请输入 0-{len(models)} 之间的数字")
            except ValueError:
                print("[!] 请输入有效数字")

        if ai_vendor == "aliyun_silicon":
            api_key = input("[?] 请输入API Key (留空使用默认): ").strip()
            if api_key:
                config = LLMConfig()
                config.update_config("aliyun_silicon", "api_key", api_key)

    # ===== 4. 目标URL =====
    print("\n" + "-" * 40)
    while True:
        target = input("[?] 请输入目标URL (需含 http:// 或 https://): ").strip()
        if not target:
            print("[!] 目标URL不能为空")
            continue
        if target.startswith("http://") or target.startswith("https://"):
            break
        print("[!] URL必须以 http:// 或 https:// 开头")

    # ===== 5. 深度爬取 =====
    while True:
        deep_choice = input("[?] 是否启用深度爬取？(y/n, 默认=n): ").strip().lower()
        if deep_choice == "":
            deep_choice = "n"
        if deep_choice in ("y", "n", "yes", "no"):
            deep = deep_choice in ("y", "yes")
            break
        print("[!] 请输入 y 或 n")

    # ===== 6. Cookie =====
    cookie = input("[?] 请输入Cookie (可选，直接回车跳过): ").strip()

    # ===== 7. 输出文件 =====
    default_ourl = os.path.join(PROJECT_DIR, "output_urls.txt")
    default_osub = os.path.join(PROJECT_DIR, "output_subdomains.txt")
    output_url = input(f"[?] URL输出文件 (默认={default_ourl}): ").strip() or default_ourl
    output_subdomain = input(f"[?] 子域名输出文件 (默认={default_osub}): ").strip() or default_osub

    # ===== 8. 确认并执行 =====
    print("\n" + "=" * 40)
    print("[+] 配置确认:")
    print(f"    目标URL: {target}")
    print(f"    深度爬取: {'是' if deep else '否'}")
    print(f"    Cookie: {'已设置' if cookie else '无'}")
    print(f"    启用AI: {'是' if enable_ai else '否'}")
    if enable_ai:
        print(f"    AI厂商: {ai_vendor}")
        print(f"    AI模型: {ai_model}")
    print(f"    URL输出: {output_url}")
    print(f"    子域名输出: {output_subdomain}")
    print("=" * 40)

    confirm = input("[?] 确认开始扫描？(y/n, 默认=y): ").strip().lower()
    if confirm not in ("", "y", "yes"):
        print("[*] 已取消扫描")
        return

    # ===== 9. 执行扫描 =====
    print("\n[*] 正在扫描中，请稍候...\n")

    extract_skill = ExtractUrlSkill()
    result = extract_skill.execute(
        url=target,
        cookie=cookie,
        deep=deep,
        file_path="",
        is_js=False
    )

    if result["status"] == "failed":
        print(f"[!] 错误: {result['message']}")
        return

    print(f"[+] Find {len(result['urls'])} URL:")
    for url in result['urls']:
        print(f"    {url}")

    print(f"\n[+] Find {len(result['subdomains'])} Subdomain:")
    for subdomain in result['subdomains']:
        print(f"    {subdomain}")

    if output_url:
        os.makedirs(os.path.dirname(output_url) or PROJECT_DIR, exist_ok=True)
        with open(output_url, "w", encoding="utf-8") as f:
            f.write("\n".join(result['urls']))
        print(f"\n[*] URL已保存到: {output_url}")

    if output_subdomain:
        os.makedirs(os.path.dirname(output_subdomain) or PROJECT_DIR, exist_ok=True)
        with open(output_subdomain, "w", encoding="utf-8") as f:
            f.write("\n".join(result['subdomains']))
        print(f"[*] 子域名已保存到: {output_subdomain}")

    if enable_ai:
        llm_config = LLMConfig()
        llm_config.update_config(ai_vendor, "model", ai_model)

        print("\n[*] 正在调用AI生成安全建议...")
        ai_client = LLMClient(vendor=ai_vendor, config=llm_config)
        ai_client.client_config["model"] = ai_model

        ai_result = ai_client.get_ai_suggestion(
            urls=result['urls'],
            subdomains=result['subdomains'],
            target_url=target
        )
        print("\n=== AI安全建议 ===")
        print(ai_result)

        default_ai = os.path.join(PROJECT_DIR, "ai_suggestion.md")
        ai_output = input(f"\n[?] 保存AI建议到文件 (默认={default_ai}): ").strip() or default_ai
        with open(ai_output, "w", encoding="utf-8") as f:
            f.write(ai_result)
        print(f"[*] AI建议已保存到: {ai_output}")

    print("\n[*] 扫描完成！")

# ===================== 命令行模式 =====================
def cli_mode(args):
    extract_skill = ExtractUrlSkill()
    result = extract_skill.execute(
        url=args.url or "",
        cookie=args.cookie or "",
        deep=args.deep,
        file_path=args.file or "",
        is_js=args.js
    )

    if result["status"] == "failed":
        print(f"错误: {result['message']}")
        return

    print(f"Find {len(result['urls'])} URL:")
    for url in result['urls']:
        print(url)

    print(f"\nFind {len(result['subdomains'])} Subdomain:")
    for subdomain in result['subdomains']:
        print(subdomain)

    if args.outputurl:
        with open(args.outputurl, "w", encoding="utf-8") as f:
            f.write("\n".join(result['urls']))
        print(f"\nURL已保存到: {args.outputurl}")

    if args.outputsubdomain:
        with open(args.outputsubdomain, "w", encoding="utf-8") as f:
            f.write("\n".join(result['subdomains']))
        print(f"子域名已保存到: {args.outputsubdomain}")

    if args.ai:
        ai_skill = AIAnalyzeSkill(llm_vendor=args.llm_vendor)
        ai_result = ai_skill.execute(
            urls=result['urls'],
            subdomains=result['subdomains'],
            target_url=args.url or args.file
        )
        print("\n=== AI安全建议 ===")
        print(ai_result['suggestion'] if ai_result['status'] == "success" else ai_result['message'])

# ===================== 主程序入口 =====================
def main():
    parser = argparse.ArgumentParser(
        epilog='\tExample: \r\npython ' + __file__ + " -u http://www.baidu.com"
    )
    parser.add_argument("-u", "--url", help="目标网站URL")
    parser.add_argument("-c", "--cookie", help="请求Cookie")
    parser.add_argument("-f", "--file", help="包含URL/JS的文件路径")
    parser.add_argument("-ou", "--outputurl", help="URL输出文件")
    parser.add_argument("-os", "--outputsubdomain", help="子域名输出文件")
    parser.add_argument("-j", "--js", help="仅解析JS文件", action="store_true")
    parser.add_argument("-d", "--deep", help="深度爬取", action="store_true")
    parser.add_argument("-gui", "--gui", help="启动图形界面", action="store_true")
    parser.add_argument("-ai", "--ai", help="启用AI建议（需配置LLM）", action="store_true")
    parser.add_argument("-llm", "--llm-vendor", help="LLM厂商（ollama/aliyun_silicon）", default="ollama")
    parser.add_argument("-i", "--interactive", help="启动交互式模式", action="store_true")

    args = parser.parse_args()

    if args.gui:
        root = tk.Tk()
        app = JSFinderGUI(root)
        root.mainloop()
        return

    if args.interactive:
        interactive_mode()
        return

    if not args.url and not args.file:
        parser.print_help()
        return

    cli_mode(args)

if __name__ == "__main__":
    main()
