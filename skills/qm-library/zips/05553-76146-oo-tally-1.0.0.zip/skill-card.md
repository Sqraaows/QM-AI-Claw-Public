## Description: <br>
Tally helps an agent search and read Tally forms and submissions through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, teams, and developers use this skill to list Tally forms, inspect form details, list submissions, and retrieve individual submissions through the oo CLI after connecting Tally in OOMOL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to Tally data through a connected OOMOL account. <br>
Mitigation: Install only when the agent is allowed to access the relevant Tally forms and submissions, and keep account permissions scoped to the intended workspace. <br>
Risk: The release is read-oriented, but its safety text mentions create, update, delete, send, and post actions that could change Tally state if connector capabilities expand. <br>
Mitigation: Treat routine use as limited to get and list actions; require explicit user confirmation before any create, update, delete, post, send, webhook, or submission-changing request. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live connector schema before constructing a payload, then ensure the request matches the current schema before execution. <br>


## Reference(s): <br>
- [ClawHub Tally skill page](https://clawhub.ai/oomol/oo-tally) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Tally homepage](https://tally.so) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
