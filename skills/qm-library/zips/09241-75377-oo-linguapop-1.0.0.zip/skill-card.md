## Description: <br>
Linguapop helps agents operate a connected Linguapop account through OOMOL's oo CLI to list placement test languages and create candidate invitations. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external operators, and developers use this skill to operate a connected Linguapop account from an agent workflow. It supports listing placement test languages and creating candidate invitations after confirming write payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL and Linguapop account and can operate with sensitive account access. <br>
Mitigation: Install and use it only when you intend to connect OOMOL to the target Linguapop account, and rely on the documented account connection flow. <br>
Risk: The send_invitation action changes Linguapop state and may send email or configure callback and return URLs. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running the action, especially recipient email, callback or return URLs, and whether email delivery is enabled. <br>
Risk: Installing the oo CLI adds a local command-line dependency from OOMOL. <br>
Mitigation: Use the documented installer only if you trust OOMOL as the CLI provider, and avoid running setup steps unless an action fails for the matching reason. <br>


## Reference(s): <br>
- [ClawHub Linguapop Skill](https://clawhub.ai/oomol/oo-linguapop) <br>
- [Linguapop Homepage](https://www.linguapop.eu/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an OOMOL sign-in, a connected Linguapop account, and live connector schema inspection before action execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
