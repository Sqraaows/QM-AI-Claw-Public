## Description: <br>
Chatwork (go.chatwork.com). Use this skill for ANY Chatwork request: reading, creating, updating, and deleting data through an OOMOL-connected Chatwork account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents with connected Chatwork accounts use this skill to read Chatwork profile, contact, room, member, message, and task data. They can also create tasks, post or update messages, update task status, and delete messages after confirming changes with the user. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Chatwork account and uses credentials through OOMOL's connector path. <br>
Mitigation: Install only when the publisher and connector path are trusted for the target Chatwork account. <br>
Risk: Posting, updating, creating tasks, or deleting messages can change shared Chatwork data. <br>
Mitigation: Review the exact action, target, and payload with the user before approving write or destructive operations. <br>


## Reference(s): <br>
- [Chatwork homepage](https://go.chatwork.com) <br>
- [ClawHub Chatwork skill](https://clawhub.ai/oomol/oo-chatwork) <br>
- [OOMOL user profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution and returns authenticated connector responses as JSON when actions run.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
