## Description: <br>
MinerU lets an agent operate MinerU through an OOMOL-connected account to create extraction tasks or batches and retrieve extraction status and result URLs. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to run MinerU document extraction workflows through an OOMOL-connected account. It helps create single or batch extraction jobs, inspect live connector schemas, and retrieve extraction status and result URLs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OOMOL account and sensitive service credentials. <br>
Mitigation: Install and use it only when the user trusts OOMOL and the connected MinerU account. <br>
Risk: First-time setup may involve running an OOMOL CLI installer. <br>
Mitigation: Prefer the official install guide or inspect the installer before running it. <br>
Risk: Create actions can change MinerU account data. <br>
Mitigation: Confirm the exact payload and intended effect before running create, update, send, post, delete, or other state-changing actions. <br>


## Reference(s): <br>
- [MinerU homepage](https://mineru.net) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-mineru) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [create_extract_task action](actions/create_extract_task.md) <br>
- [create_extract_batch action](actions/create_extract_batch.md) <br>
- [get_extract_task action](actions/get_extract_task.md) <br>
- [get_extract_batch_results action](actions/get_extract_batch_results.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; connector responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
