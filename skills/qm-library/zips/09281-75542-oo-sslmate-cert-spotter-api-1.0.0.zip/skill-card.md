## Description: <br>
Cert Spotter lets an agent read certificate transparency issuances and manage monitored domain configurations in a connected Cert Spotter account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, security teams, and operators use this skill to query Cert Spotter certificate issuance data and inspect, create, update, or delete monitored domains in a connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, or delete Cert Spotter monitored-domain settings. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write or delete actions. <br>
Risk: The skill requires access to a connected Cert Spotter account with sensitive credentials. <br>
Mitigation: Install only for intended Cert Spotter use, keep credentials managed through the approved connection flow, and prefer verified oo CLI installation sources. <br>


## Reference(s): <br>
- [Cert Spotter homepage](https://sslmate.com/certspotter/) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-sslmate-cert-spotter-api) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, JSON] <br>
**Output Format:** [Markdown guidance with bash commands and JSON payloads or results] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before payload construction; connector responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
