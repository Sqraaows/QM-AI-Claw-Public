## Description: <br>
This skill helps agents run Scrapfly scraping and monitoring actions through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and data teams use this skill to scrape a public URL through Scrapfly or retrieve monitoring metrics for a connected Scrapfly API key via the OOMOL oo CLI workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connecting a Scrapfly API key through OOMOL before actions can run. <br>
Mitigation: Confirm trust in OOMOL and the connected Scrapfly account before installing or using the skill. <br>
Risk: Scrape requests may target URLs the user is not authorized to access. <br>
Mitigation: Run scrape actions only against public or otherwise authorized URLs. <br>
Risk: The workflow may require installing or using the oo CLI. <br>
Mitigation: Review the oo CLI installer and command payloads before execution, especially on first setup. <br>


## Reference(s): <br>
- [Scrapfly homepage](https://scrapfly.io/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-scrapfly) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON envelopes from the oo connector run command.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
