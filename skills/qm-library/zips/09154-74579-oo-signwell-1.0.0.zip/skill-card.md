## Description: <br>
SignWell (signwell.com). Use this skill for ANY SignWell request - reading, creating, and updating data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate SignWell through OOMOL, including account lookup, document and template retrieval, document creation from templates, sending drafts for signing, and sending reminders. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create documents, send draft documents for signing, and send reminder emails through a connected SignWell account. <br>
Mitigation: Confirm the exact payload, recipient set, and intended effect with the user before running create, send, or reminder actions. <br>
Risk: The skill depends on a connected OOMOL SignWell account and can act with that account's permissions. <br>
Mitigation: Install only when the agent is intended to use the connected SignWell account, and review account permissions before use. <br>


## Reference(s): <br>
- [SignWell homepage](https://www.signwell.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; connector responses are JSON objects with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release version and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
