## Description: <br>
Logo.dev helps agents search brands, fetch brand metadata, and build Logo.dev logo image URLs through OOMOL's connected Logo.dev account workflow. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, designers, and external agents use this skill to discover brands, retrieve Logo.dev brand metadata, and construct logo image URLs by domain, name, ticker, ISIN, or crypto symbol. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on an OOMOL-connected Logo.dev account and may require API credentials to be connected through the intended account flow. <br>
Mitigation: Review the oo CLI and OOMOL connection setup before first use, and only provide or connect API credentials through the intended OOMOL account flow. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live action schema with the documented oo connector schema command before constructing action payloads. <br>


## Reference(s): <br>
- [Logo.dev homepage](https://logo.dev) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-logo-dev) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects that include data and meta.executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
