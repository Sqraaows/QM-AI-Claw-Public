## Description: <br>
Twelve Data lets agents search and read financial market data through an OOMOL-connected Twelve Data account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Twelve Data connector schemas and run read-only market-data actions for prices, quotes, company profiles, symbol search, market state, exchanges, forex pairs, market movers, and historical time series. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Running setup commands or connector actions without the intended account connection can trigger authentication, connection, or billing failures. <br>
Mitigation: Run install, login, or Twelve Data connection steps only when a matching command failure occurs, and review optional setup steps before executing them. <br>
Risk: Market-data queries may consume Twelve Data or OOMOL account quota, credits, or billing capacity. <br>
Mitigation: Use the skill only for intended market-data lookups and consider quota or credit impact before repeated or broad queries. <br>
Risk: Upstream connector schemas and defaults can change, causing incorrect payloads or stale assumptions. <br>
Mitigation: Inspect the live action schema with `oo connector schema` before constructing each action payload. <br>
Risk: Financial market data returned by the connector may be incomplete, delayed, or unsuitable as standalone investment advice. <br>
Mitigation: Treat results as informational data and verify important financial decisions against authoritative sources and applicable policies. <br>


## Reference(s): <br>
- [ClawHub package page](https://clawhub.ai/oomol/oo-twelve-data) <br>
- [Twelve Data homepage](https://twelvedata.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown with bash commands and JSON payload or response guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an OOMOL sign-in, and a connected Twelve Data credential; connector responses are returned as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
