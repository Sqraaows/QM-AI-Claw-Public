## Description: <br>
FFHub helps agents operate FFHub through an OOMOL-connected account to create, inspect, and list FFmpeg transcoding tasks. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and media automation teams use this skill to manage FFHub FFmpeg transcoding tasks through the OOMOL `oo` CLI without handling raw FFHub credentials. It supports creating a transcoding task, checking one task, and listing tasks with optional filters. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create FFHub tasks that change service state and may consume account credits. <br>
Mitigation: Review the create task payload and intended effect with the user before running the action, and treat billing-related failures as a stop until the account is recharged. <br>
Risk: The skill requires an OOMOL-connected FFHub account and therefore gives the agent access to operate that connected service. <br>
Mitigation: Install it only when the user intends to let the agent operate FFHub through OOMOL, and rely on OOMOL's connector flow rather than exposing raw credentials. <br>
Risk: First-time setup examples include remote installer commands. <br>
Mitigation: Prefer a verified guide or package manager for installing the `oo` CLI before using remote shell installer commands. <br>


## Reference(s): <br>
- [FFHub homepage](https://ffhub.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-ffhub) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The agent should inspect the live connector schema before building action payloads and should confirm state-changing task creation with the user.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
