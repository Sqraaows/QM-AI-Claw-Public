## Description: <br>
Enables agents to create images from HTML, CSS, or public webpage URLs, delete generated images, and retrieve usage counts through HTML/CSS to Image. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and design automation users can ask an agent to render images from HTML/CSS or webpage URLs, manage generated images, and check HTML/CSS to Image account usage through an OOMOL-connected workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can perform state-changing create and delete actions in a connected HTML/CSS to Image account. <br>
Mitigation: Review the exact JSON payload and intended effect before approving create actions, and approve delete actions only when the target image or batch is clear. <br>
Risk: The skill requires account access through OOMOL to operate the HTML/CSS to Image service. <br>
Mitigation: Install it only when the user intends to let the agent operate that account, and use the documented setup flow only after an authentication or connection failure. <br>


## Reference(s): <br>
- [HTML/CSS to Image homepage](https://htmlcsstoimage.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-htmlcsstoimage) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing payloads and returns service responses as JSON when actions run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
