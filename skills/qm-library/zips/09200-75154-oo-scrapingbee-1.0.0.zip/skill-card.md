## Description: <br>
ScrapingBee helps agents fetch HTML, extract structured data, and retrieve usage statistics through an OOMOL-connected ScrapingBee account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate ScrapingBee scraping workflows through the oo CLI without handling raw ScrapingBee tokens directly. It supports public URL HTML retrieval, structured extraction with extract_rules, and account usage checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on OOMOL as the credential broker for ScrapingBee. <br>
Mitigation: Confirm the OOMOL credential flow is approved for the account and review or install the oo CLI through a trusted method before use. <br>
Risk: Scraping tasks can retrieve page content from public URLs and may expose sensitive content if used on private or internal pages. <br>
Mitigation: Use the skill only for intended ScrapingBee tasks and avoid private URLs or sensitive page content unless the account setup is approved for that data. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ScrapingBee homepage](https://www.scrapingbee.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-scrapingbee) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action payload construction; ScrapingBee responses may include HTML, extracted JSON, or usage statistics.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
