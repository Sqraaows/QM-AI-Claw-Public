## Description: <br>
Operate Beamer through an OOMOL-connected account to list posts, count unread posts, retrieve feed URLs, and create changelog posts. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, product teams, and support teams use this skill to operate Beamer content and feed workflows from an agent through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates a connected Beamer account and requires sensitive credentials managed through OOMOL. <br>
Mitigation: Install only when the publisher and connected account are trusted, and keep Beamer access scoped to the intended workspace. <br>
Risk: Creating posts changes Beamer content visible to the configured audience. <br>
Mitigation: Review and approve the exact create-post payload and intended effect before running write actions. <br>
Risk: Remote installer commands can be risky if copied or executed without review. <br>
Mitigation: Install the oo CLI through a trusted documented method and verify installation commands before running them. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-beamer) <br>
- [Beamer homepage](https://www.getbeamer.com) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Beamer connection](https://console.oomol.com/app-connections?provider=beamer) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Reads and writes Beamer data through the oo CLI; write actions require payload review before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
