## Description: <br>
Operates a connected SendGrid account through the OOMOL oo connector to inspect account details, list API key scopes and transactional templates, and send transactional email. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and marketing teams use this skill to work with a connected SendGrid account from an agent workflow, including account inspection, credential scope review, transactional template discovery, and transactional email sending. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send real outbound transactional email through SendGrid. <br>
Mitigation: Review and confirm recipients, sender details, subject, body, and intended effect before running send actions. <br>
Risk: The skill requires a connected SendGrid credential and depends on OOMOL's oo CLI workflow. <br>
Mitigation: Install only when the publisher and CLI are trusted, and grant only the SendGrid scopes required for the planned workflow. <br>
Risk: Account, credential scope, and template inspection can reveal operational details about the connected SendGrid account. <br>
Mitigation: Limit sharing of command outputs and avoid exposing account or template details outside the intended audience. <br>


## Reference(s): <br>
- [ClawHub SendGrid skill](https://clawhub.ai/oomol/oo-sendgrid) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [SendGrid homepage](https://sendgrid.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before running actions; state-changing email sends require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
