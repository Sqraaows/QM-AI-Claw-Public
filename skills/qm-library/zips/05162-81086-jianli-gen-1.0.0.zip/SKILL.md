---
name: jianli-gen
description: Privacy-preserving resume generation from masked resume input and HTML templates. Use when Codex needs to create or update a professional resume HTML file, match a resume to a JD, manage resume templates, or help install/start the local Jianli Gen resume app without exposing private information.
---

# 简历 Gen

基于脱敏简历和模板生成最新的简历 HTML。这个 Skill 只通过文件工作，不查看浏览器页面。

## 隐私边界

- 不使用 browser、Chrome、screenshot 或 DOM 工具查看 `简历 Gen` 页面。
- 不要求用户解锁隐私信息。
- 除非用户明确要求排查文件问题，否则不要读取 `简历数据/隐私信息/隐私信息.json`。
- 只从 `简历数据/脱敏简历/Skill读取的脱敏简历.md` 生成内容，这个文件里应保留 `{{姓名}}` 这类脱敏变量。
- 输出时保留脱敏变量，不要替换成猜测的真实信息。

## 标准流程

1. 定位项目根目录；如有需要，先看 `references/files.md`。
2. 如果是首次使用、安装或启动相关问题，先看 `references/install-and-run.md`。
3. 确认用户已经在网页里填好以下内容：
   - `Skill 读取的脱敏简历`
   - `隐私信息`
   - 需要的话再选一个模板
4. 读取 `简历数据/脱敏简历/Skill读取的脱敏简历.md`。
5. 如果这个文件缺失或为空，先告诉用户回到网页里补全、保存，再继续。
6. 选择模板：
   - 用户指定哪个模板，就用哪个模板
   - 如果用户没有指定，默认用 `模板1`
   - 需要了解模板细节时，读 `references/templates.md`
7. 生成一份完整、可直接预览的 A4 简历 HTML。
8. 只写入最新结果，不保留历史版本。
9. 如果本地服务没有运行，按 `references/install-and-run.md` 处理；如果启动时报端口占用，说明旧服务还在运行，先停掉旧服务再重试。
10. 生成完成一定告诉用户打开本地应用地址 `http://127.0.0.1:8790`，点击 `查看最新` 查看最新结果，然后在网页里预览或导出。

## 生成规则

- 把 `Skill读取的脱敏简历.md` 当作简历内容的唯一来源。
- 模板只作为样式和布局参考，不直接照搬模板里的示例人物内容。
- `{{照片}}`、`{{姓名}}`、`{{手机}}` 这类脱敏变量要原样保留。
- 如果脱敏简历里有 `//` 备注，只在它明显是说明文字时忽略。
- 输出必须是完整 HTML，带内联 CSS，并保持 A4 版式。
- 语言尽量自然、专业，保留用户给出的岗位方向和事实信息。

## 校验

写完 `Skill生成的简历.html` 之后：

- 确认文件存在且非空。
- 确认它是完整 HTML 文档。
- 确认脱敏变量还在。
- 不要打开浏览器去检查隐私内容的渲染结果。

## 低频参考

- 安装和本地启动：`references/install-and-run.md`
- 文件路径约定：`references/files.md`
- 模板选择和管理：`references/templates.md`
- 仓库地址：`https://github.com/Raydon10/jianli-gen`
