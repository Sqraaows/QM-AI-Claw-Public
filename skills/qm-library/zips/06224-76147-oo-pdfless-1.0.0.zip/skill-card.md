## Description: <br>
Pdfless helps agents read the current Pdfless workspace and list document templates through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent inspect Pdfless workspace details and list available document templates without handling raw Pdfless API tokens directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Pdfless account, so an agent can access workspace and template information available to that connection. <br>
Mitigation: Install and run it only for accounts where that read access is intended, and review the connected Pdfless API key, OOMOL account, and billing setup before use. <br>
Risk: Connector schemas and upstream defaults may change over time. <br>
Mitigation: Fetch the live connector schema before constructing action payloads, as the artifact directs. <br>
Risk: Authentication, connection, or billing failures can block actions or expose account setup requirements. <br>
Mitigation: Use first-time setup commands only after the matching command failure and resolve expired credentials, missing scopes, or insufficient credit before retrying. <br>


## Reference(s): <br>
- [Pdfless homepage](https://pdfless.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-pdfless) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, JSON, Guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return data with an executionId under meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
