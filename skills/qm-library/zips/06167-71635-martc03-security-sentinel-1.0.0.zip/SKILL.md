---
name: security-sentinel
description: Security monitoring, system health checks, CVE lookups, and VPS status. Integrates with gov-cybersecurity MCP for real-time threat intel.
homepage: https://github.com/martc03/openclaw-ultimate
metadata: {"clawdbot":{"emoji":"🔒"}}
version: 1.0.0
author: martc03
tags: [security, monitoring, devops, cybersecurity]
permissions:
  commands: [ssh, curl, ping]
  network: [149.248.9.152, api.netlify.com, sentry.io]
---

# Security Sentinel

Monitor infrastructure, check system health, and get real-time threat intelligence from your phone.

## Commands

### `secure status`
Full health check across all systems.

```
secure status
```

Checks:
- VPS (149.248.9.152): uptime, disk, memory via SSH
- Websites: HTTP status for soilrichbyjohn.com and Synergy site
- SSL certificates: expiry dates
- Netlify: latest deploy status
- Sentry: recent error count

Returns a formatted summary with status indicators.

### `secure vps`
Check the OSINT VPS at 149.248.9.152.

```
secure vps
```

Runs via SSH: `uptime`, `df -h`, `free -m`, `docker ps` (if applicable).

### `secure sites`
Verify all managed websites are up and responding correctly.

```
secure sites
```

Checks:
- soilrichbyjohn.com — expects HTTP 200
- Synergy salon site — expects HTTP 200
- Response times logged
- SSL cert expiry checked

### `secure alerts`
Show recent security alerts and anomalies from Notion.

```
secure alerts
```

Reads from: Notion "Security Audit Log" database, filtered to unresolved items (Resolved = false).

### `secure scan [target]`
Quick security scan of a target URL or IP.

```
secure scan soilrichbyjohn.com
```

Checks:
- SSL certificate validity and expiry
- HTTP security headers (HSTS, CSP, X-Frame-Options, etc.)
- Open common ports
- DNS configuration

### `secure cve [id]`
Look up a CVE using the gov-cybersecurity MCP server.

```
secure cve CVE-2021-44228
```

Returns: NVD details (CVSS score, description), CISA KEV exploitation status, EPSS probability score, MITRE ATT&CK techniques.

Delegates to: `gov-cybersecurity` MCP skill (`vuln_lookup_cve` tool).

### `secure audit`
Run a comprehensive security audit across all services.

```
secure audit
```

Performs all checks from `secure status`, `secure sites`, and `secure scan` combined. Writes results to the "Security Audit Log" in Notion.

## Notion Integration

All audit results and alerts are logged to the "Security Audit Log" database:
- Event: Description of what was checked/found
- Severity: Critical, High, Medium, Low, or Info
- Source: VPS, Website, Service, or Manual
- Timestamp: When the check was performed
- Details: Full details of findings
- Resolved: Checkbox for tracking remediation

## Integrations

- **gov-cybersecurity MCP**: CVE lookup via NVD, CISA KEV, EPSS, ATT&CK
- **VPS**: SSH to 149.248.9.152 (OSINT engine)
- **Netlify**: Deploy status API
- **Sentry**: Error tracking

## Setup

Gov-cybersecurity MCP server:
```bash
mcporter add gov-cyber --url https://cybersecurity-vuln-mcp.apify.actor/mcp --transport streamable-http
```

SSH key for VPS:
```bash
ssh-copy-id root@149.248.9.152
```
