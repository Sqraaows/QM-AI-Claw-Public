## Description: <br>
Install and configure the official Gladia SDKs (@gladiaio/sdk for JS/TS, gladiaio-sdk for Python). <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[gladiaio](https://clawhub.ai/user/gladiaio) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to set up Gladia SDK clients, choose JavaScript/TypeScript or Python integration patterns, configure API credentials, and understand SDK behavior for pre-recorded and live transcription workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Examples may send audio files or live microphone audio to Gladia using an API key. <br>
Mitigation: Use the skill only where users understand that recording or transcription is happening, and review Gladia's data handling terms for the deployment. <br>
Risk: Embedding Gladia API keys in browser-side code can expose credentials. <br>
Mitigation: Keep API keys server-side for browser applications and use a backend proxy for requests to Gladia. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/gladiaio/sdk-integration) <br>
- [SDK integration guide](https://docs.gladia.io/chapters/integrations/sdk) <br>
- [JavaScript SDK on npm](https://www.npmjs.com/package/@gladiaio/sdk) <br>
- [Python SDK on PyPI](https://pypi.org/project/gladiaio-sdk/) <br>
- [SDK source code](https://github.com/gladiaio/sdk) <br>
- [Code samples](https://github.com/gladiaio/gladia-samples) <br>
- [SDK versions](references/sdk-versions.md) <br>
- [Client configuration reference](references/client-config.md) <br>
- [JavaScript / TypeScript SDK reference](references/javascript.md) <br>
- [Python SDK reference](references/python.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, shell commands, configuration] <br>
**Output Format:** [Markdown with inline code examples and shell commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include SDK installation commands, client initialization snippets, environment variable guidance, and troubleshooting notes.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
