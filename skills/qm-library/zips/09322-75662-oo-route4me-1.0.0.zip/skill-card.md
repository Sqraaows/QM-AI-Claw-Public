## Description: <br>
Route4Me helps an agent operate Route4Me through an OOMOL-connected account for reading, creating, and deleting route optimization data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent inspect Route4Me connector schemas, list optimization problems, create optimization problems, and delete selected optimizations through the OOMOL CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected Route4Me account and requires sensitive account credentials through OOMOL. <br>
Mitigation: Install and use it only when the agent is expected to operate that Route4Me account, and rely on one-time login or connection steps only when an auth or connection error requires them. <br>
Risk: Create actions can change Route4Me state and delete actions can remove optimization data. <br>
Mitigation: Review write payloads before approval, confirm delete targets explicitly, and inspect the live connector schema before constructing action data. <br>


## Reference(s): <br>
- [Route4Me homepage](https://route4me.com) <br>
- [ClawHub Route4Me skill listing](https://clawhub.ai/oomol/oo-route4me) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, API Calls, Guidance] <br>
**Output Format:** [Markdown with inline bash and PowerShell command blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses from the OOMOL Route4Me connector when run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
