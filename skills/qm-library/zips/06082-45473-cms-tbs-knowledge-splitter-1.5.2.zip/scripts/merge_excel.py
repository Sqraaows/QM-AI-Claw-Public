#!/usr/bin/env python3
"""
阶段三：多JSON → 合并去重Excel
读取 knowledge_entries_{品种}/ 下的所有 JSON，合并去重后生成 Excel。
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple

import openpyxl

CATEGORY_MAP = {
    "01": "产品基础信息",
    "02": "成分组成",
    "03": "作用机制",
    "04": "疾病背景",
    "05": "适应症及用法用量",
    "06": "适应症相关FAQ",
    "07": "安全性与不良反应",
    "08": "临床证据",
    "09": "指南共识",
    "10": "竞品信息",
    "11": "竞品差异化优势",
    "12": "开发准入",
}

EXCEL_SHEET_TITLE_MAX_LEN = 31


def infer_product_name(json_dir: Path) -> Tuple[str, bool]:
    """从 knowledge_entries_{品种} 目录名解析品种名。"""
    base = json_dir.name
    prefix = "knowledge_entries_"
    if base.startswith(prefix) and len(base) > len(prefix):
        return base[len(prefix) :], True
    return base, False


def normalize_category_code(raw: Any) -> str:
    code = str(raw or "").strip()
    if code.isdigit():
        return code.zfill(2)
    return code


def safe_sheet_title(product_name: str, suffix: str = "知识条目") -> str:
    title = f"{product_name}{suffix}"
    if len(title) <= EXCEL_SHEET_TITLE_MAX_LEN:
        return title
    keep = EXCEL_SHEET_TITLE_MAX_LEN - len(suffix)
    return f"{product_name[:keep]}{suffix}"


def dedup_key(entry: Dict[str, Any]) -> str:
    code = normalize_category_code(entry.get("分类代码", ""))
    title = str(entry.get("标题", "")).strip()
    payload = f"{code}{title}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def load_json_files(json_dir: Path) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    entries: List[Dict[str, Any]] = []
    skipped_files: List[Dict[str, str]] = []
    failed_files: List[Dict[str, str]] = []
    invalid_items: List[Dict[str, str]] = []

    json_files = sorted(p for p in json_dir.iterdir() if p.suffix.lower() == ".json")
    if not json_files:
        return entries, {
            "json_file_count": 0,
            "skipped_files": skipped_files,
            "failed_files": failed_files,
            "invalid_items": invalid_items,
        }

    for fpath in json_files:
        fname = fpath.name
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            failed_files.append({"file": fname, "error": str(exc)})
            continue

        if not isinstance(data, dict):
            failed_files.append({"file": fname, "error": "root is not a JSON object"})
            continue

        if "知识条目" not in data:
            skipped_files.append({"file": fname, "reason": "missing 知识条目"})
            continue

        items = data["知识条目"]
        if not isinstance(items, list):
            failed_files.append({"file": fname, "error": "知识条目 is not an array"})
            continue

        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                invalid_items.append(
                    {"file": fname, "index": str(idx), "reason": "entry is not an object"}
                )
                continue

            code = normalize_category_code(item.get("分类代码", ""))
            title = str(item.get("标题", "")).strip()
            if not code or not title:
                invalid_items.append(
                    {
                        "file": fname,
                        "index": str(idx),
                        "reason": "missing 分类代码 or 标题",
                    }
                )
                continue

            normalized = dict(item)
            normalized["分类代码"] = code
            normalized["标题"] = title
            entries.append(normalized)

    return entries, {
        "json_file_count": len(json_files),
        "skipped_files": skipped_files,
        "failed_files": failed_files,
        "invalid_items": invalid_items,
    }


def deduplicate(entries: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
    seen = set()
    result: List[Dict[str, Any]] = []
    for entry in entries:
        key = dedup_key(entry)
        if key in seen:
            continue
        seen.add(key)
        result.append(entry)
    removed = len(entries) - len(result)
    return result, removed


def category_counts(entries: List[Dict[str, Any]]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for entry in entries:
        code = normalize_category_code(entry.get("分类代码", ""))
        counts[code] = counts.get(code, 0) + 1
    return counts


def write_excel(output_path: Path, entries: List[Dict[str, Any]], product_name: str) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wb = openpyxl.Workbook()
    ws1 = wb.active
    ws1.title = safe_sheet_title(product_name)

    headers1 = [
        "品种",
        "分类代码",
        "分类名称",
        "标题",
        "内容",
        "来源文件",
        "来源页码",
        "审核状态",
        "生成时间",
    ]
    ws1.append(headers1)

    today = datetime.now().strftime("%Y-%m-%d")
    for entry in entries:
        code = normalize_category_code(entry.get("分类代码", ""))
        ws1.append(
            [
                product_name,
                code,
                CATEGORY_MAP.get(code, entry.get("分类名称", "") or ""),
                entry.get("标题", ""),
                entry.get("内容", ""),
                entry.get("来源文件", ""),
                entry.get("来源页码", ""),
                "待审核",
                today,
            ]
        )

    ws2 = wb.create_sheet("分类汇总")
    ws2.append(["分类代码", "分类名称", "条目数"])

    counts = category_counts(entries)
    listed_codes = set()

    for code in sorted(CATEGORY_MAP.keys()):
        listed_codes.add(code)
        ws2.append([code, CATEGORY_MAP[code], counts.get(code, 0)])

    extra_codes = sorted(code for code in counts if code not in listed_codes)
    for code in extra_codes:
        ws2.append([code, "(未在标准分类中)", counts[code]])

    ws2.append(["合计", "", sum(counts.values())])
    wb.save(output_path)


def print_report(
    product_name: str,
    product_inferred: bool,
    load_meta: Dict[str, Any],
    total: int,
    deduped: int,
    removed: int,
    output_path: Path,
    entries: List[Dict[str, Any]],
) -> None:
    if not product_inferred:
        print(
            f"警告: json_dir 目录名未匹配 knowledge_entries_{{品种}}，"
            f"品种列将使用「{product_name}」"
        )

    print(f"扫描 JSON 文件数: {load_meta['json_file_count']}")
    if load_meta["skipped_files"]:
        print(f"跳过文件（无 知识条目）: {len(load_meta['skipped_files'])}")
        for item in load_meta["skipped_files"]:
            print(f"  - {item['file']}: {item['reason']}")
    if load_meta["failed_files"]:
        print(f"失败文件（无法解析）: {len(load_meta['failed_files'])}")
        for item in load_meta["failed_files"]:
            print(f"  - {item['file']}: {item['error']}")
    if load_meta["invalid_items"]:
        print(f"跳过无效条目: {len(load_meta['invalid_items'])}")
        for item in load_meta["invalid_items"][:10]:
            print(f"  - {item['file']}#{item['index']}: {item['reason']}")
        if len(load_meta["invalid_items"]) > 10:
            print(f"  ... 另有 {len(load_meta['invalid_items']) - 10} 条")

    print(f"原始条目数: {total}")
    print(f"去重后条目数: {deduped} (去除 {removed} 条重复)")
    print(f"Excel已生成: {output_path}")

    counts = category_counts(entries)
    print("\n各分类条目数：")
    for code in sorted(CATEGORY_MAP.keys()):
        count = counts.get(code, 0)
        if count > 0:
            print(f"  {code} {CATEGORY_MAP[code]}: {count}")
    for code in sorted(counts):
        if code not in CATEGORY_MAP and counts[code] > 0:
            print(f"  {code} (非标准分类): {counts[code]}")


def main() -> int:
    if len(sys.argv) < 3:
        print("Usage: merge_excel.py <json_dir> <output_xlsx>", file=sys.stderr)
        return 2

    json_dir = Path(sys.argv[1])
    output_xlsx = Path(sys.argv[2])

    if not json_dir.is_dir():
        print(f"错误: 目录不存在: {json_dir}", file=sys.stderr)
        return 2

    product_name, product_inferred = infer_product_name(json_dir)
    if not product_name.strip():
        print("错误: 无法从目录名解析品种名", file=sys.stderr)
        return 2

    entries, load_meta = load_json_files(json_dir)
    if load_meta["json_file_count"] == 0:
        print(f"错误: 目录内无 .json 文件: {json_dir}", file=sys.stderr)
        return 2

    total = len(entries)
    if total == 0:
        print("错误: 未加载到任何有效知识条目", file=sys.stderr)
        return 2

    entries, removed = deduplicate(entries)
    entries.sort(key=lambda e: (normalize_category_code(e.get("分类代码", "")), e.get("标题", "")))

    write_excel(output_xlsx, entries, product_name)
    print_report(
        product_name,
        product_inferred,
        load_meta,
        total,
        len(entries),
        removed,
        output_xlsx,
        entries,
    )

    has_issues = bool(
        load_meta["skipped_files"] or load_meta["failed_files"] or load_meta["invalid_items"]
    )
    return 1 if has_issues else 0


if __name__ == "__main__":
    sys.exit(main())
