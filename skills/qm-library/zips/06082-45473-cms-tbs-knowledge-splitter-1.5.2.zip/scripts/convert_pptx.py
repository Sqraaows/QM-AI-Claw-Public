#!/usr/bin/env python3
"""
阶段一：PPTX → Markdown（文件处理服务 file-processing-service）

调用 POST /v1/convert/upload-sync 或 upload-jobs + 轮询，将 PPTX 转为 MD 并写入输出目录。
鉴权：请求头 appKey（由 cms-auth-skills 解析后经 --app-key 注入）。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import uuid
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_BASE_URL = "https://file-processing-service.mediportal.com.cn"
SYNC_SIZE_THRESHOLD_BYTES = 30 * 1024 * 1024  # --mode auto：≥30MB 走异步
DEFAULT_POLL_INTERVAL_SEC = 3
DEFAULT_MAX_WORKERS = 5

# 文件处理服务将 PPT 演讲者备注输出为「### Notes:」块；仅删该块，保留幻灯片上的「备注：」等正文。
_SPEAKER_NOTES_HEADING = re.compile(r"^###\s+Notes:\s*$", re.MULTILINE | re.IGNORECASE)
_NEXT_SLIDE_BOUNDARY = re.compile(
    r"^(?:##\s+第\s*\d+\s*页|<!--\s*Slide\s+number:)",
    re.MULTILINE | re.IGNORECASE,
)
_EXCESS_BLANK_LINES = re.compile(r"\n{4,}")


class ConvertError(Exception):
    pass


def strip_speaker_notes(markdown: str) -> Tuple[str, int]:
    """
    移除 API 输出的演讲者备注块（### Notes: 至下一页分隔符之前）。
    不处理幻灯片正文中的「备注：」、表格列「备注1」、图注「NOTE:」等。
    """
    removed = 0
    text = markdown
    while True:
        match = _SPEAKER_NOTES_HEADING.search(text)
        if not match:
            break
        start = match.start()
        rest = text[match.end() :]
        next_slide = _NEXT_SLIDE_BOUNDARY.search(rest)
        end = match.end() + next_slide.start() if next_slide else len(text)
        text = text[:start] + text[end:]
        removed += 1
    text = _EXCESS_BLANK_LINES.sub("\n\n\n", text)
    return text.rstrip() + "\n", removed


def build_multipart_body(
    file_path: Path,
    extra_fields: Optional[Dict[str, str]] = None,
) -> Tuple[bytes, str]:
    boundary = uuid.uuid4().hex
    file_name = file_path.name
    file_data = file_path.read_bytes()
    parts: List[bytes] = []

    for key, value in (extra_fields or {}).items():
        parts.extend(
            [
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode(),
                f"{value}\r\n".encode(),
            ]
        )

    parts.extend(
        [
            f"--{boundary}\r\n".encode(),
            (
                f'Content-Disposition: form-data; name="file"; filename="{file_name}"\r\n'
                f"Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation\r\n\r\n"
            ).encode(),
            file_data,
            f"\r\n--{boundary}--\r\n".encode(),
        ]
    )
    body = b"".join(parts)
    content_type = f"multipart/form-data; boundary={boundary}"
    return body, content_type


def _should_retry_http(code: int) -> bool:
    return code in (429, 502, 503) or 500 <= code < 600


def _should_retry_exc(exc: Exception) -> bool:
    if isinstance(exc, urllib.error.HTTPError):
        return _should_retry_http(exc.code)
    if isinstance(exc, (urllib.error.URLError, TimeoutError)):
        return True
    return False


def http_request(
    method: str,
    url: str,
    headers: Dict[str, str],
    data: Optional[bytes] = None,
    timeout: int = 300,
    retries: int = 2,
    backoff_sec: float = 1.0,
    accept_status: Optional[Tuple[int, ...]] = None,
) -> Tuple[int, Dict[str, Any], str]:
    accept = accept_status or (200,)
    last_err: Optional[Exception] = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = resp.status
                raw = resp.read().decode("utf-8")
            if status not in accept:
                raise urllib.error.HTTPError(url, status, raw, resp.headers, None)
            try:
                body = json.loads(raw) if raw else {}
            except json.JSONDecodeError:
                body = {}
            return status, body, raw
        except Exception as exc:
            last_err = exc
            if attempt >= retries or not _should_retry_exc(exc):
                raise
            time.sleep(backoff_sec * (2**attempt))
    raise RuntimeError(f"request failed: {last_err}")


def parse_envelope(body: Dict[str, Any], raw: str) -> Dict[str, Any]:
    if body.get("resultCode") != 1:
        msg = body.get("resultMsg") or raw or "unknown error"
        raise ConvertError(str(msg))
    data = body.get("data")
    if not isinstance(data, dict):
        raise ConvertError("response missing data object")
    return data


def convert_sync(
    base_url: str,
    app_key: str,
    file_path: Path,
    force_reconvert: bool,
    timeout: int,
    retries: int,
) -> str:
    url = f"{base_url.rstrip('/')}/v1/convert/upload-sync"
    extra: Dict[str, str] = {}
    if force_reconvert:
        extra["force_reconvert"] = "true"
    data, content_type = build_multipart_body(file_path, extra)
    headers = {
        "appKey": app_key,
        "Content-Type": content_type,
        "Accept": "application/json",
    }
    _, body, raw = http_request(
        "POST",
        url,
        headers,
        data=data,
        timeout=timeout,
        retries=retries,
        accept_status=(200,),
    )
    data_obj = parse_envelope(body, raw)
    markdown = data_obj.get("markdown")
    if not isinstance(markdown, str):
        raise ConvertError("response missing data.markdown")
    return markdown


def submit_async_job(
    base_url: str,
    app_key: str,
    file_path: Path,
    force_reconvert: bool,
    timeout: int,
    retries: int,
) -> str:
    url = f"{base_url.rstrip('/')}/v1/convert/upload-jobs"
    extra: Dict[str, str] = {}
    if force_reconvert:
        extra["force_reconvert"] = "true"
    data, content_type = build_multipart_body(file_path, extra)
    headers = {
        "appKey": app_key,
        "Content-Type": content_type,
        "Accept": "application/json",
    }
    _, body, raw = http_request(
        "POST",
        url,
        headers,
        data=data,
        timeout=timeout,
        retries=retries,
        accept_status=(202,),
    )
    data_obj = parse_envelope(body, raw)
    job_id = data_obj.get("job_id")
    if not isinstance(job_id, str) or not job_id.strip():
        raise ConvertError("response missing data.job_id")
    return job_id


def poll_job(
    base_url: str,
    app_key: str,
    job_id: str,
    poll_interval: float,
    timeout: int,
) -> str:
    url = f"{base_url.rstrip('/')}/v1/convert/jobs/{job_id}"
    headers = {"appKey": app_key, "Accept": "application/json"}
    deadline = time.time() + timeout
    while time.time() < deadline:
        _, body, raw = http_request(
            "GET",
            url,
            headers,
            timeout=min(60, timeout),
            retries=1,
            accept_status=(200,),
        )
        data_obj = parse_envelope(body, raw)
        status = data_obj.get("status")
        if status in ("queued", "running"):
            time.sleep(poll_interval)
            continue
        if status == "succeeded":
            markdown = data_obj.get("markdown")
            if not isinstance(markdown, str):
                raise ConvertError("job succeeded but markdown is empty")
            return markdown
        if status == "failed":
            err = data_obj.get("error") or data_obj.get("error_status") or "job failed"
            raise ConvertError(str(err))
        raise ConvertError(f"unexpected job status: {status}")
    raise ConvertError(f"poll timeout after {timeout}s for job {job_id}")


def convert_async(
    base_url: str,
    app_key: str,
    file_path: Path,
    force_reconvert: bool,
    poll_interval: float,
    submit_timeout: int,
    poll_timeout: int,
    retries: int,
) -> str:
    job_id = submit_async_job(
        base_url, app_key, file_path, force_reconvert, submit_timeout, retries
    )
    return poll_job(base_url, app_key, job_id, poll_interval, poll_timeout)


def resolve_mode(mode: str, file_path: Path) -> str:
    if mode in ("sync", "async"):
        return mode
    if file_path.stat().st_size >= SYNC_SIZE_THRESHOLD_BYTES:
        return "async"
    return "sync"


def convert_one(
    file_path: Path,
    output_dir: Path,
    base_url: str,
    app_key: str,
    mode: str,
    force_reconvert: bool,
    poll_interval: float,
    submit_timeout: int,
    poll_timeout: int,
    retries: int,
) -> Dict[str, Any]:
    resolved = resolve_mode(mode, file_path)
    try:
        if resolved == "sync":
            markdown = convert_sync(
                base_url, app_key, file_path, force_reconvert, submit_timeout, retries
            )
        else:
            markdown = convert_async(
                base_url,
                app_key,
                file_path,
                force_reconvert,
                poll_interval,
                submit_timeout,
                poll_timeout,
                retries,
            )
        cleaned, notes_removed = strip_speaker_notes(markdown)
        output_dir.mkdir(parents=True, exist_ok=True)
        out_path = output_dir / f"{file_path.stem}.md"
        out_path.write_text(cleaned, encoding="utf-8")
        return {
            "file": file_path.name,
            "mode": resolved,
            "success": True,
            "output": str(out_path),
            "speaker_notes_blocks_removed": notes_removed,
        }
    except Exception as exc:
        return {
            "file": file_path.name,
            "mode": resolved,
            "success": False,
            "error": str(exc),
        }


def strip_md_dir(md_dir: Path) -> List[Dict[str, Any]]:
    """批量清洗目录内已有 .md，去掉 ### Notes: 演讲者备注。"""
    md_files = sorted(md_dir.glob("*.md")) + sorted(md_dir.glob("*.MD"))
    seen = set()
    results: List[Dict[str, Any]] = []
    for path in md_files:
        key = path.resolve()
        if key in seen:
            continue
        seen.add(key)
        try:
            raw = path.read_text(encoding="utf-8")
            cleaned, removed = strip_speaker_notes(raw)
            changed = cleaned != raw
            if changed:
                path.write_text(cleaned, encoding="utf-8")
            results.append(
                {
                    "file": path.name,
                    "success": True,
                    "output": str(path),
                    "speaker_notes_blocks_removed": removed,
                    "changed": changed,
                }
            )
        except Exception as exc:
            results.append(
                {
                    "file": path.name,
                    "success": False,
                    "error": str(exc),
                }
            )
    return results


def collect_pptx(source_dir: Path) -> List[Path]:
    files = sorted(source_dir.glob("*.pptx")) + sorted(source_dir.glob("*.PPTX"))
    seen = set()
    result: List[Path] = []
    for p in files:
        key = p.resolve()
        if key not in seen:
            seen.add(key)
            result.append(p)
    return result


def _print_summary(summary: Dict[str, Any]) -> int:
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    failed = summary.get("failed", 0)
    return 0 if failed == 0 else 1


def main() -> int:
    ap = argparse.ArgumentParser(description="Convert PPTX to Markdown via file-processing-service")
    ap.add_argument("--source-dir", help="Directory containing .pptx files")
    ap.add_argument("--output-dir", help="Directory to write .md files")
    ap.add_argument(
        "--strip-md-dir",
        help="仅清洗目录内已有 .md（去掉 ### Notes:），不调用转换 API",
    )
    ap.add_argument(
        "--app-key",
        help="appKey header (from cms-auth-skills --resolve-app-key)",
    )
    ap.add_argument(
        "--base-url",
        default=os.getenv("FILE_PROCESSING_BASE_URL", DEFAULT_BASE_URL),
        help=f"Service base URL (default: {DEFAULT_BASE_URL})",
    )
    ap.add_argument(
        "--mode",
        choices=("sync", "async", "auto"),
        default="auto",
        help="sync | async | auto (auto: async when file >= 30MB)",
    )
    ap.add_argument("--force-reconvert", action="store_true", help="Skip cache, force reconvert")
    ap.add_argument("--concurrency", type=int, default=DEFAULT_MAX_WORKERS)
    ap.add_argument("--poll-interval", type=float, default=DEFAULT_POLL_INTERVAL_SEC)
    ap.add_argument("--submit-timeout", type=int, default=300)
    ap.add_argument("--poll-timeout", type=int, default=1800)
    ap.add_argument("--retries", type=int, default=2)
    args = ap.parse_args()

    if args.strip_md_dir:
        md_dir = Path(args.strip_md_dir)
        if not md_dir.is_dir():
            print(
                json.dumps({"success": False, "error": f"md dir not found: {md_dir}"}),
                file=sys.stderr,
            )
            return 2
        results = strip_md_dir(md_dir)
        ok = [r for r in results if r.get("success")]
        failed = [r for r in results if not r.get("success")]
        if not results:
            print(
                json.dumps({"success": False, "error": f"no .md in {md_dir}"}),
                file=sys.stderr,
            )
            return 2
        summary = {
            "success": len(failed) == 0,
            "mode": "strip-md-only",
            "total": len(results),
            "processed": len(ok),
            "changed": sum(1 for r in ok if r.get("changed")),
            "failed": len(failed),
            "md_dir": str(md_dir),
            "results": results,
        }
        return _print_summary(summary)

    if not args.source_dir or not args.output_dir:
        ap.error("PPTX 转换需同时指定 --source-dir 与 --output-dir")
    if not args.app_key or not args.app_key.strip():
        ap.error("PPTX 转换需指定 --app-key")

    source_dir = Path(args.source_dir)
    output_dir = Path(args.output_dir)
    if not source_dir.is_dir():
        print(json.dumps({"success": False, "error": f"source dir not found: {source_dir}"}), file=sys.stderr)
        return 2

    pptx_files = collect_pptx(source_dir)
    if not pptx_files:
        print(json.dumps({"success": False, "error": f"no .pptx in {source_dir}"}), file=sys.stderr)
        return 2

    workers = max(1, min(args.concurrency, DEFAULT_MAX_WORKERS, len(pptx_files)))
    results: List[Dict[str, Any]] = []

    def task(path: Path) -> Dict[str, Any]:
        return convert_one(
            path,
            output_dir,
            args.base_url,
            args.app_key.strip(),
            args.mode,
            args.force_reconvert,
            args.poll_interval,
            args.submit_timeout,
            args.poll_timeout,
            args.retries,
        )

    if workers == 1:
        for p in pptx_files:
            results.append(task(p))
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(task, p): p for p in pptx_files}
            for fut in as_completed(futures):
                results.append(fut.result())

    results.sort(key=lambda r: r.get("file", ""))
    ok = [r for r in results if r.get("success")]
    failed = [r for r in results if not r.get("success")]

    summary = {
        "success": len(failed) == 0,
        "total": len(results),
        "converted": len(ok),
        "failed": len(failed),
        "output_dir": str(output_dir),
        "speaker_notes_stripped": True,
        "results": results,
    }
    return _print_summary(summary)


if __name__ == "__main__":
    sys.exit(main())
