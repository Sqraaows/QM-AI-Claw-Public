# 输出目录结构

> **进本 Skill 前**：须由用户在**当前会话**提供 **品种名称、待转换文档、存放目录（工作根目录）**，不得默认沿用工作区已有目录。见 [`session-bootstrap.md`](session-bootstrap.md)。

以下 `{根}` 表示用户提供的**存放目录**（示例为 `/knowledge-projects`）：

```
{根}/
├── {品种}_source/                    # 用户提供的原始 PPTX（待转换文档应在此或用户指定路径）
├── parsed_markdown_api/
│   └── {品种}/*.md                 # 阶段一输出
├── knowledge_entries_{品种}/          # 阶段二输出
│   └── *.json
└── {品种}知识库_合并去重.xlsx        # 阶段三输出
```

| 阶段 | 目录/文件 | 说明 |
|------|-----------|------|
| 一 | `{品种}_source/*.pptx` | 输入 |
| 一 | `parsed_markdown_api/{品种}/*.md` | **1 PPTX → 1 MD**（与 PPTX 同名）；不应出现 `*_partN.md` |
| 二 | `knowledge_entries_{品种}/*.json` | **1 课件 1 JSON**（禁止每 part 各生成一个） |
| 三 | `{品种}知识库_合并去重.xlsx` | 合并去重结果 |
