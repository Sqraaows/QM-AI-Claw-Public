### cms-tbs-knowledge-splitter：appKey 获取与注入（强制）

文件处理服务（`file-processing-service`）的业务接口须在请求头携带 **`appKey`**（工作协同 key / cowork key）。本 Skill 的 `appKey` 获取必须通过依赖 Skill **`cms-auth-skills`** 完成。

#### 必须做

- 进入阶段一、执行 `scripts/convert_pptx.py` 之前，**必须先调用** `cms-auth-skills`，目标为 **`appKey`**（不是 `access-token`）。
- 使用 `cms-auth-skills` 的 **`--resolve-app-key`**（或等价能力）解析出可用 `appKey`。
- 将解析结果 **以 `--app-key` 注入**转换脚本，例如：

```bash
python3 scripts/convert_pptx.py \
  --source-dir /knowledge-projects/{品种}_source \
  --output-dir /knowledge-projects/parsed_markdown_api/{品种} \
  --app-key "<APP_KEY>"
```

- `cms-auth-skills` 解析 `appKey` 的优先级以其 `SKILL.md` 为准（上下文 → `XG_BIZ_API_KEY` → `sender_id+account_id` → 向用户索要 appKey）。

#### 必须禁止

- **禁止**将 `access-token` 当作 `appKey` 传给文件处理服务（会 401）。
- **禁止**为换取 `appKey` 而调用 `cms-auth-skills --ensure`（那是 `access-token` 链路；本 Skill 只需 `appKey`）。
- **禁止**在 Agent 编排链路中自行编造 appKey，或跳过 `cms-auth-skills` 直接调用 `convert_pptx.py`。
- **禁止**向用户索要 `access-token`；若需用户提供凭证，仅可按 `cms-auth-skills` 规则索要 **appKey**（工作协同 key）。

#### 失败处理

- `cms-auth-skills` 解析 `appKey` 失败：停止阶段一，引导用户完成授权或提供工作协同 key，然后重试。
- `convert_pptx.py` 返回 401 / `resultMsg` 含 appKey 无效：重新执行 `cms-auth-skills --resolve-app-key` 后再试。

---

### 环境变量与脚本参数

| 变量 / 参数 | 含义 | 涉及脚本 |
|-------------|------|----------|
| `FILE_PROCESSING_BASE_URL` / `--base-url` | 文件处理服务基地址（可选） | `convert_pptx.py` |
| `--app-key` | 由 `cms-auth-skills` 解析后注入 | `convert_pptx.py` |
| `XG_BIZ_API_KEY` | 仅由 **`cms-auth-skills`** 在解析 `appKey` 时读取；Agent **不得**绕过该 Skill 直接依赖此变量调用脚本 | — |

说明：Agent 执行链路中，`appKey` 仅通过 `cms-auth-skills` + `--app-key` 传递，与 `cms-tbs-scene-created` 使用 `access-token` 的方式对称。

---

### 环境前置自检（Smoke-Check，建议阶段一前执行）

1. 经 `cms-auth-skills` 取得非空 `APP_KEY`。
2. 可选：检查服务可达性（无需 appKey）：

```bash
curl -sS "${FILE_PROCESSING_BASE_URL:-https://file-processing-service.mediportal.com.cn}/health"
```

3. 执行转换脚本（有 PPTX 时验证 appKey 有效）：

```bash
python3 scripts/convert_pptx.py \
  --app-key "$APP_KEY" \
  --source-dir /knowledge-projects/{品种}_source \
  --output-dir /knowledge-projects/parsed_markdown_api/{品种}
```

**通过标准**：`stdout` JSON 中 `success=true` 且 `failed=0`（或无待转换文件时先确认目录存在）。

**失败处理**：

| 现象 | 可能原因 | 处理方式 |
|------|---------|---------|
| 脚本退出码 `2` + 缺少 appKey | 未注入 `--app-key` | 先走 `cms-auth-skills` 再调用脚本 |
| JSON 内 401 / appKey 无效 | key 错误或过期 | 重新 `--resolve-app-key` |
| 413 | 超过上传体积上限 | 压缩/缩小源文件或跳过（**禁止**拆 PPT 转 MD；非改异步） |
| 429 / 503 | 并发过高 | 降 `--concurrency` 或改异步 |

> Smoke-Check 失败时，**不得**进入阶段二、三。
