# 阶段一：PPTX → Markdown（文件处理服务）

> **前置**：已完成 [`session-bootstrap.md`](session-bootstrap.md) 任务参数采集（品种、待转换文档、存放目录）。未确认前**禁止**调用本阶段脚本或扫描源目录。

## 鉴权（必须先做）

细则见 [`auth.md`](auth.md)。

1. 调用依赖 Skill **`cms-auth-skills`**，使用 **`--resolve-app-key`** 取得 `APP_KEY`。
2. **不要**使用 `--ensure`（那是 `access-token`，不能用于本服务）。
3. 将 `APP_KEY` 注入下方脚本的 **`--app-key`**。

## 服务说明

使用 **`file-processing-service`** 将 PPTX 转为 Markdown。完整 API 见 [`文件处理服务API说明.md`](../../文件处理服务API说明.md)。

| 项目 | 值 |
|------|-----|
| 生产 Base URL | `https://file-processing-service.mediportal.com.cn` |
| 同步转换 | `POST /v1/convert/upload-sync`（HTTP 200） |
| 异步转换 | `POST /v1/convert/upload-jobs`（HTTP 202）+ `GET /v1/convert/jobs/{job_id}` 轮询 |
| 鉴权 | 请求头 **`appKey`**（由 `cms-auth-skills` 提供） |
| 表单 | `multipart/form-data`，字段名 **`file`** |

## 推荐执行方式（脚本）

```bash
python3 scripts/convert_pptx.py \
  --app-key "$APP_KEY" \
  --source-dir {根}/{品种}_source \
  --output-dir {根}/parsed_markdown_api/{品种} \
  --mode auto \
  --concurrency 5
```

| 参数 | 说明 |
|------|------|
| `--app-key` | **必填**，来自 `cms-auth-skills` |
| `--mode sync` | 始终同步，适合小文件 |
| `--mode async` | 始终异步 + 轮询，适合大 PPT 或易触发 429/503 |
| `--mode auto` | **默认**；单文件 **≥ 30MB** 时自动走异步（`upload-jobs` + 轮询） |
| `--force-reconvert` | 跳过缓存强制重转 |
| `--concurrency` | 并发数，默认 5，上限 5 |
| `--base-url` | 可选；默认生产地址，也可用环境变量 `FILE_PROCESSING_BASE_URL` |
| `--strip-md-dir` | **仅清洗**目录内已有 `.md`（去掉演讲者 `### Notes:`），不调用转换 API、无需 `appKey` |

脚本 stdout 为 JSON 汇总：`converted` / `failed` / 各文件 `output` 或 `error`。

退出码：`0` 全部成功，`1` 存在失败，`2` 参数或鉴权错误。

## 输入 / 输出

- **源目录：** `{根}/{品种}_source/*.pptx`（`{根}` = 用户确认的存放目录）
- **输出目录：** `{根}/parsed_markdown_api/{品种}/`
- **范围：** 仅处理用户在任务参数中确认的 PPTX（单文件或「全部」），**禁止**因目录里还有其他历史文件而擅自扩 scope
- **文件名：** `{原始PPT文件名}.md`（扩展名 `.pptx` → `.md`）
- **原则：** **1 个 PPTX → 1 个 MD**（供阶段二单次生成知识条目）

## 处理流程

1. **`cms-auth-skills`** → 解析 `appKey`
2. 扫描源目录下所有 `.pptx`
3. **`convert_pptx.py`** 调用文件处理服务，从 `data.markdown` 写入 `.md`
4. **落盘前自动剔除演讲者备注**：删除 API 输出的 `### Notes:` 及其后讲稿正文（至下一页 `## 第 N 页` / `<!-- Slide number:` 之前）
5. 汇总失败列表（若有）

### 演讲者备注 vs 幻灯片「备注」

| 类型 | 示例 | 阶段一处理 |
|------|------|------------|
| 演讲者备注（讲稿） | `### Notes:` + 大段口语讲解 | **删除** |
| 幻灯片图表说明 | `备注：横轴临床需求为…` | **保留** |
| 表格列名 | `备注1`、`备注2` | **保留** |
| 文献/森林图图注 | `NOTE: Weights are from…` | **保留** |

> 阶段二、三不再处理备注；`parsed_markdown_api/` 下的 `.md` 应仅为幻灯片可见内容。

### 清洗已有 MD（不重转 PPTX）

历史转换结果若仍含 `### Notes:`，可对输出目录批量清洗：

```bash
python3 scripts/convert_pptx.py \
  --strip-md-dir {根}/parsed_markdown_api/{品种}
```

stdout 含各文件 `speaker_notes_blocks_removed` 与 `changed`；`changed: false` 表示该文件本无备注块或已清洗过。

### 禁止为转 MD 而拆分 PPT

- `convert_pptx.py`（含异步）始终是 **1 个 `.pptx` → 1 个 `.md`**，不会自动生成 `*_partN.md`。
- 若遇 **413**：使用 `--mode async` 重试；或压缩源文件；**禁止**将同一课件拆成多个 pptx 再分别转换（见 `stage2-generate.md`、`pitfalls.md`）。
- 编排器（如 OpenClaw）**不得**在阶段一失败时默认建议「拆分 PPT」。

## 手动调用（仅当无法跑脚本时）

需已持有 `APP_KEY`（经 `cms-auth-skills` 取得）。

### 同步

```bash
curl -sS --compressed -X POST \
  "${FILE_PROCESSING_BASE_URL:-https://file-processing-service.mediportal.com.cn}/v1/convert/upload-sync" \
  -H "appKey: ${APP_KEY}" \
  -F "file=@/path/to/document.pptx"
```

成功响应根级 `resultCode === 1`，正文取 **`data.markdown`**。

### 异步（大文件）

1. `POST .../v1/convert/upload-jobs` → 记录 `data.job_id`（HTTP **202**）
2. 每 **2～5 秒** `GET .../v1/convert/jobs/{job_id}`，直至 `status` 为 `succeeded` 或 `failed`
3. `succeeded` 时取 `markdown`；`failed` 时读 `error`

## 同步 / 异步选择（`--mode auto`）

| 单文件体积 | 脚本行为 |
|------------|----------|
| **&lt; 30MB** | `POST /v1/convert/upload-sync`（同步，一次返回 `markdown`） |
| **≥ 30MB** | `POST /v1/convert/upload-jobs` + `GET /v1/convert/jobs/{job_id}` 轮询（异步） |

> 异步用于避免大文件同步阻塞/超时；**不能**绕过服务端上传体积上限。若仍返回 **413**，见下方错误处理（**禁止**为转 MD 而拆 PPT）。

## 并发控制

- 脚本默认最多 **5** 路并行（`--concurrency`，上限 5）
- 超出时分批；若频繁 **429/503**，改为 `--mode async` 或降低 `--concurrency`
- 全项目 PPTX **超过 10 个**时，建议分批评审与执行

## 错误处理

| HTTP / 场景 | 处理 |
|-------------|------|
| 401 | 重新经 `cms-auth-skills` 解析 `appKey`；禁止用 `access-token` 顶替 |
| 413 | 超过上传体积上限；**换异步无效**。处置：`--mode async` 重试 → 压缩嵌入图/媒体 → 仍失败则**跳过该文件并记录**（**禁止**拆成多个 pptx，见 `pitfalls.md` §7、§8） |
| 429 / 503 | 降并发或改 `--mode async`，脚本会自动有限重试 |
| `resultCode !== 1` | 读 `resultMsg`，记入失败列表 |
| 单文件失败 | 跳过，继续其他文件，最终汇总 |

## 输出文件命名映射

| PPTX 源文件名 | MD 输出文件名 |
|--------------|-------------|
| 维图可——三重功力.pptx | 维图可——三重功力.md |
| 2024.06.12-培训PPT.pptx | 2024.06.12-培训PPT.md |
