---
name: bizyair-cli
description: BizyAir CLI 模型上传助手。扫描指定模型文件夹，自动生成 config.yaml 配置文件，然后通过 bizyair upload 命令批量或单版本上传模型到 BizyAir 平台。当用户提到"上传 BizyAir 模型"、"bizyair upload"、"批量上传模型"、"生成 config.yaml"、"上传 LoRA"、"上传 Checkpoint"、"bizyair-cli"、"模型上传到 BizyAir"时必须使用此技能。即使用户只说"帮我上传模型"、"把模型传上去"也应触发。
---

# BizyAir CLI 模型上传助手

帮助用户将本地训练好的模型文件（.safetensors 等）上传到 BizyAir 平台。核心能力是扫描用户的模型文件夹，自动识别模型文件和封面图片，生成 `config.yaml` 配置文件，然后执行上传命令。

## 前置条件

1. 用户已安装 `bizyair` CLI 工具。如未安装，指引到 https://github.com/siliconflow/bizyair-cli/releases/ 下载
2. 用户已登录：`bizyair login`（需要 API Key，从 https://bizyair.cn/ 获取）

## 工作流程

### 第一步：确认模型文件夹信息

用户提供模型文件夹路径后，向用户确认以下关键信息（如果用户没有明确说明）：

- **模型名称**（`name`）：用于 BizyAir 平台展示，如 "FLUX2-WH"
- **模型类型**（`type`）：从下方列表选择
- **基础模型**（`base_model`）：每个版本需要指定
- **模型介绍**（`intro`）：描述模型的触发词、参考提示词等
- **是否公开**（`public`）：默认 true

### 第二步：扫描文件夹并生成 config.yaml

扫描模型文件夹，自动匹配：

1. **模型文件**：匹配 `*.safetensors`、`*.ckpt`、`*.pt`、`*.bin` 等格式
2. **封面图片**：匹配 `*.jpg`、`*.jpeg`、`*.png`、`*.webp`、`*.gif` 格式
3. **版本对应**：尝试通过文件名中的数字或序号将模型文件与封面图片一一对应
   - 例如 `FLUX2-WH_1.safetensors` 对应 `1.png`
   - 例如 `model_v2.safetensors` 对应 `cover_v2.jpg`

匹配规则（按优先级）：
- 文件名中提取数字，按数字大小排序作为版本号
- 如无法提取数字，按文件修改时间排序

生成 `config.yaml` 写入模型文件夹内，格式如下：

```yaml
models:
  - name: "模型名称"
    type: "LoRA"
    versions:
      - name: "v1.0"
        base_model: "FLUX.2 Klein"
        model_path: "/绝对路径/模型文件.safetensors"
        cover_path: "/绝对路径/封面.png"
        intro: "模型介绍文本"
        public: true
```

**关键规则：**
- `model_path` 和 `cover_path` 使用绝对路径，确保 bizyair CLI 能找到文件
- 如果文件夹内有 `covers/` 子目录，优先从该目录查找封面
- 如果模型文件数多于封面数，缺少封面的版本需提醒用户补充

### 第三步：执行上传

根据模型版本数量选择上传方式：

**方式 A：批量上传（版本数 >= 2）**

```bash
bizyair upload -f /path/to/config.yaml
```

**方式 B：单版本上传（版本数 = 1）**

```bash
bizyair upload -n 模型名称 -t LoRA \
  -p /path/to/model.safetensors \
  -b "FLUX.2 Klein" \
  -cover /path/to/cover.png \
  --intro "模型介绍" \
  --public
```

### 第四步：确认结果

上传命令执行后，检查输出是否显示成功。如遇到失败，建议用户：
1. 检查网络连接
2. 重新运行相同命令（支持断点续传）
3. 清理 checkpoint 文件：`rm -rf ~/.bizyair/uploads/`

## 模型类型（-t 参数）

| 值 | 说明 |
|---|---|
| LoRA | LoRA 微调模型 |
| Checkpoint | 完整检查点 |
| Controlnet | 控制网络 |
| VAE | VAE 模型 |
| UNet | UNet 模型 |
| CLIP | CLIP 模型 |
| Upscaler | 超分辨率模型 |
| Detection | 检测模型 |
| Other | 其他类型 |

## 基础模型（-b 参数 / base_model）

```
Flux.1 D, Flux.1 Kontext, Flux.1 S, SDXL, SD 1.5, SD 3.5,
Pony, Illustrious, NoobAI, Anima, Flux.2 D, Flux.2 Klein,
ERNIE-Image, Kolors, Hunyuan 1, Hunyuan Video, Wan Video,
Qwen-Image, Qwen-Edit, Z-image, Ovis, LTX-2, Nano Banana,
Seedream, Seedance, Sora, Veo, Kling, Hailuo, GPT-Image,
Vidu, Grok, HappyHorse, Other
```

## 封面格式

支持图片（.jpg/.jpeg/.png/.gif/.webp）和视频（.mp4/.webm/.mov，最大 100MB）。图片会自动转为 WebP 格式。

## 断点续传

上传中断后重新运行相同命令即可自动续传。checkpoint 文件保存在 `~/.bizyair/uploads/`。

## 其他常用命令

```bash
# 检查更新
bizyair upgrade --check

# 升级
sudo bizyair upgrade

# 查看已上传模型（浏览器打开）
bizyair model ls

# 删除模型
bizyair model rm -n 模型名 -t 模型类型

# 退出登录
bizyair logout
```
