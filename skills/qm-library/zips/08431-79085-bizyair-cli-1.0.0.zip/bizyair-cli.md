# BizyAir CLI 命令行工具¶

BizyAir CLI 是用于管理 BizyAir 上模型文件的命令行工具。可以轻松上传和管理 BizyAir 模型。
前往：https://github.com/siliconflow/bizyair-cli/releases/ 下载最新版本安装到本地。


BizyAir CLI 支持一键升级到最新版本：

```bash
# 检查更新
bizyair upgrade --check

# 执行升级
sudo bizyair upgrade
```


## 方式 1：直接输入文本
bizyair upload -n mymodel -t LoRA -p model.safetensors -b "Flux.1 D" \
  -cover cover.jpg --intro "这是模型的详细介绍..."

## 方式 2：从文件导入（支持 .txt 和 .md）
bizyair upload -n mymodel -t LoRA -p model.safetensors -b "Flux.1 D" \
  -cover cover.jpg --intro-path intro.md

## 方式 3：从config.yaml文件批量上传
bizyair upload -f config.yaml
```yaml
models:
  - name: "anime_style_lora"
    type: "LoRA"
    versions:
      - name: "v1.0"
        base_model: "Flux.1 D"
        model_path: "models/anime_v1.safetensors"
        cover_path: "/Users/hao/Downloads/FLUX2-WH/covers/anime_v1.jpg"
        intro: "第一版动漫风格模型"
        public: true

      - name: "v2.0"
        base_model: "Flux.1 D"
        model_path: "models/anime_v2.safetensors"
        cover_url: "https://example.com/cover.jpg"
        intro_path: "descriptions/v2_intro.txt"
        public: false

  - name: "realistic_checkpoint"
    type: "Checkpoint"
    versions:
      - base_model: "SD 1.5"
        model_path: "checkpoints/realistic.ckpt"
        cover_path: "/Users/hao/Downloads/FLUX2-WH/covers/realistic.webp"
        intro_path: "descriptions/realistic.md"
```

## -t, --type：模型类型
LoRA
Controlnet
Checkpoint
VAE
UNet
CLIP
Upscaler
Detection
Other

## -b, --base：基础模型 base_model
Flux.1 D
Flux.1 Kontext
Flux.1 S
SDXL
SD 1.5
SD 3.5
Pony
Illustrious
NoobAI
Anima
Flux.2 D
Flux.2 Klein
ERNIE-Image
Kolors
Hunyuan 1
Hunyuan Video
Wan Video
Qwen-Image
Qwen-Edit
Z-image
Ovis
LTX-2
Nano Banana
Seedream
Seedance
Sora
Veo
Kling
Hailuo
GPT-Image
Vidu
Grok
HappyHorse
Other