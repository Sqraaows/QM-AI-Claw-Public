## Description: <br>
IP2WHOIS searches WHOIS registration data and hosted-domain information through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and security analysts use this skill to query IP2WHOIS for domain WHOIS records and domains hosted on a specific IP address without handling raw IP2WHOIS credentials locally. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Optional oo CLI installer commands execute remote install scripts. <br>
Mitigation: Review the OOMOL installer source before running the installer and only install the CLI when it is required. <br>
Risk: IP2WHOIS lookups use the connected account and may consume service credits. <br>
Mitigation: Confirm that the correct OOMOL connection and IP2WHOIS account are in use before running lookups that may incur cost. <br>
Risk: Upstream connector schemas can change. <br>
Mitigation: Fetch the live action schema with the oo CLI before constructing each request payload. <br>


## Reference(s): <br>
- [ClawHub IP2WHOIS release page](https://clawhub.ai/oomol/oo-ip2whois) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, Guidance, Text] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Queries return connector JSON containing data and meta.executionId when run through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: metadata.version and release.version in evidence.json) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
