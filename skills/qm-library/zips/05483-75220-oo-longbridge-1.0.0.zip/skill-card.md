## Description: <br>
Longbridge lets an agent query Longbridge finance and brokerage data through OOMOL's oo CLI connector for account cash balances, tradable securities, and stock positions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to read Longbridge account and market data through an OOMOL-connected account. It supports account cash balance checks, tradable security discovery, and stock position review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can expose Longbridge financial account data visible to the connected OAuth user. <br>
Mitigation: Install only for trusted users, keep Longbridge scopes limited where possible, and confirm the user intent before reading account data. <br>
Risk: The workflow depends on OOMOL and the oo CLI as intermediaries for Longbridge access. <br>
Mitigation: Review the remote installer and trust OOMOL and the oo CLI before installing or authenticating. <br>
Risk: Future Longbridge actions could place trades, move money, or change account settings. <br>
Mitigation: Require explicit confirmation before any action that creates, updates, sends, posts, deletes, removes, trades, transfers, or changes settings. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-longbridge) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Longbridge Homepage](https://longbridge.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [list_account_cash action](actions/list_account_cash.md) <br>
- [list_securities action](actions/list_securities.md) <br>
- [list_stock_positions action](actions/list_stock_positions.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema checks before constructing oo CLI action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
