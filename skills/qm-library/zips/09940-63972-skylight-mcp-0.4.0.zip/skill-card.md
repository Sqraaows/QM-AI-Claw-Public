## Description: <br>
Skylight MCP lets an agent read and manage a signed-in Skylight Calendar family hub, including calendar events, chores and rewards, shared lists, and frame and device information. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users with Skylight accounts use this skill to connect an agent to their family hub so it can answer questions about calendars, chores, rewards, shared lists, frames, devices, and members. With user approval, the agent can create, update, delete, or complete supported Skylight items. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires Skylight email and password credentials. <br>
Mitigation: Use project-specific configuration or secret storage, protect the password like any account secret, and avoid exposing credentials in shared logs or prompts. <br>
Risk: Authenticated tools can read sensitive household data and create, update, delete, or complete calendar, chore, reward, list, frame, device, and member-related data. <br>
Mitigation: Require explicit user confirmation before mutating data and review read results before acting on them. <br>
Risk: Accounts with more than one Skylight frame may expose or modify the wrong family hub if frame selection is ambiguous. <br>
Mitigation: Set SKYLIGHT_FRAME_ID when multiple frames exist and confirm the target frame before write operations. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/chrischall/skylight-mcp) <br>
- [Skylight](https://www.ourskylight.com) <br>
- [npm package](https://www.npmjs.com/package/skylight-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [text, configuration, shell commands] <br>
**Output Format:** [Markdown with JSON configuration examples and inline shell commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires Skylight account credentials and can invoke authenticated tools that read or change family hub data.] <br>

## Skill Version(s): <br>
0.4.0 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
