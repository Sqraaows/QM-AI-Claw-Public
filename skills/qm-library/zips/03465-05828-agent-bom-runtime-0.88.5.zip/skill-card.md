## Description: <br>
AI runtime security monitoring for context graph analysis, runtime audit log correlation with CVE findings, and vulnerability analytics queries. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
Apache-2.0 <br>


## Use Case: <br>
Developers and security engineers use this skill to inspect agent runtime context graphs, correlate user-provided audit logs with CVE findings, and query vulnerability posture trends. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Runtime audit logs may contain sensitive operational details or credential environment variable names. <br>
Mitigation: Use trusted development contexts, review audit files before analysis, and avoid including raw credential values. <br>
Risk: Optional ClickHouse analytics storage can persist vulnerability and runtime event data. <br>
Mitigation: Configure only trusted ClickHouse endpoints with appropriate access controls, or omit persistent analytics storage when it is not needed. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/msaad00/agent-bom-runtime) <br>
- [agent-bom project homepage](https://github.com/msaad00/agent-bom) <br>
- [agent-bom PyPI package](https://pypi.org/project/agent-bom/) <br>
- [OpenSSF Scorecard](https://securityscorecards.dev/viewer/?uri=github.com/msaad00/agent-bom) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, guidance] <br>
**Output Format:** [Markdown with inline command examples and analysis results] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May reference user-provided JSONL audit logs and optional ClickHouse-backed analytics when configured.] <br>

## Skill Version(s): <br>
0.88.5 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
