"""LinkedIn automation package."""
