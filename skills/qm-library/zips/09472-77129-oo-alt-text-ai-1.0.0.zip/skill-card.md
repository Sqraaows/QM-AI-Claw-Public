## Description: <br>
AltText.ai connector wrapper for reading, creating, searching, scraping, and deleting AltText.ai image records through OOMOL's oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate an AltText.ai account from an agent workflow, including generating alt text, scraping pages for images, and managing image records. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected AltText.ai account and may rely on sensitive credentials managed by the connector. <br>
Mitigation: Install it only when OOMOL is the intended connector for the AltText.ai account, and run setup or login steps only when the connection is needed and the CLI source is trusted. <br>
Risk: Create, scrape, and delete actions can change AltText.ai state or remove image records. <br>
Mitigation: Review write and delete requests before approving them, including the exact payload, target asset, and intended effect. <br>


## Reference(s): <br>
- [AltText.ai homepage](https://alttext.ai) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-alt-text-ai) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
