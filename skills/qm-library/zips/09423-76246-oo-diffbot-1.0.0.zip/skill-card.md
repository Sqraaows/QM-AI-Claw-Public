## Description: <br>
Diffbot (diffbot.com). Use this skill for ANY Diffbot request: searching and reading data through an OOMOL-connected Diffbot account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Diffbot through the OOMOL `oo` CLI, inspect the live connector schema, and extract normalized data from public article URLs. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL account connected to Diffbot and can cause Diffbot or OOMOL billing or credit usage when extraction requests run. <br>
Mitigation: Install only after reviewing the OOMOL and Diffbot connection requirements, and monitor billing or credit use for connector runs. <br>
Risk: The agent may run `oo` connector commands using server-side credentials, so incorrect payloads could produce unintended connector activity. <br>
Mitigation: Fetch the live connector schema before constructing payloads and confirm any create, update, send, post, delete, or remove action with the user before execution. <br>


## Reference(s): <br>
- [Diffbot homepage](https://www.diffbot.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub Diffbot skill](https://clawhub.ai/oomol/oo-diffbot) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId when run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
