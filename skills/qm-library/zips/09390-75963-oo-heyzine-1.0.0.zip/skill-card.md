## Description: <br>
Use this skill for Heyzine requests, including reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Heyzine through an OOMOL-connected account, including listing and retrieving flipbooks, managing bookshelf membership, updating social metadata, and deleting flipbooks when explicitly approved. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can act on a connected Heyzine account through OOMOL. <br>
Mitigation: Install and use it only when the user wants agent access to that connected Heyzine account. <br>
Risk: Metadata updates and bookshelf membership changes alter Heyzine state. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before running write actions. <br>
Risk: Flipbook deletion and removal actions can be destructive. <br>
Mitigation: Require explicit user approval for the specific target before running delete or remove actions. <br>
Risk: CLI installation or login steps can affect the local environment and account session. <br>
Mitigation: Run oo CLI install or login steps only when needed and only from the documented OOMOL source. <br>


## Reference(s): <br>
- [Heyzine homepage](https://heyzine.com) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-heyzine) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, JSON, API Calls] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution and returns connector responses as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
