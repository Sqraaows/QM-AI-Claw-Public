## Description: <br>
Contentful lets agents operate Contentful through an OOMOL-connected account to read, create, and update CMS data with schema-checked connector actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and content operations teams use this skill to discover Contentful spaces, environments, content types, entries, and authenticated user details, then create or update entries when the user confirms the intended change. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update live Contentful entries. <br>
Mitigation: Require explicit user confirmation of the exact payload and intended effect before running create_entry or update_entry. <br>
Risk: The skill depends on sensitive Contentful access delegated through OOMOL. <br>
Mitigation: Install only for intended Contentful accounts, review Contentful scopes and OOMOL connection trust, and disconnect or rotate credentials when access is no longer needed. <br>
Risk: Connector schemas and upstream defaults can change. <br>
Mitigation: Fetch the live connector schema before each action and build payloads only from that current schema. <br>


## Reference(s): <br>
- [Contentful homepage](https://www.contentful.com) <br>
- [ClawHub Contentful skill page](https://clawhub.ai/oomol/oo-contentful) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Successful connector runs return JSON responses from Contentful through OOMOL, including data and an execution id.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
