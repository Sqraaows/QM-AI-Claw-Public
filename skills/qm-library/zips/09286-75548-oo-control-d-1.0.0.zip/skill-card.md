## Description: <br>
Control D helps agents read, create, update, and delete Control D account data through the OOMOL control_d connector and oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Control D profiles, service discovery, current-IP diagnostics, and root-folder DNS rules from an OOMOL-connected account. It supports read operations and state-changing rule creation, replacement, and deletion with confirmation requirements. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The connected account can change Control D profiles and DNS rules. <br>
Mitigation: Review create, update, and delete payloads carefully and require explicit user approval before running state-changing actions. <br>
Risk: The skill depends on sensitive credentials managed through the OOMOL-connected account. <br>
Mitigation: Install only when the publisher is trusted and use the server-side credential flow rather than handling raw Control D tokens directly. <br>
Risk: Piping a remote installation script directly into a shell can expose the environment to installer supply-chain risk. <br>
Mitigation: Prefer a verified package or manual installation path for the oo CLI when available. <br>


## Reference(s): <br>
- [ClawHub Control D skill page](https://clawhub.ai/oomol/oo-control-d) <br>
- [Control D homepage](https://controld.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
