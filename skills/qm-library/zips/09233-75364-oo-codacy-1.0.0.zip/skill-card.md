## Description: <br>
Codacy (codacy.com). Use this skill for Codacy requests that search and read data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineering teams use this skill to inspect Codacy account, organization, repository analysis, language, tool, and pattern data through the Codacy connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Codacy data available through the connected OOMOL/Codacy account. <br>
Mitigation: Use a Codacy token scoped only to organizations and repositories the agent is allowed to access. <br>
Risk: The artifact includes an oo CLI installer command. <br>
Mitigation: Verify the OOMOL install guide or use a trusted installation method before running the installer. <br>


## Reference(s): <br>
- [Codacy homepage](https://www.codacy.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-codacy) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions with shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
