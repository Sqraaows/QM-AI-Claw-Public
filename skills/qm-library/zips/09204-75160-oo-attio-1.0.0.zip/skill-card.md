## Description: <br>
Attio (attio.com). Use this skill for reading, creating, updating, and deleting Attio data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, developers, and agents use this skill to operate an Attio workspace through the OOMOL CLI for record, object, attribute, and token-inspection workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and change Attio CRM records through a credentialed OOMOL CLI connection. <br>
Mitigation: Install only when OOMOL is trusted, review requested Attio scopes, and use the connected account intended for the task. <br>
Risk: Create, update, upsert, and delete actions can modify or remove workspace data. <br>
Mitigation: Confirm the exact payload, target object, target record, and intended effect with the user before running write or destructive actions. <br>


## Reference(s): <br>
- [Attio homepage](https://attio.com) <br>
- [ClawHub Attio skill page](https://clawhub.ai/oomol/oo-attio) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; command responses are JSON when run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
