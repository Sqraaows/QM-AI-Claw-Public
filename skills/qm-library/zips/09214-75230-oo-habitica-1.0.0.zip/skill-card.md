## Description: <br>
Habitica (habitica.com). Use this skill for Habitica requests that read, create, update, score, or delete user tasks and tags through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate a connected Habitica account from an agent workflow, including profile lookup, task and tag listing, task scoring, and controlled create, update, or delete actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Setup instructions include one-line remote installer commands that execute downloaded shell or PowerShell scripts. <br>
Mitigation: Prefer a signed or package-manager installation path, inspect installer contents before execution, and run the remote installer only when the user explicitly trusts OOMOL's installer channel. <br>
Risk: The skill can create, update, score, and delete Habitica tasks or tags. <br>
Mitigation: Confirm the exact payload and intended effect before write actions, and require explicit user approval before delete actions. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-habitica) <br>
- [Habitica Homepage](https://habitica.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance, API calls] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads; write and delete actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence.release.version and artifact metadata.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
