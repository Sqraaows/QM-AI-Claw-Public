## Description: <br>
Imports an existing novel manuscript and reverse-analyzes it into a standard writing project structure that can continue through long-form or short-form story writing workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External writers and writing-workflow developers use this skill to import an existing novel or draft, classify it as long-form or short-form, run the matching analysis pipeline, and create local project files for continued writing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update local writing-project files from a manuscript import. <br>
Mitigation: Invoke it explicitly with /story-import, review the detected source file, length classification, and target project structure before confirming the import. <br>
Risk: Long-form imports may run a full analysis workflow and generate persistent local artifacts. <br>
Mitigation: Run it in the intended project workspace and review generated files marked as import-derived before using them for continued writing. <br>


## Reference(s): <br>
- [Story Import ClawHub page](https://clawhub.ai/worldwonderer/story-import) <br>
- [OpenClaw source metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [Length Routing](references/length-routing.md) <br>
- [Long-Form Structure Mapping](references/structure-mapping-long.md) <br>
- [Short-Form Structure Mapping](references/structure-mapping-short.md) <br>
- [Character State Reverse](references/character-state-reverse.md) <br>
- [State Tracking](references/state-tracking.md) <br>
- [Format and Structure](references/format-and-structure.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with file paths, project-structure templates, and local workflow commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Creates or updates local writing-project files and persistent analysis artifacts when the user confirms an import.] <br>

## Skill Version(s): <br>
1.0.3 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
