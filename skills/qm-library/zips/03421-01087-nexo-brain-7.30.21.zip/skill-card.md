## Description: <br>
Cognitive memory system for AI agents with persistent local memory, semantic retrieval, trust scoring, and error-prevention workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[wazionapps](https://clawhub.ai/user/wazionapps) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and OpenClaw users use NEXO Brain to add a local persistent-memory MCP integration to agents for semantic recall, guard checks, session continuity, reminders, and preference memory across sessions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Persistent local memory may retain sensitive context across sessions. <br>
Mitigation: Review the contents of ~/.nexo/ and apply local retention or deletion practices before using the skill with sensitive projects. <br>
Risk: The setup installs and runs an external npm package and a local MCP server. <br>
Mitigation: Review the nexo-brain package and installed server files before enabling the MCP server in OpenClaw. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/wazionapps/nexo-brain) <br>
- [NEXO homepage](https://github.com/wazionapps/nexo) <br>
- [nexo-brain npm package](https://www.npmjs.com/package/nexo-brain) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with shell commands and JSON configuration blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Targets darwin and linux, requires python3, and installs the nexo-brain package with nexo and nexo-brain binaries.] <br>

## Skill Version(s): <br>
7.30.21 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
