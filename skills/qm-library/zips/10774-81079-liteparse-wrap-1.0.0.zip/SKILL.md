---
name: LiteParse 轻量级解析器
slug: liteparse-wrap
description: LiteParse 轻量级解析器 — 专注处理 JSON、XML、YAML、TOML 等常见数据格式的高速解析工具。基于 Rust 语言开发，性能远超传统 JavaScript 解析库，支持流式解析和增量处理。适用于 Node.js 和浏览器环境，特别适合处理大型数据文件或高并发 API 响应场景。API 设计简洁，零学习成本即可上手。 | 来源：https://github.com/q15004040209-creator/liteparse-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/liteparse-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
