## Description: <br>
Use HubSpot through an OOMOL-connected account to read, create, search, and update CRM contacts, companies, deals, and property metadata. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external business users, and developers use this skill to operate HubSpot CRM records from an agent workflow through the OOMOL HubSpot connector. It supports reading, searching, creating, and updating contacts, companies, deals, and property definitions after inspecting the live connector schema. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update HubSpot CRM records through the connected OOMOL account. <br>
Mitigation: Confirm create and update payloads and intended effects with the user before running write actions. <br>
Risk: The skill may require installing or invoking the OOMOL CLI if it is not already available. <br>
Mitigation: Verify the OOMOL CLI installer source before installation and use the existing signed-in account when available. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-hubspot) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [HubSpot Homepage](https://www.hubspot.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution and returns connector responses as JSON when commands are run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
