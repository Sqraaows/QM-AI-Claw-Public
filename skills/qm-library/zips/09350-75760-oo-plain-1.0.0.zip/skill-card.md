## Description: <br>
Plain (plain.com). Use this skill for reading, creating, and updating Plain customer data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, support teams, and operators use this skill to look up, search, create, and update Plain customer records through the OOMOL oo CLI. The skill is intended for customer-management workflows where the agent can inspect the live connector schema and execute Plain connector actions with JSON payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access Plain customer data through OOMOL and requires sensitive account credentials or connection scopes. <br>
Mitigation: Install it only for intended Plain account access, review Plain connection scopes, and reconnect or reauthorize only when an auth or scope error occurs. <br>
Risk: The upsert action can create or update customer records and change Plain state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: The setup guidance includes remote installer commands for the oo CLI. <br>
Mitigation: Prefer installing the oo CLI from a trusted source and review installer commands before execution. <br>


## Reference(s): <br>
- [Plain homepage](https://www.plain.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-plain) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown with inline bash, PowerShell, text, and JSON examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses with data and meta.executionId fields when run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
