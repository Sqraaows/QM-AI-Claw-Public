## Description: <br>
Use this skill for Shodan searching and data-reading requests through an OOMOL-connected Shodan account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, security analysts, and operations teams use this skill to run Shodan host search, host lookup, DNS lookup, and API account inspection workflows from an agent. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected OOMOL account and Shodan credentials to query external security data. <br>
Mitigation: Install only if you trust oomol and intend to connect Shodan; review prompts and query payloads before execution. <br>
Risk: Shodan searches and host lookups can expose sensitive infrastructure intelligence or consume API credits. <br>
Mitigation: Confirm the target, query, and expected credit impact before running broad searches or account-related checks. <br>


## Reference(s): <br>
- [Shodan homepage](https://www.shodan.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-shodan) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
