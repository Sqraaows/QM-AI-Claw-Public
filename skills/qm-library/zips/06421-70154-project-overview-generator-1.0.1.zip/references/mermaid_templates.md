# Mermaid 图模板（常用场景）

> 所有架构/流程图统一用 Mermaid。写入 Markdown 时用 ` ```mermaid ... ``` ` 包裹。

---

## 一、整体架构图（分层架构）

### 模板：后端服务（典型 API / 业务层 / 基础设施分层）

```mermaid
flowchart TD
    Client["客户端 / Web / CLI / MCP Agent"]
    API["API 层<br/>(Handler / Controller / Route)"]
    Service["业务层<br/>(Service / UseCase)"]
    Domain["领域层<br/>(Module / Domain / Entity)"]
    Infra["基础设施层<br/>(DB / Cache / MQ / 外部服务)"]

    Client -->|HTTP / RPC / gRPC| API
    API --> Service
    Service --> Domain
    Domain --> Infra
    
    style API fill:#e1f5ff
    style Service fill:#fff4e1
    style Domain fill:#f0e5ff
    style Infra fill:#e5ffe1
```

### 模板：前端应用

```mermaid
flowchart TD
    Pages["Pages / Routes<br/>(路由层)"]
    Components["Components<br/>(UI 组件)"]
    Hooks["Hooks / Composables<br/>(状态/逻辑复用)"]
    Store["Store<br/>(Redux / Zustand / Pinia)"]
    Services["Services<br/>(API 调用)"]
    API["后端 API"]

    Pages --> Components
    Pages --> Hooks
    Components --> Hooks
    Hooks --> Store
    Hooks --> Services
    Services -->|fetch / axios| API
```

### 模板：CLI 工具

```mermaid
flowchart TD
    User["用户"]
    CLI["CLI 入口<br/>(argparse / cobra / clap)"]
    CmdRouter["命令路由"]
    Cmds["子命令实现"]
    Core["核心能力层"]
    FS["文件系统 / 外部工具"]

    User -->|命令行参数| CLI
    CLI --> CmdRouter
    CmdRouter --> Cmds
    Cmds --> Core
    Core --> FS
```

### 模板：微服务 / 多服务架构

```mermaid
flowchart TB
    subgraph Gateway["API Gateway"]
        GW["网关 / 负载均衡"]
    end

    subgraph Services["微服务集群"]
        SA["Service A<br/>(xxx)"]
        SB["Service B<br/>(yyy)"]
        SC["Service C<br/>(zzz)"]
    end

    subgraph Infra["基础设施"]
        DB[(MySQL)]
        Cache[(Redis)]
        MQ[/Kafka/]
    end

    Client --> GW
    GW --> SA & SB & SC
    SA -->|rpc| SB
    SA --> DB & Cache
    SB --> DB & MQ
    SC --> Cache & MQ
```

---

## 二、模块依赖图

### 模板：核心模块互相依赖

```mermaid
graph LR
    api[api 层]
    module[module<br/>元数据中心]
    task[task<br/>任务引擎]
    extender[cloudextender<br/>资源适配层]
    k8s[internal/pkg/k8s]
    db[middleware/db]

    api --> module
    api --> task
    task --> module
    task --> extender
    extender --> k8s
    module --> db
    task --> db
```

### 模板：业务流依赖（从入口到数据）

```mermaid
graph LR
    subgraph "入口层"
        A[Handler]
    end
    subgraph "逻辑层"
        B[Service]
        C[Validator]
    end
    subgraph "数据层"
        D[Repository]
        E[Cache]
    end

    A --> B
    B --> C
    B --> D
    B --> E
    D --> DB[(Database)]
    E --> Redis[(Redis)]
```

---

## 三、核心数据流 / 时序图

### 模板：HTTP 请求完整路径

```mermaid
sequenceDiagram
    autonumber
    participant C as Client
    participant H as Handler
    participant S as Service
    participant R as Repository
    participant DB as Database
    participant Cache as Cache

    C->>H: POST /api/xxx (payload)
    H->>H: 参数校验
    H->>S: ProcessXxx(ctx, req)
    S->>Cache: Get(key)
    alt 缓存命中
        Cache-->>S: data
    else 缓存未命中
        S->>R: FindXxx(ctx, id)
        R->>DB: SELECT ...
        DB-->>R: row
        R-->>S: entity
        S->>Cache: Set(key, data)
    end
    S-->>H: result
    H-->>C: 200 OK
```

### 模板：异步任务流

```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant API as API Handler
    participant DB as 数据库
    participant Q as Workqueue
    participant W as Worker
    participant EX as Executor

    U->>API: 发起任务 (POST /task/expand)
    API->>DB: 落任务记录
    API->>Q: Push(taskID)
    API-->>U: 202 Accepted + taskID
    
    loop 调度主循环
        W->>Q: Pop()
        Q-->>W: task
        W->>EX: Execute(task)
        EX->>DB: 更新状态=进行中
        EX->>EX: 执行实际动作
        EX->>DB: 更新状态=完成
    end
    
    U->>API: 轮询 GET /task/{id}
    API->>DB: 查询状态
    API-->>U: 任务结果
```

### 模板：消息驱动 / 事件流

```mermaid
sequenceDiagram
    autonumber
    participant P as Producer
    participant MQ as Kafka
    participant C1 as Consumer 1
    participant C2 as Consumer 2
    participant DB as 数据库

    P->>MQ: Publish(topic, event)
    par 并行消费
        MQ->>C1: Consume
        C1->>DB: 持久化
        and
        MQ->>C2: Consume
        C2->>C2: 业务处理
    end
```

---

## 四、状态机图

### 模板：任务生命周期

```mermaid
stateDiagram-v2
    [*] --> Pending: 创建
    Pending --> Running: 调度器选中
    Running --> Success: 执行成功
    Running --> Failed: 执行失败
    Failed --> Pending: 重试
    Failed --> [*]: 超过重试次数
    Running --> Cancelled: 用户取消
    Success --> [*]
    Cancelled --> [*]
```

---

## 五、类图（Class Diagram）

### 模板：工厂/策略模式

```mermaid
classDiagram
    class ResourceFactory {
        <<interface>>
        +CreateResource(type) Resource
        +Validator() Validator
    }

    class Workload {
        <<interface>>
        +Start() error
        +Stop() error
        +Scale(n int) error
    }

    class PCG123Factory {
        +CreateResource(type) Resource
        +Validator() Validator
    }

    class EKSFactory {
        +CreateResource(type) Resource
        +Validator() Validator
    }

    class KarmadaFactory {
        +CreateResource(type) Resource
        +Validator() Validator
    }

    ResourceFactory <|.. PCG123Factory
    ResourceFactory <|.. EKSFactory
    ResourceFactory <|.. KarmadaFactory
    PCG123Factory --> Workload : 创建
```

---

## 六、ER 图（数据模型）

```mermaid
erDiagram
    USER ||--o{ ORDER : places
    ORDER ||--|{ ORDER_ITEM : contains
    PRODUCT ||--o{ ORDER_ITEM : "ordered in"

    USER {
        int id PK
        string email
        string password_hash
        datetime created_at
    }
    ORDER {
        int id PK
        int user_id FK
        string status
        decimal total
    }
    ORDER_ITEM {
        int id PK
        int order_id FK
        int product_id FK
        int quantity
        decimal price
    }
    PRODUCT {
        int id PK
        string name
        decimal price
        int stock
    }
```

---

## 七、甘特图 / 时间线（较少用）

仅当项目 README 有明确的 roadmap 时使用。

```mermaid
gantt
    title 项目路线图
    dateFormat  YYYY-MM-DD
    section 阶段一
    核心能力      :done, 2024-01-01, 2024-03-01
    section 阶段二
    扩展能力      :active, 2024-03-01, 60d
    section 阶段三
    生态集成      :2024-06-01, 90d
```

---

## ⚠️ Mermaid 使用注意

1. **节点 ID 不能有特殊字符**。用简短英文 ID + 中文 label：
   ```mermaid
   A["中文节点"]
   ```

2. **中文标签要用引号**：`A["用户模块"]`，不能 `A[用户模块]`（可能渲染失败）

3. **连接符正确使用**：
   - `-->` 实线箭头
   - `-.->` 虚线箭头
   - `==>` 粗箭头
   - `--text-->` 带文字的箭头

4. **subgraph 必须有 end**：
   ```mermaid
   subgraph "名字"
       A --> B
   end
   ```

5. **生成后务必检查语法**。最简单的校验：复制到 https://mermaid.live/ 看能否渲染。

6. **节点过多时**（> 15 个）：拆成多张图，或用 `subgraph` 分组
