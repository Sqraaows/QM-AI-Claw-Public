# 章节写作范例（借鉴 core_admin 最佳实践）

> 本文提供各章节的**高质量写作示例**，供 agent 生成文档时模仿。

---

## 一、项目是什么 — 好的示例

> **core_admin** 是 **123 平台（PCG 容器平台）的后台服务（Admin Server）**，基于腾讯 **tRPC-Go** 框架实现，对接底层 Kubernetes / TAPP / Karmada 等多种容器运行时，向上为 Web 控制台、运维工具、MCP Agent、Taf 周边系统等提供统一的服务管理、发布部署、资源编排能力。
>
> - 语言栈：Go + tRPC-Go
> - 存储：TDSQL（MySQL）+ Redis + COS + CDMQ / Kafka
> - 部署：双集群 TAPP 部署，ConfigMap 注入配置
> - 入口：`cmd/operator/operator.go`

### ✅ 好在哪
- **一句话定位**极其清晰：说明了"是什么"、"给谁用"、"对接什么"、"提供什么能力"
- 紧接着是**技术选型摘要**，让读者马上有技术画像
- 写明**入口文件**，告诉读者从哪读起

### ❌ 反面教材
- "这是一个功能强大的后台服务" — 空话
- "提供各种能力" — 不具体
- "采用先进的架构" — 没信息量

---

## 二、快速开始 — 好的示例

````markdown
### 前置要求
- Go 1.20+
- Docker（用于本地启动依赖的 MySQL/Redis）
- kubectl（如需连接真实 K8s 集群）

### 3 分钟跑起来
```bash
# 1. 克隆并进入目录
git clone https://git.woa.com/pcg/core_admin && cd core_admin

# 2. 启动本地依赖（MySQL + Redis）
docker compose -f dev/docker-compose.yml up -d

# 3. 拉依赖
go mod download

# 4. 启动服务
make run
# 或：go run cmd/operator/operator.go -conf conf/trpc_go.yaml
```

### 验证启动成功
```bash
curl http://localhost:8000/trpc.admin.Health/Ping
# 期望：{"code":0,"msg":"ok"}
```

### 常见启动问题
- **连不上 MySQL**：检查 `conf/trpc_go.yaml` 中的 DSN 是否指向本地 docker 实例
- **端口冲突**：默认 8000，修改 `conf/trpc_go.yaml` 中的 `server.service[0].port`
````

### ✅ 好在哪
- 给出**最小可运行**命令组合
- 有明确的**验证命令**（不是让用户自己猜）
- 常见问题按"症状 → 原因 → 解决"组织

---

## 三、核心概念 — 好的示例

````markdown
### 1. Env-App-Server 三级模型

**是什么**：平台所有元数据都围绕这个三级实体展开：
- **Env（环境）**：逻辑隔离单位，如 "prod"、"test"、"gray"
- **App（应用）**：一个业务产品，对应若干 Module
- **Module（模块/服务）**：最小的部署/运维单元，由多个 Container 实例组成

**为什么重要**：
几乎所有 API 参数、任务、权限、配额都是这三级的组合。理解这个模型，才能看懂 90% 的 DAO 方法。

**涉及代码**：
- `internal/app/module/env_service/` — Env 元数据管理
- `internal/app/module/env_module_service/` — Env-Module 绑定
- `internal/app/module/module_service/` — Module 本体

### 2. 任务 (Task) 模型

**是什么**：所有对服务的变更（扩容、缩容、发布、重启）都不是同步执行，而是先落库为 Task，再由调度器异步推进。

**为什么重要**：
- 天然支持**限流**：同一服务同时只能有 1 个任务在跑
- 天然支持**审计**：每个变更都可追溯
- 天然支持**回滚**：失败可自动或手动重试

**涉及代码**：
- `internal/app/task/task_dao.go` — 任务持久化
- `internal/app/task/scheduler/` — 调度器
- `internal/app/task/executor/` — 执行器
````

### ✅ 好在哪
- 用"**是什么** / **为什么重要** / **涉及代码**"三段式
- 每个概念都指向具体代码位置

---

## 四、技术栈 — 好的示例

用**表格**，不要用一堆点的列表。

````markdown
| 分类 | 选型 | 说明 |
|------|------|------|
| 语言 | Go 1.20 | |
| RPC 框架 | tRPC-Go v1.0 | 腾讯自研 RPC 框架 |
| ORM | GORM v2 | 读写分离封装在 `middleware/db/` |
| Cache | Redis（go-redis） | 分桶缓存 + 分布式锁 |
| MQ | CDMQ + Kafka | 任务事件与 crontask |
| K8s 客户端 | client-go + karmada-apiserver | 多集群支持 |
| 配置中心 | Rainbow | 热加载 |
| 日志 | tRPC log + 自定义 hook | |
| 监控 | Galileo + 自定义 report | |
| 部署 | TAPP（深圳 + 广州双集群） | ConfigMap 注入 |
````

---

## 五、系统架构图 — 好的示例

**画 3 张图**（最少）：
1. **整体架构图** — 纵向分层
2. **核心模块依赖图** — 横向模块关系
3. **主流程时序图** — 典型请求的端到端

参见 `mermaid_templates.md` 里的模板。

---

## 六、目录结构 — 好的示例

````markdown
```
core_admin/
├── api/                对外 RPC 接口实现层（tRPC pb stub 的 handler）
├── cmd/operator/       可执行入口（依赖装配 / Serve）
├── internal/app/       业务模块实现（module、task、crontask、cloudextender…）
├── internal/pkg/       基础组件（k8s、thirdparty、middleware、utils…）
├── pkg/                对外可复用的小工具（jsonpb、filter、validator…）
├── skills/             内部 Agent Skill 脚本
├── docs/               方案 / 部署 / 设计文档
└── third_party/        外部共享物
```

### 设计约定
- **模块内自建 dao / service，不跨模块调用 dao** — 这是整个代码库最重要的纪律
- **依赖通过接口在 main 中注入**，业务模块都实现自己的 `New` + mock 文件
- **内部包放 `internal/`，Go 编译器会阻止外部 import**
- **自动生成的代码**（如 pb、mock）单独放置，避免污染审查
````

### ✅ 好在哪
- 目录树每行都有**精炼注释**
- 紧跟**设计约定**，这是新人**最需要知道**的"潜规则"

---

## 七、核心模块详解 — 好的示例

### 格式要求（必须遵守）

````markdown
### N. `{模块路径}` — {一句话定位}

**职责**：
- 要点 1
- 要点 2
- 要点 3

**子模块 / 文件清单**（用表格）：

| 子包 / 文件 | 说明 |
|-------------|------|
| `xxx_dao.go` | 任务 DAO |
| `xxx_service.go` | 业务逻辑 |

**核心函数**：

#### `FunctionName`
- **签名**：`func (s *Service) FunctionName(ctx context.Context, req *Req) (*Resp, error)`
- **位置**：`path/to/file.go:L123`
- **职责**：用 1-2 句话描述它做什么，为什么存在
- **调用关系**：被 xxx 调用；调用 yyy
- **关键逻辑**：

```go
func (s *Service) FunctionName(ctx context.Context, req *Req) (*Resp, error) {
    // 1. 参数校验
    if err := req.Validate(); err != nil {
        return nil, err
    }

    // 2. 核心步骤...
    //（具体代码，按 core_signals.md 的规则裁剪）

    return resp, nil
}
```

**说明 / 注意事项**：
- {坑点 1}
- {并发安全性说明}
````

### 核心模块描述的"信息密度"范例

❌ **反面**：
> "task 模块负责处理任务相关的功能，包括任务的创建、执行、状态管理等。"
>
> （这种描述等于什么都没说）

✅ **正面**：
> **`task/` — 任务执行引擎**
>
> 平台所有变更动作（扩 / 缩 / 发布 / 重启 / 停止 / 迁移 / 重建…）都落在这里。关键子能力：
>
> - **任务模型**：`task_dao` / `subtask_dao` / `task_process` 定义了任务三层结构
> - **调度器 `scheduler/`**：基于 MySQL 的持久化工作队列 + 分区选主 + Worker 池
> - **多级限流 `limiter/`**：自定义限流、服务级限流、全局限流三层叠加
> - **执行器 `executor/`**：按资源平台类型分发（TAPP / EKS / Karmada），统一接 `Workload` 接口
> - **超时/回调 `handler/`**：Pod Binding / Pod Deleting / COA 进程钩子的超时控制
> - **任务派生 `notify/`**：状态变更通知、告警、回调、镜像发布通知分别走不同策略

---

## 八、关键业务场景 — 好的示例

每个场景的结构：

````markdown
### 场景 N：{场景名}

**业务含义**：{1-2 句}

**触发入口**：`{API/CLI/事件}`

**调用链**（用纯文本，便于复制）：

```
[1] api/xxx/yyy.go:Handle()             ← 入口
    ↓
[2] internal/app/zzz/service.go:Do()    ← 业务逻辑
    ↓
[3] internal/pkg/aaa/bbb.go:Execute()   ← 底层动作
```

**时序图**：

```mermaid
sequenceDiagram
    ...
```

**涉及文件**：
- `api/xxx/yyy.go`
- `internal/app/zzz/service.go`

**新手建议阅读顺序**：
1. 先读 `xxx` — 了解入参/出参契约
2. 再读 `yyy` — 理解业务编排
3. 最后读 `zzz` — 细节实现
````

### 核心理念
**场景的价值在于"带路"**。读者顺着场景描述能把相关代码**跟读一遍**，比读纯文档强十倍。

---

## 九、如何运行 — 好的示例

````markdown
### 本地开发模式
```bash
make run          # 自动加载 dev 配置
make run-dbg      # 带 delve 调试
```

### 运行测试
```bash
make test         # 单元测试
make test-e2e     # 端到端测试（需要 minikube）
make lint         # 代码检查
```

### 构建与打包
```bash
make build        # 编译二进制
make image        # 构建 Docker 镜像
```

### 部署
- **生产部署通过 TAPP 双集群**：ConfigMap 注入 `conf/trpc_go.yaml`
- **CI/CD**：见 `.github/workflows/` 或 `ci/`
- **发布流程**：见 `docs/release.md`

### 关键环境变量
| 变量 | 必填 | 说明 |
|------|------|------|
| `CONFIG_PATH` | 是 | 配置文件路径 |
| `DB_DSN` | 是 | MySQL DSN |
| `REDIS_ADDR` | 是 | Redis 地址 |
| `LOG_LEVEL` | 否 | debug / info / warn（默认 info） |

### 观测与运维
- **日志**：标准输出 + `/data/logs/admin/`（容器内）
- **健康检查**：`GET /health`
- **监控指标**：Galileo 指标 + Prometheus `/metrics`
- **优雅关闭**：`kill -SIGTERM`，会等待任务队列处理完
````

---

## 十、同类项目对比 — 好的示例

**适用场景**：项目是知名开源项目（如 LangChain / Kratos / FastAPI / DeerFlow / HermesAgent 这类）。

````markdown
### 同类项目选型

| 项目 | 定位 | 语言 | 核心差异 |
|------|------|------|----------|
| **HermesAgent**（本项目） | 通用 AI Agent 编排框架 | Python | 强调工具动态注册 + 人机协作 |
| OpenClaw | Desktop agent 框架 | TypeScript | 面向桌面操作，Electron 集成 |
| LangChain Agent | LLM 工具链框架 | Python | 组件丰富但耦合重，偏 prompt 工程 |
| AutoGPT | 自主 agent 实现 | Python | 偏"全自动化"理念，可控性较弱 |

### 五维对比

#### 1. 定位
- **HermesAgent**：强调**工具动态发现 + 人机协作**，适合企业内部业务流程自动化
- **OpenClaw**：强调**桌面端自动化**，用户能看到 agent 在操作电脑
- **LangChain**：强调**LLM + 工具链**的通用编程模型，适合作为 SDK 嵌入应用

#### 2. 技术栈
- **HermesAgent**：Python + FastAPI + ...
- **OpenClaw**：TypeScript + Electron + ...
- **LangChain**：Python + pydantic + ...

#### 3. 核心能力
| 能力 | HermesAgent | OpenClaw | LangChain |
|------|-------------|----------|-----------|
| 工具动态注册 | ⭐⭐⭐ | ⭐ | ⭐⭐ |
| 人机协作 | ⭐⭐⭐ | ⭐⭐⭐ | ⭐ |
| 桌面自动化 | ⭐ | ⭐⭐⭐ | ⭐ |
| 多 LLM 适配 | ⭐⭐ | ⭐⭐ | ⭐⭐⭐ |

#### 4. 设计理念
- **HermesAgent**："Agent as a Service"，面向服务化部署
- **OpenClaw**："Agent on your desktop"，面向本地操作
- **LangChain**："Agent as a Library"，面向嵌入式场景

#### 5. 适用场景
- **HermesAgent**：企业内部流程自动化、多业务线统一 Agent 平台
- **OpenClaw**：个人效率工具、桌面自动化脚本
- **LangChain**：快速 POC、RAG 应用、LLM 应用脚手架

### 推荐阅读顺序
如果你熟悉 LangChain，理解 HermesAgent 可以从这里入手：
1. 先看 `agent/core.py` 对比 LangChain 的 AgentExecutor
2. 再看 `tools/registry.py` 理解动态工具注册（LangChain 静态注册）
3. 最后看 `workflow/` 看人机协作机制（LangChain 没有对应概念）
````

### ⚠️ 对比章节的写作纪律
1. **不贬低竞品**：如实描述差异，不做"XXX 不如我们"的判断
2. **聚焦差异而非细节**：五维对比足以说清，不要展开到具体 API
3. **引用要客观**：可用 star 数、功能清单、官方文档作为依据，不要臆测
4. **必要时加"推荐阅读顺序"**：帮助从竞品迁移过来的读者快速切入

---

## 总结：章节评分自检清单

生成完文档后，用这个清单自查：

- [ ] "项目是什么"能让人 30 秒 get 到定位吗？
- [ ] "快速开始"的命令能直接复制粘贴运行吗？
- [ ] "核心概念"有具体代码路径吗？
- [ ] "技术栈"是表格不是长段落吗？
- [ ] "架构图"至少有 3 张 Mermaid 吗？
- [ ] "目录结构"每行都有注释吗？有"设计约定"段吗？
- [ ] "核心模块"每个都展开到函数签名 + 关键逻辑吗？
- [ ] "关键场景"至少有 2 个完整的调用链吗？
- [ ] "如何运行"有真实可跑的命令吗？
- [ ] （可选）"对比章节"公允客观吗？

任何一项打不了勾，就回头补。
