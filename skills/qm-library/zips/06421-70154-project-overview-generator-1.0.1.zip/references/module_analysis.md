# 模块级分析策略（Module Mode Specifics）

> 本文件专门为 **Module Mode** 提供分析策略。核心思路：**模块最宝贵的信息是"边界"**——对外暴露什么、谁在用它、它依赖谁。

---

## 一、核心理念：模块 vs 项目

| 维度 | 项目级视角 | 模块级视角 |
|------|------------|------------|
| 关注点 | 系统整体 | 在系统中的**定位与边界** |
| 架构图 | 分层/全局 | **内部结构 + 与外部的边界** |
| 核心代码 | 核心模块 | 核心**子包/文件/符号** |
| 场景 | 业务场景 | **使用场景**（谁怎么用它） |
| 独有章节 | 快速开始 / 部署 / 对比 | **模块边界 / 修改指南** |

**关键差异**：模块级分析的读者通常是**调用方**或**扩展方**，他们关心"怎么用、怎么改、不要踩哪些坑"，而不是"怎么跑整个系统"。

---

## 二、识别"父项目根"（Locate Project Root）

当用户给的路径不是项目根时，需要**向上追溯**找到父项目根。

### 策略：逐级向上查找

从目标路径开始，每次取父目录，检查是否存在标识文件：

```
目标路径：/path/to/repo/internal/app/task
  ↓ 检查
/path/to/repo/internal/app/task    → 无 go.mod
/path/to/repo/internal/app         → 无
/path/to/repo/internal             → 无
/path/to/repo                      → 找到 go.mod ✅（父项目根）
```

### 标识文件优先级
按 `language_signals.md` 中的标识文件顺序检查，**任一存在即为项目根**。

### 特殊情况

1. **Monorepo 子项目**：目标路径往上找到的是 **子项目根**（如 `packages/xxx`），而非仓库根。这种情况：
   - 子项目根按 Project Mode 分析（如果用户指定的就是子项目根）
   - 如果用户指定的是子项目内的模块，则以**子项目根**作为父项目根

2. **找不到标识文件**（超过 5 层父目录仍无）：
   - 不要猜，询问用户
   - 或作为无项目上下文的 Module Mode 处理（跳过上游扫描）

---

## 三、对外暴露 API 的提取（Exported Surface）

**模块级分析的重中之重**。必须枚举完整。

### 各语言的 "Exported" 规则

| 语言 | 规则 | 识别命令参考 |
|------|------|--------------|
| **Go** | 首字母大写 | `grep -E "^(func \|type \|var \|const )[A-Z]" *.go` |
| **JS/TS** | `export` / `export default` | `grep -E "^export " *.ts` |
| **Python** | 不以 `_` 开头；或在 `__all__` 中 | 读 `__init__.py` 的 `__all__` |
| **Java** | `public` 修饰符 | `grep "public " *.java` |
| **Rust** | `pub` 关键字 | `grep "^pub " *.rs` |
| **Ruby** | 类/模块的公开方法（非 `private` 之后的） | 人工扫描 |
| **C#** | `public` 修饰符 | `grep "public " *.cs` |

### 分类枚举

按以下分类组织所有公开符号：

1. **Constructors / Factory Functions** — 如何实例化模块
2. **Primary Methods** — 模块的核心业务方法
3. **Types / Structs / Classes** — 对外暴露的数据结构
4. **Interfaces / Protocols / Abstract Classes** — 契约定义
5. **Constants / Enums** — 公开的常量
6. **Hooks / Extension Points** — 允许上游扩展的钩子

### 稳定性标记建议

| 标记 | 含义 | 判断依据 |
|------|------|----------|
| ✅ 稳定 | API 已被多处调用，破坏性变更影响大 | 上游引用 ≥ 3 处，或在 README/docstring 中明确为公开 API |
| ⚠️ 可能变 | 新加入 / 实验性 / 标记为 beta | 代码注释含 `TODO` / `FIXME` / `experimental` / `beta` |
| 🚧 内部暂时公开 | 技术上公开但不建议外部使用 | 命名含 `Internal` / 文档明确说 "internal use only" |

---

## 四、上游调用方扫描（Who Uses This Module）

### 扫描策略

1. **确定模块的"引用签名"**（多种形式）：
   - Go：`"github.com/org/repo/internal/app/task"` / `"path/to/task"`
   - JS/TS：`from '@org/package/task'` / `from './task'`
   - Python：`from project.task import` / `import project.task`
   - Java：`import com.xxx.task.`

2. **在父项目根范围内搜索**这些签名：
   - 用 `search_content` 工具，排除模块本身目录（避免自引用）
   - 排除 test 文件（可选，看是否需要）

3. **按调用方模块聚合**：
   - 不要把 50 处引用平铺列出
   - 按调用方所在目录归类：`api/xxx` 内 3 处、`app/yyy` 内 5 处 ...

### 输出格式

```markdown
| 调用方 | 引用位置 | 使用方式 |
|--------|----------|----------|
| `api/task` | `api/task/expand.go:45`, `api/task/delete.go:78` | 直接 New + Handle |
| `app/scheduler` | `app/scheduler/worker.go:123` | 通过 DI 注入 TaskInterface |
| `cmd/cli` | `cmd/cli/task_cmd.go:56` | CLI 入口调用 |
```

### 使用模式归纳

统计完引用点后，**用一两句话概括"常见使用模式"**，例如：
- "几乎所有调用都通过 `TaskInterface` 做依赖注入，只有 CLI 直接 new 实例"
- "任务创建场景用 `CreateTask()`，状态查询场景用 `QueryTask()`，这两个覆盖了 80% 的调用"

---

## 五、下游依赖分析（What This Module Depends On）

### 扫描方法

1. **读取模块内所有源文件的 import 语句**
2. **去重并分类**：
   - **内部依赖**（父项目其他模块）：path/package 包含父项目的根路径前缀
   - **外部依赖**（第三方）：其他（标准库不需列出）
3. **按使用频次 + 依赖深度排序**：用得多的放前面

### 输出要点

- 每个依赖**标注用途**：不要只写包名，要写"做什么用的"
- 特别标注**关键依赖**：如数据库驱动、RPC 框架、核心算法库
- 循环依赖检查：如果发现本模块和其他内部模块**互相 import**，在文档中明确警示（是设计隐患）

---

## 六、接口契约（Interface Contracts）

### 为什么重要
接口是模块对外的"合同"。理解接口比理解实现更重要——上游通常只依赖接口，实现可替换。

### 识别策略

1. **找所有 interface / abstract class / protocol 定义**：
   - Go：`type Xxx interface { ... }`
   - Java：`public interface Xxx` / `public abstract class`
   - Python：`class Xxx(Protocol)` / `class Xxx(ABC)`
   - TS：`export interface Xxx` / `export abstract class`

2. **找这些接口的实现**：
   - 模块内有哪些 struct/class 实现了它？
   - 模块外有哪些 mock/stub/替代实现？

3. **识别"接口契约"中的隐含约定**：
   - 并发安全性（是否要求线程安全？）
   - 幂等性（多次调用是否等价？）
   - 错误语义（返回 nil/empty 还是 error？）
   - 超时约定（ctx 是否必传？）
   - **这些约定通常写在接口方法的注释里，要仔细读并提取**

### 写入文档

```markdown
### 6.2 接口契约

#### `TaskExecutor` — 任务执行器抽象

```go
type TaskExecutor interface {
    // Execute 执行任务。
    // 约定：
    // - 必须幂等：同一 taskID 多次调用等价
    // - 必须尊重 ctx：ctx 取消时立即返回 context.Canceled
    // - 返回 error 表示不可恢复失败；可恢复错误通过 Task.Status 体现
    Execute(ctx context.Context, task *Task) error

    // Name 返回执行器类型名，用于日志和调度选择
    Name() string
}
```

**实现者**：
- `TAppExecutor` — 针对 TAPP 工作负载
- `EKSExecutor` — 针对 EKS
- `MockExecutor` — 测试用（见 `mocks/` 目录）
```

---

## 七、扩展点识别（Extension Points）

### 什么算"扩展点"
允许**上游或第三方注入自定义逻辑**的机制：

1. **接口 + 注册表模式**：模块定义 interface + 提供 `RegisterXxx()` 注册函数
2. **钩子函数**：模块接受 callback / hook 参数
3. **事件/观察者**：订阅机制（如 `AddListener`）
4. **插件目录**：约定加载 `plugins/` 下的外部模块
5. **配置驱动**：通过配置选择不同实现

### 识别信号

- 找 `Register*` / `AddHandler` / `Subscribe` / `Use*` / `Plug*` 类函数
- 找 interface + factory 组合
- 找 `type XxxFunc func(...)` 类型（函数式钩子）

### 文档展示

```markdown
### 6.5 扩展点

#### 1. 自定义 TaskExecutor
- **扩展方式**：实现 `TaskExecutor` 接口 + 调用 `RegisterExecutor(name, executor)`
- **注册位置**：通常在 `cmd/main` 初始化时
- **示例**：参见 `internal/app/task/executor/eks_executor.go`

#### 2. 任务事件订阅
- **扩展方式**：实现 `TaskEventListener` + 调用 `task.AddListener(listener)`
- **触发时机**：任务状态变更时（创建、进行中、完成、失败）
- **注意**：listener 调用**串行**且在**任务主流程内**，耗时操作请异步化
```

---

## 八、典型使用场景的提取（Usage Scenarios）

Module Mode 的场景**不同于**业务流程，更接近"API 调用示例"。

### 提取策略

1. **从上游调用方中挑 2-3 个代表性场景**
   - 覆盖不同的使用模式（如一个直接调用、一个通过接口注入、一个带配置）
   - 优先选**调用链最清晰**或**注释最详细**的调用点

2. **每个场景包含**：
   - 调用方的真实代码片段（从上游拷贝，不伪造）
   - 模块内部的处理时序图
   - 常见坑点 / 注意事项

### 模板

````markdown
### 场景 1：通过接口注入使用（推荐方式）

**调用方**：`app/scheduler/worker.go:45`

**代码示例**：

```go
type Worker struct {
    executor task.TaskExecutor  // 依赖接口而非实现
}

func (w *Worker) Run(ctx context.Context, t *Task) error {
    // 通过接口调用，实现可在 DI 容器中替换
    return w.executor.Execute(ctx, t)
}
```

**内部处理**：

```mermaid
sequenceDiagram
    participant W as Worker
    participant E as TaskExecutor
    participant D as 底层驱动

    W->>E: Execute(ctx, task)
    E->>E: 前置校验
    E->>D: 调用底层 API
    D-->>E: 结果
    E-->>W: error or nil
```

**注意事项**：
- `ctx` 必传；用于传递 traceID 和控制超时
- `task.ID` 必须唯一，否则可能触发幂等短路
````

---

## 九、常见陷阱提醒（Common Pitfalls）

生成 Module Mode 文档时，特别注意：

### ❌ 避免做的事

1. **不要把模块当项目写**：不要出现"如何启动"、"部署方式"等章节
2. **不要漏扫上游**：这是 Module Mode 最核心的部分，必须扫
3. **不要只列实现、不列接口**：接口/契约优先级更高
4. **不要对内部实现过度详述**：展开到**核心子包和公开符号**即可，纯 helper 可以省略
5. **不要编造 API 文档**：所有"对外暴露 API"必须来自代码真实扫描

### ✅ 要做的事

1. **扫完整**：上游引用、下游依赖、公开 API、接口、扩展点，一个都不要漏
2. **区分公开/内部**：对外 API 重点说；内部实现简要带过
3. **标稳定性**：帮助上游评估"这个 API 是否可信赖"
4. **给使用示例**：最好的文档就是真实代码片段
5. **重点提醒坑**：并发、幂等、超时、错误语义这些容易踩的点

---

## 十、质量自检（Module Mode Checklist）

生成完成后，用这个清单自查：

- [ ] 父项目根识别正确，"模块在项目中的角色"清晰
- [ ] **对外暴露 API 是否枚举完整**？（漏一个就是失败）
- [ ] **上游调用方是否扫描了整个父项目**？（非只扫同一子目录）
- [ ] 内部依赖和外部依赖分开列了吗？
- [ ] 所有接口的契约注释都提取到文档了吗？
- [ ] 至少有 1 个真实的上游使用示例代码吗？
- [ ] 模块内部架构图画了吗？
- [ ] 没有写"如何启动"、"部署"这类不属于模块的内容吗？
- [ ] 没有"对比章节"（模块不做对比）吗？
- [ ] 修改/贡献指南给出了具体文件路径吗？
