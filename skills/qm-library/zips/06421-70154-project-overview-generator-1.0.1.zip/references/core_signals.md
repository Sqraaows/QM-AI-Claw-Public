# 核心模块 / 核心函数判定信号

> 理念：**不限数量**。只要满足任一强信号就列出。宁可多写，不可漏写。

---

## 一、核心模块（Module）判定

一个目录是否算"核心模块"？以下信号满足 **任一强信号** 或 **2 个以上中等信号** 即可列入。

### 强信号（⭐⭐⭐）

1. **被业务代码高频 import**
   - Go：`grep -r "project/path/to/module" --include="*.go" | wc -l` ≥ 10
   - JS/TS：`grep -r "from.*'./module'" --include="*.ts"` ≥ 5
   - Python：`grep -r "from module import" --include="*.py"` ≥ 5

2. **是项目的"主营业务"目录**
   - `internal/app/{dir}` 且非 `utils` / `constant`
   - `src/services/{dir}` / `src/features/{dir}`
   - `lib/{dir}` 里有 `README.md` 或独立文档

3. **目录规模大**
   - 文件数 ≥ 5 且**不全是 test 文件**
   - 或代码行数 ≥ 500

4. **含入口或注册点**
   - 有 `Init()` / `Register()` / `New()` / `Setup()` / 主入口被 main 调用
   - 是 DI 容器中注册的 Provider

### 中等信号（⭐⭐）

1. **目录名是业务语义名词**（不是 `utils` / `helper` / `common`）
2. **含子目录（有内部分层）**
3. **README 或 `docs/` 明确提到过**
4. **测试覆盖率高**（有配套的 `*_test.go` / `test_*.py`）

### 弱信号（⭐）

1. 目录名含 `service` / `manager` / `engine` / `controller`
2. 有独立的 `mock` 文件（说明有人关心它的行为）

### 💡 排除规则（明确不列为核心）

- `utils/` / `helpers/` / `common/` — 除非里面有独立的业务子模块
- `types/` / `models/` 单纯的类型定义 — 列入"目录结构"即可，不单独展开
- `config/` / `constants/` — 同上
- `generated/` / `gen/` / `*.pb.go` — 自动生成的代码
- `vendor/` / `node_modules/` / `third_party/` — 外部依赖
- `tests/` / `__tests__/` — 测试代码（测试覆盖场景会在"关键业务场景"章节体现）
- `docs/` / `examples/` — 文档和示例

---

## 二、核心函数 / 类 判定

在核心模块中，进一步识别"核心函数/类"并展示其**签名 + 关键逻辑**。

### 强信号（必列出）

1. **入口函数**
   - `main()` / `Main.main()`
   - Handler 入口：`ServeHTTP` / `Handle` / 装饰器标记的路由 handler
   - 定时任务/Worker 主循环：`Run()` / `Start()` / `Loop()`

2. **公开接口的实现方法**
   - Go：实现了核心 interface 的 struct 方法
   - Java：`@Override` 父接口/抽象类的方法
   - TS：`implements XxxService` 的类方法
   - Python：继承基类并重写的方法

3. **被多次调用的公开方法**
   - 全项目被调用 ≥ 3 次（非 test 代码）

4. **实现了核心抽象（Factory / Strategy / Adapter）**
   - 命名含 `Factory` / `Builder` / `Strategy` / `Adapter` / `Handler` / `Registry`

### 中等信号

1. **命名含动作词**
   - `Handle*` / `Process*` / `Execute*` / `Dispatch*` / `Run*` / `Serve*` / `Start*` / `Init*` / `Resolve*` / `Compile*` / `Build*` / `Submit*`

2. **函数较长**
   - Go / Java：单个函数 > 50 行
   - JS/TS/Python：单个函数 > 40 行
   - 通常是核心编排逻辑

3. **位于"关键文件"中**
   - `service.*` / `handler.*` / `controller.*` / `manager.*` / `scheduler.*` / `engine.*` / `runner.*` / `executor.*`

4. **注释密度高**
   - 有详尽的 doc comment（JSDoc / GoDoc / Python docstring），说明作者认为重要

### 弱信号（参考）

1. 有对应的 mock 文件（说明依赖它的地方多）
2. 被 test 文件直接测试（有 `TestXxx` 或 `test_xxx`）

---

## 三、关键逻辑代码展示规则

展示核心函数时，**按以下规则处理代码片段**：

### 规则 1：签名必须完整
```go
// ✅ 正确：完整签名
func (s *Scheduler) Execute(ctx context.Context, task *Task) (*Result, error)

// ❌ 错误：缩写签名
func Execute(...)
```

### 规则 2：函数体按"价值密度"处理

| 函数规模 | 处理方式 |
|----------|----------|
| ≤ 30 行 | **全量展示** |
| 30-80 行 | **保留全部控制流主线**（分支/循环/错误处理），**细节用注释代替** |
| > 80 行 | **保留骨架**（1. 2. 3. 4. 步骤注释），**每步附 1-2 行关键代码**，其余用伪代码或 `// 详见 xxx.go` |

### 规则 3：省略示例
```go
func (s *Service) Expand(ctx context.Context, req *ExpandRequest) (*Task, error) {
    // 1. 参数校验与权限检查（略：调用 validator.Validate + auth.Check）
    if err := s.validate(req); err != nil {
        return nil, err
    }

    // 2. 生成任务（核心逻辑：基于 req.Count 拆分子任务）
    task := &Task{
        ID:       taskno.Generate(),
        Type:     TaskExpand,
        Subtasks: s.splitSubtasks(req.Count),
    }

    // 3. 持久化与入队（略：事务包裹 DAO + workqueue.Push）
    if err := s.dao.InsertWithQueue(ctx, task); err != nil {
        return nil, err
    }

    return task, nil
}
```

### 规则 4：必须有上下文说明

每段代码前后要有文字说明：
- **前置**：函数**为什么存在**、**在系统中的角色**
- **后置**：调用关系（被谁调、调用谁）、坑点、并发/幂等说明

---

## 四、识别策略（Agent 操作建议）

1. **先用 `list_files` / 目录扫描** 得到顶层目录和文件统计
2. **用 `search_content` 统计 import 频次**，过滤出高频模块
3. **打开每个候选模块的入口文件**（`service.go` / `index.ts` / `__init__.py` 等），读取其中的公开函数签名
4. **对每个公开函数，用 `search_content` 搜索调用点数量**，决定是否列出
5. **读取函数体**，按上述规则提炼代码片段

### 性能建议
- 不要一次读超大文件。超过 500 行的文件，**先读头尾 + 抽样** 定位核心函数位置，再 offset/limit 精读
- 对于庞大的项目（>1000 个源文件），可以先只分析顶层 + 入口 + README 引用的模块，再逐步深入
