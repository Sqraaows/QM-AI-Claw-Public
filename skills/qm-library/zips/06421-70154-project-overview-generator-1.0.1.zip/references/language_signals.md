# 语言与框架识别信号（Language & Framework Signals）

本文件定义了各主流语言的识别规则。在 Phase 1 中按以下顺序匹配标识文件，识别出主语言后再做进一步框架识别。

## 识别优先级（从强到弱）

1. 构建/依赖清单文件（如 `go.mod`、`package.json`）— **最强信号**
2. 入口文件（`main.go` / `app.py`）
3. 源文件后缀统计（`.go` / `.ts` / `.py` / `.java` / `.rs`）
4. 文档描述（README 中的 "Built with" 等）

---

## Go

### 标识文件
- `go.mod`（必有）
- `go.sum`

### 入口文件
- `main.go` — 单体项目
- `cmd/*/main.go` — 多入口项目（最常见）

### 典型目录布局
```
project/
├── cmd/           # 可执行入口
├── internal/      # 内部代码（Go 标准约定，外部不可 import）
│   ├── app/       # 业务逻辑
│   └── pkg/       # 内部共享基础库
├── pkg/           # 可被外部 import 的公共库
├── api/           # 协议定义 / Handler
└── go.mod
```

### 框架识别
| 框架 | 信号 |
|------|------|
| tRPC-Go | `go.mod` 含 `trpc.group/trpc-go/trpc-go`；有 `trpc_go.yaml` |
| Gin | `go.mod` 含 `gin-gonic/gin` |
| Echo | `go.mod` 含 `labstack/echo` |
| gRPC | `go.mod` 含 `google.golang.org/grpc`；有 `*.proto` |
| Fiber | `go.mod` 含 `gofiber/fiber` |
| Kratos | `go.mod` 含 `go-kratos/kratos` |
| Go-Zero | `go.mod` 含 `zeromicro/go-zero` |

### 核心信号关键词
- 命名：`Handle` / `Serve` / `Execute` / `Run` / `Start`
- 文件：`service.go` / `handler.go` / `server.go` / `scheduler.go`
- 约定：实现 interface 的方法通常是核心

---

## JavaScript / TypeScript

### 标识文件
- `package.json`（必有）
- `tsconfig.json` → TypeScript
- `yarn.lock` / `pnpm-lock.yaml` / `package-lock.json` → 包管理器
- `deno.json` → Deno

### 入口文件
- `package.json` 的 `main` / `module` / `exports` 字段
- `src/index.ts` / `src/main.ts` / `src/app.ts`
- `server.js` / `app.js`（老项目）

### 典型目录布局
```
project/
├── src/
│   ├── components/       # React/Vue 组件
│   ├── pages/ | routes/  # 页面/路由
│   ├── services/         # 业务逻辑
│   ├── utils/            # 工具函数
│   └── types/            # TypeScript 类型定义
├── public/               # 静态资源
├── tests/ | __tests__/   # 测试
└── package.json
```

### 框架识别
| 框架 | 信号 |
|------|------|
| React | `package.json` 含 `react`；有 `.jsx`/`.tsx` |
| Vue | `package.json` 含 `vue`；有 `.vue` |
| Next.js | `package.json` 含 `next`；有 `next.config.js`/`app/` |
| Nuxt | `package.json` 含 `nuxt` |
| Express | `package.json` 含 `express` |
| NestJS | `package.json` 含 `@nestjs/core`；有 `main.ts` + `*.module.ts` |
| Fastify | `package.json` 含 `fastify` |
| Remix | `package.json` 含 `@remix-run/*` |
| Svelte | `package.json` 含 `svelte` |
| Hono | `package.json` 含 `hono` |

### 核心信号关键词
- 命名：`handle*` / `process*` / `execute*` / `create*Service`
- 装饰器：`@Controller` / `@Service` / `@Module`（NestJS）
- 文件：`*.controller.ts` / `*.service.ts` / `*.module.ts`

---

## Python

### 标识文件
- `pyproject.toml`（现代首选）
- `setup.py` / `setup.cfg`（老项目）
- `requirements.txt` / `requirements-*.txt`
- `Pipfile` / `poetry.lock`

### 入口文件
- `main.py` / `app.py` / `manage.py`（Django）
- `__main__.py`
- `pyproject.toml` 的 `[project.scripts]`

### 典型目录布局
```
project/
├── src/{package_name}/  # 新风格
  or {package_name}/     # 老风格
├── tests/
├── docs/
└── pyproject.toml
```

### 框架识别
| 框架 | 信号 |
|------|------|
| Django | 依赖 `django`；有 `manage.py` + `settings.py` |
| Flask | 依赖 `flask` |
| FastAPI | 依赖 `fastapi` |
| Starlette | 依赖 `starlette` |
| Tornado | 依赖 `tornado` |
| Sanic | 依赖 `sanic` |
| Celery | 依赖 `celery`；有 `celery.py` 或 `tasks.py` |
| PyTorch | 依赖 `torch` |
| TensorFlow | 依赖 `tensorflow` |
| LangChain | 依赖 `langchain` |
| Scrapy | 依赖 `scrapy`；有 `scrapy.cfg` |

### 核心信号关键词
- 命名：类继承（`class XxxService(BaseService)`）、`__init__` 长的那些
- 装饰器：`@app.route` / `@app.get` / `@task` / `@shared_task`
- 文件：`views.py` / `services.py` / `tasks.py` / `models.py`

---

## Java

### 标识文件
- `pom.xml` → Maven
- `build.gradle` / `build.gradle.kts` → Gradle
- `settings.gradle`

### 入口文件
- `src/main/java/.../*Application.java`（Spring Boot）
- `Main.java`

### 典型目录布局
```
project/
├── src/main/java/com/xxx/  # 源码
│   ├── controller/
│   ├── service/
│   ├── repository/
│   ├── model/ | entity/
│   └── config/
├── src/main/resources/     # 配置文件
│   ├── application.yml
│   └── mapper/             # MyBatis mapper
├── src/test/java/          # 测试
└── pom.xml
```

### 框架识别
| 框架 | 信号 |
|------|------|
| Spring Boot | `pom.xml` 含 `spring-boot-starter`；有 `@SpringBootApplication` |
| Spring MVC | 含 `spring-webmvc` |
| Micronaut | 含 `io.micronaut` |
| Quarkus | 含 `io.quarkus` |
| MyBatis | 含 `mybatis`；有 `*Mapper.xml` |
| Dubbo | 含 `dubbo` |

### 核心信号关键词
- 注解：`@Controller` / `@Service` / `@Repository` / `@Component`
- 文件：`*Controller.java` / `*Service.java` / `*Repository.java`

---

## Rust

### 标识文件
- `Cargo.toml`（必有）
- `Cargo.lock`

### 入口文件
- `src/main.rs` — 二进制 crate
- `src/lib.rs` — 库 crate

### 典型目录布局
```
project/
├── src/
│   ├── main.rs | lib.rs
│   ├── bin/            # 多个二进制入口
│   └── {modules}/
├── tests/              # 集成测试
├── benches/            # benchmark
├── examples/
└── Cargo.toml
```

### 框架识别
| 框架 | 信号 |
|------|------|
| Actix Web | `Cargo.toml` 含 `actix-web` |
| Axum | 含 `axum` |
| Rocket | 含 `rocket` |
| Warp | 含 `warp` |
| Tokio | 含 `tokio`（异步运行时，几乎必有） |
| Tauri | 含 `tauri`；有 `tauri.conf.json` |

### 核心信号关键词
- 命名：`pub fn` / `pub async fn` / `impl Xxx for Yyy`
- 文件：`service.rs` / `handler.rs` / `mod.rs`

---

## 其他语言速查

### Ruby
- 标识：`Gemfile` / `*.gemspec`
- 框架：Rails（有 `config.ru`）、Sinatra

### PHP
- 标识：`composer.json`
- 框架：Laravel（有 `artisan`）、Symfony

### C# / .NET
- 标识：`*.csproj` / `*.sln`
- 框架：ASP.NET Core（有 `Program.cs`）

### Kotlin
- 标识：`build.gradle.kts`
- 框架：Spring Boot / Ktor

### Swift
- 标识：`Package.swift` / `*.xcodeproj`
- 框架：Vapor、iOS SDK

---

## 多语言项目（Monorepo）

### 识别信号
- 根目录有 `lerna.json` / `pnpm-workspace.yaml` / `turbo.json` / `nx.json`
- 有 `packages/` / `apps/` / `services/` 且每个子目录有独立的依赖文件
- 根有 `go.work`（Go Workspace）

### 处理策略
1. **先识别根目录的组织方式**（npm workspaces / Lerna / Nx / Turbo / pnpm workspaces / Go workspaces）
2. **列出所有子项目**
3. **在 "项目是什么" 部分说明这是一个 Monorepo**，列出各子项目的职责
4. **"核心模块详解" 按子项目组织**，每个子项目作为一个顶级模块展开
5. **架构图要显示子项目之间的依赖关系**
