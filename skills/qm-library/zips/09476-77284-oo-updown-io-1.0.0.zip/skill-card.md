## Description: <br>
Helps agents manage updown.io monitoring checks and node information through an OOMOL-connected updown.io account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, site reliability teams, and external operators use this skill to list, inspect, create, update, and delete updown.io monitoring checks and to retrieve monitoring node metadata. It is intended for agents working with an already connected OOMOL updown.io account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can query updown.io account data through list and get actions. <br>
Mitigation: Install only when account querying or management is intended, and treat read actions as account-data access. <br>
Risk: Create, update, and delete actions can change or remove monitoring checks. <br>
Mitigation: Require a clear payload, intended effect, and explicit user confirmation before running state-changing or destructive actions. <br>
Risk: The skill requires a connected updown.io account with sensitive credentials handled by OOMOL. <br>
Mitigation: Use the documented OOMOL connection flow and avoid exposing raw updown.io API tokens to the agent. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-updown-io) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [updown.io homepage](https://updown.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON data with execution metadata; live connector schemas should be inspected before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
