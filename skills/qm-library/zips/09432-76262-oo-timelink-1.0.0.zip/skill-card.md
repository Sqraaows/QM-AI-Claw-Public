## Description: <br>
Operate Timelink through an OOMOL-connected account to read clients, projects, services, users, company details, token metadata, and time entries. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and business users can use this skill to query Timelink account data through the oo CLI after connecting their Timelink account. It supports read-oriented workflows such as looking up clients, projects, services, users, company information, token metadata, active timers, and time entries. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can retrieve Timelink account data using connected credentials, and the security review notes that broad routing could trigger retrieval on ambiguous Timelink mentions. <br>
Mitigation: Use the skill only for intentional requests to search, fetch, list, or read Timelink information, and require confirmation before using it for ambiguous Timelink references. <br>
Risk: Timelink account contents may include sensitive business or time-tracking data. <br>
Mitigation: Review the skill before installing it in environments with sensitive Timelink data and limit use to accounts and scopes appropriate for the task. <br>


## Reference(s): <br>
- [timelink homepage](https://timelink.io) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-timelink) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payload or response handling] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; responses are expected as JSON from the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence.release.version and SKILL.md metadata.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
