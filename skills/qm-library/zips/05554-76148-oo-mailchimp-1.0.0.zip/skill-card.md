## Description: <br>
Mailchimp (mailchimp.com). Use this skill for Mailchimp requests that read, create, update, archive, or delete audience and subscriber data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Mailchimp audiences and members through the OOMOL Mailchimp connector, including list discovery, member lookup, subscriber updates, tagging, archiving, and permanent deletion. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can use a connected OOMOL/Mailchimp account to read audience data and change or permanently delete subscriber records. <br>
Mitigation: Run read actions directly, but require explicit user confirmation for state-changing or destructive payloads and review the exact target before approval. <br>
Risk: The skill depends on the OOMOL account connection model and the oo CLI installer. <br>
Mitigation: Install the oo CLI only from OOMOL sources and use the skill only when the user is comfortable granting an agent access through the connected account. <br>
Risk: Connector schemas and upstream Mailchimp fields can change. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-mailchimp) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Mailchimp Homepage](https://mailchimp.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Mailchimp Connection](https://console.oomol.com/app-connections?provider=mailchimp) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands call the OOMOL Mailchimp connector and return JSON responses with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
