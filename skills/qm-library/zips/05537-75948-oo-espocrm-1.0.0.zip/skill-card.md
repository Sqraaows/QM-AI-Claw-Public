## Description: <br>
EspoCRM helps agents read, create, update, and delete EspoCRM data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents and CRM operators use this skill to inspect EspoCRM schemas and operate CRM records, metadata, and current-user data through the configured EspoCRM connector. It supports read workflows as well as confirmed create, update, and delete operations on business records. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access EspoCRM data through connected credentials. <br>
Mitigation: Install only when the OOMOL connector provider is trusted and the connected EspoCRM account has appropriate permissions. <br>
Risk: Create, update, and delete actions can change or remove CRM business records. <br>
Mitigation: Confirm the exact entity, record ID, and payload before allowing write or delete operations. <br>


## Reference(s): <br>
- [ClawHub EspoCRM Skill](https://clawhub.ai/oomol/oo-espocrm) <br>
- [EspoCRM Homepage](https://www.espocrm.com/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration] <br>
**Output Format:** [Markdown guidance with oo CLI command examples and JSON payload expectations] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses from executed connector actions are JSON objects containing data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
