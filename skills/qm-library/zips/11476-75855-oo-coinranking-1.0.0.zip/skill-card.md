## Description: <br>
Coinranking helps agents search and read cryptocurrency market data from Coinranking through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to query Coinranking for coin details, historical price points, global market statistics, reference currencies, coin listings, and search suggestions. It is suited for cryptocurrency research, market discovery, and data retrieval workflows that need structured connector calls. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on an OOMOL-connected Coinranking account and may require sensitive credentials. <br>
Mitigation: Use it only in trusted environments, keep raw credentials out of prompts and files, and rely on the connector's server-side credential handling. <br>
Risk: Connector schemas and upstream fields can change over time. <br>
Mitigation: Inspect the live connector schema before constructing each payload and validate JSON inputs against that schema. <br>
Risk: Cryptocurrency market data is volatile and can be unsuitable as the sole basis for financial decisions. <br>
Mitigation: Treat returned data as informational and verify important decisions against authoritative financial sources. <br>


## Reference(s): <br>
- [Coinranking homepage](https://coinranking.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-coinranking) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
