## Description: <br>
Turns an idle Kindle, phone, tablet, or secondary screen into a Claude Code status monitor by forwarding hook events to a local Python HTTP server and rendering an e-ink-friendly dashboard. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[heavenchenggong](https://clawhub.ai/user/heavenchenggong) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers using Claude Code use this skill to monitor long-running sessions from a browser-capable second screen and notice when Claude Code is thinking, running tools, waiting for confirmation, or finished. It is especially suited to macOS setups that can run a local launchd-backed monitor service. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The monitor exposes hook-derived Claude Code activity over the local network without authentication. <br>
Mitigation: Use only on trusted networks, or modify the service to bind to localhost or require authentication before exposing it to other devices. <br>
Risk: Hook payload logs are stored locally and may include sensitive prompts, paths, commands, or project data. <br>
Mitigation: Review, rotate, or remove the local events log when it may contain sensitive information. <br>
Risk: Changing macOS firewall stealth mode can increase host visibility on the network. <br>
Mitigation: Avoid the stealth-mode workaround unless LAN exposure is understood and acceptable for the deployment environment. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/heavenchenggong/kindle-claude-monitor) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and configuration guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The installed runtime renders a local HTML dashboard and exposes JSON/debug endpoints for monitor state.] <br>

## Skill Version(s): <br>
0.1.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
