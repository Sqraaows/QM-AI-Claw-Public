# Liquipedia API Reference

## Base URL Pattern
```
https://liquipedia.net/{wiki}/api.php
```
Where `{wiki}` is one of: `fighters`, `dota2`, `counterstrike`, `leagueoflegends`, `valorant`, `pubg`, `pubgmobile`, `smash`, `commons`, `starcraft2`, `rocketleague`, `apexlegends`, `wildrift`, `brawlstars`, `mobilelegends`, `pokemon`, `clashroyale`, `hearthstone`, `overwatch`.

## Mandatory Headers
```
Accept-Encoding: gzip
User-Agent: LiquipediaSkill/1.1 (hermes-agent)
```
**Gzip is mandatory** — Liquipedia's Varnish cache returns HTTP 406 without it.

## Key Endpoints

### 1. OpenSearch (multi-wiki search)
```
GET /{wiki}/api.php?action=opensearch&search={query}&limit={N}
```
Returns: `[query, [titles], [descriptions], [urls]]`
- Fast, lightweight. Good for finding page URLs.
- Supports parallel search across all wikis (~2s for 19 wikis with 8-thread pool).

### 2. Parse (page content)
```
GET /{wiki}/api.php?action=parse&page={title}&prop=wikitext|text|sections&format=json
```
- `wikitext` — raw wiki markup (good for Infobox, templates)
- `text` — rendered HTML (good for tables, results)
- `sections` — table of contents

### 3. Query (metadata)
```
GET /{wiki}/api.php?action=query&titles={title}&prop=info|revisions&rvprop=content&format=json
```

## Results Page Gotcha

Player/team `/Results` pages render tables via `{{#cargo}}` — the data **only appears in the HTML `text` field**, NOT in `wikitext`.

To extract game-specific results from a player page:
1. Request with `prop=wikitext|text|sections`
2. Find the game section anchor in HTML: `id="Street_Fighter_6"`
3. Find the next `<table` after that anchor
4. Extract rows (sorted newest-first by date)

The `wikitext` field for results pages only contains: `{{Results overview |game=sf6|type=recent}}` — a template call that renders server-side.

## Infobox Parsing
Tournament Infobox data is in `wikitext` as key-value pairs:
```
{{Infobox league
|name=DreamHack Birmingham 2026
|prizepoolusd=50,000
|sdate=2026-03-28
|edate=2026-03-29
...
}}
```
Parse with regex: `\|(\w+)=([^\n]+)`

## API Terms of Use
- Gzip required (406 without it)
- No authentication needed
- Rate limit: ~600 req/min (generous, be polite)
- Data is community-maintained, may lag behind live events
