#!/usr/bin/env python3
"""Liquipedia API client — search and fetch pages from the esports wiki.

Usage:
    python liquipedia_api.py search "DreamHack" [--wiki fighters] [--limit 5]
    python liquipedia_api.py get "https://liquipedia.net/fighters/Xiao_Hai"
    python liquipedia_api.py get "DreamHack/2026/Birmingham/SF6" --wiki fighters
"""

import argparse
import gzip
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote, unquote, urlparse
from urllib.request import Request, urlopen

# Supported Liquipedia wikis (game-specific subdomains)
WIKIS = [
    "fighters",       # Fighting games (SF, Tekken, KOF, Guilty Gear, etc.)
    "dota2",          # Dota 2
    "counterstrike",  # CS2 / CS:GO
    "leagueoflegends",# League of Legends
    "valorant",       # Valorant
    "pubg",           # PUBG
    "pubgmobile",     # PUBG Mobile
    "smash",          # Super Smash Bros.
    "commons",        # Shared media
    "starcraft2",     # StarCraft II
    "rocketleague",   # Rocket League
    "apexlegends",    # Apex Legends
    "wildrift",       # Wild Rift
    "brawlstars",     # Brawl Stars
    "mobilelegends",  # Mobile Legends: Bang Bang
    "pokemon",        # Pokémon (VGC, TCG, Unite)
    "clashroyale",    # Clash Royale
    "hearthstone",    # Hearthstone
    "overwatch",      # Overwatch
]

BASE_URL = "https://liquipedia.net"
USER_AGENT = "LiquipediaSkill/1.1 (hermes-agent)"
TIMEOUT = 15  # seconds


def _api_request(url: str) -> str:
    """Send GET request with gzip support. Returns response body as string."""
    req = Request(url)
    req.add_header("Accept-Encoding", "gzip")
    req.add_header("User-Agent", USER_AGENT)
    try:
        with urlopen(req, timeout=TIMEOUT) as resp:
            data = resp.read()
            if resp.headers.get("Content-Encoding") == "gzip":
                data = gzip.decompress(data)
            return data.decode("utf-8")
    except Exception as e:
        return json.dumps({"error": f"{type(e).__name__}: {e}"}, ensure_ascii=False)


def _search_one_wiki(wiki: str, query: str, limit: int) -> dict | None:
    """Search a single wiki. Returns result dict or None if no matches."""
    url = f"{BASE_URL}/{wiki}/api.php?action=opensearch&search={quote(query)}&limit={limit}"
    raw = _api_request(url)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return None
    # opensearch format: [query, [titles], [descriptions], [urls]]
    if isinstance(data, list) and len(data) > 1 and data[1]:
        return {
            "titles": data[1],
            "urls": data[3] if len(data) > 3 else [],
            "wiki": wiki,
        }
    return None


def search(query: str, wiki: str | None = None, limit: int = 5) -> str:
    """Search Liquipedia. If wiki is specified, only search that wiki."""
    target_wikis = [wiki] if wiki else WIKIS

    if wiki and wiki not in WIKIS:
        return json.dumps(
            {"error": f"Unknown wiki '{wiki}'. Available: {', '.join(WIKIS)}"},
            ensure_ascii=False,
        )

    results = {}

    # Parallel search across wikis
    with ThreadPoolExecutor(max_workers=min(8, len(target_wikis))) as executor:
        futures = {
            executor.submit(_search_one_wiki, w, query, limit): w
            for w in target_wikis
        }
        for future in as_completed(futures):
            result = future.result()
            if result:
                results[result["wiki"]] = {
                    "titles": result["titles"],
                    "urls": result["urls"],
                }

    if not results:
        return json.dumps({"message": "No results found."}, ensure_ascii=False)

    return json.dumps(
        {"query": query, "results": results, "wikis_searched": len(target_wikis)},
        indent=2,
        ensure_ascii=False,
    )


def _parse_url(url: str) -> tuple[str, str] | None:
    """Parse a Liquipedia URL into (wiki, title). Returns None if not a valid URL."""
    try:
        parsed = urlparse(url)
        if parsed.netloc and "liquipedia.net" in parsed.netloc:
            parts = parsed.path.strip("/").split("/")
            if len(parts) >= 2:
                wiki = parts[0]
                title = unquote("/".join(parts[1:]))
                return wiki, title
    except Exception:
        pass
    return None


def get_page(target: str, wiki: str | None = None) -> str:
    """Fetch page content. Accepts URL or page title."""
    # Try to parse as URL first
    parsed = _parse_url(target)
    if parsed:
        wiki, target = parsed

    if not wiki:
        return json.dumps(
            {"error": "Wiki not specified and target is not a valid Liquipedia URL. Use --wiki <name>."},
            ensure_ascii=False,
        )

    url = (
        f"{BASE_URL}/{wiki}/api.php?"
        f"action=parse&"
        f"page={quote(target)}&"
        f"prop=wikitext|text|sections&"
        f"format=json"
    )
    return _api_request(url)


def main():
    parser = argparse.ArgumentParser(
        description="Query Liquipedia esports wiki via MediaWiki API."
    )
    sub = parser.add_subparsers(dest="action", required=True)

    # search subcommand
    sp_search = sub.add_parser("search", help="Search across wikis")
    sp_search.add_argument("query", help="Search term")
    sp_search.add_argument("--wiki", default=None, help="Search only this wiki")
    sp_search.add_argument("--limit", type=int, default=5, help="Results per wiki (default: 5)")

    # get subcommand
    sp_get = sub.add_parser("get", help="Fetch page content by URL or title")
    sp_get.add_argument("target", help="Page URL or title")
    sp_get.add_argument("--wiki", default=None, help="Wiki name (optional if target is a full URL)")

    args = parser.parse_args()

    t0 = time.monotonic()
    if args.action == "search":
        print(search(args.query, wiki=args.wiki, limit=args.limit))
    elif args.action == "get":
        print(get_page(args.target, wiki=args.wiki))
    elapsed = time.monotonic() - t0
    print(f"\n# Completed in {elapsed:.2f}s", file=sys.stderr)


if __name__ == "__main__":
    main()
