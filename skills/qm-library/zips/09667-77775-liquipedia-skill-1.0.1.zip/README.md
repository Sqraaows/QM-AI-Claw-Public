# Liquipedia Skill

https://gitee.com/gabzzz/liquipedia-skill

## 简介

**查询 Liquipedia（电竞百科）信息的 Skill。** 通过 MediaWiki API 获取赛事、战队、选手等页面内容，并返回结构化 JSON 供下游解析与总结。

- 支持两种动作：`search`（搜索）与 `get`（获取页面）
- `search` 支持跨多个 Wiki 并发搜索；也可指定单一 `wiki` 以获得更快响应
- `get` 支持传入完整 URL 自动识别 `wiki`，或使用 “`wiki` + `title`” 获取页面
- 同时返回 wikitext 与渲染 HTML，便于解析 Infobox / 表格 / 战绩页
- 内置 `Accept-Encoding: gzip` 请求头，避免 Liquipedia API 406

## SKILL.md

Skill 的行为说明与提示词入口位于：`liquipedia-skill/SKILL.md`

## 脚本目录

所有脚本都位于 `liquipedia-skill/scripts/`，主入口为：`liquipedia-skill/scripts/liquipedia_api.py`

## 使用方法

你可以直接用自然语言提问，例如：

- “Ti12 冠军是谁？决赛比分是多少？”
- “DreamHack 2026 Birmingham（SF6）什么时候开始？在哪里办？奖金池多少？”
- “T1 目前阵容有哪些人？最近一次人员变动是什么？”
- “Faker 的主要荣誉/冠军有哪些？”
- “XiaoHai ，最近一年 SF6 的战绩如何？”
- “帮我找一下某个赛事/选手/战队的 Liquipedia 页面链接”

如果你知道具体游戏/分区，也可以在问题里说明（例如 LoL / Dota2 / CS / Valorant 等），以便更快定位到对应 Wiki。

## 返回内容

- 返回结果来自 Liquipedia 页面，并附带对应页面链接
- 必要时会从 Infobox/表格/战绩页中抽取关键字段进行结构化整理

## 支持的 Wiki

支持的 wiki 标识与脚本内置列表保持一致：

| 参数 | 内容 | 参数 | 内容 |
|------|------|------|------|
| `fighters` | 格斗游戏 | `dota2` | Dota 2 |
| `counterstrike` | CS2 / CS:GO | `leagueoflegends` | 英雄联盟 |
| `valorant` | 无畏契约 | `pubg` | 绝地求生 |
| `pubgmobile` | PUBG Mobile | `smash` | 任天堂大乱斗 |
| `starcraft2` | 星际争霸2 | `apexlegends` | Apex 英雄 |
| `overwatch` | 守望先锋 | `hearthstone` | 炉石传说 |
| `pokemon` | Pokémon | `mobilelegends` | Mobile Legends |
| `wildrift` | 英雄联盟手游 | `brawlstars` | 荒野乱斗 |
| `clashroyale` | 皇室战争 | `rocketleague` | 火箭联盟 |

### API 使用条款

请遵守 [Liquipedia API Terms of Use](https://liquipedia.net/api-terms-of-use) 的使用条款。

## 许可证

本项目仅供学习和研究使用，请遵守 Liquipedia 的使用条款。
