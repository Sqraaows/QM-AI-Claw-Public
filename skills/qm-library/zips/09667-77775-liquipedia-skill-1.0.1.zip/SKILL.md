---
name: liquipedia
description: Query Liquipedia (the esports wiki) for tournaments, players, teams, and game info using their MediaWiki API.
version: 1.1.0
---

# Liquipedia Skill

查询 Liquipedia 电竞百科信息。支持搜索赛事、战队、选手及游戏维基页面。

## 什么时候用

- 用户询问特定电竞比赛结果（如 "Ti12 冠军", "Major 赛果"）
- 查询战队阵容、选手历史数据
- 了解特定游戏的电竞赛事日历

## 使用方法

脚本路径: `scripts/liquipedia_api.py`

### 1. 搜索 (Search)

在所有支持的游戏中搜索关键词（并发请求，~2 秒内完成）。

```bash
# 全局搜索
python scripts/liquipedia_api.py search "DreamHack"

# 指定游戏搜索（更快）
python scripts/liquipedia_api.py search "Faker" --wiki leagueoflegends

# 调整返回数量
python scripts/liquipedia_api.py search "T1" --limit 10
```

**返回结果**: JSON 对象，`results` 字段包含各 Wiki 中的匹配条目。

### 2. 获取页面详情 (Get Page)

根据 URL 或标题获取页面内容。

```bash
# 使用 URL (推荐，自动识别 Wiki)
python scripts/liquipedia_api.py get "https://liquipedia.net/fighters/DreamHack/2026/Birmingham/SF6"

# 使用 Wiki 和标题
python scripts/liquipedia_api.py get "DreamHack/2026/Birmingham/SF6" --wiki fighters
```

**返回结果**: 包含 `parse` 对象的 JSON。
- `wikitext` 字段：原始维基代码（适合解析 Infobox）
- `text` 字段：渲染后的 HTML（适合解析表格、选手战绩页）

## 支持的 Wiki

| 参数 | 内容 | 参数 | 内容 |
|------|------|------|------|
| `fighters` | 格斗游戏 (SF, KOF, 铁拳) | `dota2` | Dota 2 |
| `counterstrike` | CS2 / CS:GO | `leagueoflegends` | 英雄联盟 |
| `valorant` | 无畏契约 | `pubg` | 绝地求生 |
| `pubgmobile` | PUBG Mobile | `smash` | 任天堂大乱斗 |
| `starcraft2` | 星际争霸2 | `apexlegends` | Apex 英雄 |
| `overwatch` | 守望先锋 | `hearthstone` | 炉石传说 |
| `pokemon` | Pokémon | `mobilelegends` | Mobile Legends |
| `wildrift` | 英雄联盟手游 | `brawlstars` | 荒野乱斗 |
| `clashroyale` | 皇室战争 | `rocketleague` | 火箭联盟 |

## 输出处理

**不要直接输出原始 Wikitext 给用户。**
1. 解析 `Infobox` 中的关键信息：时间、地点、奖金、主办方。
2. 查找 `{{Infobox match}}` 或表格来提取比赛结果、比分。
3. 将提取的信息整理成中文简报。

## ⚠️ Pitfalls

### 选手战绩页面 (Results Pages)
选手的 `/Results` 页面返回的是**超大 HTML**（包含所有游戏的完整战绩表，可达 400KB+）。
- **不要解析 wikitext**：`{{Results overview}}` 模板在服务端渲染成 HTML，wikitext 字段只包含一个模板调用占位符。
- **必须解析 `text` 字段（HTML）**：使用 `prop=wikitext|text|sections` 同时请求两者。
- **按游戏分段提取**：页面通过 `<div class="tabs-dynamic">` 按游戏分 tab（如 Street Fighter 6, KOF XV 等）。
  先用 `html.find('id="Street_Fighter_6"')` 定位标题锚点，再往后找 `<table` 提取该游戏的战绩表。
- **只取最近条目**：HTML 表格按时间倒序排列，只提取 `2026` 年份下的前几行即可，避免解析整个历史。

### API 必须带 Gzip
Liquipedia 的 API 端点强制要求 `Accept-Encoding: gzip` 头，否则返回 406 错误。脚本已内置此头。

### URL 自动识别
`get` 操作可以直接传完整的 Liquipedia URL（如 `https://liquipedia.net/fighters/Xiao_Hai/Results`），脚本会自动从中提取 wiki 名（`fighters`）和页面标题。

### API 速查
详见 `references/liquipedia-api-notes.md`：各端点格式、性能数据、Terms of Use、Results 页面 HTML 解析技巧。

### 并发搜索
`search` 命令默认并发请求所有 19 个 Wiki（最多 8 线程并发），~2 秒内返回结果。如果用户明确指定了 `--wiki`，则只请求单个 Wiki，~0.5 秒返回。
