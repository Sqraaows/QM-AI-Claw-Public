## Description: <br>
Healthchecks.io lets an agent read, create, update, pause, resume, and delete Healthchecks.io checks through the OOMOL `healthchecks_io` connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Healthchecks.io project checks and inspect observability data such as pings, flips, badges, and notification channels from an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, pause, resume, or delete Healthchecks.io checks, including destructive delete actions. <br>
Mitigation: Confirm the exact target, payload, and intended effect with the user before write actions, and require explicit approval before deletion. <br>
Risk: The skill requires sensitive connected-account credentials through OOMOL and a trusted `oo` CLI setup. <br>
Mitigation: Install only if the publisher is trusted, run setup commands only from trusted sources, and review connector permissions before operating on the account. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-healthchecks-io) <br>
- [Healthchecks.io Homepage](https://healthchecks.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Agent responses should fetch the live connector schema before constructing action payloads and should return connector results as text or JSON summaries.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
