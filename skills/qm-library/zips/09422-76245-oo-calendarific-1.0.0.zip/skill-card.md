## Description: <br>
Calendarific helps agents retrieve holiday data, supported countries, and supported languages through OOMOL's Calendarific connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Calendarific action schemas, list supported countries or languages, and request holiday data for a specified country and year. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The security scan verdict is suspicious because the release evidence reports maintainer-oriented skill content with a nested full-access autoreview helper in the scanned bundle. <br>
Mitigation: Review the installed artifact and security scan before deployment, and avoid running unrelated maintainer helpers from the same bundle. <br>
Risk: The skill requires sensitive credentials through the OOMOL Calendarific connection. <br>
Mitigation: Use an account with appropriate Calendarific access, keep credentials managed through OOMOL, and reconnect only when an auth or connection error requires it. <br>


## Reference(s): <br>
- [Calendarific homepage](https://calendarific.com/) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-calendarific) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with CLI commands and JSON payload examples.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill directs agents to inspect live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
