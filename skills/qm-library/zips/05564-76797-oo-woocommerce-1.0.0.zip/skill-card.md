## Description: <br>
WooCommerce (woocommerce.com). Use this skill for WooCommerce requests that read, create, or update store data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and commerce teams use this skill to run WooCommerce read and write workflows through the oo CLI, including products, orders, customers, coupons, taxonomy data, variations, order notes, and media uploads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The first-time setup instructions include remote installer one-liners that pipe downloaded scripts into a shell. <br>
Mitigation: Install the oo CLI through a verified official method before letting an agent use this skill, and do not allow the agent to run installer one-liners automatically. <br>
Risk: Several actions can create or update WooCommerce records, including products, orders, coupons, order status, notes, variations, and media. <br>
Mitigation: Confirm the exact payload and intended effect with the user before any state-changing action, and use a least-privilege WooCommerce connection. <br>
Risk: Connector schemas and upstream fields can change over time. <br>
Mitigation: Run `oo connector schema` for the selected action before constructing payloads, as the artifact instructs. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-woocommerce) <br>
- [WooCommerce homepage](https://woocommerce.com) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads for oo CLI connector actions.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches live connector schemas before execution and returns WooCommerce connector responses as JSON when actions run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
