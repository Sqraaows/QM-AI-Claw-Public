## Description: <br>
Templated lets an agent operate a connected Templated account through OOMOL to inspect templates and account data, create renders, list renders, fetch render details, and delete renders. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill when they want an agent to work with Templated templates and renders through an OOMOL-connected account. It supports template lookup, render creation, render retrieval, render listing, account lookup, and confirmed render deletion. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create renders in a connected Templated account. <br>
Mitigation: Review the exact create request and intended output before approving the action. <br>
Risk: The skill can delete existing Templated renders after explicit confirmation. <br>
Mitigation: Confirm the target render ID and deletion intent before running the delete action. <br>
Risk: First-time setup may require installing the OOMOL CLI. <br>
Mitigation: Verify the installer source before running the setup command. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-templated) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Templated homepage](https://templated.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
