## Description: <br>
Dovetail helps agents read, create, update, export, and list Dovetail workspace data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Dovetail through the OOMOL oo CLI, including browsing projects, listing and retrieving data records, exporting records, and creating or updating records after confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update Dovetail records when run with connected account credentials. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create_data or update_data. <br>
Risk: First-time setup may involve running a shell or PowerShell installer for the oo CLI. <br>
Mitigation: Review the OOMOL CLI installation source and use only trusted installation instructions before executing installer commands. <br>
Risk: The skill requires a connected Dovetail account and sensitive credential handling through OOMOL. <br>
Mitigation: Install only when the user trusts OOMOL and is comfortable connecting the Dovetail account; inspect token metadata without exposing raw credentials. <br>


## Reference(s): <br>
- [Dovetail homepage](https://dovetail.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-dovetail) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Markdown, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May export Dovetail records as HTML or Markdown depending on the selected action.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
