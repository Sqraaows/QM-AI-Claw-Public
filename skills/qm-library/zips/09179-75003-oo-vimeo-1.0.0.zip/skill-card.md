## Description: <br>
Vimeo (vimeo.com). Use this skill for Vimeo requests that read, create, update, or delete data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Vimeo through an OOMOL-connected account. It supports reading video and account data, managing folders, showcases, and tags, and running upload, replacement, download, update, and delete workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can perform state-changing and destructive Vimeo operations through a connected account. <br>
Mitigation: Review each payload before execution and require explicit user approval before create, update, upload, replace, remove, or delete actions. <br>
Risk: The skill sends requests through an OOMOL-connected account. <br>
Mitigation: Connect only the intended account and inspect the live action schema before constructing command payloads. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-vimeo) <br>
- [Vimeo Homepage](https://vimeo.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Vimeo Connection](https://console.oomol.com/app-connections?provider=vimeo) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance, Configuration instructions, Files] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId; download actions may create connector transit-storage files.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
