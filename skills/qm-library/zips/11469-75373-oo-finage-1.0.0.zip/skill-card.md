## Description: <br>
Finage helps agents use OOMOL-connected actions to retrieve U.S. stock market data from Finage without calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers with an OOMOL-connected Finage account use this skill to retrieve latest quotes, latest trades, previous close bars, OHLCV aggregates, snapshots, and searchable U.S. stock symbols. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses OOMOL as the intermediary for the user's Finage account and API-key connection. <br>
Mitigation: Install only if that credential flow is acceptable for the environment and account involved. <br>
Risk: Finage operations outside the documented market-data actions could create, update, send, post, delete, or remove data. <br>
Mitigation: Require explicit user confirmation before allowing any such operation outside the documented action list. <br>
Risk: Connector schemas and defaults can change upstream, which can make a stale payload incorrect. <br>
Mitigation: Fetch the live action schema with the oo CLI before constructing each request payload. <br>


## Reference(s): <br>
- [Finage homepage](https://finage.co.uk) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_aggregates action](actions/get_aggregates.md) <br>
- [get_last_quote action](actions/get_last_quote.md) <br>
- [get_last_trade action](actions/get_last_trade.md) <br>
- [get_previous_close action](actions/get_previous_close.md) <br>
- [get_snapshot action](actions/get_snapshot.md) <br>
- [list_stock_symbols action](actions/list_stock_symbols.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an OOMOL sign-in, and a connected Finage account; action schemas are fetched before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
