## Description: <br>
Browserless (browserless.io). Use this skill for Browserless requests that search, read, render, capture screenshots, or generate PDFs through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Browserless through the OOMOL oo CLI, including fetching rendered HTML, generating screenshots, and generating PDFs. It is intended for users who have connected Browserless in OOMOL and want schema-checked connector commands instead of direct Browserless API calls. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a Browserless connection through OOMOL, so misuse or an untrusted setup path could expose account access or consume connected service resources. <br>
Mitigation: Confirm the user intends to use OOMOL with Browserless, rely on the server-injected credential flow, and do not request or handle raw Browserless tokens. <br>
Risk: Installer, login, and connection setup commands can alter the user's local environment or account state. <br>
Mitigation: Run setup only after an oo CLI, authentication, or connection failure indicates it is needed. <br>
Risk: Live connector schemas can change, which may make stale payloads invalid or misleading. <br>
Mitigation: Fetch the authoritative action schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [Browserless Skill Page](https://clawhub.ai/oomol/oo-browserless) <br>
- [Browserless Homepage](https://www.browserless.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [fetch_content action](actions/fetch_content.md) <br>
- [generate_pdf action](actions/generate_pdf.md) <br>
- [take_screenshot action](actions/take_screenshot.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses return JSON with data and meta.executionId; PDF and screenshot actions return base64 content.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
