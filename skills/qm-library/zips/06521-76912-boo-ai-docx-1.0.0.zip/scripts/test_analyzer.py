# -*- coding: utf-8 -*-
#
# =============================================
#  Boo哥AI智写 . Docx Forensic Analyzer - Test Suite
#  Copyright (c) 2024-2026 Boo哥AI智写
#  Licensed under MIT License
# =============================================

import unittest
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from analyze_docx import DOCXForensicAnalyzer, _BRAND_NAME, _VERSION


class TestDOCXForensicAnalyzer(unittest.TestCase):
    """Boo哥AI智写 - 测试 DOCX 分析器"""

    def setUp(self):
        self.test_docx = "test_sample.docx"

    def test_brand_constants(self):
        self.assertEqual(_BRAND_NAME, "Boo哥AI智写")
        self.assertEqual(_VERSION, "1.0.0")

    def test_analyzer_initialization(self):
        analyzer = DOCXForensicAnalyzer(self.test_docx)
        self.assertEqual(analyzer.docx_path, Path(self.test_docx))

    def test_file_not_found_handling(self):
        with self.assertRaises(FileNotFoundError):
            DOCXForensicAnalyzer("nonexistent_file.docx")

    def test_invalid_file_type(self):
        with self.assertRaises(ValueError):
            DOCXForensicAnalyzer("test.txt")

    def test_size_formatting(self):
        analyzer = DOCXForensicAnalyzer(self.test_docx)

        self.assertEqual(analyzer._format_size(500), "500.00 B")
        self.assertEqual(analyzer._format_size(1024), "1.00 KB")
        self.assertEqual(analyzer._format_size(1048576), "1.00 MB")
        self.assertEqual(analyzer._format_size(1073741824), "1.00 GB")

    def test_config_defaults(self):
        analyzer = DOCXForensicAnalyzer(self.test_docx)
        self.assertEqual(analyzer.config['top_n'], 50)
        self.assertEqual(analyzer.config['enable_readability'], False)
        self.assertEqual(analyzer.config['sensitive_keywords'], [])

    def test_custom_config(self):
        config = {
            'top_n': 20,
            'enable_readability': True,
            'sensitive_keywords': ['test']
        }
        analyzer = DOCXForensicAnalyzer(self.test_docx, config)
        self.assertEqual(analyzer.config['top_n'], 20)
        self.assertTrue(analyzer.config['enable_readability'])


class TestDOCXForensicAnalyzerIntegration(unittest.TestCase):
    """Boo哥AI智写 - 集成测试 (需要实际的 docx 文件)"""

    @classmethod
    def setUpClass(cls):
        cls.test_file = "sample_report.docx"
        cls.file_exists = Path(cls.test_file).exists()

    @unittest.skipUnless(Path("sample_report.docx").exists(),
                         "需要 sample_report.docx 文件进行集成测试")
    def test_full_analysis(self):
        analyzer = DOCXForensicAnalyzer(self.test_file)
        json_data, report = analyzer.analyze()

        self.assertIsInstance(json_data, dict)
        self.assertIsInstance(report, str)
        self.assertIn("Boo哥AI智写", report)
        self.assertIn("Forensic Report", report)
        self.assertIn(_BRAND_NAME, json_data['brand']['name'])

    @unittest.skipUnless(Path("sample_report.docx").exists(),
                         "需要 sample_report.docx 文件进行集成测试")
    def test_json_brand_field(self):
        analyzer = DOCXForensicAnalyzer(self.test_file)
        json_data, _ = analyzer.analyze()
        self.assertIn('brand', json_data)
        self.assertEqual(json_data['brand']['name'], _BRAND_NAME)
        self.assertEqual(json_data['brand']['version'], _VERSION)


if __name__ == '__main__':
    print(f"{_BRAND_NAME} . Docx Forensic Analyzer Test Suite v{_VERSION}")
    print()
    unittest.main()
