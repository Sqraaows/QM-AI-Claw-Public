#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# =============================================
#  Boo哥AI智写 . Docx Forensic Analyzer v1.0.0
#  Copyright (c) 2024-2026 Boo哥AI智写
#  Licensed under MIT License
# =============================================

import zipfile
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path
import re
import tempfile
import shutil
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
import os
import sys
import json

_BRAND_NAME = "Boo哥AI智写"
_BRAND_URL = "https://github.com/Boo哥AI智写/docx-file-analyzer"
_BRAND_TAGLINE = "让技术如呼吸般自然"
_VERSION = "1.0.0"

_BRAND_FOOTER = f"""
---
> 本报告由 **{_BRAND_NAME} . Docx Forensic Analyzer v{_VERSION}** 自动生成
> {_BRAND_TAGLINE} | {_BRAND_URL}"""


class DOCXForensicAnalyzer:
    """Boo哥AI智写 . DOCX 文件全面取证分析器"""

    def __init__(self, docx_path: str, config: Optional[Dict] = None):
        self.docx_path = Path(docx_path)
        self.temp_dir = None
        self.config = config or {
            'top_n': 50,
            'enable_readability': False,
            'sensitive_keywords': []
        }
        
        # OOXML 命名空间
        self.namespaces = {
            'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
            'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
            'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
            'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
            'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math',
            'cp': 'http://schemas.openxmlformats.org/package/2006/metadata/core-properties',
            'dc': 'http://purl.org/dc/elements/1.1/',
            'dcterms': 'http://purl.org/dc/terms/',
            'dcmitype': 'http://purl.org/dc/dcmitype/',
            'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            'vt': 'http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes'
        }
        
        self.results = {}
        self.warnings = []
        self._cleanup_callback = None

    def analyze(self) -> Tuple[Dict, str]:
        """执行完整分析，返回 (json_data, markdown_report)"""
        if not self.docx_path.exists():
            raise FileNotFoundError(f"文件不存在: {self.docx_path}")

        if not self.docx_path.suffix.lower() == '.docx':
            raise ValueError("文件必须是 .docx 格式")

        # 创建临时目录
        self.temp_dir = tempfile.mkdtemp(prefix='docx_forensic_')
        
        def cleanup():
            if self.temp_dir and Path(self.temp_dir).exists():
                try:
                    shutil.rmtree(self.temp_dir)
                except Exception as e:
                    print(f"警告: 清理临时文件时出错: {e}")
        
        self._cleanup_callback = cleanup

        try:
            # 解压文件
            with zipfile.ZipFile(self.docx_path, 'r') as zf:
                # 验证是否为有效的docx
                if '[Content_Types].xml' not in zf.namelist():
                    raise ValueError("无效的 .docx 文件: 缺少 [Content_Types].xml")
                zf.extractall(self.temp_dir)

            self.warnings = []
            self.results = self._analyze_all()
            
            json_data = self._generate_json_report()
            markdown_report = self._generate_markdown_report()
            
            return json_data, markdown_report

        finally:
            if self._cleanup_callback:
                self._cleanup_callback()

    def _analyze_all(self) -> Dict:
        """执行所有分析模块"""
        return {
            'file_info': self._get_file_info(),
            'metadata': self._analyze_metadata(),
            'fonts': self._analyze_fonts(),
            'paragraphs': self._analyze_paragraphs(),
            'character_formatting': self._analyze_character_formatting(),
            'styles': self._analyze_styles(),
            'tables': self._analyze_tables(),
            'media': self._analyze_media(),
            'word_frequency': self._analyze_word_frequency(),
            'structure': self._analyze_structure(),
            'page_layout': self._analyze_page_layout(),
            'advanced_objects': self._analyze_advanced_objects(),
            'health_checks': self._analyze_health_checks()
        }

    def _get_file_info(self) -> Dict:
        """获取文件基本信息"""
        stat = self.docx_path.stat()
        return {
            'path': str(self.docx_path.absolute()),
            'name': self.docx_path.name,
            'size_bytes': stat.st_size,
            'size_formatted': self._format_size(stat.st_size),
            'modified_time': datetime.fromtimestamp(stat.st_mtime).isoformat(),
            'analysis_time': datetime.now().isoformat()
        }

    def _format_size(self, size_bytes: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} TB"

    def _load_xml(self, xml_path: str) -> Optional[ET.Element]:
        """加载 XML 文件"""
        full_path = Path(self.temp_dir) / xml_path
        if not full_path.exists():
            return None
        try:
            tree = ET.parse(full_path)
            return tree.getroot()
        except Exception as e:
            self.warnings.append(f"解析 {xml_path} 时出错: {e}")
            return None

    def _get_text_from_element(self, element: ET.Element, include_tail: bool = True) -> str:
        """递归提取元素中的所有文本"""
        texts = []
        if element.text:
            texts.append(element.text)
        for child in element:
            texts.append(self._get_text_from_element(child, include_tail))
            if include_tail and child.tail:
                texts.append(child.tail)
        return ''.join(texts)

    def _analyze_metadata(self) -> Dict:
        """分析文档元数据"""
        result = {
            'core': {},
            'app': {}
        }
        
        # 分析 core.xml
        core_xml = self._load_xml('docProps/core.xml')
        if core_xml is not None:
            cp = '{http://schemas.openxmlformats.org/package/2006/metadata/core-properties'
            dc = '{http://purl.org/dc/elements/1.1/'
            dcterms = '{http://purl.org/dc/terms/'
            
            title = core_xml.find(f'{dc}title')
            if title is not None:
                result['core']['title'] = title.text
            
            subject = core_xml.find(f'{dc}subject')
            if subject is not None:
                result['core']['subject'] = subject.text
            
            creator = core_xml.find(f'{dc}creator')
            if creator is not None:
                result['core']['author'] = creator.text
            
            created = core_xml.find(f'{dcterms}created')
            if created is not None:
                result['core']['created'] = created.text
            
            modified = core_xml.find(f'{dcterms}modified')
            if modified is not None:
                result['core']['modified'] = modified.text

        # 分析 app.xml
        app_xml = self._load_xml('docProps/app.xml')
        if app_xml is not None:
            vt = '{http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes'
            
            for child in app_xml:
                tag = child.tag.split('}')[-1] if '}' in child.tag else child.tag
                if tag in ['Pages', 'Words', 'Characters', 'Paragraphs', 'Lines', 'Template',
                           'Company', 'AppVersion']:
                    result['app'][tag.lower()] = child.text
        
        return result

    def _analyze_fonts(self) -> Dict:
        """分析字体使用情况"""
        result = {
            'font_table': {},
            'font_occurrences': Counter(),
            'embedded_fonts': [],
            'theme_fonts': {},
            'symbol_fonts': []
        }
        
        # 分析 fontTable.xml
        font_table_xml = self._load_xml('word/fontTable.xml')
        if font_table_xml is not None:
            w = self.namespaces['w']
            for font in font_table_xml.findall(f'{w}font'):
                name = font.get(f'{w}name')
                if name:
                    result['font_table'][name] = {
                    'charset': font.get(f'{w}charset'),
                    'family': font.get(f'{w}family')
                }
        
        # 分析 document.xml 中的字体使用
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is not None:
            w = self.namespaces['w']
            for rPr in doc_xml.findall(f'.//{w}rPr'):
                rFonts = rPr.find(f'{w}rFonts')
                if rFonts is not None:
                    for key = rFonts.get(f'{w}ascii')
                    if key:
                        result['font_occurrences'][key] += 1
                    key_eastAsia = rFonts.get(f'{w}eastAsia')
                    if key_eastAsia:
                        result['font_occurrences'][key_eastAsia] += 1
                    key_hAnsi = rFonts.get(f'{w}hAnsi')
                    if key_hAnsi:
                        result['font_occurrences'][key_hAnsi] += 1
        
        # 检测嵌入字体
        fonts_dir = Path(self.temp_dir) / 'word' / 'fonts'
        if fonts_dir.exists():
            for font_file in fonts_dir.iterdir():
                if font_file.is_file():
                    result['embedded_fonts'].append(font_file.name)
        
        # 检测符号字体
        symbol_font_names = ['Wingdings', 'Symbol', 'Webdings', 'Marlett']
        for font_name in result['font_occurrences'].keys():
            if any(symbol_name in font_name for symbol_name in symbol_font_names):
                result['symbol_fonts'].append(font_name)
        
        return result

    def _analyze_paragraphs(self) -> Dict:
        """分析段落和格式"""
        result = {
            'total_paragraphs': 0,
            'empty_paragraphs': 0,
            'paragraph_styles': Counter(),
            'alignments': Counter(),
            'outline_levels': Counter(),
            'indents': Counter(),
            'line_spacing': Counter(),
            'manual_breaks': 0,
            'section_breaks': 0,
            'page_breaks': 0
        }
        
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is None:
            return result
        
        w = self.namespaces['w']
        paragraphs = doc_xml.findall(f'.//{w}p')
        result['total_paragraphs'] = len(paragraphs)
        
        for idx = 0
        for p in paragraphs:
            idx += 1
            text = self._get_text_from_element(p).strip()
            if not text:
                result['empty_paragraphs'] += 1
            
            # 段落样式
            pPr = p.find(f'{w}pPr')
            if pPr is not None:
                pStyle = pPr.find(f'{w}pStyle')
                if pStyle is not None:
                    style_id = pStyle.get(f'{w}val')
                    if style_id:
                        result['paragraph_styles'][style_id] += 1
                
                # 对齐方式
                jc = pPr.find(f'{w}jc')
                if jc is not None:
                    align = jc.get(f'{w}val') or 'left'
                    result['alignments'][align] += 1
                
                # 大纲级别
                outlineLvl = pPr.find(f'{w}outlineLvl')
                if outlineLvl is not None:
                    lvl = outlineLvl.get(f'{w}val') or '0'
                    result['outline_levels'][lvl] += 1
            
            # 检测分页符和分节符
            for br in p.findall(f'.//{w}br'):
                br_type = br.get(f'{w}type')
                if br_type == 'page':
                    result['page_breaks'] += 1
                else:
                    result['manual_breaks'] += 1
        
        # 检测分节符（在最后一段的pPr或sectPr中）
        sects = doc_xml.findall(f'.//{w}sectPr')
        result['section_breaks'] = len(sects)
        
        return result

    def _analyze_character_formatting(self) -> Dict:
        """分析字符级格式"""
        result = {
            'bold': 0,
            'italic': 0,
            'underline': Counter(),
            'strike': 0,
            'text_colors': Counter(),
            'highlights': Counter(),
            'superscript': 0,
            'subscript': 0,
            'text_effects': Counter(),
            'vanish': 0
        }
        
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is None:
            return result
        
        w = self.namespaces['w']
        
        for rPr in doc_xml.findall(f'.//{w}rPr'):
            if rPr.find(f'{w}b') is not None:
                result['bold'] += 1
            if rPr.find(f'{w}i') is not None:
                result['italic'] += 1
            
            u = rPr.find(f'{w}u')
            if u is not None:
                u_type = u.get(f'{w}val') or 'single'
                result['underline'][u_type] += 1
            
            if rPr.find(f'{w}strike') is not None:
                result['strike'] += 1
            
            color = rPr.find(f'{w}color')
            if color is not None:
                val = color.get(f'{w}val')
                result['text_colors'][val] += 1
            
            highlight = rPr.find(f'{w}highlight')
            if highlight is not None:
                val = highlight.get(f'{w}val')
                result['highlights'][val] += 1
            
            vertAlign = rPr.find(f'{w}vertAlign')
            if vertAlign is not None:
                val = vertAlign.get(f'{w}val')
                if val == 'superscript':
                    result['superscript'] += 1
                elif val == 'subscript':
                    result['subscript'] += 1
            
            if rPr.find(f'{w}vanish') is not None:
                result['vanish'] += 1
        
        return result

    def _analyze_styles(self) -> Dict:
        """分析样式系统"""
        result = {
            'total_styles': 0,
            'style_types': Counter(),
            'styles': {},
            'unused_styles': [],
            'built_in_styles': [],
            'custom_styles': []
        }
        
        styles_xml = self._load_xml('word/styles.xml')
        if styles_xml is None:
            return result
        
        w = self.namespaces['w']
        styles = styles_xml.findall(f'{w}style')
        result['total_styles'] = len(styles)
        
        # 收集所有样式定义
        for style in styles:
            style_id = style.get(f'{w}styleId')
            style_type = style.get(f'{w}type') or 'paragraph'
            built_in = style.get(f'{w}customStyle') is None
            name_elem = style.find(f'{w}name')
            name = name_elem.get(f'{w}val') if name_elem is not None else style_id
            
            result['style_types'][style_type] += 1
            
            result['styles'][style_id] = {
                'name': name,
                'type': style_type,
                'built_in': built_in
            }
            
            if built_in:
                result['built_in_styles'].append(name)
            else:
                result['custom_styles'].append(name)
        
        # 分析文档中实际使用的样式
        doc_xml = self._load_xml('word/document.xml')
        used_styles = set()
        if doc_xml is not None:
            for pStyle in doc_xml.findall(f'.//{w}pStyle'):
                val = pStyle.get(f'{w}val')
                if val:
                    used_styles.add(val)
        
        # 找出未使用的样式
        for style_id in result['styles'].keys():
            if style_id not in used_styles:
                result['unused_styles'].append(result['styles'][style_id]['name'])
        
        return result

    def _analyze_tables(self) -> Dict:
        """分析表格"""
        result = {
            'total_tables': 0,
            'tables': [],
            'total_cells': 0,
            'merged_cells': 0,
            'table_styles': Counter(),
            'header_rows': 0
        }
        
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is None:
            return result
        
        w = self.namespaces['w']
        tables = doc_xml.findall(f'.//{w}tbl')
        result['total_tables'] = len(tables)
        
        for idx, tbl in enumerate(tables):
            rows = tbl.findall(f'{w}tr')
            row_count = len(rows)
            col_count = 0
            merged_count = 0
            has_header = False
            table_style = None
            
            # 获取表格样式
            tblPr = tbl.find(f'{w}tblPr')
            if tblPr is not None:
                tblStyle = tblPr.find(f'{w}tblStyle')
                if tblStyle is not None:
                    table_style = tblStyle.get(f'{w}val')
                    if table_style:
                        result['table_styles'][table_style] += 1
                
                # 检测表头
                tblHeader = tblPr.find(f'{w}tblHeader')
                if tblHeader is not None:
                    has_header = True
                    result['header_rows'] += 1
            
            # 计算列数和合并单元格
            if row_count > 0:
                first_row_cells = rows[0].findall(f'{w}tc')
                col_count = 0
                for cell in first_row_cells:
                    gridSpan = cell.find(f'.//{w}gridSpan')
                    span = int(gridSpan.get(f'{w}val')) if gridSpan is not None else 1
                    col_count += span
            
            # 统计合并单元格
            for row in rows:
                for cell in row.findall(f'{w}tc'):
                    result['total_cells'] += 1
                    gridSpan = cell.find(f'.//{w}gridSpan')
                    vMerge = cell.find(f'.//{w}vMerge')
                    if gridSpan is not None or vMerge is not None:
                        merged_count += 1
                        result['merged_cells'] += 1
            
            result['tables'].append({
                'index': idx + 1,
                'rows': row_count,
                'columns': col_count,
                'merged_cells': merged_count,
                'has_header': has_header,
                'style': table_style
            })
        
        return result

    def _analyze_media(self) -> Dict:
        """分析媒体文件"""
        result = {
            'total_images': 0,
            'total_videos': 0,
            'total_audio': 0,
            'media_files': [],
            'inline_images': 0,
            'floating_images': 0,
            'missing_alt_text': 0
        }
        
        # 扫描 media 目录
        media_dir = Path(self.temp_dir) / 'word' / 'media'
        image_exts = ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff', '.svg', '.emf', '.wmf']
        video_exts = ['.mp4', '.avi', '.mov', '.wmv']
        audio_exts = ['.mp3', '.wav', '.wma']
        
        if media_dir.exists():
            for media_file in media_dir.iterdir():
                if media_file.is_file():
                    ext = media_file.suffix.lower()
                    file_info = {
                        'name': media_file.name,
                        'type': ext[1:],
                        'size_bytes': media_file.stat().st_size,
                        'size_formatted': self._format_size(media_file.stat().st_size)
                    }
                    
                    if ext in image_exts:
                        result['total_images'] += 1
                    elif ext in video_exts:
                        result['total_videos'] += 1
                    elif ext in audio_exts:
                        result['total_audio'] += 1
                    
                    result['media_files'].append(file_info)
        
        # 分析图片位置和替代文本
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is not None:
            wp = self.namespaces['wp']
            for inline in doc_xml.findall(f'.//{wp}inline')
            result['inline_images'] = len(inline)
            for anchor in doc_xml.findall(f'.//{wp}anchor'):
                result['floating_images'] = len(anchor)
        
        return result

    def _analyze_word_frequency(self) -> Dict:
        """分析词频和字符频率"""
        result = {
            'full_text': '',
            'chinese_bigrams': Counter(),
            'english_words': Counter(),
            'char_frequency': Counter(),
            'total_chinese_words': 0,
            'total_english_words': 0,
            'vocabulary_size': 0,
            'avg_word_length': 0.0,
            'avg_sentence_length': 0.0
        }
        
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is None:
            return result
        
        w = self.namespaces['w']
        
        # 提取所有文本
        texts = []
        for t in doc_xml.findall(f'.//{w}t'):
            if t.text:
                texts.append(t.text)
        full_text = ''.join(texts)
        result['full_text'] = full_text
        
        # 中文双字词统计
        chinese_pattern = re.compile(r'[\u4e00-\u9fff]{2}')
        chinese_text = re.findall(chinese_pattern, full_text)
        result['chinese_bigrams'] = Counter(chinese_text).most_common(self.config['top_n'])
        
        # 英文词统计
        english_pattern = re.compile(r'[a-zA-Z]{2,}')
        english_words = english_pattern.findall(full_text.lower())
        result['english_words'] = Counter(english_words).most_common(self.config['top_n'])
        
        # 总词数统计
        result['total_chinese_words'] = len(re.findall(r'[\u4e00-\u9fff]+', full_text))
        result['total_english_words'] = len(english_words)
        
        # 字符频率统计
        result['char_frequency'] = Counter(full_text).most_common(30)
        
        # 计算平均词长
        all_words = chinese_text + english_words
        if all_words:
            total_len = sum(len(word) for word in all_words)
            result['avg_word_length'] = total_len / len(all_words)
        
        # 计算平均句长
        sentences = re.split(r'[.!?。！？]+', full_text)
        valid_sentences = [s.strip() for s in sentences if s.strip()]
        if valid_sentences:
            result['avg_sentence_length'] = sum(len(s) for s in valid_sentences) / len(valid_sentences)
        
        return result

    def _analyze_structure(self) -> Dict:
        """分析结构和导航元素"""
        result = {
            'toc_found': False,
            'bookmarks': [],
            'bookmark_count': 0,
            'hyperlinks': {'internal': 0, 'external': 0,
            'external_urls': [],
            'footnotes': 0,
            'endnotes': 0,
            'revisions': {
                'inserts': 0,
                'deletes': 0
            },
            'comments': {
                'count': 0,
                'authors': Counter()
            },
            'content_controls': 0
        }
        
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is not None:
            w = self.namespaces['w']
            r = self.namespaces['r']
            
            # 检测目录
            if doc_xml.find(f'.//{w}toc') is not None:
                result['toc_found'] = True
            
            # 书签
            bookmarks = doc_xml.findall(f'.//{w}bookmarkStart')
            result['bookmark_count'] = len(bookmarks)
            for bm in bookmarks:
                name = bm.get(f'{w}name')
                if name:
                    result['bookmarks'].append(name)
            
            # 超链接
            for hlinks = doc_xml.findall(f'.//{w}hyperlink')
            for link in hlinks:
                id = link.get(f'{r}id')
                if id:
                    result['hyperlinks']['internal'] += 1
                else:
                    result['hyperlinks']['external'] += 1
            
            # 修订痕迹
            inserts = doc_xml.findall(f'.//{w}ins')
            deletes = doc_xml.findall(f'.//{w}del')
            result['revisions']['inserts'] = len(inserts)
            result['revisions']['deletes'] = len(deletes)
            
            # 内容控件
            sdt_elements = doc_xml.findall(f'.//{w}sdt')
            result['content_controls'] = len(sdt_elements)
        
        # 脚注
        footnotes_xml = self._load_xml('word/footnotes.xml')
        if footnotes_xml is not None:
            footnotes = footnotes_xml.findall(f'.//{w}footnote')
            result['footnotes'] = len(footnotes)
        
        # 尾注
        endnotes_xml = self._load_xml('word/endnotes.xml')
        if endnotes_xml is not None:
            endnotes = endnotes_xml.findall(f'.//{w}endnote')
            result['endnotes'] = len(endnotes)
        
        # 批注
        comments_xml = self._load_xml('word/comments.xml')
        if comments_xml is not None:
            comments = comments_xml.findall(f'.//{w}comment')
            result['comments']['count'] = len(comments)
            for comment in comments:
                author = comment.get(f'{w}author')
                if author:
                    result['comments']['authors'][author] += 1
        
        return result

    def _analyze_page_layout(self) -> Dict:
        """分析页面布局和节"""
        result = {
            'total_sections': 0,
            'sections': [],
            'watermark_present': False
        }
        
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is None:
            return result
        
        w = self.namespaces['w']
        sect_prs = doc_xml.findall(f'.//{w}sectPr')
        result['total_sections'] = len(sect_prs)
        
        for sect_pr in sect_prs:
            section_info = {}
            
            # 纸张大小
            pgSz = sect_pr.find(f'{w}pgSz')
            if pgSz is not None:
                w_val = pgSz.get(f'{w}w')
                h_val = pgSz.get(f'{w}h')
                orient = pgSz.get(f'{w}orient') or 'portrait'
                section_info['paper_size'] = {
                    'width': w_val,
                    'height': h_val,
                    'orientation': orient
                }
            
            # 边距
            pgMar = sect_pr.find(f'{w}pgMar')
            if pgMar is not None:
                section_info['margins'] = {
                    'top': pgMar.get(f'{w}top'),
                    'bottom': pgMar.get(f'{w}bottom'),
                    'left': pgMar.get(f'{w}left'),
                    'right': pgMar.get(f'{w}right')
                }
            
            # 分栏
            cols = sect_pr.find(f'{w}cols')
            if cols is not None:
                section_info['columns'] = {
                    'num': cols.get(f'{w}num') or '1',
                    'space': cols.get(f'{w}space')
                }
            
            result['sections'].append(section_info)
        
        # 水印检测
        settings_xml = self._load_xml('word/settings.xml')
        if settings_xml is not None:
            if settings_xml.find(f'.//{w}watermark') is not None:
                result['watermark_present'] = True
        
        return result

    def _analyze_advanced_objects(self) -> Dict:
        """分析高级嵌入对象"""
        result = {
            'equations': 0,
            'charts_present': False,
            'smartart_present': False,
            'ole_objects': [],
            'has_macros': False,
            'activex_controls': 0,
            'signature_lines': 0
        }
        
        doc_xml = self._load_xml('word/document.xml')
        if doc_xml is not None:
            m = self.namespaces['m']
            # 公式
            equations = doc_xml.findall(f'.//{m}oMath')
            result['equations'] = len(equations)
        
        # 检查目录
        word_dir = Path(self.temp_dir) / 'word'
        
        if (word_dir / 'charts').exists():
            result['charts_present'] = True
        
        if (word_dir / 'diagrams').exists():
            result['smartart_present'] = True
        
        embeddings_dir = word_dir / 'embeddings'
        if embeddings_dir.exists():
            for emb_file in embeddings_dir.iterdir():
                if emb_file.is_file():
                    result['ole_objects'].append(emb_file.name)
        
        if (word_dir / 'vbaProject.bin').exists():
            result['has_macros'] = True
        
        return result

    def _analyze_health_checks(self) -> Dict:
        """健康与合规检查"""
        result = {
            'unused_styles': [],
            'broken_references': [],
            'deep_nesting': [],
            'non_standard_fonts': [],
            'hidden_text_found': False,
            'sensitive_keywords_found': [],
            'accessibility_issues': []
        }
        
        # 未使用的样式
        if 'styles' in self.results:
            result['unused_styles'] = self.results['styles'].get('unused_styles', [])
        
        # 隐藏文本
        if 'character_formatting' in self.results:
            result['hidden_text_found'] = self.results['character_formatting'].get('vanish', 0) > 0
        
        # 敏感关键词检测
        if self.config['sensitive_keywords']:
            full_text = self.results['word_frequency'].get('full_text', '')
            for keyword in self.config['sensitive_keywords']:
                if keyword in full_text:
                    result['sensitive_keywords_found'].append(keyword)
        
        # 辅助功能检查
        if 'media' in self.results:
            missing_alt = self.results['media'].get('missing_alt_text', 0)
            if missing_alt > 0:
                result['accessibility_issues'].append(f"{missing_alt} 张图片缺少替代文本")
        
        # 标题级别跳跃检测
        if 'paragraphs' in self.results:
            if 'styles' in self.results:
                outline_levels = self.results['paragraphs'].get('outline_levels', {})
                prev_level = None
                for level_str in sorted(outline_levels.keys(), key=lambda x: int(x)):
                    try:
                        level = int(level_str)
                        if prev_level is not None and level > prev_level + 1:
                            result['accessibility_issues'].append(f"标题级别跳跃: 从 {prev_level} 跳到 {level}")
                        prev_level = level
                    except ValueError:
                        continue
        
        return result

    def _generate_json_report(self) -> Dict:
        """生成 JSON 报告"""
        report = {
            'file_info': self.results.get('file_info', {}),
            'metadata': self.results.get('metadata', {}),
            'fonts': self.results.get('fonts', {}),
            'paragraphs': self.results.get('paragraphs', {}),
            'character_formatting': self.results.get('character_formatting', {}),
            'styles': self.results.get('styles', {}),
            'tables': self.results.get('tables', {}),
            'media': self.results.get('media', {}),
            'word_frequency': self.results.get('word_frequency', {}),
            'structure': self.results.get('structure', {}),
            'page_layout': self.results.get('page_layout', {}),
            'advanced_objects': self.results.get('advanced_objects', {}),
            'health_checks': self.results.get('health_checks', {}),
            'warnings': self.warnings,
            'brand': {
                'name': _BRAND_NAME,
                'version': _VERSION,
                'url': _BRAND_URL,
                'tagline': _BRAND_TAGLINE
            }
        }
        return report

    def _generate_markdown_report(self) -> str:
        """生成 Markdown 报告"""
        lines = []
        file_info = self.results.get('file_info', {})
        
        lines.append(f"# Boo哥AI智写 . Docx Forensic Report for `{file_info.get('name', 'document.docx')}`\n")
        lines.append(f"**文件路径**: {file_info.get('path', 'N/A')}\n")
        lines.append(f"**分析时间**: {file_info.get('analysis_time', 'N/A')}\n")
        lines.append(f"**文件大小**: {file_info.get('size_formatted', 'N/A')}\n")
        lines.append("\n---\n")
        
        # 元数据
        metadata = self.results.get('metadata', {})
        if metadata.get('core') or metadata.get('app'):
            lines.append("## 📋 元数据\n\n")
            core = metadata.get('core', {})
            if core:
                if 'title' in core:
                    lines.append(f"- **标题**: {core['title']}\n")
                if 'author' in core:
                    lines.append(f"- **作者**: {core['author']}\n")
                if 'created' in core:
                    lines.append(f"- **创建时间**: {core['created']}\n")
                if 'modified' in core:
                    lines.append(f"- **修改时间**: {core['modified']}\n")
            app = metadata.get('app', {})
            if app:
                if 'pages' in app:
                    lines.append(f"- **页数**: {app['pages']}\n")
                if 'words' in app:
                    lines.append(f"- **字数**: {app['words']}\n")
            lines.append("\n")
        
        # 字体分析
        fonts = self.results.get('fonts', {})
        if fonts:
            lines.append("## 🔤 字体\n\n")
            font_occs = fonts.get('font_occurrences', {})
            if font_occs:
                lines.append("| 字体名称 | 出现次数 | 嵌入 |\n")
                lines.append("|----------|----------|------|\n")
                for font, count in list(font_occs.items())[:15]:
                    embedded = "是" if font in fonts.get('embedded_fonts', []) else "否"
                    lines.append(f"| {font} | {count:,} | {embedded} |\n")
                lines.append("\n")
        
        # 段落分析
        paragraphs = self.results.get('paragraphs', {})
        if paragraphs:
            lines.append("## 📝 段落分析\n\n")
            lines.append(f"- **总段落数**: {paragraphs.get('total_paragraphs', 0):,}\n")
            lines.append(f"- **空段落数**: {paragraphs.get('empty_paragraphs', 0):,}\n")
            lines.append(f"- **分页符**: {paragraphs.get('page_breaks', 0):,}\n")
            lines.append("\n")
        
        # 字符格式
        char_format = self.results.get('character_formatting', {})
        if char_format:
            lines.append("## ✨ 字符格式\n\n")
            lines.append(f"- **粗体**: {char_format.get('bold', 0):,}\n")
            lines.append(f"- **斜体**: {char_format.get('italic', 0):,}\n")
            lines.append(f"- **删除线**: {char_format.get('strike', 0):,}\n")
            lines.append(f"- **上标**: {char_format.get('superscript', 0):,}\n")
            lines.append(f"- **下标**: {char_format.get('subscript', 0):,}\n")
            lines.append("\n")
        
        # 样式分析
        styles = self.results.get('styles', {})
        if styles:
            lines.append("## 🎨 样式\n\n")
            lines.append(f"- **总样式数**: {styles.get('total_styles', 0):,}\n")
            lines.append(f"- **未使用样式数**: {len(styles.get('unused_styles', [])):,}\n")
            lines.append("\n")
        
        # 表格分析
        tables = self.results.get('tables', {})
        if tables:
            lines.append("## 📊 表格\n\n")
            lines.append(f"- **总表格数**: {tables.get('total_tables', 0):,}\n")
            lines.append(f"- **总单元格数**: {tables.get('total_cells', 0):,}\n")
            lines.append(f"- **合并单元格数**: {tables.get('merged_cells', 0):,}\n")
            lines.append("\n")
        
        # 媒体分析
        media = self.results.get('media', {})
        if media:
            lines.append("## 🖼️ 媒体文件\n\n")
            lines.append(f"- **图片**: {media.get('total_images', 0):,}\n")
            lines.append(f"- **视频**: {media.get('total_videos', 0):,}\n")
            lines.append(f"- **音频**: {media.get('total_audio', 0):,}\n")
            lines.append("\n")
        
        # 词频统计
        word_freq = self.results.get('word_frequency', {})
        if word_freq:
            lines.append("## 📈 词频统计\n\n")
            
            chinese_bigrams = word_freq.get('chinese_bigrams', [])
            if chinese_bigrams:
                lines.append("### 高频中文词组 (Top 10):\n\n")
                lines.append("| 排名 | 词组 | 出现次数 |\n")
                lines.append("|------|------|----------|\n")
                for idx, (word, count) in enumerate(chinese_bigrams[:10]):
                    lines.append(f"| {idx + 1} | {word} | {count:,} |\n")
                lines.append("\n")
            
            english_words = word_freq.get('english_words', [])
            if english_words:
                lines.append("### 高频英文单词 (Top 10):\n\n")
                lines.append("| 排名 | 单词 | 出现次数 |\n")
                lines.append("|------|------|----------|\n")
                for idx, (word, count) in enumerate(english_words[:10]):
                    lines.append(f"| {idx + 1} | {word} | {count:,} |\n")
                lines.append("\n")
        
        # 结构分析
        structure = self.results.get('structure', {})
        if structure:
            lines.append("## 🏗️ 文档结构\n\n")
            lines.append(f"- **批注数**: {structure.get('comments', {}).get('count', 0):,}\n")
            lines.append(f"- **插入修订**: {structure.get('revisions', {}).get('inserts', 0):,}\n")
            lines.append(f"- **删除修订**: {structure.get('revisions', {}).get('deletes', 0):,}\n")
            lines.append(f"- **书签**: {structure.get('bookmark_count', 0):,}\n")
            lines.append("\n")
        
        # 高级对象
        advanced = self.results.get('advanced_objects', {})
        if advanced:
            lines.append("## 🔬 高级对象\n\n")
            lines.append(f"- **公式**: {advanced.get('equations', 0):,}\n")
            if advanced.get('has_macros'):
                lines.append(f"- **宏**: ⚠️ 发现VBA宏文件\n")
            if advanced.get('charts_present'):
                lines.append(f"- **图表**: 是\n")
            lines.append("\n")
        
        # 健康检查
        health = self.results.get('health_checks', {})
        if health:
            lines.append("## ⚠️ 健康警告\n\n")
            issues = []
            
            unused_styles = health.get('unused_styles', [])
            if unused_styles:
                issues.append(f"{len(unused_styles)} 个未使用的样式")
            
            if health.get('hidden_text_found'):
                issues.append("检测到隐藏文本")
            
            sensitive_found = health.get('sensitive_keywords_found', [])
            if sensitive_found:
                issues.append(f"检测到敏感关键词: {', '.join(sensitive_found[:5])}")
            
            accessibility_issues = health.get('accessibility_issues', [])
            issues.extend(accessibility_issues)
            
            if issues:
                for issue in issues:
                    lines.append(f"- ⚠️ {issue}\n")
            else:
                lines.append("- ✅ 未发现严重问题\n")
            lines.append("\n")
        
        if self.warnings:
            lines.append("## 📢 分析警告\n\n")
            for warning in self.warnings:
                lines.append(f"- {warning}\n")
            lines.append("\n")
        
        lines.append("---\n")
        lines.append(_BRAND_FOOTER + "\n")
        lines.append("\n")

        return ''.join(lines)


def main():
    if len(sys.argv) < 2:
        print(f"{_BRAND_NAME} Docx Forensic Analyzer v{_VERSION}")
        print(f"{_BRAND_TAGLINE}")
        print()
        print("用法: python analyze_docx.py <docx文件路径> [输出JSON路径]")
        print("示例: python analyze_docx.py document.docx report.json")
        sys.exit(1)

    docx_path = sys.argv[1]
    json_output_path = sys.argv[2] if len(sys.argv) > 2 else None

    try:
        config = {
            'top_n': 50,
            'enable_readability': False,
            'sensitive_keywords': []
        }
        
        analyzer = DOCXForensicAnalyzer(docx_path, config)
        json_data, markdown_report = analyzer.analyze()
        
        print(markdown_report)
        
        if json_output_path:
            with open(json_output_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, ensure_ascii=False, indent=2)
            print(f"\nJSON 报告已保存至: {json_output_path}")
            
            md_output_path = Path(json_output_path).with_suffix('.md')
            with open(md_output_path, 'w', encoding='utf-8') as f:
                f.write(markdown_report)
            print(f"Markdown 报告已保存至: {md_output_path}")

    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
