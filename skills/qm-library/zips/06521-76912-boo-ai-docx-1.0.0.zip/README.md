<p align="center">
  <img src="https://img.shields.io/badge/Boo哥AI智写-Docx%20Forensic%20Analyzer-blue?style=for-the-badge" alt="Boo哥AI智写">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.7+-3776AB?style=flat&logo=python" alt="Python">
  <img src="https://img.shields.io/badge/License-MIT-green?style=flat" alt="License">
  <img src="https://img.shields.io/badge/Zero-Dependencies-brightgreen?style=flat" alt="Dependencies">
  <img src="https://img.shields.io/badge/Module-12_Dimensions-orange?style=flat" alt="Modules">
  <img src="https://img.shields.io/badge/Boo哥AI智写-Powered_by-purple?style=flat" alt="Brand">
</p>

<h1 align="center">
  <pre>
╔═══════════════════════════════════════╗
║  ██████╗  ██████╗  ██████╗           ║
║  ██╔══██╗██╔═══██╗██╔═══██╗  AI智写  ║
║  ██████╔╝██║   ██║██║   ██║          ║
║  ██╔══██╗██║   ██║██║   ██║          ║
║  ██████╔╝╚██████╔╝╚██████╔╝          ║
║  ╚═════╝  ╚═════╝  ╚═════╝           ║
║                                       ║
║  📄 DOCX 全面取证分析器               ║
║  Forensic Document Analyzer           ║
╚═══════════════════════════════════════╝
  </pre>
</h1>

<p align="center">
  <strong>🔍 让每一份 Word 文档都无所遁形 —— 12大维度深度扫描，零依赖开箱即用</strong>
</p>

<p align="center">
  <a href="#功能特性">功能特性</a> ·
  <a href="#快速开始">快速开始</a> ·
  <a href="#使用方式">使用方式</a> ·
  <a href="#输出示例">输出示例</a> ·
  <a href="#项目结构">项目结构</a> ·
  <a href="#路线图">路线图</a>
</p>

---

## ✨ 功能特性

| 模块 | 分析内容 |
|------|----------|
| 📋 元数据 | 标题、作者、创建/修改时间、字数、页数、模板、应用版本 |
| 🔤 字体分析 | 字体表、使用频率、嵌入字体检测、符号字体标记 |
| 📝 段落格式 | 段落统计、样式分布、对齐方式、大纲级别、分页/分节符 |
| ✨ 字符格式 | 粗体/斜体/下划线/删除线统计、颜色聚合、高亮分布、上下标 |
| 🎨 样式系统 | 样式总数、内置 vs 自定义、未使用样式检测 |
| 📊 表格分析 | 表格数、单元格数、合并单元格、表头检测、表格样式 |
| 🖼️ 媒体文件 | 图片/视频/音频统计、格式分类、文件大小、内联 vs 浮动 |
| 📈 词频统计 | 中文词组频率 (Top N)、英文单词频率 (Top N)、平均词长/句长 |
| 🏗️ 文档结构 | 目录检测、书签、超链接、脚注/尾注、批注、修订痕迹 |
| 📐 页面布局 | 节数量、纸张大小、边距、分栏、水印 |
| 🔬 高级对象 | 公式、图表、SmartArt、OLE对象、VBA宏检测 |
| ⚠️ 健康检查 | 未使用样式、隐藏文本、敏感关键词、辅助功能、标题跳跃 |

> 💡 **核心优势**: 不依赖 `python-docx`，直接解压 ZIP 并解析 OOXML XML，实现底层属性的完全访问。

---

## 📦 项目结构

```
docx-file-analyzer/
├── 📄 SKILL.md                      # 技能定义文件（含完整分析逻辑）
├── 📄 README.md                     # 项目说明（本文件）
├── 📄 LICENSE                       # MIT 开源协议
├── 📄 .gitignore                    # Git 忽略规则
├── 📄 requirements.txt              # 可选依赖清单
├── 📄 CHANGELOG.md                  # 版本变更日志
├── 📄 CONTRIBUTING.md               # 贡献指南
├── 📁 scripts/
│   ├── 🐍 analyze_docx.py           # 核心分析脚本
│   └── 🧪 test_analyzer.py          # 单元测试
├── 📁 evals/
│   ├── evals.json                   # 测试用例集
│   └── eval_metadata_1.json         # 测试元数据
└── 📁 assets/
    └── brand.md                     # 品牌与使用规范
```

---

## 🚀 快速开始

### 环境要求

- **Python** >= 3.7
- **零外部依赖** — 核心功能仅用 Python 标准库！
- 可选：`jieba`（中文分词增强）、`lxml`（更快 XML 解析）

### 安装

```bash
# 克隆仓库
git clone https://github.com/Boo哥AI智写/docx-file-analyzer.git
cd docx-file-analyzer

# （可选）安装增强依赖
pip install -r requirements.txt
```

### 使用

```bash
# 分析文档并输出 Markdown 报告
python scripts/analyze_docx.py my_document.docx

# 同时保存 JSON 和 Markdown 报告
python scripts/analyze_docx.py my_document.docx forensic_report.json
```

---

## 📖 使用方式

### 方式一：命令行

```bash
python scripts/analyze_docx.py <docx文件路径> [输出JSON路径]
```

### 方式二：Python 模块

```python
from scripts.analyze_docx import DOCXForensicAnalyzer

config = {
    'top_n': 50,
    'enable_readability': False,
    'sensitive_keywords': ['密码', '机密', 'password']
}

analyzer = DOCXForensicAnalyzer('document.docx', config)
json_data, markdown_report = analyzer.analyze()

print(markdown_report)
```

### 方式三：Claude AI 技能

将此技能安装到 Claude AI 后，直接说：

- 🗣️ "分析这个 Word 文档：年度报告.docx"
- 🗣️ "帮我全面诊断这个文档"
- 🗣️ "提取技术方案.docx 的所有属性和统计信息"

---

## 📊 输出示例

### Markdown 报告（终端/文件）

```markdown
# 📄 Boo哥AI智写 · Docx Forensic Report for `年度报告.docx`

**文件路径**: C:\Documents\年度报告.docx
**分析时间**: 2026-05-17T10:30:00
**文件大小**: 1.25 MB

---

## 📋 元数据

- **作者**: 张三
- **创建时间**: 2025-03-15T10:00:00
- **页数**: 28
- **字数**: 12,500

---

## 🔤 字体

| 字体名称 | 出现次数 | 嵌入 |
|----------|----------|------|
| 等线     | 3,420    | 否   |
| Calibri  | 180      | 否   |

## 📈 词频统计

### 高频中文词组 (Top 10):

| 排名 | 词组 | 出现次数 |
|------|------|----------|
| 1    | 项目 | 345      |
| 2    | 分析 | 278      |
...

## ⚠️ 健康警告

- ⚠️ 12 个未使用的样式
- ⚠️ 3 张图片缺少替代文本

---
> 🤖 本报告由 Boo哥AI智写 · Docx Forensic Analyzer 自动生成
```

### JSON 报告（程序消费）

```json
{
  "file_info": { "path": "C:\\...", "name": "年度报告.docx", "size_formatted": "1.25 MB" },
  "metadata": { "core": { "author": "张三", "created": "2025-03-15T10:00:00" }, "app": { "pages": "28" } },
  "fonts": { "font_occurrences": { "等线": 3420, "Calibri": 180 }, "embedded_fonts": [] },
  "tables": { "total_tables": 7, "merged_cells": 34 },
  "health_checks": { "unused_styles": ["StyleA", "StyleB"] },
  "warnings": [],
  "brand": "Boo哥AI智写"
}
```

---

## 🧪 测试

```bash
# 运行单元测试
cd scripts
python test_analyzer.py

# 或使用 pytest
pytest test_analyzer.py -v
```

---

## 🗺️ 路线图

- [ ] 多文档对比分析
- [ ] Excel 格式统计导出
- [ ] 可视化图表生成 (matplotlib)
- [ ] 文档敏感信息智能检测
- [ ] 文档合规性自动审查
- [ ] 批量文档分析流水线
- [ ] jieba 中文分词集成（更精准词频）
- [ ] Web 界面（Flask/FastAPI）

---

## 🤝 贡献

欢迎贡献代码！请阅读 [CONTRIBUTING.md](CONTRIBUTING.md) 了解详情。

- 🐛 发现 Bug？[提 Issue](https://github.com/Boo哥AI智写/docx-file-analyzer/issues)
- 💡 有建议？[开启 Discussion](https://github.com/Boo哥AI智写/docx-file-analyzer/discussions)
- 🍴 Fork 并提 PR！

---

## 🏷️ 品牌

本项目由 **Boo哥AI智写** 开发与维护。

```
     Boo哥AI智写
     让技术如呼吸般自然
```

分析报告尾部将自动附带 Boo哥AI智写 品牌标识，帮助你的技术成果在分享时获得曝光。

---

## 📄 许可证

```
MIT License

Copyright (c) 2024-2026 Boo哥AI智写

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files, to deal in the Software
without restriction...
```

详见 [LICENSE](LICENSE) 文件。

---

<p align="center">
  <sub>Made with ❤️ by <strong>Boo哥AI智写</strong></sub>
  <br>
  <sub>© 2024-2026 Boo哥AI智写. All rights reserved.</sub>
</p>
