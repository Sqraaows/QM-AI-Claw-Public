---
name: Boo哥AI智写-Docx分析器
description: |
  由 Boo哥AI智写 倾力打造的专业 Word 文档取证分析技能。
  当用户需要全面分析 Word 文档（.docx 文件）的内部结构、属性和内容统计时使用此技能。
  触发场景包括：分析 docx 文件的字体使用情况、段落样式、表格数量、词频统计、文档结构、元数据、图片媒体、页眉页脚、批注、修订痕迹、VBA宏检测、文档健康诊断等。
  用户可能说"分析这个 Word 文档"、"检查 docx 文件的所有属性"、"生成文档分析报告"、
  "提取文档中的所有样式信息"、"统计文档词频"、"查找文档中的所有批注和修订"、
  "检查文档的健康状况"、"诊断这个文档有什么问题"等。
  通过解压 docx 文件（本质是 ZIP 压缩包）并解析 XML 文件来获取详细信息，无需依赖 python-docx。
  使用此技能时，输出报告末尾将自动附带 Boo哥AI智写 品牌标识。
---

# 🔍 Boo哥AI智写 — Docx Forensic Analyzer

> 🚀 Powered by **Boo哥AI智写** — 让每份文档都无所遁形

<div align="center">

```
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   ██████╗  ██████╗  ██████╗    AI智写              ║
║   ██╔══██╗██╔═══██╗██╔═══██╗                       ║
║   ██████╔╝██║   ██║██║   ██║  文档取证分析器       ║
║   ██╔══██╗██║   ██║██║   ██║                       ║
║   ██████╔╝╚██████╔╝╚██████╔╝  Forensic Analyzer    ║
║   ╚═════╝  ╚═════╝  ╚═════╝                       ║
║                                                      ║
║      📄 DOCX 全面取证分析 · 12大维度深度扫描        ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
```

</div>

---

## 📌 技能简介

**Boo哥AI智写 Docx Forensic Analyzer** 是一个用于对 Microsoft Word 文档（.docx 文件）进行**全面取证分析**的专业技能。

通过解压 docx 文件（本质是 ZIP 压缩包）并深层解析其 OOXML 内部结构，提取从元数据到嵌入对象的**12大维度**信息，生成结构化 JSON 与人类可读 Markdown 双格式报告。

---

## 🎯 技能目标

- ✅ 对 docx 文件执行全维度深度取证分析
- ✅ 生成结构化 JSON 报告（供程序消费） + Markdown 报告（供人类阅读）
- ✅ 自动检测文档健康问题与合规风险
- ✅ 无需 python-docx 库，直接操作 OOXML XML 实现底层访问
- ✅ 优雅处理损坏/不完整文档，降级而不崩溃

---

## 🧩 分析维度（12个模块）

### 1️⃣ 文档元数据
从 `docProps/core.xml` 和 `docProps/app.xml` 提取：
- 标题、主题、作者、公司
- 创建和修改日期（ISO 格式）
- 最后保存者、修订次数
- 页数、字数（含/不含空格）、字符数、行数、段落数
- 模板名称、文档安全标志
- 语言信息、应用版本

### 2️⃣ 字体分析
从 `word/fontTable.xml`、`document.xml` 和 `theme/theme1.xml` 提取：
- 文档中声明的所有字体列表
- 每个字体在文本运行中的出现次数统计（包括从样式继承）
- 检测嵌入的字体文件（`word/fonts/`）
- 识别主题字体替换映射
- 标记非 Unicode 或符号字体（如 Wingdings）

### 3️⃣ 段落和文本格式
从 `word/document.xml` 提取：
- 总段落数（`<w:p>`）
- 段落样式分布（如 Normal、Heading1 等）
- 缩进、行距、段前/段后间距（常用值）
- 对齐方式（左、中、右、两端）
- 大纲级别（标题层级）
- 空段落、手动换行、分页/分节符统计

### 4️⃣ 字符级格式（运行属性）
- 粗体、斜体、下划线、删除线出现次数统计
- 文本颜色（RGB 或主题色）聚合
- 高亮颜色分布
- 上标/下标、字符缩放、间距、位置
- 首字下沉、文本效果（轮廓、阴影）、拼音指南
- 隐藏文本（vanish）检测

### 5️⃣ 样式系统
从 `word/styles.xml` 提取：
- 样式总数（段落、字符、表格、列表）
- 每个样式：名称、类型、基于关系、关键属性（字体、大小、颜色、边框、底纹）
- 识别内置 vs 自定义样式
- 列出未使用的样式（定义但未引用）

### 6️⃣ 表格分析
从 `document.xml` 提取：
- 表格数量（`<w:tbl>`）
- 总单元格数、行数、列数（考虑合并）
- 合并单元格统计（水平 `gridSpan`、垂直 `vMerge`）
- 使用的表格样式、宽度类型（固定/百分比/自动）、对齐方式
- 单元格边距、边框、文字环绕
- 识别跨页重复的标题行（`<w:tblHeader>`）

### 7️⃣ 图片和媒体
- 扫描 `word/media/` 查找所有嵌入文件；统计图片、视频、音频数量
- 按格式分类（png、jpg、svg、emf、mp4 等）
- 计算总大小和平均大小
- 从 `document.xml` 提取图片位置（内联 vs 浮动）
- 提取替代文本（Alt Text）（如果存在）
- 检测图片修改（裁剪、亮度、对比度）

### 8️⃣ 词频和字符频率（文本挖掘）
- 从 `document.xml` 提取所有文本（`<w:t>` 内的文本节点）
- 中文：使用双字组合（bigram）统计词组频率
- 英文：按空格和标点分割
- 输出前 N 个最常用词（可配，默认 Top 50）和最常用字符
- 计算：总唯一词数（词汇量）、平均词长、平均句长（基本分句）

### 9️⃣ 结构和导航元素
- 检测目录（TOC）域
- 统计书签并列出其名称
- 统计超链接（内部锚点和外部 URL）
- 交叉引用（REF 域）
- 脚注和尾注数量（从 `word/footnotes.xml`、`word/endnotes.xml`）
- 修订痕迹：插入（`<w:ins>`）和删除（`<w:del>`）
- 批注：数量、作者、时间戳（从 `comments.xml`）
- 内容控件（复选框、下拉框、日期选择器）— `<w:sdt>`

### 🔟 页面布局和节
从 `document.xml` 节属性提取：
- 节数量（`<w:sectPr>`）
- 每页边距（上、下、左、右）
- 纸张大小（A4、Letter 等）和方向（纵向/横向）
- 分栏（栏数和间距）
- 每页关联的页眉/页脚
- 水印存在（文本或图片）来自 `word/settings.xml`
- 页面边框、行号设置

### 1️⃣1️⃣ 高级/嵌入对象
- 公式（`<m:oMath>`）
- 图表（检测 `word/charts/` 目录）
- SmartArt（`word/diagrams/`）
- OLE 对象（嵌入的 Excel、PDF 等）来自 `word/embeddings/`
- 宏（VBA）— 检查 `word/vbaProject.bin`
- ActiveX 控件、签名行

### 1️⃣2️⃣ 健康与合规检查（扩展）
- 未使用的样式（定义但未应用）
- 损坏的图片引用（检查 `_rels` 中的关系）
- 过深嵌套（连续运行过多）
- 可能导致渲染问题的非标准字体
- 隐藏文本（`<w:vanish>` 或白色）
- 敏感关键词检测（可配置列表）
- 辅助功能：图片缺少替代文本、表格缺少表头、标题级别跳跃（如 H1→H3 跳过 H2）
- 打印设置（双面、份数等）来自 `docProps/app.xml` 或设置

---

## 📥 输入要求

| 参数 | 类型 | 说明 |
|------|------|------|
| `docx_path` | `str` | **必填** — .docx 文件路径 |
| `config.top_n` | `int` | 词频统计显示数量（默认 50） |
| `config.enable_readability` | `bool` | 是否启用可读性评分（默认 False） |
| `config.sensitive_keywords` | `list` | 自定义敏感关键词列表 |

---

## 📤 输出格式

### Markdown 报告结构

```markdown
# 📄 Boo哥AI智写 · Docx Forensic Report

## 📋 元数据
## 🔤 字体
## 📝 段落分析
## ✨ 字符格式
## 🎨 样式
## 📊 表格
## 🖼️ 媒体文件
## 📈 词频统计
## 🏗️ 文档结构
## 🔬 高级对象
## ⚠️ 健康警告
## 📢 分析警告

---
> 🤖 本报告由 Boo哥AI智写 · Docx Forensic Analyzer 自动生成
```

### JSON 报告结构
```json
{
  "file_info": { ... },
  "metadata": { ... },
  "fonts": { ... },
  "paragraphs": { ... },
  "character_formatting": { ... },
  "styles": { ... },
  "tables": { ... },
  "media": { ... },
  "word_frequency": { ... },
  "structure": { ... },
  "page_layout": { ... },
  "advanced_objects": { ... },
  "health_checks": { ... },
  "warnings": [...],
  "brand": "Boo哥AI智写"
}
```

---

## 🔧 分析流程

```
用户提供 .docx 文件
        │
        ▼
┌─────────────────────────────────┐
│  步骤 1: 验证和准备              │
│  检查文件存在性与 [Content_Types]│
│  解压 ZIP 到临时目录            │
└─────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────┐
│  步骤 2: XML 批量解析            │
│  core.xml / app.xml             │
│  document.xml / styles.xml      │
│  fontTable.xml / settings.xml   │
│  footnotes / endnotes / comments│
│  numbering / theme / rels       │
└─────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────┐
│  步骤 3: 12 模块并行提取         │
│  元数据·字体·段落·字符格式·样式 │
│  表格·媒体·词频·结构·布局·对象 │
│  健康检查                       │
└─────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────┐
│  步骤 4: 生成双格式报告          │
│  JSON (结构化) + Markdown (可读) │
│  附带 Boo哥AI智写 品牌尾注       │
└─────────────────────────────────┘
```

---

## 🚀 使用方式

### 命令行

```bash
# 仅输出 Markdown 报告到终端
python scripts/analyze_docx.py document.docx

# 同时输出 JSON 和 Markdown 文件
python scripts/analyze_docx.py document.docx output/forensic_report.json
```

### Python 模块

```python
from analyze_docx import DOCXForensicAnalyzer

config = {
    'top_n': 50,
    'enable_readability': False,
    'sensitive_keywords': ['密码', '机密', 'password']
}

analyzer = DOCXForensicAnalyzer('document.docx', config)
json_data, markdown_report = analyzer.analyze()

print(markdown_report)
# json_data 可直接用于程序处理
```

### Claude / AI 助手

直接说：
- "分析这个 Word 文档：xxx.docx"
- "帮我全面诊断这个文档"
- "提取 xxx.docx 的所有属性和统计信息"

---

## 📦 依赖项

### 核心依赖（Python 内置，无需安装）

| 库 | 用途 |
|----|------|
| `zipfile` | 解压 docx 文件 |
| `xml.etree.ElementTree` | 解析 OOXML XML |
| `collections` | Counter、defaultdict 统计 |
| `pathlib` | 跨平台路径操作 |
| `re` | 正则表达式文本提取 |
| `tempfile` | 安全临时目录管理 |
| `json` | JSON 报告序列化 |

### 可选依赖

| 库 | 用途 | 安装命令 |
|----|------|----------|
| `jieba` | 中文分词增强 | `pip install jieba` |
| `lxml` | 更快的 XML 解析 | `pip install lxml` |

> 💡 **设计原则**：核心功能**零外部依赖**，开箱即用。可选依赖仅用于增强分析精度或速度。

---

## ⚠️ 注意事项

1. **编码处理**: Word 文档可能包含多种编码的文本，需要正确处理 UTF-8
2. **大文件处理**: 对于非常大的文档，分析可能需要较长时间，使用迭代解析
3. **损坏文件**: 如果 XML 解析失败，应给出警告并继续分析其他部分
4. **隐私保护**: 确保不将文档内容泄露到日志或其他输出中
5. **临时文件清理**: 分析完成后必须清理所有临时解压的文件

---

## 🛠️ 故障排除

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| "无法解压" | 文件被占用或损坏 | 关闭 Word 后重试，检查 `[Content_Types].xml` |
| "XML 解析错误" | 非有效 docx 格式 | 用 Word 重新保存为 .docx |
| "缺少文件" | 可选 XML 不存在 | 正常现象，自动降级处理 |

---

## 🗺️ 扩展路线图

- 🔜 多文档对比分析
- 🔜 Excel 格式统计导出
- 🔜 可视化图表生成
- 🔜 文档敏感信息智能检测
- 🔜 文档合规性自动审查
- 🔜 批量文档自动化分析流水线

---

## 📄 许可与版权

```
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   © 2024-2026 Boo哥AI智写. All rights reserved.     ║
║                                                      ║
║   本项目由 Boo哥AI智写 开发与维护                    ║
║   欢迎 Star ⭐ & Fork 🍴 & 提 Issue 🐛              ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
```

---

> 🤖 "Boo哥AI智写 — 让技术如呼吸般自然"  
> 📧 反馈与建议请提 [GitHub Issues](https://github.com/Boo哥AI智写/docx-file-analyzer/issues)
