# 🤝 Contributing to Boo哥AI智写 · Docx Forensic Analyzer

感谢你对本项目感兴趣！我们欢迎各种形式的贡献。

---

## 📋 贡献方式

### 🐛 报告 Bug
1. 先搜索 [Issues](https://github.com/Boo哥AI智写/docx-file-analyzer/issues) 确认是否已存在
2. 如果没有，创建新 Issue
3. 请包含以下信息：
   - 操作系统和 Python 版本
   - 完整的错误/警告信息
   - 重现步骤
   - 如果可能，提供测试用的 .docx 文件（注意隐私）

### 💡 功能建议
1. 先搜索 [Discussions](https://github.com/Boo哥AI智写/docx-file-analyzer/discussions) 或 [Issues](https://github.com/Boo哥AI智写/docx-file-analyzer/issues)
2. 创建新 Issue，标记为 `enhancement`
3. 描述你需要的功能和使用场景

### 🍴 Pull Request 流程

```bash
# 1. Fork 仓库
# 2. 克隆到本地
git clone https://github.com/YOUR_USERNAME/docx-file-analyzer.git
cd docx-file-analyzer

# 3. 创建特性分支
git checkout -b feature/your-feature-name

# 4. 进行开发...

# 5. 运行测试
cd scripts
python test_analyzer.py

# 6. 提交
git add .
git commit -m "feat: 描述你的改动"

# 7. 推送并创建 PR
git push origin feature/your-feature-name
```

---

## 🧪 开发规范

### 代码风格
- 遵循 PEP 8
- 使用中文注释
- 函数名使用 snake_case，类名使用 PascalCase
- 保持 Python 3.7+ 兼容

### 文件名
- 分析模块方法: `_analyze_xxx()`
- 私有方法以 `_` 开头

### 测试要求
- 新功能应有对应的测试用例
- 运行 `python test_analyzer.py` 确保测试通过

### 依赖原则
- **核心功能**: 零外部依赖，仅用 Python 标准库
- **增强功能**: 可选依赖放在 `requirements.txt`

---

## 📁 项目结构约定

```
scripts/
  analyze_docx.py          # 主分析脚本 ─ 新增分析模块请在此添加
  test_analyzer.py         # 测试文件 ─ 对应新模块添加测试

evals/                     # 技能评估测试用例
  evals.json
  eval_metadata_1.json

assets/                    # 品牌 & 静态资源
```

---

## ⚡ 如何添加新的分析模块

1. 在 `DOCXForensicAnalyzer` 类中添加 `_analyze_xxx()` 方法
2. 在 `_analyze_all()` 中注册新模块
3. 在 `_generate_json_report()` 中输出新数据
4. 在 `_generate_markdown_report()` 中渲染新章节
5. 更新 `SKILL.md` 和 `README.md` 文档

示例模板：

```python
def _analyze_xxx(self) -> Dict:
    result = {'key': 'value'}
    doc_xml = self._load_xml('word/xxx.xml')
    if doc_xml is None:
        return result
    # 解析逻辑...
    return result
```

---

## 🙏 致谢

每一位贡献者都将在此致谢：

- **Boo哥AI智写** — 项目创建者与维护者

---

> 💬 有问题？欢迎在 [Discussions](https://github.com/Boo哥AI智写/docx-file-analyzer/discussions) 中讨论！
