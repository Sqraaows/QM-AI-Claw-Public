# Changelog

所有值得注意的改动都将记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

---

## [1.0.0] - 2026-05-17

### 🚀 首次发布 — Boo哥AI智写 Docx Forensic Analyzer

#### 新增
- ✨ **12大分析维度** 全面取证分析
  - 📋 文档元数据分析（core.xml / app.xml）
  - 🔤 字体表与使用频率统计
  - 📝 段落格式与样式分布
  - ✨ 字符级格式检测（粗体/斜体/颜色/高亮等）
  - 🎨 样式系统分析（内置 vs 自定义）
  - 📊 表格分析（合并单元格、表头检测）
  - 🖼️ 媒体文件统计与分类
  - 📈 中英文词频统计（Top N 排行）
  - 🏗️ 文档结构（目录/书签/超链接/批注/修订）
  - 📐 页面布局（纸张大小/边距/分栏/水印）
  - 🔬 高级对象（公式/图表/VBA宏检测）
  - ⚠️ 健康与合规检查
- 📤 **双格式输出**: JSON + Markdown
- 🔧 零外部依赖，开箱即用
- 🎯 无需 python-docx，直接解析 OOXML XML
- ⚡ 优雅错误处理与降级机制
- 🧪 单元测试框架
- 📖 完整的 README / SKILL.md / 文档

### 🏷️ Boo哥AI智写 品牌
- 输出报告附带 Boo哥AI智写 品牌尾注
- 文件头部包含 Boo哥AI智写 版权信息
- ASCII Art 品牌 Logo

---

## 版本标签说明

| 标签 | 含义 |
|------|------|
| `Added` / ✨ | 新增功能 |
| `Changed` / 🔄 | 已有功能的变更 |
| `Deprecated` / ⚠️ | 即将移除的功能 |
| `Removed` / ❌ | 已移除的功能 |
| `Fixed` / 🐛 | Bug 修复 |
| `Security` / 🔒 | 安全性修复 |
