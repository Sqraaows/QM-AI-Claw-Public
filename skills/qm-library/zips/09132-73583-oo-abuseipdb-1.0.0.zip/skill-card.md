## Description: <br>
AbuseIPDB lets agents query AbuseIPDB reputation, reports, CIDR block, and blacklist data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Security analysts, developers, and operations teams use this skill to check IP reputation, inspect reported CIDR blocks, retrieve reports, and read AbuseIPDB blacklist data through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Queried IP addresses or CIDR blocks are sent through an OOMOL-connected AbuseIPDB account. <br>
Mitigation: Install and use the skill only when that data flow is acceptable for the user's environment. <br>
Risk: The skill depends on the oo CLI and OOMOL account connection for AbuseIPDB access. <br>
Mitigation: Treat CLI installation and login as manual one-time setup, and review the installer source or vendor documentation before running it. <br>


## Reference(s): <br>
- [AbuseIPDB homepage](https://www.abuseipdb.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-abuseipdb) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Queries may send IP addresses or CIDR blocks through an OOMOL-connected AbuseIPDB service.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
