---
name: MarkItDown 文档格式转换工具
slug: markitdown-wrap
description: MarkItDown 文档格式转换工具 — 将 Word（.docx）、PDF、HTML、Excel 等多种格式文档一键转换为 Markdown 的工具。基于微软开源 markitdown 项目封装，支持批量转换和自定义转换规则。保留原文档格式、表格、图片引用等关键信息。适用于需要统一文档格式的技术写作者、内容运营者、文档工程师等场景，大幅提升文档处理效率。 | 来源：https://github.com/q15004040209-creator/markitdown-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/markitdown-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
