## Description: <br>
Leiga helps an agent search and read Leiga projects, issues, and issue schemas through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to retrieve Leiga project and issue data through the oo CLI after the user has connected Leiga to OOMOL. It is intended for read-focused project discovery, issue lookup, issue listing, and schema inspection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Leiga account through OOMOL and can expose project and issue data to the agent. <br>
Mitigation: Install and use it only when the user is comfortable allowing read access to Leiga data through the OOMOL connector. <br>
Risk: First-time setup may require running a remote oo CLI installer if the CLI is missing. <br>
Mitigation: Review OOMOL's installer instructions before running the install command. <br>
Risk: Connector fields and defaults can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing command payloads. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-leiga) <br>
- [Leiga homepage](https://www.leiga.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs agents to fetch the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
