## Description: <br>
Ipregistry helps agents retrieve Ipregistry IP, ASN, and user-agent data through an OOMOL-connected account and the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, security analysts, and data teams use this skill to run Ipregistry lookups for IP addresses, ASNs, and user-agent strings from an agent workflow. It supports single and batch lookup tasks after the user has installed the oo CLI, signed in, and connected Ipregistry. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Ipregistry account and routes lookup data through the oo CLI. <br>
Mitigation: Install and use it only if you trust OOMOL and intend to send the queried IP, ASN, or user-agent data through that connected-account workflow. <br>
Risk: First-time setup can require running the oo CLI installer before authentication and connection. <br>
Mitigation: Review the oo CLI installer before running setup commands, and run setup only when an auth or connection error requires it. <br>
Risk: IP addresses and user-agent strings can be sensitive operational or user data. <br>
Mitigation: Avoid submitting sensitive lookup values unless that use is intended and allowed for the deployment context. <br>


## Reference(s): <br>
- [ClawHub Ipregistry skill page](https://clawhub.ai/oomol/oo-ipregistry) <br>
- [Ipregistry homepage](https://ipregistry.co) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [batch_lookup_asns action reference](actions/batch_lookup_asns.md) <br>
- [batch_lookup_ips action reference](actions/batch_lookup_ips.md) <br>
- [lookup_asn action reference](actions/lookup_asn.md) <br>
- [lookup_ip action reference](actions/lookup_ip.md) <br>
- [parse_user_agents action reference](actions/parse_user_agents.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions run through the OOMOL oo CLI and return JSON with data plus execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
