# Whirlwind Setup Workflow - For ClawdBot

## Overview

This workflow guides ClawdBot through the complete Whirlwind setup process, following the exact steps from the official documentation. ClawdBot walks users through each service setup, collects all environment variables, and ensures everything is properly configured.

**Based on:** Official Whirlwind docs (app/docs/page.js)

**Complete Setup Order:**
1. Getting Started - Clone & install
2. Database Setup - Supabase
3. Authentication - Supabase Auth
4. Payments - Stripe
5. Styles - TailwindCSS/DaisyUI
6. SEO - Metadata & sitemap
7. Deployment - Vercel
8. Emails - Mailchimp event-based journeys
9. Support - Crisp chat widget
10. Analytics - Plausible
11. AI Components - OpenAI

---

## Pre-Setup Conversation

When user says they want to set up Whirlwind:

```
Great! Let's set up Whirlwind for your AI SaaS product.

First, tell me about your project:
1. What's your product name?
2. What does it do? (brief description)
3. What AI features will it have?

This helps me customize the setup for you.
```

**Collect:**
- `productName`
- `productDescription`
- `aiFeatures` (list)

---

## Step 1: Getting Started

```
📦 **STEP 1: GETTING STARTED**

First, let's clone Whirlwind and get it running locally.

Run these commands in your terminal:
```

**Commands to provide:**
```bash
git clone https://github.com/WhirlwindAI/whirlwind.git [YOUR_APP_NAME]
cd [YOUR_APP_NAME]
git checkout main
npm install
git remote remove origin
```

```
Now let's set up your environment variables:

1. Rename .env.example to .env.local:
```

```bash
mv .env.example .env.local
```

```
2. You'll need these environment variables (we'll fill them in as we go):
```

```bash
# Stripe
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=

# Mailchimp
NEXT_PUBLIC_MAILCHIMP_API_KEY=
NEXT_PUBLIC_MAILCHIMP_AUDIENCE_ID=

# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# OpenAI
NEXT_PUBLIC_OPENAI_API_KEY=

# Crisp
NEXT_PUBLIC_CRISP_ID=

# App Domain
NEXT_PUBLIC_APP_DOMAIN=
```

```
Don't worry - I'll help you get each one! Let's start with Supabase.

Ready to continue? (yes/no)
```

---

## Step 2: Database Setup (Supabase)

```
🗄️ **STEP 2: SUPABASE DATABASE SETUP**

Supabase provides your database and authentication.

### Create Account
1. Go to https://supabase.com
2. Sign up (free tier is perfect to start)
3. Click "New project"
4. Fill in:
   - Project name: {productName}-db
   - Database password: [generate strong password - SAVE THIS]
   - Region: Choose closest to you
5. Click "Create new project" (takes ~2 minutes)

Once created, get your credentials:
1. Go to Project Settings (gear icon) → API
2. Copy:
   - Project URL (looks like: https://xxxxx.supabase.co)
   - anon public key (starts with eyJ...)
   - service_role key (also starts with eyJ... - keep this SECRET!)

📋 Ready to paste these? Give me:
- NEXT_PUBLIC_SUPABASE_URL=
- NEXT_PUBLIC_SUPABASE_ANON_KEY=
- SUPABASE_SERVICE_ROLE_KEY=
```

**After receiving values:**

```
✅ Supabase credentials saved!

Now let's create your database tables.

### Run SQL Migration

1. In Supabase dashboard, go to SQL Editor
2. Click "New query"
3. Paste this ENTIRE script:
```

Provide the exact SQL from the docs:

```sql
-- Supabase App Users Setup
create extension if not exists pgcrypto;

create table if not exists public.users (
  id                 uuid primary key default gen_random_uuid(),
  auth_user_id       uuid not null unique,
  email              text unique,
  name               text,
  avatar_url         text,
  stripe_customer_id text unique,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  constraint email_format check (email is null or position('@' in email) > 1)
);

do $$
begin
  if not exists (
    select 1
    from information_schema.table_constraints
    where constraint_type = 'FOREIGN KEY'
      and table_schema = 'public'
      and table_name = 'users'
      and constraint_name = 'users_auth_user_id_fkey'
  ) then
    alter table public.users
      add constraint users_auth_user_id_fkey
      foreign key (auth_user_id)
      references auth.users(id)
      on delete cascade;
  end if;
end;
$$;

create index if not exists users_email_idx on public.users using btree (email);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists set_users_updated_at on public.users;

create trigger set_users_updated_at
before update on public.users
for each row execute procedure public.set_updated_at();

create or replace function public.handle_auth_user_insert()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (auth_user_id, email, name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'name', null),
    coalesce(new.raw_user_meta_data ->> 'avatar_url', null)
  )
  on conflict (auth_user_id) do update
    set email      = excluded.email,
        name       = excluded.name,
        avatar_url = excluded.avatar_url,
        updated_at = now();
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_auth_user_insert();

create or replace function public.handle_auth_user_update()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.users
     set email      = new.email,
         name       = coalesce(new.raw_user_meta_data ->> 'name', name),
         avatar_url = coalesce(new.raw_user_meta_data ->> 'avatar_url', avatar_url),
         updated_at = now()
   where auth_user_id = new.id;

  if not found then
    insert into public.users (auth_user_id, email, name, avatar_url)
    values (
      new.id,
      new.email,
      coalesce(new.raw_user_meta_data ->> 'name', null),
      coalesce(new.raw_user_meta_data ->> 'avatar_url', null)
    )
    on conflict (auth_user_id) do update
      set email      = excluded.email,
          name       = excluded.name,
          avatar_url = excluded.avatar_url,
          updated_at = now();
  end if;

  return new;
end;
$$;

drop trigger if exists on_auth_user_updated on auth.users;

create trigger on_auth_user_updated
after update on auth.users
for each row execute procedure public.handle_auth_user_update();

alter table public.users enable row level security;

revoke all on table public.users from public, anon, authenticated;

grant select on table public.users to authenticated;
grant update (name, avatar_url) on table public.users to authenticated;

drop policy if exists users_select_self on public.users;
drop policy if exists users_update_self on public.users;
drop policy if exists users_update_profile_only on public.users;

create policy users_select_self
on public.users
for select
using (auth.uid() = auth_user_id);

create policy users_update_self
on public.users
for update
using (auth.uid() = auth_user_id)
with check (auth.uid() = auth_user_id);
```

```
4. Click RUN
5. You should see "Success. No rows returned"

✅ Database tables created!

Let me know when you've run this (type "done")
```

---

## Step 3: Authentication Setup

```
🔐 **STEP 3: AUTHENTICATION SETUP**

Your database is ready! Now let's configure authentication.

In your Supabase dashboard:

1. Go to **Authentication** → **Providers**
2. **Email** should be enabled by default ✓
3. Optional: Enable OAuth providers:
   - Google OAuth
   - GitHub OAuth
   - (Configure if you want social login)

4. Go to **Authentication** → **URL Configuration**
5. Add redirect URLs:
   - For development: http://localhost:3000/auth/callback
   - For production: https://your-domain.com/auth/callback (we'll add this later)

### Test Your Auth
Let's verify everything works:

1. Run your app: npm run dev
2. Open: http://localhost:3000
3. Click "Sign Up"
4. Create an account with your email
5. Check Supabase → Table Editor → public.users
   - You should see your user row appear!

Did it work? (yes/no)
```

**If yes:** ✅ Authentication is working!  
**If no:** Help troubleshoot (check triggers, RLS policies, etc.)

---

## Step 4: Stripe Payments Setup

```
💳 **STEP 4: STRIPE PAYMENTS SETUP**

Now let's set up payments so you can start earning!

### Create Stripe Account
1. Go to https://stripe.com
2. Sign up for an account
3. Complete basic setup
4. **IMPORTANT:** Toggle to "Test mode" (top-right switch)

### Create Your Products

Based on your product ({productName}), let's create pricing plans.

What pricing model do you want?
A) Monthly subscription (recommended for SaaS)
B) One-time payment
C) Both

[Wait for answer, then continue...]

Let's create your first plan:

1. Go to **Products** → **Add product**
2. Fill in:
   - Name: [e.g., "Starter"]
   - Description: [brief description]
   - Pricing: $[amount]/month (or one-time)
3. Click Save
4. **Copy the Price ID** (starts with price_)

Want to create more plans? (yes/no)

[If yes, repeat for each plan]

### Get API Keys

1. Go to **Developers** → **API keys**
2. Copy:
   - Publishable key (starts with pk_test_)
   - Secret key (starts with sk_test_) - click "Reveal"

📋 Give me these:
- NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
- STRIPE_SECRET_KEY=

[Wait for values]

### Setup Webhook (IMPORTANT!)

For local development:

1. Go to **Developers** → **Webhooks**
2. Click "Add endpoint"
3. For now, use: http://localhost:3000/api/webhook/stripe
4. Select these events:
   - checkout.session.completed
   - customer.subscription.updated
   - customer.subscription.deleted
   - invoice.payment_failed
   - invoice.upcoming
5. Click "Add endpoint"
6. Copy the **Signing secret** (starts with whsec_)

📋 Give me:
- STRIPE_WEBHOOK_SECRET=

✅ Stripe configured! We'll update the webhook URL when you deploy.
```

---

## Step 5: Mailchimp Email Setup

```
📧 **STEP 5: MAILCHIMP EMAIL AUTOMATION**

Mailchimp handles automated emails for:
- Purchase confirmations
- Failed payments
- Subscription renewals
- Custom user journeys

### Create Mailchimp Account

1. Go to https://mailchimp.com
2. Sign up (free tier works great)
3. After login, create an **Audience**:
   - Click Audience → Create Audience
   - Fill in your details
   - Click Create

### Get Your Credentials

1. **Audience ID:**
   - Go to Audience → Settings → Audience name and defaults
   - Scroll down to find "Audience ID"
   - Copy it (looks like: a1b2c3d4e5)

2. **API Key:**
   - Click profile icon → Account & billing
   - Go to Extras → API keys
   - Click "Create A Key"
   - Copy the key (includes server prefix like us21)
   - Format: xxxxxxxxxxxxxxxx-us21

📋 Give me:
- NEXT_PUBLIC_MAILCHIMP_API_KEY=
- NEXT_PUBLIC_MAILCHIMP_AUDIENCE_ID=

[After receiving]

✅ Mailchimp connected!

### How It Works

The template automatically:
- Adds customers to Mailchimp when they purchase
- Sends events for: order_completed, payment_failed, renewal_due, etc.
- You create "Journeys" in Mailchimp that trigger on these events

Want me to show you how to create your first Journey? (yes/no)
```

**If yes, guide through creating a "Welcome" journey in Mailchimp**

---

## Step 6: Optional Services

```
⚙️ **STEP 6: OPTIONAL SERVICES**

These enhance your app but aren't required:

### A) Crisp (Customer Support Chat) - Recommended

Want live chat on your site?

If yes:
1. Go to https://crisp.chat
2. Sign up (free tier available)
3. Create a "Website"
4. Go to Settings → Website Settings → Setup Instructions
5. Copy your Website ID

📋 Give me: NEXT_PUBLIC_CRISP_ID=

### B) Plausible (Privacy-Friendly Analytics) - Recommended

Want to track visitors?

If yes:
1. Go to https://plausible.io
2. Sign up
3. Add your site
4. Note your domain

📋 Give me: NEXT_PUBLIC_APP_DOMAIN=

### C) OpenAI (AI Features)

Your {aiFeatures} will need an AI API.

Choose one:
A) Anthropic (Claude) - Best for content, recommended
B) OpenAI (GPT-4) - Popular, fast
C) Both

[Based on choice, guide through:]

For Anthropic:
1. Go to https://console.anthropic.com
2. Create account & add payment method
3. Go to API Keys → Create Key
4. Copy key (starts with sk-ant-)

For OpenAI:
1. Go to https://platform.openai.com
2. Create account & add payment method
3. Go to API keys → Create key
4. Copy key (starts with sk-)

📋 Give me:
- ANTHROPIC_API_KEY= (if using Claude)
- OPENAI_API_KEY= (if using OpenAI)
```

---

## Step 7: Update Configuration Files

```
⚙️ **STEP 7: CONFIGURE YOUR APP**

Now let's customize Whirlwind for {productName}!

I'll update your config files with the information you provided.
```

**ClawdBot updates:**

1. **Create/update .env.local** with all collected variables
2. **Update config.js**:
```javascript
const config = {
  appName: "{productName}",
  appDescription: "{productDescription}",
  domainName: "{NEXT_PUBLIC_APP_DOMAIN}",
  
  stripe: {
    plans: [
      // Use collected Stripe price IDs
    ],
  },
  
  mailgun: {
    fromNoReply: `{productName} <noreply@{domain}>`,
    fromAdmin: `{adminName} at {productName} <{adminEmail}>`,
    supportEmail: "{supportEmail}",
  },
  
  colors: {
    theme: "dark",
    main: "#22d3ee",
  },
};
```

3. **Create config/site.js**:
```javascript
const siteConfig = {
  productName: "{productName}",
  productDescription: "{productDescription}",
  
  hero: {
    title: "{generatedTitle}",
    subtitle: "{generatedSubtitle}",
  },
  
  features: [
    // Based on user's AI features
  ],
};
```

```
✅ Configuration files updated!
```

---

## Step 8: Test Your Setup

```
🧪 **STEP 8: LET'S TEST EVERYTHING**

Time to see it all work together!

1. Make sure npm run dev is running
2. Open http://localhost:3000

Let's test each feature:

### Test 1: Authentication
- Click "Sign Up"
- Create an account
- Check Supabase → public.users table
✅ User should appear

### Test 2: Stripe Checkout
- Go to Pricing page
- Click "Get {productName}"
- Should open Stripe checkout (test mode)
- Use test card: 4242 4242 4242 4242
✅ Payment should complete

### Test 3: Mailchimp
- After purchase, check Mailchimp → Audience
✅ Contact should be added with "order_completed" event

### Test 4: Crisp Chat (if enabled)
- Chat bubble should appear on homepage
✅ Can send test message

Everything working? (yes/no/partially)
```

**Handle any issues before proceeding**

---

## Step 9: Ready for Features!

```
🎉 **CONGRATULATIONS!**

Your {productName} template is fully set up and working!

✅ Authentication (Supabase)
✅ Database with RLS
✅ Payments (Stripe)
✅ Email automation (Mailchimp)
✅ Customer support (Crisp - if enabled)
✅ Analytics (Plausible - if enabled)
✅ AI integration ready

**What you can do now:**

1. Customize your landing page
2. Build your AI features:
   - {aiFeatures[0]}
   - {aiFeatures[1]}
   - {aiFeatures[2]}
3. Deploy to production
4. Start getting users!

**Want me to help you build your first AI feature?**

Which feature should we start with?
1. {aiFeatures[0]}
2. {aiFeatures[1]}
3. {aiFeatures[2]}

Or type the feature name you want to build first.
```

---

## Environment Variables Summary

Complete list ClawdBot collects:

### Required:
```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=

# Mailchimp
NEXT_PUBLIC_MAILCHIMP_API_KEY=
NEXT_PUBLIC_MAILCHIMP_AUDIENCE_ID=

# AI (at least one)
ANTHROPIC_API_KEY=
OPENAI_API_KEY=

# Site
NEXT_PUBLIC_APP_DOMAIN=
NEXT_PUBLIC_SITE_URL=
```

### Optional:
```bash
NEXT_PUBLIC_CRISP_ID=
NEXT_PUBLIC_PLAUSIBLE_DOMAIN=
```

---

## Deployment Workflow (When Ready)

```
🚀 **DEPLOYING TO PRODUCTION**

When you're ready to go live:

### Step 1: Prepare Code
git add .
git commit -m "Ready for deployment"
git push origin main

### Step 2: Deploy on Vercel
1. Go to vercel.com
2. Import your GitHub repo
3. Vercel auto-detects Next.js
4. Add ALL environment variables (same as .env.local)
5. Deploy!

### Step 3: Update Webhook URLs

**Stripe:**
1. Go to Stripe → Developers → Webhooks
2. Add new endpoint: https://your-domain.com/api/webhook/stripe
3. Select same events
4. Copy new webhook secret
5. Update STRIPE_WEBHOOK_SECRET in Vercel

**Supabase:**
1. Go to Authentication → URL Configuration  
2. Add: https://your-domain.com/auth/callback

### Step 4: Test Production
- Sign up with real email
- Try a test payment (still test mode)
- Verify Mailchimp events fire
- Check all features work

### Step 5: Go Live!
- Switch Stripe to Live mode
- Update Stripe keys in Vercel
- Update webhook URL to live webhook
- You're live! 🎉
```

---

## Troubleshooting Guide

### Supabase Issues
```
Problem: User not appearing in public.users table
Solution:
1. Check triggers are created (run SQL again)
2. Verify RLS policies exist
3. Check auth.users table has the user
4. Look for errors in Supabase logs
```

### Stripe Issues
```
Problem: Webhook not receiving events
Solution:
1. Verify webhook URL is correct
2. Check webhook secret matches .env
3. Test with Stripe CLI: stripe listen --forward-to localhost:3000/api/webhook/stripe
4. Check signing secret is updated
```

### Mailchimp Issues
```
Problem: Contacts not appearing
Solution:
1. Verify API key includes server prefix (us21, us19, etc.)
2. Check Audience ID is correct
3. Look at server logs for errors from /api/mc/event
4. Verify DC variable in route.js matches your data center
```

### AI API Issues
```
Problem: AI calls failing
Solution:
1. Verify API key is correct
2. Check billing is set up (OpenAI requires credit)
3. Check rate limits
4. Try with alternative provider
```

---

## Success Criteria

Setup is complete when:
- ✅ User can sign up/login
- ✅ Database row created in public.users
- ✅ Stripe checkout opens and processes test payment
- ✅ Mailchimp contact created after purchase
- ✅ Config files updated with product info
- ✅ All environment variables set
- ✅ npm run dev works without errors
- ✅ Landing page shows product branding

---

## Post-Setup: Building Features

After setup, ClawdBot transitions to feature development:

```
🎯 **TIME TO BUILD YOUR AI FEATURES!**

Your {productName} is set up. Now let's build:

Based on what you told me, you want these features:
- {aiFeatures[0]}
- {aiFeatures[1]}  
- {aiFeatures[2]}

For each feature, I'll create:
1. A React component (UI)
2. An API route (backend logic)
3. Database table (if needed)
4. Wire it into your dashboard

Which feature should we build first?
```

Then ClawdBot uses SKILL.md to build custom features.

