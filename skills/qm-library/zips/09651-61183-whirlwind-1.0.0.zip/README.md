# Whirlwind ClawdBot Skill

This skill teaches ClawdBot how to customize the Whirlwind AI SaaS template for users' specific products.

## Installation

```bash
# Install the skill
clawdbot skills add whirlwind-skill

# Or if you have the folder locally
clawdbot skills add /path/to/whirlwind-skill
```

## Usage

Once installed, you can use the Whirlwind skill in conversations:

### Create a New AI Product

```
You: "Use Whirlwind to create WriteFlow - an AI content generator"

ClawdBot: [Creates complete AI product with custom components, API routes, and database]
```

### Add a Feature

```
You: "Add image generation to my Whirlwind project"

ClawdBot: [Generates image generation component and API route]
```

### Customize Landing Page

```
You: "Update the hero text to focus on developers"

ClawdBot: [Updates config/site.js with developer-focused copy]
```

## What This Skill Does

The Whirlwind skill enables ClawdBot to:

1. **Understand the Template**
   - Knows which files are infrastructure (don't touch)
   - Knows which files to customize (landing page)
   - Knows where to create new files (features/)

2. **Generate Custom Code**
   - Creates React components with proper styling
   - Creates API routes with AIClient integration
   - Creates database migrations with RLS
   - Updates configuration files

3. **Follow Best Practices**
   - Uses the provided AI client
   - Includes error handling
   - Adds proper TypeScript types
   - Follows Next.js 14 patterns
   - Implements Row Level Security

## File Structure

```
whirlwind-skill/
├── SKILL.md                    # Main instructions for ClawdBot
├── skill.json                  # Metadata and configuration
├── examples/                   # Example conversations
│   ├── content-generator.md    # WriteFlow example
│   ├── image-analyzer.md       # VisionAI example
│   └── chatbot.md              # TalkAI example
├── templates/                  # Code templates
│   ├── component.jsx           # React component template
│   ├── api-route.js            # API endpoint template
│   └── migration.sql           # Database migration template
└── README.md                   # This file
```

## Examples

### Content Generator (WriteFlow)

Creates a content generation platform with:
- Component for selecting content type (blog/social/email)
- API route that calls Claude for generation
- Database table for storing content history

See `examples/content-generator.md` for full workflow.

### Image Analyzer (VisionAI)

Creates an image analysis platform with:
- Component for uploading images
- API route for analyzing with AI vision
- Database table for storing analyses

### Chatbot Platform (TalkAI)

Creates a conversational AI platform with:
- Chat interface component
- API route for streaming responses
- Database tables for conversations and messages

## Customization

You can customize this skill by editing:

### SKILL.md
Add more detailed instructions, code patterns, or constraints.

### templates/
Modify the code templates to match your preferred patterns.

### examples/
Add more example conversations for different use cases.

### skill.json
Update metadata, commands, or use cases.

## Requirements

### Whirlwind Template
This skill requires the Whirlwind template with:
- lib/ai-client.js (multi-model AI client)
- lib/supabaseClient.js (database client)
- lib/stripe.js (payment functions)
- Base folder structure (components/features/, app/api/custom/)

### Environment Variables
Users need these environment variables:
```bash
# Database
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=

# Payments
STRIPE_SECRET_KEY=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=

# AI (at least one)
ANTHROPIC_API_KEY=
OPENAI_API_KEY=
```

## Support

- Documentation: https://github.com/WhirlwindAI/whirlwind
- Discord: https://discord.gg/whirlwind
- Email: support@whirlwindai.xyz

## License

Commercial - Part of Whirlwind template package
