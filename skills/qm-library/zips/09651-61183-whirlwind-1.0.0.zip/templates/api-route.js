/**
 * 🤖 CLAWDBOT CREATED
 * [API Route Description]
 */
import { NextResponse } from "next/server";
import AIClient from "@/lib/ai-client";
import { supabase } from "@/lib/supabaseClient";

export async function POST(req) {
  try {
    // Parse request body
    const { input } = await req.json();
    
    // Validate input
    if (!input) {
      return NextResponse.json(
        { error: "Input is required" },
        { status: 400 }
      );
    }

    // Create AI prompt
    const prompt = `Your specific prompt here: ${input}`;

    // Call AI
    const ai = new AIClient('claude');
    const result = await ai.chat([
      { role: "user", content: prompt }
    ]);

    // Optional: Save to database
    const { data: session } = await supabase.auth.getSession();
    if (session?.user) {
      const { error: dbError } = await supabase
        .from('your_table')
        .insert({
          user_id: session.user.id,
          input,
          result,
          created_at: new Date().toISOString()
        });
      
      if (dbError) {
        console.error("Database error:", dbError);
      }
    }

    return NextResponse.json({ 
      success: true,
      result 
    });

  } catch (error) {
    console.error("API error:", error);
    return NextResponse.json(
      { error: error.message || "Processing failed" },
      { status: 500 }
    );
  }
}
