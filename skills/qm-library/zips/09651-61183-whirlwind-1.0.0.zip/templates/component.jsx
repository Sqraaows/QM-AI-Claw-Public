/**
 * 🤖 CLAWDBOT CREATED
 * [Component Description]
 */
"use client";

import { useState } from "react";
import apiClient from "@/lib/api";

export default function ComponentName() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleAction = async () => {
    if (!input) return;
    
    setLoading(true);
    try {
      const response = await apiClient.post("/custom/endpoint", {
        input
      });
      setResult(response.result);
    } catch (error) {
      console.error("Error:", error);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="font-bebas text-4xl uppercase tracking-wide mb-6">
        Component Title
      </h2>
      
      <div className="space-y-4">
        <div>
          <label className="block font-ibm text-sm mb-2">Input Label</label>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full px-4 py-2 border border-gray-200 dark:border-white/10 rounded"
            placeholder="Enter your input..."
          />
        </div>
        
        <button
          onClick={handleAction}
          disabled={loading || !input}
          className="px-6 py-3 bg-primary hover:bg-primary-focus text-black font-bebas text-lg uppercase tracking-wide transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? "Processing..." : "Generate"}
        </button>
      </div>
      
      {result && (
        <div className="mt-6 p-4 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded">
          <h3 className="font-bebas text-xl uppercase mb-2">Result:</h3>
          <div className="font-ibm text-sm whitespace-pre-wrap">{result}</div>
        </div>
      )}
    </div>
  );
}
