-- 🤖 CLAWDBOT CREATED
-- [Table description]

create table if not exists table_name (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.users on delete cascade not null,
  
  -- Your columns here
  input_field text not null,
  result_field text not null,
  
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Indexes for performance
create index table_name_user_id_idx on table_name(user_id);
create index table_name_created_at_idx on table_name(created_at desc);

-- Row Level Security
alter table table_name enable row level security;

-- Policies
create policy "Users can view own records"
  on table_name for select
  using (auth.uid() = user_id);

create policy "Users can insert own records"
  on table_name for insert
  with check (auth.uid() = user_id);

create policy "Users can update own records"
  on table_name for update
  using (auth.uid() = user_id);

create policy "Users can delete own records"
  on table_name for delete
  using (auth.uid() = user_id);
