# Example: Complete Whirlwind Setup with ClawdBot

## Initial User Request

**User:** "I want to set up Whirlwind for my AI content writing tool"

## ClawdBot Response

Great! Let's set up Whirlwind for your AI content writing tool.

First, tell me about your project:
1. What's your product name?
2. What does it do exactly?
3. What AI features will it have?

---

**User:** "It's called WriteFlow. It generates blog posts, social media content, and email copy using AI. The main features are blog post generator, social media post generator, and email copy generator."

---

Perfect! Let me help you set up WriteFlow.

### Required Services Setup

You'll need accounts for these services (don't worry, most have free tiers!):

✅ **Supabase** - Database & User Auth (FREE)
✅ **Stripe** - Payments (FREE for testing)
✅ **Mailchimp** - Email Marketing (FREE tier)
⚡ **Anthropic** - Claude AI (Pay per use, ~$0.003 per request)

Ready to start? Let's begin with Supabase!

---

## Supabase Setup

**ClawdBot:**

📊 **SUPABASE SETUP** (Step 1 of 6)

1. Go to https://supabase.com
2. Click "Start your project"
3. Sign up with GitHub or email
4. Create new project:
   - Name: writeflow-db (or anything you want)
   - Database Password: [generate strong password]
   - Region: Choose closest to you
5. Click "Create new project" (takes ~2 min)

Once created:
1. Go to Project Settings (gear icon) > API
2. Copy "Project URL" (looks like: https://xxxxx.supabase.co)
3. Copy "anon public" key (long string starting with eyJ...)

Ready? Paste them here when you have them!

---

**User:** 
```
URL: https://writeflow.supabase.co
Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSI...
```

---

**ClawdBot:**

✅ Got it! Supabase configured.

Now let's set up authentication:
1. In Supabase dashboard, go to **Authentication** > **Providers**
2. Make sure **Email** is enabled (should be by default)
3. Go to **Authentication** > **URL Configuration**
4. Under "Redirect URLs", add: `http://localhost:3000/auth/callback`

Done? Just reply "done" and we'll move to Stripe!

---

**User:** "done"

---

## Stripe Setup

**ClawdBot:**

💳 **STRIPE SETUP** (Step 2 of 6)

Stripe handles your payments and subscriptions.

1. Go to https://stripe.com and sign up
2. Complete account setup
3. **IMPORTANT:** Toggle to "Test mode" (switch in top-right)

Now create your pricing plans:

**For WriteFlow, I suggest:**
- **Starter Plan:** $29/month - 100 AI generations
- **Pro Plan:** $79/month - Unlimited generations

Let's create these:

1. Go to **Products** > **Add product**
2. Create "Starter" plan:
   - Name: Starter
   - Pricing: $29/month (recurring)
   - Click Save
   - **Copy the Price ID** (starts with `price_`)
3. Create "Pro" plan:
   - Name: Pro
   - Pricing: $79/month (recurring)
   - Click Save
   - **Copy the Price ID**

Then get your API keys:
1. Go to **Developers** > **API keys**
2. Copy **Publishable key** (starts with `pk_test_`)
3. Copy **Secret key** (starts with `sk_test_`)
4. Reveal and copy it

Finally, webhooks:
1. Go to **Developers** > **Webhooks**
2. Click "Add endpoint"
3. Endpoint URL: `http://localhost:3000/api/webhook/stripe`
4. Select these events:
   - checkout.session.completed
   - customer.subscription.updated
   - customer.subscription.deleted
5. Click "Add endpoint"
6. Copy the **Signing secret** (starts with `whsec_`)

Ready to paste all of these?

---

**User:**
```
Publishable: pk_test_51ABC123...
Secret: sk_test_51ABC123...
Webhook Secret: whsec_ABC123...
Starter Price ID: price_1ABC123...
Pro Price ID: price_1XYZ789...
```

---

**ClawdBot:**

✅ Perfect! Stripe is configured.

Quick question about pricing:
- Starter plan: $29/month ✓
- Pro plan: $79/month ✓

Do you want to display "crossed out" original prices? (like ~~$49~~ $29)
If yes, what were the original prices?

---

**User:** "Yes, show $39 crossed out for Starter and $99 for Pro"

---

## Mailchimp Setup

**ClawdBot:**

📧 **MAILCHIMP SETUP** (Step 3 of 6)

Mailchimp handles email marketing and can recover abandoned carts.

1. Go to https://mailchimp.com
2. Sign up (free tier is fine)
3. Create your first audience:
   - Click **Audience** > **Create Audience**
   - Enter your company details
4. Get your Audience ID:
   - Go to **Audience** > **Settings** > **Audience name and defaults**
   - Copy the **Audience ID**

5. Get your API key:
   - Click your profile icon (bottom left)
   - **Account & billing** > **Extras** > **API keys**
   - Click "Create A Key"
   - Copy the key (will look like: 1234567890abcdef1234567890abcdef-us12)

The "us12" part at the end is important - that's your server prefix!

Paste when ready:

---

**User:**
```
Audience ID: a1b2c3d4e5
API Key: 1234567890abcdef1234567890abcdef-us19
```

---

**ClawdBot:**

✅ Mailchimp configured!

---

## AI Provider Setup

**ClawdBot:**

🤖 **AI PROVIDER SETUP** (Step 4 of 6)

For WriteFlow's content generation, you need an AI provider.

**Recommended: Anthropic (Claude)**
- Best for long-form content
- Great at understanding context
- Cost: ~$0.003 per blog post

**Alternative: OpenAI (GPT-4)**
- Also excellent for content
- Faster responses
- Cost: ~$0.01 per blog post

Which would you like to use? (or both?)

---

**User:** "Let's use Claude"

---

**ClawdBot:**

Perfect choice! Claude is excellent for content writing.

**Setting up Anthropic (Claude):**

1. Go to https://console.anthropic.com
2. Sign up for an account
3. Add a payment method (required, but you're only charged for usage)
4. Go to **API Keys**
5. Click "Create Key"
6. Name it "WriteFlow"
7. Copy the key (starts with `sk-ant-`)

⚠️ **Important:** This key is shown only once - save it securely!

Paste it when ready:

---

**User:** `sk-ant-api03-ABC123XYZ789...`

---

## Additional Configuration

**ClawdBot:**

⚙️ **FINAL CONFIGURATION** (Step 5 of 6)

Just a few more details:

1. **Your domain name** (for production):
   - Example: writeflow.ai (no https://, no www)
   - Leave as localhost for now if you don't have one yet

2. **Support email:**
   - Example: support@writeflow.ai
   - This is where users can contact you

3. **Your name/company name** (for emails):
   - Example: "WriteFlow Team" or "John at WriteFlow"

What are these for WriteFlow?

---

**User:**
```
Domain: writeflow.ai (but I don't have it set up yet)
Support email: hello@writeflow.ai
Name: Sarah at WriteFlow
```

---

**ClawdBot:**

✅ Perfect!

**Optional services** - Do you want any of these?

1. **Crisp** (Live chat widget) - FREE
   - Adds a chat bubble on your site
   
2. **Resend** (Better transactional emails) - FREE tier
   - For password resets, welcome emails, etc.

Want to set these up? (yes/no)

---

**User:** "not right now"

---

## File Generation

**ClawdBot:**

🎉 **GENERATING YOUR CONFIGURATION** (Step 6 of 6)

Creating your WriteFlow configuration files...

✅ Created `.env` with all your API keys
✅ Updated `config.js` with WriteFlow branding
✅ Created `config/site.js` with your features:
   - 📝 Blog Post Generator
   - 📱 Social Media Generator  
   - 📧 Email Copy Generator
✅ Updated Stripe pricing plans

Now let's set up your database:

**Run this SQL in Supabase:**

1. Open your Supabase dashboard
2. Go to **SQL Editor**
3. Create new query
4. Paste this:

```sql
-- WriteFlow database tables

-- User profiles
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  full_name text,
  avatar_url text,
  created_at timestamptz default now()
);

-- Subscriptions
create table subscriptions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan_id text,
  status text,
  created_at timestamptz default now()
);

-- Generated content (we'll add more columns for your features)
create table generated_content (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade,
  content_type text,
  prompt text,
  result text,
  created_at timestamptz default now()
);

-- Row Level Security
alter table profiles enable row level security;
alter table subscriptions enable row level security;
alter table generated_content enable row level security;

-- Policies
create policy "Users can view own profile"
  on profiles for select using (auth.uid() = id);

create policy "Users can view own subscriptions"
  on subscriptions for select using (auth.uid() = user_id);

create policy "Users can view own content"
  on generated_content for select using (auth.uid() = user_id);

create policy "Users can insert own content"
  on generated_content for insert with check (auth.uid() = user_id);
```

Click "RUN" and let me know when it's done!

---

**User:** "done"

---

## Installation & Testing

**ClawdBot:**

📦 **INSTALLING DEPENDENCIES**

Running: `npm install`

⏳ Installing all packages... (this takes 2-3 minutes)

✅ Installed successfully!

---

🚀 **READY TO LAUNCH!**

Let's test WriteFlow:

```bash
npm run dev
```

Then open: http://localhost:3000

You should see:
✅ WriteFlow landing page
✅ "Sign In" button (try creating an account!)
✅ Pricing page with your $29 and $79 plans
✅ Features showing your three content generators

Try this:
1. Click "Sign Up"
2. Create an account with your email
3. You should get a confirmation email
4. Log in
5. Go to pricing and try "test" checkout with Stripe

Everything working? 🎉

---

**User:** "Yes! It's working! What's next?"

---

## Next Steps

**ClawdBot:**

🎉 **CONGRATULATIONS!**

WriteFlow is fully set up and running! Here's what you have:

✅ User authentication (Supabase)
✅ Payment processing (Stripe, test mode)
✅ Email marketing (Mailchimp)
✅ AI integration (Claude)
✅ Database with proper security
✅ Landing page with your branding

**Now let's build your AI features!**

Based on your description, you want:
1. 📝 Blog Post Generator
2. 📱 Social Media Generator
3. 📧 Email Copy Generator

Which one should we build first?

---

**User:** "Let's start with the blog post generator"

---

**ClawdBot:**

Perfect! Let's build your Blog Post Generator.

I'll create:
1. A component where users input their topic
2. An API route that calls Claude to generate the blog post
3. A database table to save generated posts
4. Add it to your dashboard

Ready? This will take about 2 minutes...

[ClawdBot proceeds to generate the feature...]

---

## Summary

This walkthrough showed:
- Complete account setup for all services
- Step-by-step guidance with clear instructions
- Collection of all environment variables
- Configuration file generation
- Database setup
- Testing verification
- Smooth transition to feature development

Total time: ~30-45 minutes
