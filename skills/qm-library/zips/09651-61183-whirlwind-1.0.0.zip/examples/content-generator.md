# Example: Creating WriteFlow - AI Content Generator

## User Request

"Create WriteFlow - an AI content generator for blog posts, social media, and email copy"

## ClawdBot Response

I'll create WriteFlow, an AI-powered content generation platform. Let me set this up for you.

### Step 1: Creating product configuration

Created `config/site.js`:
- Product name: WriteFlow
- Hero: "Generate Professional Content in Seconds"
- Features: Blog Posts, Social Media, Email Copy

### Step 2: Creating content generator component

Created `components/features/ContentGenerator.jsx`:
- Content type selector (blog/social/email)
- Topic input
- Tone selector (professional/casual/friendly)
- Generate button
- Output display

### Step 3: Creating API endpoint

Created `app/api/custom/generate-content/route.js`:
- Accepts contentType, topic, tone
- Creates prompts for each content type
- Uses AIClient with Claude
- Returns generated content
- Optional: Saves to database

### Step 4: Creating database table

Created `lib/supabase/migrations/002_content_items.sql`:
- content_items table
- Stores: user_id, type, topic, tone, content
- Row Level Security enabled
- User-specific policies

### Step 5: Updating dashboard

Updated `app/dashboard/page.js`:
- Imported ContentGenerator component
- Added to dashboard layout

## Result

WriteFlow is ready! You now have:
- ✅ Content generation UI
- ✅ Three content types (blog, social, email)
- ✅ AI-powered generation using Claude
- ✅ Database storage for content history
- ✅ User authentication required

## To Test

```bash
# Install dependencies (if not already)
npm install

# Add API key to .env
echo "ANTHROPIC_API_KEY=your_key_here" >> .env

# Run dev server
npm run dev

# Visit http://localhost:3000/dashboard
# Try generating content!
```

## To Deploy

```bash
# Deploy to Vercel
vercel

# Or deploy to your hosting platform
# Make sure to add environment variables
```

## What Users Can Do

1. Sign up / Sign in
2. Choose content type
3. Enter topic
4. Select tone
5. Generate content
6. View and copy results
7. See history of generated content

## Next Steps

You might want to add:
- Content templates
- Export to formats (PDF, DOCX)
- Content scheduling
- SEO optimization features
- Multi-language support
- Team collaboration

Just ask and I'll add these features!
