## Description: <br>
Operate Kraken.io through an OOMOL-connected account to check plan status and optimize images without handling raw API credentials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Kraken.io from Codex through the OOMOL connector, including checking account quota and optimizing a single image from a public URL or direct upload. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Image optimization may send selected image content to Kraken.io. <br>
Mitigation: Confirm which image files or public URLs will be submitted before running optimize_image, and avoid sending content that should not be shared with Kraken.io. <br>
Risk: The skill requires a connected OOMOL account and Kraken.io credentials. <br>
Mitigation: Use the existing OOMOL connection flow and avoid exposing or manually handling raw Kraken.io API credentials. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-kraken-io) <br>
- [Kraken.io homepage](https://kraken.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before execution; optimized image results are stored in connector transit for downstream workflow use.] <br>

## Skill Version(s): <br>
1.0.0 (source: server-resolved release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
