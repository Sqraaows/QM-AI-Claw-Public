## Description: <br>
TomTom (developer.tomtom.com) supports searching and reading maps and location data through the OOMOL TomTom connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to search TomTom places and addresses, run autocomplete and fuzzy search, geocode addresses, reverse geocode coordinates, and find nearby points of interest through an OOMOL-connected TomTom account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive TomTom credentials through an OOMOL-connected account. <br>
Mitigation: Connect a TomTom API key with only the scopes needed for the intended map and search actions. <br>
Risk: First-time setup may involve running a shell or PowerShell installer pipeline for the oo CLI. <br>
Mitigation: Review the official install guide or installer script before running the installer command. <br>
Risk: Requests are mediated through OOMOL before reaching TomTom. <br>
Mitigation: Install only when OOMOL is an acceptable intermediary for TomTom requests. <br>


## Reference(s): <br>
- [TomTom Developer Portal](https://developer.tomtom.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-tomtom) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before action execution; responses include data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
