## Description: <br>
Eagle Doc helps an agent process finance documents and read Eagle Doc account usage, quota, and request-log data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Eagle Doc through an OOMOL-connected account, including finance OCR for invoices, receipts, and PDFs, plus billing-month usage, quota, and recent request log checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send invoices, receipts, PDFs, usage logs, and billing metadata to Eagle Doc through OOMOL. <br>
Mitigation: Use it only with accounts and documents the user is authorized to process, and avoid sending unnecessary sensitive data. <br>
Risk: OCR and account actions may consume quota, credits, or billing capacity. <br>
Mitigation: Review the live connector schema and intended payload before running finance document processing or repeated usage queries. <br>
Risk: First-time setup includes an oo CLI installer command. <br>
Mitigation: Run the installer only from the official source when the CLI is missing, and do not repeat setup steps after authentication succeeds. <br>


## Reference(s): <br>
- [Eagle Doc API homepage](https://www.eagle-doc.com/en/products/eagle-doc-apis/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Eagle Doc ClawHub release](https://clawhub.ai/oomol/oo-eagle-doc) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects with data and meta.executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
