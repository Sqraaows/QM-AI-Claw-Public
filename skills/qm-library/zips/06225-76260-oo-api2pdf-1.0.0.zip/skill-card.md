## Description: <br>
API2PDF converts raw Markdown to PDF through an OOMOL-connected API2PDF account and returns the generated PDF URL plus conversion metadata. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to convert Markdown content into PDFs through API2PDF without directly handling API credentials. It is suited for workflows that need an externally hosted PDF URL and conversion metadata. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Markdown payloads are processed by OOMOL/API2PDF and may produce externally hosted PDF URLs. <br>
Mitigation: Avoid converting sensitive content unless third-party processing and external hosting are acceptable for the user or organization. <br>
Risk: The skill depends on the local oo CLI for connector execution. <br>
Mitigation: Verify the oo CLI source before first-time setup and keep the OOMOL/API2PDF connection scoped to this service. <br>


## Reference(s): <br>
- [API2PDF homepage](https://www.api2pdf.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-api2pdf) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, Guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces commands for schema inspection and connector execution; the connector response includes generated PDF URL data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
