## Description: <br>
AccuLynx (acculynx.com) support for reading, creating, and updating AccuLynx data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external operators, and developers use this skill to inspect AccuLynx configuration and calendar data, create contacts and Lead milestone jobs, and add or update initial appointments from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Write actions can change AccuLynx contacts, jobs, and appointment records. <br>
Mitigation: Confirm the exact payload and intended effect with the user before creating or updating AccuLynx data. <br>
Risk: The skill requires access to an OOMOL-connected AccuLynx account. <br>
Mitigation: Use an AccuLynx/OOMOL account with the least privileges needed for the workflow and review write requests before approval. <br>
Risk: Connector input and output schemas may change upstream. <br>
Mitigation: Fetch the live action schema before constructing payloads. <br>


## Reference(s): <br>
- [AccuLynx homepage](https://acculynx.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub AccuLynx skill page](https://clawhub.ai/oomol/oo-acculynx) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill relies on live connector schemas and OOMOL-managed AccuLynx credentials.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
