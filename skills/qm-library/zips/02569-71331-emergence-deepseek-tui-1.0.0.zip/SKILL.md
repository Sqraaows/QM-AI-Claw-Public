---
slug: emergence-deepseek-tui
title: 涌现智能编程：DeepSeek TUI 多智能体自主开发助手
description: "使用 DeepSeek TUI CLI 作为自主代码助手 - 两种模式：针对智能体委派的 'exec' 模式（纯文本输入输出），以及针对直接编程的 'run' 模式（全工具调用与文件系统访问）。"
version: 1.0.0
homepage: https://emergence.science/skills/zh/emergence-deepseek-tui
repository: https://gitee.com/bubble-universe/emergence-deepseek-tui
author: Emergence Science
tags: [deepseek-tui, 编程, 代码生成, 多智能体, 委派, 无头LLM, CLI工具]
---

# 涌现 DeepSeek TUI (Emergence DeepSeek TUI)

在您的智能体工作流中使用 **DeepSeek TUI** CLI (v0.8.16) 作为代码助手。本技能教导 OpenClaw / Hermes 智能体如何通过两种模式将编程任务委派给 DeepSeek。

---

## 版本信息

```
deepseek (npm 封装) v0.8.16
二进制版本: v0.8.16
代码仓库: https://github.com/Hmbown/DeepSeek-TUI.git
```

安装方式：
- **Homebrew:** `brew install hmbown/tap/deepseek-tui`
- **npm:** `npm install -g deepseek-tui`

---

## 两种运行模式

DeepSeek TUI 具有两种本质不同的模式，每种模式具有不同的能力：

| 模式 | 命令 | 文件系统访问 | 工具调用 | 使用场景 |
|------|---------|-------------------|-------------|----------|
| **无头模式 (Headless)** | `deepseek exec <PROMPT>` | ❌ 无 | ❌ 无法执行工具 | 从另一个智能体委派代码生成任务 |
| **交互模式 (Interactive)** | `deepseek run` | ✅ 有 (通过工具) | ✅ 全工具调用 | 直接编程、文件编辑、调试 |

### 模式 1：`deepseek exec` — 无头模式（智能体委派）

`deepseek exec <PROMPT>` 以纯文本输入/输出模式调用 DeepSeek API。模型可能会在 **思维链 (CoT) 输出中生成工具调用语法**（例如 `<function_calls><invoke name="list_files">`），但这些永远不会被实际执行 —— 它们仅作为模型推理文本的一部分显示。没有文件系统访问权限，也没有工具执行能力。

```
┌─────────────────────────────────────┐
│  您的智能体 (Hermes/OpenClaw)       │
│  ┌───────────────────────────────┐  │
│  │ 1. 读取文件 (理解)            │  │
│  │ 2. 构建带有上下文的提示词    │  │
│  │ 3. deepseek exec "<prompt>"   │  │
│  │ 4. 验证输出                  │  │
│  │ 5. 应用更改                  │  │
│  └───────────────────────────────┘  │
└─────────────────────────────────────┘
```

**您必须在提示词中提供所有文件上下文** —— DeepSeek exec 模式对文件系统完全处于“盲视”状态。

### 模式 2：`deepseek run` — 交互模式（直接编程）

`deepseek run` 启动具有实际工具调用能力的完整 TUI：

- `list_files` — 浏览目录
- `read_file` — 读取文件内容
- `write_file` / `edit_file` — 修改文件
- `terminal` / `bash` — 执行 shell 命令
- `grep` / `search` — 搜索代码库
- 以及更多...

在工作区目录中调用时，它可以读取整个项目。适用于您希望 DeepSeek 自主探索、编辑和构建的直接编程会话。

---

## 如何使用（无头 Exec 模式）

### 步骤 1 — 首先理解代码库

在调用 DeepSeek *之前*，先由您自己读取所有相关文件。您需要了解：

- 现有的模式和规范
- 所用组件的接口、类型和签名
- 精确的插入点和文件结构

DeepSeek **exec** 无法看到您的文件系统，因此 **您必须在提示词中提供上下文**。

### 步骤 2 — 构建精简的提示词

不要倾倒整个文件。按以下结构组织您的提示词：

```
[关于项目的一行背景说明]
[正在使用的组件接口]
[现有使用模式的示例]
[编号的修改清单 —— 具体且可操作]
[重要的约束条件]
```

### 步骤 3 — 调用 DeepSeek

```bash
# 选项 A：从文件管道输入
deepseek exec "$(cat /path/to/prompt.txt)" 2>&1

# 选项 B：内联输入（较短的提示词）
deepseek exec "在首页添加一个显示 '点我' 的蓝色按钮。" 2>&1
```

### 步骤 4 — 验证输出

DeepSeek 的无头模式可能会在响应中显示工具调用，**将其作为模拟推理文本** —— 请忽略这些。实际输出是文本内容。需注意以下情况：

| 行为 | 采取行动 |
|----------|--------|
| ✓ 返回正确的代码片段 | 从 markdown 块中提取并应用 |
| ✗ 重构/重写整个文件 | 丢弃，仅提取您需要的片段 |
| ✗ 幻觉出不存在的接口或 API | 根据您自己的代码库上下文进行交叉检查 |
| ✗ 显示 `<function_calls>` 块 | 这些是模拟推理，而非真正的工具执行 |

### 步骤 5 — 自行应用更改

使用针对性的文件编辑工具（如 `patch` 或 `write_file`），仅应用已确认的片段。永远不要盲目信任 exec 模式输出的完整文件内容。

### 步骤 6 — 构建与验证

```bash
cd /path/to/project
npm run build  # 或 npx next build, cargo build 等
```

---

## 如何使用（交互式 Run 模式）

当您希望 DeepSeek 直接探索和编辑文件时：

```bash
cd /path/to/project
deepseek run
```

或者直接传递目标：
```bash
deepseek run "添加一个类似于悬赏页面的 CommandBlock 到技能页面"
```

在此模式下，DeepSeek 拥有完整的工具访问权限，可以自主读取/写入文件、搜索并执行命令。这就是用户发现的“它会读取当前工作区中的所有文件”的模式。

---

## 最佳实践

1. **委派用 `exec`，自主用 `run`** —— 如果您拥有自己的读取文件工具并希望进行严格控制，请使用 exec。如果您希望 DeepSeek 自行探索并解决问题，请使用 run。
2. **在 exec 模式下保持外科手术般的精确** —— 告诉 DeepSeek 精确的行号、锚点注释和导入路径。
3. **通过构建进行验证** —— 在应用 DeepSeek 的输出后，始终进行编译/类型检查。
4. **使用针对性编辑** —— 优先使用 `patch`（查找并替换）而非重写整个文件。
5. **exec 模式下的提示词保持在 10KB 以下** —— 过长的提示词可能会降低输出质量；如有需要，请拆分为多个调用。
6. **exec 模式将工具调用显示为文本** —— 不要被误导。exec 输出中的 `<function_calls>` 块是模拟推理，而非实际执行。

## 真实案例

在一个真实的会话中，DeepSeek exec 生成了代码，为涌现科学 (Emergence Science) 的技能详情页添加了 `CommandBlock` 安装组件：

1. 读取现有的悬赏页面以理解 `CommandBlock` 模式。
2. 读取目标技能页面以找到插入点。
3. 构建提示词，包含：`CommandBlock` 接口、现有使用示例、精确的插入指令。
4. 运行 `deepseek exec` → 获得了确认的导入和 JSX 片段（输出中包含模拟工具调用）。
5. 使用 `patch` 应用更改，使用 `npx next build` 构建 → ✅ 顺利通过。

## 故障排除

| 问题 | 解决方法 |
|---------|-----|
| DeepSeek 返回空值 (exec) | 检查 API key 和网络：`deepseek exec "hello"` |
| 输出显示 `<function_calls>` 块 | 这些是模拟推理，非实际执行 —— 视为文本输出 |
| 输出被截断 | 将任务拆分为更小的提示词 |
| 幻觉出的代码结构 | 对文件路径和现有代码进行更明确的说明 |
| 运行太慢 | DeepSeek V4 很快（每次调用约 2-5 秒）；响应过长可能表明提示词写得不好 |
| 找不到文件（交互模式） | 确保在 `deepseek run` 之前已 `cd` 进入正确的工作区 |
