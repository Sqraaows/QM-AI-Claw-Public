## Description: <br>
SwaggerHub helps an agent search and read SwaggerHub APIs, domains, templates, projects, and API definitions through an OOMOL-connected SwaggerHub account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and API teams use this skill to find SwaggerHub resources and retrieve API, domain, template, project, and version data. It is suited for read/search workflows that need current SwaggerHub definitions in JSON or YAML. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses an OOMOL-connected SwaggerHub account and can expose resources available to that account. <br>
Mitigation: Install only for intended SwaggerHub access and keep the connected API key scoped to the resources the agent may read. <br>
Risk: The oo CLI install and connector authentication steps affect the local agent environment. <br>
Mitigation: Review the CLI install step before running it and only reconnect SwaggerHub when an auth or connection error requires it. <br>
Risk: SwaggerHub connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live action schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-swaggerhub) <br>
- [SwaggerHub homepage](https://swagger.io/tools/swaggerhub/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON or YAML SwaggerHub responses.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read/search connector actions return data with execution metadata; live action schemas should be inspected before payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
