## Description: <br>
The lexoffice skill uses the OOMOL `oo` CLI to read, create, and update Lexoffice data instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, operators, and developers use this skill to inspect Lexoffice schemas and run authenticated Lexoffice connector actions for contacts, articles, vouchers, and profile metadata. It supports both read workflows and confirmed create or update workflows through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update Lexoffice contacts and articles, which changes business records. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create or update actions. <br>
Risk: The skill relies on an authenticated OOMOL-connected Lexoffice account and can access sensitive business data. <br>
Mitigation: Use the skill only in accounts where the user is authorized to access the requested Lexoffice data, and avoid sharing sensitive data unless required for the task. <br>
Risk: Connector schemas can change upstream, which may make stale payload assumptions incorrect. <br>
Mitigation: Inspect the live action schema with `oo connector schema` before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-lexoffice) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>
- [lexoffice homepage](https://office.lexware.de/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, text] <br>
**Output Format:** [Markdown with inline bash commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector command responses are expected as JSON objects with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
