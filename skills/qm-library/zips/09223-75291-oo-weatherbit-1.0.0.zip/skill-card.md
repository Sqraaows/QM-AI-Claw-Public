## Description: <br>
Weatherbit lets agents retrieve current weather observations and daily or hourly forecasts through the OOMOL Weatherbit connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill when an agent needs Weatherbit data, including current weather observations and daily or hourly forecasts for a location. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Weatherbit account and sensitive Weatherbit API credentials. <br>
Mitigation: Install only if the user trusts OOMOL as the connector and CLI provider, and connect only the Weatherbit credentials intended for this skill. <br>
Risk: The oo CLI may need to be installed with shell or PowerShell installer commands before the skill can run. <br>
Mitigation: Use official OOMOL installer sources and review the installer before running it when the CLI is not already available. <br>
Risk: Weatherbit connector schemas and defaults can change upstream. <br>
Mitigation: Fetch the authoritative action schema with oo connector schema before constructing each request payload. <br>


## Reference(s): <br>
- [ClawHub Weatherbit skill](https://clawhub.ai/oomol/oo-weatherbit) <br>
- [Weatherbit homepage](https://www.weatherbit.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_current_weather action reference](actions/get_current_weather.md) <br>
- [get_daily_forecast action reference](actions/get_daily_forecast.md) <br>
- [get_hourly_forecast action reference](actions/get_hourly_forecast.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses use a data object with meta.executionId; the skill directs agents to fetch the live action schema before building request payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and SKILL.md metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
