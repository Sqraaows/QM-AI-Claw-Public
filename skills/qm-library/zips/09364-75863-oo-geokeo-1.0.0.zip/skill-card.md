## Description: <br>
Geokeo helps agents use an OOMOL-connected Geokeo account to run forward and reverse geocoding through the oo CLI connector workflow. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to convert addresses or place queries into geocoding results and convert coordinates into reverse geocoding results through a connected Geokeo account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connecting a Geokeo API key through OOMOL before connector calls can run. <br>
Mitigation: Confirm the user is comfortable with the Geokeo connection and use OOMOL-managed credentials rather than handling raw tokens locally. <br>
Risk: The forward geocode action is documented with a write warning even though the security summary found no hidden or destructive behavior. <br>
Mitigation: Treat the write warning as a documentation issue to review, and ask for confirmation before any future Geokeo action that would create, update, send, post, delete, or remove data. <br>


## Reference(s): <br>
- [Geokeo homepage](https://geokeo.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-geokeo) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses oo CLI connector calls that return JSON responses with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
