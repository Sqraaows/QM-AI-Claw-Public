## Description: <br>
Tripadvisor helps an agent search Tripadvisor locations and retrieve read-only location details and photos through the OOMOL Tripadvisor connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill when an agent needs to search Tripadvisor by text or coordinates and read location details or photos without calling the Tripadvisor API directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: First-time setup may require installing and trusting the OOMOL CLI. <br>
Mitigation: Use the skill only when OOMOL and its CLI are trusted, and review the install path before running first-time setup commands. <br>
Risk: Using the Tripadvisor connector requires connecting a Tripadvisor API key or account credential through OOMOL. <br>
Mitigation: Connect credentials only in the trusted OOMOL account and avoid exposing raw API keys in prompts, shell history, or shared logs. <br>
Risk: Tripadvisor action schemas and connector defaults can change upstream. <br>
Mitigation: Inspect the live connector schema before constructing each payload, as the artifact directs. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-tripadvisor) <br>
- [Tripadvisor developers](https://www.tripadvisor.com/developers) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill guides schema inspection and read-only connector calls; connector responses are returned as JSON data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
