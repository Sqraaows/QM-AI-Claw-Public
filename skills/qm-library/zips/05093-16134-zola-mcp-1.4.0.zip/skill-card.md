## Description: <br>
Provides MCP tools for agents to read and manage Zola wedding planning data, including vendors, budgets, guests, seating, events, RSVPs, registries, gifts, and vendor inquiries. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users managing a Zola wedding account can use this skill to let an agent inspect planning status and perform account actions across vendors, guests, budget, seating, events, RSVPs, registry, gifts, and inquiries. It is intended for credentialed account operation, so users should review changes before execution. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can give an agent broad access to sensitive wedding account data through a long-lived Zola refresh token or cookie. <br>
Mitigation: Treat ZOLA_REFRESH_TOKEN and the usr cookie like passwords, keep them out of chat and logs, and rotate them by signing back into Zola if exposure is suspected. <br>
Risk: The available tools can add, update, remove, invite, budget, seat, vendor, and RSVP data in the user's Zola account. <br>
Mitigation: Require user confirmation before any mutating action and review the intended account, guest, vendor, event, budget, or seating target before execution. <br>
Risk: Security evidence marks the release suspicious because broad activation wording and limited safety warnings can lead to unintended account operations. <br>
Mitigation: Activate the skill only for explicit Zola wedding planning requests and keep fetchproxy or token access scoped to users who intend agent operation of their Zola account. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/chrischall/zola-mcp) <br>
- [npm package](https://www.npmjs.com/package/zola-mcp) <br>
- [fetchproxy extension](https://github.com/chrischall/fetchproxy) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline JSON and shell code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May trigger credentialed MCP tool calls that read or change Zola account data.] <br>

## Skill Version(s): <br>
1.4.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
