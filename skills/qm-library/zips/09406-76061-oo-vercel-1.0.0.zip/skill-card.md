## Description: <br>
Vercel (vercel.com). Use this skill for Vercel requests to read, create, update, and delete Vercel resources through the oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to operate Vercel projects, deployments, domains, environment variables, teams, and webhooks through an OOMOL-connected account. It is suited for Vercel administration tasks that require schema-checked oo CLI commands and JSON payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Write actions can change Vercel state, including projects, domains, environment variables, and webhooks. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create, update, add, verify, or webhook actions. <br>
Risk: Delete actions can remove Vercel data. <br>
Mitigation: Confirm the target and get explicit user approval before running destructive actions such as deleting project environment variables. <br>
Risk: Connector input and output schemas may change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each action payload. <br>
Risk: The skill operates through a connected Vercel account and is flagged as requiring sensitive credentials. <br>
Mitigation: Use the OOMOL-connected account flow, avoid exposing raw tokens, and run authentication or connection setup only after an actual auth or connection error. <br>


## Reference(s): <br>
- [ClawHub Vercel Skill](https://clawhub.ai/oomol/oo-vercel) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Vercel Homepage](https://vercel.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before constructing action payloads; responses are JSON from the oo CLI connector.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
