## Description: <br>
Táve helps agents read Táve studio and contact data through OOMOL's oo CLI using a connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to inspect a connected Táve studio, list contacts, and fetch a contact by official ULID without handling raw API tokens. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected account and can read Táve studio and contact information. <br>
Mitigation: Install and use it only when that read access is acceptable, and keep normal use to the documented read/list actions. <br>
Risk: First-time setup may involve installing or authenticating the oo CLI. <br>
Mitigation: Review the oo CLI installer before running remote install commands and authenticate only when a command fails for missing setup. <br>
Risk: Broader Táve connector operations outside the listed read actions could change or delete data. <br>
Mitigation: Confirm exact payloads and effects with the user before create, update, send, post, delete, or remove operations. <br>


## Reference(s): <br>
- [Táve homepage](https://www.vsco.co/workspace) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-tave) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with JSON-shaped CLI responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands use live connector schemas and return data with meta.executionId when run through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
