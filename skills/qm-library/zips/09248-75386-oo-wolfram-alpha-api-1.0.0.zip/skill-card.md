## Description: <br>
Provides Wolfram|Alpha query validation and answer retrieval through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to ask Wolfram|Alpha questions, retrieve concise or spoken-style answers, and validate whether Wolfram|Alpha can interpret a query. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Wolfram|Alpha queries and API-key access depend on OOMOL as an intermediary. <br>
Mitigation: Install only if you are comfortable connecting Wolfram|Alpha to OOMOL, and review the OOMOL account connection before use. <br>
Risk: First-time setup includes curl or PowerShell installer commands for the OOMOL CLI. <br>
Mitigation: Review the OOMOL CLI installer or use an official installation method before running setup commands. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-wolfram-alpha-api) <br>
- [Wolfram|Alpha API](https://products.wolframalpha.com/api/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON response examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Returns Wolfram|Alpha short answers, spoken-style results, or query validation through OOMOL connector responses.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
