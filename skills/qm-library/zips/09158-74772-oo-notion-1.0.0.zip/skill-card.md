## Description: <br>
Notion (notion.so). Use this skill for Notion requests that read, create, update, move, delete, or search workspace content through the OOMOL oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and workspace users use this skill to let an agent inspect Notion schemas and run Notion read, search, create, update, move, archive, and Markdown content workflows through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Connecting this skill gives the agent Notion read and write capability through the user's OOMOL-connected account. <br>
Mitigation: Use it only with trusted Notion workspaces, inspect live schemas before constructing payloads, and review proposed payloads before approving writes. <br>
Risk: Archive and delete actions can remove or hide Notion content. <br>
Mitigation: Require explicit user confirmation of the target and intended effect before running destructive actions. <br>


## Reference(s): <br>
- [ClawHub Notion skill listing](https://clawhub.ai/oomol/oo-notion) <br>
- [Notion homepage](https://www.notion.so) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration guidance, JSON, Markdown, Text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload or response examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Runs through the oo CLI and requires an OOMOL-connected Notion account; write and destructive actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
