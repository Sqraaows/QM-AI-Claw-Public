## Description: <br>
HeartFlow provides an AI agent capability layer for memory persistence, self-verification, reasoning support, self-healing workflows, search and retrieval, and psychology/emotion analysis. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[mark-heartflow](https://clawhub.ai/user/mark-heartflow) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent operators use HeartFlow to add memory, verification, reasoning, search, and self-improvement behavior to AI assistant workflows. The artifact also includes scripts and configuration for optional local automation, memory tooling, browser-control integration, and synchronization workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Bundled automation may install external tools, enable browser-control tooling, run local or remote memory sync, or mutate repositories. <br>
Mitigation: Review the install, cron, and synchronization scripts before execution; run only the scripts needed for the deployment and keep internal automation disabled unless deliberately enabled. <br>
Risk: Persistent conversation-memory behavior may retain sensitive user or project information. <br>
Mitigation: Configure the memory service deliberately, avoid sending secrets to remote HTTP endpoints, and define retention and deletion practices before use. <br>
Risk: The artifact advertises safety, verification, and self-improvement capabilities that the security review treats as incomplete. <br>
Mitigation: Treat verification output as advisory, validate important claims independently, and scan the full artifact before deployment. <br>


## Reference(s): <br>
- [ClawHub Heartflow release page](https://clawhub.ai/mark-heartflow/heartflow) <br>
- [Being Logic reference](references/being-logic.md) <br>
- [Capability Audit reference](references/capability-audit.md) <br>
- [Memory System Comparison reference](references/memory-system-comparison.md) <br>
- [RL Closed Loop reference](references/rl-closed-loop.md) <br>
- [Structure reference](references/structure.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with JavaScript and Python modules, shell scripts, and JSON configuration files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Includes persistent-memory, automation, verification, and optional external-tool integration behavior; review security guidance before enabling scripts.] <br>

## Skill Version(s): <br>
1.3.5 (source: SKILL.md frontmatter and server release metadata, released 2026-05-27) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
