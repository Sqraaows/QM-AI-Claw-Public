# MoneyPrinterTurbo-Wrap

> AI 一键生成高清短视频 / Generate short videos with one click using AI LLM

[![Star](https://img.shields.io/badge/Star-80%2C000%2B-yellow?style=flat-square)](https://github.com/harry0703/MoneyPrinterTurbo)
[![Python](https://img.shields.io/badge/Python-3.11+-blue?style=flat-square)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)

---

## 🌟 项目简介 / Overview

**MoneyPrinterTurbo-Wrap** 是 [MoneyPrinterTurbo](https://github.com/harry0703/MoneyPrinterTurbo) 的 Python 封装库，提供简洁的 API 接口，让你无需关注底层实现，即可通过 AI 大模型全自动生成高清短视频。

**MoneyPrinterTurbo-Wrap** is a Python wrapper for [MoneyPrinterTurbo](https://github.com/harry0703/MoneyPrinterTurbo). It provides a clean API interface that allows you to generate HD short videos with one click using AI LLMs — without dealing with the underlying implementation details.

### 核心功能 / Core Features

-📝 **AI 文案生成** — 输入主题/关键词，自动生成视频文案 / Auto-generate video scripts from topics or keywords
- 🎬 **全自动合成** — 文案 + 素材 + 字幕 + 背景音乐，一键合成 / Full auto-synthesis: script + footage + subtitles + BGM
- 📐 **多尺寸支持** — 竖屏 9:16 (1080×1920) / 横屏 16:9 (1920×1080) / Portrait & landscape
- 🌍 **中英双语** — 支持中文和英文视频文案 / Chinese and English script support
- 🎙️ **多语音合成** — 多种声音可选，实时试听 / Multiple TTS voices with live preview
- 💬 **字幕渲染** — 可调字体、位置、颜色、大小、描边 / Customizable subtitle styling
- 🎵 **背景音乐** — 随机或指定音乐文件，可调音量 / Random or specified BGM with volume control
- 🖼️ **高清无版权素材** — Pexels 高清素材，支持本地素材 / HD royalty-free footage from Pexels or local files
- 🤖 **多模型接入** — OpenAI / DeepSeek / 智谱 / 千问 / Gemini / Ollama 等 / Multiple LLM providers supported
- ⚡ **批量生成** — 一次生成多个视频，选最满意的一个 / Batch generation for best results

---

##🚀 快速开始 / Quick Start

### 安装 / Installation

```bash
pip install moneyprinterturbo-wrap
```

或从源码安装 / Or install from source:

```bash
git clone https://github.com/q15004040209-creator/moneyprinterturbo-wrap.git
cd moneyprinterturbo-wrap
pip install -e .
```

### 前置依赖 / Prerequisites

```bash
# 配置 LLM API Key（支持 OpenAI/DeepSeek/智谱/千问等）
# Configure your LLM API Key in environment or config
export OPENAI_API_KEY="sk-xxxx"
export OPENAI_API_BASE="https://api.openai.com/v1"
```

### 最低配置要求 / Minimum Requirements

| 配置 | 最低 | 推荐 | 理想 |
|------|------|------|------|
| CPU | 4核 | 6-8核 | 8核+ |
| RAM | 4GB | 8GB | 16GB+ |
| GPU | 非必须 | 4GB+ | 8GB+ |

> [!TIP]
> 如果主要使用云端 LLM、云端 TTS 和在线素材，GPU 非必须；启用 faster-whisper 或批量生成时，GPU 会明显提升速度。

---

## 📖 使用示例 / Usage Examples

### 基础用法 / Basic Usage

```python
from moneyprinterturbo import VideoGenerator

# 初始化生成器（默认使用 OpenAI）
generator = VideoGenerator()

# 一句话生成视频
result = generator.generate(
    subject="人工智能的未来",
    aspect_ratio="9:16",  # 竖屏
)

print(f"视频已生成: {result['video_path']}")
print(f"视频时长: {result['duration']}s")
```

### 自定义文案 / Custom Script

```python
from moneyprinterturbo import VideoGenerator

generator = VideoGenerator()

result = generator.generate(
    subject="科技改变生活",
    script="""从互联网到移动互联网，从大数据到人工智能，
             科技每一次进步都在深刻改变我们的生活方式。
              清晨被智能闹钟唤醒，出行靠导航指引，
              购物用扫码支付——这一切，不过二十年。""",
    voice_name="zh-CN-XiaoxiaoNeural",
    subtitle=True,
    background_music="欢快",
    aspect_ratio="16:9",
)

print(f"视频路径: {result['video_path']}")
```

### 批量生成 / Batch Generation

```python
from moneyprinterturbo import VideoGenerator

generator = VideoGenerator()

results = generator.batch_generate(
    subjects=[
        "运动的重要性",
        "健康饮食指南",
        "睡眠与工作效率",
    ],
    count=2,  # 每个主题生成2个视频
    aspect_ratio="9:16",
)

for i, result in enumerate(results):
    print(f"[{i+1}] {result['subject']} → {result['video_path']}")
```

### 使用指定模型 / Specify LLM Provider

```python
from moneyprinterturbo import VideoGenerator
from moneyprinterturbo.providers import DeepSeekProvider, ZhipuProvider

# 使用 DeepSeek
generator = VideoGenerator(provider=DeepSeekProvider(
    api_key="your-deepseek-api-key",
    model="deepseek-chat",
))

result = generator.generate(subject="量子计算原理")

# 使用智谱 GLM
generator2 = VideoGenerator(provider=ZhipuProvider(
    api_key="your-zhipu-api-key",
    model="glm-4",
))

result2 = generator2.generate(subject="区块链技术入门")
```

### 完整配置示例 / Full Configuration

```python
from moneyprinterturbo import VideoGenerator, VideoConfig

config = VideoConfig(
    # 视频尺寸
    width=1080,
    height=1920,
    
    # 语音设置
    voice_name="zh-CN-XiaoxiaoNeural",
    voice_volume=0.7,
    
    # 字幕设置
    subtitle=True,
    subtitle_font="SimHei",
    subtitle_size=36,
    subtitle_color="white",
    subtitle_position="bottom",
    
    # 背景音乐
    background_music="resource/songs/background.mp3",
    music_volume=0.3,
    
    # 字幕生成方式（edge 快速 / whisper 精确）
    subtitle_provider="edge",
    
    # 视频片段时长（秒）
    video_clip_duration=3,
)

generator = VideoGenerator(config=config)
result = generator.generate(
    subject="如何培养良好的阅读习惯",
    script=None,  # None = AI自动生成文案
)

print(f"✅ 视频完成: {result['video_path']}")
print(f"📊 素材数量: {result['clips_used']} 个片段")
print(f"⏱️ 总时长: {result['duration']} 秒")
```

---

## 🔧 API 参考 / API Reference

### `VideoGenerator`

```python
VideoGenerator(config=None, provider=None)
```

| 参数 | 类型 | 说明 |
|------|------|------|
| `config` | `VideoConfig` | 视频配置对象 |
| `provider` | `LLMProvider` | 大模型提供商 |

### `generator.generate()`

```python
generate(subject, script=None, aspect_ratio="9:16", **kwargs) -> dict
```

| 参数 | 类型 | 说明 |
|------|------|------|
| `subject` | `str` | 视频主题/关键词 |
| `script` | `str\|None` | 自定义文案，None 则 AI 自动生成 |
| `aspect_ratio` | `str` | 视频比例，"9:16" 或 "16:9" |

**返回 / Returns:**

```python
{
    "video_path": "output/视频标题_20240101_120000.mp4",
    "duration": 60,
    "clips_used": 15,
    "subtitle_file": "output/视频标题_20240101_120000.srt",
    "script": "生成的视频文案...",
}
```

### `generator.batch_generate()`

```python
batch_generate(subjects, count=1, aspect_ratio="9:16", **kwargs) -> list[dict]
```

批量生成视频，返回结果列表。

---

##🌐 支持的模型 / Supported Providers

| 提供商 | Provider | 模型 |
|--------|----------|------|
| OpenAI | `OpenAIProvider` | GPT-4o / GPT-4o-mini |
| DeepSeek | `DeepSeekProvider` | deepseek-chat / deepseek-coder |
| 智谱 AI | `ZhipuProvider` | GLM-4 / GLM-4V |
| 通义千问 | `QwenProvider` | qwen-turbo / qwen-max |
| Google Gemini | `GeminiProvider` | gemini-pro / gemini-1.5-flash |
| MiniMax | `MiniMaxProvider` | abab6-chat |
| 文心一言 | `ErnieProvider` | ernie-bot |
| Ollama | `OllamaProvider` | 本地模型 |
| AIHubMix | `AIHubMixProvider` | 700+ 模型聚合 |

---

## 🐳 部署方式 / Deployment

### Docker 部署 / Docker Deployment

```bash
docker pull harry0703/moneyprinterturbo
docker run -d -p 8080:8080 harry0703/moneyprinterturbo
# 访问 http://127.0.0.1:8080/docs 查看 API 文档
```

### 本地部署 / Local Deployment

```bash
git clone https://github.com/harry0703/MoneyPrinterTurbo.git
cd MoneyPrinterTurbo

# 使用 uv（推荐）
uv python install 3.11
uv sync --frozen

# 或使用 pip
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate   # Windows
pip install -r requirements.txt
```

### Web UI 启动 / Start Web UI

```bash
# Windows
.\webui.bat

# Linux/Mac
sh webui.sh
```

然后访问 [http://127.0.0.1:8501](http://127.0.0.1:8501)

---

## 📁 项目结构 / Project Structure

```
MoneyPrinterTurbo/
├── webui/ # Web界面
│   └── Main.py
├── main.py                 # API 入口
├── config.example.toml     # 配置示例
├── resource/
│   ├── fonts/              # 字幕字体
│   └── songs/              # 背景音乐
├── models/                 # Whisper 模型
├── output/                 # 输出目录
└── requirements.txt
```

---

## ⚠️ 注意事项 / Notes

1. **路径要求** — 项目路径不要包含中文、特殊字符或空格 / Avoid Chinese characters, special characters, or spaces in the project path
2. **网络要求** — 确保网络正常，VPN 需要打开全局模式 / Ensure network is available, VPN in global mode if needed
3. **ffmpeg** — 最新版已自动下载 ffmpeg，如遇问题参考 README 原项目 / ffmpeg is auto-downloaded; refer to original project for issues
4. **字幕模型** — whisper模式需要下载约 3GB 模型文件 / whisper mode requires ~3GB model download

---

## 🙏 致谢 / Acknowledgements

- 原始项目 [MoneyPrinterTurbo](https://github.com/harry0703/MoneyPrinterTurbo) by [@harry0703](https://github.com/harry0703)
- [AIHubMix](https://aihubmix.com/) — 模型赞助 / Model sponsorship
- [佐糖](https://picwish.cn/) — 图像处理支持 / Image processing support
- [录咖](https://reccloud.cn/) — 在线体验支持 / Online experience support

---

## 📄 许可证 / License

MIT License — 详见 [LICENSE](LICENSE) 文件 / See [LICENSE](LICENSE) for details.

---

##⭐ 项目数据 / Project Stats

> 本周 +11,388 ⭐，总计 80,235 ⭐  
> 本项目为开源封装，不持有任何原始代码版权，所有代码版权归 [harry0703/MoneyPrinterTurbo](https://github.com/harry0703/MoneyPrinterTurbo) 所有。