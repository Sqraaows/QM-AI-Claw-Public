---
name: MoneyPrinterTurbo AI 短视频生成
slug: moneyprinterturbo-wrap
description: MoneyPrinterTurbo AI 短视频生成工具 — 输入一段文字描述，即可自动生成配图、配音、剪辑于一体的短视频内容。基于开源项目封装，集成多个 AI 模型能力，支持文生图、文生音频、字幕生成等功能。适用于内容创作者、电商卖家、自媒体运营者等群体，可将短视频制作效率提升 10 倍以上。 | 来源：https://github.com/q15004040209-creator/moneyprinterturbo-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/moneyprinterturbo-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
