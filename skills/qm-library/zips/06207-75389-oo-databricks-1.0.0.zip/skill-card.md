## Description: <br>
Databricks connector for reading, creating, updating, and deleting Databricks jobs, runs, clusters, workspace objects, repos, and secrets through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and data platform operators use this skill to manage Databricks jobs, runs, clusters, workspace files, repos, and secrets from an agent session through the OOMOL Databricks connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The connected Databricks account can affect production jobs, secrets, clusters, repos, and workspace resources. <br>
Mitigation: Use least-privilege Databricks credentials and review the target workspace, job, cluster, secret scope, or path before executing write or destructive actions. <br>
Risk: Broad Databricks requests may run connector actions that change or remove workspace state without enough visible guardrails. <br>
Mitigation: Require explicit user confirmation for create, update, delete, cancel, overwrite, import, and permanent-delete actions, including the exact target and payload. <br>


## Reference(s): <br>
- [ClawHub Databricks skill](https://clawhub.ai/oomol/oo-databricks) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Databricks homepage](https://www.databricks.com) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses may include Databricks action names, schema-inspection commands, connector run commands, setup guidance, and safety confirmations for write or destructive operations.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
