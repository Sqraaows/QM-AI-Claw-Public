## Description: <br>
ElevenReader (elevenlabs.io) lets an agent search ElevenLabs voices, inspect models and account information, and convert text to speech through the OOMOL elevenreader connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to operate an OOMOL-connected ElevenReader account from an agent workflow. It supports read-aloud tasks including voice search, model lookup, user subscription lookup, voice lookup, and text-to-speech audio generation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Text submitted for read-aloud workflows is sent to ElevenLabs and generated audio is placed in connector transit storage. <br>
Mitigation: Use the skill only with content acceptable for third-party text-to-speech processing and connector transit storage. <br>
Risk: First-time setup may involve installing the oo CLI with a curl-to-bash command. <br>
Mitigation: Review the installer source or use an official oo CLI package or install guide before running the installer, especially on systems with sensitive data. <br>


## Reference(s): <br>
- [ClawHub ElevenReader Skill](https://clawhub.ai/oomol/oo-elevenreader) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [ElevenReader Homepage](https://elevenlabs.io/text-reader) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects containing data and meta.executionId; read_text uploads generated audio to connector transit storage.] <br>

## Skill Version(s): <br>
1.0.0 (source: SKILL.md frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
