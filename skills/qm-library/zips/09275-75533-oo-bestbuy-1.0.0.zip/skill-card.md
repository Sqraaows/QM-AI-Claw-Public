## Description: <br>
Best Buy (bestbuy.com). Use this skill for Best Buy searching and read-only data retrieval instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to search Best Buy products, categories, stores, and reviews through OOMOL's Best Buy connector. It supports read-only discovery and detail lookups for Best Buy catalog and store data. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a Best Buy API key connected through OOMOL's service. <br>
Mitigation: Install only when the user trusts OOMOL and is comfortable using server-side credentials for Best Buy lookups. <br>
Risk: Connector schemas and available fields can change upstream. <br>
Mitigation: Fetch the live action schema before building each payload. <br>
Risk: Future connector versions could expose write or delete actions. <br>
Mitigation: Review connector schemas before use and require explicit user approval for any action that creates, updates, posts, deletes, or otherwise changes Best Buy state. <br>


## Reference(s): <br>
- [Best Buy homepage](https://www.bestbuy.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-bestbuy) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the oo CLI to return JSON responses from read-only Best Buy connector actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
