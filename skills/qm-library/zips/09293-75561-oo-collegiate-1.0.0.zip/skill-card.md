## Description: <br>
Merriam-Webster Collegiate helps agents look up dictionary entries and spelling suggestions through the OOMOL collegiate connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to retrieve Merriam-Webster Collegiate dictionary entries or spelling suggestions from an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill depends on OOMOL as the connector provider for Merriam-Webster lookups. <br>
Mitigation: Install only when the user is comfortable using OOMOL for this connector, as stated in the security guidance. <br>
Risk: Lookup commands can fail when the oo CLI, account sign-in, Merriam-Webster connection, or billing credits are missing. <br>
Mitigation: Run the documented OOMOL setup or billing steps only after a matching command failure, and do not handle raw Merriam-Webster API tokens directly. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-collegiate) <br>
- [Merriam-Webster Collegiate homepage](https://www.merriam-webster.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses the live connector schema before building lookup payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
