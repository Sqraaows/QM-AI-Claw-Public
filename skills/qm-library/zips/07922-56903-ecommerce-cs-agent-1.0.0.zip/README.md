# 🌸 电商温柔客服智能体

一个基于 LLM 的电商智能客服 Agent，以**温柔亲切**的语气回复客户咨询。

## ✨ 特性

- 🌸 温柔亲切的语气，让客户感受到关怀
- 📦 支持订单查询、物流追踪、退换货、商品咨询等场景
- 🔄 可对接真实电商系统（订单 API、物流 API 等）
- 📚 支持 RAG 知识库扩展（商品详情、FAQ、售后政策）
- 🤖 OpenClaw 原生集成，一键 spawn

## 🚀 快速使用

### 在 OpenClaw 中使用

直接说：「帮我用小暖客服回复一下这个客户」，然后提供客户的咨询内容。

### Spawn 独立客服会话

```python
sessions_spawn(
    task="你现在是【温柔客服小助手】小暖，请接待这位客户。",
    label="ecommerce-cs",
    mode="session",
    runtime="subagent"
)
```

### 发送客户消息

```python
sessions_send(
    sessionKey="<上面返回的 sessionKey>",
    message="客户消息内容"
)
```

## 📋 支持的场景

| 场景 | 示例 |
|------|------|
| 订单查询 | "我的订单到哪了？" |
| 物流延迟 | "快递5天了还没到" |
| 退换货 | "衣服有色差想退货" |
| 商品咨询 | "这款手机有什么颜色？" |
| 支付问题 | "付款失败了怎么办？" |
| 投诉建议 | "你们服务太差了" |

## 🔧 对接真实系统

参考 SKILL.md 中的工具定义，对接你的：
- 订单管理系统
- 物流追踪 API
- 退换货工单系统
- 商品数据库

## 📚 参考项目

- [Dify.ai](https://github.com/langgenius/dify) — 开源 AI Agent 客服平台
- [FastGPT](https://github.com/labring/FastGPT) — 知识库问答系统
- [Botpress](https://github.com/botpress/botpress) — Chatbot Builder
- [LangChain](https://github.com/langchain-ai/langchain) — LLM 应用框架

## 📁 文件结构

```
ecommerce-cs-agent/
├── SKILL.md          # OpenClaw Skill 定义（含 System Prompt + 工具）
├── system-prompt.md  # 独立 System Prompt 文件
└── README.md         # 本文件
```
