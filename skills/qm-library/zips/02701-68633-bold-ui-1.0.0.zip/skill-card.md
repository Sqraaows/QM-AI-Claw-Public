## Description: <br>
Apply professional design templates to any AI coding project, supporting eight design styles and multiple web, mobile, and desktop frameworks. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[wh19981224](https://clawhub.ai/user/wh19981224) <br>

### License/Terms of Use: <br>
MIT <br>


## Use Case: <br>
Developers and engineers use this skill to analyze an application's product context, choose or adapt a visual design direction, and generate UI styling guidance, design tokens, components, icons, or framework-specific implementation code. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can import templates from GitHub and persist them locally for future agent use. <br>
Mitigation: Use template import only with trusted repositories, review imported template files before installation, and prefer project-local templates or bundled offline icons for sensitive work. <br>
Risk: Generated UI changes may alter an application's interaction patterns, accessibility, or brand presentation. <br>
Mitigation: Review proposed file changes, test the updated interface across relevant viewports, and verify accessibility-sensitive choices such as contrast, focus states, and motion. <br>


## Reference(s): <br>
- [Bold UI skill page](https://clawhub.ai/wh19981224/bold-ui) <br>
- [Template registry](templates/index.yaml) <br>
- [Tailwind CSS adapter](adapters/tailwindcss.md) <br>
- [CSS Variables adapter](adapters/css-variables.md) <br>
- [Icon fallback data](data/icon-fallback.json) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Markdown, Code, Shell commands, Configuration] <br>
**Output Format:** [Markdown with inline code blocks and file-edit guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May generate or modify project styling files, design tokens, UI components, icons, and template configuration depending on the detected framework and requested depth.] <br>

## Skill Version(s): <br>
1.0.0 (source: metadata.version and release.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
