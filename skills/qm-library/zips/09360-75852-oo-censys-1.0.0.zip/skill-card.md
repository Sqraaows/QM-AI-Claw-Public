## Description: <br>
Censys helps an agent search and retrieve Censys Global Data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Security analysts, developers, and operators use this skill to inspect Censys hosts, certificates, and web properties through the Censys connector without handling raw API tokens directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses OOMOL as an intermediary for a Censys API connection, which may involve sensitive account credentials. <br>
Mitigation: Install and run it only when the user accepts the OOMOL account connection model, and avoid exposing raw Censys API tokens in prompts, logs, or command payloads. <br>
Risk: The optional first-time setup includes curl-to-bash and PowerShell installer commands. <br>
Mitigation: Review OOMOL's official install instructions and installer contents before running those commands. <br>
Risk: Connector schemas and upstream fields can change. <br>
Mitigation: Fetch the live connector schema before constructing request payloads. <br>


## Reference(s): <br>
- [Censys homepage](https://censys.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-censys) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses include connector data and an executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
