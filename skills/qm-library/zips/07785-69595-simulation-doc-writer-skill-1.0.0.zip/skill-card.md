## Description: <br>
Writes, revises, and reviews Chinese documentation for communication simulation programs, including code-to-paper mappings and MATLAB file/function inventories. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[orbisz](https://clawhub.ai/user/orbisz) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, researchers, and communication engineers use this skill to turn simulation code, papers, configs, plots, logs, and results into Chinese engineering documentation that explains models, parameters, reproducibility steps, and implementation mappings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill includes self-logging and self-modification guidance that goes beyond simulation documentation. <br>
Mitigation: Remove or disable the self-evolution section unless the installing user explicitly wants diary files and proposed changes to the skill definition. <br>
Risk: The artifacts conflict about whether generated documentation should be plain text or Markdown. <br>
Mitigation: Confirm the desired output extension before saving files, and reconcile SKILL.md and README.md so agents receive one output-format rule. <br>
Risk: Generated documentation can be misleading when source code, papers, plots, or runtime details are incomplete. <br>
Mitigation: Keep uncertain implementation details explicitly marked for confirmation and review generated manuals before relying on them for reproduction or delivery. <br>


## Reference(s): <br>
- [Communication simulation document template](references/communication-simulation-doc-template.md) <br>
- [ClawHub skill page](https://clawhub.ai/orbisz/simulation-doc-writer-skill) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Guidance, Files] <br>
**Output Format:** [Chinese simulation documentation, normally plain text per SKILL.md; README.md also describes Markdown output.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include tables, runnable commands, paper-to-code mappings, MATLAB file/function inventories, result descriptions, and verification guidance.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
