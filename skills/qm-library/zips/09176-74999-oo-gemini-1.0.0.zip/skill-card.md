## Description: <br>
Gemini (ai.google.dev). Use this skill for Gemini requests by calling OOMOL's Gemini connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Gemini through an OOMOL-connected account for model listing, content generation, embeddings, token counting, image generation, and Veo video workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Prompts and media-generation requests are sent through OOMOL to Gemini. <br>
Mitigation: Install only when that service path is acceptable for the user's data and review payloads before execution. <br>
Risk: Generation actions may create media, consume credits, or incur provider costs. <br>
Mitigation: Confirm the exact payload and expected effect before running content, image, or video generation actions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-gemini) <br>
- [Gemini API documentation](https://ai.google.dev/gemini-api) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Depending on the selected action, responses may include generated text, speech generation results, embeddings, token counts, image transit URLs, video operation status, or finished video transit URLs.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
