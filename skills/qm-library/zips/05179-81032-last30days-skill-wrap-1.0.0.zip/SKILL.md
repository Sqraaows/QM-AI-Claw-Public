---
name: Last30Days 技能追踪器
slug: last30days-skill-wrap
description: Last30Days 技能追踪器 — 帮助用户记录、复盘每日学习和技能提升情况的个人知识管理工具。通过自动化脚本追踪学习进度，生成可视化报告和趋势图表。支持与主流笔记工具（Notion、Obsidian、Logseq 等）同步数据。适用于终身学习者、知识工作者、学生等群体，帮助养成每日复盘的好习惯，提升学习效率 30% 以上。 | 来源：https://github.com/q15004040209-creator/last30days-skill-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/last30days-skill-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
