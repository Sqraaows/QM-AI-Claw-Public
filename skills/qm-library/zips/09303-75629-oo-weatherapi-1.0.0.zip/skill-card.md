## Description: <br>
WeatherAPI (weatherapi.com). Use this skill for ANY WeatherAPI request - searching and reading data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to query WeatherAPI through an OOMOL-connected account for location search, current weather, forecasts, timezone data, and astronomy information. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires trust in OOMOL and the oo CLI with a WeatherAPI-connected account. <br>
Mitigation: Confirm the publisher and CLI are trusted before installation or use, and run install or login steps only when needed. <br>
Risk: WeatherAPI queries can disclose location or date information to the connected service. <br>
Mitigation: Review the live connector schema and payload before sending location or date queries. <br>


## Reference(s): <br>
- [WeatherAPI homepage](https://www.weatherapi.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [WeatherAPI skill on ClawHub](https://clawhub.ai/oomol/oo-weatherapi) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs guide an agent to inspect live connector schemas and run read-only WeatherAPI connector actions through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
