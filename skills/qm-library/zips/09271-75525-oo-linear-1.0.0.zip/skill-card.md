## Description: <br>
Linear lets an agent operate Linear through an OOMOL-connected account to read, create, update, and delete issues, comments, projects, labels, cycles, teams, users, attachments, reactions, and relations. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and product teams use this skill to let an agent inspect and manage Linear work items, projects, comments, labels, cycles, teams, users, and related workflow data through approved OOMOL connector actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and change Linear data using the connected account. <br>
Mitigation: Review exact payloads before approving writes and connect only the Linear scopes you are willing for the agent to use. <br>
Risk: Delete, remove, and raw GraphQL mutation actions can make destructive or broad changes. <br>
Mitigation: Require explicit user approval for destructive targets and carefully inspect raw GraphQL mutations before execution. <br>
Risk: Access depends on OOMOL-connected Linear credentials. <br>
Mitigation: Use least-privilege Linear access and reconnect only when the existing connection is missing, expired, or lacks a required scope. <br>


## Reference(s): <br>
- [ClawHub Linear skill listing](https://clawhub.ai/oomol/oo-linear) <br>
- [Linear homepage](https://linear.app) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Linear connection](https://console.oomol.com/app-connections?provider=linear) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an OOMOL account, and a connected Linear account with appropriate Linear scopes.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
