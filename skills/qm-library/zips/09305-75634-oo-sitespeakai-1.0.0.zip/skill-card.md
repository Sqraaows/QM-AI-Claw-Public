## Description: <br>
SiteSpeakAI helps an agent operate a connected SiteSpeakAI account through the OOMOL oo CLI, including reading chatbot data, querying chatbots, and managing updated answers. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent inspect and administer SiteSpeakAI chatbots through an OOMOL-connected account. It supports chatbot discovery, settings inspection, conversation and lead review, source and prompt listing, chatbot querying, and updated-answer creation, update, or deletion. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected SiteSpeakAI account and read actions may expose conversations, leads, chatbot settings, sources, and account details to the agent session. <br>
Mitigation: Install it only for SiteSpeakAI accounts the agent is allowed to operate, and limit session sharing of returned account, lead, and conversation data. <br>
Risk: Write and delete actions can change or remove SiteSpeakAI updated-answer data. <br>
Mitigation: Review the exact payload, target chatbot, and intended effect before approving writes, and require explicit user approval before destructive delete actions. <br>
Risk: Connector input and output schemas may change upstream. <br>
Mitigation: Fetch the live action schema before constructing payloads and send JSON that matches the current schema. <br>


## Reference(s): <br>
- [SiteSpeakAI homepage](https://sitespeak.ai) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [SiteSpeakAI skill page](https://clawhub.ai/oomol/oo-sitespeakai) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance, Configuration] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON request/response data] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action execution; responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
