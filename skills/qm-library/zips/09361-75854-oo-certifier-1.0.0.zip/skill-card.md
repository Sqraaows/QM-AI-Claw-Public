## Description: <br>
Certifier (certifier.io) helps agents read, create, issue, send, and search Certifier credentials through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Certifier workflows, including listing groups, designs, credentials, credential interactions, searching credential records, and issuing credentials to recipients. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connected Certifier credentials and can act on account data. <br>
Mitigation: Use the least-privileged Certifier credentials available and confirm account scope before sensitive actions. <br>
Risk: Issuing or sending a credential changes Certifier state and can send incorrect recipient or certificate content. <br>
Mitigation: Confirm the recipient, credential content, group, design, and intended effect with the user before running write actions. <br>
Risk: Connector schemas and upstream defaults can change over time. <br>
Mitigation: Inspect the live connector schema before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-certifier) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Certifier homepage](https://certifier.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, JSON, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs agents to inspect the live connector schema before constructing payloads and to confirm write actions before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
