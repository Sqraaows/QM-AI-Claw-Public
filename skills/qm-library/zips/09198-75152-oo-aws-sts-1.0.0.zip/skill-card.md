## Description: <br>
AWS STS helps an agent inspect OOMOL connector schemas and run AWS STS actions through the oo CLI to request temporary credentials from a connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill when an agent needs AWS STS temporary credentials from an OOMOL-connected AWS account, including AssumeRole and federated credential workflows. The agent should inspect the live connector schema before constructing a payload. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can request AWS STS temporary credentials through a connected account. <br>
Mitigation: Install only when OOMOL is trusted, confirm each credential request, and verify the target role, scopes, and session duration before execution. <br>
Risk: CLI installation commands include pipe-to-shell patterns. <br>
Mitigation: Prefer a verified package or inspect the installer before running it. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Fetch the live connector schema before building each action payload. <br>


## Reference(s): <br>
- [AWS STS homepage](https://aws.amazon.com/iam/) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-aws-sts) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [AWS STS connection setup](https://console.oomol.com/app-connections?provider=aws_sts) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands may return AWS STS temporary credentials and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release version and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
