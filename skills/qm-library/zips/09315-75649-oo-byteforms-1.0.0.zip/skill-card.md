## Description: <br>
ByteForms helps an agent search and read ByteForms forms and form responses through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to list ByteForms forms, retrieve a form by ID, and read form responses from an authenticated ByteForms account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: ByteForms form contents and responses can contain sensitive account data. <br>
Mitigation: Run only user-authorized read requests and treat returned form data and responses as sensitive. <br>
Risk: The optional OOMOL CLI installer and connected account access require user trust. <br>
Mitigation: Install the CLI only from a verified source or an already trusted installation path, and connect only the intended ByteForms account. <br>


## Reference(s): <br>
- [ByteForms homepage](https://forms.bytesuite.io/) <br>
- [ClawHub ByteForms skill page](https://clawhub.ai/oomol/oo-byteforms) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, JSON] <br>
**Output Format:** [Markdown instructions with bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before payload construction; outputs may include form data and response records.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
