## Description: <br>
Discover GCP-hosted AI agent and MCP-relevant assets from the operator's environment, emit canonical agent-bom inventory JSON, and optionally scan it without giving agent-bom long-lived GCP credentials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, cloud security teams, and AI platform engineers use this skill to inventory GCP-hosted agent and MCP-relevant assets using operator-approved read-only credentials. It helps produce canonical agent-bom inventory JSON and optional local findings for Vertex AI, Cloud Run, Cloud Functions, GKE, and related GCP infrastructure. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses existing GCP credentials to query project and resource inventory. <br>
Mitigation: Use operator-approved, scoped read-only credentials such as workload identity or a short-lived service account, and avoid credentials that can modify cloud resources. <br>
Risk: Inventory JSON can contain sensitive environment or infrastructure metadata even when credential material is redacted. <br>
Mitigation: Write output only to an operator-selected local path and review the generated JSON before sharing, scanning, or pushing it elsewhere. <br>
Risk: Running discovery against the wrong project could expose unrelated cloud metadata to the local inventory file. <br>
Mitigation: Set or confirm the intended GCP project before execution and limit discovery to operator-approved projects. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/msaad00/agent-bom-discover-gcp) <br>
- [agent-bom Repository](https://github.com/msaad00/agent-bom) <br>
- [agent-bom PyPI Project](https://pypi.org/project/agent-bom/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with shell command examples and JSON inventory or findings outputs.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May write operator-selected inventory JSON and optional local scan findings JSON.] <br>

## Skill Version(s): <br>
0.88.4 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
