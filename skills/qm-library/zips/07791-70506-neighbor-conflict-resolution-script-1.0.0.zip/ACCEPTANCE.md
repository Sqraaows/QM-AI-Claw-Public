# Acceptance Criteria — neighbor-conflict-resolution-script

## Criterion 1: Complete Submission
- [ ] SKILL.md exists in `/Users/jianghaidong/.openclaw/skills/neighbor-conflict-resolution-script/`
- [ ] skill.json exists and is valid JSON
- [ ] ACCEPTANCE.md exists

## Criterion 2: Content Requirements
- [ ] SKILL.md is prompt-only (no external credentials, API calls, or network dependencies)
- [ ] All content is English, zero CJK characters
- [ ] Safety boundaries are clearly defined in SKILL.md
- [ ] skill.json contains all required fields (schema, name, version, displayName, description, categories, license, locale, promptOnly, usage)

## Criterion 3: Functional Correctness
- [ ] Produces a conflict profile from user-provided context
- [ ] Provides progressive scripts at 5 escalation levels with tone/delivery guidance
- [ ] Offers conflict-type specific notes for noise, parking, pets, property lines, and shared spaces
- [ ] Includes a documentation log template
- [ ] Includes a safety check before any script is recommended

## Criterion 4: Safety
- [ ] Never advises confronting a violent or threatening neighbor
- [ ] Redirects to authorities for threats, violence, stalking, or weapons
- [ ] Never endorses vigilante action, retaliation, or property damage
- [ ] Recommends professional survey and legal consultation for property-line disputes
- [ ] Advises contacting fair housing authorities for discrimination-based conflicts
- [ ] Contains disclaimer that it is not a substitute for legal advice or law enforcement

## Criterion 5: Edge Cases
- [ ] Handles apartment conflicts (shared walls, management escalation path)
- [ ] Handles house/adjacent property conflicts (property lines, fence disputes)
- [ ] Handles HOA/condo conflicts (rules, board escalation)
- [ ] When the user has never spoken to the neighbor, starts at Level 1 (friendly)
- [ ] When prior attempts have failed, starts at appropriate higher level

## Verification
- [ ] Run `cat skill.json | python3 -m json.tool` confirms valid JSON
- [ ] No API keys, tokens, or URLs present in any file
- [ ] All 3 files are readable and non-empty
