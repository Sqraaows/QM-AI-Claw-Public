## Description: <br>
OpenGraph.io (opengraph.io) helps an agent retrieve website metadata, raw page HTML, and webpage screenshots through an OOMOL-connected OpenGraph.io account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and content, data, or automation teams use this skill to inspect web pages, extract Open Graph/Twitter/oEmbed metadata, fetch raw HTML, and capture screenshots through OpenGraph.io. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a connected OpenGraph.io service account and may consume paid API credits or access credential-scoped service capabilities. <br>
Mitigation: Install only when the agent should use OpenGraph.io on the user's behalf, prefer scoped API credentials where available, and review user-directed mutation actions before approval. <br>


## Reference(s): <br>
- [OpenGraph.io homepage](https://www.opengraph.io) <br>
- [OpenGraph.io ClawHub skill](https://clawhub.ai/oomol/oo-opengraph-io) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses schema-first action payloads and returns connector data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
