## Description: <br>
PDFMonkey (pdfmonkey.io). Use this skill for reading, creating, and updating PDFMonkey data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to let an agent inspect PDFMonkey schemas, read account documents and templates, and create PDFMonkey documents through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an OOMOL-connected PDFMonkey account, and read/list actions may expose document payloads, templates, and logs. <br>
Mitigation: Install it only when the agent should use that account, and limit use to the intended PDFMonkey workspace and documents. <br>
Risk: The create_document action can change account state and may queue PDF generation. <br>
Mitigation: Confirm the exact document payload and intended effect before allowing creation or queued generation. <br>
Risk: Connector fields and defaults can change upstream. <br>
Mitigation: Inspect the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [PDFMonkey homepage](https://pdfmonkey.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-pdfmonkey) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON connector payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands use the OOMOL oo CLI and should inspect the live connector schema before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
