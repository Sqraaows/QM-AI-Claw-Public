## Description: <br>
Operate Sentry through an OOMOL-connected account to inspect issues, events, alerts, releases, projects, replays, integrations, and Sentry Apps, and to update issue state with user approval. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations engineers use this skill to query Sentry operational data through the oo CLI and coordinate issue triage workflows. It supports read-oriented investigation across organizations, projects, releases, replays, integrations, and issue events, plus approved updates to mutable issue fields. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires OAuth-based access to Sentry operational data, including issues, events, replays, releases, integrations, and Sentry Apps. <br>
Mitigation: Install and use it only when the user is comfortable connecting OOMOL to the intended Sentry account and organization. <br>
Risk: The update_issue action can change Sentry issue state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running any write action. <br>
Risk: Connector action fields and defaults can change upstream. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing the action payload. <br>


## Reference(s): <br>
- [Sentry homepage](https://sentry.io) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-sentry) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, API Calls, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an authenticated OOMOL account connected to Sentry; action schemas should be inspected before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
