## Description: <br>
Quick-reference card for all caveman modes, skills, and commands. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[seanford](https://clawhub.ai/user/seanford) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to display a concise caveman-style reference for available caveman modes, related skills, deactivation phrases, and default-mode configuration. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Broad trigger phrases may activate the skill when the user is only asking about caveman commands. <br>
Mitigation: Use the explicit /caveman-help trigger when possible and return to normal mode with the documented deactivation phrases if the style is not desired. <br>
Risk: Forced caveman-style output can make serious or technical answers less clear. <br>
Mitigation: Use this skill as a quick-reference and novelty style aid; review any technical guidance before relying on it. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/seanford/caveman-help) <br>
- [Full Caveman docs](https://github.com/JuliusBrussee/caveman) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration] <br>
**Output Format:** [Markdown reference card with tables and inline code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [One-shot output; does not persist mode changes, write flag files, or modify files.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
