## Description: <br>
Intercom connector skill for reading, creating, and updating Intercom contacts, conversations, admins, and workspace data through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and support teams use this skill to let an agent work with an already connected Intercom workspace, including contact, conversation, admin, and workspace lookup workflows. It also supports state-changing contact and conversation actions when the user confirms the exact payload and intended effect. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Read, list, and search actions can expose customer, admin, workspace, and conversation data from the connected Intercom workspace. <br>
Mitigation: Install the skill only when agent access to the connected Intercom workspace is intended, and review sensitive outputs before sharing them. <br>
Risk: Write actions can create contacts, update records, reply to users, or close and reopen conversations. <br>
Mitigation: Keep the confirmation requirement enabled and confirm the exact payload and intended effect before any state-changing request. <br>
Risk: Connector schemas, scopes, credentials, or billing state can change between runs. <br>
Mitigation: Inspect the live action schema before constructing payloads and use setup or reconnection steps only after an auth, connection, scope, credential, or billing error. <br>


## Reference(s): <br>
- [ClawHub Intercom release](https://clawhub.ai/oomol/oo-intercom) <br>
- [Intercom homepage](https://www.intercom.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses oo CLI connector commands; action results are JSON responses containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
