## Description: <br>
GroqCloud connector skill for listing models, fetching model metadata, and creating non-streaming OpenAI-compatible chat completions through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to operate GroqCloud through the oo CLI, inspect live connector schemas, list available models, fetch model details, and create chat completions with user-approved payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a trust-relevant one-time OOMOL CLI setup and uses OOMOL as the connector layer for GroqCloud. <br>
Mitigation: Install only when comfortable with OOMOL handling the connection layer, and review the exact setup path before signing in or connecting GroqCloud. <br>
Risk: Chat-completion payloads may consume GroqCloud credits and pass prompts or generated requests through the connected service. <br>
Mitigation: Review the exact chat-completion payload and intended effect with the user before approving create actions. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-groqcloud) <br>
- [GroqCloud Homepage](https://groq.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are requested as JSON and include data plus meta.executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
