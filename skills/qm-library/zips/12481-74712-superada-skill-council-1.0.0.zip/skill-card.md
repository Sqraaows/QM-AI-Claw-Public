## Description: <br>
Topic-aware multi-agent council for structured debate, challenge, and synthesis across engineering, sales, support, product, ops, and strategy topics. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[h-mascot](https://clawhub.ai/user/h-mascot) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and decision-makers use this skill to run quick or full multi-persona councils that stress-test plans, surface tradeoffs, and produce an actionable recommendation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Full councils can use more compute and tool calls because they may run multiple sub-agent sessions. <br>
Mitigation: Use quick council mode for lower-stakes questions and reserve full councils for decisions that need visible debate. <br>
Risk: High-stakes councils may create temporary local checkpoint files and share context across multiple persona prompts. <br>
Mitigation: Avoid highly sensitive topics unless that handling is acceptable, and remove temporary checkpoint files after the run when they are no longer needed. <br>
Risk: Broad trigger phrases can activate council behavior when a simpler answer would be sufficient. <br>
Mitigation: Prefer explicit invocations such as "run council" or "quick council" and skip council mode for trivial factual lookups or simple edits. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/h-mascot/superada-skill-council) <br>
- [README](README.md) <br>
- [Personas](Personas.md) <br>
- [Round Structure](RoundStructure.md) <br>
- [Output Format](OutputFormat.md) <br>
- [Implementation Notes](Implementation.md) <br>
- [Self-Healing for Council](SelfHealing.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown synthesis with structured council rounds, recommendations, tradeoffs, open questions, and next actions.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May use multiple sub-agent contexts and optional temporary checkpoint files for higher-stakes councils.] <br>

## Skill Version(s): <br>
1.0.0 (source: ClawHub release metadata; artifact frontmatter version is 0.1.0) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
