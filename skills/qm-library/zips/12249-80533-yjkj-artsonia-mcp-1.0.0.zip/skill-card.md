## Description: <br>
Access Artsonia student-art portfolios, comments, fans, and notification settings through an MCP-backed assistant workflow. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users with an Artsonia parent or fan account use this skill to view linked student artwork, check portfolio activity, manage comments and fans, and update notification preferences. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Credentialed access can expose student-linked Artsonia information. <br>
Mitigation: Install only for a user's own Artsonia parent or fan account, and require explicit confirmation before viewing student-linked information. <br>
Risk: Account-changing actions can post comments, invite fans, or change notification settings. <br>
Mitigation: Require explicit confirmation before posting comments, inviting fans, or updating notification settings. <br>
Risk: The skill depends on an external MCP package that receives Artsonia credentials. <br>
Mitigation: Review the external artsonia-mcp package before supplying credentials. <br>


## Reference(s): <br>
- [ClawHub Skill Listing](https://clawhub.ai/chrischall/artsonia-mcp) <br>
- [npm Package](https://www.npmjs.com/package/artsonia-mcp) <br>
- [Source Repository](https://github.com/chrischall/artsonia-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with JSON configuration and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires Artsonia account credentials through ARTSONIA_USERNAME and ARTSONIA_PASSWORD.] <br>

## Skill Version(s): <br>
0.4.0 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
