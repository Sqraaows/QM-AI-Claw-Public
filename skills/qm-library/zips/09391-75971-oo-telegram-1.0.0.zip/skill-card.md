## Description: <br>
Helps an agent operate Telegram Bot accounts through OOMOL's Telegram connector and the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and support teams use this skill to inspect and manage Telegram Bot chats, messages, webhooks, commands, media, polls, invite links, and bot-visible membership data from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can post, edit, delete, forward, and send Telegram content or create invite links on behalf of a bot. <br>
Mitigation: Review the exact payload and intended effect with the user before any write action, and require explicit approval before destructive actions such as deleting messages or webhooks. <br>
Risk: The skill requires sensitive Telegram Bot credentials through the connected OOMOL account. <br>
Mitigation: Install only when the OOMOL publisher and Telegram connection are trusted, and keep credential handling inside the connected account rather than exposing raw tokens to the agent. <br>
Risk: Using unverified CLI installation commands can expose the environment to supply-chain risk. <br>
Mitigation: Prefer a verified or package-manager install path for the oo CLI before running connector commands. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-telegram) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Telegram Bot Documentation](https://core.telegram.org/bots) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include Telegram Bot API request payloads, connector command results, and confirmation prompts for state-changing actions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
