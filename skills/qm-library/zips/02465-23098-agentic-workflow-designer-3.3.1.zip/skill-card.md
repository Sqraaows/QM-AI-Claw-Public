## Description: <br>
Designs agentic automation workflows by mapping business processes, assessing automation fit, recommending platforms, and generating workflow specifications with ROI and human-review checkpoints. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[gechengling](https://clawhub.ai/user/gechengling) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Operations managers, developers, product teams, consultants, and entrepreneurs use this skill to evaluate business processes for agentic automation and design practical workflow blueprints for platforms such as n8n, Make, Zapier, LangGraph, or CrewAI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated workflow specifications may affect external systems once implemented in automation tools. <br>
Mitigation: Review each generated workflow, test it in a sandbox, and use least-privilege credentials before deployment. <br>
Risk: Automations involving customer communications, financial decisions, data deletion, or external API actions can create business or compliance impact. <br>
Mitigation: Require human approval for high-impact steps and keep a documented manual fallback or rollback path. <br>


## Reference(s): <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with JSON or YAML workflow specifications] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include ROI tables, platform recommendations, workflow blueprints, and human-in-the-loop checkpoints.] <br>

## Skill Version(s): <br>
3.3.1 (source: server release and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
