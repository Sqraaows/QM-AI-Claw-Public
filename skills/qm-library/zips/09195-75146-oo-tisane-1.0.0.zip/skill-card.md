## Description: <br>
Use this skill for Tisane requests that analyze, transform, compare, detect, or extract text through the OOMOL `tisane` connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Tisane through an OOMOL-connected account for text analysis, language detection, translation or paraphrasing, semantic similarity, entity comparison, supported-language lookup, and plain-text extraction. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may send user-provided text to Tisane through OOMOL and requires a connected Tisane API key. <br>
Mitigation: Use it only when the user is comfortable sharing the text with Tisane through OOMOL, and connect credentials through the documented OOMOL flow. <br>
Risk: First-time setup may suggest a remote OOMOL CLI installer command when the `oo` command is missing. <br>
Mitigation: Review the installer source or use a trusted OOMOL installation method before running the remote installer. <br>


## Reference(s): <br>
- [Tisane homepage](https://tisane.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-tisane) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses `oo connector schema` to inspect action contracts and `oo connector run --json` to return connector results with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
