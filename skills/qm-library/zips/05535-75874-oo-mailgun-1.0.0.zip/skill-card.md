## Description: <br>
Mailgun lets agents operate a connected Mailgun account through OOMOL's oo CLI, including sending email and managing domains, templates, events, and suppressions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and marketing teams use this skill to inspect and manage Mailgun account resources through an already connected OOMOL account. It supports delivery workflows such as sending email, checking domains and events, managing templates, and updating suppressions or tracking settings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires trust in OOMOL's oo CLI and access to a connected Mailgun account. <br>
Mitigation: Install it only when the publisher and CLI are trusted, and connect Mailgun with account permissions appropriate for the intended work. <br>
Risk: Send, create, update, verify, and delete actions can affect real recipients or Mailgun account state. <br>
Mitigation: Review payloads and intended effects before execution, and require explicit user approval for sends, writes, tracking changes, and suppression deletions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-mailgun) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [Mailgun homepage](https://www.mailgun.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence.json release.version and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
