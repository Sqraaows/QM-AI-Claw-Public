# 几何证明视频示例

这是一个完整的 Manim 视频制作示例，演示如何用代码生成带配音的几何教学视频。

## ✨ 核心特性：音频驱动画面同步

本示例实现了**真正的音画同步**：画面会根据每段音频的实际时长自动等待，确保语音播放完成后才进入下一幕。

```
传统方式:              音频驱动方式 (本示例):
预估时长 → 动画        生成音频 → 记录实际时长
   ↓                       ↓
动画播放 (可能不同步)    动画自动等待语音结束
   ↓                       ↓
合并音视频              完美同步的音视频
```

## 📋 文件说明

| 文件 | 说明 |
|------|------|
| `scene.py` | Manim 场景代码（竖屏 9:16，1080x1920） |
| `几何_20260218_四点共圆证明_分镜.md` | 完整分镜脚本 |
| `storyboard.md` | 简化版分镜模板 |
| `generate_edge_tts.py` | 从分镜生成配音音频 |
| `render.sh` | 一键渲染脚本 |
| `audio/` | 生成的音频文件目录 |

## 🚀 快速开始

### 1. 安装依赖

```bash
# 安装 Manim
pip install manim

# 安装 Edge TTS
pip install edge-tts

# 安装 ffmpeg
# macOS:
brew install ffmpeg
# Ubuntu/Debian:
# sudo apt install ffmpeg
```

### 2. 一键渲染

```bash
# 生成音频并渲染视频
./render.sh

# 或跳过音频生成（如果已有音频）
./render.sh --skip-audio
```

### 3. 查看输出

- **视频文件**: `final_video.mp4`
- **音频目录**: `audio/`
- **清单文件**: `audio/audio_manifest.json`

## 📝 音频驱动工作流程

```
1. 编辑分镜脚本 (.md)
      ↓
2. 生成 TTS 音频
   python generate_edge_tts.py 分镜.md ./audio
      ↓
3. 自动记录时长 → audio/timeline.json
   {
     "scenes": [
       {"index": 1, "duration": 11.66, ...},
       {"index": 2, "duration": 17.18, ...}
     ]
   }
      ↓
4. 渲染视频（自动同步）
   scene.py 读取 timeline.json
   → 画面自动等待对应音频时长
      ↓
5. 合并音视频
   ./render.sh → final_video.mp4
```

### 同步机制

在 `scene.py` 中：

```python
def construct(self):
    # 加载音频时长
    AUDIO_TIMINGS = load_audio_timings()  # 从 timeline.json

    # 第一幕
    self.start_scene("opening")  # 开始计时
    # ... 动画代码 ...
    self.wait_for_audio(animation_time=10)  # 自动等待至音频结束

    # 第二幕
    self.start_scene("show_figure")
    # ... 动画代码 ...
    self.wait_for_audio(animation_time=15)
```

渲染时会输出等待信息：
```
▶️  场景: opening (音频时长: 11.66秒)
   ⏱️  动画用时 10.00秒, 等待 1.66秒
```

## 🎨 自定义内容

### 修改分镜

编辑 `storyboard.md` 或创建新的分镜文件：

```markdown
### 第一幕：开场（5秒）

**画面**: 标题淡入
**字幕**: "我的标题"
**读白**: "大家好，今天我们来学习..."
```

### 修改动画

编辑 `scene.py` 中的动画逻辑：

```python
def construct(self):
    # 创建几何图形
    triangle = Polygon(A, B, C)
    self.play(Create(triangle))
```

### 更换语音

```bash
# 使用男声（沉稳）
python generate_edge_tts.py 分镜.md ./audio --voice yunjian

# 可用语音: xiaoxiao, xiaoyi, yunjian, yunxi, yunxia, yunyang
```

## 📐 画面比例

当前配置为 **竖屏 9:16**（1080x1920），适合短视频平台。

如需横屏，修改 `scene.py`：

```python
config.pixel_width = 1920
config.pixel_height = 1080
config.frame_width = 16
config.frame_height = 9
```

## 🔧 故障排除

### 找不到 manim

```bash
pip install manim
# 或
pip3 install manim
```

### 找不到 ffmpeg

```bash
# macOS
brew install ffmpeg

# Linux
sudo apt install ffmpeg
```

### Edge TTS 报错

检查网络连接（Edge TTS 需要联网）

### 音频时长不对

确保先生成音频，再根据实际时长调整动画。使用 `audio/audio_manifest.json` 中的时长数据。

## 📚 参考

- [Manim 文档](https://docs.manim.community/)
- [Edge TTS](https://github.com/rany2/edge-tts)
- LeopohuTutor 技能参考文档
