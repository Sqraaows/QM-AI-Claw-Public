# LeopohuTutor - 数学教学视频制作

一对一辅导老师技能，用于解答数学题，生成 HTML 讲解文档和带配音的 Manim 动画视频。

## 核心工作流

1. **数学分析** → 推导数学事实，建立几何模型
2. **HTML 可视化** → SVG 画图形，展示画图过程
3. **分镜脚本** → 定义幕结构，设计画面/字幕/读白
4. **TTS 音频** → 生成配音文件
5. **验证更新** → 填充音频时长
6. **脚手架** → 生成 Manim 代码框架
7. **实现代码** → 根据分镜实现动画
8. **渲染验证** → 生成最终视频

## 2026-04 新增：系统级布局、清场与跨问继承机制

这一版不再鼓励"每道题手调位置"。脚手架默认提供三类底层能力：

1. **固定安全布局区**
   - `geometry`：几何主图区域（默认左中）
   - `facts`：跨问继承事实区（默认右上）
   - `formula`：公式/提示区域（默认右侧中上）
   - `right_panel`：当右侧信息密度较高时，用单个统一面板替代 facts + formula 双卡片
   - `title`：顶部题目信息区域（可常驻显示题目条件 + 当前小问）
   - `subtitle`：字幕区域（底部）
   - `summary`：结论/总结区域（中间）
   - `assert_layout_safety()`：在 `construct()` 开头校验 `geometry` 与右侧信息区不重叠，避免渲完才发现遮挡

2. **persistent / transient 分层管理**
   - `register_persistent(...)`：登记跨幕保留的底图或核心标注
   - `register_transient(...)`：登记当前幕的临时元素
   - `clear_transients()`：幕末自动清理临时元素；清场时优先回收登记的根对象，只有根对象不在场景里时才兜底回收 family 子元素，并在淡出后强制 `remove(root + family)`，避免面板边框/旧文字残留
   - `reset_scene(clear_persistent=True)`：切题或总结前统一收口

3. **跨问继承 + 角标注预算**
   - `begin_subproblem(...)`：切换到第二问/第三问时，自动清临时层；若当前小问不再沿用上一问的事实板，会主动把旧 fact board 收掉，再准备新的继承事实
   - `set_problem_context(...)`：把题目条件和当前小问常驻在顶部，方便学生暂停时随时回看完整题意
   - `set_fact_board(...)` / `set_grouped_fact_board(...)`：把"上一问结论""当前推导""最终结论"分层收进右侧事实板；板块切换默认走"旧板淡出 + 新板淡入"，不再用整板 morph，避免多层边框叠影
   - `set_named_panel(panel_name, ...)` / `clear_named_panel(...)`：同一槽位里的 `right_panel` / `formula` / 说明卡片跨幕时走显式替换，避免 scene 5、6、7 这种连续推导一层层叠框
   - `purge_zone_residue(...)`：切到总结页或纯净新场景时，按布局区兜底清掉孤儿对象，处理那些已经脱离注册体系的残留文本/边框
   - `reveal_fact_rows(...)`：让事实板条目按讲解节奏一条一条出现，而不是整块替换
   - `create_text_panel(...)` + `reveal_panel_lines(...)`：让公式区支持 keyed line lookup，公式行也能按节奏逐条露出
   - `pulse_fact_with_targets(...)`：让某条事实和图中对应角弧 / 高亮扇形 / callout / 公式行同步做局部聚光
   - `create_angle_annotation(..., mode="auto")`：核心角留图内；超预算后自动降级为 callout 或事实板
   - `CALLOUT_LANE_RATIOS`：同侧多个 callout 自动走不同车道，并用分轨折线降低连线交叉

## 渲染音轨守门（新）

LeopohuTutor 现在不再只靠"渲完之后人工试听"来判断音轨是否正常，而是在渲染流程里直接加入守门机制：

1. **渲染前检查音频素材**
   - 读取 `audio/audio_info.json`
   - 确认每条登记音频都真实存在，且文件时长大于 0

2. **自动判断是否需要禁用缓存**
   - 如果 `audio_list.csv`、`audio/audio_info.json` 或 `audio/` 下的音频文件比当前成片更新
   - `scripts/render.py` 会自动启用 `--disable-caching`

3. **脚手架统一记录音频调度**
   - `add_scene_audio()` 会按时间轴登记每段音频的开始时间、持续时间、结束时间
   - `play_scene()` 会在清场前自动补足音频尾部，避免画面先切走、声音拖到下一幕
   - 渲染过程会输出 `audio/audio_schedule.json`
   - 这样就不只是知道"总共多少秒"，而是知道"最后一段音频应该在时间轴哪里结束"

4. **渲染后校验最终 mp4**
   - 用 `ffprobe` 检查成片中是否真的有 audio stream
   - 优先对照 `audio/audio_schedule.json` 的最后结束时间，检查成片音轨是否覆盖到位
   - 若没有 schedule，再回退到 `audio_info.json` 的总时长校验
   - 用 `ffmpeg volumedetect` 排查"有音轨但其实全静音"的情况

5. **失败自动重试**
   - 如果首轮渲染后的音轨校验失败，渲染脚本会自动再做一次无缓存重渲
   - 只有校验通过，才会报"渲染完成"

这样后续再遇到"视频有了，但只剩第一段有声"这类问题，流水线会自己拦住，而不是靠人耳碰运气。

## 数学读白归一化（TTS）

TTS 现在默认区分"显示文本"和"朗读文本"：

1. `text`
   - 用于画面显示、脚本原文、分镜记录
   - 可以保留标准数学写法，如 `∠AOE`

2. `speak_text`
   - 可选，用于手工指定真正喂给 TTS 的读法
   - 适合处理需要精细控制停顿或发音的句子

3. 自动归一化
   - 如果没有提供 `speak_text`，`scripts/generate_tts.py` 会自动把数学符号转换成更适合中文 TTS 的朗读文本
   - 当前内置规则：`∠AOE` → `角 A、O、E`，`角AOE` → `角 A、O、E`
   - 这样能避免把角名直接连读成模糊发音

推荐原则：**画面保留数学表达，读白交给归一化层处理**。不要为了 TTS 发音去污染画面上的数学显示文本。

## 推荐写法

```python
figure = VGroup(line_ab, rays, labels)
self.place_in_zone(figure, "geometry")
self.register_persistent(figure)
self.add(figure)

self.begin_subproblem(
    "q2",
    clear_transient=False,
)
self.set_grouped_fact_board(
    [
        {"role": "inherit", "items": [{"key": "inherit_eob", "text": "∠EOB = 40°", "color": BLUE}]},
        {"role": "current", "items": [
            {"key": "current_x", "text": "设 ∠AOD = x", "color": RED, "visible": False},
            {"key": "current_foa", "text": "题设：∠FOA = 3x", "color": ORANGE, "visible": False},
        ]},
    ],
    title="第二问事实板"
)

formula = self.create_text_panel(
    [
        {"key": "formula_x", "text": "第二问先设 ∠AOD = x", "color": RED, "visible": False},
        {"key": "formula_foa", "text": "题设再给出：∠FOA = 3x", "color": ORANGE, "visible": False},
    ],
    zone_name="formula"
)
self.register_transient(formula)
self.play(FadeIn(formula))

x_arc = self.create_angle_annotation(refs, theta_od, theta_oa, "x", RED, cluster="q2")
foa_arc = self.create_angle_annotation(refs, theta_of, theta_oa, "3x", ORANGE, cluster="q2")
coe_callout = self.create_angle_annotation(refs, theta_oe, theta_oc, "x-40°", YELLOW, cluster="q2", mode="auto")
self.register_persistent(x_arc, foa_arc)
self.register_transient(coe_callout)
self.add(x_arc, foa_arc, coe_callout)

self.reveal_fact_rows("current_x")
self.reveal_panel_lines(formula, "formula_x")
self.pulse_fact_with_targets("current_x", x_arc, self.get_panel_line(formula, "formula_x"), color=RED)
self.reveal_fact_rows("current_foa")
self.reveal_panel_lines(formula, "formula_foa")
self.pulse_fact_with_targets("current_foa", foa_arc, self.get_panel_line(formula, "formula_foa"), color=ORANGE)
```

## 明确避免的反模式

- 不要再用 `FadeOut(self.mobjects)` 或 `for m in self.mobjects` 这种整场清理方式
- 不要把公式框、字幕、角标直接散落在画布任意位置
- 不要把跨幕底图和临时提示混在同一个清理逻辑里
- 不要在第二问里把第一问得到的全部角关系重新挤回 O 点附近
- 不要把 `120°-x`、`x-40°`、`2x-80°` 这类代数表达长期塞在几何主图中心，优先用事实板或公式区承接
- 不要把继承事实、当前推导、最终结论全混在一个长列表里；多问题型题目优先用分组事实板拆层展示
- 不要让事实板一更新就整块跳变；优先用 `visible=False` + `reveal_fact_rows(...)` 按节奏逐条放出
- 不要让公式区一口气全亮出来；优先给公式行加 key，并用 `reveal_panel_lines(...)` 跟着讲解节奏走
- 不要让事实板和主图彻底脱节；关键结论优先通过 `pulse_fact_with_targets(...)` 建立事实板 / 主图 / 公式区三方对应
- 不要让同侧 callout 直接按出现顺序硬叠，优先走自动避让车道和分轨折线连线

## 使用方式

```bash
# 初始化项目
python init.py [项目目录]

# 生成 TTS 音频（未提供 speak_text 时，会自动把 ∠AOE 这类文本转成更适合朗读的形式）
python scripts/generate_tts.py audio_list.csv ./audio

# 验证音频并更新分镜
python scripts/validate_audio.py 分镜.md ./audio

# 检查代码结构
python scripts/check.py

# 渲染视频（默认带音轨守门）
python scripts/render.py

# 渲染脚本现在会自动：
# 1) 检查 audio/audio_info.json 中登记的音频文件是否真实存在且时长正常
# 2) 在渲染过程中输出 audio/audio_schedule.json，记录每段音频的时间轴
# 3) 在每幕清场前自动补足剩余音频尾部，避免画面比声音先结束
# 4) 若检测到脚本或音频/TTS 输入比当前成片更新，则自动启用无缓存渲染
# 5) 渲染后优先按 audio_schedule.json 校验 mp4 是否真的覆盖到最后一段音频
# 6) 若首轮校验失败，会自动再做一次无缓存重渲

# 如果你想手工强制无缓存，也可以显式指定
python scripts/render.py --disable-caching
```

## 目录说明

- `scripts/` - TTS 生成、音频验证、代码检查、渲染等脚本
- `templates/` - Manim 脚手架模板
- `references/` - 分镜脚本示例
- `sample/` - 早期探索风格示例，仅作参考

## 依赖

- uv
- manim
- edge-tts
- ffmpeg / ffprobe（用于渲染后的音轨校验与静音检测）
