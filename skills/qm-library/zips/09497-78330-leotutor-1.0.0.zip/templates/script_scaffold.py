"""
Math Video Scene Scaffold
数学教学视频场景脚手架（2026-04 跨问继承 / 标注预算增强版）

目标：
1. 把几何图、事实板、公式、标题、字幕放进固定安全区，避免互相压住。
2. 用 persistent / transient 两层管理场景元素，避免跨幕残留。
3. 把“上一问结论”转成可继承的事实板，而不是继续往 O 点附近硬塞文字。
4. 给角标注设置预算：核心角可留在图内，超预算后自动降级为 callout 或事实板。
"""

from manim import *
import json
import os
import subprocess
import numpy as np
from pathlib import Path


class MathScene(Scene):
    """
    数学教学视频场景

    核心原则：
    1. 数学先行：先建立正确的数学模型
    2. 安全布局：几何区 / 事实区 / 公式区 / 标题区 / 字幕区分开
    3. 分层清场：persistent 常驻，transient 幕末自动清理
    4. 跨问继承：上一问结论进入 fact board，不再占用几何主图区
    5. 标注预算：顶点附近只保留少量核心角标签，其余自动降级
    6. 音画同步：动画总时长 >= 音频时长
    """

    # ========== 1. 画布配置 ==========
    config.pixel_width = 1920
    config.pixel_height = 1080
    config.frame_rate = 60

    COLORS = {
        "background": "#1a1a2e",
        "primary": "#4ecca3",
        "secondary": "#e94560",
        "highlight": "#ffc107",
        "text": "#ffffff",
        "text_secondary": "#b8bfd6",
        "panel_fill": "#101626",
        "panel_stroke": "#2d3b5f",
        "fact_title": "#7fb3ff",
        "fact_text": "#dce7ff",
        "fact_dim": "#8f9bb3",
    }

    # 固定安全区：左侧主图，右侧信息区；默认留出明确水平缝隙，避免右侧卡片压到主图。
    LAYOUT_ZONES = {
        "geometry": {"center": LEFT * 2.55 + DOWN * 0.1, "width": 7.7, "height": 5.8},
        "facts": {"center": RIGHT * 3.58 + UP * 1.72, "width": 3.15, "height": 1.95},
        "formula": {"center": RIGHT * 3.58 + DOWN * 0.65, "width": 3.15, "height": 2.15},
        "right_panel": {"center": RIGHT * 3.58 + UP * 0.42, "width": 3.25, "height": 4.95},
        "title": {"center": UP * 3.15, "width": 11.8, "height": 0.9},
        "subtitle": {"center": DOWN * 3.15, "width": 11.8, "height": 0.9},
        "summary": {"center": UP * 0.2, "width": 10.8, "height": 5.5},
    }

    # 必须互不重叠的布局对；right_panel 是 facts/formula 的替代方案，因此只校验其与 geometry 的关系。
    LAYOUT_SAFE_PAIRS = [
        ("geometry", "facts"),
        ("geometry", "formula"),
        ("geometry", "right_panel"),
        ("facts", "formula"),
    ]

    FACT_SECTION_STYLES = {
        "inherit": {"label": "继承上一问", "accent": "#7fb3ff"},
        "current": {"label": "当前推导", "accent": "#ffc107"},
        "conclusion": {"label": "最终结论", "accent": "#61d095"},
        "default": {"label": "要点", "accent": "#dce7ff"},
    }

    # 角标注预算：前两个槽位给图内核心标签；再往后优先变成 callout；超出再进事实板。
    ANGLE_LABEL_SLOTS = [
        {"radius_ratio": 0.18, "label_ratio": 1.55, "font_size": 22, "mode": "inline"},
        {"radius_ratio": 0.28, "label_ratio": 1.32, "font_size": 21, "mode": "inline"},
        {"radius_ratio": 0.42, "label_ratio": 1.00, "font_size": 20, "mode": "callout"},
        {"radius_ratio": 0.56, "label_ratio": 1.00, "font_size": 19, "mode": "callout"},
    ]
    CALLOUT_LANE_RATIOS = [0.78, 0.50, 0.22, -0.06, -0.34, -0.62]

    # 格式：(幕号, 幕名, 音频文件名, 时长秒数)
    SCENES = [
        # 示例：(1, "开场", "audio_001_开场.wav", None),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.audio_dir = Path("audio")
        self.audio_info_file = self.audio_dir / "audio_info.json"
        self.audio_schedule_file = self.audio_dir / "audio_schedule.json"
        self.audio_schedule_entries = []
        if self.audio_schedule_file.exists():
            try:
                self.audio_schedule_file.unlink()
            except OSError:
                pass
        self.audio_timings = self._load_audio_timings()
        self.persistent_mobjects = []
        self.transient_mobjects = []
        self.fact_board = None
        self.fact_row_lookup = {}
        self.current_subproblem = None
        self.annotation_budgets = {}
        self.named_panels = {}

    # ========== 2. 音频 ==========
    def _load_audio_timings(self):
        """从 audio_info.json 加载音频时长，并回填到 SCENES。"""
        timings = {}
        if self.audio_info_file.exists():
            try:
                with open(self.audio_info_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for item in data.get("files", []):
                    scene_num = item.get("scene")
                    duration = item.get("duration")
                    if scene_num and duration:
                        timings[scene_num] = duration
            except Exception as e:
                print(f"Warning: Failed to load audio info: {e}")

        for index, (scene_num, name, audio_file, duration) in enumerate(self.SCENES):
            if scene_num in timings:
                self.SCENES[index] = (scene_num, name, audio_file, timings[scene_num])
        return timings

    def _probe_audio_duration(self, audio_path, scene_num=None, fallback=None):
        """优先使用已知时长；缺失时再探测真实音频时长。"""
        known_duration = self.audio_timings.get(scene_num) if scene_num is not None else None
        for candidate in (known_duration, fallback):
            if isinstance(candidate, (int, float)) and candidate > 0:
                return float(candidate)

        if not audio_path.exists():
            return None

        try:
            result = subprocess.run(
                [
                    "ffprobe",
                    "-v",
                    "error",
                    "-show_entries",
                    "format=duration",
                    "-of",
                    "default=noprint_wrappers=1:nokey=1",
                    str(audio_path),
                ],
                capture_output=True,
                text=True,
                check=True,
            )
            value = float((result.stdout or "").strip())
            if value > 0:
                return value
        except Exception:
            pass

        if audio_path.suffix.lower() == ".wav":
            try:
                import wave
                with wave.open(str(audio_path), "rb") as wav_file:
                    frames = wav_file.getnframes()
                    rate = wav_file.getframerate()
                    if rate > 0:
                        return frames / float(rate)
            except Exception:
                pass

        return None

    def _record_audio_schedule(self, scene_num, scene_name, audio_file, start_time, duration, time_offset=0, gain=None):
        duration = float(duration or 0)
        start_time = float(start_time)
        entry = {
            "scene": scene_num,
            "scene_name": scene_name,
            "file": audio_file,
            "start_time": round(start_time, 3),
            "duration": round(duration, 3),
            "end_time": round(start_time + duration, 3),
            "time_offset": round(float(time_offset or 0), 3),
            "gain": gain,
        }
        self.audio_schedule_entries.append(entry)
        return entry

    def _mark_scene_audio_complete(self, scene_num):
        scene_exit_time = round(float(self.time), 3)
        for entry in reversed(self.audio_schedule_entries):
            if entry.get("scene") != scene_num:
                continue
            if "scene_exit_time" in entry:
                break
            entry["scene_exit_time"] = scene_exit_time
            entry["scene_coverage_ok"] = scene_exit_time + 0.05 >= entry.get("end_time", 0)
            break

    def _ensure_scene_audio_coverage(self, scene_num, cleanup_run_time=0.0, safety_margin=0.05):
        """若当前幕画面将提前退出，则自动补足等待时间，避免音频尾巴被截在下一幕。"""
        for entry in reversed(self.audio_schedule_entries):
            if entry.get("scene") != scene_num:
                continue
            expected_end_time = float(entry.get("end_time", 0) or 0)
            projected_exit_time = float(self.time) + float(cleanup_run_time or 0)
            extra_wait = expected_end_time - projected_exit_time + float(safety_margin or 0)
            if extra_wait > 0.02:
                extra_wait = round(extra_wait, 3)
                entry["auto_tail_wait"] = extra_wait
                self.wait(extra_wait)
            return max(extra_wait, 0) if 'extra_wait' in locals() else 0
        return 0

    def write_audio_schedule(self, finalized=True):
        """把统一音频调度信息写入 audio/audio_schedule.json。"""
        self.audio_schedule_file.parent.mkdir(parents=True, exist_ok=True)
        expected_end_time = max((entry.get("end_time", 0) for entry in self.audio_schedule_entries), default=0)
        payload = {
            "entries": self.audio_schedule_entries,
            "count": len(self.audio_schedule_entries),
            "expected_end_time": round(expected_end_time, 3),
            "finalized": finalized,
        }
        self.audio_schedule_file.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return payload

    def add_scene_audio(self, scene_num, time_offset=0, gain=None):
        """给当前幕添加音频，并记录到统一调度清单。"""
        for sn, scene_name, audio_file, duration in self.SCENES:
            if sn != scene_num:
                continue
            audio_path = self.audio_dir / audio_file
            resolved_duration = self._probe_audio_duration(audio_path, scene_num=scene_num, fallback=duration)
            if audio_path.exists():
                start_time = self.time + float(time_offset or 0)
                self.add_sound(str(audio_path), time_offset=time_offset, gain=gain)
                self._record_audio_schedule(
                    scene_num=sn,
                    scene_name=scene_name,
                    audio_file=audio_file,
                    start_time=start_time,
                    duration=resolved_duration,
                    time_offset=time_offset,
                    gain=gain,
                )
            else:
                print(f"Warning: Audio file not found: {audio_path}")
            return resolved_duration or duration or 0
        return 0

    # ========== 3. 布局 helper ==========
    def get_zone_rect(self, zone_name, padding=0.0):
        """返回某个布局区对应的矩形。"""
        zone = self.LAYOUT_ZONES[zone_name]
        rect = Rectangle(
            width=max(zone["width"] - 2 * padding, 0.1),
            height=max(zone["height"] - 2 * padding, 0.1),
        )
        rect.move_to(zone["center"])
        return rect

    def _zone_overlap_size(self, zone_a, zone_b):
        rect_a = self.get_zone_rect(zone_a)
        rect_b = self.get_zone_rect(zone_b)
        overlap_w = min(rect_a.get_right()[0], rect_b.get_right()[0]) - max(rect_a.get_left()[0], rect_b.get_left()[0])
        overlap_h = min(rect_a.get_top()[1], rect_b.get_top()[1]) - max(rect_a.get_bottom()[1], rect_b.get_bottom()[1])
        return overlap_w, overlap_h

    def assert_layout_safety(self, min_gap=0.01):
        """校验关键布局区是否互相压住；发现重叠时尽早失败，而不是渲完才肉眼发现。"""
        for zone_a, zone_b in self.LAYOUT_SAFE_PAIRS:
            overlap_w, overlap_h = self._zone_overlap_size(zone_a, zone_b)
            if overlap_w > min_gap and overlap_h > min_gap:
                raise AssertionError(
                    f"布局区发生重叠: {zone_a} vs {zone_b} (overlap_w={overlap_w:.2f}, overlap_h={overlap_h:.2f})"
                )

    def place_in_zone(self, mobject, zone_name, padding=0.25, align_edges=None, max_scale=1.0):
        """
        将对象缩放并移动到安全区。

        用法：
        - 几何图整体：place_in_zone(group, "geometry")
        - 事实板：place_in_zone(board, "facts", align_edges=[UP, RIGHT])
        - 公式框：place_in_zone(panel, "formula", align_edges=[UP, RIGHT])
        - 总结页：place_in_zone(group, "summary")
        """
        target = self.get_zone_rect(zone_name, padding=padding)
        width_ratio = target.width / max(mobject.width, 0.01)
        height_ratio = target.height / max(mobject.height, 0.01)
        scale_factor = min(width_ratio, height_ratio, max_scale)
        mobject.scale(scale_factor)
        mobject.move_to(target.get_center())

        if align_edges:
            if not isinstance(align_edges, (list, tuple)):
                align_edges = [align_edges]
            for edge in align_edges:
                mobject.align_to(target, edge)
        return mobject

    def purge_zone_residue(self, *zone_names, padding=0.02):
        purge = []
        seen = set()
        zone_rects = {zone_name: self.get_zone_rect(zone_name, padding=padding) for zone_name in zone_names}
        for mob in list(self.mobjects):
            if id(mob) in seen or not hasattr(mob, "get_center"):
                continue
            center = mob.get_center()
            for rect in zone_rects.values():
                if rect.get_left()[0] <= center[0] <= rect.get_right()[0] and rect.get_bottom()[1] <= center[1] <= rect.get_top()[1]:
                    purge.append(mob)
                    seen.add(id(mob))
                    break
        if purge:
            self.remove(*purge)
        return purge

    def _normalize_panel_lines(self, lines, default_color):
        if isinstance(lines, str):
            lines = [lines]

        normalized = []
        for line in lines or []:
            if isinstance(line, dict):
                text = str(line.get("text", "")).strip()
                color = line.get("color", default_color)
                key = line.get("key") or line.get("id")
                visible = line.get("visible", True)
            else:
                text = str(line).strip()
                color = default_color
                key = None
                visible = True
            if not text:
                continue
            normalized.append({"text": text, "color": color, "key": key, "visible": visible})
        return normalized

    def create_text_panel(
        self,
        lines,
        zone_name="formula",
        color=None,
        font_size=24,
        padding=0.28,
        line_buff=0.18,
        align_edges=(UP, RIGHT),
        panel_fill=None,
        panel_stroke=None,
    ):
        """创建带底板的文本面板，并自动放进指定安全区。支持 keyed line lookup 与逐条 reveal。"""
        color = color or self.COLORS["text"]
        panel_fill = panel_fill or self.COLORS["panel_fill"]
        panel_stroke = panel_stroke or self.COLORS["panel_stroke"]

        line_entries = self._normalize_panel_lines(lines, color)
        if not line_entries:
            line_entries = [{"text": "暂无", "color": self.COLORS["fact_dim"], "key": None, "visible": True}]

        line_lookup = {}
        row_mobjects = []
        for entry in line_entries:
            row = Text(entry["text"], font="PingFang SC", font_size=font_size, color=entry["color"])
            if not entry["visible"]:
                row.set_opacity(0)
                row._wb_hidden = True
            else:
                row._wb_hidden = False
            key = entry.get("key")
            if key:
                line_lookup[key] = row
            row_mobjects.append(row)

        content = row_mobjects[0] if len(row_mobjects) == 1 else VGroup(*row_mobjects).arrange(
            DOWN,
            aligned_edge=LEFT,
            buff=line_buff,
        )

        panel = RoundedRectangle(
            corner_radius=0.16,
            width=content.width + 0.55,
            height=content.height + 0.45,
            fill_color=panel_fill,
            fill_opacity=0.92,
            stroke_color=panel_stroke,
            stroke_width=2,
        )
        content.move_to(panel.get_center())
        group = VGroup(panel, content)
        group.line_lookup = line_lookup
        return self.place_in_zone(group, zone_name, padding=padding, align_edges=align_edges)

    def _flatten_context_text(self, lines, separator="；"):
        """把条件 / 当前小问压成紧凑文本，适合顶部两行课件头。"""
        if not lines:
            return ""
        if isinstance(lines, str):
            lines = [lines]

        cleaned = []
        for line in lines:
            text = str(line).strip()
            if not text:
                continue
            cleaned.append(text.rstrip("；;。"))
        return separator.join(cleaned)

    def create_problem_context_panel(self, title, conditions=None, current_question=None):
        """创建顶部题目信息面板：默认用两行版显示题号+已知，并高亮当前小问。"""
        conditions_text = self._flatten_context_text(conditions)
        current_text = self._flatten_context_text(current_question, separator=" / ") or "待讲解"

        title_text = Text(title, font="PingFang SC", font_size=22, color=self.COLORS["primary"])
        known_text = None
        if conditions_text:
            known_text = Text(
                f"已知：{conditions_text}",
                font="PingFang SC",
                font_size=17,
                color=self.COLORS["text_secondary"],
            )
            top_row = VGroup(title_text, known_text).arrange(RIGHT, buff=0.24, aligned_edge=DOWN)
        else:
            top_row = title_text

        current_label = Text("当前：", font="PingFang SC", font_size=19, color=self.COLORS["highlight"])
        current_value = Text(current_text, font="PingFang SC", font_size=20, color=self.COLORS["good"])
        current_chip = RoundedRectangle(
            corner_radius=0.12,
            width=current_value.width + 0.34,
            height=current_value.height + 0.18,
            fill_color=self.COLORS["good"],
            fill_opacity=0.14,
            stroke_color=self.COLORS["good"],
            stroke_width=1.6,
        )
        current_value.move_to(current_chip.get_center())
        current_group = VGroup(current_chip, current_value)
        bottom_row = VGroup(current_label, current_group).arrange(RIGHT, buff=0.12, aligned_edge=DOWN)

        content = VGroup(top_row, bottom_row).arrange(DOWN, aligned_edge=LEFT, buff=0.12)
        panel = RoundedRectangle(
            corner_radius=0.16,
            width=content.width + 0.62,
            height=content.height + 0.42,
            fill_color=self.COLORS["panel_fill"],
            fill_opacity=0.94,
            stroke_color=self.COLORS["panel_stroke"],
            stroke_width=2,
        )
        accent = Line(
            panel.get_left() + UP * (panel.height / 2 - 0.14),
            panel.get_left() + DOWN * (panel.height / 2 - 0.14),
            color=self.COLORS["primary"],
        ).set_stroke(width=4)
        accent.shift(RIGHT * 0.12)
        content.move_to(panel.get_center()).shift(RIGHT * 0.08)
        group = VGroup(panel, accent, content)
        group.line_lookup = {"conditions": known_text, "current_question": current_value}
        return self.place_in_zone(group, zone_name="title", padding=0.04, align_edges=[UP])

    def set_problem_context(self, title, conditions=None, current_question=None, run_time=0.3):
        """更新顶部题目信息区；适合在每问开头调用，让观众暂停时仍能看到完整题干上下文。"""
        new_panel = self.create_problem_context_panel(title, conditions=conditions, current_question=current_question)
        old_panel = self.problem_context_panel
        self.problem_context_panel = new_panel

        if old_panel is None or old_panel not in self.mobjects:
            if run_time <= 0:
                self.add(new_panel)
            else:
                self.play(FadeIn(new_panel), run_time=run_time)
            return new_panel

        if run_time <= 0:
            self.remove(old_panel)
            self.add(new_panel)
        else:
            self.play(ReplacementTransform(old_panel, new_panel), run_time=run_time)
        return new_panel

    def _normalize_fact_items(self, facts):
        normalized = []
        seen = set()
        for fact in facts or []:
            if isinstance(fact, dict):
                text = fact.get("text", "").strip()
                color = fact.get("color", self.COLORS["fact_text"])
                key = fact.get("key") or fact.get("id")
                visible = fact.get("visible", True)
            else:
                text = str(fact).strip()
                color = self.COLORS["fact_text"]
                key = None
                visible = True
            if not text or text in seen:
                continue
            normalized.append({"text": text, "color": color, "key": key, "visible": visible})
            seen.add(text)
        return normalized

    def _normalize_fact_sections(self, facts=None, sections=None):
        raw_sections = sections if sections is not None else facts
        if not raw_sections:
            return []

        if isinstance(raw_sections, dict):
            raw_sections = [raw_sections]

        structured = (
            isinstance(raw_sections, (list, tuple))
            and raw_sections
            and all(isinstance(section, dict) and "items" in section for section in raw_sections)
        )
        if not structured:
            items = self._normalize_fact_items(raw_sections)
            if not items:
                return []
            style = self.FACT_SECTION_STYLES["default"]
            return [{"title": style["label"], "accent": style["accent"], "items": items}]

        normalized_sections = []
        for section in raw_sections:
            role = section.get("role", "default")
            style = self.FACT_SECTION_STYLES.get(role, self.FACT_SECTION_STYLES["default"])
            title = section.get("title", style["label"])
            accent = section.get("accent", style["accent"])
            items = self._normalize_fact_items(section.get("items", []))
            if not items and not section.get("show_empty", False):
                continue
            normalized_sections.append({"title": title, "accent": accent, "items": items})
        return normalized_sections

    def _build_fact_section(self, section):
        accent = section["accent"]
        badge_label = Text(section["title"], font="PingFang SC", font_size=17, color=accent)
        badge_bg = RoundedRectangle(
            corner_radius=0.09,
            width=badge_label.width + 0.28,
            height=badge_label.height + 0.14,
            fill_color=accent,
            fill_opacity=0.16,
            stroke_color=accent,
            stroke_width=1.2,
        )
        badge_label.move_to(badge_bg.get_center())
        badge = VGroup(badge_bg, badge_label)

        items = section["items"] or [{"text": "暂无", "color": self.COLORS["fact_dim"], "key": None, "visible": True}]
        row_lookup = {}
        row_mobjects = []
        for item in items:
            row = Text(
                f"• {item['text']}",
                font="PingFang SC",
                font_size=19,
                color=item.get("color", self.COLORS["fact_text"]),
            )
            if not item.get("visible", True):
                row.set_opacity(0)
                row._wb_hidden = True
            else:
                row._wb_hidden = False
            key = item.get("key")
            if key:
                row_lookup[key] = row
            row_mobjects.append(row)
        rows = VGroup(*row_mobjects).arrange(DOWN, aligned_edge=LEFT, buff=0.10)

        content = VGroup(badge, rows).arrange(DOWN, aligned_edge=LEFT, buff=0.12)
        section_panel = RoundedRectangle(
            corner_radius=0.12,
            width=content.width + 0.32,
            height=content.height + 0.24,
            fill_color="#0b1222",
            fill_opacity=0.84,
            stroke_color=accent,
            stroke_width=1.1,
        )
        content.move_to(section_panel.get_center())
        return VGroup(section_panel, content), row_lookup

    def create_fact_board(self, facts=None, title="继承事实", zone_name="facts", sections=None):
        """创建右侧事实板，用于承接跨问结论或图内放不下的代数表达。"""
        fact_sections = self._normalize_fact_sections(facts=facts, sections=sections)
        title_text = Text(title, font="PingFang SC", font_size=25, color=self.COLORS["fact_title"])
        row_lookup = {}

        if fact_sections:
            section_mobjects = []
            for section in fact_sections:
                section_group, section_rows = self._build_fact_section(section)
                section_mobjects.append(section_group)
                row_lookup.update(section_rows)
            section_groups = VGroup(*section_mobjects).arrange(
                DOWN,
                aligned_edge=LEFT,
                buff=0.14,
            )
            content = VGroup(title_text, section_groups).arrange(DOWN, aligned_edge=LEFT, buff=0.18)
        else:
            placeholder = Text("• 暂无", font="PingFang SC", font_size=22, color=self.COLORS["fact_dim"])
            content = VGroup(title_text, placeholder).arrange(DOWN, aligned_edge=LEFT, buff=0.22)

        panel = RoundedRectangle(
            corner_radius=0.16,
            width=content.width + 0.6,
            height=content.height + 0.46,
            fill_color=self.COLORS["panel_fill"],
            fill_opacity=0.94,
            stroke_color=self.COLORS["fact_title"],
            stroke_width=2,
        )
        content.move_to(panel.get_center())
        board = VGroup(panel, content)
        board.fact_row_lookup = row_lookup
        board._wb_cleanup_targets = [board, panel, content, *list(row_lookup.values())]
        return self.place_in_zone(board, zone_name, padding=0.12, align_edges=[UP, RIGHT])

    def _forget_registered(self, mobject):
        if mobject in self.persistent_mobjects:
            self.persistent_mobjects.remove(mobject)
        if mobject in self.transient_mobjects:
            self.transient_mobjects.remove(mobject)

    def _collect_scene_family(self, *mobjects):
        existing = []
        seen = set()
        for mob in mobjects:
            candidates = list(getattr(mob, "_wb_cleanup_targets", []))
            if not candidates:
                candidates = [mob]
                if hasattr(mob, "get_family"):
                    candidates.extend(mob.get_family())
            for candidate in candidates:
                if candidate in self.mobjects and id(candidate) not in seen:
                    existing.append(candidate)
                    seen.add(id(candidate))
        return existing

    def _force_remove(self, *mobjects):
        existing = self._collect_scene_family(*mobjects)
        if existing:
            self.remove(*existing)

    def set_grouped_fact_board(self, sections, title="事实板", persistent=True, run_time=0.35):
        return self.set_fact_board(None, title=title, persistent=persistent, run_time=run_time, sections=sections)

    def set_fact_board(self, facts=None, title="继承事实", persistent=True, run_time=0.35, sections=None):
        """创建或更新事实板。默认作为 persistent 保存，供后续各幕复用。

        这里默认不用 ReplacementTransform 做“板子变形替换”。
        原因：当标题、分组数、行数差异较大时，旧板和新板会在过渡中叠影，
        更稳的策略是“旧板退场 + 新板入场”。
        同时，旧板淡出后会强制移除 root + family，避免描边或旧文本残留。
        """
        new_board = self.create_fact_board(facts=facts, title=title, sections=sections)
        old_board = self.fact_board
        old_visible = self._collect_scene_family(old_board) if old_board is not None else []

        if old_visible:
            self._forget_registered(old_board)
            if run_time > 0:
                fade_out_time = max(run_time * 0.45, 0.12)
                fade_in_time = max(run_time - fade_out_time, 0.12)
                fade_targets = [old_board] if old_board in self.mobjects else old_visible
                self.play(*[FadeOut(mob) for mob in fade_targets], run_time=fade_out_time)
                self._force_remove(old_board)
                self.add(new_board)
                self.play(FadeIn(new_board), run_time=fade_in_time)
            else:
                self._force_remove(old_board)
                self.add(new_board)
        else:
            if run_time > 0:
                self.play(FadeIn(new_board), run_time=run_time)
            else:
                self.add(new_board)

        self.fact_board = new_board
        self.fact_row_lookup = getattr(new_board, "fact_row_lookup", {})
        if persistent:
            self.register_persistent(new_board)
        else:
            self.register_transient(new_board)
        return new_board

    def clear_fact_board(self, run_time=0.25):
        if self.fact_board is None:
            self.fact_board = None
            self.fact_row_lookup = {}
            return
        board = self.fact_board
        visible = self._collect_scene_family(board)
        self._forget_registered(board)
        self.fact_board = None
        self.fact_row_lookup = {}
        if not visible:
            return
        if run_time <= 0:
            self._force_remove(board)
            return
        fade_targets = [board] if board in self.mobjects else visible
        self.play(*[FadeOut(mob) for mob in fade_targets], run_time=run_time)
        self._force_remove(board)

    def set_named_panel(self, panel_name, panel, persistent=False, run_time=0.3):
        old_panel = self.named_panels.get(panel_name)
        old_visible = self._collect_scene_family(old_panel) if old_panel is not None else []
        if old_visible:
            self._forget_registered(old_panel)
            if run_time > 0:
                fade_out_time = max(run_time * 0.45, 0.12)
                fade_in_time = max(run_time - fade_out_time, 0.12)
                fade_targets = [old_panel] if old_panel in self.mobjects else old_visible
                self.play(*[FadeOut(mob) for mob in fade_targets], run_time=fade_out_time)
                self._force_remove(old_panel)
                self.add(panel)
                self.play(FadeIn(panel), run_time=fade_in_time)
            else:
                self._force_remove(old_panel)
                self.add(panel)
        else:
            if run_time > 0:
                self.play(FadeIn(panel), run_time=run_time)
            else:
                self.add(panel)
        self.named_panels[panel_name] = panel
        if persistent:
            self.register_persistent(panel)
        else:
            self.register_transient(panel)
        return panel

    def clear_named_panel(self, panel_name, run_time=0.25):
        panel = self.named_panels.pop(panel_name, None)
        if panel is None:
            return
        visible = self._collect_scene_family(panel)
        self._forget_registered(panel)
        if not visible:
            return
        if run_time <= 0:
            self._force_remove(panel)
            return
        fade_targets = [panel] if panel in self.mobjects else visible
        self.play(*[FadeOut(mob) for mob in fade_targets], run_time=run_time)
        self._force_remove(panel)

    def _reveal_lookup_items(self, lookup, keys, run_time=0.32, cascade=0.16):
        animations = []
        seen = set()
        for key in keys:
            item = lookup.get(key)
            if item is None or id(item) in seen:
                continue
            seen.add(id(item))
            item_color = item.get_color() if hasattr(item, "get_color") else self.COLORS["highlight"]
            if getattr(item, "_wb_hidden", False):
                item._wb_hidden = False
                animations.append(
                    Succession(
                        item.animate.set_opacity(1),
                        Indicate(item, color=item_color, scale_factor=1.04),
                    )
                )
            else:
                animations.append(Indicate(item, color=item_color, scale_factor=1.04))

        if animations:
            self.play(LaggedStart(*animations, lag_ratio=cascade), run_time=run_time)

    def reveal_fact_rows(self, *fact_keys, run_time=0.32, cascade=0.16):
        self._reveal_lookup_items(self.fact_row_lookup, fact_keys, run_time=run_time, cascade=cascade)

    def get_panel_line(self, panel, line_key):
        return getattr(panel, "line_lookup", {}).get(line_key)

    def reveal_panel_lines(self, panel, *line_keys, run_time=0.32, cascade=0.16):
        self._reveal_lookup_items(getattr(panel, "line_lookup", {}), line_keys, run_time=run_time, cascade=cascade)

    def _collect_visible_targets(self, *targets):
        visible = []
        seen = set()
        queue = list(targets)
        while queue:
            target = queue.pop(0)
            if target is None:
                continue
            if isinstance(target, (list, tuple, set)):
                queue.extend(target)
                continue
            candidates = []
            if hasattr(target, "get_family"):
                family_visible = [candidate for candidate in target.get_family() if candidate in self.mobjects]
                if family_visible:
                    candidates.extend(family_visible)
            if not candidates:
                candidates = [target]
            for candidate in candidates:
                if id(candidate) not in seen:
                    visible.append(candidate)
                    seen.add(id(candidate))
        return visible

    def _build_spotlight_animation(self, target, color):
        if isinstance(target, Text):
            frame = SurroundingRectangle(target, buff=0.08, color=color, corner_radius=0.08)
            frame.set_fill(color, opacity=0.10)
            frame.set_stroke(color, width=2.2)
            return AnimationGroup(
                Indicate(target, color=color, scale_factor=1.05),
                Succession(FadeIn(frame, run_time=0.08), FadeOut(frame, run_time=0.18)),
                lag_ratio=0.0,
            )
        return Indicate(target, color=color, scale_factor=1.04)

    def pulse_fact_with_targets(self, fact_key, *targets, run_time=0.35, color=None):
        focus_targets = []
        row = self.fact_row_lookup.get(fact_key)
        if row is not None:
            focus_targets.append(row)
        focus_targets.extend(self._collect_visible_targets(*targets))

        animations = []
        for target in focus_targets:
            target_color = color
            if target_color is None and hasattr(target, "get_color"):
                try:
                    target_color = target.get_color()
                except Exception:
                    target_color = None
            animations.append(self._build_spotlight_animation(target, target_color or self.COLORS["highlight"]))

        if animations:
            self.play(*animations, run_time=run_time)

    # ========== 4. 场景分层管理 ==========
    def register_persistent(self, *mobjects):
        """登记常驻元素。"""
        for mob in mobjects:
            if mob not in self.persistent_mobjects:
                self.persistent_mobjects.append(mob)
        return mobjects[0] if len(mobjects) == 1 else VGroup(*mobjects)

    def register_transient(self, *mobjects):
        """登记临时元素，幕末自动清理。"""
        for mob in mobjects:
            if mob not in self.transient_mobjects:
                self.transient_mobjects.append(mob)
        return mobjects[0] if len(mobjects) == 1 else VGroup(*mobjects)

    def _collect_existing_registered(self, registry):
        """优先回收登记的根对象；只有根对象不在场景里时，才回收已落地的 family 子元素。"""
        existing = []
        seen = set()
        for mob in registry:
            if mob in self.mobjects and id(mob) not in seen:
                existing.append(mob)
                seen.add(id(mob))
                continue
            if not hasattr(mob, "get_family"):
                continue
            for candidate in mob.get_family():
                if candidate in self.mobjects and id(candidate) not in seen:
                    existing.append(candidate)
                    seen.add(id(candidate))
        return existing

    def clear_transients(self, run_time=0.35):
        """清理当前幕的临时元素。"""
        registered = list(self.transient_mobjects)
        existing = self._collect_existing_registered(registered)
        removed_ids = {id(mob) for mob in registered}
        self.transient_mobjects.clear()
        self.named_panels = {key: panel for key, panel in self.named_panels.items() if id(panel) not in removed_ids}
        if not existing:
            return
        if run_time <= 0:
            self._force_remove(*registered)
            return
        self.play(*[FadeOut(mob) for mob in existing], run_time=run_time)
        self._force_remove(*registered)

    def clear_persistents(self, run_time=0.45):
        """清理常驻元素。一般用于题目切换或总结页前。"""
        registered = list(self.persistent_mobjects)
        existing = self._collect_existing_registered(registered)
        self.persistent_mobjects.clear()
        self.fact_board = None
        self.fact_row_lookup = {}
        if not existing:
            return
        if run_time <= 0:
            self._force_remove(*registered)
            return
        self.play(*[FadeOut(mob) for mob in existing], run_time=run_time)
        self._force_remove(*registered)

    def reset_scene(self, clear_persistent=False, clear_transient=True, run_time=0.35):
        """统一收口，不要直接 FadeOut(self.mobjects)。"""
        if clear_transient:
            self.clear_transients(run_time=run_time)
        if clear_persistent:
            self.clear_persistents(run_time=run_time)

    def begin_subproblem(
        self,
        subproblem_key,
        carried_facts=None,
        fact_title="继承事实",
        clear_transient=True,
        run_time=0.35,
        reset_annotation=True,
    ):
        """
        开始一个子问题：
        1. 切换 current_subproblem
        2. 清掉上一问临时元素
        3. 把需要沿用的结论放进右侧 fact board
        4. 重置当前子问题的角标注预算
        """
        self.current_subproblem = subproblem_key
        if clear_transient:
            self.clear_transients(run_time=run_time)
        if reset_annotation:
            self.reset_annotation_budget(subproblem_key)
        if carried_facts:
            self.set_fact_board(carried_facts, title=fact_title, persistent=True, run_time=run_time)
        elif self.fact_board is not None and self._collect_scene_family(self.fact_board):
            self.clear_fact_board(run_time=run_time)
        return subproblem_key

    # ========== 5. 角标注预算 / 自动降级 ==========
    def reset_annotation_budget(self, cluster="default"):
        self.annotation_budgets[cluster] = {
            "slot_index": 0,
            "occupied_lanes": {"left": set(), "right": set()},
            "queued_facts": [],
        }
        return self.annotation_budgets[cluster]

    def get_annotation_budget(self, cluster="default"):
        return self.annotation_budgets.setdefault(
            cluster,
            {
                "slot_index": 0,
                "occupied_lanes": {"left": set(), "right": set()},
                "queued_facts": [],
            },
        )

    def queue_fact(self, text, cluster="default"):
        text = str(text).strip()
        if not text:
            return
        budget = self.get_annotation_budget(cluster)
        if text not in budget["queued_facts"]:
            budget["queued_facts"].append(text)

    def consume_queued_facts(self, cluster="default"):
        budget = self.get_annotation_budget(cluster)
        facts = budget["queued_facts"][:]
        budget["queued_facts"].clear()
        return facts

    def _get_callout_lane_positions(self):
        zone = self.get_zone_rect("geometry", padding=0.12)
        center_y = zone.get_center()[1]
        half_height = zone.height / 2
        return [center_y + ratio * half_height for ratio in self.CALLOUT_LANE_RATIOS]

    def _choose_callout_side_and_lane(self, preferred_side, preferred_y, cluster="default"):
        budget = self.get_annotation_budget(cluster)
        lane_positions = self._get_callout_lane_positions()
        scores = {}

        for side in ("left", "right"):
            used = budget["occupied_lanes"][side]
            candidates = [(idx, y) for idx, y in enumerate(lane_positions) if idx not in used] or list(enumerate(lane_positions))
            lane_index, lane_y = min(candidates, key=lambda item: abs(item[1] - preferred_y))
            penalty = 0 if side == preferred_side else 0.28
            scores[side] = (abs(lane_y - preferred_y) + penalty, lane_index, lane_y)

        chosen_side = min(scores, key=lambda side: scores[side][0])
        _, lane_index, lane_y = scores[chosen_side]
        budget["occupied_lanes"][chosen_side].add(lane_index)
        return chosen_side, lane_y, lane_index

    def _build_angle_arc(self, refs, start_angle, end_angle, radius_ratio, color, label_text, label_ratio=1.18, font_size=20, stroke_width=3):
        center = refs["dot_o"].get_center()
        radius = refs["base_length"] * radius_ratio
        arc = Arc(
            radius=radius,
            start_angle=start_angle,
            angle=end_angle - start_angle,
            arc_center=center,
            color=color,
            stroke_width=stroke_width,
        )
        mid_angle = (start_angle + end_angle) / 2
        label_pos = center + radius * label_ratio * np.array([np.cos(mid_angle), np.sin(mid_angle), 0.0])
        label = Text(label_text, font="PingFang SC", font_size=font_size, color=color).move_to(label_pos)
        return VGroup(arc, label)

    def _build_angle_callout(self, refs, start_angle, end_angle, radius_ratio, color, label_text, cluster="default", font_size=20, stroke_width=3):
        center = refs["dot_o"].get_center()
        radius = refs["base_length"] * radius_ratio
        arc = Arc(
            radius=radius,
            start_angle=start_angle,
            angle=end_angle - start_angle,
            arc_center=center,
            color=color,
            stroke_width=stroke_width,
        )

        mid_angle = (start_angle + end_angle) / 2
        anchor = center + radius * np.array([np.cos(mid_angle), np.sin(mid_angle), 0.0])
        preferred_side = "left" if np.cos(mid_angle) < 0 else "right"
        preferred_y = float(anchor[1] + 0.52)
        side, y, lane_index = self._choose_callout_side_and_lane(preferred_side, preferred_y, cluster=cluster)

        zone = self.get_zone_rect("geometry", padding=0.12)
        x = zone.get_left()[0] + 0.72 if side == "left" else zone.get_right()[0] - 0.72

        text = Text(label_text, font="PingFang SC", font_size=font_size, color=color)
        bubble = RoundedRectangle(
            corner_radius=0.12,
            width=text.width + 0.34,
            height=text.height + 0.22,
            fill_color=self.COLORS["panel_fill"],
            fill_opacity=0.88,
            stroke_color=color,
            stroke_width=1.5,
        )
        text.move_to(bubble.get_center())
        badge = VGroup(bubble, text).move_to(np.array([x, y, 0.0]))
        connector_end = badge.get_right() if side == "left" else badge.get_left()
        track_offset = 0.24 + 0.06 * min(lane_index, 3)
        track_x = connector_end[0] + (track_offset if side == "left" else -track_offset)
        elbow_1 = np.array([track_x, anchor[1], 0.0])
        elbow_2 = np.array([track_x, connector_end[1], 0.0])
        connector_path = VMobject(color=color)
        connector_path.set_points_as_corners([anchor, elbow_1, elbow_2, connector_end])
        connector = DashedVMobject(connector_path, num_dashes=18, dashed_ratio=0.62)
        connector.set_color(color)
        connector.set_stroke(width=2)
        return VGroup(arc, connector, badge)

    def create_angle_annotation(
        self,
        refs,
        start_angle,
        end_angle,
        text,
        color,
        cluster="default",
        mode="auto",
        fact_text=None,
        font_size=None,
        stroke_width=3,
    ):
        """
        角标注统一入口：
        - inline：图内角弧 + 文字
        - callout：图外引线标注
        - fact：直接排进右侧事实板
        - auto：按预算自动降级
        """
        budget = self.get_annotation_budget(cluster)
        slot_index = budget["slot_index"]
        span_deg = abs(np.degrees(end_angle - start_angle))
        compact = len(text) <= 4 and all(token not in text for token in ["-", "+", "=", "×", "/"]) and span_deg >= 14

        if mode == "auto":
            if slot_index < 2 and compact:
                mode = "inline"
            elif slot_index < len(self.ANGLE_LABEL_SLOTS) and len(text) <= 6:
                mode = "callout"
            else:
                mode = "fact"

        if mode == "fact":
            self.queue_fact(fact_text or text, cluster=cluster)
            return VGroup()

        slot = self.ANGLE_LABEL_SLOTS[min(slot_index, len(self.ANGLE_LABEL_SLOTS) - 1)]
        budget["slot_index"] += 1
        font_size = font_size or slot["font_size"]

        if mode == "inline":
            return self._build_angle_arc(
                refs,
                start_angle,
                end_angle,
                slot["radius_ratio"],
                color,
                text,
                label_ratio=slot["label_ratio"],
                font_size=font_size,
                stroke_width=stroke_width,
            )

        return self._build_angle_callout(
            refs,
            start_angle,
            end_angle,
            slot["radius_ratio"],
            color,
            text,
            cluster=cluster,
            font_size=font_size,
            stroke_width=stroke_width,
        )

    # ========== 6. 几何 & 元素 ==========
    def to_3d(self, point_2d):
        return np.array([point_2d[0], point_2d[1], 0.0])

    def calculate_geometry(self):
        """
        计算所有几何元素的位置和属性。
        TODO: 根据题目几何关系完整实现。
        """
        geometry = {
            "points": {},
            "lines": {},
            "circles": {},
            "arcs": {},
            "polygons": {},
        }
        return geometry

    def assert_geometry(self, geometry):
        """
        验证几何正确性 + 画布范围。
        TODO: 根据题目条件补上关键 assert。
        """
        all_points = list(geometry.get("points", {}).values())
        for circle in geometry.get("circles", {}).values():
            cx, cy = circle["center"]
            radius = circle["radius"]
            all_points.extend([
                (cx + radius, cy),
                (cx - radius, cy),
                (cx, cy + radius),
                (cx, cy - radius),
            ])

        if not all_points:
            return

        xs = [p[0] for p in all_points]
        ys = [p[1] for p in all_points]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)

        margin = 0.5
        assert min_x >= -6.5 + margin, f"图形超出左边界：{min_x:.2f}，建议缩小或右移"
        assert max_x <= 6.5 - margin, f"图形超出右边界：{max_x:.2f}，建议缩小或左移"
        assert min_y >= -3.8 + margin, f"图形超出下边界：{min_y:.2f}，建议缩小或上移"
        assert max_y <= 3.8 - margin, f"图形超出上边界：{max_y:.2f}，建议缩小或下移"

    def define_elements(self, geometry):
        """
        定义基础图形对象。
        TODO: 根据题目返回基础图形元素。
        """
        return {
            "points": {},
            "lines": {},
            "circles": {},
            "labels": {},
        }

    # ========== 7. 字幕 / 高亮 ==========
    def create_subtitle(self, text, font_size=30):
        subtitle = self.create_text_panel(
            text,
            zone_name="subtitle",
            color=self.COLORS["text"],
            font_size=font_size,
            padding=0.08,
            align_edges=None,
        )
        return subtitle

    def show_subtitle_timed(self, text, duration, fade_in_time=0.25, fade_out_time=0.25):
        subtitle = self.register_transient(self.create_subtitle(text))
        self.play(FadeIn(subtitle), run_time=fade_in_time)
        hold = max(duration - fade_in_time - fade_out_time, 0)
        if hold > 0:
            self.wait(hold)
        self.play(FadeOut(subtitle), run_time=fade_out_time)
        if subtitle in self.transient_mobjects:
            self.transient_mobjects.remove(subtitle)
        return subtitle

    def show_subtitle_with_audio(self, text, audio_duration):
        return self.show_subtitle_timed(text, max(audio_duration, 1.0))

    def highlight_element(self, element, color=None, scale=1.15, duration=0.8):
        color = color or self.COLORS["highlight"]
        original_color = element.get_color() if hasattr(element, "get_color") else WHITE
        self.play(element.animate.scale(scale).set_color(color), run_time=0.25)
        hold = max(duration - 0.5, 0)
        if hold > 0:
            self.wait(hold)
        self.play(element.animate.scale(1 / scale).set_color(original_color), run_time=0.25)

    # ========== 8. 主流程 ==========
    def construct(self):
        self.camera.background_color = self.COLORS["background"]
        self.assert_layout_safety()
        geometry = self.calculate_geometry()
        self.assert_geometry(geometry)
        elements = self.define_elements(geometry)

        try:
            for scene_num, scene_name, audio_file, duration in self.SCENES:
                self.play_scene(scene_num, scene_name, audio_file, duration, elements, geometry)
        finally:
            self.write_audio_schedule(finalized=True)

    def play_scene(self, scene_num, scene_name, audio_file, duration, elements, geometry):
        """
        每幕统一入口：
        1. 先清理上一幕 transient
        2. 添加当前幕音频
        3. 调用 play_scene_X
        4. 若本幕节奏偏短，自动补足到音频尾部附近
        5. 幕末自动清理 transient
        6. 回填本幕实际结束时间，供 audio_schedule.json 校验
        """
        cleanup_run_time = 0.35
        self.clear_transients(run_time=0)
        audio_duration = self.add_scene_audio(scene_num)
        effective_duration = duration or audio_duration or 0

        method_name = f"play_scene_{scene_num}"
        if not hasattr(self, method_name):
            print(f"Warning: {method_name} not implemented")
            return

        getattr(self, method_name)(effective_duration, elements, geometry)
        projected_cleanup_run_time = cleanup_run_time if self._collect_existing_registered(self.transient_mobjects) else 0.0
        self._ensure_scene_audio_coverage(scene_num, cleanup_run_time=projected_cleanup_run_time)
        self.clear_transients(run_time=cleanup_run_time)
        self._mark_scene_audio_complete(scene_num)


# ========== 使用提醒 ==========
"""
写题目脚本时请遵守：
1. `construct()` 开头先跑 assert_layout_safety()；几何主图整体先组进一个 VGroup，再 place_in_zone(group, "geometry")。
2. 跨问结论不要继续画回主图，优先 begin_subproblem(..., carried_facts=[...]) 放进事实板。
3. 公式 / 提示 / 结论统一用 create_text_panel(..., zone_name="formula"/"summary")；如果右侧信息密度高，优先改用 zone_name="right_panel" 做单面板。
4. 每幕临时元素都 register_transient(...)，不要手写 FadeOut(self.mobjects)。
5. 需要跨多幕保留的底图或核心角标签才 register_persistent(...)。
6. 多个角挤在同一顶点时，用 create_angle_annotation(..., mode="auto")，让系统自动决定图内 / callout / 事实板；同侧 callout 会按车道自动避让，并尽量走分轨折线。
7. 右侧信息尽量用 set_grouped_fact_board(...) 拆成“继承上一问 / 当前推导 / 最终结论”，需要延后出现的条目直接写 `visible=False`。
8. 公式区如果要跟着讲解推进，给每一行加 key，再用 reveal_panel_lines(...) 逐条揭示。
9. 关键事实出现后，可用 pulse_fact_with_targets(...) 让事实板条目、主图对象、公式行做三方同步聚光。
10. 如果切换到新题型/总结页，调用 reset_scene(clear_persistent=True)。
11. 默认不使用 MathTex，优先用 Text + Unicode 符号，避免 LaTeX 依赖。
12. 每幕音频统一走 add_scene_audio(scene_num)，不要零散直接 add_sound；这样渲染流程才能稳定生成 audio_schedule.json 做时间轴验收。
13. `play_scene()` 现在会在清场前自动补齐音频尾部，所以幕内 `wait(...)` 主要关注讲解节奏本身，不用再手工扣那 0.3s / 0.35s 的 cleanup 时间。
"""
