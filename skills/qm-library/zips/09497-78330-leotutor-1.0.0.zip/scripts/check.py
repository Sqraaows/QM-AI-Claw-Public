#!/usr/bin/env python3
"""
Manim 教学视频代码检查脚本（跨问继承 / 标注预算增强版）
验证 script.py 是否包含必要函数、布局 helper，以及是否具备“事实板 + 角标注预算”的系统性能力。

使用方法:
    python scripts/check.py [script_file]
"""

import ast
import sys
from pathlib import Path


class CodeChecker:
    """代码结构检查器"""

    REQUIRED_FUNCTIONS = [
        "calculate_geometry",
        "assert_geometry",
        "define_elements",
    ]

    RECOMMENDED_FUNCTIONS = [
        "play_scene",
        "add_scene_audio",
        "_ensure_scene_audio_coverage",
        "write_audio_schedule",
    ]

    RECOMMENDED_LAYOUT_HELPERS = [
        "place_in_zone",
        "assert_layout_safety",
        "create_text_panel",
        "register_transient",
        "clear_transients",
        "reset_scene",
    ]

    RECOMMENDED_SYSTEM_HELPERS = [
        "begin_subproblem",
        "set_problem_context",
        "set_fact_board",
        "set_grouped_fact_board",
        "reveal_fact_rows",
        "reveal_panel_lines",
        "pulse_fact_with_targets",
        "reset_annotation_budget",
        "create_angle_annotation",
    ]

    RECOMMENDED_CLASS_ATTRIBUTES = [
        "LAYOUT_ZONES",
        "LAYOUT_SAFE_PAIRS",
        "ANGLE_LABEL_SLOTS",
        "CALLOUT_LANE_RATIOS",
    ]

    def __init__(self, file_path):
        self.file_path = Path(file_path)
        self.errors = []
        self.warnings = []
        self.tree = None
        self.source = ""
        self.classes = {}
        self.class_attrs = {}
        self.scene_class_name = "MathScene"

    def parse(self):
        if not self.file_path.exists():
            self.errors.append(f"文件不存在: {self.file_path}")
            return False

        try:
            self.source = self.file_path.read_text(encoding="utf-8")
            self.tree = ast.parse(self.source)
            return True
        except SyntaxError as e:
            self.errors.append(f"语法错误: {e}")
            return False
        except Exception as e:
            self.errors.append(f"解析失败: {e}")
            return False

    def analyze(self):
        if not self.tree:
            return

        for node in ast.iter_child_nodes(self.tree):
            if not isinstance(node, ast.ClassDef):
                continue

            class_name = node.name
            methods = []
            attrs = set()

            for item in node.body:
                if isinstance(item, ast.FunctionDef):
                    methods.append(item.name)
                elif isinstance(item, (ast.Assign, ast.AnnAssign)):
                    for name in self._extract_assignment_names(item):
                        attrs.add(name)

            self.classes[class_name] = methods
            self.class_attrs[class_name] = attrs

    def _extract_assignment_names(self, node):
        names = []
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, ast.AnnAssign):
            targets = [node.target]

        for target in targets:
            if isinstance(target, ast.Name):
                names.append(target.id)
            elif isinstance(target, ast.Tuple):
                for elt in target.elts:
                    if isinstance(elt, ast.Name):
                        names.append(elt.id)
        return names

    def _all_methods(self):
        methods = set()
        for _, class_methods in self.classes.items():
            methods.update(class_methods)
        return methods

    def _all_attrs(self):
        attrs = set()
        for _, class_attrs in self.class_attrs.items():
            attrs.update(class_attrs)
        return attrs

    def check_required_functions(self):
        all_methods = self._all_methods()
        for func_name in self.REQUIRED_FUNCTIONS:
            if func_name not in all_methods:
                self.errors.append(
                    f"缺少必需函数: {func_name}()\n"
                    f"  请在 Scene 类中实现此方法\n"
                    f"  作用: {self._get_function_description(func_name)}"
                )

    def check_recommended_functions(self):
        all_methods = self._all_methods()
        for func_name in self.RECOMMENDED_FUNCTIONS:
            if func_name not in all_methods:
                self.warnings.append(
                    f"缺少推荐函数: {func_name}()\n"
                    f"  建议使用统一的单幕入口，便于自动清理 transient 元素"
                )

    def check_layout_helpers(self):
        all_methods = self._all_methods()
        missing = [name for name in self.RECOMMENDED_LAYOUT_HELPERS if name not in all_methods]
        if missing:
            self.warnings.append(
                "未完整提供布局/清场 helper\n"
                f"  缺少: {', '.join(missing)}\n"
                "  建议: 使用新版 script_scaffold.py 中的安全布局区 + transient 清理机制"
            )

        all_attrs = self._all_attrs()
        for attr_name in self.RECOMMENDED_CLASS_ATTRIBUTES:
            if attr_name not in all_attrs:
                self.warnings.append(
                    f"未找到推荐类属性: {attr_name}\n"
                    "  建议: 定义固定安全区和角标注预算，避免公式、字幕、几何图抢位置"
                )

    def check_system_helpers(self):
        all_methods = self._all_methods()
        missing = [name for name in self.RECOMMENDED_SYSTEM_HELPERS if name not in all_methods]
        if missing:
            self.warnings.append(
                "未完整提供跨问继承 / 标注预算 helper\n"
                f"  缺少: {', '.join(missing)}\n"
                "  风险: 第二问继承第一问结论时，容易把历史信息重新塞回主图中心，导致 O 点附近拥挤"
            )

        if "facts" not in self.source:
            self.warnings.append(
                "未检测到 facts / 事实板相关定义\n"
                "  建议: 为跨问题型预留事实区，把上一问结论放到右侧而不是继续挤占几何主图区"
            )

        if "CALLOUT_LANE_RATIOS" not in self.source and "_choose_callout_side_and_lane" not in self.source:
            self.warnings.append(
                "未检测到 callout 自动避让配置\n"
                "  风险: 同侧多个外置标签容易互相压住，继承事实与当前推导同时出现时画面会乱"
            )

        if "reveal_fact_rows" not in self.source and "_wb_hidden" not in self.source:
            self.warnings.append(
                "未检测到事实板条目的逐条 reveal 机制\n"
                "  风险: 右侧事实只能整块替换，讲解节奏一快就会显得像在跳页"
            )

        if "reveal_panel_lines" not in self.source and "line_lookup" not in self.source:
            self.warnings.append(
                "未检测到公式区逐条显隐或 keyed line lookup 机制\n"
                "  风险: 公式只能整面板一起出现，无法和主图的推导节奏精准同步"
            )

        if "pulse_fact_with_targets" not in self.source and "fact_row_lookup" not in self.source:
            self.warnings.append(
                "未检测到事实板与主图联动高亮机制\n"
                "  风险: 右侧事实板和几何主图各说各话，学生需要自己猜哪条事实对应哪段图形"
            )

    def check_scene_class(self):
        found_scene = False
        for node in ast.iter_child_nodes(self.tree):
            if not isinstance(node, ast.ClassDef):
                continue
            for base in node.bases:
                if isinstance(base, ast.Name) and base.id == "Scene":
                    found_scene = True
                    self.scene_class_name = node.name
                    break
                if isinstance(base, ast.Attribute) and base.attr == "Scene":
                    found_scene = True
                    self.scene_class_name = node.name
                    break
        if not found_scene:
            self.errors.append(
                "未找到继承自 Scene 的类\n"
                "  必须有一个类继承自 Scene，例如: class MathScene(Scene):"
            )

    def check_add_sound(self):
        has_add_sound = False
        for node in ast.walk(self.tree):
            if not isinstance(node, ast.Call):
                continue
            if isinstance(node.func, ast.Attribute) and node.func.attr == "add_sound":
                has_add_sound = True
                break
            if isinstance(node.func, ast.Name) and node.func.id == "add_sound":
                has_add_sound = True
                break
        if not has_add_sound:
            self.warnings.append(
                "未检测到 add_sound() 调用\n"
                "  提醒: 每幕动画应该添加对应的音频文件\n"
                "  示例: self.add_sound('audio/audio_001_开场.wav')"
            )

    def check_audio_schedule_helpers(self):
        all_methods = self._all_methods()
        missing = [name for name in ("add_scene_audio", "_ensure_scene_audio_coverage", "write_audio_schedule") if name not in all_methods]
        if missing:
            self.warnings.append(
                "未完整提供统一音频调度 helper\n"
                f"  缺少: {', '.join(missing)}\n"
                "  风险: 渲染后只能做总时长级校验，且幕末可能出现画面比音频先结束的问题"
            )

        if "audio_schedule" not in self.source:
            self.warnings.append(
                "未检测到 audio_schedule.json 相关逻辑\n"
                "  建议: 用 add_scene_audio() 统一登记音轨，并在 construct() 结束时写出 audio_schedule.json"
            )

    def check_cleanup_antipatterns(self):
        patterns = [
            "FadeOut(self.mobjects",
            "for m in self.mobjects",
            "self.play(*[FadeOut(m) for m in self.mobjects]",
        ]
        if any(pattern in self.source for pattern in patterns):
            self.warnings.append(
                "检测到直接基于 self.mobjects 的整场清理写法\n"
                "  风险: 容易误删底图，或遗漏未登记对象导致跨幕残留\n"
                "  建议: 使用 register_transient()/clear_transients()/reset_scene()"
            )

    def check_panel_transition_antipatterns(self):
        if "ReplacementTransform(old_board, new_board)" in self.source:
            self.warnings.append(
                "检测到事实板使用 ReplacementTransform 做整板替换\n"
                "  风险: 当标题、分组数或行数差异较大时，旧板和新板会叠影，出现多层边框\n"
                "  建议: 改成旧板 FadeOut + 新板 FadeIn，或固定外框只更新内部文本"
            )

        if "assert_layout_safety" not in self.source and "LAYOUT_SAFE_PAIRS" not in self.source:
            self.warnings.append(
                "未检测到布局安全断言\n"
                "  风险: geometry 与 facts/formula/right_panel 可能在参数层面直接重叠，渲完才被肉眼发现\n"
                "  建议: 定义 LAYOUT_SAFE_PAIRS，并在 construct() 开头调用 assert_layout_safety()"
            )

    def check_cross_problem_antipatterns(self):
        direct_angle_texts = [
            "120°-x",
            "x-40°",
            "2x-80°",
        ]
        if sum(self.source.count(text) for text in direct_angle_texts) >= 3 and "set_fact_board" not in self.source:
            self.warnings.append(
                "检测到多个代数角标签直接写在脚本中，但未配合事实板使用\n"
                "  风险: 第二问或多问场景容易在顶点附近堆满 x、120°-x、2x-80° 等表达\n"
                "  建议: 让代数表达进入 fact board / formula 区，主图只保留核心角标签"
            )

    def _get_function_description(self, func_name):
        descriptions = {
            "calculate_geometry": "计算所有几何元素（点、线、圆）的坐标和属性",
            "assert_geometry": "验证几何计算的正确性和画布范围",
            "define_elements": "定义 Manim 图形对象（点、线、圆等）",
        }
        return descriptions.get(func_name, "未知功能")

    def run(self):
        print(f"🔍 检查文件: {self.file_path}")
        print("=" * 50)

        if not self.parse():
            return False

        self.analyze()
        self.check_scene_class()
        self.check_required_functions()
        self.check_recommended_functions()
        self.check_layout_helpers()
        self.check_system_helpers()
        self.check_add_sound()
        self.check_audio_schedule_helpers()
        self.check_cleanup_antipatterns()
        self.check_panel_transition_antipatterns()
        self.check_cross_problem_antipatterns()
        return self.report()

    def report(self):
        success = len(self.errors) == 0

        if self.errors:
            print("\n❌ 错误 (必须修复):")
            for index, error in enumerate(self.errors, 1):
                print(f"\n  {index}. {error}")

        if self.warnings:
            print("\n⚠️  警告 (建议修复):")
            for index, warning in enumerate(self.warnings, 1):
                print(f"\n  {index}. {warning}")

        if success and not self.warnings:
            print("\n✅ 所有检查通过！可以开始渲染。")
        elif success:
            print("\n✅ 必要检查通过，但有警告建议处理。")

        print("\n" + "=" * 50)
        if success:
            print("🎬 下一步: 运行渲染命令")
            print(f"   manim -pqh {self.file_path} {self.scene_class_name}")
        else:
            print("⛔ 检查失败，请修复错误后重试。")
        return success


def main():
    script_file = sys.argv[1] if len(sys.argv) > 1 else "script.py"
    checker = CodeChecker(script_file)
    success = checker.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
