#!/usr/bin/env python3
"""
Manim 教学视频渲染脚本
完整流程: 检查代码 -> 校验音频素材 -> 渲染视频 -> 校验成片音轨

新增守门机制：
1. 如果检测到音频/TTS 相关输入比当前成片更新，会自动启用无缓存渲染
2. 渲染完成后会校验 mp4 是否包含真实音轨，且音轨时长是否合理
3. 如果首轮成片音轨异常，会自动触发一次无缓存重渲，避免缓存把音轨吃坏

使用方法:
    python scripts/render.py [options]

选项:
    -f, --file           指定脚本文件 (默认: script.py)
    -s, --scene          指定场景类名 (默认: MathScene)
    -q, --quality        渲染质量: l(ow)/m(edium)/h(igh)/k(4k) (默认: high)
    -p, --preview        渲染后预览 (默认: 开启)
    --no-check           跳过代码检查 (不推荐)
    --disable-caching    显式禁用 Manim 缓存

示例:
    python scripts/render.py
    python scripts/render.py -f my_script.py -s MyScene
    python scripts/render.py -q h --no-preview
    python scripts/render.py --disable-caching
"""

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path


class RenderPipeline:
    """渲染流水线"""

    QUALITY_MAP = {
        'l': '480p15',
        'low': '480p15',
        'm': '720p30',
        'medium': '720p30',
        'h': '1080p60',
        'high': '1080p60',
        'k': '2160p60',
        '4k': '2160p60',
    }

    QUALITY_FLAG_MAP = {
        'l': 'l',
        'low': 'l',
        'm': 'm',
        'medium': 'm',
        'h': 'h',
        'high': 'h',
        'k': 'k',
        '4k': 'k',
    }

    AUDIO_EXTENSIONS = {'.wav', '.mp3', '.m4a', '.flac', '.aac', '.ogg'}

    def __init__(self, script_file='script.py', scene_name='MathScene',
                 quality='high', preview=True, skip_check=False, disable_caching=False):
        self.script_file = Path(script_file).resolve()
        self.scene_name = scene_name
        self.quality = self.QUALITY_MAP.get(quality, '1080p60')
        self.quality_flag = self.QUALITY_FLAG_MAP.get(quality, 'h')
        self.preview = preview
        self.skip_check = skip_check
        self.disable_caching = disable_caching
        self.disable_caching_explicit = disable_caching

        # skill 目录只用于找到检查脚本；真正执行渲染时以目标 script 所在目录为 cwd
        self.skill_dir = Path(__file__).parent.parent
        self.script_dir = self.script_file.parent
        self.check_script = self.skill_dir / 'scripts' / 'check.py'

        self.audio_dir = self.script_dir / 'audio'
        self.audio_info_path = self.audio_dir / 'audio_info.json'
        self.audio_schedule_path = self.audio_dir / 'audio_schedule.json'
        self.audio_list_path = self.script_dir / 'audio_list.csv'

    def run_check(self):
        """步骤 1: 运行代码检查"""
        if self.skip_check:
            print("⚠️  跳过代码检查 (不推荐)")
            return True

        print("🔍 步骤 1/4: 代码结构检查")
        print("=" * 50)

        if not self.check_script.exists():
            print(f"❌ 检查脚本不存在: {self.check_script}")
            return False

        try:
            result = subprocess.run(
                [sys.executable, str(self.check_script), str(self.script_file)],
                cwd=self.script_dir,
                capture_output=False
            )
            return result.returncode == 0
        except Exception as exc:
            print(f"❌ 检查失败: {exc}")
            return False

    def _run_ffprobe_json(self, target_path):
        """调用 ffprobe 并返回 JSON。"""
        try:
            result = subprocess.run(
                [
                    'ffprobe',
                    '-v', 'error',
                    '-show_entries', 'format=duration:stream=index,codec_type,duration',
                    '-of', 'json',
                    str(target_path),
                ],
                capture_output=True,
                text=True,
                check=True,
            )
            return json.loads(result.stdout or '{}')
        except FileNotFoundError:
            print("❌ 未找到 ffprobe，请先安装 ffmpeg。")
            return None
        except Exception as exc:
            print(f"❌ ffprobe 执行失败: {exc}")
            return None

    def _probe_media_duration(self, target_path):
        """获取媒体文件时长。"""
        info = self._run_ffprobe_json(target_path)
        if not info:
            return None

        format_info = info.get('format') or {}
        duration = format_info.get('duration')
        try:
            return float(duration)
        except (TypeError, ValueError):
            return None

    def _analyze_audio_volume(self, video_path):
        """通过 ffmpeg volumedetect 检查音轨是否为纯静音。"""
        try:
            result = subprocess.run(
                [
                    'ffmpeg',
                    '-i', str(video_path),
                    '-vn',
                    '-af', 'volumedetect',
                    '-f', 'null',
                    '-',
                ],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            print("⚠️  未找到 ffmpeg，跳过静音检测。")
            return {'skipped': True, 'silent': False}
        except Exception as exc:
            print(f"⚠️  静音检测失败，已跳过: {exc}")
            return {'skipped': True, 'silent': False}

        output = f"{result.stdout}\n{result.stderr}"
        mean_match = re.search(r'mean_volume:\s*([^\s]+)\s*dB', output)
        max_match = re.search(r'max_volume:\s*([^\s]+)\s*dB', output)
        mean_volume = mean_match.group(1) if mean_match else None
        max_volume = max_match.group(1) if max_match else None
        silent = mean_volume == '-inf' and max_volume == '-inf'

        return {
            'skipped': False,
            'silent': silent,
            'mean_volume': mean_volume,
            'max_volume': max_volume,
        }

    def _load_audio_info(self):
        """读取 audio_info.json。"""
        if not self.audio_info_path.exists():
            return None

        try:
            return json.loads(self.audio_info_path.read_text(encoding='utf-8'))
        except Exception as exc:
            print(f"❌ 读取音频元数据失败: {exc}")
            return None

    def _load_audio_schedule(self):
        """读取 audio_schedule.json。"""
        if not self.audio_schedule_path.exists():
            return None

        try:
            return json.loads(self.audio_schedule_path.read_text(encoding='utf-8'))
        except Exception as exc:
            print(f"❌ 读取音频调度清单失败: {exc}")
            return None

    def _expected_audio_duration(self):
        """读取期望音频总时长。"""
        info = self._load_audio_info()
        if not info:
            return None

        total_duration = info.get('total_duration')
        if isinstance(total_duration, (int, float)) and total_duration > 0:
            return float(total_duration)

        files = info.get('files') or []
        durations = []
        for item in files:
            duration = item.get('duration')
            if isinstance(duration, (int, float)) and duration > 0:
                durations.append(float(duration))

        if durations:
            return sum(durations)
        return None

    def _expected_audio_schedule_end(self):
        """读取统一音频调度清单里的最后结束时间。"""
        schedule = self._load_audio_schedule()
        if not schedule:
            return None

        expected_end_time = schedule.get('expected_end_time')
        if isinstance(expected_end_time, (int, float)) and expected_end_time > 0:
            return float(expected_end_time)

        entries = schedule.get('entries') or []
        end_times = []
        for entry in entries:
            end_time = entry.get('end_time')
            if isinstance(end_time, (int, float)) and end_time > 0:
                end_times.append(float(end_time))

        if end_times:
            return max(end_times)
        return None

    def _audio_dependency_paths(self):
        """收集影响音频结果的输入文件。"""
        paths = []

        for candidate in (self.audio_list_path, self.audio_info_path):
            if candidate.exists():
                paths.append(candidate)

        if self.audio_dir.exists():
            for path in sorted(self.audio_dir.iterdir()):
                if path.is_file() and path.suffix.lower() in self.AUDIO_EXTENSIONS:
                    paths.append(path)

        return paths

    def _latest_mtime(self, paths):
        """获取文件集合中的最新修改时间。"""
        if not paths:
            return None
        return max(path.stat().st_mtime for path in paths if path.exists())

    def _media_output_paths(self):
        """返回 Manim 可能输出的视频路径列表，优先当前质量目录。"""
        media_dir = self.script_dir / 'media' / 'videos' / self.script_file.stem
        quality_dirs = [self.quality]
        quality_dirs.extend(
            quality_dir
            for quality_dir in ('2160p60', '1920p60', '1080p60', '720p30', '480p15')
            if quality_dir != self.quality
        )
        return [media_dir / quality_dir / f'{self.scene_name}.mp4' for quality_dir in quality_dirs]

    def _find_rendered_video(self):
        """查找 Manim 实际生成的视频，优先当前质量，其次选最新文件。"""
        candidates = [path for path in self._media_output_paths() if path.exists()]
        if not candidates:
            return None

        preferred = self.script_dir / 'media' / 'videos' / self.script_file.stem / self.quality / f'{self.scene_name}.mp4'
        if preferred in candidates:
            return preferred
        return max(candidates, key=lambda path: path.stat().st_mtime)

    def _root_video_path(self):
        """项目根目录中的最终视频路径。"""
        return self.script_dir / f'{self.scene_name}.mp4'

    def _find_existing_output_video(self):
        """找到现有成片，用于判断音频是否比成片更新。"""
        root_video = self._root_video_path()
        if root_video.exists():
            return root_video
        return self._find_rendered_video()

    def maybe_enable_disable_caching(self):
        """如果检测到脚本或音频输入较成片更新，则自动禁用缓存。"""
        if self.disable_caching_explicit:
            print("🎧 缓存策略: 已手动启用无缓存渲染")
            return

        dependency_paths = [self.script_file]
        dependency_paths.extend(self._audio_dependency_paths())
        dependency_paths = [path for path in dependency_paths if path.exists()]
        existing_video = self._find_existing_output_video()

        if not dependency_paths:
            print("🎧 缓存策略: 未检测到可比较的脚本/音频输入，保持当前渲染方式")
            return

        if not existing_video:
            print("🎧 缓存策略: 当前无历史成片，首次渲染不强制禁用缓存")
            return

        latest_input_mtime = self._latest_mtime(dependency_paths)
        video_mtime = existing_video.stat().st_mtime if existing_video.exists() else None

        if latest_input_mtime and video_mtime and latest_input_mtime > video_mtime:
            self.disable_caching = True
            print("🎧 缓存策略: 检测到脚本或音频/TTS 输入比当前成片更新，自动启用无缓存渲染")
            print(f"   参考成片: {existing_video}")
        else:
            print("🎧 缓存策略: 当前成片不早于脚本/音频输入，保持当前渲染方式")

    def validate_audio_assets(self):
        """步骤 2: 在渲染前验证音频素材。"""
        print("\n🎵 步骤 2/4: 音频素材检查")
        print("=" * 50)

        info = self._load_audio_info()
        if not info:
            print("⚠️  未找到 audio/audio_info.json，跳过音频素材检查")
            return True

        files = info.get('files') or []
        if not files:
            print("❌ audio_info.json 中没有有效的 files 列表")
            return False

        errors = []
        verified = 0
        for item in files:
            filename = item.get('file') or item.get('filename')
            if not filename:
                errors.append("❌ audio_info.json 存在缺少 file 字段的条目")
                continue

            audio_path = self.audio_dir / filename
            if not audio_path.exists():
                errors.append(f"❌ 缺少音频文件: {audio_path}")
                continue

            duration = self._probe_media_duration(audio_path)
            if duration is None or duration <= 0:
                errors.append(f"❌ 音频时长异常: {audio_path}")
                continue

            verified += 1
            print(f"✓ {filename} - {duration:.2f}s")

        if errors:
            print("\n音频素材检查失败：")
            for error in errors:
                print(error)
            return False

        expected_duration = self._expected_audio_duration()
        if expected_duration:
            print(f"✅ 共校验 {verified} 段音频，总时长约 {expected_duration:.2f}s")
        else:
            print(f"✅ 共校验 {verified} 段音频")
        return True

    def run_render(self):
        """步骤 3: 运行 Manim 渲染"""
        print("\n🎬 步骤 3/4: 渲染视频")
        print("=" * 50)

        if not self.script_file.exists():
            print(f"❌ 脚本文件不存在: {self.script_file}")
            return False

        if self.audio_schedule_path.exists():
            try:
                self.audio_schedule_path.unlink()
            except OSError as exc:
                print(f"⚠️  清理旧 audio_schedule.json 失败，将继续渲染: {exc}")

        cmd = ['manim']
        cmd.extend(['-q', self.quality_flag])

        if self.preview:
            cmd.append('-p')

        if self.disable_caching:
            cmd.append('--disable_caching')

        cmd.extend([str(self.script_file), self.scene_name])

        print(f"执行命令: {' '.join(cmd)}")
        print()

        try:
            result = subprocess.run(cmd, cwd=self.script_dir)
            return result.returncode == 0
        except FileNotFoundError:
            print("❌ 未找到 manim 命令，请确保已安装: pip install manim")
            return False
        except Exception as exc:
            print(f"❌ 渲染失败: {exc}")
            return False

    def copy_to_root(self):
        """拷贝视频到项目根目录并返回最终路径。"""
        print("\n📁 拷贝视频到根目录")
        print("=" * 50)

        video_src = self._find_rendered_video()
        if not video_src:
            print("⚠️  未找到生成的视频文件")
            return None

        video_dst = self._root_video_path()
        try:
            shutil.copy2(video_src, video_dst)
            print(f"✅ 视频已拷贝: {video_dst}")
            print(f"   源文件: {video_src}")
            return video_dst
        except Exception as exc:
            print(f"⚠️  拷贝失败: {exc}")
            return None

    def validate_rendered_audio(self, video_path):
        """步骤 4: 校验成片音轨。"""
        print("\n🔊 步骤 4/4: 校验成片音轨")
        print("=" * 50)

        if not video_path or not Path(video_path).exists():
            print("❌ 成片不存在，无法校验音轨")
            return False

        info = self._run_ffprobe_json(video_path)
        if not info:
            return False

        streams = info.get('streams') or []
        audio_streams = [stream for stream in streams if stream.get('codec_type') == 'audio']
        if not audio_streams:
            print("❌ 成片中没有检测到 audio stream")
            return False

        audio_durations = []
        for stream in audio_streams:
            duration = stream.get('duration')
            try:
                audio_durations.append(float(duration))
            except (TypeError, ValueError):
                continue

        actual_audio_duration = max(audio_durations) if audio_durations else None
        if actual_audio_duration is None or actual_audio_duration <= 0:
            print("❌ 成片音轨时长异常，无法确认真实音轨")
            return False

        expected_duration = self._expected_audio_duration()
        schedule = self._load_audio_schedule()
        schedule_end_time = self._expected_audio_schedule_end()

        if schedule_end_time:
            schedule_tolerance = max(0.8, schedule_end_time * 0.02)
            if actual_audio_duration + schedule_tolerance < schedule_end_time:
                print("❌ 成片音轨未覆盖统一调度清单的最后结束时间")
                print(f"   实际音轨: {actual_audio_duration:.2f}s")
                print(f"   调度末端: {schedule_end_time:.2f}s (容差 {schedule_tolerance:.2f}s)")
                return False
        elif schedule is None:
            print("⚠️  未找到 audio_schedule.json，当前回退为基于总时长的音轨校验")

        if expected_duration:
            tolerance = max(2.0, expected_duration * 0.05)
            if actual_audio_duration + tolerance < expected_duration:
                print("❌ 成片音轨明显短于期望音频总时长")
                print(f"   实际音轨: {actual_audio_duration:.2f}s")
                print(f"   期望下限: {expected_duration:.2f}s (容差 {tolerance:.2f}s)")
                return False

        volume_stats = self._analyze_audio_volume(video_path)
        if volume_stats.get('silent'):
            print("❌ 成片音轨被检测为纯静音")
            return False

        print(f"✅ 成片包含 {len(audio_streams)} 条音轨")
        print(f"✅ 音轨时长: {actual_audio_duration:.2f}s")
        if expected_duration:
            print(f"✅ 期望总时长: {expected_duration:.2f}s")
        if schedule_end_time:
            schedule_entries = (schedule or {}).get('entries') or []
            entry_count = len(schedule_entries)
            print(f"✅ 调度清单条目: {entry_count} 条")
            print(f"✅ 调度末端时间: {schedule_end_time:.2f}s")
            uncovered_scenes = [entry.get('scene') for entry in schedule_entries if entry.get('scene_coverage_ok') is False]
            if uncovered_scenes:
                print(f"⚠️  调度清单显示部分场景的画面覆盖略短于对应音频: {uncovered_scenes}")
                print("   这不代表成片没声，但说明这些场景的画面节奏仍值得再压一遍。")
        if schedule is not None and schedule.get('finalized') is False:
            print("⚠️  audio_schedule.json 标记为未完成，请留意脚本是否在异常中提前退出")
        if not volume_stats.get('skipped'):
            print(
                "✅ 音量检测: "
                f"mean={volume_stats.get('mean_volume')} dB, "
                f"max={volume_stats.get('max_volume')} dB"
            )
        return True

    def render_once(self):
        """执行一轮渲染 + 拷贝 + 音轨校验。"""
        if not self.run_render():
            return False

        final_video = self.copy_to_root()
        if not final_video:
            return False

        return self.validate_rendered_audio(final_video)

    def run(self):
        """运行完整流程"""
        print("\n" + "=" * 50)
        print("🎬 Manim 教学视频渲染流水线")
        print("=" * 50)
        print(f"脚本文件: {self.script_file}")
        print(f"场景类名: {self.scene_name}")
        print(f"渲染质量: {self.quality}")
        print(f"显式禁用缓存: {'是' if self.disable_caching_explicit else '否'}")
        print("=" * 50 + "\n")

        if not self.run_check():
            print("\n⛔ 代码检查失败，终止渲染。")
            print("   请修复错误后重试，或使用 --no-check 跳过检查（不推荐）")
            return False

        if not self.validate_audio_assets():
            print("\n⛔ 音频素材检查失败，终止渲染。")
            return False

        self.maybe_enable_disable_caching()

        if self.render_once():
            print("\n" + "=" * 50)
            print("✅ 渲染完成，音轨校验通过！")
            print("=" * 50)
            return True

        if not self.disable_caching:
            print("\n⚠️  首轮成片音轨校验失败，自动切换为无缓存重渲一次...")
            self.disable_caching = True
            if self.render_once():
                print("\n" + "=" * 50)
                print("✅ 无缓存重渲完成，音轨校验通过！")
                print("=" * 50)
                return True

        print("\n⛔ 成片音轨校验失败。请检查音频素材、脚本调度或缓存状态。")
        return False


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='Manim 教学视频渲染流水线（含音轨守门）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
    python scripts/render.py
    python scripts/render.py -f my_script.py
    python scripts/render.py -s MyScene
    python scripts/render.py -q k
    python scripts/render.py --no-check
    python scripts/render.py --disable-caching
        '''
    )

    parser.add_argument(
        '-f', '--file',
        default='script.py',
        help='要渲染的脚本文件 (默认: script.py)'
    )

    parser.add_argument(
        '-s', '--scene',
        default='MathScene',
        help='场景类名 (默认: MathScene)'
    )

    parser.add_argument(
        '-q', '--quality',
        default='high',
        choices=['l', 'low', 'm', 'medium', 'h', 'high', 'k', '4k'],
        help='渲染质量: l/low(480p), m/medium(720p), h/high(1080p), k/4k(2160p) (默认: high)'
    )

    parser.add_argument(
        '-p', '--preview',
        action='store_true',
        default=True,
        help='渲染后预览 (默认: 开启)'
    )

    parser.add_argument(
        '--no-preview',
        action='store_true',
        help='渲染后不预览'
    )

    parser.add_argument(
        '--no-check',
        action='store_true',
        help='跳过代码检查 (不推荐)'
    )

    parser.add_argument(
        '--disable-caching',
        action='store_true',
        help='显式禁用 Manim 缓存；当刚改过脚本布局、文案或 TTS / 音频时可手动启用'
    )

    args = parser.parse_args()
    preview = not args.no_preview

    pipeline = RenderPipeline(
        script_file=args.file,
        scene_name=args.scene,
        quality=args.quality,
        preview=preview,
        skip_check=args.no_check,
        disable_caching=args.disable_caching
    )

    success = pipeline.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
