---
name: leopohu-tutor
description: |
  一对一辅导老师技能，用于解答数学题，生成HTML讲解文档和带配音的Manim动画视频。
  核心工作流：数学分析 → HTML可视化 → 分镜脚本 → TTS音频 → 验证更新 → 脚手架 → Manim代码 → 渲染验证
  触发条件：学生粘贴数学题图片、需要教学视频、需要HTML讲解资料
---

# LeopohuTutor - 一对一辅导老师

## 核心工作流

```python
WORKFLOW = [
    # 步骤1: 数学建模
    {
        "step": 1,
        "name": "analyze_problem",
        "input": "题目图片/文本",
        "output": "math_analysis.md",
        "tasks": ["推导数学事实", "建立几何模型", "确定图形构建方法"]
    },

    # 步骤2: HTML可视化
    {
        "step": 2,
        "name": "html_visualization",
        "input": "math_analysis.md",
        "output": "数学_{日期}_{题目}.html",
        "tasks": ["SVG画图形", "展示画图过程", "标注关键要素"]
    },

    # 步骤3: 分镜脚本
    {
        "step": 3,
        "name": "storyboard",
        "input": "HTML内容",
        "output": "{日期}_{题目}_分镜.md",
        "tasks": ["定义幕结构(不限制幕数)", "设计画面/字幕/读白", "音频清单(时长留空)"]
    },

    # 步骤4: TTS生成
    {
        "step": 4,
        "name": "generate_tts",
        "input": "分镜脚本",
        "output": "audio/audio_{三位幕号}_{幕名}.wav + audio_info.json",
        "command": "python scripts/generate_tts.py audio_list.csv ./audio --voice xiaoxiao"
    },

    # 步骤5: 验证更新
    {
        "step": 5,
        "name": "validate_audio",
        "input": "分镜.md + audio/",
        "output": "更新后的分镜.md(填充时长) + audio_info.json",
        "command": "python scripts/validate_audio.py 分镜.md ./audio",
        "check": ["音频存在性", "时长>0", "数量匹配"]
    },

    # 步骤6: 脚手架
    {
        "step": 6,
        "name": "scaffold",
        "input": "分镜.md + audio_info.json",
        "output": "script.py (伪代码框架)",
        "template": "templates/script_scaffold.py",
        "must_include": [
            "calculate_geometry() - 几何建模",
            "assert_geometry() - 几何验证(题目条件+精度) + 画布范围检查(边界+中心)",
            "COLORS - 颜色定义",
            "SCENES[] - 幕信息数组(从audio_info.json加载时长)",
            "LAYOUT_ZONES / LAYOUT_SAFE_PAIRS - 几何区/事实区/公式区/right_panel/顶部题目信息区/字幕区安全布局，并显式声明哪些区域绝不能重叠",
            "place_in_zone()/assert_layout_safety()/create_text_panel()/set_problem_context() - 统一布局 helper，并支持顶部两行版课件头（题干常驻 + 当前小问高亮）",
            "register_persistent()/register_transient()/reset_scene() - 分层清场机制",
            "begin_subproblem()/set_fact_board()/set_grouped_fact_board()/reveal_fact_rows() - 跨问结论继承、分组事实板与逐条 reveal 机制",
            "create_text_panel()/reveal_panel_lines()/pulse_fact_with_targets() - 公式区 keyed line、三方联动聚光与节奏控制",
            "ANGLE_LABEL_SLOTS/CALLOUT_LANE_RATIOS/create_angle_annotation() - 角标注预算、自动降级与 callout 自动避让"
        ]
    },

    # 步骤7: 生成代码
    {
        "step": 7,
        "name": "implement",
        "input": "script.py脚手架 + 分镜.md + audio_info.json",
        "output": "完整的script.py",
        "rules": [
            "根据分镜实现每幕动画",
            "读白提到什么就高亮什么",
            "画面时长 >= 音频时长",
            "calculate_geometry()必须完整实现"
        ]
    },

    # 步骤8: 检查与渲染
    {
        "step": 8,
        "name": "check_and_render",
        "input": "script.py",
        "output": "视频文件 + 关键帧截图",
        "command": "python scripts/render.py",
        "check": ["代码结构检查(check.py)", "几何正确性", "高亮同步", "字幕清晰", "动画流畅"],
        "on_fail": "回到步骤7修改代码"
    }
]

# 工作流状态转换
# step1 → step2 → step3 → step4 → step5 → step6 → step7 → step8
#                                          ↑____________↓ (失败时循环)
```

---

## 步骤1：分析题目，推导数学事实

**目标**：建立正确的数学计算方法和流程，形成画出符合数学的图形的方法。

### 输出格式
```markdown
## 数学事实分析

### 已知条件
- 条件1：...
- 条件2：...

### 推导的事实
1. **事实名称**: 描述
   - 计算过程: ...
   - 数学表达: ...

### 图形构建方法
- 点的坐标: ...
- 边的关系: ...
- 圆/弧的定义: ...

### 需要证明的结论
- 结论1: ...
```

**注意**：所有证明题需要证明的结论，在分镜中都可以作为已确立的**事实**来使用。

---

## 步骤2：HTML + SVG 可视化

**目标**：用 HTML + SVG 画出图形，展示画图过程和解答流程，为分镜做规划。
**补充**：如果用户已经提供了准确的HTML文件，描述了画图过程，可以按文件名要求复制一份，跳过生成文件。

### 输出要求
- 文件命名：`数学_{日期}_{题目简述}.html`
- 包含：题目陈述、SVG 图形、分步解答、关键要素标注
- SVG 需要展示**画图过程**（如：先画三角形 → 再画圆 → 标注点）

---

## 步骤3：生成分镜脚本

**目标**：定义视频结构，不限制幕数，结尾预留音频文件名（时长为空）。

### 文件命名
`{日期}_{题目}_分镜.md`

### 分镜脚本结构
```markdown
# 分镜脚本 - {题目名称}

## 分镜设计

### 第1幕：{幕名}
**画面**: ...
**字幕**: ...（简洁，≤20字）
**读白**: ...（详细，口语化）
**动画**: ...
**目的**: ...

---

## 音频生成清单（步骤4填写）

| 幕号 | 文件名 | 读白文本 | 时长 | 说话人 | 情感 |
|------|--------|----------|------|--------|------|
| 1 | audio_001_{幕名}.wav | "读白文本" | | xiaoxiao | 热情 |
| 2 | audio_002_{幕名}.wav | "读白文本" | | xiaoxiao | 平和 |
```

### 关键规范
- 幕号从1开始连续编号
- 文件名格式：`audio_{三位幕号}_{幕名}.wav`
- **时长列为空**，由步骤5填充
- 不限制幕数，根据内容需要决定

### 字幕退场约定（重要）

为了避免动画中文字忘记退场，在分镜的**动画**部分使用以下约定指定退场时机：

```markdown
**动画**:
- 0.0s: 字幕"勾股定理"淡入
- 2.0s: → 字幕退场（或：字幕淡出）
- 3.0s: 图形高亮
```

**退场标记方式**（三选一）：
1. `→` 箭头符号表示退场（推荐，最简洁）
2. `退场:` 或 `淡出:` 显式标记
3. `持续X秒` 指定显示时长

**示例**：
```markdown
**动画**:
- 字幕"正方形性质"淡入，持续3秒 → 自动退场
- 0.0s: 标题淡入 | 3.0s: →
- 公式分步显示，第5秒全部退场
```

### 参考示例
见 `references/storyboard_sample.md` - 第九十九题：证明四点共圆

---

## 步骤4：TTS 生成语音文件

**使用脚本**：`scripts/generate_tts.py`（Edge TTS 推荐）

### 执行命令
```bash
python scripts/generate_tts.py audio_list.csv ./audio --voice xiaoxiao
```

### 读白规则（系统级）
1. CSV 默认使用 `filename,text[,speak_text]` 格式
2. `text` 保留画面显示或原始读白文本，可继续写 `∠AOE` 这类标准数学表达
3. `speak_text` 为可选列；若填写，则直接作为 TTS 朗读文本
4. 若未填写 `speak_text`，脚本会自动做数学读白归一化
   - 当前内置规则：`∠AOE` → `角 A、O、E`，`角AOE` → `角 A、O、E`
   - 目标是避免中文 TTS 把角名直接连读成模糊发音
5. 原则：**显示文本服务画面，朗读文本服务 TTS**，不要为了发音去污染画面上的数学写法

### 输出文件
```
audio/
├── audio_001_开场.wav
├── audio_002_展示图形.wav
├── audio_003_定理证明.wav
├── ...
└── audio_info.json
```

### audio_info.json 格式
```json
{
  "files": [
    {"scene": 1, "file": "audio_001_开场.wav", "text": "设 ∠AOE = 40°", "spoken_text": "设角 A、O、E 等于 40°", "duration": 8.5},
    {"scene": 2, "file": "audio_002_展示图形.wav", "text": "继续看 ∠BOC", "spoken_text": "继续看角 B、O、C", "duration": 15.2}
  ]
}
```

---

## 步骤5：验证并更新分镜时长

**使用脚本**：`scripts/validate_audio.py`

### 功能
1. 读取 `audio/audio_info.json` 获取音频时长
2. 验证所有音频文件存在且时长正常（>0秒）
3. 更新分镜脚本的"音频生成清单"中的时长列
4. 如果缺少音频或时长异常，报错提醒

### 执行命令
```bash
python scripts/validate_audio.py 分镜.md ./audio
```

### 验证失败情况
- 缺少音频文件 → 报错："缺少第X幕音频文件"
- 时长为0或异常 → 报错："第X幕音频时长异常，请检查格式"
- 分镜与音频数量不匹配 → 报错："分镜X幕，音频Y个，数量不匹配"

---

## 步骤6：生成 script.py 脚手架

**使用模板**：`templates/script_scaffold.py`

**输出**：`script.py`（肯定 build 不过的伪代码框架）

**新增要求（系统级，不是单题补丁）**：脚手架必须默认提供固定安全布局区、`persistent / transient` 分层清场机制，以及“跨问事实继承 + 分组事实板 + 事实板逐条 reveal + 公式区 keyed line + 三方联动聚光 + 角标注预算/自动降级 + callout 自动避让”能力。后续题目优先复用这些 helper，不要再靠每道题手工挪公式框、手工清空全场，或把上一问结论硬塞回下一问主图。

### 脚手架必须包含的部分

```python
from manim import *
import json
import os

class MathScene(Scene):
    """
    数学教学视频场景 - 脚手架
    根据分镜脚本和音频信息生成完整动画
    """

    # ========== 1. 颜色定义 ==========
    COLORS = {
        'background': '#1a1a2e',      # 深蓝背景
        'primary': '#4ecca3',          # 主色（青色）
        'secondary': '#e94560',        # 辅助色（红色）
        'highlight': '#ffc107',        # 高亮色（黄色）
        'text': '#ffffff',             # 文字白色
        'grid': '#2a2a4e',             # 网格线
    }

    # ========== 2. 幕信息数组（供AI参考） ==========
    # 格式: (幕号, 幕名, 音频文件名, 时长秒数)
    # 注意：时长从 audio_info.json 读取，确保画面等待音频原则
    SCENES = [
        (1, "开场", "audio_001_开场.wav", None),
        (2, "展示图形", "audio_002_展示图形.wav", None),
        # ... 根据分镜动态生成
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # 加载音频时长信息
        self.audio_timings = self._load_audio_timings()

    def _load_audio_timings(self):
        """从 audio_info.json 加载音频时长"""
        # TODO: AI实现 - 读取JSON并填充 SCENES 的时长
        pass

    # ========== 3. 几何计算函数 ==========
    def calculate_geometry(self):
        """
        计算所有几何元素的位置和属性

        从步骤2的HTML画图中提取信息，建立数学模型：
        - 所有点的坐标 (x, y) - ⚠️ 始终使用2D，z坐标始终为0
        - 边的长度和方程
        - 圆/弧的圆心和半径
        - 交点计算
        - 切线、法线等辅助线

        返回: dict 包含所有几何对象的数据
        """
        # TODO: AI根据题目几何关系实现
        geometry = {
            'points': {},      # {'A': (x, y), 'B': (x, y), ...}
            'lines': {},       # {'AB': {'start': A, 'end': B, 'length': L}, ...}
            'circles': {},     # {'circle1': {'center': O, 'radius': r}, ...}
            'arcs': {},        # 圆弧定义
        }
        return geometry

    # ========== 4. 几何验证函数 ==========
    def assert_geometry(self, geometry):
        """
        验证几何计算的正确性（最小验证原则）

        验证内容：
        1. 题目给定的事实（如：两条边相等，谁是谁的一半）
        2. 精度问题：使用相对误差比较，而非绝对相等
        3. 画布范围检查：确保图形在可视区域内
        4. 错误提示：所有assert必须用中文描述问题，包含具体数值和修复建议

        === 几何条件验证 ===
        基于题目给定的条件，编写最小但关键的验证：
        - 如果题目说 AB = BC，验证 |AB - BC| < epsilon
        - 如果题目说 E 是中点，验证 AE = EB（考虑浮点误差）
        - 如果题目说某角是直角，验证向量点积接近0
        - 如果题目给具体数值（如边长为5），验证计算结果匹配

        精度建议：
        - 相对误差：1e-6 或绝对误差 1e-4
        - 示例：assert abs(len_AB - len_BC) < 1e-4, "中文错误提示：AB长度不等于BC长度"

        === 画布范围验证算法 ===
        目标：确保整个图形在画布内，且位于视觉中心区域

        算法步骤（AI需要根据几何数据实现）：
        1. 计算所有几何元素的外接矩形 bounding_box
           - 遍历所有点、线、圆的边界点
           - 取最小x, 最大x, 最小y, 最大y

        2. 验证矩形在画布范围内（考虑边距）
           - 画布默认范围：FRAME_WIDTH=14.2, FRAME_HEIGHT=8
           - 建议边距：四周各留 0.5-1.0 单位
           - 验证：min_x > -7+margin 且 max_x < 7-margin
                   min_y > -4+margin 且 max_y < 4-margin

        3. 验证矩形中心在视觉中心区域
           - 画布中心：(0, 0)
           - 视觉中心区域：中心 ±20%（即 x∈[-1.4, 1.4], y∈[-0.8, 0.8]）
           - 计算矩形中心：(center_x, center_y) = ((min_x+max_x)/2, (min_y+max_y)/2)
           - 验证：center_x ∈ [-1.4, 1.4] 且 center_y ∈ [-0.8, 0.8]

        4. 如果图形超出范围，AI需要调整几何计算的缩放或平移
        """
        # === TODO: AI实现 - 基于题目条件的验证（失败时用中文报错）===
        # 示例代码（根据实际题目修改）：
        # epsilon = 1e-4
        # len_ab = geometry['lines']['AB']['length']
        # len_bc = geometry['lines']['BC']['length']
        # assert abs(len_ab - len_bc) < epsilon, f"几何验证失败：AB长度({len_ab:.4f})不等于BC长度({len_bc:.4f})，题目要求两边相等"
        #
        # len_ae = geometry['lines']['AE']['length']
        # len_ab = geometry['lines']['AB']['length']
        # assert abs(len_ae * 2 - len_ab) < epsilon, f"几何验证失败：E不是AB中点，AE({len_ae:.4f})*2={len_ae*2:.4f} != AB({len_ab:.4f})"

        # === TODO: AI实现 - 画布范围检查（失败时用中文报错）===
        # 1. 计算bounding_box
        #    all_points = list(geometry['points'].values())
        #    min_x = min(p[0] for p in all_points)
        #    max_x = max(p[0] for p in all_points)
        #    min_y = min(p[1] for p in all_points)
        #    max_y = max(p[1] for p in all_points)
        #
        # 2. 验证画布边界（失败时报具体数值）
        #    margin = 0.5
        #    assert min_x > -7 + margin, f"画布验证失败：图形左边界(min_x={min_x:.2f})超出安全区域(>{-7+margin})，需要向右平移或缩小"
        #    assert max_x < 7 - margin, f"画布验证失败：图形右边界(max_x={max_x:.2f})超出安全区域(<{7-margin})，需要向左平移或缩小"
        #    assert min_y > -4 + margin, f"画布验证失败：图形下边界(min_y={min_y:.2f})超出安全区域(>{-4+margin})，需要向上平移或缩小"
        #    assert max_y < 4 - margin, f"画布验证失败：图形上边界(max_y={max_y:.2f})超出安全区域(<{4-margin})，需要向下平移或缩小"
        #
        # 3. 验证视觉中心（失败时报具体偏移）
        #    center_x = (min_x + max_x) / 2
        #    center_y = (min_y + max_y) / 2
        #    assert -1.4 <= center_x <= 1.4, f"视觉中心验证失败：图形中心X={center_x:.2f}超出视觉中心区域[-1.4, 1.4]，建议调整几何计算使图形居中"
        #    assert -0.8 <= center_y <= 0.8, f"视觉中心验证失败：图形中心Y={center_y:.2f}超出视觉中心区域[-0.8, 0.8]，建议调整几何计算使图形居中"

        pass

    # ========== 5. 图形元素定义 ==========
    def define_elements(self, geometry):
        """
        定义 Manim 图形对象（但不创建动画）

        为每一幕需要的图形元素预先定义，便于结构化调用：
        - 点、线、圆的基础对象
        - 高亮效果对象
        - 标注文字对象
        """
        # TODO: AI根据分镜需求定义
        elements = {
            'points': {},      # Mobject 点对象
            'lines': {},       # Mobject 线对象
            'circles': {},     # Mobject 圆对象
            'labels': {},      # 标签文字
        }
        return elements

    # ========== 6. 构造主流程 ==========
    def construct(self):
        """主构造流程"""
        # 计算几何
        geometry = self.calculate_geometry()
        self.assert_geometry(geometry)
        elements = self.define_elements(geometry)

        # 设置背景
        self.camera.background_color = self.COLORS['background']

        # 按幕执行
        for scene_num, scene_name, audio_file, duration in self.SCENES:
            self.play_scene(scene_num, scene_name, audio_file, duration, elements, geometry)

    def play_scene(self, scene_num, scene_name, audio_file, duration, elements, geometry):
        """
        播放单幕动画 - 必须添加音频

        ========== 音频集成（强制要求） ==========
        每幕必须添加对应的音频文件，否则视频将没有声音！

        方式：在方法第一行就添加音频
            self.add_sound(f"audio/{audio_file}")

        注意：
        - audio_file 参数已经包含文件名（如 "audio_001_开场.wav"）
        - 音频文件位于 audio/ 目录下
        - 添加音频后，后续动画时长应 >= duration（音频时长）

        ========== 画面等待音频原则 ==========
        - 动画总时长 >= 音频时长（duration 参数）
        - 可以画面多等待（多出静音部分，后期可剪辑）
        - 不能画面比音频短（会导致音频被截断）

        ========== 高亮规范（必须在读白提到时同步） ==========
        - 提到某个边等于某个边 → 用动画高亮两条边
        - 提到某个点/圆 → 闪烁或放大高亮
        - 提到证明结论 → 用框或颜色强调

        ========== 绘制策略 ==========
        - 简单图形：直接显示，然后高亮关键部分
        - 复杂图形：逐步绘制，边画边讲解
        """
        # TODO: AI实现 - 第一行必须添加音频！
        # self.add_sound(f"audio/{audio_file}")
        pass

    # ========== 7. 音频集成 ==========
    def add_audio_to_scene(self, audio_file, animation_duration):
        """
        添加音频到场景

        方式1（推荐）：在script.py中直接添加音频文件
        self.add_sound(audio_file)

        方式2：如果需要在特定时间点触发，使用延时

        确保：animation_duration >= 音频实际时长
        """
        # TODO: AI实现音频集成
        pass

    
```

---

## 步骤7：AI 生成最终代码

**输入**：
- 分镜脚本（已更新时长）
- `audio/audio_info.json`
- `script.py` 脚手架

**输出**：完整的 `script.py`

**AI 生成指导**：
1. 根据分镜的"动画"描述实现具体动画代码
2. 根据"读白"内容确定高亮时机
3. 实现 `calculate_geometry()` 的具体计算
4. 实现 `assert_geometry()` 的验证逻辑
5. 为每幕实现 `play_scene_X()` 方法
6. **音频集成（必须）**：
   - 每幕的第一行必须是 `self.add_sound(f"audio/{audio_file}")`
   - 确保动画总时长 >= 音频时长（使用 `duration` 参数）
   - 如果动画太短，添加 `self.wait()` 来延长
7. 验证音频文件路径正确：`audio/audio_001_XXX.wav`
8. **字幕显示与退场（关键）**：
   - 使用脚手架提供的 `show_subtitle_timed(text, duration)` 方法显示定时字幕
   - 或使用 `show_subtitle_with_audio(text, audio_duration)` 让字幕持续到音频结束
   - 分镜中的 `→` 或 `退场:` 标记表示文字需要在该时间点淡出
   - **必须确保所有文字元素都有退场动画**，避免残留到下一幕
9. **统一安全布局（关键）**：
   - 几何主图先组装成 `VGroup`，再 `place_in_zone(group, "geometry")`
   - `construct()` 开头优先调用 `assert_layout_safety()`，提前拦截 `geometry` 与 `facts` / `formula` / `right_panel` 的重叠
   - 上一问结论、当前问图内放不下的代数关系，优先放入 `set_fact_board(...)` 或 `set_grouped_fact_board(...)`
  - 若右侧信息密度偏高，优先改用 `create_text_panel(..., zone_name="right_panel")` 做单面板，不要硬堆 facts + formula 双卡片；若这个面板会跨多幕持续更新，优先走 `set_named_panel(panel_name, ...)` / `clear_named_panel(...)` 做同槽位替换
  - 公式、提示、结论统一用 `create_text_panel(..., zone_name="formula"/"summary")`；切到总结页或需要纯净画面时，可补一层 `purge_zone_residue("facts", "formula", "right_panel")` 兜底清孤儿对象

   - 事实板里要延后出现的条目，优先写成 `visible=False`，再用 `reveal_fact_rows(...)` 按节奏逐条放出
   - 公式区里要跟着讲解推进的行，优先加 `key`，再用 `reveal_panel_lines(...)` 单独揭示
  - 幕内临时元素必须 `register_transient(...)`，幕切换由 `reset_scene()`/`clear_transients()` 收口；清场时优先回收登记的根对象，只有根对象不在场景里时才兜底回收 family 子元素，并在 FadeOut 后强制 `remove(root + family)`，避免板子描边或旧文本残留
  - 多问题切换时用 `begin_subproblem(...)`，不要手工保留一堆旧角标；若当前问不沿用上一问的事实板，应由 helper 主动清掉旧 fact board

   - 关键事实出现后，优先用 `pulse_fact_with_targets(...)` 把事实板条目、图中角弧 / 扇形 / callout、以及对应公式行同步点亮
   - 顶点附近多个角标签优先走 `create_angle_annotation(..., mode="auto")`，超过预算后自动降级为 callout 或事实板
   - 同侧多个 callout 必须配合 `CALLOUT_LANE_RATIOS` 或等价车道机制自动避让，并尽量使用分轨折线减少连线交叉
   - **禁止** 使用 `FadeOut(self.mobjects)` 或遍历 `self.mobjects` 的整场清理写法

---

## 步骤8：代码检查与渲染

### 8.1 代码结构检查（必须）

**使用脚本**：`scripts/check.py`

在渲染之前，必须先检查代码是否包含必要的函数和结构：

```bash
# 检查 script.py（默认）
python scripts/check.py

# 检查指定文件
python scripts/check.py my_script.py
```

**检查内容**：
1. ✅ `calculate_geometry()` - 几何计算函数是否存在
2. ✅ `assert_geometry()` - 几何验证函数是否存在
3. ✅ `define_elements()` - 图形元素定义函数是否存在
4. ✅ `LAYOUT_ZONES`、`place_in_zone()`、`register_transient()` 等布局/清场 helper 是否具备
5. ✅ `begin_subproblem()`、`set_fact_board()`、`set_grouped_fact_board()`、`reveal_fact_rows()`、`reveal_panel_lines()`、`pulse_fact_with_targets()`、`create_angle_annotation()` 等跨问继承 / 逐条 reveal / 联动高亮 / 标注预算 helper 是否具备
6. ✅ `CALLOUT_LANE_RATIOS` 或等价 callout 自动避让与分轨连线配置是否具备
7. ✅ 是否有 `add_sound()` 调用（音频集成）
8. ✅ 是否有继承 `Scene` 的类
9. ✅ 是否出现 `FadeOut(self.mobjects)` / `for m in self.mobjects` 这类高风险整场清理写法

**检查结果**：
- ❌ 错误：必须修复，否则无法渲染
- ⚠️ 警告：建议修复，但不会阻止渲染

### 8.2 渲染视频

#### 方式1：使用渲染脚本（推荐，包含检查）

```bash
# 完整流程：检查 -> 音频素材检查 -> 记录音频调度 -> 渲染 -> 成片音轨校验 -> 拷贝到根目录
python scripts/render.py

# 渲染脚本会自动：
# 1) 校验 audio/audio_info.json 中登记的音频文件是否真实存在且时长正常
# 2) 在渲染过程中输出 audio/audio_schedule.json，记录每段音频的开始/结束时间
# 3) 在每幕清场前自动补足剩余音频尾部，避免画面比声音先结束
# 4) 若检测到脚本或音频/TTS 输入比当前成片更新，则自动启用无缓存渲染
# 5) 渲染后优先按 audio_schedule.json 校验 mp4 是否真的覆盖到最后一段音频
# 6) 若首轮校验失败，自动再做一次无缓存重渲

# 如果你想手工强制无缓存，也可以显式指定
python scripts/render.py --disable-caching

# 指定文件和场景
python scripts/render.py -f script.py -s MathScene

# 指定渲染质量
python scripts/render.py -q h    # 1080p60 (默认)
python scripts/render.py -q k    # 4K
python scripts/render.py -q m    # 720p30

# 跳过检查（不推荐，仅用于快速测试）
python scripts/render.py --no-check
```

#### 方式2：直接使用 manim（跳过检查，不推荐）

```bash
manim -pqh script.py MathScene
```

### 提取关键帧验证
```bash
python scripts/extract_frames.py media/videos/script/1080p60/MathScene.mp4 --interval 5
```

### 验证内容
1. 几何图形是否正确（点、线、圆位置）
2. 高亮是否与讲解同步
3. 字幕是否清晰可读
4. 动画是否流畅
5. **音频是否正确添加**：
   - 成片中真实存在 audio stream，而不是只有 video stream
   - 若存在 `audio/audio_schedule.json`，音轨必须覆盖到调度清单里的最后结束时间
   - 若没有 schedule，至少也不能明显短于 `audio_info.json` 的期望总时长
   - 若可用 `ffmpeg`，进一步排查“有音轨但其实全静音”的情况
   - 音频与分镜中的读白内容一致

### 渲染后必须执行
```python
# 在construct()最后添加：拷贝视频到根目录
import shutil
import os
from pathlib import Path

# 渲染完成后拷贝到根目录
video_src = Path("media/videos/script/1920p60/SquareTriangleProblem.mp4")
video_dst = Path("最终视频.mp4")
if video_src.exists():
    shutil.copy2(video_src, video_dst)
    print(f"✓ 视频已拷贝到: {video_dst}")
```

**规则：渲染完成后必须将视频拷贝到项目根目录**，不要留在media/深处。

### 如果发现问题
- 回到步骤7修改代码
- 重新渲染验证

---

## 数学解题原则（绝对重要）

### ❌ 禁止使用坐标系
**绝不用坐标系来求解**，应该用各种定义和推理。

**错误示例**（坐标法）：
```
设B=(0,0), C=(5,0), A=(1.8, 2.4)...
面积 = ½ × 底 × 高
```

**正确示例**（几何推理）：
```
1. 由勾股定理：BC = √(AB² + AC²) = 5
2. 正方形性质：BE = BC = 5
3. 等积变换：S△ABE = S△ABC × (EB/BC) × sin(∠ABE)/sin(∠ABC)
4. 或用向量叉积、海伦公式等纯几何方法
```

**允许的可视化辅助**：
- 为了动画展示可以显示坐标，但解题过程不能用坐标计算
- 可以用几何画板的思路：旋转、平移、对称等变换

### 推荐的几何推理方法
1. **等积变换** - 同底等高、等底同高
2. **相似三角形** - 比例关系
3. **勾股定理** - 边长关系
4. **向量/叉积** - 纯几何意义的运算
5. **旋转/对称** - 几何变换

---

## 文件结构

```
leopohu_tutor/
├── SKILL.md                          # 本文件 - 工作流程定义
├── requirements.txt                  # Python 依赖
├── references/
│   └── storyboard_sample.md          # 分镜脚本示例（参考）
├── templates/
│   └── script_scaffold.py            # Manim 脚手架模板（含安全布局区 + 分层清场 + 分组事实板 + 角标注预算 + callout 避让）
├── scripts/
│   ├── generate_tts.py               # TTS 生成脚本
│   ├── validate_audio.py             # 音频验证脚本
│   ├── check.py                      # 代码结构检查脚本（渲染前必执行）
│   └── render.py                     # 渲染流水线脚本（检查 + 音轨守门 + 渲染 + 拷贝）
└── sample/                           # 示例项目（保留参考）
    └── geometry_proof/
```

---

## 依赖管理

使用 `uv` 管理依赖：

```bash
# 创建虚拟环境
uv venv .venv

# 安装依赖
uv pip install -r requirements.txt

# 激活环境
source .venv/bin/activate
```

---

## 绕过LaTeX依赖（重要）

Manim默认需要LaTeX来渲染数学公式。如果不想安装LaTeX，**全部使用Text替代MathTex**：

```python
# ❌ 需要LaTeX
MathTex(r"BC^2 = AB^2 + AC^2")
MathTex(r"\frac{1}{2} \times 5")
MathTex("A")  # 甚至连字母都需要LaTeX

# ✅ 不需要LaTeX
Text("BC² = AB² + AC²", font_size=36)
Text("½ × 5", font_size=30)
Text("A", font_size=32)  # 用Text直接显示字母
```

**常用替换对照表**：

| 数学符号 | LaTeX写法 | 无LaTeX写法 |
|---------|----------|------------|
| 上标 | `x^2` | `x²` (直接输入Unicode) |
| 分数 | `\frac{1}{2}` | `½` 或 `1/2` |
| 度数 | `90^\circ` | `90°` |
| 平方厘米 | `\text{cm}^2` | `cm²` |
| 根号 | `\sqrt{25}` | `√25` |
| 角度 | `\angle A` | `∠A` |

**脚手架默认不使用MathTex**，如需数学公式请直接输入Unicode字符。

---

## 关键原则总结

| 原则 | 说明 |
|------|------|
| **数学先行** | 先建立正确的数学模型，再画图 |
| **音频必填** | 每幕必须调用 `self.add_sound()`，否则视频无声音 |
| **音画同步** | 画面等待音频（动画时长 >= 音频时长），确保讲解和动画同步 |
| **高亮对应** | 配音提到什么，画面高亮什么 |
| **最小验证** | `assert_geometry` 验证题目条件(带精度) + 画布范围(边界+中心) |
| **逐步抽象** | 从 HTML 可视化 → 分镜脚本 → Manim 代码 |
