## Description: <br>
AgentQL lets agents use the OOMOL oo CLI connector to query webpages, create AgentQL Tetra browser sessions, and retrieve AgentQL usage and session telemetry. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external agent users use AgentQL to run OOMOL-connected AgentQL actions for structured web extraction, remote browser session creation, and usage or session telemetry. The skill guides agents to inspect live connector schemas before building payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The setup path can run a remote oo CLI installer script. <br>
Mitigation: Install the oo CLI only after trusting OOMOL and reviewing the official installer; avoid running installer commands automatically. <br>
Risk: State-changing AgentQL actions such as create_browser_session can create remote browser sessions. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>
Risk: AgentQL queries, target webpages, session metadata, usage data, and connected account credentials are handled through OOMOL or AgentQL services. <br>
Mitigation: Avoid submitting sensitive data unless the user approves the external service handling and account connection. <br>


## Reference(s): <br>
- [AgentQL homepage](https://www.agentql.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub AgentQL release](https://clawhub.ai/oomol/oo-agentql) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance, Configuration] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data plus meta.executionId; live schemas should be inspected before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
