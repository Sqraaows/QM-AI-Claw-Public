---
name: 517-volunteer-organizer
description: 高校志愿服务数据整理 — 按学院/组织拆分活动记录，支持 CSV 和 Excel 输入
---

# 517 — 志愿服务数据整理技能包

将高校志愿服务活动的 Excel/CSV 台账按学院（或组织）拆分，每个学院生成独立的 `.txt` 汇总文件。

## 文件结构

```
517/
├── SKILL.md          # 技能定义（本文件）
├── README.md          # 使用说明
├── data.csv           # 输入数据样例（CSV 格式）
├── process.py         # Python 版处理脚本
├── process.ps1        # PowerShell 版处理脚本
├── 工作簿1.xlsx       # 输入数据样例（Excel 格式）
└── 学院文件/           # 输出目录（运行后生成）
    ├── 经济学院.txt
    ├── 法学院.txt
    └── ...
```

## 处理逻辑

1. 读取 CSV 或 Excel 中的活动记录（日期、学院/组织、活动名称）
2. 按学院/组织名称分组
3. 为每个学院生成一个文本文件，包含该学院的所有活动条目

## 使用方式

### Python
```bash
# 修改 process.py 中的 csv_path 为实际路径
python process.py
```

### PowerShell（需 ImportExcel 模块）
```powershell
# 安装依赖
Install-Module -Name ImportExcel -Scope CurrentUser

# 修改 process.ps1 中的路径后运行
.\process.ps1
```

## 数据格式

### 输入
| 列 | 含义 |
|----|------|
| P1 | 日期（如 45789=Excel 序列号，或 "5月12日-5月15日"） |
| P2 | 学院/组织名称 |
| P3 | 活动描述 |

### 输出
每个学院一个 `.txt` 文件，格式：
```
学院/组织：经济学院
日期：45789	活动：防灾减灾日宣传志愿活动、石家庄站文明引导志愿活动
```
