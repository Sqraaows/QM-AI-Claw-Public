import csv
import os
import re

csv_path = r'D:\517\data.csv'
output_dir = r'D:\517\学院文件'
os.makedirs(output_dir, exist_ok=True)

with open(csv_path, 'r', encoding='utf-8') as f:
    reader = csv.reader(f)
    rows = list(reader)

# Skip header rows (first 3 rows are TYPE, blank, and header)
data_rows = rows[3:]

# Group by college (P2 index = 1)
colleges = {}
for row in data_rows:
    p1 = row[0].strip() if len(row) > 0 and row[0] else ''
    p2 = row[1].strip() if len(row) > 1 and row[1] else ''
    p3 = row[2].strip() if len(row) > 2 and row[2] else ''
    
    if not p2:
        # Try to use previous college name for continuation rows
        continue
    
    if p2 not in colleges:
        colleges[p2] = []
    colleges[p2].append((p1, p3))

for college, entries in colleges.items():
    safe_name = re.sub(r'[\\/:*?"<>|]', '_', college)
    filepath = os.path.join(output_dir, f'{safe_name}.txt')
    
    lines = [f'学院/组织：{college}\n']
    for date, activity in entries:
        lines.append(f'日期：{date}\t活动：{activity}\n')
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.writelines(lines)
    print(f'已创建：{filepath}')

print(f'\n共处理 {len(colleges)} 个学院/组织')
