# 517 — 志愿服务数据整理工具

> 将高校志愿服务台账按学院/组织自动拆分，生成独立汇总文件。

## 适用场景

- 学校青年志愿者协会每月/每周整理各学院志愿活动记录
- 从 Excel 或 CSV 台账中按学院维度拆分数据
- 批量生成各学院的活动汇总文本

## 快速开始

### 方法一：Python

```bash
# 1. 修改 process.py 中的路径（第 5-6 行）
csv_path = r'D:\你的路径\data.csv'
output_dir = r'D:\你的路径\学院文件'

# 2. 运行
python process.py
```

### 方法二：PowerShell

```powershell
# 1. 安装 ImportExcel 模块（首次使用）
Install-Module -Name ImportExcel -Scope CurrentUser

# 2. 修改 process.ps1 中的路径后运行
.\process.ps1
```

## 输入格式

CSV/Excel 文件包含三列核心字段：

| 列名 | 内容 | 示例 |
|------|------|------|
| P1 | 日期 | 45789（Excel 日期序列号）或 "5月12日-5月15日" |
| P2 | 学院/组织名称 | 经济学院、法学院、爱心之家 |
| P3 | 活动名称 | 防灾减灾日宣传志愿活动 |

## 输出示例

`学院文件/经济学院.txt`：
```
学院/组织：经济学院
日期：45789	活动：防灾减灾日宣传志愿活动、石家庄站文明引导志愿活动
日期：45790	活动：附中协助志愿活动
日期：45793	活动：社团志愿活动
```

## 依赖

- **Python 版**：标准库（csv, os, re），无需额外安装
- **PowerShell 版**：[ImportExcel](https://github.com/dfinke/ImportExcel) 模块

## 注意事项

- 日期字段可能为 Excel 序列号（如 45789），如需可读日期需额外转换
- 文件名中的特殊字符（`\ / : * ? " < > |`）会被自动替换为下划线
- 首 3 行作为表头自动跳过
