## Description: <br>
M5Stack official-knowledge support and development assistant for product specifications, pins, SKUs, power and electrical characteristics, selection comparisons, compatibility, troubleshooting, and Arduino, UIFlow/UIFlow2, MicroPython, ESP-IDF, ESPHome, and Home Assistant integration questions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[yuyun2000](https://clawhub.ai/user/yuyun2000) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, engineers, and technical support users use this skill to retrieve M5Stack product and development information from the M5Stack MCP service and turn it into actionable answers, code guidance, configuration steps, and troubleshooting workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Lookup questions are sent to M5Stack's MCP service. <br>
Mitigation: Do not include secrets, credentials, private logs, or proprietary code in queries unless sharing that content with the service is acceptable. <br>
Risk: The MCP service may be unavailable or may not confirm a requested product detail. <br>
Mitigation: State when official material is unavailable or unconfirmed and direct users to M5Stack documentation or official M5Stack repositories for manual verification. <br>


## Reference(s): <br>
- [M5Stack Arduino Programming Reference](references/quick-reference.md) <br>
- [M5Stack Documentation](https://docs.m5stack.com) <br>
- [M5Stack GitHub](https://github.com/m5stack) <br>
- [M5Stack MCP Service](https://mcp.m5stack.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline code and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Answers should be grounded in retrieved M5Stack MCP results and should identify uncertainty when official material does not confirm a detail.] <br>

## Skill Version(s): <br>
1.0.4 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
