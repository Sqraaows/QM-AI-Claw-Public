## Description: <br>
Apify (apify.com). Use this skill for Apify requests that search, read, inspect, or run Apify resources through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Apify through an OOMOL-connected account, including actor metadata lookup, account introspection, actor run status checks, dataset item retrieval, and actor execution with JSON input. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Actor execution can create external side effects, incur costs, or trigger network activity through the connected Apify account. <br>
Mitigation: Require explicit approval before run_actor use after the agent shows the actor ID, input payload, expected effect, and possible cost or external network behavior. <br>
Risk: The skill requires a connected Apify account through OOMOL. <br>
Mitigation: Install and use it only when the account owner accepts agent access to that connection and reviews state-changing actions before execution. <br>


## Reference(s): <br>
- [ClawHub Apify skill page](https://clawhub.ai/oomol/oo-apify) <br>
- [Apify homepage](https://apify.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_actor action reference](actions/get_actor.md) <br>
- [get_current_user action reference](actions/get_current_user.md) <br>
- [get_dataset_items action reference](actions/get_dataset_items.md) <br>
- [get_run action reference](actions/get_run.md) <br>
- [run_actor action reference](actions/run_actor.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill guides use of live connector schemas and returns connector responses as JSON data with execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
