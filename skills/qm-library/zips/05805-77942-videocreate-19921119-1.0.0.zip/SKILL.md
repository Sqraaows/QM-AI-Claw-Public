---
name: img2vid-prompts
description: "AI图生视频（Image-to-Video）提示词生成技能。基于 aiandcivilization/Img2Vid-Prompts 开源库，掌握图生视频提示词的核心结构、电影级运镜技巧与视觉特效术语，为 ImagenVideo、RunwayML Gen-2/Gen-3、Pika Labs、可灵、即梦等图生视频模型生成高质量提示词。**【强制】每次生成必须同时输出中英文双语提示词**，英文版用于 Runway/Pika/Sora 等，中文版用于可灵/即梦/通义等国产平台。触发词：图生视频、img2vid、image-to-video、视频提示词、图转视频、动态视频、让图片动起来。"
---

# 图生视频提示词生成器 — Img2Vid Prompt Expert

深度学习自 [aiandcivilization/Img2Vid-Prompts](https://github.com/aiandcivilization/Img2Vid-Prompts) 开源指南，掌握图生视频提示词的核心结构模式、电影级运镜语言与视觉特效术语体系。

## 核心能力

当用户要求"让图片动起来"、"图生视频"、"生成视频提示词"等需求时，基于用户提供的图片描述和期望的动态效果，**【强制】同时生成英文版和中文版双语提示词**，英文版用于 RunwayML、Pika Labs、Sora、Imagen Video 等，中文版用于可灵、即梦、通义等国产平台。

## 与文生图提示词的关键区别

图生视频 ≠ 文生图！核心差异：

| 维度 | 文生图 | 图生视频 |
|------|--------|---------|
| 起始点 | 从零生成 | **基于已有图片延伸** |
| 核心描述 | 外观+风格+构图 | **运动+变化+时间流** |
| 关键词类型 | 静态美学词 | **动作动词+运镜+时序** |
| 时长意识 | 无 | **短片段（几秒），非电影** |
| 叠加层 | 色彩/光影/构图 | 色彩/光影/构图 + **运镜+特效** |

## 图生视频提示词五层结构

- **第1层：基础图片描述（隐含）** → 由输入图片决定，AI已理解起点
- **第2层：运动描述（核心！）** → 动词+副词，什么动、怎么动
- **第3层：运镜语言** → 相机如何运动（平移/俯仰/推拉/航拍等）
- **第4层：风格与氛围** → 艺术风格、色调、光照、整体氛围
- **第5层：电影特效与术语** → 后期特效、时间操控、聚焦技术

### 各层详解

#### 第2层：运动描述（提示词的核心）

这是图生视频提示词最重要的部分。**必须使用动词和副词**描述运动：

- 人物动作："Subject slowly turns head..." / "The man flexes his muscles..."
- 自然运动："Water ripples gently..." / "Wind rustles the leaves..."
- 相机相关运动："Camera pans left..." / "Camera circles around..."
- 物理现象："Explosion erupts..." / "Flames engulf..."
- 环境变化："Clouds drift across the sky..." / "Mist swirls around..."

#### 第3层：运镜语言

| 运镜术语 | 英文 | 效果 |
|---------|------|------|
| 水平摇摄 | Pan (left/right) | 水平视角扫描 |
| 垂直摇摄 | Tilt (up/down) | 垂直视角扫描 |
| 推拉变焦 | Zoom (in/out) | 改变焦距 |
| 轨道推进 | Dolly (forward/backward) | 摄像机整体前后移动 |
| 跟踪拍摄 | Tracking Shot | 跟随移动主体 |
| 升降拍摄 | Crane Shot | 垂直升降摄像机 |
| 航拍 | Aerial Shot | 无人机俯视视角 |
| 倾斜构图 | Dutch Angle | 倾斜画面营造不安感 |
| 第一人称 | POV | 角色主观视角 |
| 过肩拍摄 | Over-the-Shoulder (OTS) | 越过一人肩膀看另一人 |
| 快速摇摄 | Whip Pan | 快速水平甩镜头 |
| 静态镜头 | Static | 相机不动 |

#### 第4层：风格与氛围

与文生图共享，但需额外考虑时间维度：

- "...in the style of a Ghibli film." / "...吉卜力动画风格。"
- "...with a dark, gritty aesthetic." / "...暗黑粗粝美学。"
- "...using vibrant, saturated colors." / "...鲜艳饱和的色彩。"
- "...with dramatic, low-key lighting." / "...戏剧性低调光照。"
- "...hyperrealistic and detailed." / "...超写实精细。"
- "...1980s film grain." / "...1980年代胶片颗粒感。"

#### 第5层：电影特效术语

**时间操控类：** Slow Motion（慢动作）/ Fast Motion（快动作）/ Time-Lapse（延时摄影）/ Freeze Frame（定格画面）

**运动特效类：** Shaky Cam（手持震动）/ Camera Shake（镜头震动）/ Motion Blur（运动模糊）/ Zoom Transitions（快速变焦过渡）

**视觉特效类：** Glitch Effects（故障效果）/ Flickering（闪烁）/ Deep Focus（深焦）/ Shallow Focus（浅景深）/ Lens Flare（镜头眩光）/ God Rays（丁达尔光）/ Particle Systems（粒子系统）/ Volumetric Lighting（体积光）

**后期调色类：** Color Grading / LUTs（色彩分级）/ Film Emulation（胶片模拟）/ Desaturated Color Palette（去饱和调色板）/ Muted Colors（柔和色调）/ Cinematic Filters（电影滤镜）

## 场景分类与示例

完整案例库见 references/sample-prompts.md，覆盖以下场景：

| 场景类型 | 特征 | 参考案例 |
|---------|------|---------|
| 奇幻生物 | 神秘生物+光影+微距 | 案例 #1 |
| 武士/忍者 | 日式武士+拔刀+慢动作 | 案例 #2, #8, #15 |
| 蒸汽朋克 | 机械+蒸汽+飞船 | 案例 #3, #12 |
| 史诗战斗 | 剑术+火花+混乱 | 案例 #5, #11 |
| 太空科幻 | 飞船+推进器+星空 | 案例 #6 |
| 魔法花园 | 奇幻+闪光+微风 | 案例 #7 |
| 未来机器人 | 机甲+霓虹+扫描 | 案例 #9 |
| 奇幻战士 | 披风+盔甲+环绕 | 案例 #10 |
| 丛林探险 | 废墟+迷雾+阳光 | 案例 #13 |
| 部落领袖 | 怒吼+军队+近景 | 案例 #14 |
| 动作/力量 | 肌肉+汗水+旋转 | 案例 #16 |

## 生成流程

1. **理解需求** — 分析用户提供的图片内容和期望的动态效果
2. **确定运动类型** — 选择合适的运动描述（人物动作/自然运动/环境变化）
3. **匹配运镜** — 从运镜术语表中选择最佳镜头运动
4. **叠加风格** — 确定艺术风格、色调、光照氛围
5. **添加特效** — 从电影特效术语中选择合适的后期效果
6. **构建英文提示词** — 按"运动 + 运镜 + 风格 + 特效"结构组装
7. **构建中文提示词** — 翻译/改写为中文版，保持相同细节密度
8. **输出交付** — 双语提示词 + 推荐参数 + 变体建议

## 提示词模板

### 英文模板

[Camera movement], [subject motion description]. [Environment/lighting change]. [Style/mood]. [Cinematic effects].

### 中文模板

[运镜描述]，[主体运动描述]。[环境/光影变化]。[风格/氛围]。[电影特效术语]。

### 示例组装

输入：一张武士站在雾中握剑的图片

英文版：The samurai in the foreground slowly grips his sword hilt. Mist swirls around the figures. Close-up on his eyes, showing intense focus. Deep Focus.

中文版：前景中的武士缓缓握紧剑柄。雾气在人物间缭绕。特写他的双眼，展现强烈专注。深焦。

## 输出格式（强制双语）

每次生成必须同时输出英文版 + 中文版，不得只输出一种语言。

### 英文版（RunwayML / Pika / Sora / Imagen Video）

正向提示词：[完整英文提示词：运动描述 + 运镜语言 + 风格氛围 + 电影特效]

### 中文版（可灵 / 即梦 / 通义）

正向提示词：[完整中文提示词，细节与英文版完全对齐]

### 运镜解析
- 镜头运动：[具体运镜术语]
- 运动主体：[什么在动]
- 氛围风格：[整体风格关键词]

### 推荐参数
- Runway Gen-3：直接使用英文版
- Pika Labs：直接使用英文版 + 运镜关键词
- 可灵：直接使用中文版
- 即梦：直接使用中文版

### 变体建议
[可调整的运镜/运动/特效变体列表]

## 质量检查

- 运动描述具体（使用了动词和副词，非泛泛的"动起来"）
- 运镜术语正确（Pan/Tilt/Zoom/Dolly/Tracking 等）
- 风格氛围与图片一致
- 时长意识合理（描述的是几秒内的短动作）
- 包含电影特效术语增强质感
- 双语输出完整（英文版 + 中文版）
- 无遗留占位符

## 最佳实践

1. **从图片出发** — 仔细审视基础图片，视频将从此延伸
2. **简洁精准** — 短促精准的提示词效果最佳
3. **使用动作动词** — ripples、explodes、drifts、pans
4. **指定方向** — left、up、towards the camera
5. **运动+风格叠加** — Slow-motion pan across the burning city, gritty color grading.
6. **考虑模型特性** — 不同模型擅长不同效果，适当调整
7. **实验迭代** — 尝试不同运镜、风格、特效的组合

## 参考案例库

完整 16 个精选案例见 references/sample-prompts.md。
