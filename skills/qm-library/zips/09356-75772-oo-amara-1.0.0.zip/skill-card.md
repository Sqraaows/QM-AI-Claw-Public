## Description: <br>
Amara (amara.org). Use this skill for reading, creating, updating, and deleting Amara videos, subtitle tracks, teams, users, activity records, and related collaboration workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Amara through an OOMOL-connected account, including video management, subtitle workflows, team and user lookup, activity review, and collaboration actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires credentials for an Amara-connected account and can perform account-affecting actions. <br>
Mitigation: Install it only for intended Amara workflows, use the minimum credentials needed, and review commands before approving account-affecting actions. <br>
Risk: Create, update, send, moderation, upload, and delete actions can change or remove Amara data. <br>
Mitigation: Confirm the target, payload, and intended effect before state-changing actions; require explicit approval before destructive actions. <br>


## Reference(s): <br>
- [Amara homepage](https://amara.org) <br>
- [Publisher profile: oomol](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Markdown, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches live action schemas before constructing payloads; outputs may include Amara records, subtitle data, URLs, activity items, or action execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
