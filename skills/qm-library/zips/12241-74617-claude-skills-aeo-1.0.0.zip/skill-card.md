## Description: <br>
Answer Engine Optimization (AEO) skill that helps audit, optimize, and track content for citation by AI language models such as ChatGPT, Perplexity, Claude, Gemini, and Mistral. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[alirezarezvani](https://clawhub.ai/user/alirezarezvani) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and content teams use this skill to evaluate content for E-E-A-T signals, generate AEO-focused improvements, and track which pages are cited by major LLMs. Developers can also run its local Python tools in pipelines that need markdown or JSON audit output. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read local content files supplied by the user and fetch URLs explicitly passed to the audit tool. <br>
Mitigation: Run it only on files and URLs intended for analysis, and avoid passing confidential material unless local processing and URL fetch behavior are acceptable. <br>
Risk: Citation queries, URLs, notes, and audit outputs may be retained in a local ledger under ~/.aeo-data. <br>
Mitigation: Review, export, or delete ~/.aeo-data when citation history or audit records contain sensitive information. <br>
Risk: AEO recommendations can affect public content in regulated domains such as healthcare, finance, or legal. <br>
Mitigation: Have qualified reviewers validate factual claims, citations, schema markup, and required disclaimers before publishing. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/alirezarezvani/claude-skills-aeo) <br>
- [E-E-A-T Methodology for Answer Engine Optimization](references/aeo_eeat_canon.md) <br>
- [AEO vs SEO](references/aeo_vs_seo.md) <br>
- [LLM Citation Patterns](references/llm_citation_patterns.md) <br>
- [Schema.org](https://schema.org) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, JSON, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown audit reports by default, optional JSON for pipeline integration, plus local files such as optimized markdown, CSV exports, and citation ledger data.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Stdlib Python tools can read provided local files, fetch URLs explicitly passed by the user, and store citation history under ~/.aeo-data.] <br>

## Skill Version(s): <br>
1.0.0 (source: ClawHub release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
