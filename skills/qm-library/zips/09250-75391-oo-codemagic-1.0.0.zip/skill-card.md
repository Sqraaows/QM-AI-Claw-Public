## Description: <br>
Codemagic helps agents read Codemagic account data and manage builds through schema-checked connector actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and CI/CD operators use this skill to inspect Codemagic users, teams, apps, and builds, and to start or cancel Codemagic builds from an agent workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can start Codemagic builds, which may consume CI/CD resources or trigger deployment workflows. <br>
Mitigation: Confirm the exact app, workflow, branch, and payload with the user before running create_build. <br>
Risk: The skill can cancel Codemagic builds, which may interrupt active CI/CD work. <br>
Mitigation: Confirm the exact build ID and intended effect with the user before running cancel_build. <br>
Risk: The skill uses an OOMOL-connected account and may access Codemagic data available to that account. <br>
Mitigation: Install and use it only when the agent is expected to operate with the connected account's Codemagic permissions. <br>


## Reference(s): <br>
- [Codemagic homepage](https://codemagic.io) <br>
- [ClawHub Codemagic skill](https://clawhub.ai/oomol/oo-codemagic) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Agents should fetch the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server-resolved release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
