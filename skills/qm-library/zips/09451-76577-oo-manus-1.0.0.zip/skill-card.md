## Description: <br>
Manus helps an agent operate Manus through an OOMOL-connected account using the oo CLI for reading, creating, updating, and deleting Manus tasks, projects, agents, connectors, skills, and messages. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Manus tasks and account resources from an agent session, including task creation, status review, follow-up messages, project grouping, and custom agent updates. It is intended for users who already trust OOMOL and have connected their Manus account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, send, stop, or delete Manus resources. <br>
Mitigation: Confirm the exact payload, target, and intended effect with the user before running state-changing actions, and require explicit approval for destructive deletes. <br>
Risk: The one-time oo CLI installer command downloads and executes an external script. <br>
Mitigation: Install only after trusting OOMOL and the Manus connector, and prefer reviewing the installer or following official verified installation steps. <br>
Risk: The integration depends on a connected Manus account and sensitive account credentials managed through OOMOL. <br>
Mitigation: Run the skill only in environments where the OOMOL account, Manus connector, and requested scopes are trusted and appropriate for the task. <br>


## Reference(s): <br>
- [ClawHub Manus skill](https://clawhub.ai/oomol/oo-manus) <br>
- [Manus homepage](https://manus.im) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [OOMOL Manus connection](https://console.oomol.com/app-connections?provider=manus) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Configuration instructions, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
