## Description: <br>
Generates detailed short video storyboard scripts from user-provided themes, structured copy, or outlines. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[dlazyai](https://clawhub.ai/user/dlazyai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Creators, marketers, and video production teams use this skill to convert structured short-form video copy into shot-by-shot storyboard scripts while preserving the user's spoken copy verbatim. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The security review says the release is labeled as a text-only storyboard helper but also sets up and instructs use of a third-party media-generation CLI with API credentials and external uploads. <br>
Mitigation: Review the @dlazy/cli package before use, avoid sensitive prompts or local file paths, and treat the skill as a dLazy media-generation integration rather than only a text helper. <br>
Risk: Prompts and media may be sent to dLazy services when the CLI is used. <br>
Mitigation: Use per-session credentials or environment variables where possible, rotate or revoke API keys when needed, and do not submit confidential source material unless approved for that service. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/dlazyai/text-storyboard-script) <br>
- [dLazy CLI source](https://github.com/dlazyai/cli) <br>
- [dLazy CLI npm package](https://www.npmjs.com/package/@dlazy/cli) <br>
- [dLazy homepage](https://dlazy.com) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Guidance, Shell commands, Configuration] <br>
**Output Format:** [Markdown storyboard script with video parameters, shot sections, scene notes, camera direction, and spoken-script text.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill preserves user-provided spoken copy verbatim, defaults missing video settings to 9:16 and 720p, and may provide dLazy CLI setup or command guidance when media generation is requested.] <br>

## Skill Version(s): <br>
1.2.0 (source: server release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
