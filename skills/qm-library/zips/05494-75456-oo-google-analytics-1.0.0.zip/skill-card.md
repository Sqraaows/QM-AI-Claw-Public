## Description: <br>
Operate Google Analytics through an OOMOL-connected account for account discovery, GA4 reporting, metadata lookup, quota checks, and configuration changes. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate GA4 through the OOMOL Google Analytics connector, including reporting, account and property discovery, metadata lookup, and quota review. Users with write permission can also manage custom dimensions, custom metrics, property settings, and data retention settings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Google Analytics account, property, report, metadata, and quota data available to the connected account. <br>
Mitigation: Install and run it only with an OOMOL-connected account whose Google Analytics access is appropriate for the requested task. <br>
Risk: Users with write scopes can create, update, or archive GA4 configuration such as custom dimensions, custom metrics, property settings, and data retention settings. <br>
Mitigation: Confirm the exact property, action, and JSON payload with the user before any create, update, or archive operation. <br>
Risk: Google Analytics action schemas and defaults can change upstream. <br>
Mitigation: Fetch the live connector schema before building each action payload. <br>


## Reference(s): <br>
- [Google Analytics](https://analytics.google.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Google Analytics skill on ClawHub](https://clawhub.ai/oomol/oo-google-analytics) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing Google Analytics action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
