## Description: <br>
AWS S3 (aws.amazon.com). Use this skill for AWS S3 requests that read, create, update, or delete bucket and object data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to inspect buckets, list objects, read object metadata, upload objects, delete objects, and generate pre-signed URLs from an OOMOL-connected AWS S3 account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The connected AWS credential can modify or remove S3 objects through upload and delete actions. <br>
Mitigation: Confirm the exact bucket, key, payload, and intended permission effect with the user before running write or delete actions. <br>
Risk: Pre-signed URLs can grant time-limited object access or operation capability. <br>
Mitigation: Confirm the URL operation, target object, and expiry before generating or sharing a pre-signed URL. <br>
Risk: Fallback setup includes shell and PowerShell installer commands for the oo CLI. <br>
Mitigation: Review the installer command and source before running setup, and only run setup after an auth or connection failure requires it. <br>


## Reference(s): <br>
- [ClawHub AWS S3 skill page](https://clawhub.ai/oomol/oo-aws-s3) <br>
- [AWS S3 homepage](https://aws.amazon.com/s3/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [delete_object action](actions/delete_object.md) <br>
- [generate_presigned_url action](actions/generate_presigned_url.md) <br>
- [head_object action](actions/head_object.md) <br>
- [list_buckets action](actions/list_buckets.md) <br>
- [list_objects action](actions/list_objects.md) <br>
- [put_object action](actions/put_object.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces oo CLI schema and connector-run commands; connector responses are JSON with data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
