## Description: <br>
Reference for Lance v7, the open columnar lakehouse format and Rust crate workspace for building directly with Lance datasets, file formats, indexes, schema evolution, versioning, concurrency, namespaces, and object-store configuration. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[tenequm](https://clawhub.ai/user/tenequm) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill as a technical reference when building directly on Lance crates, creating or reading .lance datasets, configuring indexes, handling schema evolution and concurrency, or working with Lance object storage. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated guidance or code may be incorrect for a real Lance dataset or cloud-storage environment. <br>
Mitigation: Review generated steps before applying them, and test changes against non-production datasets before using them with production data. <br>
Risk: The skill tracks a Lance beta tag, and next-format encodings or operational details may change across Lance releases. <br>
Mitigation: Pin work to the intended Lance tag and file-format version, and verify version-sensitive guidance before upgrading Lance. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/tenequm/lance-format) <br>
- [Skill source homepage](https://github.com/tenequm/skills/tree/main/skills/lance-format) <br>
- [Lance v7.2.0-beta.5 upstream tag](https://github.com/lance-format/lance/tree/v7.2.0-beta.5) <br>
- [Lance reference](references/lance-reference.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown reference guidance with code, commands, and configuration snippets when relevant.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only skill; no executable files are produced by the skill itself.] <br>

## Skill Version(s): <br>
0.5.0 (source: frontmatter, changelog, release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
