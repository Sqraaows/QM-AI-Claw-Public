## Description: <br>
Provides a Gmail MCP skill for reading, organizing, drafting, forwarding, autoreplying, and managing Gmail threads, labels, attachments, drafts, and bulk mailbox operations. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to connect an agent to Gmail workflows that require deeper mailbox operations than simple search, get, or send actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill exposes broad mailbox access across reading, labels, drafts, attachments, administrative settings, and tracking. <br>
Mitigation: Review before installing and use only with Gmail accounts where broad operational access is acceptable. <br>
Risk: Destructive or externally visible actions can delete messages, change forwarding or delegate settings, send replies, download attachments, or enable tracking. <br>
Mitigation: Require explicit confirmation before deletion, settings changes, sending replies, attachment downloads, or tracking actions. <br>
Risk: Bulk queries and autoreplies can affect many messages or recipients if the query is too broad. <br>
Mitigation: Preview matching messages, recipients, and intended changes before executing bulk archive, trash, mark-read, modify, delete, or autoreply operations. <br>


## Reference(s): <br>
- [gogcli](https://github.com/openclaw/gogcli) <br>
- [gogcli-mcp](https://github.com/chrischall/gogcli-mcp) <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp-gmail) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, API Calls, Shell commands, Configuration] <br>
**Output Format:** [Markdown guidance, setup JSON, and Gmail data returned through MCP tool calls] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May read, mutate, send, delete, download, and configure mailbox state depending on user-approved tool calls.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
