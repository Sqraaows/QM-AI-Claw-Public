## Description: <br>
Discover AWS-hosted AI agent and MCP-relevant assets from the operator's environment, emit canonical agent-bom inventory JSON, and optionally scan that inventory without giving agent-bom long-lived cloud credentials. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and cloud security operators use this skill to inventory AWS Bedrock, ECS, SageMaker, Lambda, EKS, Step Functions, EC2, and related agentic infrastructure from approved AWS accounts. It produces local canonical inventory that can be scanned or exported only when the operator chooses that handoff. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses AWS credentials to inventory cloud assets and can expose sensitive infrastructure details in generated files. <br>
Mitigation: Use only authorized, short-lived, read-only AWS profiles or assumed roles, confirm the regions and services before running, and treat generated inventory as sensitive cloud-asset data. <br>
Risk: Running discovery with broader service scope than intended can collect more AWS asset metadata than the operator expected. <br>
Mitigation: Start with the narrowest requested services and expand service flags only after the operator confirms the intended scope. <br>


## Reference(s): <br>
- [agent-bom GitHub repository](https://github.com/msaad00/agent-bom) <br>
- [agent-bom PyPI package](https://pypi.org/project/agent-bom/) <br>
- [ClawHub skill page](https://clawhub.ai/msaad00/agent-bom-discover-aws) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, json] <br>
**Output Format:** [Markdown guidance with shell commands and JSON inventory output paths] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The workflow writes inventory or findings only to operator-selected local paths.] <br>

## Skill Version(s): <br>
0.88.4 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
