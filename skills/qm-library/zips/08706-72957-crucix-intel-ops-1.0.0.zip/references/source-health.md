# Source Health

Monitoring framework for Crucix 27-source health.

## Health Metrics

| Metric | Description | Healthy Threshold |
|--------|-------------|------------------|
| `availability` | % sweeps with data returned | ≥ 95% over 7 days |
| `freshness` | Time since last successful data | ≤ 2 × refresh interval |
| `latency` | API response time trend | ≤ 5s per source |
| `error_rate` | Failed sweeps / total sweeps | ≤ 5% over 7 days |
| `data_quality` | Non-null field ratio | ≥ 80% |

## Source Categories (27 Sources)

### Tier 1 — Critical
| Source | Type | Refresh |
|--------|------|---------|
| GDELT | Conflict/Events | 15 min |
| ACLED | Conflict (armed) | 15 min |
| FIRMS | Fire detection | 15 min |

### Tier 2 — High
| Source | Type | Refresh |
|--------|------|---------|
| OpenSky | Aviation (ADS-B) | 15 min |
| Maritime | Ship tracking (AIS) | 15 min |
| Safecast | Radiation | 15 min |

### Tier 3 — Standard
| Source | Type | Refresh |
|--------|------|---------|
| VIX | Volatility index | 15 min |
| Crypto | Prices | 15 min |
| Starlink | Satellite count | 15 min |
| News | Sentiment | 15 min |

## Health Report Format

```json
{
  "generated_at": "ISO8601",
  "period": "7d",
  "sources": {
    "<source_name>": {
      "status": "healthy | degraded | down",
      "availability": 0.99,
      "avg_latency_ms": 1234,
      "error_count": 0,
      "last_success": "ISO8601",
      "last_error": "string | null"
    }
  },
  "overall_status": "healthy | degraded | critical",
  "action_required": ["string"] | []
}
```

## Alert Thresholds

| Condition | Alert Tier |
|-----------|-----------|
| Any Tier 1 source down > 30 min | FLASH |
| Any Tier 2 source down > 2 hours | PRIORITY |
| 3+ sources degraded simultaneously | PRIORITY |
| Overall error rate > 10% | ROUTINE |
