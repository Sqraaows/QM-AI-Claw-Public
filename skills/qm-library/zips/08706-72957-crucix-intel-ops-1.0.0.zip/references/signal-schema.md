# Signal Schema

Unified signal structure for all Crucix intelligence outputs.

## Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `key` | string | Unique signal identifier (e.g., `firms-fire-ukraine-20260407`) |
| `category` | enum | `fact` \| `observation` \| `inference` |
| `topic` | enum | One of 7 topic taxonomy entries |
| `region` | string | Geographic region (ISO country code or region name) |
| `source` | string | Crucix source name (e.g., `FIRMS`, `GDELT`, `OpenSky`) |
| `timestamp` | ISO8601 | When the signal was detected |
| `title` | string | Short headline (≤120 chars) |
| `summary` | string | 1-3 sentence description |
| `why_it_matters` | string | Why this signal matters to the user |
| `evidence_count` | integer | Number of corroborating data points |
| `confidence` | enum | `low` \| `medium` \| `high` |
| `classification` | enum | `fact` \| `observation` \| `inference` |
| `status` | enum | `snapshot` \| `sustained` \| `trend` |

## Classification Definitions

- **fact**: Directly observed, measured, or reported by source
- **observation**: Pattern recognized from data (no causal inference)
- **inference**: Analyst conclusion, requires confirmation

## Status Definitions

- **snapshot**: Single detection, single source — lowest confidence
- **sustained**: Confirmed across multiple sweep cycles
- **trend**: Statistical baseline established; directional movement confirmed over ≥3 days

## Topic → Region Mapping

| Topic | Primary Regions |
|-------|----------------|
| conflict-security | UA, RU, IL, IR, KP, SS |
| disaster-environment | Global (FIRMS/Safecast) |
| macro-markets | Global |
| news-sentiment | Global |
| aviation-maritime | Global (ADS-B, AIS) |
| public-health | Global |
| technology-space | Global (LEO satellites) |
