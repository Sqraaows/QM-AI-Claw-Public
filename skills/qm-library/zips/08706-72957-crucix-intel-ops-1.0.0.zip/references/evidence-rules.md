# Evidence Rules

Cross-source validation and evidence hierarchy rules.

## Evidence Hierarchy

| Level | Source Type | Examples | Confidence Boost |
|-------|-------------|----------|-----------------|
| 1 | Government/Institutional | FEMA, NOAA, WHO, IAEA | +high |
| 2 | Verified Open Data | FIRMS, GDELT, ACLED, OpenSky | +medium |
| 3 | Crowdsourced/UGC | Reddit, Telegram (unverified) | +low |
| 4 | Modeled/Synthetic | LLM-generated, derived indices | +none |

## Validation Rules

### Single Source
- Max classification: `observation`
- Max status: `snapshot`
- Confidence: `low` or `medium`

### Multi-Source (2+)
- Min classification: `observation`
- If sources are Level 1: classification can reach `fact`
- Confidence: `medium` or `high`

### Multi-Day (3+ days consistent)
- Status can reach `sustained`
- If + multi-source: can reach `trend`

### Trend (requires ALL)
- [ ] Statistical baseline > 3 days
- [ ] Directional movement confirmed
- [ ] 2+ independent sources
- [ ] Not explained by data artifact

## Red Flags (demote confidence)

- Single source only
- Conflicting data between sources
- Missing data in normally-active source
- Source reporting outside normal parameters
- User reports contradict data

## Evidence Package Structure

```
evidence/<topic>/
├── metadata.json       # topic, priority, created_at
├── signals.json        # all signals for this topic
├── timeline.json       # chronological view
└── validation.json    # cross-check results
```
