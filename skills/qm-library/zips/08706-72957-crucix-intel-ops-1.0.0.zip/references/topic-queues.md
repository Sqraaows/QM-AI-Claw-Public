# Topic Queues

Multi-dimensional priority queues for signal theming and prioritization.

## Queue Structure

```json
{
  "queues": {
    "conflict-security": {
      "priority": "high",
      "signals": [],
      "last_updated": "ISO8601"
    },
    "disaster-environment": {
      "priority": "high",
      "signals": [],
      "last_updated": "ISO8601"
    },
    "macro-markets": {
      "priority": "medium",
      "signals": [],
      "last_updated": "ISO8601"
    },
    "news-sentiment": {
      "priority": "medium",
      "signals": [],
      "last_updated": "ISO8601"
    },
    "aviation-maritime": {
      "priority": "low",
      "signals": [],
      "last_updated": "ISO8601"
    },
    "public-health": {
      "priority": "medium",
      "signals": [],
      "last_updated": "ISO8601"
    },
    "technology-space": {
      "priority": "low",
      "signals": [],
      "last_updated": "ISO8601"
    }
  }
}
```

## Priority Escalation Rules

| Condition | Action |
|-----------|--------|
| Signal from 3+ different sources | escalate priority |
| Evidence count ≥ 10 | escalate |
| Region = UA or IL (active conflict) | always high priority |
| Status = `trend` | hold at elevated priority |

## Queue Maintenance

- Remove signals older than 7 days unless `status = trend`
- Merge duplicate signals (same key, different timestamps → keep latest)
- Sort each queue by: `confidence DESC, evidence_count DESC, timestamp DESC`
