#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_topic_queues.py
Build and maintain multi-dimensional topic queues from sweep signals.
"""
import json, sys, os
from datetime import datetime, timedelta
from pathlib import Path

CRUCIX_RUN = "/home/admin/Crucix/runs/latest.json"
OUTPUT_DIR = Path("/home/admin/Crucix/output/queues")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

QUEUES_FILE = OUTPUT_DIR / "topic-queues.json"

TOPIC_META = {
    "conflict-security": {"priority": "high", "emoji": "🪖"},
    "disaster-environment": {"priority": "high", "emoji": "🌍"},
    "macro-markets": {"priority": "medium", "emoji": "📊"},
    "news-sentiment": {"priority": "medium", "emoji": "📰"},
    "aviation-maritime": {"priority": "low", "emoji": "✈️"},
    "public-health": {"priority": "medium", "emoji": "🏥"},
    "technology-space": {"priority": "low", "emoji": "🛰️"},
}


def load_signals():
    """Load signals from latest sweep."""
    if not os.path.exists(CRUCIX_RUN):
        return []
    with open(CRUCIX_RUN) as f:
        sweep = json.load(f)

    signals = []
    for src_name, src_data in sweep.get("sources", {}).items():
        if isinstance(src_data, dict) and "data" in src_data:
            for item in src_data.get("data", []):
                signals.append({
                    "key": f"{src_name.lower()}-{item.get('id', id(item))}",
                    "topic": map_topic(src_name),
                    "region": item.get("region", item.get("country", "GLOBAL")),
                    "source": src_name,
                    "timestamp": item.get("timestamp", sweep.get("crucix", {}).get("timestamp", "")),
                    "title": item.get("title", item.get("event", "Unknown")),
                    "summary": item.get("summary", ""),
                    "confidence": item.get("confidence", "medium"),
                    "status": item.get("status", "snapshot"),
                    "evidence_count": item.get("evidence_count", 1),
                })
    return signals


def map_topic(source):
    src = source.upper()
    if src in ("GDELT", "ACLED"): return "conflict-security"
    if src in ("FIRMS", "SAFECAST"): return "disaster-environment"
    if src in ("OPENSKY", "MARITIME"): return "aviation-maritime"
    if src in ("VIX", "CRYPTO", "INDEXES"): return "macro-markets"
    if src in ("NEWS", "SENTIMENT"): return "news-sentiment"
    if src in ("STARLINK", "ISS", "SATELLITE"): return "technology-space"
    return "news-sentiment"


def maintain_queues(signals):
    """Build or update topic queues from signals."""
    queues = {}
    now = datetime.now().isoformat()
    cutoff = (datetime.now() - timedelta(days=7)).isoformat()

    for topic in TOPIC_META:
        meta = TOPIC_META[topic]
        # Filter signals for this topic
        topic_sigs = [s for s in signals if s["topic"] == topic]

        # Sort: confidence DESC, evidence_count DESC, timestamp DESC
        topic_sigs.sort(key=lambda x: (
            {"high": 3, "medium": 2, "low": 1}.get(x["confidence"], 2),
            x["evidence_count"],
            x["timestamp"] or "",
        ), reverse=True)

        # Keep only recent signals (7 days) unless trend
        filtered = [s for s in topic_sigs if s["status"] != "trend" and s["timestamp"] >= cutoff]
        trend_sigs = [s for s in topic_sigs if s["status"] == "trend"]

        queues[topic] = {
            "priority": meta["priority"],
            "emoji": meta["emoji"],
            "count": len(filtered) + len(trend_sigs),
            "signals": filtered[-20:],  # keep last 20 non-trend
            "trend_signals": trend_sigs,
            "last_updated": now,
        }

    return queues


def main():
    print("📋 Building topic queues...")
    signals = load_signals()
    print(f"  → {len(signals)} signals loaded")

    queues = maintain_queues(signals)

    with open(QUEUES_FILE, "w") as f:
        json.dump({"queues": queues, "generated_at": datetime.now().isoformat()}, f, indent=2, ensure_ascii=False)

    print(f"  ✅ Saved: {QUEUES_FILE}")
    for topic, q in queues.items():
        print(f"     {TOPIC_META[topic]['emoji']} {topic}: {q['count']} signals")


if __name__ == "__main__":
    main()
