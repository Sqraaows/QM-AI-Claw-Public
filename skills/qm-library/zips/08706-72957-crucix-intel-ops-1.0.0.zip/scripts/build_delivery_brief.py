#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_delivery_brief.py
Reads latest Crucix sweep → generates delivery brief (MD + JSON).
"""
import json, os
from datetime import datetime
from pathlib import Path

CRUCIX_RUN = "/home/admin/Crucix/runs/latest.json"
OUTPUT_DIR = Path("/home/admin/Crucix/output")
OUTPUT_DIR.mkdir(exist_ok=True)

# Source → Topic mapping (27 sources)
SOURCE_TOPIC_MAP = {
    "GDELT": "conflict-security",
    "ACLED": "conflict-security",
    "FIRMS": "disaster-environment",
    "Safecast": "disaster-environment",
    "NOAA": "disaster-environment",
    "EPA": "disaster-environment",
    "YFinance": "macro-markets",
    "FRED": "macro-markets",
    "Treasury": "macro-markets",
    "BLS": "macro-markets",
    "EIA": "macro-markets",
    "GSCPI": "macro-markets",
    "Telegram": "news-sentiment",
    "Reddit": "news-sentiment",
    "Bluesky": "news-sentiment",
    "ReliefWeb": "public-health",
    "WHO": "public-health",
    "OpenSky": "aviation-maritime",
    "ADS-B": "aviation-maritime",
    "Maritime": "aviation-maritime",
    "KiwiSDR": "aviation-maritime",
    "Space": "technology-space",
    "Patents": "technology-space",
    "OFAC": "conflict-security",
    "OpenSanctions": "conflict-security",
    "USAspending": "macro-markets",
    "Comtrade": "macro-markets",
}

# Topic display names
TOPIC_LABELS = {
    "conflict-security": "🪖 Conflict & Security",
    "disaster-environment": "🌍 Environment & Disasters",
    "macro-markets": "📊 Macro Markets",
    "news-sentiment": "📰 News & Sentiment",
    "aviation-maritime": "✈️ Aviation & Maritime",
    "public-health": "🏥 Public Health",
    "technology-space": "🛰️ Technology & Space",
}


def extract_signals(sweep):
    """Extract structured signals from sweep sources."""
    signals = []
    if not sweep:
        return signals

    sources = sweep.get("sources", {})
    crucix_ts = sweep.get("crucix", {}).get("timestamp", "")

    for src_name, src_data in sources.items():
        if not isinstance(src_data, dict):
            continue

        topic = SOURCE_TOPIC_MAP.get(src_name, "news-sentiment")

        # Extract signals from nested data
        nested_signals = _extract_from_source(src_name, src_data, topic, crucix_ts)
        signals.extend(nested_signals)

    return signals


def _extract_from_source(name, data, topic, base_ts):
    """Extract signals from a specific source's data."""
    signals = []

    # Conflict/security
    if name in ("GDELT", "ACLED"):
        conflicts = data.get("conflicts", [])
        for c in (conflicts if isinstance(conflicts, list) else []):
            signals.append(_mk_signal(
                key=f"{name.lower()}-conflict-{c.get('id', id(c))}",
                topic=topic, source=name, timestamp=base_ts,
                title=c.get("event", c.get("title", "Conflict event")),
                summary=c.get("summary", c.get("description", "")),
                region=c.get("region", c.get("country", "GLOBAL")),
                why=c.get("fatalities", "") and f"Fatalities: {c.get('fatalities')}",
            ))

    # YFinance
    if name == "YFinance":
        quotes = data.get("quotes", {})
        for ticker, info in quotes.items():
            if isinstance(info, dict) and info.get("change_percent", 0) != 0:
                signals.append(_mk_signal(
                    key=f"yfinance-{ticker}",
                    topic=topic, source=name, timestamp=base_ts,
                    title=f"{ticker}: {info.get('price', '?')} ({info.get('change_percent', 0):+.2f}%)",
                    summary=f"Change: {info.get('change', '')}, Volume: {info.get('volume', '')}",
                    region="GLOBAL",
                    why="Price movement",
                ))
        # VIX from volatility list
        vol_list = data.get("volatility", [])
        for vol in (vol_list if isinstance(vol_list, list) else []):
            if isinstance(vol, dict) and vol.get("symbol") == "^VIX":
                signals.append(_mk_signal(
                    key="macro-vix",
                    topic="macro-markets", source="YFinance", timestamp=base_ts,
                    title=f"VIX: {vol.get('price', vol.get('value', '?'))} ({vol.get('changePct', 0):+.2f}%)",
                    summary=f"VIX fear index: {vol.get('name', '')}",
                    region="GLOBAL", why="Market volatility signal",
                ))

    # Telegram urgent posts
    if name == "Telegram":
        urgent = data.get("urgentPosts", [])
        for post in (urgent if isinstance(urgent, list) else []):
            signals.append(_mk_signal(
                key=f"telegram-urgent-{post.get('id', id(post))}",
                topic=topic, source=name, timestamp=base_ts,
                title=post.get("title", post.get("snippet", "Telegram post"))[:100],
                summary=post.get("snippet", ""),
                region=post.get("region", "GLOBAL"),
                why="Urgent social signal",
            ))

    # Space
    if name == "Space":
        status = data.get("status", {})
        if isinstance(status, dict):
            signals.append(_mk_signal(
                key="space-starlink",
                topic="technology-space", source=name, timestamp=base_ts,
                title=f"Space: {status.get('message', status.get('starlink_count', 'Active'))}",
                summary=str(status),
                region="GLOBAL", why="Satellite activity",
            ))

    # FIRMS fire data
    if name == "FIRMS":
        status = data.get("status", "")
        msg = data.get("message", "")
        signals.append(_mk_signal(
            key="firms-status",
            topic="disaster-environment", source=name, timestamp=base_ts,
            title=f"FIRMS: {status}",
            summary=msg[:200] if msg else "",
            region="GLOBAL", why="Fire detection active",
        ))

    # ADS-B
    if name == "ADS-B":
        military = data.get("militaryAircraft", [])
        if isinstance(military, list) and military:
            for ac in military[:3]:
                signals.append(_mk_signal(
                    key=f"adsb-{ac.get('icao24', id(ac))}",
                    topic="aviation-maritime", source=name, timestamp=base_ts,
                    title=f"Military: {ac.get('callsign', 'Unknown')}",
                    summary=f"From: {ac.get('origin_country', '?')}, Alt: {ac.get('baro_altitude', '?')}m",
                    region=ac.get("origin_country", "GLOBAL"),
                    why="Military aviation tracking",
                ))

    return signals


def _mk_signal(key, topic, source, timestamp, title, summary, region, why=""):
    return {
        "key": key,
        "category": "observation",
        "topic": topic,
        "region": region,
        "source": source,
        "timestamp": timestamp,
        "title": title[:120],
        "summary": summary[:500] if summary else "",
        "why_it_matters": why,
        "evidence_count": 1,
        "confidence": "medium",
        "classification": "observation",
        "status": "snapshot",
    }


def build_brief(signals):
    brief = {
        "generated_at": datetime.now().isoformat(),
        "generated_by": "crucix-intel-ops",
        "total_signals": len(signals),
        "topics": {},
    }

    for sig in signals:
        topic = sig["topic"]
        if topic not in brief["topics"]:
            brief["topics"][topic] = {"count": 0, "signals": []}
        brief["topics"][topic]["count"] += 1
        brief["topics"][topic]["signals"].append(sig)

    return brief


def format_md(brief, signals):
    lines = [
        f"# Crucix Intelligence Delivery Brief",
        f"Generated: {brief['generated_at']}",
        f"Total Signals: {brief['total_signals']}",
        "",
    ]

    for topic in ["conflict-security", "disaster-environment", "macro-markets",
                  "news-sentiment", "aviation-maritime", "public-health", "technology-space"]:
        if topic not in brief["topics"]:
            continue
        info = brief["topics"][topic]
        label = TOPIC_LABELS.get(topic, topic)
        lines.append(f"## {label} ({info['count']})")
        lines.append("")
        for sig in info["signals"][:8]:
            lines.append(f"**{sig['title']}**")
            lines.append(f"- Source: `{sig['source']}` | Region: `{sig['region']}`")
            lines.append(f"- Confidence: `{sig['confidence']}` | Status: `{sig['status']}`")
            if sig.get("summary"):
                lines.append(f"- {sig['summary'][:200]}")
            lines.append("")
        lines.append("")

    return "\n".join(lines)


def main():
    print("📋 Building delivery brief...")

    if not os.path.exists(CRUCIX_RUN):
        print(f"❌ No sweep found at {CRUCIX_RUN}")
        return

    with open(CRUCIX_RUN) as f:
        sweep = json.load(f)

    signals = extract_signals(sweep)
    print(f"  → {len(signals)} signals extracted")

    brief = build_brief(signals)

    json_path = OUTPUT_DIR / "delivery-brief.json"
    with open(json_path, "w") as f:
        json.dump(brief, f, indent=2, ensure_ascii=False)
    print(f"  ✅ JSON: {json_path}")

    md_path = OUTPUT_DIR / "delivery-brief.md"
    with open(md_path, "w") as f:
        f.write(format_md(brief, signals))
    print(f"  ✅ MD: {md_path}")


if __name__ == "__main__":
    main()
