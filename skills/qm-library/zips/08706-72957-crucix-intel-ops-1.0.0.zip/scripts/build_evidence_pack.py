#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_evidence_pack.py
Generate evidence package for a specific topic.
Usage: python3 build_evidence_pack.py <topic>
"""
import json, sys, os
from datetime import datetime
from pathlib import Path

CRUCIX_RUN = "/home/admin/Crucix/runs/latest.json"
OUTPUT_DIR = Path("/home/admin/Crucix/output/evidence")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

VALID_TOPICS = [
    "conflict-security", "disaster-environment", "macro-markets",
    "news-sentiment", "aviation-maritime", "public-health", "technology-space"
]

TOPIC_SOURCE_MAP = {
    "conflict-security": ["GDELT", "ACLED"],
    "disaster-environment": ["FIRMS", "Safecast"],
    "aviation-maritime": ["OpenSky", "Maritime"],
    "macro-markets": ["VIX", "Crypto", "Indexes"],
    "news-sentiment": ["News", "Sentiment"],
    "technology-space": ["Starlink", "ISS", "Satellite"],
    "public-health": [],
}


def load_sweep():
    if not os.path.exists(CRUCIX_RUN):
        return None
    with open(CRUCIX_RUN) as f:
        return json.load(f)


def build_pack(topic):
    sweep = load_sweep()
    if not sweep:
        print("❌ No sweep data found")
        return None

    sources = TOPIC_SOURCE_MAP.get(topic, [])
    signals = []

    for src_name, src_data in sweep.get("sources", {}).items():
        if sources and src_name not in sources:
            continue
        if isinstance(src_data, dict) and "data" in src_data:
            for item in src_data.get("data", []):
                sig = {
                    "key": f"{src_name.lower()}-{item.get('id', id(item))}",
                    "topic": topic,
                    "source": src_name,
                    "timestamp": item.get("timestamp", sweep.get("crucix", {}).get("timestamp", "")),
                    "title": item.get("title", item.get("event", "Unknown")),
                    "summary": item.get("summary", ""),
                    "classification": "observation",
                    "status": "snapshot",
                    "confidence": "medium",
                    "evidence_count": 1,
                    "region": item.get("region", item.get("country", "GLOBAL")),
                }
                signals.append(sig)

    # Build timeline
    timeline = sorted(signals, key=lambda x: x.get("timestamp", ""), reverse=True)

    # Validation
    validation = {
        "single_source": len(set(s.get("source") for s in signals)) == 1 if signals else True,
        "multi_source": len(set(s.get("source") for s in signals)) > 1 if signals else False,
        "trend_eligible": False,
        "confidence_override": None,
    }
    if len(set(s.get("source") for s in signals)) >= 2:
        validation["confidence_override"] = "elevated to high"
    if len(signals) >= 3 and validation["multi_source"]:
        validation["trend_eligible"] = True

    metadata = {
        "topic": topic,
        "created_at": datetime.now().isoformat(),
        "signal_count": len(signals),
        "sources_used": list(set(s.get("source") for s in signals)),
        "evidence_level": len(set(s.get("source") for s in signals)),
    }

    topic_dir = OUTPUT_DIR / topic
    topic_dir.mkdir(parents=True, exist_ok=True)

    for fname, data in [
        ("metadata.json", metadata),
        ("signals.json", {"signals": signals}),
        ("timeline.json", {"timeline": timeline}),
        ("validation.json", validation),
    ]:
        path = topic_dir / fname
        with open(path, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    # Also write latest.md
    md_lines = [f"# Evidence Pack: {topic}", f"Generated: {metadata['created_at']}", ""]
    md_lines.append(f"Signals: {len(signals)} | Sources: {', '.join(metadata['sources_used'])}")
    md_lines.append(f"Validation: {validation}")
    md_lines.append("")
    for sig in signals[:10]:
        md_lines.append(f"### {sig['title']}")
        md_lines.append(f"- Source: `{sig['source']}` | Region: `{sig['region']}`")
        md_lines.append(f"- {sig.get('summary', '')[:200']}")
        md_lines.append("")

    with open(topic_dir / "latest.md", "w") as f:
        f.write("\n".join(md_lines))

    return metadata


def main():
    topic = sys.argv[1] if len(sys.argv) > 1 else "conflict-security"

    if topic not in VALID_TOPICS:
        print(f"❌ Invalid topic: {topic}")
        print(f"   Valid: {', '.join(VALID_TOPICS)}")
        sys.exit(1)

    print(f"📦 Building evidence pack for: {topic}")
    result = build_pack(topic)
    if result:
        print(f"  ✅ Evidence pack created: output/evidence/{topic}/")
        print(f"     Files: metadata.json, signals.json, timeline.json, validation.json, latest.md")


if __name__ == "__main__":
    main()
