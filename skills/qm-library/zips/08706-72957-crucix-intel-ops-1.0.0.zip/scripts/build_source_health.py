#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_source_health.py
Generate source health report from Crucix sweep data.
"""
import json, sys, os
from datetime import datetime
from pathlib import Path

CRUCIX_RUN = "/home/admin/Crucix/runs/latest.json"
STATE_FILE = Path("/home/admin/Crucix/state/source-health.json")
STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR = Path("/home/admin/Crucix/output")
OUTPUT_DIR.mkdir(exist_ok=True)

# 27 sources grouped by tier
SOURCE_TIERS = {
    "critical": ["GDELT", "ACLED", "FIRMS"],
    "high": ["OpenSky", "Maritime", "Safecast"],
    "standard": ["VIX", "Crypto", "Indexes", "News", "Sentiment", "Starlink", "ISS", "Satellite"],
}

SOURCE_METRICS = {
    src: {"status": "unknown", "availability": 0.0, "avg_latency_ms": 0,
          "error_count": 0, "last_success": None, "last_error": None}
    for tier in SOURCE_TIERS for src in SOURCE_TIERS[tier]
}


def load_history():
    """Load history from Crucix runs directory."""
    import glob
    history_dir = Path("/home/admin/Crucix/runs/history")
    files = sorted(history_dir.glob("*.json")) if history_dir.exists() else []
    # Also check runs/ for historical json files
    runs_dir = Path("/home/admin/Crucix/runs")
    all_files = sorted(runs_dir.glob("*.json")) if runs_dir.exists() else []
    all_files = [f for f in all_files if f.name != "latest.json"]
    return all_files


def compute_source_health(sweep):
    """Compute per-source health metrics from sweep data."""
    if not sweep:
        return SOURCE_METRICS.copy()

    sources_in_sweep = sweep.get("sources", {})
    crucix_meta = sweep.get("crucix", {})
    timing = sweep.get("timing", {})

    health = SOURCE_METRICS.copy()

    for src_name, src_data in sources_in_sweep.items():
        if src_name not in health:
            continue

        latency_ms = timing.get(src_name, {}).get("durationMs", 0)
        has_data = isinstance(src_data, dict) and bool(src_data.get("data"))

        health[src_name].update({
            "status": "healthy" if has_data else "degraded",
            "avg_latency_ms": latency_ms,
            "last_success": crucix_meta.get("timestamp") if has_data else None,
            "availability": 1.0 if has_data else 0.0,
        })

    # Flag failed sources
    for src_name in health:
        if src_name not in sources_in_sweep:
            health[src_name]["status"] = "down"

    return health


def determine_overall(health):
    """Determine overall system health."""
    statuses = [h["status"] for h in health.values()]
    if any(s == "down" for s in statuses):
        return "critical"
    if any(s == "degraded" for s in statuses):
        return "degraded"
    return "healthy"


def build_report():
    sweep = None
    if os.path.exists(CRUCIX_RUN):
        with open(CRUCIX_RUN) as f:
            sweep = json.load(f)

    health = compute_source_health(sweep)
    now = datetime.now().isoformat()

    report = {
        "generated_at": now,
        "period": "realtime",
        "sources": health,
        "overall_status": determine_overall(health),
        "action_required": [],
    }

    # Check tier-1 critical sources
    for src in SOURCE_TIERS.get("critical", []):
        if health.get(src, {}).get("status") == "down":
            report["action_required"].append(f"FLASH: Critical source down: {src}")

    # Save JSON
    json_path = OUTPUT_DIR / "source-health-report.json"
    with open(json_path, "w") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    # Save state
    with open(STATE_FILE, "w") as f:
        json.dump({"sources": health, "last_updated": now}, f, indent=2)

    # Save MD
    md_lines = [
        f"# Source Health Report",
        f"Generated: {now}",
        f"Overall: **{report['overall_status'].upper()}**",
        "",
        "| Source | Status | Availability | Latency |",
        "|--------|--------|-------------|---------|",
    ]
    for src, h in sorted(health.items()):
        tier_label = "🔴" if src in SOURCE_TIERS.get("critical", []) else "🟡" if src in SOURCE_TIERS.get("high", []) else "🟢"
        md_lines.append(f"| {tier_label} {src} | {h['status']} | {h['availability']:.0%} | {h['avg_latency_ms']}ms |")

    if report["action_required"]:
        md_lines.append("")
        md_lines.append("## ⚠️ Actions Required")
        for action in report["action_required"]:
            md_lines.append(f"- {action}")

    md_path = OUTPUT_DIR / "source-health-report.md"
    with open(md_path, "w") as f:
        f.write("\n".join(md_lines))

    return report


def main():
    print("🏥 Building source health report...")
    report = build_report()
    print(f"  ✅ Overall: {report['overall_status']}")
    print(f"  ✅ Reports: output/source-health-report.json + .md")
    for action in report.get("action_required", []):
        print(f"  ⚠️  {action}")


if __name__ == "__main__":
    main()
