---
name: crucix-intel-ops
description: >
  Generate structured intelligence outputs from Crucix 27-source sweep results.
  Use when handling delivery briefs, topic queues, evidence packs, source health checks,
  or multi-source validation for cloud-side intelligence operations.
emoji: 🎯
tags: [intelligence, crucix, osint, collection, delivery-brief, evidence-pack, source-health]
license: MIT
author: stonestorm2024
version: 1.0.0
language: en
homepage: https://github.com/stonestorm2024/crucix-intel-ops
requires:
  - python3 >= 3.9
  - node.js (for Crucix briefing.mjs)
---

# Crucix Intel Ops — Skill

Manages Crucix 27-source intelligence collection, filtering, theming, and delivery output.

## Activation

Activate when user asks for:
- 生成情报简报 / delivery brief
- 生成专题队列 / topic queues
- 判断趋势是否成立 / trend validation
- 做 source 健康检查 / source health check
- 生成证据文件 / evidence pack
- 生成可供后续系统消费的结构化结果

## Input Sources

| Path | Description |
|------|-------------|
| `/home/admin/Crucix/runs/latest.json` | Latest sweep results |
| `/home/admin/Crucix/runs/history/*.json` | Historical slices |
| `/home/admin/Crucix/apis/derived/*` | Derived/processed data |
| `/home/admin/Crucix/state/source-health.json` | Source health state |

## Output Directory

All outputs go to `/home/admin/Crucix/output/`:

```
output/
├── delivery-brief.md
├── delivery-brief.json
├── topic-queues.json
├── source-health-report.md
├── source-health.json
├── trend-summary.json
└── evidence/
    └── <topic>/
        ├── latest.md
        └── latest.json
```

## Topic Taxonomy

| Topic | Covers |
|-------|--------|
| `conflict-security` | GDELT, ACLED conflict events |
| `disaster-environment` | FIRMS fire, Safecast radiation |
| `macro-markets` | VIX, indexes, crypto, commodities |
| `news-sentiment` | Social sentiment, news acceleration |
| `aviation-maritime` | OpenSky flights, Maritime AIS |
| `public-health` | Health feeds |
| `technology-space` | Starlink, ISS, satellite tracking |

## Signal Schema

Every signal must have:
```json
{
  "key": "string",
  "category": "fact | observation | inference",
  "topic": "conflict-security | disaster-environment | macro-markets | ...",
  "region": "string",
  "source": "string (source name)",
  "timestamp": "ISO8601",
  "title": "string",
  "summary": "string",
  "why_it_matters": "string",
  "evidence_count": "integer",
  "confidence": "low | medium | high",
  "classification": "fact | observation | inference",
  "status": "snapshot | sustained | trend"
}
```

## Confidence Rules

| Rule | Applies when |
|------|-------------|
| `snapshot` | Single source, single time |
| `sustained` | Same signal across multiple sweeps |
| `trend` | Statistical baseline established over days + multi-source |

## Evidence Rules

- Single source → `snapshot` only
- Multi-source, same event → elevated confidence
- Narrative across 3+ days → `trend`
- Never label single-source as `trend`

## Output Principles

1. **优先事实** — lead with facts
2. **明示证据来源** — always cite source
3. **明示证据不足** — flag when evidence is thin
4. **不夸大结论** — don't overstate confidence
