## Description: <br>
Rocketlane (rocketlane.com). Use this skill for Rocketlane requests that search and read project, task, and user data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and customer-facing teams use this skill to let an agent inspect Rocketlane projects, tasks, and users through an existing OOMOL Rocketlane connection. It is intended for explicit Rocketlane lookup and reporting tasks rather than general conversation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can expose Rocketlane project, task, and user data available to the connected OOMOL account. <br>
Mitigation: Install and use it only for explicit Rocketlane lookup tasks, and review the OOMOL CLI and Rocketlane connection setup before authorizing credentials. <br>


## Reference(s): <br>
- [Rocketlane homepage](https://www.rocketlane.com) <br>
- [Rocketlane ClawHub listing](https://clawhub.ai/oomol/oo-rocketlane) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
