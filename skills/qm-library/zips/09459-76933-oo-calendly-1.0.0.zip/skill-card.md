## Description: <br>
Calendly (calendly.com). Use this skill for ANY Calendly request - reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to operate a connected Calendly account through OOMOL, including scheduling, invitee, organization, routing form, availability, and webhook workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change Calendly state, including bookings, cancellations, invitations, organization memberships, webhooks, and availability settings. <br>
Mitigation: Require explicit user confirmation of the target, payload, and expected effect before any state-changing action. <br>
Risk: The skill operates a connected Calendly account and requires sensitive credentials through the OOMOL connection. <br>
Mitigation: Install only for users who intend to grant the agent Calendly account access and keep credential handling within the connected account flow. <br>
Risk: Action schemas and upstream defaults may change. <br>
Mitigation: Inspect the live connector schema before constructing or running each action payload. <br>


## Reference(s): <br>
- [Calendly homepage](https://calendly.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-calendly) <br>
- [Publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads or API responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before action execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
