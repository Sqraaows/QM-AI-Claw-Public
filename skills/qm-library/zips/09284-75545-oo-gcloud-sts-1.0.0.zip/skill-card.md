## Description: <br>
Google Cloud STS helps agents use an OOMOL-connected account to exchange an OIDC token for a Google Cloud access token through Workload Identity Federation. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill when they need a Google Cloud federated access token from a configured OOMOL Google Cloud STS connection. It supports inspecting the live connector schema and running the token-exchange action through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can mint and return a raw Google Cloud access token. <br>
Mitigation: Treat returned tokens as secrets and avoid logging, pasting, or sharing them outside the intended workflow. <br>
Risk: A token may provide access beyond the user's intended project, scopes, or task. <br>
Mitigation: Verify the target Google Cloud project, scopes, and intended use before running the token-exchange action. <br>


## Reference(s): <br>
- [Google Cloud Workload Identity Federation](https://cloud.google.com/iam/docs/workload-identity-federation) <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-gcloud-sts) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Guidance, Configuration, JSON] <br>
**Output Format:** [Markdown guidance with bash commands; the connector action returns JSON.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Returned Google Cloud access tokens are secrets and should not be logged, pasted into unrelated tools, or shared.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
