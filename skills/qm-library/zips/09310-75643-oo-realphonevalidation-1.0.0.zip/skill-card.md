## Description: <br>
RealPhoneValidation validates individual 10-digit phone numbers through an OOMOL-connected RealPhoneValidation account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations users use this skill to inspect RealPhoneValidation connector schemas and validate phone numbers through an OOMOL-connected account. It supports standard validation and Turbo v3 validation with caller enrichment fields when available. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Phone numbers submitted for validation are sent through the OOMOL connector to RealPhoneValidation. <br>
Mitigation: Use the skill only when phone-number validation is intended, and avoid submitting unnecessary personal data. <br>
Risk: Actions may use the user's connected RealPhoneValidation account or OOMOL billing credits. <br>
Mitigation: Confirm the connected account and available credits before running validation at scale. <br>
Risk: First-time setup may require installing the oo CLI from an external install source. <br>
Mitigation: Review the oo CLI install source before running setup commands. <br>


## Reference(s): <br>
- [RealPhoneValidation homepage](https://realphonevalidation.com) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-realphonevalidation) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses oo CLI schema inspection before constructing action payloads; connector responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact metadata and server release) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
