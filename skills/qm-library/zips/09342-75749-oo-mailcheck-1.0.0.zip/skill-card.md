## Description: <br>
Mailcheck helps agents validate email addresses, validate domains, and retrieve UserCheck account status through an OOMOL-connected Mailcheck account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Mailcheck/UserCheck through OOMOL for email deliverability checks, domain risk assessment, and account usage lookup. It is intended for workflows that need lookup results from the connected Mailcheck service without direct API-token handling. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Mailcheck/UserCheck account and sends queried email addresses, domains, or account status requests through the OOMOL Mailcheck connector. <br>
Mitigation: Install and use it only where that connector path is acceptable, and avoid sending lookup values that violate user, customer, or organizational data-handling requirements. <br>
Risk: First-time setup may use remote shell installers for the oo CLI. <br>
Mitigation: Review the oo CLI install script source or use an approved installation path before running remote installer commands in restricted environments. <br>
Risk: Upstream connector schemas can change, which can make stale payloads incorrect. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing payloads for each connector action. <br>


## Reference(s): <br>
- [ClawHub Mailcheck skill page](https://clawhub.ai/oomol/oo-mailcheck) <br>
- [Mailcheck homepage](https://www.usercheck.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [get_status action reference](actions/get_status.md) <br>
- [validate_domain action reference](actions/validate_domain.md) <br>
- [verify_email action reference](actions/verify_email.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
