## Description: <br>
OptimoRoute (optimoroute.com). Use this skill for ANY OptimoRoute request - reading, creating, updating, and deleting data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to retrieve, create, update, merge, sync, or delete OptimoRoute orders through an OOMOL-connected account without handling raw API credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, merge, sync, or delete OptimoRoute orders. <br>
Mitigation: Confirm the exact payload and intended effect before write actions, and require explicit approval for delete targets. <br>
Risk: The skill requires an OOMOL-connected OptimoRoute account and sensitive credentials managed outside the artifact. <br>
Mitigation: Install only when the agent is intended to operate that account, and use the OOMOL connection flow rather than exposing raw API credentials. <br>
Risk: The optional oo CLI installation commands fetch and execute remote installer scripts. <br>
Mitigation: Review the installer source or install the CLI through a trusted method before running remote install commands. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-optimoroute) <br>
- [OptimoRoute Homepage](https://optimoroute.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, JSON] <br>
**Output Format:** [Markdown instructions with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
