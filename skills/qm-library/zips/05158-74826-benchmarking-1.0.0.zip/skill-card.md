## Description: <br>
Benchmarking helps agents design, run, score, and expand model or agent benchmarks focused on tool choice, hidden constraints, failure recovery, and proof-oriented completion. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[h-mascot](https://clawhub.ai/user/h-mascot) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, engineers, and operators use this skill to create or execute real-work benchmark packs that compare models and providers for routing decisions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Execution mode can consume provider quota and create local benchmark result files. <br>
Mitigation: Confirm the model roster and provider access before running, then store outputs in the designated benchmark folder. <br>
Risk: Benchmark reports can mislead if raw outputs are not locked before scoring or if provider and harness failures are treated as model failures. <br>
Mitigation: Save raw outputs before scoring, classify failures explicitly, and list failed or skipped models with reasons. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/h-mascot/benchmarking) <br>


## Skill Output: <br>
**Output Type(s):** [Markdown, JSON, Code, Shell commands, Guidance] <br>
**Output Format:** [Markdown guidance with JSON benchmark artifacts, optional code harnesses, and optional chart or image outputs.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Expected artifacts may include README.md, tasks.json, answer-key.json, rubric.md, judge notes, raw results, scored results, and optional league-table imagery.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
