## Description: <br>
Buildkite lets an agent inspect organizations, pipelines, users, tokens, and builds, and create, rebuild, or cancel builds through an OOMOL-connected Buildkite account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and release engineers use this skill to read Buildkite organizations, pipelines, users, access-token metadata, and build status, and to create, rebuild, or cancel CI/CD builds after confirming the target and payload. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, rebuild, or cancel Buildkite builds, which can affect CI/CD runs. <br>
Mitigation: Confirm the exact organization, pipeline, build number, payload, and intended effect before running create, rebuild, or cancel actions. <br>
Risk: The skill operates through an OOMOL-connected Buildkite account and requires sensitive credentials. <br>
Mitigation: Install only when the agent should operate Buildkite through that connected account, and inspect token scopes or account details when access is uncertain. <br>


## Reference(s): <br>
- [ClawHub Buildkite Skill](https://clawhub.ai/oomol/oo-buildkite) <br>
- [Buildkite Homepage](https://buildkite.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
