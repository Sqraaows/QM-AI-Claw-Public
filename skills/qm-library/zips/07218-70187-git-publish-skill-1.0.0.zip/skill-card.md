## Description: <br>
Publishes the current project to a GitHub remote by handling Git initialization, remote setup, commits, and pushes. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[orbisz](https://clawhub.ai/user/orbisz) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to publish local projects to GitHub, including first-time repository setup, committing pending changes, configuring remotes, and pushing the current branch. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The workflow can stage, commit, and publish all local project changes to GitHub. <br>
Mitigation: Use it only in repositories intended for publication, review status and diffs first, and check for secrets or private files before pushing. <br>
Risk: A force push may overwrite remote repository history if normal push fails and the user approves it. <br>
Mitigation: Confirm the remote URL, branch, and history impact before allowing a force push. <br>
Risk: The skill keeps persistent local mappings and may record execution details through its self-evolution notes. <br>
Mitigation: Remove or disable the mapping and self-evolution behavior if persistent local path, repository, or execution-detail records are not desired. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/orbisz/git-publish-skill) <br>
- [Repository mapping reference](references/repo-map.json) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown responses with shell commands, Git status summaries, and push results.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May stage and commit local changes, configure a Git remote, push a branch, and update the skill's local repository mapping file.] <br>

## Skill Version(s): <br>
1.0.0 (source: ClawHub release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
