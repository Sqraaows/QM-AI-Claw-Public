## Description: <br>
OpenRouter helps agents operate OpenRouter through an OOMOL-connected account for reading, creating, and updating OpenRouter data instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to inspect OpenRouter schemas, run OpenRouter connector actions, and manage model, provider, usage, credit, and generation workflows through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected OpenRouter account and can use sensitive credentials managed by OOMOL. <br>
Mitigation: Install only if you trust OOMOL and want the agent to use your connected OpenRouter account. <br>
Risk: Chat, message, and charge actions can send prompt data, consume credits, or affect account state. <br>
Mitigation: Review payloads and confirm the intended effect before running create or charge actions. <br>
Risk: The Coinbase charge action targets a deprecated upstream endpoint that may fail. <br>
Mitigation: Prefer current billing flows and treat 410 Gone responses from the deprecated endpoint as expected. <br>


## Reference(s): <br>
- [ClawHub OpenRouter skill page](https://clawhub.ai/oomol/oo-openrouter) <br>
- [OpenRouter homepage](https://openrouter.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OpenRouter connection settings](https://console.oomol.com/app-connections?provider=openrouter) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
