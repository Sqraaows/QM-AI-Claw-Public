## Description: <br>
Deepgram (deepgram.com). Use this skill for ANY Deepgram request - searching and reading data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to let an agent inspect Deepgram projects, balances, API keys, and model metadata through an OOMOL-connected account without exposing raw Deepgram credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected Deepgram account and can list sensitive project balances and API-key metadata. <br>
Mitigation: Install it only for users and agents that should access that Deepgram account, and treat returned project and key information as sensitive. <br>
Risk: The setup guidance includes an optional shell installer for the oo CLI. <br>
Mitigation: Prefer an official package when available, or inspect and verify the installer before running it. <br>


## Reference(s): <br>
- [Deepgram homepage](https://deepgram.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-deepgram) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with bash command examples and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before action payloads; action responses include data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
