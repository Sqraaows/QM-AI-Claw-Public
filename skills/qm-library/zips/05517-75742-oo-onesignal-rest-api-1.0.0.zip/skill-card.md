## Description: <br>
OneSignal helps agents operate the OneSignal REST API through an OOMOL-connected account for reading messages, creating push notifications, and canceling scheduled messages. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, marketers, and support operators use this skill to inspect OneSignal messages, create push notifications, and cancel scheduled messages from an agent workflow after confirming write or cancellation intent. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create push notifications and cancel scheduled messages, which changes OneSignal state. <br>
Mitigation: Require explicit user confirmation of recipients, message content, payload, intended effect, and cancellation target before create or cancel actions. <br>
Risk: The skill relies on OOMOL-brokered access to a connected OneSignal account. <br>
Mitigation: Install it only when OOMOL should broker that access, and verify the oo CLI installer source or use a trusted installation method. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-onesignal-rest-api) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [OneSignal homepage](https://onesignal.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions should fetch the live connector schema before constructing payloads; create and cancel operations require explicit user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
