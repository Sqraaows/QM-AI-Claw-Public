## Description: <br>
Install, set up, or drive any Hive CLI workflow from OpenClaw. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[ivankuznetsov](https://clawhub.ai/user/ivankuznetsov) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to install Hive, initialize projects, run Hive CLI workflows, and inspect or administer Hive tasks from OpenClaw. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Installer commands can modify the user's environment and enable a per-user daemon service. <br>
Mitigation: The skill requires explicit user confirmation before running installers and verifies the Hive CLI version before continuing. <br>
Risk: Destructive Hive admin verbs can remove worktrees, stop agents, close draft PRs, drop registry entries, or rewrite installed software. <br>
Mitigation: The skill restates the effect and requires explicit confirmation before running destructive or bypass commands. <br>
Risk: Foreground daemon or tail commands can hold the agent in a long-running process. <br>
Mitigation: The skill prefers detached daemon startup and requires confirmation before foreground or streaming commands. <br>


## Reference(s): <br>
- [Hive CLI ClawHub page](https://clawhub.ai/ivankuznetsov/hive-cli) <br>
- [Hive CLI homepage](https://github.com/ivankuznetsov/hive) <br>
- [Homebrew install formula](ivankuznetsov/hive/hive) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and summarized CLI output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Prefers JSON CLI output when available and summarizes task metadata, daemon setup results, initialization results, and runtime dependency issues.] <br>

## Skill Version(s): <br>
0.1.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
