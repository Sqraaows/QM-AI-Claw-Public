## Description: <br>
Databox helps agents operate Databox accounts through OOMOL's oo CLI for account discovery, dataset and data source management, and dataset ingestion. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to manage Databox ingestion workflows through a connected OOMOL account. It supports listing accounts, creating data sources and datasets, pushing JSON records, checking ingestion status, and deleting Databox resources when explicitly approved. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires credentialed access to a Databox account. <br>
Mitigation: Use only the connected OOMOL account intended for the task and approve credentialed actions only when they match the requested Databox workflow. <br>
Risk: Create and data-push actions can change Databox state. <br>
Mitigation: Inspect the live connector schema and confirm the exact payload and intended effect before running write actions. <br>
Risk: Delete actions can remove Databox datasets or data sources. <br>
Mitigation: Confirm the target identifier and get explicit approval before running destructive actions. <br>


## Reference(s): <br>
- [Databox homepage](https://databox.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Databox skill listing](https://clawhub.ai/oomol/oo-databox) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, JSON] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
