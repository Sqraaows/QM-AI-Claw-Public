## Description: <br>
Provides agent guidance for using the ofw-mcp MCP server to read and update OurFamilyWizard co-parenting messages, calendar events, expenses, journal entries, drafts, and attachments. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
People using an AI agent with access to their OurFamilyWizard account can use this skill to check co-parenting records and perform guided updates such as drafting or sending messages, managing calendar events, logging expenses, and creating journal entries. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The integration can expose sensitive OurFamilyWizard co-parenting records to an AI agent. <br>
Mitigation: Install only for intended OFW access, keep OFW credentials in a private secret mechanism or locked-down config, and review local cache and download locations. <br>
Risk: The integration can change co-parenting records by sending messages, deleting drafts or events, logging expenses, uploading files, or creating journal entries. <br>
Mitigation: Require explicit user confirmation before any write, send, delete, upload, or expense operation. <br>
Risk: Some reads can affect OFW state, such as last-seen status or marking unread messages as read. <br>
Mitigation: Warn the user before calls that may update read or last-seen state, and avoid running those calls silently in the background. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/ofw-mcp) <br>
- [ofw-mcp npm package](https://www.npmjs.com/package/ofw-mcp) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, Text] <br>
**Output Format:** [Markdown with JSON and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May propose MCP tool calls that read or modify OFW records; user confirmation is required before sending messages, deleting drafts or events, logging expenses, uploading files, or reading messages the user wants kept unread.] <br>

## Skill Version(s): <br>
2.3.1 (source: server evidence release.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
