## Description: <br>
Loops helps agents read and manage Loops contacts, contact properties, mailing lists, and workflow events through OOMOL's oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Marketing and communication teams, operators, and developers use this skill to query and maintain Loops customer data, mailing lists, contact properties, and workflow-triggering events from an agent session. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a trusted OOMOL oo CLI and Loops connector with access to a Loops account. <br>
Mitigation: Install and use the skill only when the publisher, CLI, connector, and connected Loops account are trusted and appropriately scoped. <br>
Risk: Create, update, event-send, and delete actions can modify contacts, custom properties, workflows, or remove Loops data. <br>
Mitigation: Review the exact payload and intended effect before approving write actions, and require explicit approval before destructive delete actions. <br>
Risk: Loops connector input and output schemas may change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each payload and match the payload to the returned schema. <br>


## Reference(s): <br>
- [Loops homepage](https://loops.so) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Loops skill](https://clawhub.ai/oomol/oo-loops) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs may include Loops connector responses containing data and meta.executionId values.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
