#!/usr/bin/env python3
"""
tlabel 命令行版本 - 纯后端无浏览器交互
支持直接通过命令行/API调用完成标注、训练、导出等全流程
"""
import os
import json
import argparse
import tempfile
import cv2
import numpy as np
from PIL import Image
from AiUtils import AIAutoLabeler

# 配置路径
BASE_PATH = os.getcwd()
UPLOAD_FOLDER = os.path.join(BASE_PATH, 'uploads')
ANNOTATIONS_FOLDER = os.path.join(UPLOAD_FOLDER, 'annotations')
ANNOTATIONS_FILE = os.path.join(ANNOTATIONS_FOLDER, 'annotations.json')
CLASSES_FILE = os.path.join(ANNOTATIONS_FOLDER, 'classes.json')
# 全局API密钥配置路径
GLOBAL_API_KEYS_PATH = "/root/.OpenClaw/workspace/memory/api_keys.json"

def load_global_api_config():
    """加载全局统一的API配置"""
    try:
        if os.path.exists(GLOBAL_API_KEYS_PATH):
            with open(GLOBAL_API_KEYS_PATH, 'r', encoding='utf-8') as f:
                config = json.load(f)
                aliyun_config = config.get("阿里云百炼", {})
                api_key = aliyun_config.get("api_key", "")
                if api_key:
                    return {
                        "apiUrl": "https://dashscope.aliyuncs.com/compatible-mode/v1",
                        "apiKey": api_key,
                        "model": "qwen3-vl-plus",
                        "inferenceTool": "阿里云百炼"
                    }
    except Exception as e:
        print(f"加载全局API配置失败: {str(e)}")
    # 失败返回默认本地配置
    return {
        "apiUrl": "http://127.0.0.1:1234/v1",
        "apiKey": "",
        "model": "qwen/qwen3-vl-plus",
        "inferenceTool": "LMStudio"
    }

# 加载全局API配置
GLOBAL_API_CONFIG = load_global_api_config()

# 初始化必要目录
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(ANNOTATIONS_FOLDER, exist_ok=True)

# 初始化标注文件
if not os.path.exists(ANNOTATIONS_FILE):
    with open(ANNOTATIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump({}, f)

# 初始化类别文件
if not os.path.exists(CLASSES_FILE):
    default_classes = [{'name': 'person', 'color': '#3aa757'}]
    with open(CLASSES_FILE, 'w', encoding='utf-8') as f:
        json.dump(default_classes, f)

def load_annotations():
    """加载标注信息"""
    if os.path.exists(ANNOTATIONS_FILE):
        try:
            with open(ANNOTATIONS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_annotations(annotations):
    """保存标注信息"""
    with open(ANNOTATIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump(annotations, f, indent=2, ensure_ascii=False)

def load_classes():
    """加载类别信息"""
    if os.path.exists(CLASSES_FILE):
        try:
            with open(CLASSES_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return []
    return []

def save_classes(classes):
    """保存类别信息"""
    with open(CLASSES_FILE, 'w', encoding='utf-8') as f:
        json.dump(classes, f, indent=2, ensure_ascii=False)

def add_class(class_name, color=None):
    """添加新类别"""
    classes = load_classes()
    existing_names = [cls['name'] for cls in classes]
    if class_name in existing_names:
        return False, "类别已存在"
    
    if not color:
        # 生成随机颜色
        color = '#{:06x}'.format(hash(class_name) % 0x1000000)
    
    classes.append({'name': class_name, 'color': color})
    save_classes(classes)
    return True, "类别添加成功"

def import_images(image_paths):
    """导入图片到数据集"""
    from shutil import copyfile
    imported = []
    errors = []
    
    for path in image_paths:
        if not os.path.exists(path):
            errors.append(f"文件不存在: {path}")
            continue
            
        filename = os.path.basename(path)
        dest_path = os.path.join(UPLOAD_FOLDER, filename)
        
        if os.path.exists(dest_path):
            errors.append(f"文件已存在: {filename}")
            continue
            
        copyfile(path, dest_path)
        imported.append(filename)
    
    return imported, errors

def import_video(video_path, frame_interval=30):
    """导入视频并抽帧"""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return [], f"无法打开视频文件: {video_path}"
    
    frame_count = 0
    saved_count = 0
    extracted_frames = []
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        if frame_count % frame_interval == 0:
            frame_filename = f"{video_name}_frame_{saved_count:06d}.jpg"
            frame_path = os.path.join(UPLOAD_FOLDER, frame_filename)
            cv2.imwrite(frame_path, frame)
            extracted_frames.append(frame_filename)
            saved_count += 1
            
        frame_count += 1
    
    cap.release()
    return extracted_frames, f"成功抽帧 {saved_count} 张"

def ai_annotate(images=None, label_name=None, api_config=None):
    """AI自动标注"""
    if not images:
        # 如果不指定图片，标注所有图片
        images = [f for f in os.listdir(UPLOAD_FOLDER) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
    
    if not label_name:
        return False, "请指定标注标签"
    
    if not api_config:
        # 优先使用全局配置
        api_config = GLOBAL_API_CONFIG.copy()
        api_config.update({
            "timeout": 30,
            "prompt": "检测图中物体，返回JSON：{\"detections\":[{\"label\":\"类别\",\"confidence\":0.9,\"bbox\":[x1,y1,x2,y2]}]}"
        })
    
    # 检查标签是否存在
    classes = load_classes()
    class_exists = any(cls['name'] == label_name for cls in classes)
    if not class_exists:
        add_class(label_name)
    
    # 初始化标注器
    labeler = AIAutoLabeler(
        api_config['apiUrl'],
        api_config['apiKey'],
        api_config['prompt'],
        api_config['timeout'],
        api_config['inferenceTool'],
        api_config['model']
    )
    
    annotations = load_annotations()
    processed = 0
    labeled = 0
    
    for image_name in images:
        image_path = os.path.join(UPLOAD_FOLDER, image_name)
        if not os.path.exists(image_path):
            continue
            
        processed += 1
        print(f"正在处理: {image_name} ({processed}/{len(images)})")
        
        try:
            result = labeler.analyze_image(image_path)
            detections = result.get("detections", [])
            if isinstance(detections, dict):
                detections = [detections]
                
            if detections:
                image_annotations = []
                for detection in detections:
                    if isinstance(detection, dict):
                        confidence = detection.get("confidence", 0.0)
                        bbox = detection.get("bbox", [0, 0, 0, 0])
                        bbox = list(map(float, bbox)) if isinstance(bbox, (list, tuple)) else [0, 0, 0, 0]
                        if len(bbox) < 4:
                            bbox = bbox + [0] * (4 - len(bbox))
                        x1, y1, x2, y2 = bbox[:4]
                        
                        annotation = {
                            "class": label_name,
                            "type": "rectangle",
                            "points": [
                                [x1, y1],
                                [x2, y1],
                                [x2, y2],
                                [x1, y2]
                            ],
                            "confidence": confidence
                        }
                        image_annotations.append(annotation)
                
                annotations[image_name] = image_annotations
                labeled += 1
                print(f"标注成功: {image_name}, 检测到 {len(detections)} 个目标")
                
        except Exception as e:
            print(f"处理失败 {image_name}: {str(e)}")
            continue
    
    save_annotations(annotations)
    return True, f"处理完成，共处理 {processed} 张，成功标注 {labeled} 张"

def export_dataset(output_path="dataset.zip", train_ratio=0.7, val_ratio=0.2, test_ratio=0.1, selected_classes=None):
    """导出YOLO格式数据集"""
    import zipfile
    import tempfile
    from shutil import copyfile
    
    if not selected_classes:
        # 导出所有类别
        classes = load_classes()
        selected_classes = [cls['name'] for cls in classes]
    
    annotations = load_annotations()
    images = [f for f in os.listdir(UPLOAD_FOLDER) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
    
    # 过滤有标注的图片
    annotated_images = [img for img in images if img in annotations and annotations[img]]
    
    if not annotated_images:
        return False, "没有可导出的标注数据"
    
    # 随机打乱
    np.random.shuffle(annotated_images)
    total = len(annotated_images)
    
    # 分割数据集
    train_count = int(total * train_ratio)
    val_count = int(total * val_ratio)
    
    train_images = annotated_images[:train_count]
    val_images = annotated_images[train_count:train_count+val_count]
    test_images = annotated_images[train_count+val_count:]
    
    # 创建临时目录
    with tempfile.TemporaryDirectory() as temp_dir:
        # 创建目录结构
        for split in ['train', 'val', 'test']:
            os.makedirs(os.path.join(temp_dir, split, 'images'), exist_ok=True)
            os.makedirs(os.path.join(temp_dir, split, 'labels'), exist_ok=True)
        
        # 创建data.yaml
        data_yaml = f"""path: .
train: train/images
val: val/images
test: test/images

nc: {len(selected_classes)}
names: {selected_classes}
"""
        with open(os.path.join(temp_dir, 'data.yaml'), 'w') as f:
            f.write(data_yaml)
        
        # 处理每个分割
        splits = [
            ('train', train_images),
            ('val', val_images),
            ('test', test_images)
        ]
        
        for split_name, split_images in splits:
            for image_name in split_images:
                src_img = os.path.join(UPLOAD_FOLDER, image_name)
                dst_img = os.path.join(temp_dir, split_name, 'images', image_name)
                copyfile(src_img, dst_img)
                
                # 生成标签文件
                base_name = os.path.splitext(image_name)[0]
                label_path = os.path.join(temp_dir, split_name, 'labels', f"{base_name}.txt")
                
                image_annotations = annotations.get(image_name, [])
                with open(label_path, 'w') as f:
                    for ann in image_annotations:
                        if ann['class'] in selected_classes:
                            # 获取类别ID
                            class_id = selected_classes.index(ann['class'])
                            
                            # 获取图片尺寸
                            img = Image.open(src_img)
                            width, height = img.size
                            
                            points = np.array(ann['points'])
                            x_min = np.min(points[:, 0])
                            y_min = np.min(points[:, 1])
                            x_max = np.max(points[:, 0])
                            y_max = np.max(points[:, 1])
                            
                            # 转换为YOLO格式
                            center_x = ((x_min + x_max) / 2) / width
                            center_y = ((y_min + y_max) / 2) / height
                            bbox_width = (x_max - x_min) / width
                            bbox_height = (y_max - y_min) / height
                            
                            f.write(f"{class_id} {center_x:.6f} {center_y:.6f} {bbox_width:.6f} {bbox_height:.6f}\n")
        
        # 打包为zip
        with zipfile.ZipFile(output_path, 'w') as zipf:
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arc_name = os.path.relpath(file_path, temp_dir)
                    zipf.write(file_path, arc_name)
    
    return True, f"数据集导出成功，保存到: {output_path}，共包含 {len(annotated_images)} 张标注图片"

def main():
    parser = argparse.ArgumentParser(description='tlabel 命令行版 - 无浏览器交互的图像标注工具')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 导入图片
    import_parser = subparsers.add_parser('import', help='导入图片/视频')
    import_parser.add_argument('paths', nargs='+', help='图片/视频文件路径')
    import_parser.add_argument('--frame-interval', type=int, default=30, help='视频抽帧间隔，默认30帧')
    
    # 添加类别
    add_class_parser = subparsers.add_parser('add-class', help='添加标注类别')
    add_class_parser.add_argument('name', help='类别名称')
    add_class_parser.add_argument('--color', help='类别颜色（十六进制）')
    
    # AI标注
    annotate_parser = subparsers.add_parser('annotate', help='AI自动标注')
    annotate_parser.add_argument('--images', nargs='+', help='要标注的图片文件名，不指定则标注所有图片')
    annotate_parser.add_argument('--label', required=True, help='标注标签名称')
    annotate_parser.add_argument('--api-url', default=GLOBAL_API_CONFIG['apiUrl'], help='API地址，默认使用阿里云百炼')
    annotate_parser.add_argument('--api-key', default=GLOBAL_API_CONFIG['apiKey'], help='API密钥，默认读取全局配置')
    annotate_parser.add_argument('--model', default=GLOBAL_API_CONFIG['model'], help='模型名称，默认使用 qwen3-vl-8b-thinking')
    annotate_parser.add_argument('--prompt', default='检测图中物体，返回JSON：{"detections":[{"label":"类别","confidence":0.9,"bbox":[x1,y1,x2,y2]}]}', help='标注提示词')
    annotate_parser.add_argument('--timeout', type=int, default=30, help='API超时时间（秒）')
    
    # 导出数据集
    export_parser = subparsers.add_parser('export', help='导出YOLO格式数据集')
    export_parser.add_argument('--output', default='dataset.zip', help='输出文件路径')
    export_parser.add_argument('--train-ratio', type=float, default=0.7, help='训练集比例')
    export_parser.add_argument('--val-ratio', type=float, default=0.2, help='验证集比例')
    export_parser.add_argument('--test-ratio', type=float, default=0.1, help='测试集比例')
    export_parser.add_argument('--classes', nargs='+', help='要导出的类别，不指定则导出所有')
    
    # 列出所有图片
    subparsers.add_parser('list-images', help='列出所有导入的图片')
    
    # 列出所有类别
    subparsers.add_parser('list-classes', help='列出所有标注类别')
    
    args = parser.parse_args()
    
    if args.command == 'import':
        for path in args.paths:
            if path.lower().endswith(('.mp4', '.avi', '.mov', '.flv', '.wmv', '.mkv')):
                # 视频文件
                frames, msg = import_video(path, args.frame_interval)
                print(msg)
                if frames:
                    print(f"抽帧文件: {', '.join(frames[:5])}{'...' if len(frames) > 5 else ''}")
            else:
                # 图片文件
                imported, errors = import_images([path])
                if imported:
                    print(f"成功导入: {imported[0]}")
                if errors:
                    print(f"错误: {errors[0]}")
    
    elif args.command == 'add-class':
        success, msg = add_class(args.name, args.color)
        print(msg)
    
    elif args.command == 'annotate':
        api_config = {
            "apiUrl": args.api_url,
            "apiKey": args.api_key,
            "model": args.model,
            "prompt": args.prompt,
            "timeout": args.timeout,
            "inferenceTool": "LMStudio"
        }
        success, msg = ai_annotate(args.images, args.label, api_config)
        print(msg)
    
    elif args.command == 'export':
        success, msg = export_dataset(args.output, args.train_ratio, args.val_ratio, args.test_ratio, args.classes)
        print(msg)
    
    elif args.command == 'list-images':
        images = [f for f in os.listdir(UPLOAD_FOLDER) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
        annotations = load_annotations()
        print(f"共导入 {len(images)} 张图片：")
        for img in images:
            ann_count = len(annotations.get(img, []))
            status = f"已标注({ann_count}个标注)" if ann_count > 0 else "未标注"
            print(f"  - {img}: {status}")
    
    elif args.command == 'list-classes':
        classes = load_classes()
        print(f"共 {len(classes)} 个标注类别：")
        for cls in classes:
            print(f"  - {cls['name']} (颜色: {cls['color']})")
    
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
