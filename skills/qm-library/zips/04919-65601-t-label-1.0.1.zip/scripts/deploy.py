#!/usr/bin/env python3
import os
import subprocess
import sys

def run_cmd(cmd, cwd=None):
    print(f"Running: {cmd}")
    try:
        result = subprocess.run(cmd, shell=True, cwd=cwd, check=True, capture_output=True, text=True)
        print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr}")
        return False

def deploy_venv(xclabel_dir):
    print("Deploying with virtual environment...")
    # 创建虚拟环境
    if not run_cmd("python3 -m venv venv", cwd=xclabel_dir):
        return False
    # 激活虚拟环境并安装依赖
    pip_path = os.path.join(xclabel_dir, "venv/bin/pip")
    if not os.path.exists(pip_path):
        pip_path = os.path.join(xclabel_dir, "venv/Scripts/pip.exe")
    if not run_cmd(f"{pip_path} install -r requirements.txt", cwd=xclabel_dir):
        return False
    print("Virtual environment deployment completed!")
    print(f"To start service: cd {xclabel_dir} && source venv/bin/activate && python app.py")
    return True

def deploy_docker(xclabel_dir):
    print("Deploying with Docker...")
    # 检查Docker是否安装
    if not run_cmd("docker --version"):
        print("Docker not installed, please install Docker first.")
        return False
    # 构建镜像
    if not run_cmd("docker build -t xclabel .", cwd=xclabel_dir):
        return False
    # 运行容器
    if not run_cmd("docker run -d -p 8000:8000 --name xclabel xclabel", cwd=xclabel_dir):
        return False
    print("Docker deployment completed!")
    print("Service is running at http://localhost:8000")
    return True

if __name__ == '__main__':
    xclabel_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../references/xclabel')
    if not os.path.exists(xclabel_dir):
        print(f"Error: xclabel directory not found at {xclabel_dir}")
        sys.exit(1)
    
    if len(sys.argv) > 1 and sys.argv[1] == 'docker':
        success = deploy_docker(xclabel_dir)
    else:
        success = deploy_venv(xclabel_dir)
    
    sys.exit(0 if success else 1)
