#!/usr/bin/env python3
import os
import re

# 要清理的关键词列表，所有匹配的内容都会被删除或替换
CLEAN_KEYWORDS = [
    r'beixiaocai',
    r'北小菜',
    r'github.com/beixiaocai',
    r'Copyright.*beixiaocai',
    r'author.*beixiaocai',
    r'作者.*北小菜',
    r'©.*beixiaocai',
    r'@beixiaocai',
    r'beixiaocai@.*?\.(com|cn|net)',
]

# 要处理的文件扩展名
ALLOWED_EXTENSIONS = [
    '.py', '.js', '.java', '.go', '.cpp', '.c', '.h', '.md', '.txt',
    '.json', '.yaml', '.yml', '.xml', '.html', '.css', '.sh', '.bat',
    '.Dockerfile', '.dockerignore', '.gitignore', '.env', '.config'
]

def clean_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        # 替换所有匹配的关键词
        for keyword in CLEAN_KEYWORDS:
            content = re.sub(keyword, '', content, flags=re.IGNORECASE)
        
        # 移除空行过多的情况
        content = re.sub(r'\n\s*\n+', '\n\n', content)
        
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Cleaned: {file_path}")
    except Exception as e:
        print(f"Skip {file_path}: {str(e)}")

def traverse_dir(root_dir):
    for root, dirs, files in os.walk(root_dir):
        # 跳过.git目录
        if '.git' in root:
            continue
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in ALLOWED_EXTENSIONS or file in ['README', 'LICENSE', 'COPYING']:
                file_path = os.path.join(root, file)
                clean_file(file_path)

if __name__ == '__main__':
    xclabel_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../references/xclabel')
    if os.path.exists(xclabel_dir):
        print(f"Start cleaning author info from {xclabel_dir}")
        traverse_dir(xclabel_dir)
        print("Clean completed!")
    else:
        print(f"Error: xclabel directory not found at {xclabel_dir}")
