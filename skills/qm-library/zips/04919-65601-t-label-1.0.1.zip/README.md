# t-label 全自动化标注工具使用手册
## 🎯 产品简介
t-label 是一款纯服务端、无浏览器依赖的自动化图像标注工具，基于开源项目深度改造而成，支持AI自动标注、数据集管理、YOLO格式导出等全流程功能，无需任何前端交互即可完成标注任务。

## ✨ 核心特性
- 🚀 **纯命令行操作**：完全不需要浏览器，所有功能通过命令/API调用完成
- 🤖 **AI自动标注**：支持对接各类大模型（LMStudio、ollama、阿里云通义千问、Qwen-VL等）实现零人工标注
- 📦 **多格式支持**：支持图片、视频、LabelMe格式数据集导入，自动视频抽帧
- 📊 **YOLO格式导出**：一键导出标准YOLO训练格式数据集，支持自定义训练/验证/测试比例
- 🏷️ **灵活标签管理**：支持自定义标签、颜色，多类别标注
- ⚡ **高性能**：批量处理、异步标注、进度实时反馈

## 🔧 安装部署
### 环境要求
- Python 3.8+
- 依赖安装：
```bash
pip install flask flask-cors flask-socketio opencv-python pillow numpy requests ultralytics
```

### 快速使用
工具路径：`/root/.OpenClaw/workspace/skills/t-label/scripts/tlabel_cli.py`
直接执行即可查看帮助：
```bash
python tlabel_cli.py --help
```

## 📖 详细使用指南
### 1. 数据集导入
#### 导入图片
```bash
# 导入单张图片
python tlabel_cli.py import /path/to/image.jpg

# 批量导入图片
python tlabel_cli.py import /path/to/images/*.jpg /path/to/images/*.png

# 导入整个文件夹
python tlabel_cli.py import /path/to/dataset/*
```

#### 导入视频并自动抽帧
```bash
# 每10帧抽1张
python tlabel_cli.py import /path/to/video.mp4 --frame-interval 10

# 每5帧抽1张
python tlabel_cli.py import /path/to/video.mp4 --frame-interval 5
```
支持视频格式：mp4、avi、mov、flv、wmv、mkv

### 2. 标签管理
#### 查看所有标签
```bash
python tlabel_cli.py list-classes
```
输出示例：
```
共 3 个标注类别：
  - person (颜色: #3aa757)
  - car (颜色: #ff0000)
  - defect (颜色: #ffff00)
```

#### 添加新标签
```bash
# 自动生成颜色
python tlabel_cli.py add-class 病害

# 指定颜色
python tlabel_cli.py add-class 裂纹 --color "#ff0000"
```

### 3. AI自动标注
#### 基础使用
```bash
python tlabel_cli.py annotate --label "病害" \
  --api-url "http://你的大模型API地址/v1" \
  --model "qwen/qwen3-vl-8b" \
  --prompt "检测图片中的混凝土病害，返回bbox坐标"
```

#### 自定义参数
```bash
# 只标注指定图片
python tlabel_cli.py annotate --images img1.jpg img2.jpg --label "裂缝"

# 指定API密钥和超时时间
python tlabel_cli.py annotate --label "缺陷" \
  --api-url "https://dashscope.aliyuncs.com/compatible-mode/v1" \
  --api-key "你的阿里云API密钥" \
  --model "qwen-vl-max" \
  --timeout 60
```

#### 支持的推理后端
| 推理工具 | 示例API地址 | 支持的模型 |
|---------|------------|----------|
| LMStudio | `http://127.0.0.1:1234/v1` | Qwen3-VL系列、LLaVA系列等本地部署模型 |
| Ollama | `http://127.0.0.1:11434/v1` | Qwen3-VL系列、LLaVA系列等本地部署模型 |
| vLLM | `http://你的vLLM服务地址/v1` | 各类开源视觉大模型 |
| 阿里云通义千问 | `https://dashscope.aliyuncs.com/compatible-mode/v1` | qwen-vl-max、qwen3-vl-plus、qwen3-vl-8b等 |
| 其他OpenAI兼容接口 | 对应服务地址 | 所有兼容OpenAI格式的视觉大模型 |

### 4. 数据集管理
#### 查看数据集状态
```bash
python tlabel_cli.py list-images
```
输出示例：
```
共导入 128 张图片：
  - img_001.jpg: 已标注(3个标注)
  - img_002.jpg: 未标注
  - img_003.jpg: 已标注(1个标注)
```

### 5. 导出数据集
#### 基础导出
```bash
# 导出所有类别，默认7:2:1分割
python tlabel_cli.py export --output 病害数据集.zip
```

#### 自定义导出
```bash
# 指定导出类别和分割比例
python tlabel_cli.py export --output 桥梁病害数据集.zip \
  --classes 裂缝 剥落 露筋 \
  --train-ratio 0.8 \
  --val-ratio 0.15 \
  --test-ratio 0.05
```

#### 导出结果结构
导出的zip包结构符合YOLO训练标准：
```
dataset/
├── data.yaml          # 数据集配置文件
├── train/
│   ├── images/        # 训练集图片
│   └── labels/        # 训练集标注（txt格式）
├── val/
│   ├── images/        # 验证集图片
│   └── labels/        # 验证集标注
└── test/
    ├── images/        # 测试集图片
    └── labels/        # 测试集标注
```

## 📡 API调用方式
你也可以直接在Python代码中调用，无需通过命令行：
```python
from tlabel_cli import import_images, ai_annotate, export_dataset

# 1. 导入数据集
imported, errors = import_images(["/path/to/your/dataset/*.jpg"])
print(f"成功导入 {len(imported)} 张图片")

# 2. AI自动标注
success, msg = ai_annotate(
    label_name="混凝土病害",
    api_config={
        "apiUrl": "http://127.0.0.1:1234/v1",
        "model": "qwen/qwen3-vl-8b",
        "prompt": "检测图片中的所有混凝土病害，返回bbox坐标数组",
        "timeout": 30
    }
)
print(msg)

# 3. 导出数据集
success, msg = export_dataset(
    output_path="concrete_defect_dataset.zip",
    selected_classes=["裂缝", "剥落", "露筋"],
    train_ratio=0.8,
    val_ratio=0.15
)
print(msg)
```

## 💡 最佳实践
### 1. 大模型标注提示词优化
为了获得更好的标注效果，建议使用明确的提示词：
```
# 示例1：病害检测
"检测图片中的混凝土表面病害，包括裂缝、剥落、露筋、蜂窝麻面，每个目标返回bbox坐标，格式为[x1, y1, x2, y2]，左上角为原点"

# 示例2：目标检测
"检测图中的所有车辆，包括轿车、卡车、公交车、摩托车，返回每个目标的类别和bbox坐标，坐标范围0到图片宽高"
```

### 2. 批量处理优化
- 对于大量图片，建议分批次标注，每次处理100-200张
- 视频抽帧建议间隔不小于10，避免重复冗余图片
- 导出前使用`list-images`命令确认标注完成度

### 3. 常见问题
**Q：AI标注准确率低怎么办？**
A：1. 优化提示词，尽可能详细描述要检测的目标；2. 更换更大参数的视觉模型；3. 对检测结果进行人工校验后再导出。

**Q：支持的图片格式有哪些？**
A：支持jpg、jpeg、png、bmp、gif格式。

**Q：标注数据保存在哪里？**
A：所有标注数据保存在`scripts/uploads/annotations/`目录下，annotations.json保存标注信息，classes.json保存类别信息。

**Q：使用阿里云qwen3-vl-plus模型时标注框错位怎么办？**
A：qwen3-vl-plus默认返回的bbox坐标是基于图片长边缩放至1000px的尺寸，需要按原图实际分辨率缩放：
  - 宽度缩放系数 = 原图宽度 / 1000
  - 高度缩放系数 = 原图高度 / 1000
  - 修正后坐标 = [x1*宽度系数, y1*高度系数, x2*宽度系数, y2*高度系数]
  本工具已内置自动坐标转换，v1.0.1及以上版本无需手动处理。

## 📌 版本信息
### 当前版本：v1.0.1
- 更新时间：2026-03-31
- 新增支持：阿里云通义千问qwen3-vl-plus模型
- 功能优化：内置qwen3-vl-plus坐标自动转换，解决标注框错位问题
- 支持平台：Windows/Linux/macOS

### 历史版本
- v1.0.0（2026-03-31）：初始版本，基础功能上线

