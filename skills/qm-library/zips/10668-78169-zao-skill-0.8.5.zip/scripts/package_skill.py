#!/usr/bin/env python3
"""
Skill Packager - Creates a distributable .skill file of a skill folder

Usage:
    package_skill.py <path/to/skill-folder> [output-directory]

Example:
    package_skill.py skills/public/my-skill
    package_skill.py skills/public/my-skill ./dist
"""

import sys
import zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from quick_validate import validate_skill


def package_skill(skill_path, output_dir=None):
    """
    Package a skill folder into a .skill file.

    Args:
        skill_path: Path to the skill folder
        output_dir: Optional output directory for the .skill file (defaults to current directory)

    Returns:
        Path to the created .skill file, or None if error
    """
    skill_path = Path(skill_path).resolve()

    # Validate skill folder exists
    if not skill_path.exists():
        print(f"Error: Skill folder not found: {skill_path}")
        return None

    if not skill_path.is_dir():
        print(f"Error: Path is not a directory: {skill_path}")
        return None

    # Validate SKILL.md exists
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        print(f"Error: SKILL.md not found in {skill_path}")
        return None

    # Run validation before packaging (safety net — normal flow runs Phase 3 separately)
    print("Validating skill...")
    result = validate_skill(skill_path)
    if not result["valid"]:
        failures = [c for c in result["checks"] if c["status"] == "FAIL"]
        print(f"Validation failed ({len(failures)} FAILs):")
        for f in failures:
            print(f"  - {f['item']}: {f.get('detail', '')}")
        print("   Please fix the validation errors before packaging.")
        return None
    print("Validation passed.\n")

    # Determine output location
    skill_name = skill_path.name
    if output_dir:
        output_path = Path(output_dir).resolve()
        output_path.mkdir(parents=True, exist_ok=True)
    else:
        output_path = Path.cwd()

    skill_filename = output_path / f"{skill_name}.skill"

    # Create the .skill file (zip format)
    EXCLUDE_DIRS = {'__pycache__', '.git', '.github', '.hg', '.svn', 'node_modules'}
    EXCLUDE_FILES = {'.ds_store', '.gitignore', '.gitattributes'}

    try:
        with zipfile.ZipFile(skill_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Walk through the skill directory
            for file_path in skill_path.rglob('*'):
                # Skip directories and excluded files
                if file_path.is_file():
                    # Skip excluded directories
                    if any(part in EXCLUDE_DIRS for part in file_path.parts):
                        continue
                    # Skip wip directories (any path ending with .wip)
                    if any(part.endswith('.wip') for part in file_path.parts):
                        continue
                    # Skip excluded files
                    if file_path.name.lower() in EXCLUDE_FILES:
                        continue
                    # Calculate the relative path within the zip
                    arcname = file_path.relative_to(skill_path.parent)
                    zipf.write(file_path, arcname)
                    print(f"  Added: {arcname}")

        print(f"\nSuccessfully packaged skill to: {skill_filename}")
        return skill_filename

    except Exception as e:
        print(f"Error creating .skill file: {e}")
        return None


def main():
    if len(sys.argv) < 2:
        print("Usage: package_skill.py <path/to/skill-folder> [output-directory]")
        print("\nExample:")
        print("  package_skill.py skills/public/my-skill")
        print("  package_skill.py skills/public/my-skill ./dist")
        sys.exit(1)

    skill_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None

    print(f"Packaging skill: {skill_path}")
    if output_dir:
        print(f"   Output directory: {output_dir}")
    print()

    result = package_skill(skill_path, output_dir)

    if result:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
