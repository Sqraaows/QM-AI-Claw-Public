## Description: <br>
GitHub (github.com). Use this skill for GitHub requests that read, create, update, or delete repository, issue, pull request, release, workflow, event, and search data through the OOMOL GitHub connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to let an agent operate GitHub through an OOMOL-connected account, including repository inspection, issue and pull request workflows, release lookup, workflow reruns, status updates, reviews, comments, labels, and search. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can modify GitHub state through merges, file changes, issue or pull request edits, workflow reruns, label changes, reviewer changes, and deletion or removal actions. <br>
Mitigation: Review granted GitHub scopes and require confirmation of the exact target, payload, and intended effect before state-changing or destructive actions. <br>
Risk: The skill operates through the user's OOMOL-connected GitHub account, so actions inherit that account's repository access and permissions. <br>
Mitigation: Connect only the GitHub account and scopes needed for the intended workflow, and re-check connection scope or credential-expiration errors before retrying. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-github) <br>
- [GitHub Homepage](https://github.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON when actions are executed with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
