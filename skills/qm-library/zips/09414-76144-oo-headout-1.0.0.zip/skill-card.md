## Description: <br>
Headout (headout.com). Use this skill for any Headout request involving searching or reading Headout data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to inspect Headout schemas and run read-oriented Headout connector actions through the oo CLI. It supports discovery of cities, categories, product listings, product details, inventory, and booking records available to the connected Headout API key. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read Headout data available to the connected Headout API key, including bookings. <br>
Mitigation: Use a Headout API key whose access matches the intended agent use, and review booking access before installing or running the connector. <br>
Risk: First-time setup requires trusting the OOMOL account connection and oo CLI authentication flow. <br>
Mitigation: Only run oo CLI installation, login, or Headout connection setup when needed and when the user trusts OOMOL for this connector. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-headout) <br>
- [Headout Homepage](https://www.headout.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, API Calls, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs agents to inspect the live connector schema before constructing JSON payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
