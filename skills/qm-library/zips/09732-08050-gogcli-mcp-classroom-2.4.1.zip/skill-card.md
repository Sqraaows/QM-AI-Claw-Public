## Description: <br>
Provides an MCP server-backed agent skill for managing Google Classroom courses, rosters, announcements, assignments, submissions, grades, topics, invitations, and profiles. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Educators, administrators, and support agents can use this skill to administer Google Classroom resources through an authenticated gogcli Classroom MCP server. It is intended for real Classroom operations, including roster, coursework, invitation, and grading workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can give an agent broad authority over live Google Classroom resources. <br>
Mitigation: Install it only for intended Classroom administration and use a least-privilege Google account. <br>
Risk: Destructive or sensitive actions can affect courses, rosters, invitations, submissions, and grades. <br>
Mitigation: Require explicit user requests and manual confirmation before deletes, archives, roster removals, invitation actions, and grade changes. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp-classroom) <br>
- [gogcli project](https://github.com/openclaw/gogcli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON configuration examples and command guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May trigger live Google Classroom MCP tool actions when installed and authenticated.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
