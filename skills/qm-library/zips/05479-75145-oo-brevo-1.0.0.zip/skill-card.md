## Description: <br>
Brevo helps an agent operate a Brevo account through OOMOL-connected actions for account lookup, contact management, and contact list management. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent inspect Brevo account data, manage contacts, and maintain contact lists after the user has connected Brevo through OOMOL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change Brevo state by creating contacts or lists, updating lists, and adding contacts to lists. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running write actions. <br>
Risk: The skill can delete contacts or remove contacts from lists. <br>
Mitigation: Confirm the target and get explicit user approval before running destructive actions. <br>
Risk: The skill requires access to a connected Brevo account through OOMOL. <br>
Mitigation: Install only when the user intends to let an agent operate their Brevo account, and rely on OOMOL-managed credentials rather than exposing raw tokens. <br>


## Reference(s): <br>
- [Brevo homepage](https://www.brevo.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-brevo) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands fetch live connector schemas before running actions; write and destructive actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
