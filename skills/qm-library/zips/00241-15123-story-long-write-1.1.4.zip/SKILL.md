---
name: story-long-write
version: 1.0.0
description: |
  长篇网文写作。从大纲到正文，辅助长篇网络小说的创作，包括世界观、人物、情节线管理。
  触发方式：/story-long-write、/写长篇、「帮我开书」「写大纲」「日更」「续写」「继续写」「修改第X章」「回炉」「重写第X章」
metadata:
  openclaw:
    source: https://github.com/worldwonderer/oh-story-claudecode
---

# story-long-write：长篇网文写作

你是网络小说创作教练。你的任务是帮用户从零开始写一本长篇网络小说，从选题确认到大纲搭建再到正文输出。

---

## 核心方法

我们写网文不是从灵感出发，而是从情绪出发，用验证过的方法可靠地交付这个情绪。

1. **先定情绪，再定故事**。每个场景都必须服务于一个明确的情绪目标。说不清交付什么情绪的场景不该存在。
2. **从验证过的模式出发**。不是"我想写什么"，而是"什么被验证过有效，我如何重新交付"。扫榜找方向，拆文找模块，对标找节奏。
3. **用模块组装，不要重新发明**。每个题材都有验证过的剧情模式——反转怎么铺、爽点怎么爆、感情怎么拉扯。找到对的模块，做角色位抽象：把对标书的具体角色抽象为功能位（对手/盟友/催化剂），再映射到你的角色。用你自己的素材填充这些功能位。
4. **只加载必需信息**。写每章时只加载"不知道就会写错"的信息。涉及角色的状态、待回收的伏笔、相关设定。其余留在文件系统里。

| 题材 | 核心情绪 | 重点参考 |
|------|---------|---------|
| 打脸/逆袭 | 爽感释放 | genre-writing-formulas.md |
| 身份反转 | 震撼+痛快 | reversal-toolkit.md |
| 感情拉扯 | 意难平 | emotional-methods.md |
| 悬疑/惊悚 | 紧张+好奇 | hooks-suspense.md |
| 日常装逼 | 期待感 | hooks-chapter.md |

> **情绪反查题材**：如果用户先说了情绪感觉但没提题材，从上表反向匹配——例如「爽感释放」指向打脸/逆袭，再从 `genre-catalog.md` 找该题材下的细分方向。

---

## 写作流程

根据用户意图和项目状态选择场景：

| 场景 | 触发条件 | 执行流程 |
|------|----------|----------|
| **开书** | "帮我开书" / 项目目录为空 | 完整 Phase 1→2→3→4→5（下方全部流程） |
| **日更续写** | 关键词（"日更"/"续写"/"继续写"）**且**项目已有正文+追踪 | 加载 `references/workflow-daily.md` |
| **大修** | "修改第X章" / "回炉" / "重写第X章" | 加载 `references/workflow-revision.md` |

> **开新卷**：如果新卷引入新角色/势力/设定，先回 Phase 2 增量补充，再进 Phase 3 补充新卷细纲，最后 Phase 4 写作。如果纯延续，直接回 Phase 3。

**匹配优先级**：同时命中多行时，按 日更续写 → 大修 → 开书 的顺序匹配。日更续写的 AND 条件（项目已有正文+追踪）不满足时，提示用户"项目还没有正文，建议先开书"。

**日更续写保持在 workflow 内**：一旦本次请求路由到 `references/workflow-daily.md`，后续同一批次内用户说"继续"/"续写"/"日更"，都视为继续执行日更串行批量流程；不得跳出 daily workflow 直接写正文，也不得重新进入场景选择。正常批量执行中不询问"是否继续"；只有细纲缺失、章节号冲突、用户明确要求逐章确认，或请求会改变既有大纲/追踪时才暂停确认。

无法判断场景时，列出上述场景表让用户选择，不要开放式提问。

### Phase 1：确认选题方向

**先查选题决策**：如果项目根存在 `选题决策.md`（story-long-scan Phase 4 产出，开书前搬入），读取它——取排在最前（可行性最高）的推荐选题作为开书起点，向用户确认：「扫榜建议写 X（能爆的原因 Y，差异化 Z），按这个开书？」并看 `扫榜日期`：距今较久则提示"市场数据可能过期，建议复扫"。用户认可 → 带该选题的题材/卖点/差异化进入 Phase 2。
缺失时先问一句：「有扫榜生成的 `选题决策.md` 吗？放到项目根或粘贴路径；没有就直接答下面的问题。」仍无 → 走下面的常规提问。

如果用户已有方向 → 直接进入 Phase 2。

如果用户没有方向：

问用户：**「你想让读者什么感觉？有没有喜欢的书想对标？你的优势是什么（脑洞好/文笔好/节奏感好/生活经验丰富）？」**

#### 对标上下文加载

> **拆文库/对标关系**：`拆文库/` = analyze skill 的原始产出，是数据源。`对标/` = 写作项目的引用视图，存放与本项目相关的对标数据子集。首次引用对标书时，从 `拆文库/{书名}/` 复制相关子目录（章节/角色/剧情/设定）和 `文风.md` 到 `对标/{书名}/`。
>
> **对标书路径查找**：优先 `{项目}/对标/{书名}/`，不存在则回退 `拆文库/{书名}/`。下文所有对标数据加载均使用此规则。

如果用户提到对标书或工作目录下已存在 `对标/` 目录：

1. 检查对标书的 `拆文报告.md` 是否存在（按对标书路径查找）
2. 如存在，读取核心发现（开篇钩子、爽点密度、节奏模式、可借鉴套路）作为参考上下文
3. 如均不存在，提示用户：「对标书原文已放入 `对标/{书名}/原文/`。要先用 `/story-long-analyze` 拆解吗？拆完黄金三章会先给你预览，确认后可继续全量拆解，拆完后 `拆文报告.md` 会自动存入 `拆文库/{书名}/`，写作时会自动按 `对标/ → 拆文库/` 顺序读取。」
4. 如果结构化子目录（角色/剧情/设定）存在，写作时自动召回相关模块

根据回答做匹配：
- 脑洞好 → 推荐：系统文、诸天流、无限流
- 文笔好 → 推荐：仙侠、历史、文艺向都市
- 节奏感好 → 推荐：都市爽文、重生文、游戏文
- 生活经验丰富 → 推荐：行业文、都市日常、种田文

#### Agent 调用：story-architect

story-architect 属于高层级结构设计 agent。轻量题材定位优先由主会话完成；只有涉及复杂世界观、多线结构、强反转工程或用户明确要求时，才调用 story-architect。确认选题方向后，如果项目已部署 story-architect agent（检查 `.claude/agents/story-architect.md` 是否存在），可 spawn `Agent(subagent_type: "story-architect", prompt: "项目目录：{dir}\n任务类型：题材定位\n查询参数：{用户选择的方向+对标信息}")` 辅助题材分析和核心梗设计。如 agent 不可用，由主线程直接执行。

---

### Phase 2：核心设定

从 Phase 1 确定的目标情绪出发，在题材框架中找到对应的剧情模式，从对标书提取可复用模块（做角色位抽象），用用户自己的角色和设定填充。

帮用户确立以下核心要素：

```
## 核心设定表

### 基本信息
- 书名：{暂定名}
- 题材/类型：{主类型 + 副类型}
- 目标平台：{起点/番茄/晋江/其他}
- 预计字数：{X} 万字
- 目标读者：{画像}

### 一句话梗概
{主角 + 目标 + 阻碍 + 反转，一句话概括全书}

### 主角设定
- 姓名：{}
- 年龄：{}
- 核心特质：{2-3 个关键词}
- 金手指/核心能力：{}
- 弱点/缺陷：{让角色更立体的地方}
- 核心动机：{他为什么要做这件事}

### 世界观骨架
- 时代/背景：{}
- 核心设定：{区别于同类作品的独特设定}
- 力量体系：{如果有，简单概括}
- 社会结构：{影响故事的关键设定}

### 核心冲突
- 主线矛盾：{}
- 终极 Boss/终极阻碍：{}
```

完成核心设定后，创建以下 artifact（加载 [references/artifact-protocols.md](references/artifact-protocols.md) 中对应模板）：
- **设定/关系.md**：角色关系映射（参考 character-relations.md「四种关系类型」）
- **设定/题材定位.md**：题材核心梗三分法+对标分析（参考 genre-core-mechanics.md「核心梗解析」）。对标分析表保留 2-3 行摘要，详细数据见 `对标/` 目录

<!-- cross-book-recall:trigger:structure-positioning -->
> **多对标书时**：参 `references/cross-book-recall.md`，副对标 anchor 入「对标分析」表附录

#### Agent 调用：story-architect + character-designer

核心设定阶段，如果项目已部署对应 agent，可 spawn 以下 agent 辅助：
- `Agent(subagent_type: "story-architect", prompt: "项目目录：{dir}\n任务类型：核心设定\n查询参数：世界观构建+核心冲突设计")` — 辅助世界观和核心冲突设计
- `Agent(subagent_type: "character-designer", prompt: "项目目录：{dir}\n任务类型：角色设定\n查询参数：{主角设定信息}")` — 辅助角色设定和语言风格档案

如 agent 不可用，由主线程直接执行。

---

### Phase 3：大纲搭建

#### 卷级大纲（全书结构）

```
## 卷级大纲

### 第一卷：{卷名}（约 {X} 万字，{Y} 章）
- 功能：{铺垫/起步/第一个大爽点}
- 核心事件：{一句话}
- 起始状态 → 结束状态：{主角从 {A} 变成 {B}}

### 第二卷：{卷名}
...

### 最终卷：{卷名}
- 功能：{高潮 + 收尾}
- 核心事件：{一句话}
```

<!-- cross-book-recall:trigger:tempo-volume -->
> **多对标书时**：参 `references/cross-book-recall.md`，副对标 `章节/*_摘要.md` + `剧情/*.md` 召回卷级节奏

#### 细纲（全书每章）

⚠️ **大纲四检（每卷/每章设计前必答）**：① 本卷交付什么情绪？什么剧情模式能可靠交付？② 本卷核心冲突是什么？③ 卷节奏（起承转合）哪段加速哪段减速？④ 本卷需要新埋设的伏笔有哪些？上一卷待回收的伏笔如何处理？

**每章必须有一个细纲文件**（`大纲/细纲_第XXX章.md`），不允许跳章。

默认分批建纲：先建前 10 章细纲进入 Phase 4 写作；每写完 5 章再滚动补齐后 5-10 章。不要在单次对话里强行产出 30 章完整细纲。
如果全书章数较少（≤30 章），可以在 Phase 3 一次全部建完。

```
## 细纲（第 N 章）

### 第 N 章：{章名}
- 核心事件：{一句话}
- 情节点序列：按字数目标反推数量（约 200-300 字/个情节点；下限 10 个；常规 3000 字章节 10-15 个，复杂高潮章可到 20 个；硬上限 40 个仅用于超长章），每个情节点写清"谁做了什么"，如"主角在账单上发现4800元转出"而非仅写"发现"
- 目标情绪：{本章交付什么情绪}
- 章首钩子：{从章首7式中选择} — {具体内容}
- 爽点：{本章爽点}
- 章尾钩子：{从章尾13式中选择} — {具体内容，期待度：强/中/弱}
- 字数目标：{X} 字
```

**大纲锁定**：已进入正文写作的前 10 章细纲锁定，未经用户确认不得修改；后续滚动细纲可随正文反馈微调。

**细纲质量要求**：每章细纲一视同仁，全部用最高标准打磨——钩子+人设+爽点+悬念+伏笔。

<!-- cross-book-recall:trigger:tempo-chapter -->
> **多对标书时**：参 `references/cross-book-recall.md`，副对标同基调 `章节/*_摘要.md` 作细纲钩子

**章节标题规则**：只做轻量去重；发现同名或明显重复标题时，按本章核心事件改名，并保持细纲标题与正文文件名一致。

**细纲后设定补全（每批细纲建完后执行）**：扫描本批细纲新出现的具名角色/势力/关键设定，对**会复用**的（按卷纲/细纲判断：后续多次出场或承担剧情功能）自动建档，不等用户确认：
- 角色 → 建 `设定/角色/{名}.md`（填空模板见 character-basics.md 主角卡/配角卡），并在 `追踪/角色状态.md` 登记初始状态（该文件若未建则一并创建）；
- 势力/组织 → 建 `设定/势力/{名}.md`（名称、定位、核心目标、关键人物、与主角关系）；
- 影响多章的世界观规则 → 建/补 `设定/世界观/{主题}.md`（规则、适用范围）。

已存在的设定文件按细纲新信息**增量补充、不覆盖**，同一角色不重复登记 `追踪/角色状态.md`。一次性路人、后文无戏份的配角不建档。建档只填细纲已确定的信息，未定字段留占位符，不提前杜撰。

大纲完成后，创建以下 artifact（加载 [references/artifact-protocols.md](references/artifact-protocols.md) 中对应模板）：
- **大纲/大纲.md**：全书卷级鸟瞰（卷名+字数+章数+核心事件+状态变化，一段式汇总）
- **大纲/卷纲_第X卷.md**：每卷的爽点节奏+情绪弧线+人物弧线+伏笔+反转（参考 outline-methods.md「大纲三层结构法」 + emotional-arc-design.md「六种弧线速查」 + reversal-toolkit.md「反转类型」）
- **追踪/伏笔.md** + **追踪/时间线.md** + **追踪/角色状态.md**：伏笔状态表+故事时间线+角色状态快照（参考 plot-core-methods.md「连续性追踪」、state-tracking.md「角色状态快照格式」）

前 3 章细纲额外加载 [references/opening-design.md](references/opening-design.md)（黄金三章法则+六大标准）。

#### Agent 调用：story-architect

大纲搭建阶段优先由主会话产出卷纲+首批细纲；只有结构复杂、反转链多或主会话方案不稳定时，才调用 story-architect agent。若项目已部署 story-architect agent（检查 `.claude/agents/story-architect.md` 是否存在），可 spawn `Agent(subagent_type: "story-architect", prompt: "项目目录：{dir}\n任务类型：大纲搭建\n查询参数：卷级结构+细纲+钩子/反转/情绪弧线设计")` 辅助大纲排布、钩子/反转/情绪弧线设计。如 agent 不可用，由主线程直接执行。

---

### Phase 4：正文写作辅助

#### 项目文件结构

长篇写作必须用文件系统管理，不要把内容堆在对话里。在用户指定的工作目录下创建：

```
{书名}/
├── 设定/
│   ├── 世界观/
│   │   ├── 背景设定.md        # 时代背景、地理、历史
│   │   ├── 力量体系.md        # 修炼/能力/等级体系
│   │   └── ...
│   ├── 角色/
│   │   ├── 沈栀.md            # 每个人物一个文件，文件名用角色名
│   │   └── ...
│   ├── 势力/
│   │   ├── 天机阁.md          # 每个势力/组织一个文件
│   │   └── ...
│   ├── 关系.md                # 角色关系映射
│   └── 题材定位.md            # 题材核心梗+对标分析
├── 大纲/
│   ├── 大纲.md                # 全书卷级结构
│   ├── 卷纲_第一卷.md         # 每卷一个：爽点节奏+情绪弧线+人物弧线+伏笔+反转
│   └── 细纲_第001章.md        # 每章一个：事件+钩子(章首/章尾/段落级)+爽点+悬念
├── 正文/
│   ├── 第001章_章名.md
│   └── ...
├── 对标/                          ← 拆文产出的结构化资产
│   └── {对标书名}/
│       ├── 原文/
│       │   ├── 第001章_章名.md
│       │   └── ...
│       ├── 角色/                  ← 从拆文库/结构化输出同步
│       │   └── {角色名}.md
│       ├── 剧情/                  ← 从拆文库/结构化输出同步
│       │   ├── {剧情线名}.md
│       │   └── 故事线.md
│       ├── 设定/                  ← 从拆文库/结构化输出同步
│       │   ├── 世界观/             ← 按主题拆分到子目录（早期单文件版本由 story-import 兜底转换）
│       │   │   ├── 背景设定.md
│       │   │   ├── 力量体系.md
│       │   │   ├── 地理.md
│       │   │   └── 金手指.md       ← 金手指现在放在 世界观/ 下，不再扁平
│       │   └── 势力/
│       │       └── {势力名}.md
│       └── 拆文报告.md
├── 追踪/                          ← 角色状态、伏笔、时间线
│   ├── 伏笔.md                    ← 跨卷追踪
│   ├── 时间线.md                  ← 全书时间线
│   ├── 角色状态.md                ← 角色当前状态快照
│   └── 上下文.md                  ← 正文级（日更进度摘要）
├── 参考资料/
│   └── {topic}.md             # story-researcher 输出的研究资料
```

**产物映射表**（创建模板详见 [references/artifact-protocols.md](references/artifact-protocols.md)）：

| 文件 | 粒度 | 创建阶段 | 读取时机 |
|------|------|---------|---------|
| 设定/关系.md | 全书 | Phase 2 | Phase 3 大纲、Phase 4 写作 |
| 设定/题材定位.md（含 `主对标书` 字段，多对标时必填） | 全书 | Phase 2 | Phase 3 大纲、每卷开始前、Phase 4 文风召回 |
| 设定/角色/{角色名}.md、设定/势力/{名}.md | 角色/势力 | Phase 3 细纲后增量补全（首批含主角/主要角色） | Phase 4 状态筛选/写作 |
| 对标/{书名}/文风.md | 对标书 | analyze Stage 6 输出 → story-import 同步 | Phase 4 每章写作前（文风召回） |
| 大纲/卷纲_第X卷.md | 卷 | Phase 3 | Phase 4 写卷首章前 |
| 追踪/伏笔.md | 全书 | Phase 3 起 | Phase 4 每章写作前 |
| 追踪/时间线.md | 全书 | Phase 3 起 | Phase 4 每章写作前 |
| 对标/{书名}/拆文报告.md | 对标书 | 用户手动+analyze | Phase 2 核心设定、Phase 3 大纲、Phase 4 写作 |
| 追踪/上下文.md | 全书 | Phase 4 首次日更（workflow-daily 自动创建） | 每次日更开始时 |
| 参考资料/{topic}.md | 按需 | Phase 4（story-researcher 输出） | Phase 4 后续章节写作时复用 |
| 追踪/角色状态.md | 全书 | Phase 3 | Phase 4 每章写作前（状态筛选步骤） |
| 对标/{书名}/角色/{角色名}.md | 对标书 | analyze 输出 | Phase 4 模块召回（角色参考） |
| 对标/{书名}/剧情/{剧情线名}.md | 对标书 | analyze 输出 | Phase 4 模块召回（剧情模块参考） |
| 对标/{书名}/设定/*.md | 对标书 | analyze 输出 | Phase 2 设定参考、Phase 4 世界观约束 |

**缺失文件回退**：所有新增文件是可选增强，缺失时按以下优先级降级，不报错不阻塞：
1. **角色状态文件缺失** → 从角色设定文件和前文推断当前状态
2. **对标结构化子目录缺失** → 按「对标书路径查找」规则回退（对标子目录 → 拆文库同名子目录 → 对标拆文报告.md → 跳过）
3. **有对标书但 `文风.md` 缺失** → 日更文风召回 fail-fast，提示先运行 `/story-long-analyze` Stage 6 并 `/story-import` 同步；**完全无对标项目**则跳过文风召回，不阻塞
4. **伏笔/时间线文件缺失** → 不检查，相关信息在卷纲或大纲中体现即可

**文件组织原则：**
- **人物一个一个文件**：`角色/角色名.md`，方便按需读取
- **势力一个一个文件**：`势力/势力名.md`，组织/门派/家族/国家等
- **世界观按主题拆分**：背景、力量体系、社会结构等各自独立
- **细纲一章一个文件**：`细纲_第XXX章.md`，含钩子设计，与正文一一对应
- **正文按章拆分**：每章一个文件，`第XXX章_章名.md`
- 每章写完直接写入 `正文/` 目录，不要先输出到对话

#### 单章写作流程

当用户准备写某一章时：

1. **检查细纲**：读取 `大纲/细纲_第{N}章.md`。如果不存在，**必须先补建细纲再写正文**，不允许跳过细纲直接写作。补建时参考卷纲中本章对应的事件规划和上下文。
2. **读取上下文**（按需加载，缺失则跳过。可选快捷路径：如果项目已部署 story-explorer agent（检查 `.claude/agents/story-explorer.md` 是否存在），可 spawn `Agent(subagent_type: "story-explorer", prompt: "项目目录：{dir}\n查询类型：context_load\n查询参数：准备写第 {N} 章")` 一次获取上下文）：
   - (1) `正文/第{N-1}章_*.md` — 上一章正文
   - (2) `大纲/细纲_第{N}章.md` — 本章细纲（含钩子设计）
   - (3) `追踪/伏笔.md`（如存在）— 待回收伏笔
   - (4) `设定/角色/{相关角色}.md` — 本章涉及角色
   - (5) 对标书路径下 `拆文报告.md`（按对标书路径查找）— 对标参考
   - (6) `对标/{对标书名}/原文/第{N}章_*.md`（如存在）— 同位置章节参考
   - (7) `参考资料/{topic}.md`（如存在）— 历史研究资料（由 story-researcher 产出）
   - (8) `追踪/角色状态.md`（如存在）— 角色当前状态快照
   - (9) 对标书路径下 `剧情/故事线.md`（按对标书路径查找）— 剧情线索引，用于确定本章涉及哪些剧情线
   - (10) 对标书路径下 `剧情/{相关剧情线}.md`（按对标书路径查找）— 从索引中选择与本章相关的剧情线文件
   - (11) 对标书路径下 `设定/世界观/*.md`（glob，按对标书路径查找）— 从拆文产出的设定中获取参考。**回退顺序**：① glob `设定/世界观/*.md`；② 若 `设定/世界观/` 子目录不存在则读单文件 `设定/世界观.md`（早期拆文库格式）；③ 若也无则读 `设定/金手指.md` 当作最低限度参考；④ 都没有则跳过本步骤（缺失不阻塞）
3. **准备层**（下面的 3 步是核心方法在单章写作中的落地：筛选状态 → 召回模块 → 确认意图）：
   - 3.1 **状态筛选**：从 `追踪/角色状态.md` 中筛选本章涉及角色的当前状态，从 `追踪/伏笔.md` 中筛选本章需要回收/推进的伏笔。输出最简记忆包（参考 state-tracking.md）。如果角色状态文件不存在，从角色设定和前文推断
   - 3.2 **模块召回与文风召回**：
     - ① 本章目标情绪词？② 借鉴哪个参考文件的哪个技法？③ 用在哪些段落？答不出 → 先回读参考再动笔
     - (a) **文风召回**：按「对标书路径查找」规则读 `{对标书路径}/文风.md`（路径优先 `{项目}/对标/{书名}/`，回退 `拆文库/{书名}/`）；多本对标书时从 `设定/题材定位.md` 读 `主对标书` 字段。文风文件不存在 → **fail-fast 报错**：「对标书 X 缺少 文风.md。请用 `/story-long-analyze` 跑 Stage 6 生成文风，再 `/story-import` 同步。」不 inline 生成
     - (b) **匹配章节挑选**：从 `{对标书路径}/章节/*_摘要.md` grep `基调：(紧张|轻松|悲伤|热血|温馨|压抑)`（全角冒号），按本章目标情绪挑章 K——多章同基调时选择规则：先看爽点类型是否接近，再看情节点数量/原文章节估算字数是否接近本章目标字数，最后取章节号最小者；必读 `{对标书路径}/章节/第K章_摘要.md`，若同章存在 `第K章_深度拆解.md` 则加读，否则回退黄金三章深度拆解/文风文件里的可借鉴技巧，不因非黄金三章缺少深度拆解而失败
     - (c) **模块召回**：从对标的结构化子目录（角色/剧情/设定）中按本章情节检索相关模块
     - (d) <!-- cross-book-recall:trigger:execution-output --> 输出"对标召回摘要 + 文风召回指令 + 原文锚点片段引用"（合计 ≤10 条），作为 narrative-writer 的输入。**多对标书时**参 `references/cross-book-recall.md`，进 prompt 的只主对标（副对标不入正文）
     - **快捷路径**：项目已部署 story-explorer agent 时（检查 `.claude/agents/story-explorer.md`），直接 spawn `Agent(subagent_type: "story-explorer", prompt: "项目目录：{dir}\n查询类型：benchmark_style_load\n查询参数：我要写第 {N} 章；这一章按细纲偏{紧张/热血/轻松等}，目标字数约 {N}，爽点类型={如有}")` 一次拿到 `{style_profile_path, style_profile_summary, matched_chapter_K, matched_chapter_techniques, anchor_excerpts, gaps}`；准备层必须原样保留 `gaps`，若 `gaps.matched_deep_dive_missing: true`，文风召回指令必须说明已用黄金三章/文风文件里的技巧回退
   - 3.3 **指令确认**：综合细纲+最简记忆包+模块召回结果，确认本章节奏（快/慢）和情绪目标，用一句话概括本章写作意图。例：「快节奏打脸——读者等了三章，这章必须一拳到位。技法=信息差揭示（hooks-suspense.md），用于第2-4段。」
4. **资料研究**（按需）：如果写作中遇到需要查证的外部事实（历史年代、地理方位、职业细节等），spawn `story-researcher` agent 搜索并输出到 `参考资料/` 目录。研究完成后再继续写作。
5. **标题预检**：写正文前从细纲读取章名；如与既有章节同名或明显重复，先按本章核心事件改名，并同步细纲标题与正文文件名。
6. **写作**：第 1 章如果以内心戏、设定认知或独处开场，必须先把内心变化外化为可见事件（决定、误判、对话、物件变化、外部压力），再按字数目标展开；不得用大段心理独白凑字。若第 1 章低于目标，优先补“外部事件/对话/选择代价”，不要补解释性内心戏。
7. **正文执行**：如果项目已部署 narrative-writer agent（**必须先检查 `.claude/agents/narrative-writer.md` 是否存在**），spawn `Agent(subagent_type: "narrative-writer", prompt: "项目目录：{dir}\n任务描述：写正文\n章节：第{N}章\n细纲文件：大纲/细纲_第{N}章.md\n上一章：正文/第{N-1}章_*.md\n准备层输出：{3.1最简记忆包 + 3.2模块/文风召回结果 + 3.3写作意图}\n情绪目标：{从准备层3.3确认}\n涉及角色：{从准备层3.1筛选}\n参考技法：{从准备层3.2召回}\n对标/拆文路径：{本次查找到的 对标/{书名}/ 或 拆文库/{书名}/，没有则写 无}\n对标召回摘要：{准备层3.2(c)输出的相关角色/剧情/设定/章节模块，最多5条；没有则写 无}\n文风路径：{准备层3.2(a) 找到的 文风.md 绝对路径，没有则写 无}\n文风召回指令：{准备层3.2(b) 输出，含匹配章节号和 1-2 句技法指令——例如 '标点节奏照文风文件里的破折号节拍、对话潜台词用问非所答；情绪交替参考第K章爽点铺放比'。没有则写 无}\n原文锚点片段：{文风文件里 4-6 段中按本章情绪选 1-2 段，完整粘贴 300-500字 原文 — 用于 few-shot 模仿手法、非抄字句；没有则写 无}\n写作硬约束：按三维度织入写场景，但仍必须按镜头断段；一段只承载一个动作/信息变化，优先一段一句，避免一段到底。输出前做密度重排：段落 >60 字按句号/动作转折拆开，单句 >45 字拆短。**文风优先级**：与默认 Gates 冲突时按 narrative-writer.md 的优先级表决议（硬约束 banned-words/Gate F/万能比喻禁令/字数下限 不让位；句长/标点/对话潜台词/情绪交替由文风优先）。\n⚠️字数硬约束：本章必须达到细纲中设定的字数目标（{从细纲读取}字）。写完后立即用跨平台 Python 字符统计核对（命令见 narrative-writer 定义；勿直接用 python3——Windows 上会触发 Microsoft Store 占位程序、exit 49 失败，按 python3→python→py 探测可用解释器）；macOS/Linux 可用 wc -m 备选；禁止 wc -c 或模型估算。字数未达标禁止结束本章。")` 执行正文写作，输出写入 `正文/第XXX章_章名.md`。如 narrative-writer agent 未部署，由主线程直接写作。
8. **字数验证**（写作完成后的第一件事）：优先用跨平台 Python 字符统计本章实际字数 `for PYBIN in python3 python py; do "$PYBIN" -c "" 2>/dev/null && break; done; "$PYBIN" -c "from pathlib import Path; print(len(Path('正文文件路径').read_text(encoding='utf-8')))"`（**勿直接用 `python3`**：Windows 上它会触发 Microsoft Store 占位程序、exit 49 失败，探测会按 `python3→python→py` 选可用解释器）；macOS/Linux 可用 `wc -m` 备选。如果字数 < 细纲目标的 90%，**回到细纲补充更多子事件/情节点**，然后用三维度织入将这些新子事件写成正文，并按镜头断段控制单段密度，直到字数达标后再进入步骤 9。
9. **检查**：章尾是否有钩子、爽点是否到位
10. **禁用词扫描**：对照 `references/banned-words.md` 检查本章，一级词（高频AI腔）命中即替换；二级词（低频/语境相关）高频出现时替换，偶发可参考 `references/anti-ai-writing.md` 定性裁定
11. **更新追踪**：写完后即时更新 `追踪/伏笔.md`（新增/回收伏笔）、`追踪/时间线.md`（记录事件时序）和 `追踪/角色状态.md`（如本章引起角色状态变化——身份、能力、关系、公众形象——则更新对应角色条目并追加变更记录）。本章若首次引入会复用的具名角色/势力，按 Phase 3「细纲后设定补全」规则补建对应 `设定/` 档案。角色状态更新规则详见 state-tracking.md。
12. **中途快照**（长篇写作安全网）：每连续写完 3 章，在继续前执行以下快照操作：
   - 将当前进度写入 `追踪/上下文.md`（只更新进度元信息——当前位置、最近决策、待处理线索——不重复角色状态/伏笔的具体内容）
   - 用 `ls -la 正文/` 确认最近 3 个章节文件已成功写入磁盘且大小正常（>100 bytes）
   - 如果发现文件缺失或大小异常，立即重新写入
   - 快照完成后可继续写作

> **日更模式**：此步骤自动跳过——workflow-daily Step 2 已按章更新上下文.md。

#### 写作技巧提醒

| 场景 | 技巧 |
|------|------|
| 开篇 500 字 | 必须有钩子，不能从天气/风景开始（除非反差极大） |
| 对话 | 推进剧情或揭示性格，不能只为了凑字数 |
| 打斗 | 不要流水账，写策略和反转，不写「你一拳我一脚」 |
| 日常 | 日常要有人物互动和伏笔，不能只是「吃饭睡觉」 |
| 爽点释放 | 铺垫要充分、释放要干脆，读者等得越久释放越要爽 |
| 爽点密度 | 每 3000-5000 字必须有一个让读者「爽」的情绪节点 |
| 公式约束 | 参考 genre-writing-formulas.md 中的创作公式 |
| 章尾 | 每章结尾都要有让读者想翻下一页的东西 |
| 情绪验证 | 写完每章回头检查：读者到这里应该感受到什么？感受到了吗？如果没感受到 → 补冲突或钩子 |

#### 字数硬约束

| 节奏 | 最低字数 | 说明 |
|------|----------|------|
| 高速推进 | ≥ 2000 字/章 | 每章一个明确事件 |
| 正常节奏 | ≥ 3000 字/章 | 主线 + 少量副线 |
| 舒缓铺垫 | ≥ 3000 字/章 | 人物互动 + 伏笔 |
| 高潮爆发 | ≥ 2000 字/章 | 集中释放、不拖沓 |

**默认最低字数：3000 字/章。细纲另有标注时以细纲为准。低于最低字数的章节必须补足后再继续。**


#### 追踪文件归档

每完成 50 章或一个卷结束时，对 `追踪/上下文.md` 做一次轻量归档：保留最近 5 章详记，将更早内容压缩到 `追踪/归档/第XXX-YYY章.md`，并在上下文中保留归档索引。伏笔、时间线、角色状态仍以当前文件为准，不把活跃线索移入归档。

---

### Phase 5：质量检查

检查两个维度：(1) **情绪交付**——每章是否交付了细纲中规划的目标情绪？(2) **技术质量**——一致性、格式、禁用词。参考 [references/quality-checklist.md](references/quality-checklist.md) 中的通用检查和长篇专项清单。

#### Agent 调用：consistency-checker

质量检查阶段，如果项目已部署 consistency-checker agent（检查 `.claude/agents/consistency-checker.md` 是否存在），spawn `Agent(subagent_type: "consistency-checker", prompt: "项目目录：{dir}\n检查范围：{本次写作的章节}\n检查类型：事实冲突+伏笔断线+角色属性不一致")` 执行一致性检查，获取 S1-S4 分级报告。如 agent 不可用，由主线程参照 quality-checklist.md 直接检查。

#### Agent 调用：narrative-writer（去AI味审查）

质量检查阶段，如果项目已部署 narrative-writer agent，可 spawn `Agent(subagent_type: "narrative-writer", prompt: "项目目录：{dir}\n任务描述：审查+去AI味\n检查范围：{本次写作的章节}")` 执行文字质量审查和去AI味检查。如 agent 不可用，由主线程直接执行。

检查后更新追踪文件：
- 更新 `追踪/伏笔.md` 中的过期伏笔和回收状态
- 更新 `追踪/时间线.md` 中的时间线疑点

---

## 流程衔接

**流水线：** 长篇
**位置：** 写作（第 3/3 步）

| 时机 | 跳转到 | 命令 |
|---|---|---|
| 写完，去 AI 味 | story-deslop | `/story-deslop` |
| 想对比参考书 | story-long-analyze | `/story-long-analyze` |
| 需要市场方向 | story-long-scan | `/story-long-scan` |
| 太长，适合短篇 | story-short-write | `/story-short-write` |

---

## 参考资料索引

按场景加载，不一次全部加载。

### Phase 1：选题方向

| 场景 | 加载文件 |
|------|---------|
| 确定题材类型 | `references/genre-catalog.md` |
| 判断市场方向 | `references/genre-readers.md` |
| 特殊题材考量 | `references/plot-special-topics.md` |
| 女频长篇（题材/文案/平台/感情线） | `references/female-audience-writing.md` |

### Phase 2：核心设定

| 场景 | 加载文件 |
|------|---------|
| 设定人物 | `references/character-basics.md` |
| 设计关系 | `references/character-relations.md` |
| 题材框架与定位 | `references/genre-catalog.md` + `references/genre-core-mechanics.md` |
| 创建 artifact | `references/artifact-protocols.md` |

### Phase 3：大纲搭建

| 场景 | 加载文件 |
|------|---------|
| 搭建大纲 | `references/outline-methods.md` |
| 设计矛盾与结构 | `references/outline-conflict.md` |
| 深度结构设计 | `references/outline-structure-theory.md` |
| 节奏与升级感 | `references/outline-rhythm.md` |
| 小纲与卡文 | `references/plot-core-methods.md` |
| 选择叙事框架 | `references/plot-frameworks.md` |
| 题材写作公式 | `references/genre-writing-formulas.md` |
| 黄金三章 | `references/opening-design.md` |
| 情绪弧线 | `references/emotional-arc-design.md` |
| 反转设计 | `references/reversal-toolkit.md` |

### Phase 4：正文写作

| 场景 | 加载文件 |
|------|---------|
| 章节钩子 | `references/hooks-chapter.md` |
| 悬念设计 | `references/hooks-suspense.md` |
| 段落级钩子 | `references/hooks-paragraph.md` |
| 题材风格 | `references/style-genre-modules.md` |
| 打斗/装逼 | `references/style-combat-face.md` |
| 写作技法 | `references/style-craft.md` |
| 商业创作核心方法 | `references/commercial-core-methods.md` |
| 对话 | `references/dialogue-mastery.md` |
| 人物深化 | `references/character-design-methods.md` |
| 情绪技法 + 叙事单元 | `references/plot-emotion-system.md` + `references/emotional-methods.md` |
| 写作技法全程参考 | `references/writing-craft.md` |
| 格式与结构规范 | `references/format-and-structure.md`（仅对话/段落格式适用长篇） |
| 状态追踪协议 | `references/state-tracking.md` |

### Phase 5：质量检查

| 场景 | 加载文件 |
|------|---------|
| 质量检查 | `references/quality-checklist.md` |
| 禁用词扫描 | `references/banned-words.md` |
| 去AI味 | `references/anti-ai-writing.md` |

### 按主题快速定位（横切主题）

有些主题横跨多个阶段、散在多个文件里。下表给每个主题一个**权威文件**（先读它，通常够用），配套文件只在需要那个角度时再加载。括号是该文件里对应的小节。

| 主题 | 权威文件（先读） | 配套文件（按角度补充） |
|------|-----------------|----------------------|
| 爽点（按意图分流） | **`references/plot-emotion-system.md`**（爽点设计体系：本质/六种类型/倒推法——"怎么设计爽点"先读这个） | 翻盘/高潮式爽点→`references/plot-core-methods.md`（假胜→崩解）· 打脸/装逼释放→`references/style-combat-face.md`· 题材打脸逆袭公式→`references/genre-writing-formulas.md`· 爽文循环/多层→`references/outline-methods.md`·`references/outline-conflict.md` |
| 情绪模块 | **`references/plot-emotion-system.md`**（情绪模块与戏剧单元分类） | `references/outline-rhythm.md`（情绪模块系统 + 常用情绪模块公式） |
| 节奏 | **`references/outline-rhythm.md`**（升级感三步 + 桥段与节奏的结构化设计） | `references/plot-core-methods.md`（连续性追踪与节奏管理：热度/冷却） |
| 高潮 | **`references/plot-core-methods.md`**（高潮构建公式：蓄能→假胜→崩解） | `references/outline-rhythm.md`（高潮分类与反推）· `references/outline-methods.md`（八节点故事结构：结构定位） |
| 金手指 | **`references/plot-special-topics.md`**（金手指拆分理解与战力防崩 + 进阶设计） | `references/outline-conflict.md`（金手指与身份：四点统一） |
| 感情线 | **`references/character-relations.md`**（好感度体系/四阶段 + 男女频差异） | `references/outline-conflict.md`（感情线设计）· `references/style-combat-face.md`（后宫文女主 / 男频极简爱情线构型）· `references/plot-special-topics.md`（爱情线提纯策略） |
| 反转 | **`references/reversal-toolkit.md`**（反转类型/铺垫/有效性自检） | `references/plot-core-methods.md`（假胜：先给希望再击碎） |
| 人物 | **`references/character-basics.md`**（主角/配角/反派/动机模板速填） | `references/character-design-methods.md`（三层标签反差/九维深化）· `references/character-relations.md`（关系类型/感情线） |
| 女频写作 | **`references/female-audience-writing.md`**（女频长篇：核心原则/文案/题材/感情线长线/平台） | `references/genre-readers.md`（读者心理/平台差异）· `references/character-relations.md`（感情线总框架） |
| 去AI味 | **`references/anti-ai-writing.md`**（AI指纹/核心规则/Show Don't Tell） | `references/banned-words.md`（禁用词扫描）· `references/quality-checklist.md`（成稿检查） |

---

## 语言

- 跟随用户的语言回复，用户用什么语言就用什么语言回复
- 中文回复遵循《中文文案排版指北》
