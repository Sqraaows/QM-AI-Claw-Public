## Description: <br>
Assists long-form web novel writers with story setup, outlining, chapter drafting, revision, state tracking, and quality checks. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Writers and writing assistants use this skill to plan, draft, continue, and revise serialized Chinese web fiction projects. It helps manage genre positioning, character and relationship design, chapter outlines, manuscript files, continuity tracking, and revision workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may create or update manuscript project files automatically. <br>
Mitigation: Install it only in a dedicated novel-writing workspace, confirm the working directory before use, and keep versioned backups of drafts. <br>
Risk: Generated prose or planning may be influenced too closely by copyrighted source works or large verbatim excerpts supplied by the user. <br>
Mitigation: Avoid using copyrighted works as close templates and avoid feeding large verbatim excerpts into generated prose workflows. <br>
Risk: Writing workflow outputs may introduce unwanted plot, continuity, or style changes across a long manuscript. <br>
Mitigation: Review generated or modified outline, tracking, and chapter files before relying on them. <br>


## Reference(s): <br>
- [ClawHub listing](https://clawhub.ai/worldwonderer/story-long-write) <br>
- [OpenClaw source metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>
- [SKILL.md](artifact/SKILL.md) <br>
- [Artifact Protocols](artifact/references/artifact-protocols.md) <br>
- [Daily Writing Workflow](artifact/references/workflow-daily.md) <br>
- [Revision Workflow](artifact/references/workflow-revision.md) <br>
- [Quality Checklist](artifact/references/quality-checklist.md) <br>
- [Genre Catalog](artifact/references/genre-catalog.md) <br>
- [Outline Methods](artifact/references/outline-methods.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, configuration, guidance] <br>
**Output Format:** [Markdown and plain-language Chinese prose with structured writing project artifacts] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May create or update outline, setting, manuscript, tracking, and revision files in the user's writing workspace.] <br>

## Skill Version(s): <br>
1.1.4 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
