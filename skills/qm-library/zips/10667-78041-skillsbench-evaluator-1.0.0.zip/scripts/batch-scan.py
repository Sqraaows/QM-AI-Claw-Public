#!/usr/bin/env python3
"""SkillsBench 批量 Skill 扫描工具

扫描指定目录下所有 SKILL.md 文件，提取基本信息并输出 CSV。
用于批量评测前的快速摸底，或在 CI 中做自动化质量门禁。

用法:
    python batch-scan.py <skills_dir>              # 扫描目录输出 CSV
    python batch-scan.py <skills_dir> --json        # 输出 JSON
    python batch-scan.py <skills_dir> --gate 7      # 质量门禁，<7分别 exit 1
"""

import os
import sys
import json
import csv
import io
import re


def parse_frontmatter(text: str) -> dict:
    """提取 YAML frontmatter 中的关键字段"""
    if not text.startswith("---"):
        return {"has_frontmatter": False}
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {"has_frontmatter": False}
    fm = parts[1]
    result = {"has_frontmatter": True}
    for key in ["name", "description", "description_zh", "version", "allowed-tools", "triggers"]:
        val = _extract_yaml_field(fm, key)
        if val is not None:
            result[key] = val
    return result


def _extract_yaml_field(fm: str, key: str):
    """简单提取 YAML 字段值（不做完整解析，够用）"""
    # 匹配 key: value 或 key:\n  value 等格式
    m = re.search(rf"^{key}\s*:\s*(.+)$", fm, re.MULTILINE)
    if m:
        return m.group(1).strip().strip('"').strip("'")
    return None


def count_sections(text: str) -> dict:
    """统计 Markdown 章节结构"""
    h1 = len(re.findall(r"^#\s", text, re.MULTILINE))
    h2 = len(re.findall(r"^##\s", text, re.MULTILINE))
    h3 = len(re.findall(r"^###\s", text, re.MULTILINE))
    return {"h1": h1, "h2": h2, "h3": h3}


def has_section(text: str, keywords: list[str]) -> bool:
    """检查是否包含特定关键章节"""
    for kw in keywords:
        if re.search(rf"^#{{2,3}}\s.*{kw}", text, re.MULTILINE | re.IGNORECASE):
            return True
    return False


def scan_skill(skill_path: str) -> dict:
    """扫描单个 Skill"""
    md_path = os.path.join(skill_path, "SKILL.md")
    if not os.path.exists(md_path):
        return None

    name = os.path.basename(skill_path)
    with open(md_path, "r", encoding="utf-8") as f:
        text = f.read()

    lines = text.count("\n") + 1
    fm = parse_frontmatter(text)
    sections = count_sections(text)

    # 检查关键章节
    has_gotchas = has_section(text, ["gotcha", "pitfall", "陷阱", "坑点", "troubleshoot"])
    has_constraints = has_section(text, ["constraint", "约束", "限制", "rule", "boundary"])
    has_verification = has_section(text, ["verif", "checklist", "验证", "检查", "自检"])
    has_examples = has_section(text, ["example", "示例", "usage", "用法"])

    return {
        "name": name,
        "path": skill_path,
        "lines": lines,
        "frontmatter": fm,
        "sections": sections,
        "checks": {
            "frontmatter_ok": fm.get("has_frontmatter", False),
            "has_name": fm.get("name") is not None,
            "has_description": fm.get("description") is not None,
            "has_description_zh": fm.get("description_zh") is not None,
            "has_allowed_tools": fm.get("allowed-tools") is not None,
            "has_triggers": fm.get("triggers") is not None,
            "has_gotchas": has_gotchas,
            "has_constraints": has_constraints,
            "has_verification": has_verification,
            "has_examples": has_examples,
        }
    }


def scan_all(skills_dir: str) -> list[dict]:
    """扫描目录下所有 Skill"""
    results = []
    for entry in sorted(os.listdir(skills_dir)):
        full = os.path.join(skills_dir, entry)
        if not os.path.isdir(full):
            continue
        info = scan_skill(full)
        if info:
            results.append(info)
    return results


def quick_score(info: dict) -> int:
    """基于基本检查项快速估算分数 (0-12)"""
    c = info["checks"]
    score = 0
    if c["frontmatter_ok"]: score += 1
    if c["has_name"]: score += 1
    if c["has_description"]: score += 1
    if c["has_description_zh"]: score += 1
    if c["has_allowed_tools"]: score += 1
    if c["has_triggers"]: score += 1
    # 内容结构
    if info["sections"]["h2"] >= 3: score += 1
    if c["has_gotchas"]: score += 1
    if c["has_constraints"]: score += 1
    if c["has_verification"]: score += 1
    if c["has_examples"]: score += 1
    if info["lines"] < 500: score += 1
    return min(score, 12)


def main():
    if len(sys.argv) < 2:
        print("Usage: python batch-scan.py <skills_dir> [--json] [--gate N]")
        sys.exit(1)

    skills_dir = sys.argv[1]
    output_json = "--json" in sys.argv
    gate = None
    for i, arg in enumerate(sys.argv):
        if arg == "--gate" and i + 1 < len(sys.argv):
            gate = int(sys.argv[i + 1])

    results = scan_all(skills_dir)

    if output_json:
        for r in results:
            r["quick_score"] = quick_score(r)
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "name", "lines", "h2_count",
            "frontmatter", "allowed_tools", "triggers",
            "gotchas", "constraints", "verification", "examples",
            "quick_score"
        ])
        for r in results:
            c = r["checks"]
            writer.writerow([
                r["name"], r["lines"], r["sections"]["h2"],
                "yes" if c["frontmatter_ok"] else "no",
                "yes" if c["has_allowed_tools"] else "no",
                "yes" if c["has_triggers"] else "no",
                "yes" if c["has_gotchas"] else "no",
                "yes" if c["has_constraints"] else "no",
                "yes" if c["has_verification"] else "no",
                "yes" if c["has_examples"] else "no",
                quick_score(r)
            ])
        print(output.getvalue())

    # 质量门禁
    if gate is not None:
        scores = [quick_score(r) for r in results]
        avg = sum(scores) / len(scores) if scores else 0
        if avg < gate:
            print(f"\n❌ 质量门禁失败: 平均分 {avg:.1f} < {gate}", file=sys.stderr)
            sys.exit(1)
        else:
            print(f"\n✅ 质量门禁通过: 平均分 {avg:.1f} >= {gate}", file=sys.stderr)


if __name__ == "__main__":
    main()
