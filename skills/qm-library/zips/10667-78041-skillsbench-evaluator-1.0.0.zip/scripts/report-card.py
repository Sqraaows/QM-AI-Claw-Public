#!/usr/bin/env python3
"""SkillsBench 评测报告生成器

读取评测结果 JSON，生成格式化的 Markdown 评测报告。

用法:
    python report-card.py <result.json>                    # 输出到 stdout
    python report-card.py <result.json> -o report.md       # 输出到文件
    python report-card.py <result.json> --batch            # 批量排行榜模式

JSON 输入格式 (单 Skill):
{
    "skill_name": "my-skill",
    "version": "1.0.0",
    "lines": 186,
    "category": "tool",
    "scores": {
        "frontmatter": 1, "trigger_clarity": 1, "role_definition": 1,
        "instruction_structure": 1, "freedom_levels": 0, "output_format": 0,
        "example_coverage": 1, "gotchas": 0, "constraints": 1,
        "tool_control": 1, "verification": 0, "conciseness": 1
    },
    "evidence": {"frontmatter": "YAML frontmatter 格式正确, 包含 name/description/..."}
}

JSON 输入格式 (批量模式):
[{"skill_name": "...", "total_score": 8, "tier": "foundation"}, ...]
"""

import sys
import json


# 维度中文名
DIMENSION_NAMES = [
    "Frontmatter 元数据", "触发条件明确性", "角色/人设设定",
    "指令结构清晰度", "自由度分级", "输出格式规范",
    "示例覆盖度", "陷阱/已知坑点", "约束条件明确",
    "工具控制", "验证机制", "简洁性"
]

DIMENSION_KEYS = [
    "frontmatter", "trigger_clarity", "role_definition",
    "instruction_structure", "freedom_levels", "output_format",
    "example_coverage", "gotchas", "constraints",
    "tool_control", "verification", "conciseness"
]

TIER_MAP = {
    (11, 12): ("🟢 精品层", "Top 2.5%"),
    (9, 10): ("🟡 专业层", "Top 25%"),
    (0, 8): ("🔴 基石层", "~75%"),
}


def get_tier(score: int) -> tuple[str, str]:
    for (lo, hi), (tier, pct) in TIER_MAP.items():
        if lo <= score <= hi:
            return tier, pct
    return "🔴 基石层", "~75%"


def percentile(score: int) -> str:
    if score >= 11: return "97"
    if score >= 9: return "75"
    if score >= 7: return "50"
    if score >= 5: return "25"
    return "10"


def single_report(data: dict) -> str:
    scores = data["scores"]
    total = sum(scores.values())
    tier, pct = get_tier(total)

    lines = []
    lines.append("╔══════════════════════════════════════════╗")
    lines.append("║     SkillsBench Skill 质量评测报告       ║")
    lines.append("╠══════════════════════════════════════════╣")
    lines.append(f"║  Skill: {data.get('skill_name', 'unknown')}")
    lines.append(f"║  版本: {data.get('version', '-')}")
    lines.append(f"║  行数: {data.get('lines', '-')} 行")
    lines.append(f"║  定位: {data.get('category', '-')}")
    lines.append("╠══════════════════════════════════════════╣")
    lines.append(f"║  总分: {total}/12  |  等级: {tier}")
    lines.append(f"║  SkillsBench 百分位: 超越 ~{percentile(total)}% 的技能")
    lines.append("╠══════════════════════════════════════════╣")
    lines.append(f"{'║  #  维度 (12项)':<35s}  {'得分':>6s} ║")

    for i, (name, key) in enumerate(zip(DIMENSION_NAMES, DIMENSION_KEYS)):
        s = scores.get(key, 0)
        mark = "✅" if s == 1 else "❌"
        lines.append(f"║  {i+1:2d} {name:<30s}  {mark:>5s}   ║")

    lines.append("╠══════════════════════════════════════════╣")
    lines.append("║  🔧 改进建议 (按影响优先级排序)         ║")

    improvements = data.get("improvements", [])
    if not improvements:
        # 自动生成失分项建议
        for name, key in zip(DIMENSION_NAMES, DIMENSION_KEYS):
            if scores.get(key, 0) == 0:
                improvements.append(f"[{name}] 建议补充相应内容")

    for i, imp in enumerate(improvements[:5]):
        lines.append(f"║  {i+1}. {imp:<36s} ║")

    lines.append("╚══════════════════════════════════════════╝")
    return "\n".join(lines)


def batch_leaderboard(results: list[dict]) -> str:
    lines = []
    lines.append("🏆 Skill 质量排行榜 (SkillsBench 12分制)")
    lines.append("════════════════════════════════════════════")

    # 排序
    sorted_results = sorted(results, key=lambda r: r.get("total_score", 0), reverse=True)

    for rank, r in enumerate(sorted_results, 1):
        score = r.get("total_score", 0)
        tier, _ = get_tier(score)
        tier_short = {"🟢 精品层": "🟢", "🟡 专业层": "🟡", "🔴 基石层": "🔴"}.get(tier, "")
        lines.append(f"  {rank:2d}  {r['skill_name']:<30s} {score:2d}/12  {tier_short} {tier}")

    # 统计
    scores_list = [r.get("total_score", 0) for r in sorted_results]
    avg = sum(scores_list) / len(scores_list) if scores_list else 0
    premium = sum(1 for s in scores_list if s >= 11)
    pro = sum(1 for s in scores_list if 9 <= s <= 10)
    foundation = sum(1 for s in scores_list if s <= 8)

    lines.append("────────────────────────────────────────────")
    lines.append(f"📊 统计:")
    lines.append(f"  平均分: {avg:.1f}/12")
    lines.append(f"  🟢 精品层: {premium} 个")
    lines.append(f"  🟡 专业层: {pro} 个")
    lines.append(f"  🔴 基石层: {foundation} 个")
    lines.append(f"  SkillsBench 全球均值: 6.2/12")

    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print("Usage: python report-card.py <result.json> [-o output.md] [--batch]")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = None
    batch_mode = "--batch" in sys.argv

    for i, arg in enumerate(sys.argv):
        if arg == "-o" and i + 1 < len(sys.argv):
            output_file = sys.argv[i + 1]

    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    if batch_mode or isinstance(data, list):
        result = batch_leaderboard(data)
    else:
        result = single_report(data)

    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(result)
        print(f"Report saved to {output_file}")
    else:
        print(result)


if __name__ == "__main__":
    main()
