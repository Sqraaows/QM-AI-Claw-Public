# SkillsBench 12 维度评分标准 (详细版)

> 每维度 0 或 1 分，满分 12 分。评分需引用原文证据。

---

## 维度 1: Frontmatter 元数据 (1分)

**评判标准**：
- YAML frontmatter 格式正确 (`---` 包裹)
- 包含 `name` 字段，值为 kebab-case (如 `my-skill-name`)
- 包含 `description` 字段，说明技能用途 (非仅功能列表)
- 可选加分: 有 `description_zh`、`version`、`allowed-tools`

**✅ 得 1 分示例**：
```yaml
---
name: agent-browser-core
description: "OpenClaw skill for the agent-browser CLI enabling AI-friendly web automation. Use when automating web tasks via CLI."
description_zh: "基于 agent-browser CLI 的 AI 友好型网页自动化"
version: 1.0.1
allowed-tools: Bash
---
```

**❌ 得 0 分示例**：
```yaml
---
name: myskill
description: "does stuff"
---
```
→ 问题：name 不是 kebab-case，description 过于模糊

---

## 维度 2: 触发条件明确性 (1分)

**评判标准**：
- `description` 中明确说明**何时调用**该 Skill，而非仅说明"能做什么"
- 包含触发词/触发场景 (如 "用户提到 XX 时触发")
- 有 `triggers` 字段或 description 中包含触发短语示例

**✅ 得 1 分示例**：
```yaml
description: "Scan any agent skill for security risks before you install or use it. Triggers on: 这个 skill 安全吗, skill 安全扫描, audit skill, scan skill."
```
→ 明确告知 Agent "什么时候应该调用我"

**❌ 得 0 分示例**：
```yaml
description: "A tool for working with Excel files."
```
→ 只说能做什么，没说什么情况下该用它

---

## 维度 3: 角色/人设设定 (1分)

**评判标准**：
- 开篇段落明确定义 Agent 在执行该 Skill 时的行为模式
- 包含身份描述 ("你是 XX 角色" / "You are a XX")
- 或明确的行为约束 ("Handle the request directly. Do NOT spawn sub-agents.")
- 人设与 Skill 领域一致，不突兀

**✅ 得 1 分示例**：
```markdown
# Humanizer: Remove AI Writing Patterns

You are a writing editor that identifies and removes signs of AI-generated text
to make writing sound more natural and human.
```

**❌ 得 0 分示例**：
无开篇角色设定，直接进入操作步骤。

---

## 维度 4: 指令结构清晰度 (1分)

**评判标准**：
- 有编号步骤或清晰的层次结构 (h2/h3/h4)
- 呈现 **输入 → 动作 → 输出** 的闭环流程
- 每步有明确的输入和输出说明
- 条件分支有清晰的路由逻辑

**✅ 得 1 分示例**：
```markdown
## Workflow
1. **Parse input** — collect sources and artifact selection
2. **Create notebook** — `notebooklm create "<slug>"`
3. **Add sources** — for each source: `notebooklm source add "<url>"`
4. **Generate artifacts** — generate each selected artifact
```
→ 步骤有序号、每步可执行、输入输出明确

**❌ 得 0 分示例**：
大段连续文字描述，没有结构化步骤，Agent 难以解析执行。

---

## 维度 5: 自由度分级 (1分)

**评判标准**：
- 关键步骤标注执行自由度: EXACT (严格遵守) 或 FLEX (自主判断)
- 或通过其他方式明确哪些是硬性规则、哪些是建议
- 有明确的安全边界/禁止事项

**✅ 得 1 分示例**：
```markdown
**EXACT**: Never modify the source file during READ operations.
**FLEX**: Choose the most appropriate analysis method based on data shape.
**CRITICAL — EDIT INTEGRITY RULES:**
1. NEVER create a new Workbook() for edit tasks.
```
→ 清晰区分 "必须遵守" 和 "灵活处理"

**❌ 得 0 分示例**：
所有指令平铺直叙，Agent 无法判断哪些可灵活处理、哪些必须严格遵守。

---

## 维度 6: 输出格式规范 (1分)

**评判标准**：
- 给出填写完毕的输出示例 (非占位符)
- 示例中包含逼真的样本数据
- 输出格式明确 (JSON schema / Markdown 模板 / 表格结构)

**✅ 得 1 分示例**：
```markdown
## Expected Output
```json
{
  "status": "success",
  "files_processed": 15,
  "errors": ["file_3.csv: encoding error"],
  "output_path": "/data/processed/report_2026-05-25.xlsx"
}
```
```
→ 有具体数据，不是 `"status": "xxx"` 占位符

**❌ 得 0 分示例**：
只说 "输出一个文件" 或 "返回结果"，没有具体格式。

---

## 维度 7: 示例覆盖度 (1分)

**评判标准**：
- 有正常路径 (happy path) 的完整示例
- 有异常/边缘情况的处理示例
- 示例场景多样，覆盖不同使用场景

**✅ 得 1 分示例**：
```markdown
## Examples

### Basic usage
Input: "Convert report.pdf to markdown" → `markitdown report.pdf`

### Error handling
If file not found → "Error: file not found. Check path and try again."

### Edge case: password-protected PDF
→ Use `--password` flag or prompt user for password.
```
→ 正常、错误、边界情况都有

**❌ 得 0 分示例**：
只有一个简单示例，没有异常处理或边界情况。

---

## 维度 8: 陷阱/已知坑点 (1分)

**评判标准**：
- 有专门章节记录常见的失败模式
- 包含 API 注意事项 (限流、认证、版本兼容)
- 记录环境依赖的特殊要求
- 有具体的错误信息和对应解决方案

**✅ 得 1 分示例**：
```markdown
## Gotchas / Common Pitfalls

### Docker build OOM
Symptom: Build fails with exit code 137
Fix: Increase Docker memory to 16GB+

### API rate limiting
Symptom: HTTP 429 from PubChem API
Fix: Reduce concurrency to n_concurrent_trials: 2

### ARM64 numerical precision
Symptom: Float comparison failures on Apple Silicon
Fix: Use approximate equality with tolerance 1e-6
```
→ 具体症状 + 具体解决方案

**❌ 得 0 分示例**：
没有 Gotchas 章节，或只有一句 "注意可能出错"。

---

## 维度 9: 约束条件明确 (1分)

**评判标准**：
- 有专门的约束/限制章节
- 明确安全边界 (不做 XX、不访问 XX)
- 明确领域限制 (仅适用于 XX 场景)
- 明确语气/风格要求

**✅ 得 1 分示例**：
```markdown
## Constraints

- NEVER modify user-uploaded original resume files
- NEVER fabricate numbers or statistics
- Output MUST be ATS-friendly plain text (no columns, no tables, no icons)
- Language: output in same language as input
```

**❌ 得 0 分示例**：
没有约束章节，Agent 可能在执行时越界。

---

## 维度 10: 工具控制 (1分)

**评判标准**：
- frontmatter 中有 `allowed-tools` 声明
- 工具权限范围与 Skill 功能匹配 (不多不少)
- 有明确的工具使用边界说明
- 如果 Skill 不需要外部工具，有明确说明

**✅ 得 1 分示例**：
```yaml
allowed-tools: Read, Write, Bash, Glob
```
→ 明确工具白名单

**❌ 得 0 分示例**：
没有 `allowed-tools`，或声明了与功能无关的工具。

---

## 维度 11: 验证机制 (1分)

**评判标准**：
- 有自我检查项 (checklist / verification steps)
- 有成功标准 (怎样算执行成功)
- 有交叉验证机制 (如何确认结果正确)
- 或有测试 prompt 用于验证

**✅ 得 1 分示例**：
```markdown
## Verification

After generating the output file, verify:
- [ ] File exists and is not empty
- [ ] Contains all expected sheet names
- [ ] Sample data matches source
- [ ] Formulas calculate correctly (spot-check 3 cells)

Run validation: `python formula_check.py output.xlsx`
```
→ 有 checklist + 验证命令

**❌ 得 0 分示例**：
无验证环节，执行完就结束，无法确认结果正确性。

---

## 维度 12: 简洁性 (1分)

**评判标准**：
- 总行数 < 500 行 (不含 references 子文件)
- 无冗余段落、无重复内容
- 语言精炼，无 marketing 语言
- 代码示例适中 (不过度展开实现细节)

**✅ 得 1 分示例**：
```markdown
# Summarize
Fast CLI to summarize URLs, local files, and YouTube links.

## Quick start
summarize "https://example.com" --model google/gemini-3-flash-preview

## Useful flags
- --length short|medium|long
- --json (machine readable)
```
→ 精炼、直奔主题、没有废话

**❌ 得 0 分示例**：
SKILL.md 超过 1000 行，包含大量重复描述、过长的背景介绍、大段代码实现。

---

## 打分规则总结

| 维度 | 检查要点 | 得分条件 |
|------|---------|---------|
| 1. Frontmatter | YAML 格式、name、description | 格式正确 + 字段完整 |
| 2. 触发条件 | description 说明"何时调用" | 有触发场景或触发词 |
| 3. 角色设定 | 开篇定义 Agent 行为模式 | 有明确身份/行为描述 |
| 4. 指令结构 | 编号步骤、输入→动作→输出 | 步骤可独立执行 |
| 5. 自由度 | EXACT/FLEX 标注 | 硬性规则与建议有区分 |
| 6. 输出格式 | 填充完毕的输出示例 | 有具体示例非占位符 |
| 7. 示例覆盖 | 正常+异常+边界 | ≥2 类场景有示例 |
| 8. 陷阱坑点 | Gotchas 章节 | 有具体失败模式+解决方案 |
| 9. 约束条件 | 安全边界、领域限制 | 有明确禁止/限制说明 |
| 10. 工具控制 | allowed-tools | 有且与实际功能匹配 |
| 11. 验证机制 | 自检/list/验证命令 | 有至少 1 种验证方式 |
| 12. 简洁性 | <500行、无冗余 | 精炼、无废话 |
