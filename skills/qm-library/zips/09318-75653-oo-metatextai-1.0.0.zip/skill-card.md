## Description: <br>
This skill lets an agent operate MetatextAI for guardrail policy management, transcript evaluation, and red-team test scans through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage MetatextAI guardrail policies, evaluate chat transcripts, and run red-team test scans through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create guardrail policies or run test scans against a connected MetatextAI application. <br>
Mitigation: Review the action payload and intended effect before approving write actions or scans. <br>
Risk: The skill requires access to a connected MetatextAI account through OOMOL. <br>
Mitigation: Install and use it only when the agent is expected to operate that connected account. <br>


## Reference(s): <br>
- [ClawHub Skill Listing](https://clawhub.ai/oomol/oo-metatextai) <br>
- [MetatextAI Homepage](https://metatext.ai) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [create_policy action](actions/create_policy.md) <br>
- [evaluate action](actions/evaluate.md) <br>
- [list_policies action](actions/list_policies.md) <br>
- [run_test_scan action](actions/run_test_scan.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema checks before action payload construction.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
