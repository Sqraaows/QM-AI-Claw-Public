#!/usr/bin/env bash
# 知信图谱 (Knowledge-Trust Graph) 一键安装脚本
# 使用: bash <(curl -sL https://raw.githubusercontent.com/你的用户名/zhixin-graph/main/install.sh)
# 或:   curl -sL https://raw.githubusercontent.com/你的用户名/zhixin-graph/main/install.sh | bash

set -e

REPO="你的用户名/zhixin-graph"
BRANCH="main"
BASE_URL="https://raw.githubusercontent.com/$REPO/$BRANCH"

echo "🧠 知信图谱 (Knowledge-Trust Graph) 安装中..."
echo ""

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 需要 Python 3.8+，但未找到 python3"
    exit 1
fi

PY_VERSION=$(python3 --version 2>&1 | grep -oP '\d+\.\d+' | head -1)
echo "✅ Python $PY_VERSION"

# 创建目录
mkdir -p ~/.zhixin/references

# 下载 kg.py
echo "⬇️  下载 kg.py..."
curl -sL "$BASE_URL/kg.py" -o ~/.zhixin/kg.py
chmod +x ~/.zhixin/kg.py
echo "✅ kg.py 已安装到 ~/.zhixin/kg.py"

# 下载 SKILL.md
echo "⬇️  下载 SKILL.md..."
curl -sL "$BASE_URL/SKILL.md" -o ~/.zhixin/SKILL.md

# 下载参考文档
echo "⬇️  下载参考文档..."
for doc in schema.md trust-engine.md usage-patterns.md ai-extraction-guide.md; do
    curl -sL "$BASE_URL/references/$doc" -o ~/.zhixin/references/$doc
done

# 下载 LICENSE
curl -sL "$BASE_URL/LICENSE" -o ~/.zhixin/LICENSE
curl -sL "$BASE_URL/LICENSE-docs" -o ~/.zhixin/LICENSE-docs

echo ""
echo "🎉 安装完成！"
echo ""
echo "快速开始："
echo "  python3 ~/.zhixin/kg.py init"
echo "  python3 ~/.zhixin/kg.py add-entity '{\"name\":\"我的项目\",\"type\":\"project\"}'"
echo "  python3 ~/.zhixin/kg.py add-fact '{\"entity_name\":\"我的项目\",\"content\":\"使用Python 3.12\",\"fact_type\":\"knowledge\"}'"
echo "  python3 ~/.zhixin/kg.py search 'Python'"
echo ""
echo "查看使用说明：  cat ~/.zhixin/SKILL.md"
