#!/usr/bin/env python3
"""知信图谱 (Knowledge-Trust Graph) CLI
知识信息 + 可信任的验证 -> 动态化图谱
核心依赖：Python 标准库 (sqlite3, json, argparse, uuid, datetime)
可选扩展：Ollama + bge-m3 → 语义向量搜索
"""
import sqlite3
import json
import uuid
import os
import sys
import argparse
import math
import urllib.request
from datetime import datetime, timedelta

DB_DIR = os.path.expanduser("~/.zhixin")
DB_PATH = os.path.join(DB_DIR, "zhixin.db")

# ── Ollama / Vector helpers (optional) ────────────────────────

OLLAMA_URL = "http://127.0.0.1:11434"

def _ollama_available():
    """Check if Ollama is running. Returns True if reachable."""
    try:
        req = urllib.request.Request(f"{OLLAMA_URL}/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return True
    except Exception:
        return False

def _ollama_embed(text, model=None):
    """Generate embedding vector for text via Ollama.
    Uses Ollama's default embedding model if model not specified.
    Returns (embedding_list, model_used) or (None, None) on failure."""
    payload = {"prompt": text}
    if model:
        payload["model"] = model
    try:
        req = urllib.request.Request(f"{OLLAMA_URL}/api/embeddings",
            data=json.dumps(payload).encode(), method="POST",
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read())
            emb = result.get("embedding")
            used = result.get("model", model or "default")
            return emb, used
    except Exception as e:
        print(f"  ⚠️  Ollama embedding 失败: {e}")
        return None, None

def _cosine_similarity(vec_a, vec_b):
    """Cosine similarity between two vectors."""
    dot = sum(a*b for a, b in zip(vec_a, vec_b))
    mag_a = math.sqrt(sum(a*a for a in vec_a))
    mag_b = math.sqrt(sum(b*b for b in vec_b))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)

# ── helpers ──────────────────────────────────────────────────

def _validate_date(date_str):
    """Validate YYYY-MM-DD date format. Returns True if valid."""
    try:
        if not date_str or date_str.strip() == "":
            return False
        datetime.strptime(date_str.strip(), "%Y-%m-%d")
        return True
    except (ValueError, TypeError):
        return False


def get_db():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.row_factory = sqlite3.Row
    return conn

def uid():
    return str(uuid.uuid4())[:8]

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log_change(conn, table, rid, action, old=None, new=None, by="cli"):
    conn.execute("""INSERT INTO change_log (table_name, record_id, action, old_values, new_values, changed_by)
        VALUES (?,?,?,?,?,?)""",
        (table, rid, action, json.dumps(old, ensure_ascii=False) if old else None,
         json.dumps(new, ensure_ascii=False) if new else None, by))

# ── DDL ──────────────────────────────────────────────────────

DDL = [
    """CREATE TABLE IF NOT EXISTS branches (
        id TEXT PRIMARY KEY DEFAULT 'main', name TEXT NOT NULL,
        description TEXT, created_at TEXT DEFAULT (datetime('now')))""",
    """CREATE TABLE IF NOT EXISTS sources (
        id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
        type TEXT NOT NULL DEFAULT 'person',
        credibility_score REAL DEFAULT 0.5,
        reliability_notes TEXT,
        created_at TEXT DEFAULT (datetime('now')))""",
    """CREATE TABLE IF NOT EXISTS entities (
        id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
        type TEXT NOT NULL DEFAULT 'concept',
        description TEXT, tags TEXT,
        branch_id TEXT DEFAULT 'main' REFERENCES branches(id),
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')))""",
    """CREATE TABLE IF NOT EXISTS relations (
        id TEXT PRIMARY KEY,
        from_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        to_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        relation_type TEXT NOT NULL,
        strength REAL DEFAULT 1.0,
        source_ref TEXT,
        branch_id TEXT DEFAULT 'main',
        created_at TEXT DEFAULT (datetime('now')),
        UNIQUE(from_id, to_id, relation_type))""",
    """CREATE TABLE IF NOT EXISTS facts (
        id TEXT PRIMARY KEY, entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        content TEXT NOT NULL,
        fact_type TEXT DEFAULT 'knowledge',
        source_id TEXT REFERENCES sources(id),
        verification_state TEXT DEFAULT 'unverified',
        fresh_until TEXT, consensus_count INTEGER DEFAULT 0,
        dispute_count INTEGER DEFAULT 0,
        branch_id TEXT DEFAULT 'main',
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')))""",
    """CREATE TABLE IF NOT EXISTS annotations (
        id TEXT PRIMARY KEY, fact_id TEXT NOT NULL REFERENCES facts(id) ON DELETE CASCADE,
        annotator TEXT NOT NULL,
        annotation_type TEXT NOT NULL,
        content TEXT,
        created_at TEXT DEFAULT (datetime('now')))""",
    """CREATE TABLE IF NOT EXISTS change_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        table_name TEXT NOT NULL, record_id TEXT NOT NULL,
        action TEXT NOT NULL, old_values TEXT, new_values TEXT,
        changed_by TEXT, changed_at TEXT DEFAULT (datetime('now')))""",
    # Verifiability view
    """CREATE VIEW IF NOT EXISTS v_fact_verifiability AS
    SELECT f.id, f.content, f.verification_state, f.consensus_count, f.dispute_count, f.fresh_until,
        COALESCE(s.credibility_score, 0.5) AS source_score,
        CASE f.verification_state
            WHEN 'unverified' THEN 0.0 WHEN 'self_checked' THEN 0.3
            WHEN 'peer_reviewed' THEN 0.7 WHEN 'external_confirmed' THEN 1.0
            WHEN 'disputed' THEN 0.2 WHEN 'consensus' THEN 0.9
            WHEN 'outdated' THEN 0.1 ELSE 0.0 END AS verification_score,
        CASE WHEN f.fresh_until IS NULL THEN 1.0
            WHEN date(f.fresh_until) >= date('now') THEN 1.0
            ELSE MAX(0.0, 1.0 - (julianday('now')-julianday(f.fresh_until))/300.0) END AS freshness_score,
        CASE WHEN f.consensus_count+f.dispute_count=0 THEN 0.5
            ELSE CAST(f.consensus_count AS REAL)/(f.consensus_count+f.dispute_count) END AS consensus_ratio,
        ROUND(0.30*COALESCE(s.credibility_score,0.5) + 0.35*
            CASE f.verification_state
                WHEN 'unverified' THEN 0.0 WHEN 'self_checked' THEN 0.3
                WHEN 'peer_reviewed' THEN 0.7 WHEN 'external_confirmed' THEN 1.0
                WHEN 'disputed' THEN 0.2 WHEN 'consensus' THEN 0.9
                WHEN 'outdated' THEN 0.1 ELSE 0.0 END + 0.20*
            CASE WHEN f.fresh_until IS NULL THEN 1.0
                WHEN date(f.fresh_until)>=date('now') THEN 1.0
                ELSE MAX(0.0,1.0-(julianday('now')-julianday(f.fresh_until))/300.0) END + 0.15*
            CASE WHEN f.consensus_count+f.dispute_count=0 THEN 0.5
                ELSE CAST(f.consensus_count AS REAL)/(f.consensus_count+f.dispute_count) END, 2) AS verifiability
    FROM facts f LEFT JOIN sources s ON f.source_id=s.id""",
    # Optional: vector embeddings for semantic search
    """CREATE TABLE IF NOT EXISTS entity_embeddings (
        entity_id TEXT PRIMARY KEY REFERENCES entities(id) ON DELETE CASCADE,
        embedding TEXT NOT NULL,
        model TEXT, dims INTEGER,
        updated_at TEXT DEFAULT (datetime('now')))""",
    """CREATE TABLE IF NOT EXISTS fact_embeddings (
        fact_id TEXT PRIMARY KEY REFERENCES facts(id) ON DELETE CASCADE,
        embedding TEXT NOT NULL,
        model TEXT, dims INTEGER,
        updated_at TEXT DEFAULT (datetime('now')))""",
]


def cmd_init(args):
    conn = get_db()
    for stmt in DDL:
        conn.execute(stmt)
    # Insert default main branch after branches table exists
    conn.execute("INSERT OR IGNORE INTO branches (id, name, description) VALUES ('main','main','Default branch')")
    conn.commit()
    conn.close()
    print("✅ 知信图谱已初始化")
    print(f"   数据库: {DB_PATH}")
    print(f"   核心表: entities, relations, facts, sources, annotations, branches, change_log")
    print(f"   向量表: entity_embeddings, fact_embeddings (可选扩展)")
    if _ollama_available():
        print(f"   🟢 Ollama 可用 — semantic/embed 命令就绪")
    else:
        print(f"   ⚪ Ollama 未检测到 — 向量搜索暂不可用 (keyword 搜索始终可用)")


# ── add commands ─────────────────────────────────────────────

def _resolve_entity(conn, name):
    """Resolve entity by name, return id. Creates stub if not found."""
    row = conn.execute("SELECT id FROM entities WHERE name=?", (name,)).fetchone()
    if row:
        return row[0]
    eid = uid()
    conn.execute("INSERT INTO entities (id,name,type) VALUES (?,?,'concept')", (eid, name))
    log_change(conn, "entities", eid, "insert", new={"name": name, "type": "concept", "_auto_created": True})
    return eid

def _resolve_source(conn, name):
    """Resolve source by name, return id."""
    if not name:
        return None
    row = conn.execute("SELECT id FROM sources WHERE name=?", (name,)).fetchone()
    if row:
        return row[0]
    sid = uid()
    conn.execute("INSERT INTO sources (id,name,type) VALUES (?,?,'person')", (sid, name))
    log_change(conn, "sources", sid, "insert", new={"name": name, "type": "person", "_auto_created": True})
    return sid

def cmd_add_entity(args):
    d = json.loads(args.json)
    conn = get_db()
    eid = uid()
    conn.execute("""INSERT INTO entities (id,name,type,description,tags)
        VALUES (?,?,?,?,?)""",
        (eid, d["name"], d.get("type","concept"), d.get("description",""),
         json.dumps(d.get("tags",[]), ensure_ascii=False)))
    log_change(conn, "entities", eid, "insert", new=d)
    conn.commit(); conn.close()
    print(f"✅ 实体已添加: {d['name']} ({eid})")

def cmd_add_fact(args):
    d = json.loads(args.json)
    if "fresh_until" not in d:
        d["fresh_until"] = (datetime.now() + timedelta(days=90)).strftime("%Y-%m-%d")
    elif not _validate_date(d["fresh_until"]):
        print(f"❌ 无效日期格式: {d['fresh_until']}，应为 YYYY-MM-DD"); sys.exit(1)
    conn = get_db()
    entity_name = d.pop("entity_name")
    entity_id = _resolve_entity(conn, entity_name)
    source_name = d.pop("source_name", None)
    source_id = _resolve_source(conn, source_name) if source_name else None
    verification = d.pop("verification", "unverified")
    fid = uid()
    conn.execute("""INSERT INTO facts (id,entity_id,content,fact_type,source_id,verification_state,fresh_until)
        VALUES (?,?,?,?,?,?,?)""",
        (fid, entity_id, d["content"], d.get("fact_type","knowledge"),
         source_id, verification, d.get("fresh_until")))
    log_change(conn, "facts", fid, "insert", new={"entity_name":entity_name,"content":d["content"]})
    conn.commit()
    # update entity updated_at
    conn.execute("UPDATE entities SET updated_at=? WHERE id=?", (now(), entity_id))
    conn.commit(); conn.close()
    state_label = {"unverified":"未验证","self_checked":"已自查","peer_reviewed":"已复核","external_confirmed":"外部确认"}.get(verification, verification)
    print(f"✅ 事实已添加 ({state_label}): {d['content'][:60]}...")

def cmd_add_relation(args):
    d = json.loads(args.json)
    conn = get_db()
    from_id = _resolve_entity(conn, d["from"])
    to_id = _resolve_entity(conn, d["to"])
    rel_type = d["relation_type"]
    rid = uid()
    try:
        conn.execute("""INSERT INTO relations (id,from_id,to_id,relation_type,source_ref)
            VALUES (?,?,?,?,?)""", (rid, from_id, to_id, rel_type, d.get("source_ref","")))
        log_change(conn, "relations", rid, "insert", new=d)
        conn.commit(); conn.close()
        print(f"✅ 关系已添加: {d['from']} --[{rel_type}]--> {d['to']}")
    except sqlite3.IntegrityError:
        conn.close()
        print(f"⚠️  关系已存在: {d['from']} --[{rel_type}]--> {d['to']}")

def cmd_add_source(args):
    d = json.loads(args.json)
    conn = get_db()
    sid = uid()
    conn.execute("""INSERT INTO sources (id,name,type,credibility_score,reliability_notes)
        VALUES (?,?,?,?,?)""",
        (sid, d["name"], d.get("type","person"), d.get("credibility_score",0.5), d.get("reliability_notes","")))
    log_change(conn, "sources", sid, "insert", new=d)
    conn.commit(); conn.close()
    print(f"✅ 信息源已注册: {d['name']} (可信度:{d.get('credibility_score',0.5)})")


# ── update ───────────────────────────────────────────────────

def cmd_update_fact(args):
    d = json.loads(args.json)
    if "fresh_until" in d and not _validate_date(d["fresh_until"]):
        print(f"❌ 无效日期格式: {d['fresh_until']}，应为 YYYY-MM-DD"); sys.exit(1)
    conn = get_db()
    old = dict(conn.execute("SELECT * FROM facts WHERE id=?", (args.id,)).fetchone())
    updates = []
    params = []
    for k in ("content","fact_type","verification_state","fresh_until"):
        if k in d:
            updates.append(f"{k}=?")
            params.append(d[k])
    if not updates:
        conn.close(); print("⚠️  无更新字段"); return
    params.append(args.id)
    conn.execute(f"UPDATE facts SET {','.join(updates)}, updated_at=? WHERE id=?", params + [now()])
    log_change(conn, "facts", args.id, "update", old=dict(old), new=d)
    conn.commit(); conn.close()
    print(f"✅ 事实已更新: {args.id}")


# ── query commands ───────────────────────────────────────────

def cmd_search(args):
    conn = get_db()
    kw = f"%{args.keyword}%"
    rows = conn.execute("""SELECT f.id, f.content, e.name as entity_name, f.verification_state,
        (SELECT verifiability FROM v_fact_verifiability WHERE id=f.id) as vf
        FROM facts f JOIN entities e ON f.entity_id=e.id
        WHERE f.content LIKE ? OR e.name LIKE ?
        ORDER BY f.created_at DESC LIMIT 30""", (kw, kw)).fetchall()
    conn.close()
    if not rows:
        print("未找到匹配结果。")
        return
    print(f"搜索 '{args.keyword}' 结果 ({len(rows)}):\n")
    for r in rows:
        state = {"unverified":" ","self_checked":"✓","peer_reviewed":"✓✓","external_confirmed":"✓✓✓"}.get(r["verification_state"]," ")
        vf = r["vf"] or 0
        print(f"  [{state}] {r['content'][:80]}  (←{r['entity_name']}) 可信度:{vf:.2f}")

def cmd_entity(args):
    conn = get_db()
    e = conn.execute("SELECT * FROM entities WHERE name=?", (args.name,)).fetchone()
    if not e:
        conn.close(); print(f"实体不存在: {args.name}"); return
    facts = conn.execute("""SELECT f.*, (SELECT verifiability FROM v_fact_verifiability WHERE id=f.id) as vf
        FROM facts f WHERE f.entity_id=? ORDER BY f.created_at DESC""", (e["id"],)).fetchall()
    rels = conn.execute("""SELECT r.relation_type, e2.name as target_name
        FROM relations r JOIN entities e2 ON r.to_id=e2.id WHERE r.from_id=?
        UNION ALL SELECT r.relation_type, e2.name as target_name
        FROM relations r JOIN entities e2 ON r.from_id=e2.id WHERE r.to_id=?""",
        (e["id"], e["id"])).fetchall()
    # Also get reverse relations
    rev_rels = conn.execute("""SELECT e2.name as from_name, r.relation_type, ?
        FROM relations r JOIN entities e2 ON r.from_id=e2.id WHERE r.to_id=?""",
        (e["name"], e["id"])).fetchall()
    conn.close()

    print(f"\n📦 {e['name']} ({e['type']})")
    if e["description"]:
        print(f"   {e['description']}")
    if e["tags"]:
        print(f"   标签: {', '.join(json.loads(e['tags']))}")

    print(f"\n📝 事实 ({len(facts)}):")
    for f in facts:
        state = f["verification_state"]
        state_icon = {"unverified":" ","self_checked":"✓","peer_reviewed":"✓✓","external_confirmed":"✓✓✓","consensus":"✓✓✓✓","disputed":"⚠","outdated":"⏳"}.get(state," ")
        vf = f["vf"] or 0
        bar = "█" * int(vf*10) + "░" * (10-int(vf*10))
        print(f"  [{state_icon}] {f['content']}")
        print(f"      状态:{state} 可信度:[{bar}] {vf:.2f}  过期:{f['fresh_until'] or '无'}")

    print(f"\n🔗 关系 ({len(rels)+len(rev_rels)}):")
    for r in rev_rels:
        print(f"  {r['from_name']} --[{r['relation_type']}]--> {e['name']}")
    for r in rels:
        print(f"  {e['name']} --[{r['relation_type']}]--> {r['target_name']}")

def cmd_traverse(args):
    conn = get_db()
    depth = args.depth or 2
    e = conn.execute("SELECT id,name FROM entities WHERE name=?", (args.name,)).fetchone()
    if not e:
        conn.close(); print(f"实体不存在: {args.name}"); return

    visited = set()
    def bfs(start_id, max_depth):
        queue = [(start_id, 0)]
        result = []
        while queue:
            nid, d = queue.pop(0)
            if nid in visited or d > max_depth: continue
            visited.add(nid)
            name = conn.execute("SELECT name FROM entities WHERE id=?",(nid,)).fetchone()[0]
            result.append((d, name))
            if d < max_depth:
                for row in conn.execute("SELECT to_id,relation_type FROM relations WHERE from_id=?",(nid,)):
                    if row[0] not in visited:
                        queue.append((row[0], d+1))
                        result.append((f"  {row[1]}→", row[0]))
                for row in conn.execute("SELECT from_id,relation_type FROM relations WHERE to_id=?",(nid,)):
                    if row[0] not in visited:
                        queue.append((row[0], d+1))
                        result.append((f"  ←{row[1]}", row[0]))
        return result

    nodes = bfs(e["id"], depth)
    conn.close()
    print(f"\n🔍 从 '{args.name}' 出发 (深度 {depth}):\n")
    for d, name in nodes:
        if isinstance(d, int):
            print(f"{'  '*d}├─ {name}")
        else:
            pass  # skip raw IDs

def cmd_recent(args):
    days = args.days or 7
    conn = get_db()
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    facts = conn.execute("""SELECT f.*, e.name as entity_name
        FROM facts f JOIN entities e ON f.entity_id=e.id
        WHERE f.created_at >= ? ORDER BY f.created_at DESC LIMIT 50""", (since,)).fetchall()
    entities = conn.execute("""SELECT * FROM entities WHERE created_at >= ? ORDER BY created_at DESC LIMIT 20""", (since,)).fetchall()
    conn.close()
    print(f"\n最近 {days} 天更新:\n")
    if entities:
        print(f"🏷️  新实体 ({len(entities)}):")
        for e in entities:
            print(f"  + {e['name']} ({e['type']})")
    if facts:
        print(f"\n📝 新事实 ({len(facts)}):")
        for f in facts:
            print(f"  + [{f['verification_state']}] {f['content'][:70]} (←{f['entity_name']})")
    if not entities and not facts:
        print("  无更新")


# ── verification & trust commands ────────────────────────────

def cmd_verify(args):
    conn = get_db()
    valid = {"self_checked","peer_reviewed","external_confirmed"}
    if args.level not in valid:
        conn.close(); print(f"无效验证等级: {args.level}。可选: {valid}"); return
    conn.execute("UPDATE facts SET verification_state=?, updated_at=? WHERE id=?",
        (args.level, now(), args.id))
    log_change(conn, "facts", args.id, "update", old={"verification_state":"?"}, new={"verification_state":args.level})
    conn.commit(); conn.close()
    print(f"✅ 事实 {args.id} 验证状态 → {args.level}")

def cmd_annotate(args):
    d = json.loads(args.json)
    conn = get_db()
    aid = uid()
    fact = conn.execute("SELECT * FROM facts WHERE id=?", (d["fact_id"],)).fetchone()
    if not fact:
        conn.close(); print(f"事实不存在: {d['fact_id']}"); return
    conn.execute("""INSERT INTO annotations (id,fact_id,annotator,annotation_type,content)
        VALUES (?,?,?,?,?)""",
        (aid, d["fact_id"], d["annotator"], d["type"], d.get("content","")))
    # Update consensus/dispute counts and state
    atype = d["type"]
    if atype == "confirm":
        conn.execute("UPDATE facts SET consensus_count=consensus_count+1, updated_at=? WHERE id=?", (now(), d["fact_id"]))
        new_count = conn.execute("SELECT consensus_count FROM facts WHERE id=?", (d["fact_id"],)).fetchone()[0]
        if new_count >= 3:
            conn.execute("UPDATE facts SET verification_state='consensus' WHERE id=?", (d["fact_id"],))
        elif fact["verification_state"] == "unverified":
            conn.execute("UPDATE facts SET verification_state='peer_reviewed' WHERE id=?", (d["fact_id"],))
    elif atype == "dispute":
        conn.execute("UPDATE facts SET dispute_count=dispute_count+1, verification_state='disputed', updated_at=? WHERE id=?", (now(), d["fact_id"]))
    log_change(conn, "annotations", aid, "insert", new=d)
    conn.commit(); conn.close()
    print(f"✅ 标注已添加: {atype} → {d['fact_id']}")

def cmd_check(args):
    conn = get_db()
    row = conn.execute("""SELECT f.*, e.name as entity_name, s.name as source_name,
        s.credibility_score as source_score,
        (SELECT verifiability FROM v_fact_verifiability WHERE id=f.id) as vf,
        (SELECT COUNT(*) FROM annotations WHERE fact_id=f.id) as ann_count
        FROM facts f JOIN entities e ON f.entity_id=e.id
        LEFT JOIN sources s ON f.source_id=s.id
        WHERE f.id=?""", (args.id,)).fetchone()
    if not row:
        conn.close(); print(f"事实不存在: {args.id}"); return

    annotations = conn.execute("SELECT * FROM annotations WHERE fact_id=? ORDER BY created_at", (args.id,)).fetchall()
    conn.close()

    vf = row["vf"] or 0
    bar = "█"*int(vf*10) + "░"*(10-int(vf*10))
    state = row["verification_state"]
    print(f"\n📝 事实: {row['content']}")
    print(f"   所属实体: {row['entity_name']}")
    print(f"   类型: {row['fact_type']}  |  验证状态: {state}  |  可信度: [{bar}] {vf:.2f}")
    print(f"\n🔗 验证链:")
    print(f"   信息源: {row['source_name'] or '未指定'} (可信度:{row['source_score'] or 0.5:.1f})")
    print(f"   验证深度: {state}")
    print(f"   有效期: {row['fresh_until'] or '永久'}")
    print(f"   共识: {row['consensus_count']}确认 / {row['dispute_count']}质疑")

    if annotations:
        print(f"\n💬 标注记录 ({len(annotations)}):")
        for a in annotations:
            icon = {"confirm":"✅","dispute":"⚠️","clarify":"💡","update":"📝"}.get(a["annotation_type"]," ")
            print(f"   {icon} {a['annotator']}: {a['content'][:60]}")
    print()

def cmd_check_report(args):
    conn = get_db()
    if args.entity:
        e = conn.execute("SELECT id,name FROM entities WHERE name=?", (args.entity,)).fetchone()
        if not e:
            conn.close(); print(f"实体不存在: {args.entity}"); return
        facts = conn.execute("""SELECT * FROM (SELECT f.*, e.name as en, v.verifiability FROM facts f
            JOIN entities e ON f.entity_id=e.id
            LEFT JOIN v_fact_verifiability v ON v.id=f.id
            WHERE f.entity_id=?) ORDER BY verifiability""", (e["id"],)).fetchall()
    else:
        facts = conn.execute("""SELECT f.*, e.name as en, v.verifiability FROM facts f
            JOIN entities e ON f.entity_id=e.id
            LEFT JOIN v_fact_verifiability v ON v.id=f.id
            ORDER BY v.verifiability LIMIT 50""").fetchall()
    conn.close()

    print(f"\n📊 可信任全景{' — '+args.entity if args.entity else ''} ({len(facts)}条):\n")
    if not facts:
        print("  无数据"); return
    for f in facts:
        vf = f["verifiability"] or 0
        bar = "█"*int(vf*10) + "░"*(10-int(vf*10))
        state = f["verification_state"]
        level = "🟢" if vf>=0.8 else "🟡" if vf>=0.5 else "🟠" if vf>=0.2 else "🔴"
        print(f"  {level} [{bar}] {f['content'][:60]}")
        print(f"     ←{f['en']} | {state}")
    print()

def cmd_stale(args):
    days = args.days or 30
    conn = get_db()
    if args.state_filter:
        rows = conn.execute("""SELECT f.*, e.name as en FROM facts f JOIN entities e ON f.entity_id=e.id
            WHERE f.verification_state=? ORDER BY f.created_at""", (args.state_filter,)).fetchall()
    else:
        future = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
        rows = conn.execute("""SELECT f.*, e.name as en FROM facts f JOIN entities e ON f.entity_id=e.id
            WHERE f.fresh_until IS NOT NULL AND f.fresh_until <= ? AND f.verification_state != 'outdated'
            ORDER BY f.fresh_until""", (future,)).fetchall()
    conn.close()

    label = f"验证状态: {args.state_filter}" if args.state_filter else f"{days}天内过期"
    print(f"\n⏳ 过期/待验证 ({label}): {len(rows)}条\n")
    if not rows:
        print("  全部健康 ✅"); return
    for r in rows:
        icon = "⏳" if r["verification_state"]=="outdated" else "⚠️" if r["verification_state"]=="unverified" else " "
        print(f"  {icon} [{r['verification_state']}] {r['content'][:70]} (←{r['en']}) 过期:{r['fresh_until'] or '无'}")


# ── branch ───────────────────────────────────────────────────

def cmd_branch(args):
    conn = get_db()
    if args.action == "create":
        d = json.loads(args.json)
        conn.execute("INSERT INTO branches (id,name,description) VALUES (?,?,?)",
            (d["name"], d["name"], d.get("description","")))
        log_change(conn, "branches", d["name"], "insert", new=d)
        conn.commit(); conn.close()
        print(f"✅ 分支已创建: {d['name']}")
    elif args.action == "list":
        rows = conn.execute("SELECT * FROM branches ORDER BY created_at").fetchall()
        conn.close()
        print("\n📂 分支列表:")
        for r in rows:
            print(f"  {r['id']}: {r['name']} — {r['description'] or ''}")
        print()


# ── export / import ──────────────────────────────────────────

def cmd_export(args):
    conn = get_db()
    branch = args.branch or "main"
    data = {
        "version": "1.0",
        "exported_at": now(),
        "branch": branch,
        "sources": [dict(r) for r in conn.execute("SELECT * FROM sources").fetchall()],
        "entities": [dict(r) for r in conn.execute("SELECT * FROM entities WHERE branch_id=?", (branch,)).fetchall()],
        "relations": [dict(r) for r in conn.execute("SELECT * FROM relations WHERE branch_id=?", (branch,)).fetchall()],
        "facts": [dict(r) for r in conn.execute("SELECT * FROM facts WHERE branch_id=?", (branch,)).fetchall()],
    }
    conn.close()
    print(json.dumps(data, ensure_ascii=False, indent=2))

def cmd_import(args):
    if args.file:
        data = json.load(open(args.file, encoding="utf-8"))
    else:
        data = json.load(sys.stdin)

    conn = get_db()
    count = {"sources":0,"entities":0,"relations":0,"facts":0}
    skipped = {"sources":0,"entities":0,"relations":0,"facts":0}

    for s in data.get("sources", []):
        try:
            conn.execute("INSERT INTO sources (id,name,type,credibility_score,reliability_notes,created_at) VALUES (?,?,?,?,?,?)",
                (s.get("id",uid()), s["name"], s.get("type","person"), s.get("credibility_score",0.5), s.get("reliability_notes",""), s.get("created_at",now())))
            count["sources"] += 1
        except sqlite3.IntegrityError:
            skipped["sources"] += 1

    id_map = {}
    for e in data.get("entities", []):
        try:
            eid = e.get("id", uid())
            conn.execute("INSERT INTO entities (id,name,type,description,tags,branch_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",
                (eid, e["name"], e.get("type","concept"), e.get("description",""), e.get("tags","[]"), e.get("branch_id","main"), e.get("created_at",now()), e.get("updated_at",now())))
            id_map[e["name"]] = eid
            count["entities"] += 1
        except sqlite3.IntegrityError:
            skipped["entities"] += 1
            # map to existing
            existing = conn.execute("SELECT id FROM entities WHERE name=?", (e["name"],)).fetchone()
            if existing:
                id_map[e["name"]] = existing[0]

    for r in data.get("relations", []):
        try:
            from_id = id_map.get(r.get("from_name")) or r.get("from_id")
            to_id = id_map.get(r.get("to_name")) or r.get("to_id")
            # Try to resolve by name stored in from_id/to_id
            if not from_id:
                from_e = conn.execute("SELECT id FROM entities WHERE name=?", (r.get("from_name",""),)).fetchone()
                if from_e: from_id = from_e[0]
            if not to_id:
                to_e = conn.execute("SELECT id FROM entities WHERE name=?", (r.get("to_name",""),)).fetchone()
                if to_e: to_id = to_e[0]
            if from_id and to_id:
                conn.execute("INSERT INTO relations (id,from_id,to_id,relation_type,strength,source_ref,branch_id,created_at) VALUES (?,?,?,?,?,?,?,?)",
                    (r.get("id",uid()), from_id, to_id, r["relation_type"], r.get("strength",1.0), r.get("source_ref",""), r.get("branch_id","main"), r.get("created_at",now())))
                count["relations"] += 1
            else:
                skipped["relations"] += 1
        except sqlite3.IntegrityError:
            skipped["relations"] += 1

    for f in data.get("facts", []):
        try:
            entity_id = f.get("entity_id")
            if not entity_id:
                en = f.get("entity_name","")
                if en in id_map:
                    entity_id = id_map[en]
                else:
                    e_row = conn.execute("SELECT id FROM entities WHERE name=?", (en,)).fetchone()
                    if e_row: entity_id = e_row[0]
            if entity_id:
                conn.execute("""INSERT INTO facts (id,entity_id,content,fact_type,source_id,verification_state,fresh_until,consensus_count,dispute_count,branch_id,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                    (f.get("id",uid()), entity_id, f["content"], f.get("fact_type","knowledge"), f.get("source_id"), f.get("verification_state","unverified"), f.get("fresh_until"), f.get("consensus_count",0), f.get("dispute_count",0), f.get("branch_id","main"), f.get("created_at",now())))
                count["facts"] += 1
            else:
                skipped["facts"] += 1
        except sqlite3.IntegrityError:
            skipped["facts"] += 1

    conn.commit()
    conn.close()

    print(f"✅ 导入完成:")
    for t in ["sources","entities","relations","facts"]:
        s = f" (跳过{skipped[t]})" if skipped[t] else ""
        print(f"   {t}: +{count[t]}{s}")


# ── vector embed / semantic search (optional) ────────────────

def cmd_embed(args):
    """Generate embeddings for entities/facts that don't have them yet."""
    if not _ollama_available():
        print("⚠️  Ollama 不可用。请先启动 Ollama。")
        print("   安装: ollama pull <embedding-model>")
        return

    conn = get_db()
    target = args.target or "entities"

    if target == "entities":
        rows = conn.execute("""SELECT e.id, e.name, COALESCE(e.description,'') || ' ' || e.name as text
            FROM entities e LEFT JOIN entity_embeddings ve ON e.id=ve.entity_id
            WHERE ve.entity_id IS NULL""").fetchall()
    else:
        rows = conn.execute("""SELECT f.id, f.content as name, f.content as text
            FROM facts f LEFT JOIN fact_embeddings fe ON f.id=fe.fact_id
            WHERE fe.fact_id IS NULL""").fetchall()

    if not rows:
        print(f"✅ 所有 {target} 已有向量嵌入")
        conn.close()
        return

    print(f"🔧 为 {len(rows)} 个 {target} 生成向量嵌入...")
    count = 0
    for r in rows:
        emb, model = _ollama_embed(r["text"], model=args.model)
        if emb is None:
            print(f"  ❌ 失败: {r['name'][:50]}")
            continue
        emb_json = json.dumps(emb, ensure_ascii=False)
        dims = len(emb)
        if target == "entities":
            conn.execute("""INSERT OR REPLACE INTO entity_embeddings (entity_id, embedding, model, dims)
                VALUES (?,?,?,?)""", (r["id"], emb_json, model, dims))
        else:
            conn.execute("""INSERT OR REPLACE INTO fact_embeddings (fact_id, embedding, model, dims)
                VALUES (?,?,?,?)""", (r["id"], emb_json, model, dims))
        count += 1
        if count % 10 == 0:
            conn.commit()
            print(f"  ... {count}/{len(rows)}")

    conn.commit()
    conn.close()
    print(f"✅ 完成: {count}/{len(rows)} {target} 已嵌入 (模型: {model or 'default'}, 维度: {dims})")

def cmd_semantic(args):
    """Semantic search using vector embeddings."""
    if not _ollama_available():
        print("⚠️  Ollama 不可用。请先启动 Ollama，然后运行 embed 生成向量。")
        print("   备选: 使用 'search <keyword>' 进行关键词搜索。")
        return

    query_emb, model = _ollama_embed(args.query, model=args.model)
    if query_emb is None:
        print("❌ 查询嵌入失败")
        return

    conn = get_db()
    target = args.target or "facts"
    top_k = args.top_k or 10

    if target == "facts":
        rows = conn.execute("""SELECT f.id, f.content, e.name as entity_name, f.verification_state,
            fe.embedding, fe.model, fe.dims,
            (SELECT verifiability FROM v_fact_verifiability WHERE id=f.id) as vf
            FROM fact_embeddings fe JOIN facts f ON fe.fact_id=f.id
            JOIN entities e ON f.entity_id=e.id""").fetchall()
    else:
        rows = conn.execute("""SELECT e.id, e.name as content, e.name as entity_name, '' as verification_state,
            ve.embedding, ve.model, ve.dims, 0 as vf
            FROM entity_embeddings ve JOIN entities e ON ve.entity_id=e.id""").fetchall()

    if not rows:
        print(f"⚠️  无向量嵌入。请先运行: kg.py embed")
        conn.close()
        return

    # Compute cosine similarity
    scored = []
    for r in rows:
        emb = json.loads(r["embedding"])
        sim = _cosine_similarity(query_emb, emb)
        scored.append((sim, r))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:top_k]

    print(f"\n🔍 语义搜索 '{args.query[:60]}' (模型:{model or 'default'}, top {top_k}):\n")
    for sim, r in top:
        bar = "█"*int(sim*10) + "░"*(10-int(sim*10))
        state = r["verification_state"]
        state_icon = {"unverified":" ","self_checked":"✓","peer_reviewed":"✓✓",
            "external_confirmed":"✓✓✓","consensus":"✓✓✓✓","disputed":"⚠","outdated":"⏳"}.get(state," ")
        vf = r["vf"] or 0
        print(f"  [{state_icon}] [{bar}] {sim:.3f}  {r['content'][:80]}")
        print(f"       ←{r['entity_name']}  |  可信度:{vf:.2f}")

    conn.close()

# ── stats ────────────────────────────────────────────────────

def cmd_stats(args):
    conn = get_db()
    entities = conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
    relations = conn.execute("SELECT COUNT(*) FROM relations").fetchone()[0]
    facts = conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0]
    sources = conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0]
    states = conn.execute("""SELECT verification_state, COUNT(*) as cnt FROM facts
        GROUP BY verification_state ORDER BY cnt DESC""").fetchall()
    stale = conn.execute("""SELECT COUNT(*) FROM facts WHERE fresh_until IS NOT NULL
        AND fresh_until <= date('now','+7 days') AND verification_state != 'outdated'""").fetchone()[0]
    e_emb = conn.execute("SELECT COUNT(*) FROM entity_embeddings").fetchone()[0]
    f_emb = conn.execute("SELECT COUNT(*) FROM fact_embeddings").fetchone()[0]
    emb_info = ""
    if e_emb or f_emb:
        emb_row = conn.execute("SELECT model, dims FROM entity_embeddings UNION ALL SELECT model, dims FROM fact_embeddings LIMIT 1").fetchone()
        if emb_row:
            emb_info = f" ({emb_row['model']}, {emb_row['dims']}维)"
    conn.close()
    print(f"\n📊 知信图谱统计:\n")
    print(f"   实体: {entities}  |  关系: {relations}  |  事实: {facts}  |  信息源: {sources}")
    if e_emb or f_emb:
        print(f"   向量嵌入: 实体{e_emb} 事实{f_emb}{emb_info}")
    print(f"\n   验证状态分布:")
    for s in states:
        bar = "█" * min(s["cnt"], 40)
        print(f"   {s['verification_state']:20s} {s['cnt']:4d} {bar}")
    print(f"\n   过期/即将过期(7天): {stale}")


# ── CLI router ───────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="知信图谱 CLI — 知识信息 + 可信任验证 → 动态化图谱")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("init", help="初始化数据库")

    p = sub.add_parser("add-entity", help="添加实体")
    p.add_argument("json", help="JSON: {name, type, description?, tags?}")

    p = sub.add_parser("add-fact", help="添加事实")
    p.add_argument("json", help="JSON: {entity_name, content, fact_type?, source_name?, verification?, fresh_until?}")

    p = sub.add_parser("add-relation", help="添加关系")
    p.add_argument("json", help="JSON: {from, to, relation_type, source_ref?}")

    p = sub.add_parser("add-source", help="注册信息源")
    p.add_argument("json", help="JSON: {name, type?, credibility_score?, reliability_notes?}")

    p = sub.add_parser("update-fact", help="更新事实")
    p.add_argument("id")
    p.add_argument("json", help="JSON: {content?, fact_type?, verification_state?, fresh_until?}")

    p = sub.add_parser("search", help="全文搜索")
    p.add_argument("keyword")

    p = sub.add_parser("entity", help="查看实体详情")
    p.add_argument("name")

    p = sub.add_parser("traverse", help="关系遍历")
    p.add_argument("name")
    p.add_argument("--depth", type=int, default=2)

    p = sub.add_parser("recent", help="最近更新")
    p.add_argument("--days", type=int, default=7)

    p = sub.add_parser("verify", help="验证事实")
    p.add_argument("id")
    p.add_argument("--level", required=True, choices=["self_checked","peer_reviewed","external_confirmed"])

    p = sub.add_parser("annotate", help="团队标注")
    p.add_argument("json", help="JSON: {fact_id, annotator, type:confirm|dispute|clarify|update, content?}")

    p = sub.add_parser("check", help="查看事实验证链")
    p.add_argument("id")

    p = sub.add_parser("check-report", help="可信任全景报告")
    p.add_argument("--entity")

    p = sub.add_parser("stale", help="过期/待验证事实")
    p.add_argument("--days", type=int, default=30)
    g = p.add_mutually_exclusive_group()
    g.add_argument("--type", dest="state_filter", help="按验证状态过滤（已废弃，请用 --state）")
    g.add_argument("--state", dest="state_filter", help="按验证状态过滤: unverified, outdated, self_checked, peer_reviewed, external_confirmed, consensus, disputed")

    p = sub.add_parser("branch", help="分支管理")
    p.add_argument("action", choices=["create","list"])
    p.add_argument("json", nargs="?", default="{}", help="create时: {name, description?}")

    p = sub.add_parser("export", help="导出JSON")
    p.add_argument("--branch", default="main")

    p = sub.add_parser("import", help="导入JSON")
    p.add_argument("file", nargs="?", help="JSON文件路径，不指定则从stdin读取")

    sub.add_parser("stats", help="数据库统计")

    p = sub.add_parser("embed", help="[可选] 为实体/事实生成向量嵌入")
    p.add_argument("--target", choices=["entities","facts"], default="entities", help="目标类型 (默认:entities)")
    p.add_argument("--model", help="Ollama embedding模型名 (不指定则用Ollama默认)")

    p = sub.add_parser("semantic", help="[可选] 语义向量搜索")
    p.add_argument("query", help="搜索查询文本")
    p.add_argument("--target", choices=["facts","entities"], default="facts", help="搜索目标 (默认:facts)")
    p.add_argument("--top-k", type=int, default=10, help="返回条数 (默认:10)")
    p.add_argument("--model", help="Ollama embedding模型名 (不指定则用Ollama默认)")

    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        return

    cmds = {
        "init": cmd_init,
        "add-entity": cmd_add_entity,
        "add-fact": cmd_add_fact,
        "add-relation": cmd_add_relation,
        "add-source": cmd_add_source,
        "update-fact": cmd_update_fact,
        "search": cmd_search,
        "entity": cmd_entity,
        "traverse": cmd_traverse,
        "recent": cmd_recent,
        "verify": cmd_verify,
        "annotate": cmd_annotate,
        "check": cmd_check,
        "check-report": cmd_check_report,
        "stale": cmd_stale,
        "branch": cmd_branch,
        "export": cmd_export,
        "import": cmd_import,
        "stats": cmd_stats,
        "embed": cmd_embed,
        "semantic": cmd_semantic,
    }
    cmds[args.cmd](args)

if __name__ == "__main__":
    main()
