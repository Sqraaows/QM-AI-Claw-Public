# 🧠 知信图谱 (Knowledge-Trust Graph)

> **知 + 信** — 知识信息与可信任验证组合而成的动态化图谱。

每个人/团队都需要一个属于自己的知识系统，但传统知识库只回答"我们知道了什么"，从不回答"凭什么信"。知信图谱解决了这个问题。

## 核心价值

| 传统知识库 | 知信图谱 |
|-----------|---------|
| "这条信息可信度 0.8" | "张三说的，李四复核过，3人确认，有效期至6月" |
| 信任是静态分数 | 信任是动态验证链 |
| 过期信息无人知晓 | 自动检测过期，提醒刷新 |
| 知识孤岛 | JSON 导出/导入可共享 |

## 一句话

**零外部依赖**的 Python CLI 工具（SQLite + 标准库），让任何 AI 智能体或人类团队都能管理带验证链的知识图谱。

## 快速开始

```bash
# 1. 安装（30秒）
bash <(curl -sL https://raw.githubusercontent.com/你的用户名/zhixin-graph/main/install.sh)

# 2. 初始化
python3 ~/.zhixin/kg.py init

# 3. 开始使用
python3 ~/.zhixin/kg.py add-entity '{"name":"我的项目","type":"project"}'
python3 ~/.zhixin/kg.py add-fact '{"entity_name":"我的项目","content":"使用Python 3.12","fact_type":"knowledge"}'
python3 ~/.zhixin/kg.py search "Python"
```

## 谁适合用

| 角色 | 场景 |
|------|------|
| 🧑‍💻 个人开发者 | 管理项目知识、学习笔记、决策记录 |
| 👥 小团队（3-10人） | 共享项目上下文、异步同步信息 |
| 🤖 AI 智能体 | 作为长期记忆/知识库，供 OpenClaw、Claude Code 等调用 |
| 🏢 组织 | 分支隔离不同项目/部门的知识 |

## 核心概念

### 知信 = 知 + 信

- **知**：知识信息（实体、关系、事实）
- **信**：可信任的验证（验证链、状态、过期机制）

每条知识的验证链可追溯：
```
信息源 → 源可信度 → 验证行为 → 验证方法 → 有效期限 → 团队共识
(谁说的) (此人可靠吗) (核实过吗) (怎么核实的) (过期了吗) (别人认可吗)
```

### CLI 速查

```bash
kg.py init                # 初始化数据库
kg.py add-entity <JSON>    # 添加实体（人/项目/概念/工具等）
kg.py add-fact <JSON>      # 添加知识事实
kg.py add-relation <JSON>  # 建立实体间关系
kg.py search <keyword>     # 全文搜索
kg.py entity <name>        # 查看实体详情
kg.py verify <id> --level L # 验证事实（自查/复核/外部确认）
kg.py annotate <JSON>      # 标注（确认/质疑/澄清）
kg.py check <id>           # 查看验证链
kg.py stale                # 查找过期/未验证事实
kg.py export               # 导出为JSON
kg.py import <file>        # 导入JSON（团队同步）
kg.py stats                # 统计概览
```

## 验证状态流转

```
录入 → unverified
  ↓ 自查
self_checked
  ↓ 至少1人确认
peer_reviewed
  ↓ ≥3人确认 → consensus
```

过期：`任何状态 → outdated → 更新后 → unverified（重新验证）`
质疑：`任何状态 → disputed → 解决后 → unverified（重新验证）`

## 依赖

- **必须**：Python 3.8+（标准库：sqlite3, json, argparse, uuid, datetime）
- **可选**：Ollama（用于向量语义搜索）

## 开源许可

- 代码 (`kg.py`)：MIT License
- 文档 (`SKILL.md`, `references/`)：CC BY 4.0

## 归因

| 来源 | 贡献 |
|------|------|
| [泛智生态系统](https://github.com/fanzhi-ecosystem) | entity→relation→fact 核心模型、分支概念、CLI 设计模式 |
| Ronie | 项目发起、方向决策、核心理念定义 |
| Win-ClaudeCode | 验证链模型、动态验证状态、AI 辅助提取流程 |
| WSL-OpenClaw | 通用智能体适配、智能体集成指南、代码审计 |
