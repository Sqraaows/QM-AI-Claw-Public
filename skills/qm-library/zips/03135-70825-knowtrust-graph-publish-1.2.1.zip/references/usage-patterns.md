# 知信图谱 — 使用模式

## 模式 1：个人知识库

### 适用场景
- 独立开发者管理项目知识
- 个人学习笔记的系统化整理
- 决策记录和追溯

### 最小命令集
```
--init                # 一次性初始化
--add-entity          # 添加知识节点
--add-fact            # 添加知识原子
--add-relation        # 连接知识节点
--search              # 搜索
--entity              # 查看详情
--verify self_checked # 自查确认
```

### 典型会话
```bash
# 第一天：初始化
python3 ~/.zhixin/kg.py init

# 记录项目信息
python3 ~/.zhixin/kg.py add-entity '{"name":"我的SaaS项目","type":"project","tags":["saas","python"]}'
python3 ~/.zhixin/kg.py add-fact '{"entity_name":"我的SaaS项目","content":"目标用户是中小企业的HR部门","fact_type":"knowledge","verification":"self_checked"}'
python3 ~/.zhixin/kg.py add-fact '{"entity_name":"我的SaaS项目","content":"MVP计划8月上线","fact_type":"status","fresh_until":"2026-09-01"}'

# 记录技术选型
python3 ~/.zhixin/kg.py add-entity '{"name":"PostgreSQL","type":"tool","description":"主数据库"}'
python3 ~/.zhixin/kg.py add-relation '{"from":"我的SaaS项目","to":"PostgreSQL","relation_type":"depends_on"}'

# 查询
python3 ~/.zhixin/kg.py search "数据库"
python3 ~/.zhixin/kg.py entity "我的SaaS项目"

# 定期检查过期信息
python3 ~/.zhixin/kg.py stale
```

---

## 模式 2：小团队信息共享

### 适用场景
- 3-10 人团队需要共享项目上下文
- 分布式团队需要异步同步信息
- 新人入职需要快速了解项目知识结构

### 额外命令
```
--add-source          # 注册团队成员为信息源
--verify peer_reviewed # 复核
--annotate confirm    # 确认队友的知识
--annotate dispute    # 质疑过时/错误信息
--check-report        # 查看可信任全景
--export / --import   # 团队同步
```

### 典型团队流程

**成员 A — 录入知识**：
```bash
# 先注册自己为信息源
python3 ~/.zhixin/kg.py add-source '{"name":"张三","type":"team_member","credibility_score":0.7}'

# 录入
python3 ~/.zhixin/kg.py add-fact '{"entity_name":"API网关","content":"QPS上限10000","fact_type":"constraint","source_name":"张三","fresh_until":"2026-07-01"}'
```

**成员 B — 复核验证**：
```bash
# 搜索待验证的知识
python3 ~/.zhixin/kg.py stale --type unverified

# 确认一条
python3 ~/.zhixin/kg.py annotate <fact_id> '{"annotator":"李四","type":"confirm","content":"压测数据一致"}'

# 质疑一条
python3 ~/.zhixin/kg.py annotate <fact_id> '{"annotator":"李四","type":"dispute","content":"新的压测显示QPS只有8000"}'
```

**同步**：
```bash
# A 导出
python3 ~/.zhixin/kg.py export > team-kg-2026-05-11.json

# B 导入（冲突项交互确认）
python3 ~/.zhixin/kg.py import team-kg-2026-05-11.json
```

---

## 模式 3：AI 辅助录入（推荐）

### 适用场景
- 会议后快速整理讨论内容
- 阅读文档后提取关键信息
- 对话中自然沉淀知识

### 使用方式

直接对 Claude Code 说：
- "把刚才讨论的内容整理到知信图谱"
- "把这篇文档的关键信息录入知信图谱"
- "查知信图谱里关于 API 网关的所有信息"

Claude 会自动：
1. 分析内容 → 提取实体/关系/事实
2. 展示预览 → 等你确认
3. 批量写入 → 报告结果

---

## 模式 4：分支隔离

### 适用场景
- 多个项目共享同一 kg.py 但需要知识隔离
- 敏感项目信息和通用知识分开管理

```bash
# 创建项目分支
python3 ~/.zhixin/kg.py branch create '{"name":"client-a","description":"客户A项目"}'

# 后续所有操作默认使用 main 分支
# 切换分支: 目前通过配置或后续版本支持
```

> 当前版本分支功能为基础实现，后续版本将支持 `--branch switch`。

---

## 数据库维护

```bash
# 统计概览
python3 ~/.zhixin/kg.py stats

# 示例输出:
# 实体: 45 | 关系: 67 | 事实: 128
# 验证状态: consensus:12 | peer_reviewed:23 | self_checked:45 | unverified:48
# 过期: 3 | 即将过期(7天): 5
```
