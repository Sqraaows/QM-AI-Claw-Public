## Description: <br>
V2EX lets an agent operate V2EX through the OOMOL oo CLI, including topic discovery, member utilities, notifications, and approved account actions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to read V2EX topics and operate authenticated account utilities through an installed OOMOL oo CLI connection. Write, delete, and token actions should be run only after confirming the exact target and payload. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can act on a connected V2EX account, including public visibility changes and token creation. <br>
Mitigation: Inspect the live action schema and confirm the exact topic, token, or payload before allowing write actions. <br>
Risk: The delete_notification action removes V2EX notification data. <br>
Mitigation: Require explicit user approval for the notification identifier before running destructive actions. <br>
Risk: The skill depends on a trusted OOMOL CLI and connector setup for account access. <br>
Mitigation: Use it only with a trusted OOMOL installation and connected V2EX account, and do not repeat sign-in or connection setup unless an auth or connection error requires it. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-v2ex) <br>
- [V2EX homepage](https://www.v2ex.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, JSON, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an OOMOL sign-in, and a connected V2EX account; write or destructive actions require explicit confirmation before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
