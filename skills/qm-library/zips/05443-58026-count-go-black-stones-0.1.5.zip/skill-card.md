## Description: <br>
Count black Go/Weiqi stones from source board photos, estimate black Chinese-area scoring, and render a clean static 19x19 result board image. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[imcaptor](https://clawhub.ai/user/imcaptor) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to analyze original Go board photos, count visible black stones, estimate black Chinese-area score, and produce optional verification or result images. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Photo quality, cropping, obstruction, or unsettled dead stones can make the count or Chinese-area score misleading. <br>
Mitigation: Use only intended board images, inspect the generated overlay or result board, and manually confirm uncertain classifications before relying on the score. <br>
Risk: Dependency behavior can vary across environments. <br>
Mitigation: Pin and review dependencies in controlled deployments. <br>


## Reference(s): <br>
- [Chinese README](artifact/README.md) <br>
- [English README](artifact/README.en.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, code, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands, JSON result fields, and optional generated image files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Can produce a verification overlay and a clean static 19x19 result board image when requested.] <br>

## Skill Version(s): <br>
0.1.5 (source: release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
