## Description: <br>
Comprehensive ComfyUI operations reference for the Genor-Comfy-Gate gateway, covering multi-modal audio, images, and video workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[genortg](https://clawhub.ai/user/genortg) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to configure and operate a local ComfyUI gateway, route generation requests across backends, and produce audio or image outputs through registered workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill runs a persistent local ComfyUI gateway with powerful workflow and service-control capabilities. <br>
Mitigation: Install it only where a persistent gateway is intended, restrict access to trusted users, and keep the service on localhost or private networks. <br>
Risk: Remote access depends on sensitive API key configuration and weak scoping can expose generation and workflow-mutation features. <br>
Mitigation: Set a strong GCG_API_KEY or API_KEY before exposing the gateway and enforce firewall or bind-address controls. <br>
Risk: Generated media links and sidecar metadata can contain sensitive content or operational details. <br>
Mitigation: Treat generated media links and metadata as sensitive, share them only with trusted recipients, and review MCP tools before connecting an agent. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/genortg/genor-comfy-gate) <br>
- [GSD Core project attribution](https://github.com/open-gsd/gsd-core) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, code, API calls, text, markdown] <br>
**Output Format:** [Markdown guidance with JSON examples, shell commands, and API request examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May direct an agent to submit ComfyUI workflow requests and manage generated media files when connected to a configured gateway.] <br>

## Skill Version(s): <br>
2.1.0 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
