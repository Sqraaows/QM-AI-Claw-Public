## Description: <br>
Generates Chinese web-novel cover prompts and uses GPT-Image-2 or a compatible image endpoint to save completed cover images with title and author text. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[worldwonderer](https://clawhub.ai/user/worldwonderer) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Authors, editors, and publishing teams use this skill to create Chinese web-novel cover concepts and final cover image files from a title, author name, target platform, genre, and optional reference image. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires GPT_IMAGE_API_KEY and sends book titles, author names, prompts, and optional reference images to the configured image-generation endpoint. <br>
Mitigation: Use an API key and endpoint approved for the content being processed, and avoid sending confidential book details or reference images unless that external processing is acceptable. <br>
Risk: The skill writes generated cover files under BOOK_DIR and may fetch an optional REF_IMAGE URL before image editing. <br>
Mitigation: Set BOOK_DIR to a directory you control, review the resolved output path before execution, and use only trusted local files or URLs for REF_IMAGE. <br>
Risk: Broad trigger phrases such as "封面设计" could start a cover-generation workflow when the user's intent is ambiguous. <br>
Mitigation: Confirm the book details, output directory, and generation intent before running API calls or saving files. <br>


## Reference(s): <br>
- [Cover style reference](references/cover-styles.md) <br>
- [Story Cover on ClawHub](https://clawhub.ai/worldwonderer/story-cover) <br>
- [OpenClaw source metadata](https://github.com/worldwonderer/oh-story-claudecode) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, files, guidance] <br>
**Output Format:** [Markdown guidance with bash commands, generated PNG files, and prompt/reference sidecar text files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires GPT_IMAGE_API_KEY, curl, jq, base64, and BOOK_DIR; generated files are saved under BOOK_DIR/封面.] <br>

## Skill Version(s): <br>
1.1.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
