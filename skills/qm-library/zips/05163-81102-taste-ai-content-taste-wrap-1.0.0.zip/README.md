# taste-skill-wrap

> **AI 品味提升技能封装** — 让 AI 告别平淡生成的 Shell 工具

[English](#english) | [中文](#中文)

---

## English

### What is this?

`taste-skill` is a suite of **anti-slop** skills for AI coding agents. It stops AI from generating the same boring, templated output every time — and instead produces frontend interfaces that actually look designed.

With **34,757 GitHub stars** and **6,044+ this week**, it's one of the most popular frontend quality tools for AI agents.

### Why it exists

LLMs have severe statistical defaults: centered heroes, three-equal-card rows, AI-purple gradients, Inter font, generic glassmorphism everywhere, and em-dashes as a design element. `taste-skill` overrides these defaults with concrete, testable rules.

### Available Skills

| Skill | Install Name | Description |
|---|---|---|
| **taste-skill** (v2) | `design-taste-frontend` | Anti-slop frontend default — landing pages, portfolios, redesigns |
| **taste-skill-v1** | `design-taste-frontend-v1` | Original v1, preserved for backward compatibility |
| **gpt-taste** | `gpt-taste` | Strict GPT/Codex variant — Awwwards-level, GSAP motion, Python randomization |
| **image-to-code-skill** | `image-to-code` | Image-first pipeline: generate → analyze → implement |
| **redesign-skill** | `redesign-existing-projects` | Existing projects: audit UI first, then fix |
| **soft-skill** | `high-end-visual-design` | Polished, call, advanced UI with softer contrast |
| **output-skill** | `full-output-enforcement` | Fixes half-finished output — no placeholder comments |
| **minimalist-skill** | `minimalist-ui` | Editorial product UI (Notice/Linear style), restrained palette |
| **brutalist-skill** | `industrial-brutalist-ui` | Hard mechanical language: Swiss type, sharp contrast |
| **stitch-skill** | `stitch-design` | Google Stitch-compatible rules, optional DESIGN.md export |
| **brandkit** | `brandkit` | Brand kit boards: logo, palette, type, identity |
| **imagegen-frontend-web** | `imagegen-frontend-web` | Website composition: hero, landing, multi-section |
| **imagegen-frontend-mobile** | `imagegen-frontend-mobile` | Mobile screens: iOS/Android, cross-platform, readable type |
| **imagegen-brandkit** | `brandkit` | Brand kit board generation |

### Installation

```bash
# Install all skills (npm skills add)
npm skills add https://github.com/Leonxlnx/taste-skill

# Install a single skill by install name
npm skills add https://github.com/Leonxlnx/taste-skill --skill "design-taste-frontend"

# Or copy SKILL.md directly into your project / ChatGPT / Codex conversation
```

### The Three Dials (Core Configuration)

Every skill is controlled by three dials that gate all layout, motion, and density decisions:

| Dial | Range | Description |
|---|---|---|
| `DESIGN_VARIANCE` | 1–10 | Layout asymmetry (1=symmetrical, 10=artsyst) |
| `MOTION_INTENSITY` | 1–10 | Animation depth (1=static, 10=cinematic) |
| `VISUAL_DENSITY` | 1–10 | Information per viewport (1=airy, 10=packed) |

### Key Rules

- **Zero em-dashes** — the #1 AI tell, completely banned
- **No Inter as default** — use Geist, Outfit, Cabinet Grotesk, Satoshi
- **No AI purple gradients** — neutral bases with high-contrast singular accents
- **No centered hero bias** — force split-screen, asymmetric white-space
- **No three-equal-card rows** — use 2-column, bento, or scroll-pinned alternatives
- **Real images required** — no div-based fake screenshots
- **Hero fits in viewport** — max 2 lines, subtext ≤20 words, CTAs visible without scroll
- **Max 1 eyebrow per 3 sections** — eyebrows over every section = templated rhythm
- **One accent color per page** — lock it, use it consistently
- **Pre-flight check** — 50+ item checklist before every output

### Research Background

The skills are backed by published research in `research/`:
- Root causes of AI slop (cognitive shortcuts, RLHF bias, output limits)
- Empirical results on what makes AI output look "designed"
- Architectural patterns, parameter tuning, and prompt engineering remediation

### License

MIT License — Copyright © 2026 Leonxlnx

---

## 中文

### 这是什么？

`taste-skill` 是一套 **AI 反平淡生成** 技能包。它让 AI 不再每次都输出千篇一律的模板化界面，而是真正有设计感的作品。

GitHub **34,757 颗星**，本周 **+6,044**，是最受欢迎的 AI 前端质量工具之一。

### 核心问题

大语言模型有严重的统计默认值：居中英雄区、三等分卡片行、AI 紫色渐变、Inter 字体、通篇玻璃拟物化、用 em-dash 做设计元素。`taste-skill` 用可测试的规则覆盖这些默认值。

### 三大旋钮

每个技能通过三个旋钮控制所有布局、动效和密度决策：

| 旋钮 | 范围 | 说明 |
|---|---|---|
| `DESIGN_VARIANCE` | 1–10 | 布局不对称性（1=对称，10=艺术化） |
| `MOTION_INTENSITY` | 1–10 | 动画深度（1=静止，10=电影级） |
| `VISUAL_DENSITY` | 1–10 | 单位视口信息量（1=透气，10=紧凑） |

### 核心规则

- **禁用 em-dash** — AI 标志性特征，零容忍
- **默认不用 Inter** — 用 Geist、Outfit、Cabinet Grotesk、Satoshi
- **禁止 AI 紫色渐变** — 中性底色 + 高对比单色点缀
- **打破居中英雄区惯性** — 强制分屏、不对称留白
- **禁止三等分卡片行** — 用双栏、 Bento 网格、或滚动固定替代
- **必须用真实图片** — 禁止 div 堆出来的假截图
- **英雄区必须塞进首屏** — 标题最多 2 行，副文本 ≤20 词，CTA 首屏可见
- **每 3 个区块最多 1 个眉标** — 每个区块都加眉标 = 模板化节奏
- **整页单一强调色** — 选定后锁定，全页一致使用
- **输出前强制预检** — 每次输出前执行 50+ 项检查清单

### 技能速查

| 技能 | 安装名 | 适用场景 |
|---|---|---|
| `taste-skill` v2 | `design-taste-frontend` | 默认反平淡 — 着陆页、作品集、改版 |
| `taste-skill-v1` | `design-taste-frontend-v1` | 原始 v1，保留兼容性 |
| `gpt-taste` | `gpt-taste` | 严格版 — Awwwards 级、GSAP 动效、Python 随机化 |
| `image-to-code` | `image-to-code` | 图生码流程：生成 → 分析 → 实现 |
| `redesign-skill` | `redesign-existing-projects` | 改版项目：先审核 UI，再修复 |
| `soft-skill` | `high-end-visual-design` | 柔和对比度的高端视觉设计 |
| `output-skill` | `full-output-enforcement` | 修复半成品输出，禁止占位注释 |
| `minimalist-skill` | `minimalist-ui` | 编辑类产品 UI（Notice/Linear 风格） |
| `brutalist-skill` | `industrial-brutalist-ui` | 硬核机械风：瑞士版面、锐利对比 |
| `stitch-skill` | `stitch-design` | Google Stitch 兼容，可选导出 DESIGN.md |
| `brandkit` | `brandkit` | 品牌工具包：Logo、色板、字体、身份 |
| `imagegen-frontend-web` | `imagegen-frontend-web` | 网站构图：英雄区、着陆页、多区块 |
| `imagegen-frontend-mobile` | `imagegen-frontend-mobile` | 移动端：iOS/Android，字号可读 |

### 安装方式

```bash
# 安装全部技能
npm skills add https://github.com/Leonxlnx/taste-skill

# 按安装名安装单个技能
npm skills add https://github.com/Leonxlnx/taste-skill --skill "design-taste-frontend"

# 或将 SKILL.md 直接复制到项目 / ChatGPT / Codex 对话中
```

### 研究支撑

技能基于 `research/` 中的已发布研究：
- AI 平庸输出的根本原因（认知捷径、RLHF 偏差、输出限制）
- 什么让 AI 输出看起来"有设计感"的经验结果
- 架构模式、参数调优、提示词工程修复方案

### 许可证

MIT License — Copyright © 2026 Leonxlnx