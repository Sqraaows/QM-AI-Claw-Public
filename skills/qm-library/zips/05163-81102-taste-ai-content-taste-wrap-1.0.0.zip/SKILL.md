---
name: Taste 美食 AI 推荐助手
slug: taste-skill-wrap
description: Taste 美食 AI 推荐助手 — 基于用户口味偏好和饮食限制，智能推荐食谱和餐饮选择的 AI 工具。支持根据现有食材生成菜谱、分析营养成分、推荐搭配方案等功能。适用于希望提升烹饪效率、均衡饮食的用户群体，提供中西方多种菜系选择。 | 来源：https://github.com/q15004040209-creator/taste-skill-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/taste-skill-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
