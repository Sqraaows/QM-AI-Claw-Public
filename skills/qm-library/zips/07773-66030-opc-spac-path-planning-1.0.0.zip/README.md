# SPAC资本路径规划

## 简介

这是「胡田-OPC导师-股权合作机制」的**姊妹篇**： | 维度 | 姊妹Skill（OPC股权合作机制） | 本Skill（SPAC资本路径规划） | |------|-----------------------------|-----------------------------|

## 定价信息

| 属性 | 值 |
|------|-----|
| 等级 | 专业级 |
| 价格 | ¥8 |
| 分类 | 专业-中度 |
| 文件数 | 11 |
| 大小 | 125.6 KB |

## 文件结构

```
.opcskill-004/
├── SKILL.md       # 核心配置文件
├── references/    # 参考资料
```

## 使用方法

### 在Coze平台使用

1. 登录 [Coze平台](https://coze.cn)
2. 导入 `SKILL.md` 文件
3. 根据需要配置相关参数
4. 开始使用

### 本地部署

```bash
# 克隆仓库
git clone https://github.com/OPC-Skills/opcskill-004.git
cd opcskill-004

# 查看SKILL.md了解使用方式
cat SKILL.md
```

## OPC生态

本Skill是OPC（One Person Company）导师技能体系的一部分。

OPC导师生态是一个专注于个人创业者的赋能平台，通过专业化、模块化的技能体系，帮助创业者快速构建商业能力。如需了解更多，请访问 [OPC平台](https://opc.cn)。

## License

MIT License

---
*本仓库由OPC导师技能体系自动生成*
