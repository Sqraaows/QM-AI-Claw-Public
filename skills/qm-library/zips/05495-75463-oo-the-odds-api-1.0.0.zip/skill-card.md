## Description: <br>
The Odds API skill helps agents retrieve supported sports, live and upcoming events, participants, market keys, odds, event-specific odds, and scores through OOMOL's The Odds API connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to search and read sports data from The Odds API without handling raw API tokens locally. It supports read-focused workflows for sports discovery, event lookup, odds comparison, participant lookup, market discovery, and score retrieval. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill relies on a connected OOMOL account and The Odds API credentials, which may expose account access or quota consumption if used without trust review. <br>
Mitigation: Confirm the user trusts OOMOL and the The Odds API connection flow before installation or execution, and use the connected account only for intended read workflows. <br>
Risk: Connector calls may consume The Odds API quota or OOMOL credits. <br>
Mitigation: Inspect action schemas first, run only the necessary read action, and stop on billing or insufficient-credit errors until the user decides to recharge or retry. <br>
Risk: Installing the oo CLI through a remote installer changes the local environment. <br>
Mitigation: Run the remote CLI installer only when the oo CLI is missing and the user intentionally wants it installed. <br>


## Reference(s): <br>
- [The Odds API homepage](https://the-odds-api.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-the-odds-api) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses include connector data and meta.executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and artifact frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
