## Description: <br>
Loomio helps agents search and read Loomio poll data through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and teams use this skill to retrieve Loomio poll information from a connected Loomio account, including listing polls in a group and getting a poll by ID or key. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill reads Loomio poll data available to the connected account through an OOMOL-brokered connection. <br>
Mitigation: Install and use it only when OOMOL is trusted to broker the Loomio connection and the connected account has appropriate access. <br>
Risk: First-time setup may require running an OOMOL CLI installer as local code. <br>
Mitigation: Review OOMOL's official install instructions before running the curl or PowerShell installer. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Loomio skill](https://clawhub.ai/oomol/oo-loomio) <br>
- [Loomio homepage](https://www.loomio.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [get_poll action reference](actions/get_poll.md) <br>
- [list_polls action reference](actions/list_polls.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON connector responses.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only Loomio poll access; requires a signed-in OOMOL account with Loomio connected.] <br>

## Skill Version(s): <br>
1.0.0 (source: server-resolved release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
