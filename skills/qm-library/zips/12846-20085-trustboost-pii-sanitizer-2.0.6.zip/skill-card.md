## Description: <br>
TrustBoost PII Sanitizer sends text to the TrustBoost API to detect and redact PII before LLM use, returning sanitized text plus safety and risk signals across documented context modes and languages. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[teodorofodocrispin-cmyk](https://clawhub.ai/user/teodorofodocrispin-cmyk) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and AI agent builders use this skill to sanitize prompts, documents, or agent text before sending content to LLMs, with context modes for general, legal, financial, medical, and code-oriented redaction. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Raw sensitive text may be sent to TrustBoost's remote service before redaction. <br>
Mitigation: Use only when policy allows remote processing, and confirm retention, logging, processing location, subprocessors, and consent requirements before using customer data, regulated records, secrets, or autonomous workflows. <br>
Risk: Paid sanitizations may create Solana-based proof records whose contents and linkability are not fully described in the evidence. <br>
Mitigation: Confirm exactly what is written on chain before production use, and avoid submitting workflows where immutable metadata could create privacy or compliance exposure. <br>


## Reference(s): <br>
- [ClawHub Skill Listing](https://clawhub.ai/teodorofodocrispin-cmyk/trustboost-pii-sanitizer) <br>
- [TrustBoost Sanitize API](https://api.trustboost.dev/sanitize) <br>
- [TrustBoost Preview Endpoint](https://api.trustboost.dev/sanitize/preview) <br>
- [TrustBoost MCP Endpoint](https://api.trustboost.dev/mcp) <br>
- [TrustBoost Agent Card](https://api.trustboost.dev/.well-known/agent-card.json) <br>
- [TrustBoost llms.txt](https://api.trustboost.dev/llms.txt) <br>
- [TrustBoost Verification Endpoint](https://api.trustboost.dev/verify/{anchor_tx}) <br>
- [TrustBoost OpenAPI Specification](https://api.trustboost.dev/openapi.json) <br>


## Skill Output: <br>
**Output Type(s):** [Text, JSON, API Calls, Shell commands, Configuration] <br>
**Output Format:** [JSON API responses with sanitized text, safety score, risk category, context metadata, and Markdown usage examples.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires internet access to TrustBoost endpoints; trial and paid usage may use wallet address and transaction hash fields for quota or payment tracking.] <br>

## Skill Version(s): <br>
2.0.6 (source: server release metadata; artifact frontmatter reports 2.6.0) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
