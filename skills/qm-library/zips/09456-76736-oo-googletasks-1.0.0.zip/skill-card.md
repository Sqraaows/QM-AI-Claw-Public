## Description: <br>
Operate Google Tasks through an OOMOL-connected account for reading, creating, updating, moving, and deleting tasks and task lists. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to manage Google Tasks task lists and tasks through the OOMOL Google Tasks connector. It supports listing and fetching task data as well as creating, moving, updating, clearing, and deleting tasks or task lists. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, move, delete, or clear Google Tasks data. <br>
Mitigation: Confirm exact task list IDs, task IDs, payloads, and destructive targets before approving write, clear, or delete actions. <br>
Risk: The skill depends on an OOMOL Google Tasks connection with access to user task data. <br>
Mitigation: Install only when Google Tasks management is intended, review task content before execution, and disconnect the OOMOL Google Tasks connection when it is no longer needed. <br>


## Reference(s): <br>
- [Google Tasks](https://tasks.google.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-googletasks) <br>
- [OOMOL Publisher Profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown action guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON through the oo connector run workflow when executed.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
