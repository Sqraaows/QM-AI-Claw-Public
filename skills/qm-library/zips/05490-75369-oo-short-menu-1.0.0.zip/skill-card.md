## Description: <br>
Short Menu (shortmenu.com). Use this skill for Short Menu requests that read, create, update, or delete Short Menu data through the OOMOL `oo` CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Short Menu links from an OOMOL-connected account. It supports creating, updating, and deleting short links after inspecting the live connector schema. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, or delete Short Menu account data. <br>
Mitigation: Confirm the exact payload, intended effect, and target link with the user before running write or delete actions. <br>
Risk: The security summary notes broad trigger language and pipe-to-shell installer guidance. <br>
Mitigation: Use the skill only with a trusted OOMOL `oo` CLI installation and prefer documented, verifiable install steps over running remote scripts directly. <br>


## Reference(s): <br>
- [Short Menu homepage](https://shortmenu.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Short Menu ClawHub page](https://clawhub.ai/oomol/oo-short-menu) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, Guidance, JSON] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing payloads; write and delete actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
