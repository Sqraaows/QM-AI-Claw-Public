## Description: <br>
Provides a six-phase, hypothesis-driven runtime debugging workflow that helps agents instrument code, reproduce failures, confirm root causes, apply minimal fixes, and remove diagnostic code afterward. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[zelixag](https://clawhub.ai/user/zelixag) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineering agents use Debug Probe to investigate bugs or unexpected behavior when static code reading is insufficient, using a structured loop of hypotheses, precise diagnostic logging, reproduction, evidence review, fix, and cleanup. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The workflow can add temporary source-code instrumentation and diagnostic dump hooks while debugging. <br>
Mitigation: Require operator confirmation before adding instrumentation or deploying instrumented code, keep changes on a clean branch, and remove all DIAG-marked code and dump hooks after verification. <br>
Risk: Diagnostic logs can expose secrets, personal data, tokens, or sensitive application state if broad values are logged. <br>
Mitigation: Log only narrow key=value signals needed to test a hypothesis, avoid secrets or personal data, and inspect any exported logs before sharing them. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/zelixag/debug-probe) <br>
- [Debug Probe README](artifact/README.md) <br>
- [Diagnostic Buffer Templates](artifact/TEMPLATES.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with hypotheses, diagnostic code snippets, build or reproduction commands, log interpretation, and cleanup instructions.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May temporarily add diagnostic buffer files or DIAG-marked instrumentation during debugging; the workflow requires removing that instrumentation after verification.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
