---
name: "headless"
description: "Claude Code headless mode for SOLO to execute programming tasks via CLI. Invoke when SOLO needs to call Claude Code programmatically for code generation, bug fixes, refactoring, code review, or CI/CD automation."
---

# Claude Code Headless Mode

Non-interactive execution via `-p` / `--print`. For CI/CD, agent orchestration, and automation.

## Quick Start

```bash
# Minimal
claude -p "list files" --print

# Production-ready
claude -p "fix type errors in src/app.ts" \
  --print \
  --output-format json \
  --allowedTools "Read,Edit,Write,Glob,Grep,Bash" \
  --permission-mode dontAsk \
  --model sonnet \
  --no-session-persistence
```

## Core Parameters

### Essential

| Param | Description | Example |
|-------|-------------|---------|
| `-p, --print` | Non-interactive mode, output result and exit | `-p "fix bug"` |
| `--output-format` | `text` (default), `json`, `stream-json` | `--output-format json` |
| `--input-format` | `text` (default), `stream-json` | `--input-format stream-json` |
| `-r, --resume [id]` | Resume session by ID (no ID = interactive picker) | `--resume abc-123` |
| `--session-id <uuid>` | Specify session ID | `--session-id $(uuidgen)` |
| `-c, --continue` | Continue most recent session in cwd | `-c` |

### Permissions & Security

| Param | Description | Example |
|-------|-------------|---------|
| `--allowedTools` | Allowed tools (comma/space separated) | `"Read,Edit,Bash(git *)"` |
| `--disallowedTools` | Blocked tools | `"Bash(rm *)"` |
| `--permission-mode` | `default`, `acceptEdits`, `dontAsk`, `auto`, `plan`, `bypassPermissions` | `dontAsk` |
| `--dangerously-skip-permissions` | Skip all permission checks (sandbox only) | — |
| `--add-dir` | Extra directories for tool access | `/path/to/project` |

### Model & Cost

| Param | Description | Example |
|-------|-------------|---------|
| `--model` | `sonnet`, `opus`, `haiku`, or full model ID | `--model opus` |
| `--effort` | `low`, `medium`, `high`, `xhigh`, `max` | `--effort low` |
| `--max-budget-usd` | Max API cost (print mode only) | `--max-budget-usd 0.5` |
| `--fallback-model` | Auto-fallback on overload (print mode only) | `--fallback-model haiku` |

### Session & Prompt

| Param | Description |
|-------|-------------|
| `--no-session-persistence` | Don't save session to disk |
| `--system-prompt` | Custom system prompt |
| `--append-system-prompt` | Append to default system prompt |
| `--name` | Session display name |
| `--bare` | Minimal mode: skip hooks, LSP, plugins, auto-memory, CLAUDE.md auto-discovery |

### Advanced

| Param | Description |
|-------|-------------|
| `--agents <json>` | Define custom agents |
| `--agent <name>` | Use specified agent |
| `--json-schema` | Structured output JSON Schema |
| `--mcp-config` | Load MCP servers from JSON file/string |
| `--strict-mcp-config` | Only use MCP servers from `--mcp-config` |
| `--plugin-dir` / `--plugin-url` | Load plugins from dir/URL |
| `--tools` | Built-in tool set (`""`=none, `"default"`=all, or list) |
| `--debug [filter]` | Debug mode with optional filter |
| `--settings` | Extra settings file or JSON |
| `--exclude-dynamic-system-prompt-sections` | Move dynamic info to first user message for cache reuse |

## Output Formats

### text (default)

```bash
claude -p "list files" --print
# Plain text output
```

### json

```bash
claude -p "create calculator.py" --print --output-format json
```

Key fields in response:
```json
{
  "type": "result",
  "subtype": "success",
  "is_error": false,
  "duration_ms": 10181,
  "num_turns": 3,
  "result": "...",
  "session_id": "uuid",
  "total_cost_usd": 0.117,
  "usage": { "input_tokens": 15530, "output_tokens": 941, "cache_read_input_tokens": 32000 }
}
```

### stream-json

Real-time streaming events: `message_start`, `content_block_delta`, `tool_use_start`, `tool_use_end`, `permission_request`, `error`, `signal`.

## --allowedTools Format

```
ToolName                   # All operations
ToolName(pattern)          # Prefix match
```

Examples:
```bash
--allowedTools "Read"                           # All reads
--allowedTools "Bash(git *)"                    # git commands
--allowedTools "Bash(npm run test)"             # Exact match
--allowedTools "Edit(.claude/settings.json)"    # Specific file
--allowedTools "Read,Edit,Write,Bash(git *),Bash(npm *)"
```

Built-in tools: `Read`, `Write`, `Edit`, `Glob`, `Grep`, `Bash`, `WebFetch`, `WebSearch`, `PowerShell`, `Agent`, `NotebookEdit`, `TaskCreate/Update/Get`

## Multi-turn Sessions

```bash
# Turn 1: analyze
claude -p "analyze src/ structure" --print --output-format json --session-id "task-001"

# Turn 2: fix (resume)
claude -r "task-001" -p "fix all TypeScript errors" --print --output-format json
```

## Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | General error |
| `2` | Auth failure |
| `124` | Timeout |

## Common Errors

| Error | Fix |
|-------|-----|
| 401 / Auth failed | Check `ANTHROPIC_API_KEY` or run `claude login` |
| Cost limit exceeded | Increase `--max-budget-usd` or use `--model haiku` |
| Token limit exceeded | Shorten prompt, use CLAUDE.md, or split with `--resume` |
| Tool not allowed | Add tool to `--allowedTools` |
| Permission denied | Use `--permission-mode dontAsk` |
| Session not found | Check session ID; `--no-session-persistence` disables saving |
| Model overloaded | Add `--fallback-model haiku` |

## CI/CD (GitHub Actions)

```yaml
- uses: anthropics/claude-code-action@v1
  with:
    prompt: "Fix the issue described in the PR"
    allowed-tools: "Read,Edit,Write,Glob,Grep,Bash(git *)"
    permission-mode: dontAsk
    max-budget-usd: 1.0
```

## Programmatic Usage (Python)

```python
import subprocess, json

def claude(prompt, tools=None, model="sonnet", budget=1.0):
    cmd = ["claude", "-p", prompt, "--print", "--output-format", "json",
           "--permission-mode", "dontAsk", "--no-session-persistence",
           "--model", model, "--max-budget-usd", str(budget)]
    if tools:
        cmd += ["--allowedTools", ",".join(tools)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if r.returncode != 0:
        raise RuntimeError(f"Claude failed: {r.stderr}")
    return json.loads(r.stdout)
```

## References

- [Claude Code Overview](https://docs.anthropic.com/en/docs/claude-code/overview)
- [Settings Reference](https://docs.anthropic.com/en/docs/claude-code/settings)
- [Security Guide](https://docs.anthropic.com/en/docs/claude-code/security)
- [GitHub Action](https://github.com/anthropics/claude-code-action)
- [Headless Mode & CI/CD (SFEIR)](https://institute.sfeir.com/en/claude-code/claude-code-headless-mode-and-ci-cd/)
