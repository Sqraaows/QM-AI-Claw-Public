# Keygen · `delete_entitlement`

Delete an entitlement from the connected Keygen account.

- **Service**: `keygen`
- **Action**: `delete_entitlement`
- **Action id**: `keygen.delete_entitlement`

## Inspect the schema

Always fetch the authoritative input/output schema before building a payload — fields and defaults can change upstream:

```bash
oo connector schema "keygen" --action "delete_entitlement"
```

## Run

```bash
oo connector run "keygen" --action "delete_entitlement" --data '{}' --json
```

Replace `{}` with a JSON object that matches the input schema. The response is `{ "data": ..., "meta": { "executionId": "..." } }`.

> **Destructive action.** This removes or overwrites Keygen data. Always confirm the target and get explicit user approval before running.
