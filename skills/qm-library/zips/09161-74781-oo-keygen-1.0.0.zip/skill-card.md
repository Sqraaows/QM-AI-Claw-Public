## Description: <br>
Keygen (keygen.sh) skill for reading, creating, updating, and deleting Keygen account data through the OOMOL Keygen connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operations teams, and agents use this skill to administer Keygen products, policies, licenses, users, groups, machines, components, processes, and entitlements from a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can make real changes to a Keygen account, including write, delete, ban, suspend, revoke, ownership, entitlement, and usage-change actions. <br>
Mitigation: Install only for trusted agents, confirm the target and payload before account-changing actions, and get explicit approval before destructive actions. <br>
Risk: The skill requires sensitive Keygen credentials or connected-account access. <br>
Mitigation: Avoid connecting credentials with broader permissions than needed and keep the skill limited to agents trusted to administer the account. <br>
Risk: Action input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema before constructing a payload. <br>


## Reference(s): <br>
- [Keygen homepage](https://keygen.sh) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-keygen) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands call the Keygen connector through the oo CLI and return JSON responses with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
