## Description: <br>
Firecrawl helps agents scrape, crawl, search, map, and extract structured data from websites through an OOMOL-connected Firecrawl account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to operate Firecrawl through the oo CLI for website scraping, crawling, search, URL discovery, structured extraction, usage checks, and asynchronous job management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill operates Firecrawl through an OOMOL-connected account and requires sensitive credentials to be connected before use. <br>
Mitigation: Install it only when the agent should operate Firecrawl, and keep account connection and credential management within OOMOL. <br>
Risk: Crawls, batch scrapes, extraction, agents, cancellations, and delete-compatible actions can affect Firecrawl jobs and consume account credits. <br>
Mitigation: Review the target, payload, and expected effect before running state-changing actions, and require explicit approval for destructive or cancel/delete-compatible actions. <br>
Risk: Upstream Firecrawl action schemas and defaults can change. <br>
Mitigation: Inspect the live connector schema before constructing payloads and validate returned data before relying on it. <br>


## Reference(s): <br>
- [ClawHub Firecrawl Skill](https://clawhub.ai/oomol/oo-firecrawl) <br>
- [Firecrawl Homepage](https://www.firecrawl.dev) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
