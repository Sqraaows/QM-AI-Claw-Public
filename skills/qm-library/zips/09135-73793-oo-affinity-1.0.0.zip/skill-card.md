## Description: <br>
Affinity lets agents read Affinity CRM data through an OOMOL-connected account using the oo CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees and developers use this skill to retrieve Affinity CRM records, field metadata, lists, saved views, opportunities, companies, and people through an authenticated OOMOL connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through the user's OOMOL account. <br>
Mitigation: Install only when the agent should read Affinity CRM data, and review the oo CLI sign-in and Affinity connection steps before use. <br>
Risk: The skill has broad routing language for Affinity requests. <br>
Mitigation: Use the packaged get and list actions for read workflows, and require separate documented actions plus explicit approval before any write or delete workflow. <br>
Risk: Connector schemas and upstream fields can change. <br>
Mitigation: Fetch the live action schema with oo connector schema before constructing each payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-affinity) <br>
- [Affinity homepage](https://www.affinity.co) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [OOMOL Affinity connection](https://console.oomol.com/app-connections?provider=affinity) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Read-only get and list workflows use live connector schemas before execution.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server-resolved release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
