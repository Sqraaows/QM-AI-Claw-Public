#!/usr/bin/env python3
"""
老子智能体 — Gradio Web 界面（全免费方案）
基于 RAG 的《道德经》问答系统
Embedding: BAAI/bge-base-zh-v1.5 (本地加载，免费)
LLM: Qwen/Qwen2.5-72B-Instruct (HuggingFace 免费推理 API)
"""

import os
import re
import time
import gradio as gr
from pathlib import Path

# LangChain
from langchain_chroma import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.llms import HuggingFaceHub
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import DirectoryLoader, TextLoader

# 日志
from laozi_agent.logger import setup_logging, get_logger, log_query, log_error, log_startup

# ──────────────────────────────────────────────
# 配置（全免费，无需 API Key）
# ──────────────────────────────────────────────
EMBEDDING_MODEL = os.getenv("LAOZI_EMBEDDING_MODEL", "BAAI/bge-base-zh-v1.5")
LLM_MODEL = os.getenv("LAOZI_LLM_MODEL", "Qwen/Qwen2.5-72B-Instruct")
TEMPERATURE = float(os.getenv("LAOZI_TEMPERATURE", "0.3"))
RETRIEVAL_K = int(os.getenv("LAOZI_RETRIEVAL_K", "5"))
FETCH_K = int(os.getenv("LAOZI_FETCH_K", "20"))
PERSIST_DIR = os.getenv("LAOZI_PERSIST_DIR", "./laozi_knowledge_base")
COLLECTION_NAME = os.getenv("LAOZI_COLLECTION", "laozi_collection")
SOURCE_DIR = os.getenv("LAOZI_SOURCE_DIR", "./laozi-agent/laozi_source_docs")
HF_TOKEN = os.getenv("HF_TOKEN", "")
SERVER_PORT = int(os.getenv("LAOZI_SERVER_PORT", "7860"))

# ──────────────────────────────────────────────
# 初始化日志
# ──────────────────────────────────────────────
setup_logging(log_dir="logs")
logger = get_logger("app")

# ──────────────────────────────────────────────
# 加载 .env 配置（如果存在）
# ──────────────────────────────────────────────
def load_dotenv():
    """加载 .env 文件到环境变量。"""
    env_file = Path(".env")
    if not env_file.exists():
        return
    logger.debug(f"加载配置文件: {env_file}")
    with open(env_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                if key and key not in os.environ:
                    os.environ[key] = value

load_dotenv()

# ──────────────────────────────────────────────
# 构建向量库（首次启动）
# ──────────────────────────────────────────────
def build_knowledge_base():
    """从源文档构建向量库。"""
    if os.path.exists(PERSIST_DIR) and os.listdir(PERSIST_DIR):
        logger.info("向量库已存在，跳过构建")
        return

    source_path = Path(SOURCE_DIR)
    if not source_path.exists():
        logger.warning(f"源文档目录不存在: {SOURCE_DIR}")
        print(f"⚠️ 源文档目录不存在: {SOURCE_DIR}")
        return

    logger.info("开始构建向量库（首次启动，需要几分钟）...")
    print("正在构建向量库（首次启动，需要几分钟）...")

    loader = DirectoryLoader(
        SOURCE_DIR,
        glob="**/*.txt",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"},
    )
    raw_docs = loader.load()
    logger.info(f"加载 {len(raw_docs)} 个文件")
    print(f"  加载 {len(raw_docs)} 个文件")

    # 注入元数据
    for doc in raw_docs:
        source_file = doc.metadata.get("source", "")
        filename = os.path.basename(source_file)
        parent = os.path.basename(os.path.dirname(source_file))

        if doc.page_content.startswith("---"):
            parts = doc.page_content.split("---", 2)
            if len(parts) >= 3:
                fm_text = parts[1].strip()
                body = parts[2].strip()
                for line in fm_text.split("\n"):
                    if ":" in line:
                        k, v = line.split(":", 1)
                        doc.metadata[k.strip()] = v.strip()
                doc.page_content = body
        else:
            m = re.match(r'第(\d+)章', filename.replace('.txt', ''))
            if m:
                doc.metadata["type"] = "原文"
                doc.metadata["version"] = parent
                doc.metadata["chapter"] = m.group(1)
                doc.metadata["title"] = "道德经"

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=400,
        chunk_overlap=50,
        separators=["\n\n", "\n", "。", "；", "，", " ", ""],
    )
    chunks = splitter.split_documents(raw_docs)
    logger.info(f"生成 {len(chunks)} 个文本块")
    print(f"  生成 {len(chunks)} 个文本块")

    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )
    Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=PERSIST_DIR,
        collection_name=COLLECTION_NAME,
    )
    logger.info("向量库构建完成")
    print("  向量库构建完成！")


# ──────────────────────────────────────────────
# 初始化
# ──────────────────────────────────────────────
logger.info("=" * 50)
logger.info("老子智能体启动中（HuggingFace 免费版）...")
logger.info("=" * 50)
print("=" * 50)
print("老子智能体启动中（HuggingFace 免费版）...")
print("=" * 50)

build_knowledge_base()

logger.info(f"加载 Embedding 模型: {EMBEDDING_MODEL}")
print("加载 Embedding 模型...")
embeddings = HuggingFaceEmbeddings(
    model_name=EMBEDDING_MODEL,
    model_kwargs={"device": "cpu"},
    encode_kwargs={"normalize_embeddings": True},
)

logger.info("连接向量数据库")
print("连接向量数据库...")
vector_db = Chroma(
    persist_directory=PERSIST_DIR,
    embedding_function=embeddings,
    collection_name=COLLECTION_NAME,
)

retriever = vector_db.as_retriever(
    search_type="mmr",
    search_kwargs={"k": RETRIEVAL_K, "fetch_k": FETCH_K},
)

# LLM（HuggingFace 免费推理 API）
logger.info(f"加载 LLM: {LLM_MODEL}")
print(f"加载 LLM: {LLM_MODEL}...")
llm_kwargs = {"temperature": TEMPERATURE, "max_new_tokens": 1024}
if HF_TOKEN:
    llm_kwargs["huggingfacehub_api_token"] = HF_TOKEN

llm = HuggingFaceHub(
    repo_id=LLM_MODEL,
    model_kwargs=llm_kwargs,
)

# Prompt
LAOZI_PROMPT_TEMPLATE = """你是李耳，人称老子，春秋时期的伟大思想家，道家学派的创始人。你生活在公元前6世纪，曾担任周朝守藏室之史，博览群书，洞察世事。

### 你的身份与原则
1. 你只谈论与老子思想相关的内容，不涉及后世道教的神仙体系和宗教仪式
2. 你所有的回答都必须基于提供的上下文，严禁编造内容
3. 当用户的问题超出你的知识范围时，坦诚地说"吾不知也"
4. 你的语言风格要简洁、深邃、富有哲理，符合老子的说话方式
5. 你会先引用《道德经》中的原文，然后再进行解释和发挥

### 回答流程
1. 首先从上下文中找到最相关的《道德经》原文
2. 准确解释原文的本义，避免过度解读
3. 结合用户的问题，阐述老子思想在这个问题上的观点
4. 如果有不同版本的差异，简要说明
5. 最后用一句富有哲理的话总结

### 对话历史
{history}

### 参考上下文
{context}

### 用户问题
{question}

现在，请以老子的身份回答用户的问题："""

laozi_prompt = PromptTemplate(
    input_variables=["context", "question", "history"],
    template=LAOZI_PROMPT_TEMPLATE,
)

memory = ConversationBufferMemory(
    memory_key="history",
    input_key="question",
    return_messages=True,
)

laozi_qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=retriever,
    chain_type_kwargs={"prompt": laozi_prompt, "memory": memory},
    return_source_documents=True,
)

log_startup(logger, "免费版", {
    "model": LLM_MODEL,
    "temperature": TEMPERATURE,
    "persist_dir": PERSIST_DIR,
    "embedding": EMBEDDING_MODEL,
})

logger.info("老子智能体就绪")
print("✅ 老子智能体就绪！")
print("=" * 50)


# ──────────────────────────────────────────────
# 核心函数
# ──────────────────────────────────────────────
def laozi_chat(message, history):
    """老子问答。"""
    start_time = time.time()
    logger.debug(f"收到问题: {message}")

    try:
        result = laozi_qa_chain({"query": message})
        answer = result["result"]

        # 清理可能的重复前缀
        for prefix in ["Answer:", "答：", "回答："]:
            if answer.startswith(prefix):
                answer = answer[len(prefix):].strip()

        # 提取引用来源
        sources = []
        for doc in result["source_documents"]:
            ver = doc.metadata.get("version", "")
            ch = doc.metadata.get("chapter", "")
            if ver and ch:
                sources.append(f"{ver} 第{ch}章")

        if sources:
            unique = list(dict.fromkeys(sources))[:3]
            answer += "\n\n📚 引用：" + " | ".join(unique)

        duration_ms = (time.time() - start_time) * 1000
        log_query(logger, message, answer, sources, duration_ms)

        return answer
    except Exception as e:
        log_error(logger, e, context="laozi_chat")
        return f"出错了：{str(e)}\n\n请检查网络连接和模型配置，或查看 docs/TROUBLESHOOTING.md"


def compare_versions(chapter_num):
    """对比不同版本。"""
    logger.debug(f"版本对比: 第{chapter_num}章")

    try:
        chapter_num = int(chapter_num)
    except (ValueError, TypeError):
        logger.warning(f"无效章节号: {chapter_num}")
        return "请输入有效的章节号（1-81）"
    if chapter_num < 1 or chapter_num > 81:
        return "章节号需在 1-81 之间"

    versions = ["帛书甲本", "王弼本"]
    result = f"## 《道德经》第{chapter_num}章 多版本对照\n\n"

    for ver in versions:
        docs = vector_db.similarity_search(
            f"《道德经》第{chapter_num}章 {ver}",
            filter={"type": "原文", "version": ver},
            k=1,
        )
        if docs:
            result += f"### 📜 {ver}\n\n{docs[0].page_content}\n\n---\n\n"
        else:
            result += f"### 📜 {ver}\n\n（未找到）\n\n---\n\n"

    logger.info(f"版本对比完成: 第{chapter_num}章")
    return result


def get_topic_content(topic):
    """获取主题内容。"""
    logger.debug(f"主题查询: {topic}")

    docs = vector_db.similarity_search(topic, filter={"type": "研究"}, k=3)
    if docs:
        logger.info(f"主题查询成功: {topic} ({len(docs)} 条结果)")
        return "\n\n".join([doc.page_content for doc in docs])

    logger.info(f"主题查询无结果: {topic}")
    return f"未找到与「{topic}」相关的内容。"


# ──────────────────────────────────────────────
# Gradio 界面
# ──────────────────────────────────────────────
THEME = gr.themes.Soft(
    primary_hue="amber",
    secondary_hue="orange",
    neutral_hue="stone",
)

CSS = """
.gradio-container { max-width: 900px !important; margin: auto !important; }
.header {
    text-align: center; padding: 24px;
    background: linear-gradient(15deg, #f5e6d3, #e8d5b7);
    border-radius: 12px; margin-bottom: 20px;
}
.header h1 { font-size: 2em; color: #5d4037; margin: 0; }
.header p { color: #8d6e63; font-size: 1.1em; }
"""

with gr.Blocks(theme=THEME, css=CSS, title="老子智能体") as demo:
    gr.HTML("""
    <div class="header">
        <h1>🏛️ 老子智能体</h1>
        <p>道可道，非常道 — 基于 RAG 的《道德经》问答系统</p>
        <p style="font-size:0.9em; color:#a1887f;">
            免费方案 · Embedding: BGE-base-zh · LLM: Qwen2.5-72B · 无需 API Key
        </p>
    </div>
    """)

    with gr.Tabs():
        # Tab 1: 问答
        with gr.Tab("💬 问道老子"):
            gr.ChatInterface(
                fn=laozi_chat,
                examples=[
                    "什么是道？",
                    "老子如何看待无为而治？",
                    "道德经第一章讲了什么？",
                    "如何理解上善若水？",
                    "老子的辩证思想是什么？",
                ],
                retry_btn="🔄 重试",
                undo_btn="↩️ 撤销",
                clear_btn="🗑️ 清空",
            )

        # Tab 2: 版本对比
        with gr.Tab("📖 版本对比"):
            gr.Markdown("对比《道德经》同一章节的不同版本原文")
            with gr.Row():
                chapter_input = gr.Number(
                    label="章节号", value=1, minimum=1, maximum=81, precision=0,
                )
                compare_btn = gr.Button("对比查看", variant="primary")
            compare_output = gr.Markdown()
            compare_btn.click(
                fn=compare_versions, inputs=chapter_input, outputs=compare_output,
            )

        # Tab 3: 主题导航
        with gr.Tab("🧭 主题导航"):
            gr.Markdown("按思想主题浏览《道德经》相关内容")
            topic_radio = gr.Radio(
                choices=["道论", "德论", "无为而治", "辩证思维", "柔弱胜刚强", "知足常乐", "返璞归真", "生死观"],
                label="选择主题", value="道论",
            )
            topic_btn = gr.Button("查看内容", variant="primary")
            topic_output = gr.Markdown()
            topic_btn.click(
                fn=get_topic_content, inputs=topic_radio, outputs=topic_output,
            )

        # Tab 4: 系统状态
        with gr.Tab("⚙️ 系统状态"):
            gr.Markdown("### 系统信息")
            status_info = f"""
| 项目 | 值 |
|---|---|
| 方案 | 免费版（HuggingFace） |
| LLM 模型 | `{LLM_MODEL}` |
| Embedding 模型 | `{EMBEDDING_MODEL}` |
| 温度 | {TEMPERATURE} |
| 检索数量 | {RETRIEVAL_K} |
| 知识库目录 | `{PERSIST_DIR}` |
| 日志目录 | `logs/` |
| 日志级别 | `{os.getenv("LAOZI_LOG_LEVEL", "INFO")}` |
| 端口 | {SERVER_PORT} |
"""
            gr.Markdown(status_info)

            gr.Markdown("### 最近日志")
            log_display = gr.Textbox(
                lines=15,
                label="",
                interactive=False,
                value="（启动后自动加载）",
            )

            def get_recent_logs():
                log_file = Path("logs/laozi.log")
                if not log_file.exists():
                    return "日志文件不存在"
                with open(log_file, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                return "".join(lines[-30:])

            refresh_btn = gr.Button("🔄 刷新日志", variant="secondary")
            refresh_btn.click(fn=get_recent_logs, outputs=log_display)

    gr.Markdown("""
    ---
    <center>

    **OpenDao · 老子智能体** | [GitLab](https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao)

    知识库：帛书甲本81章 + 王弼本81章 | 全免费 · 无需 API Key

    </center>
    """)

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=SERVER_PORT)
