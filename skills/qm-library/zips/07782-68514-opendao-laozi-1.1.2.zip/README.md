# 老子智能体

基于 LangChain + Chroma 的 RAG 问答系统，以春秋时期思想家老子（李耳）的身份回答关于《道德经》和道家思想的问题。

## 功能

- **问道老子** — 以老子身份回答问题，引用《道德经》原文
- **多版本对比** — 对比同一章节的不同版本原文（帛书甲本、王弼本等）
- **主题导航** — 按思想主题浏览相关内容（道论、德论、无为而治等）
- **对话记忆** — 支持多轮对话，上下文连贯

## 两套方案

| | OpenAI 版 | 免费版 |
|---|---|---|
| 入口 | `scripts/laozi_agent.py` | `app.py` |
| 界面 | 命令行 | Gradio Web |
| Embedding | `text-embedding-3-large` | `BAAI/bge-base-zh-v1.5`（本地） |
| LLM | `gpt-4o` | `Qwen2.5-72B-Instruct` |
| 需要 API Key | ✅ `OPENAI_API_KEY` | ❌ 无需 |

## 一键配置（推荐）

```bash
python3 setup.py
```

交互式引导，自动完成：
- 选择方案（OpenAI 版 / 免费版）
- 配置 API Key
- 安装依赖
- 检查知识库
- 生成启动脚本

## 手动安装

```bash
pip install -r requirements.txt
```

## 启动

```bash
# 使用启动脚本（setup.py 自动生成）
bash start_free.sh      # 免费版
bash start_openai.sh    # OpenAI 版

# 或手动启动
# OpenAI 版（效果更好）
export OPENAI_API_KEY="sk-xxx"
python3 scripts/laozi_agent.py

# 免费版（Web 界面）
python3 app.py
# 浏览器打开 http://localhost:7860
```

## 配置

通过环境变量覆盖默认值：

| 环境变量 | 说明 | OpenAI 版默认 | 免费版默认 |
|---|---|---|---|
| `LAOZI_EMBEDDING_MODEL` | 向量模型 | `text-embedding-3-large` | `BAAI/bge-base-zh-v1.5` |
| `LAOZI_LLM_MODEL` | 生成模型 | `gpt-4o` | `Qwen/Qwen2.5-72B-Instruct` |
| `LAOZI_TEMPERATURE` | 温度 | `0.1` | `0.3` |
| `LAOZI_RETRIEVAL_K` | 返回文档数 | `5` | `5` |
| `LAOZI_FETCH_K` | MMR 候选池 | `20` | `20` |
| `LAOZI_PERSIST_DIR` | 向量库目录 | `./laozi_knowledge_base` | `./laozi_knowledge_base` |

## 知识库

- 目录：`./laozi_knowledge_base/`
- 集合名：`laozi_collection`
- 元数据：`type`、`version`、`chapter`、`topic`、`title`、`page`

## 准确性保障

- 低温度减少幻觉
- MMR 检索兼顾相关性与多样性
- 强制引用原文再解释
- 超出范围回答"吾不知也"
- 严禁编造无上下文支持的内容

## 文档

- 📖 [详细说明书](docs/USER_MANUAL.md) — 完整使用指南
- 🔧 [故障排查](docs/TROUBLESHOOTING.md) — 常见问题解决
- 📋 [API 文档](laozi-agent/docs/API.md) — 编程接口
- 📝 [版本日志](CHANGELOG.md) — 更新记录

## 注意事项

- 严格区分道家（哲学）与道教（宗教），不涉及神仙体系
- 坚持学术中立，避免过度解读
- 有争议问题说明不同学者观点
- 保持老子本人的谦逊态度
