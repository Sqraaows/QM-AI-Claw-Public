# 版本日志

## v1.1.1 (2026-05-25)

### 新增

- **一键配置脚本 `setup.py`** — 傻瓜式交互引导，支持两种方案选配
  - 环境自动检测（Python 版本、pip、Git、虚拟环境）
  - 方案一：OpenAI 版（效果更好，需要 API Key）
  - 方案二：免费版（无需 API Key，Web 界面）
  - 自动生成 `.env` 配置文件
  - 自动生成启动脚本 `start_free.sh` / `start_openai.sh`
  - 支持 `--auto`（自动模式）和 `--plan`（直接选方案）
- **系统日志模块 `laozi_agent/logger.py`** — 全链路日志记录
  - 控制台彩色输出（INFO 以上）
  - 文件日志自动轮转（10MB × 5 份）
  - 独立错误日志 `logs/error.log`
  - 结构化日志格式，按模块分 logger
  - 问答日志记录（问题、来源、耗时）
- **故障排查手册 `docs/TROUBLESHOOTING.md`** — 8 大类常见错误及解决方案
  - 安装与依赖、配置、知识库、模型与 API、Gradio 界面、性能与内存、日志与调试、错误码
- **详细说明书 `docs/USER_MANUAL.md`** — 14 章完整文档
  - 项目简介、系统要求、快速开始、功能详解、配置参数、知识库说明、日志系统、API 接口、部署指南、开发指南
- **Web 界面"系统状态"标签页** — 显示当前配置、模型信息、最近日志
- **`.env` 配置自动加载** — `app.py` 启动时自动读取 `.env` 文件

### 改进

- `app.py` 全面集成日志系统，问答/检索/错误全链路记录
- 错误信息更友好，附带故障排查文档链接
- 启动脚本自动配置环境变量并加载 `.env`

## v1.1.0 (2026-05-24)

### 修复

- **`scripts/laozi_agent.py` 模型配置与文档不一致** — 原代码实际使用 OpenAI 模型（`text-embedding-3-large` + `gpt-4o`），但 SKILL.md 描述的是"全免费方案"。现明确分为两个入口，各自文档独立
- **`requirements.txt` 缺失依赖** — 补充 `langchain-openai>=0.3.0`（OpenAI 版所需），并标注各依赖归属哪个版本
- **`app.py` 的 `compare_versions` filter 过于严格** — 原代码同时按 `type` + `version` + `chapter` 三个字段 filter，容易查不到结果。现改为只 filter `type` + `version`，与 `scripts/laozi_agent.py` 保持一致
- **`compare_versions` 两处实现不一致** — 版本名称和 filter 条件统一

### 新增

- `scripts/__init__.py` — 确保 `from scripts.laozi_agent import ...` 正常工作
- `README.md` — 项目说明文档
- `CHANGELOG.md` — 版本日志（本文件）

### 改进

- SKILL.md 重写，增加"两套方案"对比表，两个入口的启动命令和配置项分开说明
- requirements.txt 加入注释，标注哪些依赖属于哪个版本

## v1.0.0 (2026-05-22)

### 初始发布

- 基于 LangChain + Chroma 的 RAG 问答系统
- 以老子身份回答《道德经》和道家思想问题
- 支持多版本原文对比（帛书甲本、王弼本等）
- 思想主题导航（道论、德论、无为而治等）
- Gradio Web 界面 + 命令行交互
- 全免费方案：BGE-base-zh embedding + Qwen2.5-72B LLM
