# 老子智能体 — 详细说明书

> 道可道，非常道。名可名，非常名。—— 《道德经》第一章

---

## 目录

1. [项目简介](#1-项目简介)
2. [系统要求](#2-系统要求)
3. [快速开始](#3-快速开始)
4. [一键配置（推荐）](#4-一键配置推荐)
5. [手动配置](#5-手动配置)
6. [功能详解](#6-功能详解)
7. [配置参数参考](#7-配置参数参考)
8. [知识库说明](#8-知识库说明)
9. [日志系统](#9-日志系统)
10. [API 接口](#10-api-接口)
11. [部署指南](#11-部署指南)
12. [开发指南](#12-开发指南)
13. [常见问题](#13-常见问题)
14. [版本历史](#14-版本历史)

---

## 1. 项目简介

### 什么是老子智能体？

老子智能体是一个基于 **RAG（检索增强生成）** 技术的《道德经》问答系统。它以春秋时期思想家老子（李耳）的身份，回答关于道家思想和《道德经》的问题。

### 核心特性

- **问道老子** — 以老子身份回答问题，引用《道德经》原文
- **多版本对比** — 对比帛书甲本、王弼本等不同版本
- **主题导航** — 按道论、德论、无为而治等主题浏览
- **对话记忆** — 支持多轮对话，上下文连贯
- **强制引用** — 先引原文再解释，严禁编造
- **全免费方案** — 无需 API Key 即可使用

### 技术架构

```
用户提问
    ↓
[Embedding 模型] → 向量化
    ↓
[ChromaDB] → 向量检索（MMR）
    ↓
[LLM 模型] → 生成回答（老子身份）
    ↓
返回回答 + 引用来源
```

### 两套方案

| 特性 | OpenAI 版 | 免费版 |
|---|---|---|
| 入口 | `scripts/laozi_agent.py` | `app.py` |
| 界面 | 命令行 | Gradio Web |
| Embedding | `text-embedding-3-large` | `BAAI/bge-base-zh-v1.5` |
| LLM | `gpt-4o` | `Qwen2.5-72B-Instruct` |
| 需要 API Key | ✅ 是 | ❌ 否 |
| 效果 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| 速度 | 快 | 中等 |
| 费用 | 按量付费 | 完全免费 |

---

## 2. 系统要求

### 硬件要求

| 资源 | 最低 | 推荐 |
|---|---|---|
| CPU | 2 核 | 4 核+ |
| 内存 | 4GB | 8GB+ |
| 磁盘 | 2GB | 5GB+ |
| GPU | 不需要 | 不需要（CPU 运行） |

### 软件要求

| 软件 | 版本 |
|---|---|
| Python | 3.9+ |
| pip | 最新版 |
| Git | 任意版本（可选） |
| 操作系统 | Linux / macOS / Windows |

### 网络要求

- OpenAI 版：需要访问 `api.openai.com`
- 免费版：需要访问 `huggingface.co`（首次下载模型）
- 可选：使用国内镜像加速

---

## 3. 快速开始

### 3.1 获取代码

```bash
git clone https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao.git
cd opendao
```

### 3.2 一键配置（推荐）

```bash
python3 setup.py
```

脚本会引导你完成：
1. 选择方案（OpenAI 版 / 免费版）
2. 配置 API Key（如果需要）
3. 安装依赖
4. 检查知识库
5. 生成启动脚本

### 3.3 启动

```bash
# 使用启动脚本
bash start_free.sh    # 免费版
bash start_openai.sh  # OpenAI 版

# 或手动启动
python3 app.py              # 免费版
python3 scripts/laozi_agent.py  # OpenAI 版
```

---

## 4. 一键配置（推荐）

### 运行配置脚本

```bash
python3 setup.py
```

### 交互流程

```
  ██╗      █████╗  ██████╗ ███████╗██╗
  ██║     ██╔══██╗██╔═══██╗╚══███╔╝██║
  ██║     ███████║██║   ██║  ███╔╝ ██║
  ██║     ██╔══██║██║   ██║ ███╔╝  ██║
  ███████╗██║  ██║╚██████╔╝███████╗██║
  ╚══════╝╚═╝  ╚═╝ ╚═════╝╚══════╝╚═╝
  ─────────────────────────────────────
   老子智能体 · 一键配置工具 v1.1.1
  ─────────────────────────────────────

  📋 环境检测
  ────────────────────────────────────
  系统:     Linux (x86_64)
  Python:   3.10.12
  Git:      ✅ 可用
  pip:      ✅ 可用
  ────────────────────────────────────

  🎯 选择方案

  方案一：OpenAI 版
    • 效果最好，理解能力最强
    • 需要 OpenAI API Key（付费）

  方案二：免费版
    • 完全免费，无需任何 API Key
    • Gradio Web 界面

  选择方案 (1/2) [2]:
```

### 命令行参数

```bash
python3 setup.py --auto       # 自动模式（跳过交互，使用免费版）
python3 setup.py --plan 1     # 直接选择方案一
python3 setup.py --plan 2     # 直接选择方案二
python3 setup.py --help       # 查看帮助
```

---

## 5. 手动配置

### 5.1 创建虚拟环境（推荐）

```bash
python3 -m venv venv
source venv/bin/activate  # Linux/macOS
# venv\Scripts\activate   # Windows
```

### 5.2 安装依赖

```bash
# 全部安装
pip install -r requirements.txt

# 或按需安装
# OpenAI 版
pip install langchain langchain-openai langchain-chroma chromadb

# 免费版
pip install langchain langchain-community langchain-chroma chromadb sentence-transformers huggingface_hub gradio
```

### 5.3 配置环境变量

```bash
# 方式一：创建 .env 文件（推荐）
cat > .env << 'EOF'
# OpenAI 版配置
OPENAI_API_KEY=sk-your-key-here
LAOZI_LLM_MODEL=gpt-4o
LAOZI_EMBEDDING_MODEL=text-embedding-3-large
LAOZI_TEMPERATURE=0.1

# 或免费版配置
# HF_TOKEN=hf_your_token_here
# LAOZI_LLM_MODEL=Qwen/Qwen2.5-72B-Instruct
# LAOZI_EMBEDDING_MODEL=BAAI/bge-base-zh-v1.5
# LAOZI_TEMPERATURE=0.3

# 通用配置
LAOZI_PERSIST_DIR=./laozi_knowledge_base
LAOZI_RETRIEVAL_K=5
LAOZI_FETCH_K=20
LAOZI_LOG_LEVEL=INFO
EOF

# 方式二：export 环境变量
export OPENAI_API_KEY="sk-your-key-here"
export LAOZI_LLM_MODEL="gpt-4o"
```

### 5.4 启动

```bash
# OpenAI 版
python3 scripts/laozi_agent.py

# 免费版
python3 app.py
# 浏览器打开 http://localhost:7860
```

---

## 6. 功能详解

### 6.1 问道老子

以老子身份回答问题，自动引用《道德经》原文。

**使用方式**：
- Web 界面：在"问道老子"标签页输入问题
- 命令行：直接输入问题

**示例问题**：
- "什么是道？"
- "老子如何看待无为而治？"
- "道德经第一章讲了什么？"
- "如何理解上善若水？"
- "老子的辩证思想是什么？"

**回答特点**：
1. 先引用《道德经》原文
2. 解释原文本义
3. 结合问题阐述观点
4. 如有版本差异会说明
5. 以哲理总结收尾

### 6.2 多版本对比

对比同一章节的不同版本原文。

**支持版本**：
- 帛书甲本（马王堆出土）
- 王弼本（通行本）

**使用方式**：
- Web 界面：在"版本对比"标签页输入章节号
- 命令行：调用 `compare_versions(chapter_num)`

**示例**：
```python
# 命令行
result = compare_versions(1)
# 返回: {"帛书甲本": "...", "王弼本": "..."}
```

### 6.3 主题导航

按思想主题浏览相关内容。

**支持主题**：
- 道论 — 道的本质与特性
- 德论 — 德的内涵与实践
- 无为而治 — 政治哲学
- 辩证思维 — 对立统一
- 柔弱胜刚强 — 以柔克刚
- 知足常乐 — 知足哲学
- 返璞归真 — 回归本真
- 生死观 — 生死哲学

**使用方式**：
- Web 界面：在"主题导航"标签页选择主题
- 命令行：调用 `get_topic_content(topic)`

### 6.4 对话记忆

系统会记住对话历史，支持多轮对话。

**特点**：
- 自动维护上下文
- 可以追问和深入讨论
- Web 界面支持重试、撤销、清空

### 6.5 系统状态（Web 界面）

Web 界面提供"系统状态"标签页，显示：
- 当前配置信息
- 模型参数
- 最近日志
- 一键刷新日志

---

## 7. 配置参数参考

### 环境变量列表

| 变量名 | 说明 | OpenAI 版默认 | 免费版默认 |
|---|---|---|---|
| `OPENAI_API_KEY` | OpenAI API 密钥 | （必填） | — |
| `HF_TOKEN` | HuggingFace Token | — | （可选） |
| `LAOZI_LLM_MODEL` | LLM 模型名 | `gpt-4o` | `Qwen/Qwen2.5-72B-Instruct` |
| `LAOZI_EMBEDDING_MODEL` | Embedding 模型 | `text-embedding-3-large` | `BAAI/bge-base-zh-v1.5` |
| `LAOZI_TEMPERATURE` | 生成温度（0-1） | `0.1` | `0.3` |
| `LAOZI_RETRIEVAL_K` | 返回文档数 | `5` | `5` |
| `LAOZI_FETCH_K` | MMR 候选池大小 | `20` | `20` |
| `LAOZI_PERSIST_DIR` | 向量库目录 | `./laozi_knowledge_base` | `./laozi_knowledge_base` |
| `LAOZI_COLLECTION` | 向量集合名 | `laozi_collection` | `laozi_collection` |
| `LAOZI_SOURCE_DIR` | 源文档目录 | `./laozi-agent/laozi_source_docs` | `./laozi-agent/laozi_source_docs` |
| `LAOZI_SERVER_PORT` | Web 服务端口 | — | `7860` |
| `LAOZI_LOG_LEVEL` | 日志级别 | `INFO` | `INFO` |
| `LAOZI_LOG_DIR` | 日志目录 | `logs` | `logs` |

### 参数调优建议

**温度（Temperature）**：
- `0.0-0.2`：严谨、一致性强，适合学术研究
- `0.3-0.5`：平衡，适合日常使用
- `0.6-1.0`：创造性强，但可能产生幻觉

**检索数量（RETRIEVAL_K）**：
- `3-5`：快速、精准
- `5-10`：全面、但可能引入噪音
- `10+`：不推荐，容易混淆

**MMR 候选池（FETCH_K）**：
- 是 `RETRIEVAL_K` 的 3-4 倍为佳
- 太小：多样性不足
- 太大：速度变慢

---

## 8. 知识库说明

### 数据来源

| 版本 | 说明 | 章节数 |
|---|---|---|
| 帛书甲本 | 马王堆汉墓出土 | 81 章 |
| 王弼本 | 通行本（王弼注） | 81 章 |

### 目录结构

```
laozi-agent/laozi_source_docs/
├── 帛书甲本/
│   ├── 第01章.txt
│   ├── 第02章.txt
│   └── ... (共81章)
└── 王弼本/
    ├── 第01章.txt
    ├── 第02章.txt
    └── ... (共81章)
```

### 元数据字段

每个文档块包含以下元数据：

| 字段 | 说明 | 示例 |
|---|---|---|
| `type` | 文档类型 | "原文" / "注释" / "研究" |
| `version` | 版本名 | "帛书甲本" / "王弼本" |
| `chapter` | 章节号 | "1" ~ "81" |
| `topic` | 主题标签 | "道论" / "德论" |
| `title` | 书名 | "道德经" |
| `page` | 页码 | "1" |

### 向量库管理

```bash
# 查看向量库大小
du -sh laozi_knowledge_base/

# 重建向量库（删除后首次启动自动重建）
rm -rf laozi_knowledge_base/
python3 app.py

# 导出向量库（备份）
tar czf laozi_knowledge_base.tar.gz laozi_knowledge_base/
```

### 添加自定义文档

1. 将 `.txt` 文件放入 `laozi-agent/laozi_source_docs/` 对应目录
2. 文件格式：
   ```
   ---
   type: 原文
   version: 帛书甲本
   chapter: 1
   title: 道德经
   ---
   道可道也，非恒道也...
   ```
3. 删除向量库，重启后自动重建

---

## 9. 日志系统

### 日志级别

| 级别 | 说明 | 使用场景 |
|---|---|---|
| `DEBUG` | 调试信息 | 开发调试 |
| `INFO` | 一般信息 | 正常运行（默认） |
| `WARNING` | 警告 | 潜在问题 |
| `ERROR` | 错误 | 功能异常 |
| `CRITICAL` | 严重错误 | 系统崩溃 |

### 日志文件

| 文件 | 内容 | 大小限制 |
|---|---|---|
| `logs/laozi.log` | 全部日志 | 10MB × 5 份 |
| `logs/error.log` | 仅错误 | 10MB × 5 份 |

### 查看日志

```bash
# 实时查看
tail -f logs/laozi.log

# 查看错误
cat logs/error.log

# 搜索关键词
grep "问答" logs/laozi.log
grep "ERROR" logs/laozi.log

# 查看最近 N 行
tail -100 logs/laozi.log
```

### 修改日志级别

```bash
# 临时
export LAOZI_LOG_LEVEL=DEBUG

# 永久（编辑 .env）
LAOZI_LOG_LEVEL=DEBUG
```

### 日志格式

```
2026-05-25 06:45:12 INFO  [laozi.app] 问答: 什么是道... | 来源: 王弼本 第1章 | 耗时: 1234ms
2026-05-25 06:45:15 ERROR [laozi.app] [laozi_chat] 错误: TimeoutError: Request timed out
```

---

## 10. API 接口

### Python API

```python
# OpenAI 版
from scripts.laozi_agent import laozi_skill, compare_versions, get_topics, get_topic_content

# 问答
result = laozi_skill("什么是道？")
print(result["answer"])    # 回答文本
print(result["sources"])   # 引用来源列表

# 版本对比
versions = compare_versions(1)
# {"帛书甲本": "...", "王弼本": "..."}

# 主题列表
topics = get_topics()
# ["道论", "德论", "无为而治", ...]

# 主题内容
content = get_topic_content("道论")
```

### Gradio API（免费版）

启动后访问 `http://localhost:7860/api` 查看 API 文档。

```python
from gradio_client import Client

client = Client("http://localhost:7860")
result = client.predict("什么是道？", api_name="/chat")
```

---

## 11. 部署指南

### 本地部署

```bash
# 最简单的方式
python3 setup.py
bash start_free.sh
```

### 服务器部署

```bash
# 1. 克隆代码
git clone <repo-url>
cd opendao

# 2. 配置
python3 setup.py --auto

# 3. 使用 systemd 管理服务
sudo tee /etc/systemd/system/laozi.service << 'EOF'
[Unit]
Description=老子智能体
After=network.target

[Service]
Type=simple
User=www
WorkingDirectory=/opt/opendao
ExecStart=/opt/opendao/venv/bin/python3 app.py
Restart=always
RestartSec=5
Environment="LAOZI_SERVER_PORT=7860"

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable laozi
sudo systemctl start laozi
```

### Docker 部署

```dockerfile
FROM python:3.10-slim

WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
EXPOSE 7860

CMD ["python3", "app.py"]
```

```bash
docker build -t laozi .
docker run -p 7860:7860 -v laozi_data:/app/laozi_knowledge_base laozi
```

### 反向代理（Nginx）

```nginx
server {
    listen 80;
    server_name laozi.example.com;

    location / {
        proxy_pass http://127.0.0.1:7860;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

---

## 12. 开发指南

### 项目结构

```
opendao/
├── app.py                  # 免费版主入口
├── setup.py                # 一键配置脚本
├── requirements.txt        # 依赖清单
├── .env                    # 配置文件（自动生成）
├── start_free.sh           # 免费版启动脚本
├── start_openai.sh         # OpenAI 版启动脚本
├── scripts/
│   ├── laozi_agent.py      # OpenAI 版主入口
│   └── __init__.py
├── laozi_agent/
│   ├── __init__.py
│   └── logger.py           # 日志模块
├── laozi-agent/
│   ├── laozi_source_docs/  # 源文档
│   ├── scripts/            # 工具脚本
│   ├── docs/               # 文档
│   └── references/         # 参考资料
├── docs/
│   ├── USER_MANUAL.md      # 本说明书
│   └── TROUBLESHOOTING.md  # 故障排查
└── logs/                   # 日志目录
    ├── laozi.log
    └── error.log
```

### 代码规范

- Python 3.9+ 兼容
- 使用类型注解
- 遵循 PEP 8
- 所有公共函数有 docstring
- 使用 `laozi_agent.logger` 记录日志

### 添加新功能

1. 在对应模块中添加函数
2. 在 `app.py` 和/或 `scripts/laozi_agent.py` 中集成
3. 添加日志记录
4. 更新文档

---

## 13. 常见问题

**Q: 首次启动为什么很慢？**
A: 首次需要下载 Embedding 模型（约 400MB）并构建向量库。后续启动秒级完成。

**Q: 可以离线使用吗？**
A: 免费版首次需要网络下载模型，之后可以离线。OpenAI 版需要持续网络连接。

**Q: 支持哪些语言？**
A: 目前仅支持中文（《道德经》及问答均为中文）。

**Q: 如何提高回答质量？**
A: 使用 OpenAI 版（GPT-4o）效果最佳。免费版可以降低温度到 0.1-0.2。

**Q: 知识库可以扩展吗？**
A: 可以。将新文档放入 `laozi-agent/laozi_source_docs/`，删除向量库后重启即可。

**Q: 数据安全吗？**
A: 免费版本地运行，数据不出服务器。OpenAI 版的问题会发送到 OpenAI API。

更多问题见 [故障排查手册](TROUBLESHOOTING.md)。

---

## 14. 版本历史

### v1.2.0 (2026-05-25)

**新增**：
- 一键配置脚本 `setup.py`（交互式引导）
- 系统日志模块 `laozi_agent/logger.py`
- 故障排查手册 `docs/TROUBLESHOOTING.md`
- 详细说明书 `docs/USER_MANUAL.md`
- Web 界面系统状态标签页
- `.env` 配置文件自动加载
- 启动脚本自动生成

**改进**：
- `app.py` 集成日志系统
- 全链路日志记录（问答、检索、错误）
- 错误信息更友好，附带排查链接

### v1.1.0 (2026-05-24)

**修复**：
- `scripts/laozi_agent.py` 模型配置与文档不一致
- `requirements.txt` 缺失依赖
- `app.py` 的 `compare_versions` filter 过于严格
- 两处 `compare_versions` 实现不一致

**新增**：
- `scripts/__init__.py`
- `README.md`
- `CHANGELOG.md`

### v1.0.0 (2026-05-22)

- 初始发布
- 基于 LangChain + Chroma 的 RAG 问答系统
- 支持多版本原文对比
- 思想主题导航
- Gradio Web 界面 + 命令行交互
- 全免费方案

---

> _上善若水。水善利万物而不争。_ —— 《道德经》第八章
