# 老子智能体 — 故障排查手册

> 遇到问题先看这里。按错误类型分类，附带解决方案。

---

## 目录

1. [安装与依赖问题](#1-安装与依赖问题)
2. [配置问题](#2-配置问题)
3. [知识库问题](#3-知识库问题)
4. [模型与API问题](#4-模型与api问题)
5. [Gradio Web 界面问题](#5-gradio-web-界面问题)
6. [性能与内存问题](#6-性能与内存问题)
7. [日志与调试](#7-日志与调试)
8. [常见错误码](#8-常见错误码)

---

## 1. 安装与依赖问题

### ❌ `ModuleNotFoundError: No module named 'xxx'`

**原因**：缺少 Python 依赖包。

**解决**：
```bash
# 安装全部依赖
pip install -r requirements.txt

# 如果使用虚拟环境，确认已激活
source venv/bin/activate
pip install -r requirements.txt
```

### ❌ `pip install` 超时或失败

**原因**：网络问题，PyPI 源连接慢。

**解决**：
```bash
# 使用国内镜像源
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 或阿里云镜像
pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/
```

### ❌ `error: Microsoft Visual C++ 14.0 or greater is required`（Windows）

**原因**：编译 C 扩展缺少 Visual Studio Build Tools。

**解决**：
1. 下载安装 [Visual Studio Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)
2. 或使用预编译的 wheel：`pip install --only-binary :all: chromadb`

### ❌ Python 版本不兼容

**症状**：语法错误或 `ImportError`。

**解决**：需要 Python 3.9 或更高版本。
```bash
python3 --version  # 检查版本

# 如果版本过低，建议安装 Python 3.10+
# Ubuntu: sudo apt install python3.10
# macOS: brew install python@3.10
```

---

## 2. 配置问题

### ❌ `OPENAI_API_KEY` 未设置

**症状**（OpenAI 版）：
```
openai.OpenAIError: The api_key client option must be set
```

**解决**：
```bash
# 方式一：环境变量
export OPENAI_API_KEY="sk-your-key-here"

# 方式二：写入 .env 文件
echo "OPENAI_API_KEY=sk-your-key-here" >> .env

# 方式三：重新配置
python3 setup.py
```

### ❌ `.env` 配置不生效

**原因**：环境变量优先级高于 `.env` 文件。

**解决**：
```bash
# 检查当前环境变量
env | grep LAOZI

# 清除后重新加载
unset LAOZI_LLM_MODEL
source .env  # 或重启终端
```

### ❌ HuggingFace Token 无效（免费版）

**症状**：
```
401 Client Error: Unauthorized
```

**解决**：
1. 访问 https://huggingface.co/settings/tokens 确认 Token 有效
2. 确认 Token 有 `read` 权限
3. 如果没有 Token，可以留空（速率会降低但能用）

---

## 3. 知识库问题

### ❌ 向量库不存在或为空

**症状**：
```
⚠️ 源文档目录不存在: ./laozi-agent/laozi_source_docs
```

**解决**：
```bash
# 检查源文档目录
ls -la laozi-agent/laozi_source_docs/

# 如果目录不存在，重新克隆仓库
git clone https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao.git

# 首次启动会自动构建向量库（需要几分钟）
python3 app.py
```

### ❌ 向量库构建失败

**症状**：
```
ChromaDB error: ...
```

**解决**：
```bash
# 删除旧的向量库，重新构建
rm -rf laozi_knowledge_base/
python3 app.py  # 首次启动自动构建
```

### ❌ 检索结果不相关

**症状**：回答与问题无关。

**解决**：
```bash
# 增加检索数量
export LAOZI_RETRIEVAL_K=10
export LAOZI_FETCH_K=40

# 或在 .env 文件中修改
LAOZI_RETRIEVAL_K=10
LAOZI_FETCH_K=40
```

---

## 4. 模型与API问题

### ❌ OpenAI API 限流（429 错误）

**症状**：
```
RateLimitError: Rate limit reached
```

**解决**：
```bash
# 方式一：降低请求频率
export LAOZI_TEMPERATURE=0.1

# 方式二：切换到更便宜的模型
export LAOZI_LLM_MODEL="gpt-4o-mini"

# 方式三：使用免费版
python3 app.py
```

### ❌ HuggingFace 推理 API 超时

**症状**（免费版）：
```
TimeoutError: Request timed out
```

**解决**：
```bash
# 方式一：设置 HuggingFace Token（提高速率限制）
export HF_TOKEN="hf_your_token_here"

# 方式二：换用更快的模型
export LAOZI_LLM_MODEL="Qwen/Qwen2.5-14B-Instruct"

# 方式三：检查网络连接
curl -I https://api-inference.huggingface.co
```

### ❌ 模型输出乱码或重复

**原因**：温度设置过高或模型不兼容。

**解决**：
```bash
# 降低温度
export LAOZI_TEMPERATURE=0.1

# OpenAI 版推荐 0.1，免费版推荐 0.3
```

### ❌ Embedding 模型加载失败

**症状**：
```
OSError: [Model] not found
```

**解决**：
```bash
# 检查网络（HuggingFace 模型需要首次下载）
# 使用国内镜像
export HF_ENDPOINT=https://hf-mirror.com
python3 app.py
```

---

## 5. Gradio Web 界面问题

### ❌ 端口被占用

**症状**：
```
OSError: [Errno 98] Address already in use
```

**解决**：
```bash
# 方式一：换端口
export LAOZI_SERVER_PORT=7861
python3 app.py

# 方式二：找出占用端口的进程并停止
lsof -i :7860
kill <PID>
```

### ❌ 浏览器无法访问

**可能原因**：
1. 防火墙阻止了端口
2. 服务绑定在 127.0.0.1 而非 0.0.0.0
3. 服务器在远程机器上

**解决**：
```bash
# 检查服务是否运行
curl http://localhost:7860

# 远程服务器需要开放端口
# 或使用 SSH 隧道
ssh -L 7860:localhost:7860 user@server
```

### ❌ 页面加载后空白

**原因**：JavaScript 加载失败或浏览器缓存。

**解决**：
1. 强制刷新：`Ctrl+Shift+R`
2. 清除浏览器缓存
3. 尝试无痕模式

---

## 6. 性能与内存问题

### ❌ 内存不足（OOM）

**症状**：进程被杀死或 `Killed`。

**解决**：
```bash
# 方式一：使用更小的 Embedding 模型
export LAOZI_EMBEDDING_MODEL="BAAI/bge-small-zh-v1.5"

# 方式二：减少检索数量
export LAOZI_RETRIEVAL_K=3

# 方式三：增加 swap
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

### ❌ 首次启动很慢

**原因**：首次需要下载 Embedding 模型并构建向量库。

**解决**：
- 这是正常现象，首次需要 5-15 分钟
- 后续启动会直接加载已构建的向量库（秒级）
- 如果网络慢，可以预先下载模型：
```bash
python3 -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('BAAI/bge-base-zh-v1.5')"
```

### ❌ 向量库占用磁盘过多

**解决**：
```bash
# 查看大小
du -sh laozi_knowledge_base/

# 如果太大，可以重建（会重新分块）
rm -rf laozi_knowledge_base/
python3 app.py
```

---

## 7. 日志与调试

### 查看日志

```bash
# 实时查看日志
tail -f logs/laozi.log

# 查看错误日志
cat logs/error.log

# 查看最近 50 行
tail -50 logs/laozi.log

# 搜索特定错误
grep "ERROR" logs/laozi.log
```

### 开启 DEBUG 日志

```bash
# 临时开启
export LAOZI_LOG_LEVEL=DEBUG
python3 app.py

# 永久修改
# 编辑 .env 文件
LAOZI_LOG_LEVEL=DEBUG
```

### 日志文件说明

| 文件 | 说明 |
|---|---|
| `logs/laozi.log` | 主日志（INFO 以上，自动轮转 10MB×5） |
| `logs/error.log` | 错误日志（ERROR 以上） |
| `logs/laozi.log.1` | 旧日志备份 |

---

## 8. 常见错误码

| 错误 | 原因 | 解决方案 |
|---|---|---|
| `ModuleNotFoundError` | 缺少依赖 | `pip install -r requirements.txt` |
| `OpenAIError` | API Key 未设置 | 设置 `OPENAI_API_KEY` |
| `RateLimitError` | API 限流 | 等待或切换模型 |
| `TimeoutError` | 请求超时 | 检查网络或设置 Token |
| `OSError: Address in use` | 端口占用 | 换端口或停止占用进程 |
| `ChromaDB error` | 向量库损坏 | 删除重建 `laozi_knowledge_base/` |
| `CUDA out of memory` | GPU 显存不足 | 使用 CPU 模式或更小模型 |

---

## 还是解决不了？

1. 查看 [用户手册](USER_MANUAL.md)
2. 查看 [API 文档](../laozi-agent/docs/API.md)
3. 提交 Issue: [GitLab Issues](https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao/-/issues)
4. 查看日志文件，将错误信息附在 Issue 中

---

> _善为士者不武，善战者不怒。_ —— 《道德经》第68章
