#!/usr/bin/env python3
"""
老子智能体 — 系统日志模块

功能：
  - 控制台彩色输出（INFO 级别以上）
  - 文件日志记录（DEBUG 级别以上，自动轮转）
  - 结构化日志格式
  - 按模块分 logger

用法：
  from laozi_agent.logger import get_logger, setup_logging

  # 初始化（程序启动时调用一次）
  setup_logging(log_level="INFO", log_dir="logs")

  # 获取 logger
  logger = get_logger("app")
  logger.info("系统启动")
  logger.error("出错了", exc_info=True)
"""

import os
import sys
import logging
import logging.handlers
from datetime import datetime
from pathlib import Path

# ──────────────────────────────────────────────
# 默认配置
# ──────────────────────────────────────────────
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_LOG_DIR = "logs"
DEFAULT_LOG_FILE = "laozi.log"
DEFAULT_MAX_BYTES = 10 * 1024 * 1024  # 10MB
DEFAULT_BACKUP_COUNT = 5

# 日志格式
CONSOLE_FORMAT = "%(asctime)s %(levelname)-5s [%(name)s] %(message)s"
FILE_FORMAT = "%(asctime)s %(levelname)-8s [%(name)s] [%(filename)s:%(lineno)d] %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# 已初始化标记
_initialized = False


# ──────────────────────────────────────────────
# 控制台彩色 Formatter
# ──────────────────────────────────────────────
class ColoredFormatter(logging.Formatter):
    """控制台带颜色的日志格式化器。"""

    COLORS = {
        logging.DEBUG:    "\033[36m",   # 青色
        logging.INFO:     "\033[32m",   # 绿色
        logging.WARNING:  "\033[33m",   # 黄色
        logging.ERROR:    "\033[31m",   # 红色
        logging.CRITICAL: "\033[35m",   # 紫色
    }
    RESET = "\033[0m"

    def __init__(self, fmt=None, datefmt=None):
        super().__init__(fmt, datefmt)
        self._is_tty = hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()

    def format(self, record):
        msg = super().format(record)
        if not self._is_tty:
            return msg
        color = self.COLORS.get(record.levelcode, self.COLORS.get(record.levelno, ""))
        return f"{color}{msg}{self.RESET}"


# ──────────────────────────────────────────────
# 日志事件过滤器
# ──────────────────────────────────────────────
class ModuleFilter(logging.Filter):
    """按模块名过滤日志。"""

    def __init__(self, modules=None):
        super().__init__()
        self.modules = modules

    def filter(self, record):
        if self.modules is None:
            return True
        return any(record.name.startswith(m) for m in self.modules)


# ──────────────────────────────────────────────
# 初始化日志系统
# ──────────────────────────────────────────────
def setup_logging(
    log_level=None,
    log_dir=None,
    log_file=None,
    max_bytes=None,
    backup_count=None,
    modules=None,
):
    """
    初始化日志系统。程序启动时调用一次。

    Args:
        log_level: 日志级别（DEBUG/INFO/WARNING/ERROR），默认从环境变量读取
        log_dir:   日志文件目录，默认 logs/
        log_file:  日志文件名，默认 laozi.log
        max_bytes: 单个日志文件最大字节数，默认 10MB
        backup_count: 保留的旧日志文件数量，默认 5
        modules:   要记录的模块列表，None 表示全部

    Returns:
        logging.Logger: 根 logger
    """
    global _initialized

    # 从环境变量读取
    log_level = log_level or os.getenv("LAOZI_LOG_LEVEL", DEFAULT_LOG_LEVEL)
    log_dir = log_dir or os.getenv("LAOZI_LOG_DIR", DEFAULT_LOG_DIR)
    log_file = log_file or DEFAULT_LOG_FILE
    max_bytes = max_bytes or DEFAULT_MAX_BYTES
    backup_count = backup_count or DEFAULT_BACKUP_COUNT

    # 创建日志目录
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    log_filepath = log_path / log_file

    # 获取根 logger
    root_logger = logging.getLogger()
    level = getattr(logging, log_level.upper(), logging.INFO)
    root_logger.setLevel(logging.DEBUG)  # 总是最低级别，由 handler 控制

    # 清除已有 handler（防止重复）
    if _initialized:
        root_logger.handlers.clear()

    # ── 控制台 Handler（INFO 以上）──
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(ColoredFormatter(CONSOLE_FORMAT, DATE_FORMAT))
    if modules:
        console_handler.addFilter(ModuleFilter(modules))
    root_logger.addHandler(console_handler)

    # ── 文件 Handler（DEBUG 以上，自动轮转）──
    file_handler = logging.handlers.RotatingFileHandler(
        filename=str(log_filepath),
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(FILE_FORMAT, DATE_FORMAT))
    root_logger.addHandler(file_handler)

    # ── 错误日志（单独文件）──
    error_filepath = log_path / "error.log"
    error_handler = logging.handlers.RotatingFileHandler(
        filename=str(error_filepath),
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(logging.Formatter(FILE_FORMAT, DATE_FORMAT))
    root_logger.addHandler(error_handler)

    _initialized = True

    # 记录启动信息
    logger = get_logger("logger")
    logger.info(f"日志系统初始化完成")
    logger.info(f"  级别: {log_level}")
    logger.info(f"  文件: {log_filepath}")
    logger.info(f"  错误日志: {error_filepath}")
    logger.debug(f"  最大: {max_bytes // 1024 // 1024}MB, 保留: {backup_count} 份")

    return root_logger


# ──────────────────────────────────────────────
# 获取 Logger
# ──────────────────────────────────────────────
def get_logger(name):
    """
    获取一个命名 logger。

    Args:
        name: 模块名（如 "app"、"retriever"、"llm"）

    Returns:
        logging.Logger
    """
    return logging.getLogger(f"laozi.{name}")


# ──────────────────────────────────────────────
# 便捷函数
# ──────────────────────────────────────────────
def log_query(logger, question, answer, sources=None, duration_ms=None):
    """记录一次问答日志。"""
    src_str = ""
    if sources:
        src_str = f" | 来源: {', '.join(sources[:3])}"
    dur_str = f" | 耗时: {duration_ms:.0f}ms" if duration_ms else ""
    logger.info(f"问答: {question[:50]}...{src_str}{dur_str}")


def log_error(logger, error, context=None):
    """记录错误日志。"""
    ctx_str = f" [{context}]" if context else ""
    logger.error(f"错误{ctx_str}: {type(error).__name__}: {error}", exc_info=True)


def log_startup(logger, plan, config):
    """记录启动信息。"""
    logger.info("=" * 50)
    logger.info("老子智能体启动")
    logger.info(f"  方案: {plan}")
    logger.info(f"  模型: {config.get('model', 'N/A')}")
    logger.info(f"  温度: {config.get('temperature', 'N/A')}")
    logger.info(f"  知识库: {config.get('persist_dir', 'N/A')}")
    logger.info("=" * 50)
