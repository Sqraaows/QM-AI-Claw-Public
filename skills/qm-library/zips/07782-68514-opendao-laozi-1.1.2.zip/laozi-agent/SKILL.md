---
name: laozi-agent
description: >
  老子智能体（李耳）— 基于 RAG 的《道德经》问答系统。使用 LangChain + Chroma 向量数据库，
  检索增强生成，以老子身份回答关于道家思想和《道德经》的问题。
  支持多版本原文对比、思想主题导航、对话记忆。
  触发场景：用户提到"老子"、"道德经"、"道家"、"请问老子"、"老子说"、"李耳"、
  "无为"、"道论"、"德论"等关键词时激活。
---

# 老子智能体 SKILL

基于 LangChain + Chroma 的 RAG 问答系统，以春秋时期思想家老子（李耳）的身份回答问题。

## 前置依赖

```bash
pip install -r requirements.txt
```

无需 API Key。Embedding 使用 BAAI/bge-base-zh-v1.5（本地加载），LLM 使用 Qwen2.5-72B（HuggingFace 免费推理 API）。

## 快速启动

```bash
# Web 界面（推荐）
python3 app.py

# 或命令行交互
python3 scripts/laozi_agent.py
```

## 核心功能

### 1. 问答 (`laozi_skill`)

以老子身份回答问题，引用《道德经》原文，返回引用来源。

```python
from scripts.laozi_agent import laozi_skill
result = laozi_skill("什么是道？")
# result["answer"] — 老子的回答
# result["sources"] — 引用来源列表
```

### 2. 多版本对比 (`compare_versions`)

对比同一章节的不同版本原文（郭店楚简、马王堆帛书、王弼注本等）。

```python
from scripts.laozi_agent import compare_versions
versions = compare_versions(1)  # 对比第1章
```

### 3. 主题导航 (`get_topics` / `get_topic_content`)

获取老子思想主要主题及相关内容。

```python
from scripts.laozi_agent import get_topics, get_topic_content
topics = get_topics()
content = get_topic_content("道论")
```

## 知识库结构

知识库目录 `./laozi_knowledge_base/`，向量集合名 `laozi_collection`。

文档元数据字段：
- `type` — "原文" / "注释" / "研究"
- `version` — 版本名（郭店楚简本、马王堆帛书甲本 等）
- `chapter` — 章节号
- `topic` — 主题标签（道论、德论 等）
- `title` — 书名/篇名
- `page` — 页码

详细书单见 [references/knowledge_base_booklist.md](references/knowledge_base_booklist.md)。

## 配置项

在 `scripts/laozi_agent.py` 顶部可调整：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `EMBEDDING_MODEL` | `BAAI/bge-base-zh-v1.5` | 向量模型（中文优化，免费） |
| `LLM_MODEL` | `Qwen/Qwen2.5-72B-Instruct` | 生成模型（免费推理） |
| `TEMPERATURE` | `0.3` | 温度（越低越严谨） |
| `RETRIEVAL_K` | 5 | 返回文档数 |
| `FETCH_K` | 20 | MMR 候选池大小 |
| `PERSIST_DIR` | `./laozi_knowledge_base` | 向量库目录 |
| `COLLECTION_NAME` | `laozi_collection` | 集合名 |

## 准确性保障

- **低温度** (0.1) 减少幻觉
- **MMR 检索** 兼顾相关性与多样性
- **强制引用原文** — Prompt 要求先引原文再解释
- **未知就说不知** — 超出范围回答"吾不知也"
- **禁止编造** — 严禁无上下文支持的内容

## 注意事项

1. 严格区分道家（哲学）与道教（宗教），不涉及神仙体系
2. 坚持学术中立，避免过度解读
3. 有争议问题说明不同学者观点
4. 保持老子本人的谦逊态度
