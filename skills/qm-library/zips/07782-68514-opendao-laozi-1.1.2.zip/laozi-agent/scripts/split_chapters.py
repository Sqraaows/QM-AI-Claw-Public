#!/usr/bin/env python3
"""
将《道德经》全文按章节拆分为单章文件。
输入：从网页抓取的原始文本
输出：按版本×章节拆分的 .txt 文件
"""
import re
import os
import sys

def split_by_chapters(text, version_name, output_dir):
    """将文本按章节拆分并写入文件。"""
    # 匹配 "第X章" 或 "第X章" 格式
    pattern = r'#{1,4}\s*第([一二三四五六七八九十百零\d]+)章'
    chapters = re.split(pattern, text)
    
    # chapters[0] 是前言，之后是 (章号, 内容) 交替
    count = 0
    for i in range(1, len(chapters), 2):
        ch_num = chapters[i]
        # 中文数字转阿拉伯数字
        ch_int = cn_to_int(ch_num)
        if ch_int is None:
            try:
                ch_int = int(ch_num)
            except ValueError:
                continue
        
        content = chapters[i+1].strip() if i+1 < len(chapters) else ""
        # 清理内容：去掉多余的空行和标记
        content = re.sub(r'\n{3,}', '\n\n', content)
        content = content.strip()
        
        if not content:
            continue
        
        # 写入文件
        ver_dir = os.path.join(output_dir, version_name)
        os.makedirs(ver_dir, exist_ok=True)
        fname = os.path.join(ver_dir, f"第{ch_int:02d}章.txt")
        with open(fname, 'w', encoding='utf-8') as f:
            f.write(f"---\ntype: 原文\nversion: {version_name}\nchapter: {ch_int}\ntitle: 道德经\n---\n\n")
            f.write(content)
        count += 1
    
    print(f"  {version_name}: 生成 {count} 个章节文件")

def cn_to_int(cn):
    """简单的中文数字转阿拉伯数字。"""
    cn_map = {'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10,
              '十一':11,'十二':12,'十三':13,'十四':14,'十五':15,'十六':16,'十七':17,'十八':18,'十九':19,'二十':20,
              '二十一':21,'二十二':22,'二十三':23,'二十四':24,'二十五':25,'二十六':26,'二十七':27,'二十八':28,'二十九':29,'三十':30,
              '三十一':31,'三十二':32,'三十三':33,'三十四':34,'三十五':35,'三十六':36,'三十七':37,'三十八':38,'三十九':39,'四十':40,
              '四十一':41,'四十二':42,'四十三':43,'四十四':44,'四十五':45,'四十六':46,'四十七':47,'四十八':48,'四十九':49,'五十':50,
              '五十一':51,'五十二':52,'五十三':53,'五十四':54,'五十五':55,'五十六':56,'五十七':57,'五十八':58,'五十九':59,'六十':60,
              '六十一':61,'六十二':62,'六十三':63,'六十四':64,'六十五':65,'六十六':66,'六十七':67,'六十八':68,'六十九':69,'七十':70,
              '七十一':71,'七十二':72,'七十三':73,'七十四':74,'七十五':75,'七十六':76,'七十七':77,'七十八':78,'七十九':79,'八十':80,
              '八十一':81}
    return cn_map.get(cn)

if __name__ == "__main__":
    output_dir = sys.argv[1] if len(sys.argv) > 1 else "./laozi_source_docs"
    
    # 从 stdin 读取
    if len(sys.argv) > 2:
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            text = f.read()
        version = sys.argv[3] if len(sys.argv) > 3 else "未知版本"
        split_by_chapters(text, version, output_dir)
    else:
        print("用法: python3 split_chapters.py <output_dir> <input_file> <version_name>")
