#!/usr/bin/env python3
"""
知识库构建脚本 — 将《道德经》及相关文献导入 Chroma 向量数据库

使用方式：
  1. 将文档放入 ./laozi_source_docs/ 目录（支持 .txt / .md）
  2. 运行: python3 scripts/setup_knowledge_base.py
  3. 向量库生成到 ./laozi_knowledge_base/

文档命名规范（用于自动提取元数据）：
  - 原文:  <版本>_第<章>_<可选说明>.txt
          例: 王弼注本_第01章.txt / 马王堆帛书甲本_第01章.txt
  - 注释:  注释_<书名>_<章节>.txt
          例: 注释_陈鼓应_第01章.txt
  - 研究:  研究_<主题>.txt
          例: 研究_道论.txt / 研究_无为而治.txt

也可在文档头部用 YAML frontmatter 手动指定元数据：
  ---
  type: 原文
  version: 王弼注本
  chapter: 1
  title: 道德经
  ---
  道可道，非常道...
"""

import os
import re
import sys
from pathlib import Path

try:
    from langchain_chroma import Chroma
    from langchain_openai import OpenAIEmbeddings
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain_community.document_loaders import DirectoryLoader, TextLoader
except ImportError:
    print("缺少依赖，请先安装：")
    print("  pip install langchain langchain-openai langchain-community chromadb")
    sys.exit(1)

# ──────────────────────────────────────────────
# 配置
# ──────────────────────────────────────────────
SOURCE_DIR = os.getenv("LAOZI_SOURCE_DIR", "./laozi_source_docs")
PERSIST_DIR = os.getenv("LAOZI_PERSIST_DIR", "./laozi_knowledge_base")
COLLECTION_NAME = os.getenv("LAOZI_COLLECTION", "laozi_collection")
EMBEDDING_MODEL = os.getenv("LAOZI_EMBEDDING_MODEL", "text-embedding-3-large")

# 古文分块：按段落/章节切分，保持语义完整
CHUNK_SIZE = 400
CHUNK_OVERLAP = 50

# ──────────────────────────────────────────────
# 元数据解析
# ──────────────────────────────────────────────
def parse_filename_metadata(filename: str) -> dict:
    """从文件名推断元数据。"""
    name = Path(filename).stem
    meta = {"source": filename}

    # 研究类
    m = re.match(r"研究[_\-](.+)", name)
    if m:
        return {**meta, "type": "研究", "topic": m.group(1)}

    # 注释类
    m = re.match(r"注释[_\-](.+?)[_\-]第(\d+)章", name)
    if m:
        return {**meta, "type": "注释", "title": m.group(1), "chapter": m.group(2)}

    # 原文类
    m = re.match(r"(.+?)[_\-]第(\d+)章", name)
    if m:
        return {**meta, "type": "原文", "version": m.group(1), "chapter": m.group(2)}

    return meta


def parse_frontmatter(text: str) -> tuple:
    """解析 YAML frontmatter，返回 (metadata_dict, body_text)。"""
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            fm_text = parts[1].strip()
            body = parts[2].strip()
            meta = {}
            for line in fm_text.split("\n"):
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip()
            return meta, body
    return {}, text


# ──────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────
def main():
    source_path = Path(SOURCE_DIR)
    if not source_path.exists():
        print(f"源文档目录不存在: {SOURCE_DIR}")
        print(f"请创建目录并放入《道德经》相关文档：")
        print(f"  mkdir -p {SOURCE_DIR}")
        print(f"  将 .txt / .md 文件放入 {SOURCE_DIR}/")
        print(f"\n命名规范见脚本顶部注释。")
        sys.exit(1)

    print(f"📂 加载文档: {SOURCE_DIR}")
    loader = DirectoryLoader(
        SOURCE_DIR,
        glob="**/*.{txt,md}",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"},
    )
    raw_docs = loader.load()
    print(f"   找到 {len(raw_docs)} 个文件")

    if not raw_docs:
        print("❌ 未找到任何文档，请检查目录内容。")
        sys.exit(1)

    # 注入元数据
    for doc in raw_docs:
        source_file = doc.metadata.get("source", "")
        filename = os.path.basename(source_file)

        # 尝试 frontmatter
        fm, body = parse_frontmatter(doc.page_content)
        if fm:
            doc.page_content = body
            doc.metadata.update(fm)
        else:
            # 从文件名推断
            doc.metadata.update(parse_filename_metadata(filename))

    # 分块
    print(f"✂️  分块 (size={CHUNK_SIZE}, overlap={CHUNK_OVERLAP})")
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", "。", "；", "，", " ", ""],
    )
    chunks = splitter.split_documents(raw_docs)
    print(f"   生成 {len(chunks)} 个文本块")

    # 构建向量库
    print(f"🔢 构建向量库 (model={EMBEDDING_MODEL})")
    embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)
    db = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=PERSIST_DIR,
        collection_name=COLLECTION_NAME,
    )
    print(f"✅ 知识库构建完成: {PERSIST_DIR}")
    print(f"   集合: {COLLECTION_NAME}")
    print(f"   文档数: {len(chunks)}")


if __name__ == "__main__":
    main()
