# 📖 老子智能体 — 用户手册与部署教程

## 目录

- [项目简介](#项目简介)
- [功能概览](#功能概览)
- [系统要求](#系统要求)
- [快速安装](#快速安装)
- [本地部署](#本地部署)
- [服务器部署](#服务器部署)
- [GitLab Spaces 部署](#gitlab-spaces-部署)
- [Docker 部署](#docker-部署)
- [环境变量配置](#环境变量配置)
- [知识库管理](#知识库管理)
- [使用指南](#使用指南)
- [常见问题](#常见问题)
- [故障排查](#故障排查)

---

## 项目简介

老子智能体是一个基于 RAG（检索增强生成）技术的《道德经》问答系统。它以春秋时期思想家老子（李耳）的身份，回答关于道家思想和《道德经》的问题。

**核心特点：**
- 🆓 **全免费** — 无需任何 API Key，开箱即用
- 🧠 **RAG 架构** — 基于向量检索，回答有据可查
- 📚 **多版本** — 支持帛书甲本、王弼本等多版本原文
- 💬 **对话记忆** — 支持多轮对话，保持上下文连贯
- 🌐 **Web 界面** — Gradio 构建，美观易用

---

## 功能概览

### 💬 问道老子
以老子身份回答问题，自动引用《道德经》原文，标注引用来源。

### 📖 版本对比
选择任意章节（1-81），对比帛书甲本与王弼本的原文差异。

### 🧭 主题导航
按思想主题浏览：道论、德论、无为而治、辩证思维、柔弱胜刚强、知足常乐、返璞归真、生死观。

---

## 系统要求

| 项目 | 最低要求 | 推荐配置 |
|------|---------|---------|
| Python | 3.9+ | 3.11+ |
| 内存 | 4 GB | 8 GB+ |
| 磁盘 | 2 GB | 5 GB+ |
| CPU | 2 核 | 4 核+ |
| GPU | 不需要 | 不需要（CPU 推理） |

> ⚠️ 首次启动会下载 Embedding 模型（约 400 MB），需要网络连接。

---

## 快速安装

### 方式一：OpenClaw Skill 安装（推荐）

```bash
clawhub install laozi-agent
```

### 方式二：Git 克隆

```bash
git clone https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao.git
cd opendao
```

### 方式三：下载源码

从 [GitLab Releases](https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao/-/releases) 下载最新版本。

---

## 本地部署

### 1. 创建虚拟环境（推荐）

```bash
python3 -m venv venv
source venv/bin/activate    # Linux/macOS
# venv\Scripts\activate     # Windows
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

> 💡 国内用户建议使用镜像源加速：
> ```bash
> pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
> ```

### 3. 启动 Web 界面

```bash
python3 app.py
```

首次启动会：
1. 自动下载 Embedding 模型（约 400 MB，仅首次）
2. 自动构建向量知识库（约 2-3 分钟，仅首次）
3. 启动 Gradio Web 服务

浏览器打开 `http://localhost:7860` 即可使用。

### 4. 命令行模式（可选）

```bash
python3 scripts/laozi_agent.py
```

进入交互式问答，输入 `exit` 退出。

---

## 服务器部署

### 使用 systemd（推荐）

创建服务文件 `/etc/systemd/system/laozi-agent.service`：

```ini
[Unit]
Description=Laozi Agent - RAG Q&A System
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/laozi-agent
ExecStart=/opt/laozi-agent/venv/bin/python3 app.py
Restart=always
RestartSec=10
Environment="LAOZI_TEMPERATURE=0.3"
Environment="LAOZI_RETRIEVAL_K=5"

[Install]
WantedBy=multi-user.target
```

启动服务：

```bash
sudo systemctl daemon-reload
sudo systemctl enable laozi-agent
sudo systemctl start laozi-agent
sudo systemctl status laozi-agent
```

### 使用 Supervisor

```ini
[program:laozi-agent]
command=/opt/laozi-agent/venv/bin/python3 /opt/laozi-agent/app.py
directory=/opt/laozi-agent
user=www-data
autostart=true
autorestart=true
stderr_logfile=/var/log/laozi-agent.err.log
stdout_logfile=/var/log/laozi-agent.out.log
```

### Nginx 反向代理

```nginx
server {
    listen 80;
    server_name laozi.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:7860;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read 86400s;
    }
}
```

---

## GitLab Spaces 部署

### 1. 创建 Space

1. 登录 [超算互联网](https://gitlab.scnet.cn:9002)
2. 创建新 Space，选择 **Static** 类型
3. 克隆 Space 仓库

### 2. 推送代码

```bash
git lfs install
git clone https://gitlab.scnet.cn:9002/space/YOUR_USERNAME/YOUR_SPACE.git
cd YOUR_SPACE

# 复制老子智能体文件
cp -r /path/to/laozi-agent/* .

# 提交推送
git add -A
git commit -m "deploy laozi-agent"
git push
```

### 3. 注意事项

- GitLab Spaces 的 Static 类型只识别**根目录**的 `index.html`
- 如需前端部署，将 `app.py` 的 Gradio 界面替换为静态前端
- 后端需要单独部署到有 Python 环境的服务器

---

## Docker 部署

### Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# 安装 Python 依赖
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 复制源码
COPY . .

# 暴露端口
EXPOSE 7860

# 启动
CMD ["python3", "app.py"]
```

### 构建与运行

```bash
# 构建镜像
docker build -t laozi-agent .

# 运行容器
docker run -d \
  --name laozi-agent \
  -p 7860:7860 \
  -v laozi-kb:/app/laozi_knowledge_base \
  laozi-agent

# 查看日志
docker logs -f laozi-agent
```

### Docker Compose

```yaml
version: '3.8'

services:
  laozi-agent:
    build: .
    ports:
      - "7860:7860"
    volumes:
      - laozi-kb:/app/laozi_knowledge_base
    environment:
      - LAOZI_TEMPERATURE=0.3
      - LAOZI_RETRIEVAL_K=5
    restart: unless-stopped

volumes:
  laozi-kb:
```

---

## 环境变量配置

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| `LAOZI_EMBEDDING_MODEL` | `BAAI/bge-base-zh-v1.5` | Embedding 模型名称 |
| `LAOZI_LLM_MODEL` | `Qwen/Qwen2.5-72B-Instruct` | LLM 模型名称 |
| `LAOZI_TEMPERATURE` | `0.3` | 生成温度（0.0-1.0，越低越严谨） |
| `LAOZI_RETRIEVAL_K` | `5` | 检索返回文档数 |
| `LAOZI_FETCH_K` | `20` | MMR 候选池大小 |
| `LAOZI_PERSIST_DIR` | `./laozi_knowledge_base` | 向量库存储目录 |
| `LAOZI_COLLECTION` | `laozi_collection` | Chroma 集合名称 |
| `LAOZI_SOURCE_DIR` | `./laozi-agent/laozi_source_docs` | 源文档目录 |
| `HF_TOKEN` | (空) | HuggingFace Token（可选，提高速率限制） |

### 配置示例

```bash
# 使用 .env 文件
cat > .env << EOF
LAOZI_TEMPERATURE=0.1
LAOZI_RETRIEVAL_K=8
HF_TOKEN=hf_xxxxxxxxxxxxx
EOF

# 或直接导出
export LAOZI_TEMPERATURE=0.1
python3 app.py
```

---

## 知识库管理

### 查看当前知识库

```bash
ls ./laozi_knowledge_base/
```

### 重新构建知识库

```bash
# 删除旧库
rm -rf ./laozi_knowledge_base

# 重启应用（自动重建）
python3 app.py
```

### 添加新文本

1. 将 `.txt` 文件放入 `laozi_source_docs/` 目录
2. 建议使用子目录分类（如 `帛书乙本/`、`河上公注本/`）
3. 删除向量库目录，重启应用

### 文本格式建议

纯文本文件，章节内容以 `第X章` 开头：

```
第1章
道可道，非常道。名可名，非常名。
无名天地之始，有名万物之母。
```

---

## 使用指南

### 问道老子

1. 打开 Web 界面，进入「问道老子」标签
2. 输入问题，如：
   - "什么是道？"
   - "如何看待无为而治？"
   - "上善若水是什么意思？"
3. 老子会引用原文并解答
4. 底部显示引用来源

### 版本对比

1. 进入「版本对比」标签
2. 输入章节号（1-81）
3. 查看不同版本的原文差异

### 主题导航

1. 进入「主题导航」标签
2. 选择感兴趣的主题
3. 浏览相关内容

---

## 常见问题

### Q: 首次启动很慢？

A: 首次需要下载 Embedding 模型（约 400 MB）并构建向量库（约 2-3 分钟）。后续启动会直接加载缓存，几秒内完成。

### Q: 如何更换 LLM？

A: 设置环境变量 `LAOZI_LLM_MODEL`，支持 HuggingFace 上的任何 Instruct 模型：

```bash
export LAOZI_LLM_MODEL="Qwen/Qwen2.5-32B-Instruct"
```

### Q: 内存不足怎么办？

A: 尝试：
1. 使用更小的 Embedding 模型
2. 减小 `LAOZI_FETCH_K` 值
3. 使用 GPU 加速（需安装 CUDA 版 PyTorch）

### Q: 如何提高回答质量？

A: 
1. 降低温度 `LAOZI_TEMPERATURE=0.1`
2. 增加检索数 `LAOZI_RETRIEVAL_K=8`
3. 补充更多知识库文本

### Q: 支持哪些语言？

A: 主要支持中文。问题可用中文或英文提问，回答默认为中文。

---

## 故障排查

### 向量库构建失败

```bash
# 检查源文档目录
ls ./laozi_source_docs/

# 检查磁盘空间
df -h

# 查看详细日志
python3 app.py 2>&1 | tee build.log
```

### 模型下载失败

```bash
# 使用 HuggingFace 镜像
export HF_ENDPOINT=https://hf-mirror.com
python3 app.py
```

### 端口被占用

```bash
# 查找占用进程
lsof -i :7860

# 或使用其他端口
python3 -c "import app; app.demo.launch(server_port=7861)"
```

### LangChain 版本冲突

```bash
pip install --upgrade langchain langchain-community langchain-chroma
```

---

## 获取帮助

- 📧 邮件：aaroncxxx@gitlab.scnet.cn
- 🐛 问题反馈：[GitLab Issues](https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao/-/issues)
- 💬 社区讨论：[GitLab Discussions](https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao/-/discussions)
- 📦 ClawHub：`clawhub install laozi-agent`
