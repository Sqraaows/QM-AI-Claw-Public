# 🔌 老子智能体 — API 文档

## 目录

- [概述](#概述)
- [Python SDK](#python-sdk)
- [HTTP API](#http-api)
- [Gradio API](#gradio-api)
- [错误处理](#错误处理)
- [性能调优](#性能调优)

---

## 概述

老子智能体提供三种集成方式：

| 方式 | 适用场景 | 认证 |
|------|---------|------|
| Python SDK | 直接导入，本地调用 | 无需 |
| HTTP API | 远程调用，微服务集成 | 无需（内网）/ Token（公网） |
| Gradio API | Web UI 自动化 | 无需 |

---

## Python SDK

### 安装

```bash
pip install langchain langchain-chroma chromadb sentence-transformers huggingface_hub
```

### 基础用法

```python
from scripts.laozi_agent import laozi_skill, compare_versions, get_topics, get_topic_content
```

### `laozi_skill(question)` — 问答

以老子身份回答问题。

**参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `question` | `str` | ✅ | 用户问题 |

**返回值：**

```python
{
    "answer": "老子的回答...",
    "sources": [
        {
            "title": "道德经",
            "chapter": "1",
            "version": "王弼本",
            "page": "未知"
        }
    ]
}
```

**示例：**

```python
result = laozi_skill("什么是道？")
print(result["answer"])
print(result["sources"])
```

### `compare_versions(chapter)` — 版本对比

对比同一章节的不同版本原文。

**参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `chapter` | `int` | ✅ | 章节号（1-81） |

**返回值：**

```python
{
    "郭店楚简本": "...",
    "马王堆帛书甲本": "...",
    "马王堆帛书乙本": "...",
    "王弼注本": "...",
    "河上公注本": "..."
}
```

> 注意：未找到的版本不会出现在返回字典中。

**示例：**

```python
versions = compare_versions(1)
for name, content in versions.items():
    print(f"=== {name} ===")
    print(content)
    print()
```

### `get_topics()` — 获取主题列表

**返回值：** `list[str]`

```python
["道论", "德论", "无为而治", "辩证思维", "柔弱胜刚强", "知足常乐", "返璞归真", "生死观"]
```

### `get_topic_content(topic)` — 获取主题内容

**参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `topic` | `str` | ✅ | 主题名 |

**返回值：** `str`（拼接后的主题内容文本）

**示例：**

```python
content = get_topic_content("无为而治")
print(content)
```

---

## HTTP API

> ⚠️ 需要额外启动 HTTP 服务。当前版本使用 Gradio 内置 API。

### 启动 API 服务

Gradio 启动后自动暴露 HTTP API。

```bash
python3 app.py
# API 地址: http://localhost:7860/api/
```

### 端点列表

#### `POST /api/chat` — 问答接口

**请求：**

```json
{
    "data": ["什么是道？"]
}
```

**响应：**

```json
{
    "data": ["老子的回答...\n\n📚 引用：王弼本 第1章"]
}
```

**curl 示例：**

```bash
curl -X POST http://localhost:7860/api/chat \
  -H "Content-Type: application/json" \
  -d '{"data": ["什么是道？"]}'
```

#### `POST /api/compare` — 版本对比

**请求：**

```json
{
    "data": [1]
}
```

**响应：**

```json
{
    "data": ["## 《道德经》第1章 多版本对照\n\n### 📜 帛书甲本\n\n...\n\n### 📜 王弼本\n\n..."]
}
```

#### `POST /api/topic` — 主题导航

**请求：**

```json
{
    "data": ["道论"]
}
```

**响应：**

```json
{
    "data": ["主题相关内容..."]
}
```

---

## Gradio API

### Python 客户端

```python
from gradio_client import Client

client = Client("http://localhost:7860")

# 问答
result = client.predict(
    message="什么是道？",
    api_name="/chat"
)
print(result)

# 版本对比
result = client.predict(
    chapter_num=1,
    api_name="/compare"
)
print(result)

# 主题导航
result = client.predict(
    topic="道论",
    api_name="/topic"
)
print(result)
```

### JavaScript 客户端

```javascript
import { Client } from "@gradio/client";

const client = await Client.connect("http://localhost:7860");

// 问答
const result = await client.predict("/chat", {
    message: "什么是道？"
});
console.log(result.data);
```

---

## 错误处理

### 错误响应格式

```json
{
    "error": "错误描述",
    "code": "ERROR_CODE"
}
```

### 常见错误码

| 错误码 | 说明 | 解决方案 |
|--------|------|---------|
| `KB_NOT_FOUND` | 向量库未构建 | 删除 `laozi_knowledge_base/` 重启 |
| `MODEL_LOAD_FAILED` | 模型加载失败 | 检查网络，重试 |
| `INVALID_CHAPTER` | 章节号无效 | 使用 1-81 的整数 |
| `EMPTY_QUERY` | 空查询 | 提供非空问题 |
| `LLM_TIMEOUT` | LLM 响应超时 | 增加超时或换用更快模型 |

### Python 异常处理

```python
from scripts.laozi_agent import laozi_skill

try:
    result = laozi_skill("什么是道？")
    print(result["answer"])
except FileNotFoundError:
    print("向量库未构建，请先运行 build_knowledge_base()")
except Exception as e:
    print(f"调用失败: {e}")
```

---

## 性能调优

### 检索参数调优

```python
# 更多结果，更高召回率
RETRIEVAL_K = 8
FETCH_K = 30

# 更少结果，更快响应
RETRIEVAL_K = 3
FETCH_K = 10
```

### 温度参数

| 值 | 效果 |
|------|------|
| 0.0 | 最严谨，几乎确定性输出 |
| 0.1 | 推荐，低幻觉 |
| 0.3 | 默认，平衡 |
| 0.7 | 更有创意，但可能不准 |
| 1.0 | 最随机，不推荐 |

### 批量调用优化

```python
# 避免重复初始化
from scripts.laozi_agent import laozi_skill

questions = ["什么是道？", "什么是德？", "无为是什么？"]
results = [laozi_skill(q) for q in questions]
```

---

## 扩展开发

### 自定义 Prompt

```python
from scripts.laozi_agent import laozi_qa_chain, laozi_prompt

# 修改 Prompt 模板
custom_prompt = laozi_prompt.template.replace(
    "你是李耳",
    "你是老子的弟子，传承老子思想"
)
```

### 集成到其他框架

```python
# Flask 集成
from flask import Flask, request, jsonify
from scripts.laozi_agent import laozi_skill

app = Flask(__name__)

@app.route("/ask", methods=["POST"])
def ask():
    question = request.json.get("question", "")
    result = laozi_skill(question)
    return jsonify(result)

if __name__ == "__main__":
    app.run(port=5000)
```

```python
# FastAPI 集成
from fastapi import FastAPI
from pydantic import BaseModel
from scripts.laozi_agent import laozi_skill

app = FastAPI()

class Question(BaseModel):
    text: str

@app.post("/ask")
async def ask(q: Question):
    return laozi_skill(q.text)
```
