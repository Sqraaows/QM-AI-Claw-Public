# 老子智能体 SKILL

基于 LangChain + Chroma 向量数据库的 RAG 问答系统，以春秋时期思想家老子（李耳）的身份回答关于《道德经》和道家思想的问题。

## 功能

- **问答** — 以老子身份回答，引用《道德经》原文，返回来源
- **版本对比** — 对比同一章节的多版本原文（帛书甲本、王弼本等）
- **主题导航** — 按思想主题检索相关内容（道论、德论、无为而治等）
- **对话记忆** — 支持多轮对话，保持上下文连贯

## 快速开始

### 1. 安装依赖

```bash
pip install langchain langchain-openai langchain-community chromadb tiktoken
```

### 2. 设置环境变量

```bash
export OPENAI_API_KEY="sk-your-key"
```

### 3. 构建知识库

```bash
python3 scripts/setup_knowledge_base.py
```

### 4. 启动问答

```bash
python3 scripts/laozi_agent.py
```

## 目录结构

```
laozi-agent/
├── SKILL.md                          # OpenClaw skill 主文档
├── README.md                         # 本文件
├── CHANGELOG.md                      # 版本说明
├── laozi_source_docs/                # 知识库源文档
│   ├── 帛书甲本/                     # 马王堆帛书甲本 81 章
│   │   ├── 第01章.txt
│   │   └── ...
│   └── 王弼本/                       # 王弼传世本 81 章
│       ├── 第01章.txt
│       └── ...
├── scripts/
│   ├── laozi_agent.py                # 核心代码（问答/对比/导航）
│   ├── setup_knowledge_base.py       # 向量库构建脚本
│   └── build_kb.py                   # 原始文本拆分工具
└── references/
    └── knowledge_base_booklist.md    # 书单 + 文档格式规范
```

## 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `OPENAI_API_KEY` | (必填) | OpenAI API 密钥 |
| `LAOZI_EMBEDDING_MODEL` | `text-embedding-3-large` | 向量模型 |
| `LAOZI_LLM_MODEL` | `gpt-4o` | 生成模型 |
| `LAOZI_TEMPERATURE` | `0.1` | 温度参数 |
| `LAOZI_RETRIEVAL_K` | `5` | 返回文档数 |
| `LAOZI_FETCH_K` | `20` | MMR 候选池大小 |
| `LAOZI_PERSIST_DIR` | `./laozi_knowledge_base` | 向量库目录 |
| `LAOZI_COLLECTION` | `laozi_collection` | 集合名 |

## 知识库来源

### 已入库

- **帛书甲本** — 马王堆汉墓帛书甲本，约公元前 180 年，81 章全文
- **王弼本** — 三国魏王弼注本，流传最广的传世本，81 章全文

### 待补充

- 帛书乙本、郭店楚简本、傅奕本、河上公注本
- 《黄帝四经》（经法、十大经、称、道原）
- 《老子古今》（刘笑敢，五种对勘与析评引论）

将 `.txt` 文件按命名规范放入 `laozi_source_docs/` 后，重新运行 `setup_knowledge_base.py` 即可更新向量库。

## 文档命名规范

```
原文:   <版本名>/第<章号>.txt    例: 帛书甲本/第01章.txt
注释:   注释_<书名>/第<章号>.txt  例: 注释_陈鼓应/第01章.txt
研究:   研究_<主题>.txt           例: 研究_道论.txt
```

每个文件需包含 YAML frontmatter：

```yaml
---
type: 原文        # 原文 / 注释 / 研究
version: 帛书甲本  # 版本名
chapter: 1        # 章节号
title: 道德经      # 书名
---
```

## API 使用

```python
from scripts.laozi_agent import laozi_skill, compare_versions, get_topics, get_topic_content

# 问答
result = laozi_skill("什么是道？")
print(result["answer"])

# 版本对比
versions = compare_versions(1)

# 主题导航
topics = get_topics()
content = get_topic_content("道论")
```

## License

本 skill 代码采用 MIT License。《道德经》原文为公共领域古籍。
