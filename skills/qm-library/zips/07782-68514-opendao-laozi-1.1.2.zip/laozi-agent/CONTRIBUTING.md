# 🤝 贡献指南

感谢你对老子智能体项目的关注！我们欢迎各种形式的贡献。

## 目录

- [如何贡献](#如何贡献)
- [开发环境](#开发环境)
- [代码规范](#代码规范)
- [提交规范](#提交规范)
- [分支策略](#分支策略)
- [知识库贡献](#知识库贡献)
- [Issue 规范](#issue-规范)
- [PR 规范](#pr-规范)

---

## 如何贡献

| 贡献类型 | 说明 |
|---------|------|
| 🐛 Bug 修复 | 修复已知问题 |
| ✨ 新功能 | 添加新能力 |
| 📚 知识库 | 补充道德经版本、注释、研究资料 |
| 📖 文档 | 完善文档、修正错误 |
| 🎨 UI/UX | 改进界面设计和用户体验 |
| ⚡ 性能 | 优化检索速度、内存占用等 |
| 🌐 国际化 | 多语言支持 |

---

## 开发环境

### 1. Fork & Clone

```bash
# Fork 仓库后克隆
git clone https://gitlab.scnet.cn:9002/YOUR_USERNAME/opendao.git
cd opendao
```

### 2. 创建虚拟环境

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt

# 开发依赖（可选）
pip install pytest ruff black mypy
```

### 4. 验证环境

```bash
python3 -c "from scripts.laozi_agent import laozi_skill; print('OK')"
```

---

## 代码规范

### Python 代码风格

- 遵循 [PEP 8](https://peps.python.org/pep-0008/)
- 使用 4 空格缩进，不用 Tab
- 行宽限制 100 字符
- 使用 type hints

### 命名规范

| 类型 | 规范 | 示例 |
|------|------|------|
| 变量/函数 | snake_case | `laozi_skill`, `build_kb` |
| 类 | PascalCase | `LaoziAgent` |
| 常量 | UPPER_SNAKE_CASE | `EMBEDDING_MODEL` |
| 私有函数 | 前缀 `_` | `_format_answer` |

### 文档字符串

```python
def laozi_skill(question: str) -> dict:
    """
    老子智能体主函数。

    以老子身份回答用户关于《道德经》和道家思想的问题，
    自动检索相关原文并生成回答。

    Args:
        question: 用户提出的问题

    Returns:
        包含 answer 和 sources 的字典

    Raises:
        FileNotFoundError: 向量库未构建时抛出
    """
```

### 格式化工具

```bash
# 格式化
black .

# 检查
ruff check .

# 类型检查
mypy scripts/
```

---

## 提交规范

### Commit Message 格式

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Type 类型

| 类型 | 说明 | 示例 |
|------|------|------|
| `feat` | 新功能 | `feat(agent): 添加流式输出` |
| `fix` | Bug 修复 | `fix(retriever): 修复空结果崩溃` |
| `docs` | 文档 | `docs: 补充 API 文档` |
| `style` | 格式 | `style: 格式化代码` |
| `refactor` | 重构 | `refactor(prompt): 优化 Prompt 结构` |
| `perf` | 性能 | `perf(embedding): 优化向量检索速度` |
| `test` | 测试 | `test: 添加单元测试` |
| `chore` | 杂项 | `chore: 更新依赖` |
| `kb` | 知识库 | `kb(帛书乙本): 添加帛书乙本全文` |

### 示例

```
feat(agent): 添加帛书乙本版本对比支持

- 新增帛书乙本文本文件
- 更新 compare_versions 函数
- 修改版本列表

Closes #12
```

---

## 分支策略

```
main          ← 稳定版本，可直接部署
├── develop   ← 开发分支，功能合并到这里
├── feat/xxx  ← 功能分支
├── fix/xxx   ← 修复分支
└── kb/xxx    ← 知识库更新分支
```

### 分支命名

| 类型 | 格式 | 示例 |
|------|------|------|
| 功能 | `feat/功能名` | `feat/streaming-output` |
| 修复 | `fix/问题描述` | `fix/empty-result-crash` |
| 知识库 | `kb/版本名` | `kb/boshuyiben` |
| 文档 | `docs/文档名` | `docs/api-reference` |

---

## 知识库贡献

### 添加新版本

1. 在 `laozi_source_docs/` 下创建版本目录：

```
laozi_source_docs/
├── 帛书甲本/
├── 王弼本/
└── 你的版本名/    ← 新增
    ├── 第01章.txt
    ├── 第02章.txt
    └── ...
```

2. 文本文件格式：

```txt
第1章
道可道，非常道。名可名，非常名。
无名天地之始，有名万物之母。
故常无欲以观其妙，常有欲以观其徼。
此两者同出而异名，同谓之玄。玄之又玄，众妙之门。
```

3. 删除向量库，重新构建：

```bash
rm -rf ./laozi_knowledge_base
python3 app.py
```

### 添加注释/研究资料

在文本文件中使用 frontmatter 格式添加元数据：

```txt
---
type: 注释
title: 老子道德经注
author: 王弼
chapter: 1
topic: 道论
---

道可道，非常道。
王弼注：可道之道，可名之名，指事造形，非其常也...
```

---

## Issue 规范

### Bug 报告

使用 [Bug Report 模板](.github/ISSUE_TEMPLATE/bug_report.md)，包含：

- 问题描述
- 复现步骤
- 期望行为
- 实际行为
- 环境信息
- 日志/截图

### 功能请求

使用 [Feature Request 模板](.github/ISSUE_TEMPLATE/feature_request.md)，包含：

- 功能描述
- 使用场景
- 实现建议（可选）

---

## PR 规范

### PR 标题

遵循 Commit Message 格式：

```
feat(agent): 添加帛书乙本支持
```

### PR 要求

- [ ] 代码遵循项目规范
- [ ] 包含必要的测试
- [ ] 文档已更新（如适用）
- [ ] Commit 历史清晰
- [ ] 无合并冲突

### PR 流程

1. Fork 仓库
2. 创建功能分支
3. 编写代码和测试
4. 确保 CI 通过
5. 提交 PR
6. 等待 Code Review
7. 合并到 `develop`

### PR 描述模板

```markdown
## 变更说明

简要描述此 PR 的变更内容。

## 变更类型

- [ ] 新功能
- [ ] Bug 修复
- [ ] 文档更新
- [ ] 知识库更新
- [ ] 性能优化
- [ ] 重构

## 测试

说明如何测试这些变更。

## 关联 Issue

Closes #xxx
```

---

## Code Review

### Reviewer 检查项

- [ ] 代码逻辑正确
- [ ] 符合项目规范
- [ ] 无安全风险
- [ ] 性能可接受
- [ ] 文档完整

### Review 反馈

- 使用建设性语言
- 说明问题原因
- 提供改进建议
- 区分必须修改和建议修改

---

## 社区行为准则

- 尊重每位贡献者
- 接受建设性批评
- 专注于对社区最有利的事情
- 对他人表示同理心

---

## 问题？

如有疑问，请通过以下方式联系：

- 📧 邮件：aaroncxxx@gitlab.scnet.cn
- 💬 [GitLab Discussions](https://gitlab.scnet.cn:9002/space/aaroncxxx/opendao/-/discussions)
