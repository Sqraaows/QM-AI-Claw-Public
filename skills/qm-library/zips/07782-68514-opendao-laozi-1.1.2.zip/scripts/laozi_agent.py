#!/usr/bin/env python3
"""
老子智能体 — 基于 LangChain + Chroma 的 RAG 问答系统（OpenAI 版）
以老子（李耳）身份回答关于《道德经》和道家思想的问题

⚠️ 需要 OPENAI_API_KEY 环境变量
"""

import os
from typing import Optional

from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory

# ──────────────────────────────────────────────
# 配置项（按需修改）
# ──────────────────────────────────────────────
EMBEDDING_MODEL = os.getenv("LAOZI_EMBEDDING_MODEL", "text-embedding-3-large")
LLM_MODEL = os.getenv("LAOZI_LLM_MODEL", "gpt-4o")
TEMPERATURE = float(os.getenv("LAOZI_TEMPERATURE", "0.1"))
RETRIEVAL_K = int(os.getenv("LAOZI_RETRIEVAL_K", "5"))
FETCH_K = int(os.getenv("LAOZI_FETCH_K", "20"))
PERSIST_DIR = os.getenv("LAOZI_PERSIST_DIR", "./laozi_knowledge_base")
COLLECTION_NAME = os.getenv("LAOZI_COLLECTION", "laozi_collection")

# ──────────────────────────────────────────────
# 初始化向量数据库
# ──────────────────────────────────────────────
embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)

vector_db = Chroma(
    persist_directory=PERSIST_DIR,
    embedding_function=embeddings,
    collection_name=COLLECTION_NAME,
)

# ──────────────────────────────────────────────
# 检索器（MMR：兼顾相关性与多样性）
# ──────────────────────────────────────────────
retriever = vector_db.as_retriever(
    search_type="mmr",
    search_kwargs={"k": RETRIEVAL_K, "fetch_k": FETCH_K},
)

# ──────────────────────────────────────────────
# 老子专属 Prompt
# ──────────────────────────────────────────────
LAOZI_PROMPT_TEMPLATE = """
你是李耳，人称老子，春秋时期的伟大思想家，道家学派的创始人。你生活在公元前6世纪，曾担任周朝守藏室之史，博览群书，洞察世事。

### 你的身份与原则
1. 你只谈论与老子思想相关的内容，不涉及后世道教的神仙体系和宗教仪式
2. 你所有的回答都必须基于提供的上下文，严禁编造内容
3. 当用户的问题超出你的知识范围时，坦诚地说"吾不知也"
4. 你的语言风格要简洁、深邃、富有哲理，符合老子的说话方式
5. 你会先引用《道德经》中的原文，然后再进行解释和发挥

### 回答流程
1. 首先从上下文中找到最相关的《道德经》原文
2. 准确解释原文的本义，避免过度解读
3. 结合用户的问题，阐述老子思想在这个问题上的观点
4. 如果有不同版本的差异，简要说明
5. 最后用一句富有哲理的话总结

### 对话历史
{history}

### 参考上下文
{context}

### 用户问题
{question}

现在，请以老子的身份回答用户的问题：
"""

laozi_prompt = PromptTemplate(
    input_variables=["context", "question", "history"],
    template=LAOZI_PROMPT_TEMPLATE,
)

# ──────────────────────────────────────────────
# 对话记忆
# ──────────────────────────────────────────────
memory = ConversationBufferMemory(
    memory_key="history",
    input_key="question",
    return_messages=True,
)

# ──────────────────────────────────────────────
# 检索问答链
# ──────────────────────────────────────────────
laozi_qa_chain = RetrievalQA.from_chain_type(
    llm=ChatOpenAI(model=LLM_MODEL, temperature=TEMPERATURE),
    chain_type="stuff",
    retriever=retriever,
    chain_type_kwargs={"prompt": laozi_prompt, "memory": memory},
    return_source_documents=True,
)


# ──────────────────────────────────────────────
# SKILL 函数
# ──────────────────────────────────────────────
def laozi_skill(question: str) -> dict:
    """
    老子智能体主函数：回答用户关于老子思想和《道德经》的问题。

    Args:
        question: 用户的问题

    Returns:
        {"answer": str, "sources": list[dict]}
    """
    result = laozi_qa_chain({"query": question})

    sources = []
    for doc in result["source_documents"]:
        sources.append({
            "title": doc.metadata.get("title", "未知"),
            "chapter": doc.metadata.get("chapter", "未知"),
            "version": doc.metadata.get("version", "未知"),
            "page": doc.metadata.get("page", "未知"),
        })

    return {"answer": result["result"], "sources": sources}


def compare_versions(chapter: int) -> dict:
    """
    对比《道德经》同一章节的不同版本原文。

    Args:
        chapter: 章节号

    Returns:
        {版本名: 原文内容} 字典
    """
    versions = [
        "郭店楚简本",
        "马王堆帛书甲本",
        "马王堆帛书乙本",
        "王弼注本",
        "河上公注本",
    ]
    result = {}

    for version in versions:
        docs = vector_db.similarity_search(
            f"《道德经》第{chapter}章 {version}",
            filter={"type": "原文", "version": version},
            k=1,
        )
        if docs:
            result[version] = docs[0].page_content

    return result


def get_topics() -> list:
    """获取老子思想的主要主题列表。"""
    return [
        "道论", "德论", "无为而治", "辩证思维",
        "柔弱胜刚强", "知足常乐", "返璞归真", "生死观",
    ]


def get_topic_content(topic: str) -> str:
    """
    获取某个思想主题的相关内容。

    Args:
        topic: 主题名（如"道论"、"无为而治"）

    Returns:
        拼接后的主题内容文本
    """
    docs = vector_db.similarity_search(
        topic,
        filter={"type": "研究", "topic": topic},
        k=3,
    )
    return "\n\n".join([doc.page_content for doc in docs])


# ──────────────────────────────────────────────
# 交互式入口
# ──────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 50)
    print("老子智能体（OpenAI 版）— 请问老子（输入 exit 退出）")
    print("=" * 50)

    while True:
        user_question = input("\n请问老子：").strip()
        if not user_question:
            continue
        if user_question.lower() in ("exit", "quit", "退出"):
            print("善哉，后会有期。")
            break

        response = laozi_skill(user_question)

        print("\n老子曰：")
        print(response["answer"])

        if response["sources"]:
            print("\n引用来源：")
            for src in response["sources"]:
                parts = []
                if src["title"] != "未知":
                    parts.append(src["title"])
                if src["chapter"] != "未知":
                    parts.append(f"第{src['chapter']}章")
                if src["version"] != "未知":
                    parts.append(src["version"])
                print(f"- {' | '.join(parts) if parts else '未知来源'}")

        print("-" * 50)
