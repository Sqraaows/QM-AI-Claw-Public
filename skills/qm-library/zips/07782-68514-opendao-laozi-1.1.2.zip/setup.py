#!/usr/bin/env python3
"""
老子智能体 — 傻瓜式一键配置脚本

两种方案：
  方案一：OpenAI 版（效果更好，需要 API Key）
  方案二：免费版（无需 API Key，本地运行）

用法：
  python3 setup.py          # 交互式引导
  python3 setup.py --auto   # 自动检测，跳过交互
  python3 setup.py --help   # 查看帮助
"""

import os
import sys
import json
import shutil
import subprocess
import platform
from pathlib import Path

# ──────────────────────────────────────────────
# 常量
# ──────────────────────────────────────────────
VERSION = "1.1.1"
CONFIG_FILE = ".env"
LOG_DIR = "logs"
KNOWLEDGE_DIR = "laozi_knowledge_base"
SOURCE_DOCS_DIR = "laozi-agent/laozi_source_docs"

BANNER = r"""
  ██╗      █████╗  ██████╗ ███████╗██╗
  ██║     ██╔══██╗██╔═══██╗╚══███╔╝██║
  ██║     ███████║██║   ██║  ███╔╝ ██║
  ██║     ██╔══██║██║   ██║ ███╔╝  ██║
  ███████╗██║  ██║╚██████╔╝███████╗██║
  ╚══════╝╚═╝  ╚═╝ ╚═════╝╚══════╝╚═╝
  ─────────────────────────────────────
   老子智能体 · 一键配置工具 v{version}
  ─────────────────────────────────────
"""

# ──────────────────────────────────────────────
# 颜色输出
# ──────────────────────────────────────────────
class C:
    """终端颜色。"""
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[31m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    BLUE    = "\033[34m"
    CYAN    = "\033[36m"
    MAGENTA = "\033[35m"

    @staticmethod
    def disable():
        for attr in ["RESET","BOLD","DIM","RED","GREEN","YELLOW","BLUE","CYAN","MAGENTA"]:
            setattr(C, attr, "")


def cprint(color, text, end="\n"):
    print(f"{color}{text}{C.RESET}", end=end)


def step(n, total, msg):
    cprint(C.CYAN, f"\n  [{n}/{total}] {msg}")


def ok(msg):
    cprint(C.GREEN, f"  ✅ {msg}")


def warn(msg):
    cprint(C.YELLOW, f"  ⚠️  {msg}")


def fail(msg):
    cprint(C.RED, f"  ❌ {msg}")


def info(msg):
    cprint(C.DIM, f"  💡 {msg}")


def ask(prompt, default=""):
    suffix = f" [{default}]" if default else ""
    try:
        val = input(f"  {prompt}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(0)
    return val if val else default


def confirm(prompt, default=True):
    suffix = " [Y/n]" if default else " [y/N]"
    try:
        val = input(f"  {prompt}{suffix}: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(0)
    if not val:
        return default
    return val in ("y", "yes", "是", "对")


# ──────────────────────────────────────────────
# 环境检测
# ──────────────────────────────────────────────
def detect_environment():
    """检测当前环境。"""
    env = {
        "os": platform.system(),
        "arch": platform.machine(),
        "python": platform.python_version(),
        "has_git": shutil.which("git") is not None,
        "has_pip": shutil.which("pip3") is not None or shutil.which("pip") is not None,
        "has_venv": False,
        "in_venv": hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix),
    }

    # 检查 venv 模块
    try:
        import venv
        env["has_venv"] = True
    except ImportError:
        pass

    return env


def print_env(env):
    """打印环境信息。"""
    cprint(C.BOLD, "\n  📋 环境检测")
    print(f"  {'─' * 40}")
    print(f"  系统:     {env['os']} ({env['arch']})")
    print(f"  Python:   {env['python']}")
    print(f"  Git:      {'✅ 可用' if env['has_git'] else '❌ 未安装'}")
    print(f"  pip:      {'✅ 可用' if env['has_pip'] else '❌ 未安装'}")
    print(f"  venv:     {'✅ 可用' if env['has_venv'] else '❌ 不可用'}")
    print(f"  虚拟环境:  {'✅ 已激活' if env['in_venv'] else '⚠️ 未激活'}")
    print(f"  {'─' * 40}")


# ──────────────────────────────────────────────
# 方案选择
# ──────────────────────────────────────────────
def choose_plan():
    """让用户选择方案。"""
    cprint(C.BOLD, "\n  🎯 选择方案")
    print()
    print(f"  {C.CYAN}方案一：OpenAI 版{C.RESET}")
    print(f"    • 效果最好，理解能力最强")
    print(f"    • 需要 OpenAI API Key（付费）")
    print(f"    • 使用 GPT-4o + text-embedding-3-large")
    print(f"    • 命令行交互")
    print()
    print(f"  {C.MAGENTA}方案二：免费版{C.RESET}")
    print(f"    • 完全免费，无需任何 API Key")
    print(f"    • 使用 Qwen2.5-72B + BGE-base-zh（本地）")
    print(f"    • Gradio Web 界面（浏览器访问）")
    print()

    while True:
        choice = ask("选择方案 (1/2)", "2")
        if choice in ("1", "2"):
            return int(choice)
        warn("请输入 1 或 2")


# ──────────────────────────────────────────────
# 方案一：OpenAI 版配置
# ──────────────────────────────────────────────
def setup_openai():
    """配置 OpenAI 版。"""
    cprint(C.BOLD, "\n  🔑 方案一：OpenAI 版配置")
    print()

    # API Key
    existing_key = os.getenv("OPENAI_API_KEY", "")
    if existing_key:
        masked = existing_key[:8] + "..." + existing_key[-4:]
        ok(f"检测到已有的 OPENAI_API_KEY: {masked}")
        if not confirm("是否使用已有的 Key？"):
            existing_key = ""

    api_key = existing_key
    if not api_key:
        print()
        info("获取 API Key: https://platform.openai.com/api-keys")
        print()
        while True:
            api_key = ask("输入 OpenAI API Key", "")
            if api_key.startswith("sk-"):
                break
            warn("API Key 通常以 sk- 开头，请检查")

    # 模型选择
    print()
    info("默认模型：GPT-4o（最佳效果）")
    info("可选模型：gpt-4o-mini（更便宜）、gpt-3.5-turbo（最快）")
    model = ask("选择模型", "gpt-4o")

    # Temperature
    print()
    info("温度越低回答越严谨（0.0-1.0）")
    temp = ask("温度", "0.1")

    # 知识库路径
    kb_dir = ask("知识库目录", KNOWLEDGE_DIR)

    config = {
        "OPENAI_API_KEY": api_key,
        "LAOZI_LLM_MODEL": model,
        "LAOZI_EMBEDDING_MODEL": "text-embedding-3-large",
        "LAOZI_TEMPERATURE": temp,
        "LAOZI_PERSIST_DIR": kb_dir,
        "LAOZI_RETRIEVAL_K": "5",
        "LAOZI_FETCH_K": "20",
        "LAOZI_COLLECTION": "laozi_collection",
        "LAOZI_LOG_LEVEL": "INFO",
    }

    return config, "openai"


# ──────────────────────────────────────────────
# 方案二：免费版配置
# ──────────────────────────────────────────────
def setup_free():
    """配置免费版。"""
    cprint(C.BOLD, "\n  🆓 方案二：免费版配置")
    print()

    # HuggingFace Token（可选）
    print()
    info("HuggingFace Token 是可选的，有 Token 速率更高")
    info("获取 Token: https://huggingface.co/settings/tokens")
    hf_token = ask("HuggingFace Token（可选，直接回车跳过）", "")

    # LLM 模型
    print()
    info("默认：Qwen2.5-72B-Instruct（HuggingFace 免费推理）")
    info("备选：THUDM/glm-4-9b-chat、Qwen/Qwen2.5-14B-Instruct")
    llm_model = ask("LLM 模型", "Qwen/Qwen2.5-72B-Instruct")

    # Temperature
    print()
    info("免费模型建议温度稍高（0.3），避免过于死板")
    temp = ask("温度", "0.3")

    # 端口
    print()
    port = ask("Web 端口", "7860")

    # 知识库路径
    kb_dir = ask("知识库目录", KNOWLEDGE_DIR)

    config = {
        "HF_TOKEN": hf_token,
        "LAOZI_LLM_MODEL": llm_model,
        "LAOZI_EMBEDDING_MODEL": "BAAI/bge-base-zh-v1.5",
        "LAOZI_TEMPERATURE": temp,
        "LAOZI_PERSIST_DIR": kb_dir,
        "LAOZI_RETRIEVAL_K": "5",
        "LAOZI_FETCH_K": "20",
        "LAOZI_COLLECTION": "laozi_collection",
        "LAOZI_SERVER_PORT": port,
        "LAOZI_LOG_LEVEL": "INFO",
    }

    return config, "free"


# ──────────────────────────────────────────────
# 写入配置文件
# ──────────────────────────────────────────────
def write_config(config, plan_name):
    """写入 .env 配置文件。"""
    lines = [
        f"# 老子智能体配置 — {plan_name}版",
        f"# 由 setup.py 自动生成 ({VERSION})",
        f"# 修改时间: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
    ]

    # 按分组输出
    groups = {
        "模型配置": ["OPENAI_API_KEY", "HF_TOKEN", "LAOZI_LLM_MODEL", "LAOZI_EMBEDDING_MODEL", "LAOZI_TEMPERATURE"],
        "检索配置": ["LAOZI_RETRIEVAL_K", "LAOZI_FETCH_K"],
        "路径配置": ["LAOZI_PERSIST_DIR", "LAOZI_COLLECTION"],
        "服务配置": ["LAOZI_SERVER_PORT"],
        "日志配置": ["LAOZI_LOG_LEVEL"],
    }

    written = set()
    for group_name, keys in groups.items():
        group_items = [(k, config[k]) for k in keys if k in config]
        if group_items:
            lines.append(f"# ── {group_name} ──")
            for k, v in group_items:
                # API Key 不写明文注释
                if "KEY" in k or "TOKEN" in k:
                    lines.append(f'{k}={v}')
                else:
                    lines.append(f'{k}={v}')
            lines.append("")
            written.update(keys)

    content = "\n".join(lines)

    # 备份旧配置
    if os.path.exists(CONFIG_FILE):
        backup = f"{CONFIG_FILE}.bak"
        shutil.copy2(CONFIG_FILE, backup)
        warn(f"已备份旧配置到 {backup}")

    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        f.write(content)

    ok(f"配置已写入 {CONFIG_FILE}")
    return content


# ──────────────────────────────────────────────
# 依赖安装
# ──────────────────────────────────────────────
def install_deps(plan, env):
    """安装依赖。"""
    cprint(C.BOLD, "\n  📦 安装依赖")
    print()

    if not env["has_pip"]:
        fail("pip 不可用，请先安装 pip")
        return False

    pip_cmd = "pip3" if shutil.which("pip3") else "pip"

    # 创建虚拟环境（推荐）
    if not env["in_venv"]:
        if confirm("是否创建虚拟环境？（推荐）", True):
            venv_dir = "venv"
            if os.path.exists(venv_dir):
                warn(f"虚拟环境目录 {venv_dir} 已存在")
            else:
                print(f"  创建虚拟环境...")
                ret = os.system(f"{sys.executable} -m venv {venv_dir}")
                if ret != 0:
                    fail("创建虚拟环境失败")
                    return False
                ok(f"虚拟环境创建成功: {venv_dir}")

            # 切换到虚拟环境的 pip
            if env["os"] == "Windows":
                pip_cmd = os.path.join(venv_dir, "Scripts", "pip")
                python_cmd = os.path.join(venv_dir, "Scripts", "python")
            else:
                pip_cmd = os.path.join(venv_dir, "bin", "pip")
                python_cmd = os.path.join(venv_dir, "bin", "python")

            info(f"激活虚拟环境: source {venv_dir}/bin/activate")
        else:
            python_cmd = sys.executable
    else:
        python_cmd = sys.executable

    # 安装依赖
    print(f"  安装 Python 依赖...")
    if plan == "openai":
        packages = "langchain langchain-openai langchain-chroma chromadb"
    else:
        packages = "langchain langchain-community langchain-chroma chromadb sentence-transformers huggingface_hub gradio"

    cmd = f"{pip_cmd} install {packages}"
    print(f"  $ {cmd}")
    print()

    ret = os.system(cmd)
    if ret != 0:
        fail("依赖安装失败，请检查网络连接")
        info("可以手动运行: " + cmd)
        return False

    ok("依赖安装完成")
    return True


# ──────────────────────────────────────────────
# 知识库检查
# ──────────────────────────────────────────────
def check_knowledge_base():
    """检查知识库状态。"""
    cprint(C.BOLD, "\n  📚 知识库检查")

    if os.path.exists(KNOWLEDGE_DIR) and os.listdir(KNOWLEDGE_DIR):
        ok(f"知识库已存在: {KNOWLEDGE_DIR}")
        return True
    else:
        warn(f"知识库目录不存在或为空: {KNOWLEDGE_DIR}")

        if os.path.exists(SOURCE_DOCS_DIR):
            count = len(list(Path(SOURCE_DOCS_DIR).rglob("*.txt")))
            ok(f"发现源文档: {SOURCE_DOCS_DIR} ({count} 个文件)")
            info("首次启动时会自动构建向量库（需要几分钟）")
        else:
            fail(f"源文档目录不存在: {SOURCE_DOCS_DIR}")
            info("请手动放置《道德经》源文档到该目录")
        return False


# ──────────────────────────────────────────────
# 创建日志目录
# ──────────────────────────────────────────────
def setup_log_dir():
    """创建日志目录。"""
    os.makedirs(LOG_DIR, exist_ok=True)
    ok(f"日志目录: {LOG_DIR}/")


# ──────────────────────────────────────────────
# 生成启动脚本
# ──────────────────────────────────────────────
def generate_launch_script(plan, config):
    """生成启动脚本。"""
    if plan == "openai":
        script = """#!/bin/bash
# 老子智能体 — OpenAI 版启动脚本
# 由 setup.py 自动生成

set -e
cd "$(dirname "$0")"

# 加载配置
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

echo "🏛️  启动老子智能体（OpenAI 版）..."
echo "   模型: ${LAOZI_LLM_MODEL:-gpt-4o}"
echo "   温度: ${LAOZI_TEMPERATURE:-0.1}"
echo ""

python3 scripts/laozi_agent.py
"""
        path = "start_openai.sh"
    else:
        script = """#!/bin/bash
# 老子智能体 — 免费版启动脚本
# 由 setup.py 自动生成

set -e
cd "$(dirname "$0")"

# 加载配置
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

PORT=${LAOZI_SERVER_PORT:-7860}

echo "🏛️  启动老子智能体（免费版）..."
echo "   模型: ${LAOZI_LLM_MODEL:-Qwen/Qwen2.5-72B-Instruct}"
echo "   温度: ${LAOZI_TEMPERATURE:-0.3}"
echo "   端口: $PORT"
echo ""
echo "   浏览器访问: http://localhost:$PORT"
echo ""

python3 app.py
"""
        path = "start_free.sh"

    with open(path, "w", encoding="utf-8") as f:
        f.write(script)
    os.chmod(path, 0o755)
    ok(f"启动脚本: {path}")
    return path


# ──────────────────────────────────────────────
# 生成启动说明
# ──────────────────────────────────────────────
def print_summary(plan, config, launch_script):
    """打印配置总结。"""
    cprint(C.BOLD, "\n  " + "═" * 50)
    cprint(C.GREEN + C.BOLD, "  🎉 配置完成！")
    cprint(C.BOLD, "  " + "═" * 50)

    print()
    if plan == "openai":
        cprint(C.CYAN, "  📌 启动方式（任选一种）：")
        print()
        print(f"    方式一：运行启动脚本")
        print(f"      $ bash {launch_script}")
        print()
        print(f"    方式二：手动启动")
        print(f"      $ export OPENAI_API_KEY=\"{config['OPENAI_API_KEY'][:8]}...\"")
        print(f"      $ python3 scripts/laozi_agent.py")
    else:
        cprint(C.CYAN, "  📌 启动方式（任选一种）：")
        print()
        print(f"    方式一：运行启动脚本")
        print(f"      $ bash {launch_script}")
        print()
        print(f"    方式二：手动启动")
        print(f"      $ python3 app.py")
        print(f"      浏览器打开 http://localhost:{config.get('LAOZI_SERVER_PORT', 7860)}")

    print()
    cprint(C.YELLOW, "  📌 常用命令：")
    print(f"    查看日志:  tail -f logs/laozi.log")
    print(f"    修改配置:  编辑 {CONFIG_FILE}")
    print(f"    重新配置:  python3 setup.py")
    print(f"    查看帮助:  python3 setup.py --help")
    print()

    cprint(C.DIM, "  📖 文档：")
    print(f"    用户手册:  docs/USER_MANUAL.md")
    print(f"    故障排查:  docs/TROUBLESHOOTING.md")
    print(f"    API 文档:  laozi-agent/docs/API.md")
    print()


# ──────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────
def main():
    # 参数处理
    if "--help" in sys.argv or "-h" in sys.argv:
        print(__doc__)
        print("选项：")
        print("  --auto    自动检测环境，使用默认配置")
        print("  --plan 1  直接选择方案一（OpenAI 版）")
        print("  --plan 2  直接选择方案二（免费版）")
        print("  --help    显示帮助")
        return

    auto_mode = "--auto" in sys.argv

    # 颜色检测
    if not sys.stdout.isatty():
        C.disable()

    # Banner
    cprint(C.CYAN, BANNER.format(version=VERSION))

    # 环境检测
    env = detect_environment()
    print_env(env)

    # 环境警告
    if not env["has_pip"]:
        fail("pip 未安装，请先安装 Python 和 pip")
        sys.exit(1)

    if env["python"] < "3.9":
        warn(f"Python 版本 {env['python']} 可能不兼容，建议 3.9+")

    if not env["in_venv"]:
        warn("未激活虚拟环境，建议使用 venv 隔离依赖")

    # 选择方案
    if "--plan" in sys.argv:
        idx = sys.argv.index("--plan")
        if idx + 1 < len(sys.argv):
            plan_choice = int(sys.argv[idx + 1])
        else:
            plan_choice = 2
    elif auto_mode:
        plan_choice = 2
        info("自动模式：使用免费版（方案二）")
    else:
        plan_choice = choose_plan()

    # 执行配置
    if plan_choice == 1:
        config, plan_name = setup_openai()
        launch_script = generate_launch_script("openai", config)
    else:
        config, plan_name = setup_free()
        launch_script = generate_launch_script("free", config)

    # 写入配置
    step(1, 4, "写入配置文件")
    write_config(config, plan_name)

    # 安装依赖
    step(2, 4, "安装 Python 依赖")
    if not auto_mode:
        if not confirm("是否立即安装依赖？", True):
            warn("跳过依赖安装，稍后可手动运行 pip install -r requirements.txt")
        else:
            install_deps(plan_name, env)
    else:
        install_deps(plan_name, env)

    # 知识库检查
    step(3, 4, "检查知识库")
    check_knowledge_base()

    # 日志目录
    step(4, 4, "初始化日志")
    setup_log_dir()

    # 生成启动脚本
    generate_launch_script(plan_name, config)

    # 打印总结
    print_summary(plan_name, config, launch_script)


if __name__ == "__main__":
    main()
