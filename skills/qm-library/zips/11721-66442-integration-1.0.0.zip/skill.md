# Skill Name

## Overview

A short description of what this skill does.

Example:

> This skill allows the agent to search GitHub repositories, fetch code snippets, and summarize project structures.

---

# Metadata

```yaml
name: github-integration
version: 1.0.0
category: developer-tools
description: GitHub integration skill for repositories and code analysis
author: Your Name
license: MIT
```

---

# Purpose

Explain:

* Why this skill exists
* What problem it solves
* Which workflows it supports

Example:

* Repository analysis
* Pull request summaries
* File search
* Commit history lookup

---

# Capabilities

List the major capabilities of the skill.

## Features

* Search repositories
* Read repository files
* Fetch pull requests
* Analyze commits
* Generate summaries
* Semantic search support

---

# Inputs

Describe what input the skill expects.

| Input Name | Type   | Required | Description            |
| ---------- | ------ | -------- | ---------------------- |
| repository | string | Yes      | GitHub repository name |
| branch     | string | No       | Branch name            |
| query      | string | No       | Search query           |

---

# Outputs

Describe the response structure.

| Field   | Type   | Description        |
| ------- | ------ | ------------------ |
| summary | string | Generated summary  |
| files   | array  | Matching files     |
| commits | array  | Commit information |

---

# Environment Variables

```env
GITHUB_TOKEN=your_token_here
API_BASE_URL=https://api.github.com
```

---

# Installation

## Clone Repository

```bash
git clone https://github.com/example/skill.git
cd skill
```

## Install Dependencies

```bash
npm install
```

---

# Usage

## Example Request

```json
{
  "repository": "openai/openai-python",
  "query": "embedding implementation"
}
```

## Example Response

```json
{
  "summary": "Found embedding-related files and utilities.",
  "files": [
    "embeddings.py",
    "vector_store.py"
  ]
}
```

---

# Architecture

Explain how the skill works internally.

Example Flow:

```text
User Request
    ↓
Skill Router
    ↓
Authentication Layer
    ↓
GitHub API Client
    ↓
Processing Layer
    ↓
Formatted Response
```

---

# Error Handling

Common errors and solutions.

| Error                | Cause             | Solution          |
| -------------------- | ----------------- | ----------------- |
| Unauthorized         | Invalid token     | Update API token  |
| Rate Limited         | Too many requests | Retry later       |
| Repository Not Found | Wrong repo name   | Verify repository |

---

# Security

Describe security considerations.

* Store tokens securely
* Never expose secrets in logs
* Use HTTPS requests only
* Apply permission checks

---

# Best Practices

* Cache frequent API responses
* Use pagination for large repositories
* Validate user inputs
* Handle API rate limits

---

# Dependencies

```json
{
  "axios": "^1.0.0",
  "dotenv": "^16.0.0"
}
```

---

# Future Improvements

* Add vector search
* Add webhook support
* Add multi-repository analysis
* Improve semantic ranking

---

# Maintainers

| Name      | Role      |
| --------- | --------- |
| Your Name | Developer |

---

# License

MIT License
