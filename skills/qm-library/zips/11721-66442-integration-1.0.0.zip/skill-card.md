## Description: <br>
my integration helps agents search GitHub repositories, read files, fetch pull requests and commits, and summarize code for repository analysis. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[karaninfoorigin](https://clawhub.ai/user/karaninfoorigin) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineering agents use this skill to inspect GitHub repositories, locate files, review commit and pull request context, and produce concise summaries during code analysis workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: GitHub tokens and repository data may be exposed if users configure broad token scopes or analyze sensitive private repositories. <br>
Mitigation: Use least-privilege GitHub tokens, store secrets outside prompts and logs, and avoid private or sensitive repositories unless the data flow is acceptable. <br>
Risk: Repository names, branches, queries, and fetched content may be sent to GitHub as part of normal operation. <br>
Mitigation: Treat the skill as a GitHub API helper and review repository privacy requirements before use. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/karaninfoorigin/integration) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown and structured text with code, JSON, environment-variable, and shell-command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include repository summaries, matching files, commit details, pull request context, error-handling guidance, and setup instructions.] <br>

## Skill Version(s): <br>
1.0.0 (source: server-resolved release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
