## Description: <br>
Operates VirusTotal through OOMOL's oo CLI connector to retrieve reports, search threat intelligence, submit URLs or files for analysis, and add community comments or votes. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Security analysts, incident responders, and developers use this skill to operate VirusTotal through an OOMOL-connected account for threat-intelligence lookups, report retrieval, URL and file submissions, rescans, and community comments or votes. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive VirusTotal credentials through OOMOL's connector path. <br>
Mitigation: Install only when the user trusts OOMOL's oo CLI and is comfortable connecting a VirusTotal API key through OOMOL. <br>
Risk: Uploads, URL scans, rescans, comments, and votes can send data to VirusTotal or change community-visible state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running state-changing actions. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Inspect the live action schema with the oo CLI before constructing JSON payloads. <br>


## Reference(s): <br>
- [ClawHub VirusTotal Skill](https://clawhub.ai/oomol/oo-virustotal) <br>
- [VirusTotal Homepage](https://www.virustotal.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, JSON, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload and response references] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI and an OOMOL-connected VirusTotal account; live action schemas should be inspected before constructing payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
