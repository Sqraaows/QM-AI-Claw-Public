---
name: daily-command-center
description: Personal productivity hub — tasks, calendar, daily briefings, financial tracking, research, and tech news. Notion-powered.
homepage: https://github.com/martc03/openclaw-ultimate
metadata: {"clawdbot":{"emoji":"📡"}}
version: 1.0.0
author: martc03
tags: [productivity, tasks, calendar, finance, research]
permissions:
  network: [api.notion.com, api.google.com]
---

# Daily Command Center

Your personal productivity hub. Manage tasks, check your calendar, get daily briefings, track finances, do research, and stay up on tech — all from your phone.

## Commands

### `day brief`
Morning briefing. Aggregates today's key information into one summary.

```
day brief
```

Returns:
- Today's calendar events (from Google Calendar)
- High-priority tasks due today or overdue (from Notion Tasks)
- Quick financial snapshot — recent entries (from Notion Financial Tracking)
- Weather for Boise, ID
- Any unresolved security alerts (from Security Audit Log)

### `day tasks`
Show current tasks from Notion, sorted by priority then due date.

```
day tasks
day tasks high priority
day tasks soil rich
day tasks synergy
day tasks dev
```

Filters by priority or category when specified.

### `day add [task]`
Add a new task to Notion Tasks database.

```
day add Call Nathan Price about ISDA renewal - high priority
day add Update Synergy website photos - medium - due friday
day add Review Apify analytics - low - dev
day add Pick up label samples from Fortis - synergy - due march 10
```

Parses priority, category, and due date from natural language.
Defaults: Medium priority, no due date, Personal category.

### `day done [task]`
Mark a task as complete in Notion. Matches by task name (partial match).

```
day done Call Nathan Price
day done Update Synergy
```

Sets Status to "Done" in Notion Tasks.

### `day calendar`
Show calendar events from Google Calendar.

```
day calendar
day calendar tomorrow
day calendar this week
day calendar march 15
```

### `day finance`
Financial snapshot across all revenue sources.

```
day finance
day finance this month
day finance soil rich
day finance synergy
day finance expenses
```

Reads from: Notion Financial Tracking database. Shows revenue and expenses by source (Apify, RapidAPI, Soil Rich, Synergy, Other).

### `day research [topic]`
Quick web research on any topic. Returns a concise summary with key findings.

```
day research Idaho soil amendment regulations 2026
day research Next.js 15 new features
day research FFA National Convention 2026 dates
day research Boise farmers market schedule
```

### `day note [content]`
Save a note to the Notion Daily Notes database with today's date.

```
day note Met with Matt Wright about Fortis label printing - need to send corrected FEED file
day note Idea: Partner with local FFA chapter for spring demo
day note Research: New biochar supplier found - competitive pricing
```

Auto-categorizes as Note, Research, Idea, or Meeting based on content. Tags relevant topics.

### `day tech`
Latest tech news relevant to your stack.

```
day tech
```

Returns top 5 news items from the last 24 hours covering:
- Next.js / React / Node.js
- AI / Claude / MCP ecosystem
- Cybersecurity
- Web development

## Notion Databases

- **Tasks** — Personal task management with priority, category, due date
- **Daily Notes** — Notes, research, ideas, meeting notes with tags
- **Financial Tracking** — Revenue and expenses across all sources
- **Security Audit Log** — Referenced in daily brief for unresolved alerts
