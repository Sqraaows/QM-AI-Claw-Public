## Description: <br>
IPGeolocation.io helps agents run IP geolocation, timezone, and astronomy lookups through the OOMOL `ipgeolocation_io` connector instead of calling the API directly. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect OOMOL connector schemas and run read-only IPGeolocation.io lookups for IP location, timezone, and astronomy data using connected credentials. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires connected IPGeolocation.io credentials through OOMOL. <br>
Mitigation: Connect only credentials intended for these read-only lookups and review the account or scope before use. <br>
Risk: The optional first-time setup includes a shell-based oo CLI installer. <br>
Mitigation: Inspect OOMOL's install instructions or install the oo CLI through a trusted method before running installer commands. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing each payload. <br>
Risk: Lookup results may reflect external IPGeolocation.io data quality and account billing state. <br>
Mitigation: Review returned JSON before relying on it, and resolve billing or credit errors in OOMOL before retrying. <br>


## Reference(s): <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-ipgeolocation-io) <br>
- [IPGeolocation.io homepage](https://ipgeolocation.io/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [actions/get_astronomy.md](actions/get_astronomy.md) <br>
- [actions/get_timezone.md](actions/get_timezone.md) <br>
- [actions/lookup_ip.md](actions/lookup_ip.md) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, json] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON request and response payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, OOMOL sign-in, and a connected IPGeolocation.io API key before live lookups can run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
