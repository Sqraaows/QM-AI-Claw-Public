## Description: <br>
Helps agents search and read HackerRank Work tests and candidate records through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Recruiting teams, hiring managers, and developers use this skill to inspect HackerRank Work tests and candidate records from an authenticated OOMOL-connected HackerRank Work account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an OOMOL-connected HackerRank Work account and can read recruiting test and candidate information. <br>
Mitigation: Install only for trusted OOMOL workflows, review OOMOL and HackerRank permissions, and avoid connecting production recruiting data unless that access is intended. <br>
Risk: Live connector schemas and permissions can change upstream. <br>
Mitigation: Inspect the connector schema before constructing each payload and run only the read-oriented get, list, or search action needed for the user's request. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-hackerrank-work) <br>
- [HackerRank Work homepage](https://www.hackerrank.com/work) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands return JSON responses from the HackerRank Work connector when run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
