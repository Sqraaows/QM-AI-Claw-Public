# Multi-Agent LLM Wiki

> 🤖 基于多 Agent 协作的 LLM Wiki 知识库管理系统
>
> 基于 Karpathy 的 [LLM Wiki 模式](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Claude Code Compatible](https://img.shields.io/badge/Claude%20Code-2.1+-blue.svg)](https://claude.com/claude-code)

## 🎯 项目简介

Multi-Agent LLM Wiki 是一个 Claude Code Skill，实现了**蚁群协作模式**的知识库管理系统。基于 Karpathy 提出的 LLM Wiki 架构，通过多 Agent 协作完成知识消化、查询和校验。

### 核心理念

> **"知识只需编译一次并保持最新，不需要每次查询时重新推导。"**

```
┌─────────────────────────────────────────────────────────────────┐
│                   Multi-Agent LLM Wiki 工作流                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  用户输入 ──▶ Lead 协调 ──▶ 蚁群协作 ──▶ 结果输出              │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                     蚁群生命周期                         │   │
│  │  🔍 Scout(侦察) → ⚒️ Worker(执行) → 🛡️ Reviewer(审查)    │   │
│  │       │              │               │                    │   │
│  │   探索源文件      创建页面        检查质量                │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## ✨ 特性

- 🐜 **蚁群协作** — Lead(协调) → Scout(侦察) → Worker(执行) → Reviewer(审查)
- 🚀 **首次用户引导** — 无知识库时自动引导创建架构
- 📚 **三大核心操作** — Ingest(消化) / Query(查询) / Lint(检查)
- 🔍 **健康检查** — 自动检测孤立页面、矛盾内容、缺失链接
- 💾 **全局配置** — 支持 OpenClaw 全局运行
- 📦 **开箱即用** — 自动创建目录结构和模板文件

## 📁 目录结构

```
Multi-Agent-LLM-Wiki/
├── README.md                 # 本文档
├── LICENSE                   # MIT 许可证
├── SKILL.md                  # Claude Code Skill 定义
├── CLAUDE.md                 # Schema 说明（用户引导时自动创建）
└── scripts/
    ├── init.js              # 初始化脚本
    ├── validate.js          # 验证脚本
    └── lint.js              # 健康检查脚本
```

## 🔧 安装

### 方式一：复制到 Claude Code Skills 目录

```bash
# 克隆仓库
git clone https://github.com/muruai2021/Multi-Agent-LLM-Wiki.git

# 复制到 Claude Code skills 目录
cp -r Multi-Agent-LLM-Wiki ~/.claude/skills/multi-agent-llm-wiki
```

### 方式二：手动下载

1. 下载本仓库到 `~/.claude/skills/multi-agent-llm-wiki/` 目录

### 验证安装

```bash
# 运行验证脚本
node ~/.claude/skills/multi-agent-llm-wiki/scripts/validate.js
```

## 🚀 使用方法

### 首次使用

```bash
# 初始化知识库（首次使用时会自动引导）
claude
> /llm-wiki init

# 或指定路径
> /llm-wiki init --path /path/to/your/vault
```

### 三大核心操作

```bash
# Ingest：消化源文件（蚁群协作）
> /llm-wiki ingest raw/articles/my-article.md

# Query：查询知识库
> /llm-wiki query RAG和Wiki有什么区别

# Lint：健康检查
> /llm-wiki lint
```

### 脚本直接调用

```bash
# 初始化
node scripts/init.js --path <vault-root>

# 验证 vault 结构
node scripts/validate.js

# 健康检查
node scripts/lint.js [--json]
```

## 🐜 蚁群角色体系

| 角色 | 名称 | 模型 | 职责 |
|------|------|------|------|
| **Lead** | 蚁后/主修 | sonnet | 协调、分解任务、汇总结果 |
| **Scout** | 侦察蚁 | haiku | 快速探索源文件结构（低成本） |
| **Worker** | 工蚁 | sonnet | 创建/更新 Wiki 页面 |
| **Reviewer** | 护法 | sonnet | 审查质量、检查矛盾 |

### 工作流程

```
1. Lead 协调
   ↓
2. Scout 侦察（haiku）- 探索源文件，提取概念
   ↓ 信息素传递
3. Worker 执行（sonnet）- 创建 Wiki 页面
   ↓ 信息素传递
4. Reviewer 审查（sonnet）- 检查质量
   ↓
5. Lead 汇总结果
```

## 📖 知识库架构

### 三层架构

```
┌─────────────────────────────────────────────────────────────────┐
│                     LLM Wiki 三层架构                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   Raw Sources (源文件层)                                         │
│   ──────────────────────────────                                 │
│   你的"原材料"：文章、论文、笔记、图片                            │
│   特点：不可变，LLM 只读不改                                     │
│                                                                 │
│                          ↓ Ingest                                │
│                                                                 │
│   Wiki (整理层)                                                  │
│   ──────────────                                                 │
│   LLM 对原材料的"二次加工"：                                    │
│   • 摘要页（这篇讲了什么）                                       │
│   • 概念页（这个概念是什么）                                     │
│                                                                 │
│                          ↓ Query                                │
│                                                                 │
│   Schema (说明层)                                               │
│   ─────────────────                                             │
│   CLAUDE.md — 告诉你怎么操作                                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 自动创建的目录结构

```
vault_root/
├── raw/                    # 原始文档（不可变）
│   ├── articles/           # 文章
│   ├── papers/             # 论文
│   └── assets/             # 图片/附件
├── wiki/                   # Wiki 页面（LLM 维护）
│   ├── index.md            # 全局索引
│   ├── log.md              # 操作日志
│   └── concepts/           # 概念页面
├── .claude/                # Claude Code 配置
└── CLAUDE.md               # Schema 说明
```

## 📊 健康检查

### 检查项

| 检查项 | 说明 | 严重程度 |
|--------|------|----------|
| `orphan_pages` | 没有页面引用它 | ⚠️ warning |
| `outdated_assertions` | 被新来源否定的旧说法 | ❌ error |
| `contradictions` | 页面间的矛盾陈述 | ❌ error |
| `missing_pages` | 重要概念被提及但无独立页面 | ℹ️ info |
| `stale_pages` | 超过 30 天未更新的页面 | ⚠️ warning |
| `missing_links` | 可以添加但缺失的链接 | ℹ️ info |

### 示例输出

```
🔍 Multi-Agent LLM Wiki - 健康检查

📁 Vault: C:/Users/Admin/OneDrive/Knowledge
==================================================

📄 分析 40 个页面...

📋 检查结果:

✅ 无孤立页面

💡 可添加链接 (9):
  - [[AI编码自进化]] 引用了 [[ClaudeCode-Review]] 但无独立页面
  ...

==================================================
总计: 40 个页面
```

## 🎓 经典语录

> **"Obsidian is the IDE; the LLM is the programmer; the wiki is the codebase."**
>
> **"LLM does all the grunt work — the summarizing, cross-referencing, filing, and bookkeeping."**
>
> **"Human's job is to curate sources, guide analysis, ask good questions, and think about meaning. LLM's job is everything else."**

## 🔗 相关资源

- [Karpathy's LLM Wiki Gist](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) — 原始设计
- [Claude Code](https://claude.com/claude-code) — Agent 开发环境
- [Claude Code Skills](https://docs.anthropic.com/en/docs/claude-code/skills) — Skill 开发文档

## 📝 许可证

MIT License — 详见 [LICENSE](LICENSE)

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 👤 作者

[muruai2021](https://github.com/muruai2021)