#!/usr/bin/env node
/**
 * Multi-Agent LLM Wiki - 验证脚本
 * 验证 vault 目录结构是否符合规范
 */

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(process.env.HOME || process.env.USERPROFILE, '.claude', 'llm-wiki-vault.json');

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    }
  } catch (e) {}
  return null;
}

function validateDirectory(dir, name) {
  if (!fs.existsSync(dir)) {
    console.log(`✗ 缺少目录: ${name} (${dir})`);
    return false;
  }
  if (!fs.statSync(dir).isDirectory()) {
    console.log(`✗ 不是目录: ${name} (${dir})`);
    return false;
  }
  console.log(`✓ ${name}: ${dir}`);
  return true;
}

function countFiles(dir, extensions) {
  let count = 0;
  try {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        count += countFiles(fullPath, extensions);
      } else {
        const ext = path.extname(file).toLowerCase();
        if (extensions.includes(ext)) {
          count++;
        }
      }
    }
  } catch (e) {}
  return count;
}

function validate(jsonOutput = false) {
  console.log('🔍 Multi-Agent LLM Wiki - Vault 验证\n');
  console.log('='.repeat(50));

  const config = loadConfig();

  if (!config) {
    console.log('\n❌ 未配置 vault');
    console.log('\n请先运行初始化:');
    console.log('  /llm-wiki init [--path <vault-root>]');
    if (jsonOutput) console.log(JSON.stringify({ status: 'not_configured' }));
    process.exit(1);
  }

  console.log(`\n📁 Vault: ${config.vault_root}`);
  console.log(`📅 初始化: ${config.initialized_at || '未知'}`);

  // 验证必需目录
  console.log('\n📂 目录结构:');
  const vaultRoot = config.vault_root;
  let allValid = true;

  allValid &= validateDirectory(path.join(vaultRoot, config.raw_dir), 'Raw (源文件)');
  allValid &= validateDirectory(path.join(vaultRoot, config.wiki_dir), 'Wiki (页面)');
  allValid &= validateDirectory(path.join(vaultRoot, config.concepts_dir), 'Concepts (概念)');

  // 统计
  console.log('\n📊 统计:');
  const rawCount = countFiles(path.join(vaultRoot, config.raw_dir), ['.md', '.txt', '.pdf', '.html']);
  const wikiCount = countFiles(path.join(vaultRoot, config.wiki_dir), ['.md']);
  const conceptsCount = countFiles(path.join(vaultRoot, config.concepts_dir), ['.md']);

  console.log(`  源文件: ${rawCount} 个`);
  console.log(`  Wiki 页面: ${wikiCount} 个`);
  console.log(`  概念页面: ${conceptsCount} 个`);

  console.log('\n' + '='.repeat(50));
  
  if (allValid) {
    console.log('✅ Vault 结构完整');
    if (jsonOutput) console.log(JSON.stringify({ status: 'valid', stats: { rawCount, wikiCount, conceptsCount } }));
  } else {
    console.log('⚠️  Vault 结构不完整');
    if (jsonOutput) console.log(JSON.stringify({ status: 'incomplete' }));
  }
}

const args = process.argv.slice(2);
validate(args.includes('--json'));
