#!/usr/bin/env node
/**
 * Multi-Agent LLM Wiki - 初始化脚本
 * 支持首次用户引导，自动创建知识库架构
 */

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(process.env.HOME || process.env.USERPROFILE, '.claude', 'llm-wiki-vault.json');

const DEFAULT_CONFIG = {
  version: '1.0.0',
  vault_root: '',
  raw_dir: 'raw',
  wiki_dir: 'wiki',
  concepts_dir: 'wiki/concepts',
  index_file: 'wiki/index.md',
  log_file: 'wiki/log.md',
  initialized: false,
  initialized_at: ''
};

// 模板文件
const INDEX_TEMPLATE = `# Wiki 索引

所有 wiki 页面的全局目录。

## 最近更新

- [[log]] — 操作日志
`;

const LOG_TEMPLATE = `# 操作日志

按时间顺序记录所有知识库的维护操作。
`;

const CLAUDE_TEMPLATE = `# CLAUDE.md — LLM Wiki Schema

你是一名个人知识库的 wiki 维护者，专注于构建可持续演进的第二大脑。

## 目录结构

\`\`\`
vault/
├── raw/                    # 不可变的原始文档（文章、论文、笔记）
│   └── assets/            # 从来源下载的图片和附件
├── wiki/                   # LLM 维护的 Markdown 页面
│   ├── index.md           # 全局页面目录
│   ├── log.md             # 按时间顺序的操作日志
│   └── concepts/          # 概念页面（可扩展子目录）
├── .claude/                # Claude Code 配置
└── CLAUDE.md               # 本文件 — 你的配置说明
\`\`\`

## 三项核心操作

### 消化（Ingest）
1. 从 \`raw/\` 读取源文件
2. Scout 侦察 → Worker 执行 → Reviewer 审查
3. 在 \`wiki/\` 中编写/更新摘要页面
4. 更新相关实体和概念页面
5. 在 \`index.md\` 中添加新页面
6. 在 \`log.md\` 中追加记录

### 查询（Query）
1. 阅读 \`index.md\` 找到相关页面
2. 深钻到相关 wiki 页面
3. 综合答案并标注引用来源

### 校验（Lint）
1. 检查页面间的矛盾之处
2. 找出没有入口链接的孤立页面
3. 建议缺失的交叉引用

## 页面格式

\`\`\`markdown
# 页面标题

## 摘要
一段概述。

## 关键要点
- 要点 1
- 要点 2

## 来源
- [[来源标题]]

## 相关
- [[相关页面]]
\`\`\`

## 提示
- 积极使用交叉引用 \`[[页面名]]\`
- 保持页面聚焦——每个概念一页
`;

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    }
  } catch (e) {}
  return null;
}

function createDirectoryStructure(vaultRoot) {
  const dirs = [
    'raw',
    'raw/articles',
    'raw/papers',
    'raw/assets',
    'wiki',
    'wiki/concepts',
    'wiki/topics'
  ];

  console.log('\n📁 创建目录结构...\n');
  for (const dir of dirs) {
    const fullPath = path.join(vaultRoot, dir);
    if (!fs.existsSync(fullPath)) {
      fs.mkdirSync(fullPath, { recursive: true });
      console.log(`  ✓ ${dir}/`);
    }
  }
}

function createTemplateFiles(vaultRoot) {
  console.log('\n📄 创建模板文件...\n');

  const indexPath = path.join(vaultRoot, 'wiki', 'index.md');
  if (!fs.existsSync(indexPath)) {
    fs.writeFileSync(indexPath, INDEX_TEMPLATE, 'utf-8');
    console.log('  ✓ wiki/index.md');
  }

  const logPath = path.join(vaultRoot, 'wiki', 'log.md');
  if (!fs.existsSync(logPath)) {
    fs.writeFileSync(logPath, LOG_TEMPLATE, 'utf-8');
    console.log('  ✓ wiki/log.md');
  }

  const claudePath = path.join(vaultRoot, 'CLAUDE.md');
  if (!fs.existsSync(claudePath)) {
    fs.writeFileSync(claudePath, CLAUDE_TEMPLATE, 'utf-8');
    console.log('  ✓ CLAUDE.md');
  }
}

function saveConfig(vaultRoot) {
  const config = {
    ...DEFAULT_CONFIG,
    vault_root: vaultRoot,
    initialized: true,
    initialized_at: new Date().toISOString().split('T')[0]
  };

  const configDir = path.dirname(CONFIG_PATH);
  if (!fs.existsSync(configDir)) {
    fs.mkdirSync(configDir, { recursive: true });
  }

  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf-8');
  console.log(`\n💾 配置已保存: ${CONFIG_PATH}`);
}

function showHelp() {
  console.log(`
📚 Multi-Agent LLM Wiki - 初始化工具

用法:
  init.js [--path <vault-root>]

选项:
  --path <path>    指定 vault 根目录路径
  --force          强制重新初始化

示例:
  init.js --path C:/Users/Admin/OneDrive/Knowledge
`);
}

function init(args) {
  console.log('🚀 Multi-Agent LLM Wiki - 初始化\n');
  console.log('='.repeat(50));

  // 解析参数
  let vaultRoot = null;
  let force = false;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--path' && i + 1 < args.length) {
      vaultRoot = args[i + 1];
      i++;
    } else if (args[i] === '--force') {
      force = true;
    } else if (args[i] === '--help') {
      showHelp();
      process.exit(0);
    }
  }

  // 检查现有配置
  const existingConfig = loadConfig();

  if (existingConfig && existingConfig.initialized && !force) {
    console.log(`\n✅ 已配置 vault: ${existingConfig.vault_root}`);
    console.log(`📅 初始化时间: ${existingConfig.initialized_at}`);
    console.log('\n使用 --force 强制重新初始化');
    process.exit(0);
  }

  // 如果没有指定路径，尝试使用当前目录或已有配置
  if (!vaultRoot) {
    if (existingConfig && existingConfig.vault_root) {
      vaultRoot = existingConfig.vault_root;
      console.log(`\n📂 使用已有配置: ${vaultRoot}`);
    } else {
      // 使用当前工作目录
      vaultRoot = process.cwd().replace(/\/g, '/');
      console.log(`\n📂 使用当前目录: ${vaultRoot}`);
    }
  } else {
    vaultRoot = vaultRoot.replace(/\/g, '/');
  }

  // 验证或创建目录
  let directoryExisted = fs.existsSync(vaultRoot);

  if (!directoryExisted) {
    console.log(`\n📁 创建目录: ${vaultRoot}`);
    fs.mkdirSync(vaultRoot, { recursive: true });
  }

  // 创建目录结构
  createDirectoryStructure(vaultRoot);

  // 创建模板文件
  createTemplateFiles(vaultRoot);

  // 保存配置
  saveConfig(vaultRoot);

  // 完成
  console.log('\n' + '='.repeat(50));
  console.log('✅ 初始化完成！\n');
  console.log('现在可以使用以下命令:');
  console.log('  /llm-wiki ingest <file>   # 消化源文件（蚁群协作）');
  console.log('  /llm-wiki query <问题>     # 查询知识库');
  console.log('  /llm-wiki lint             # 健康检查');
}

const args = process.argv.slice(2).filter(a => a !== 'node' && !a.endsWith('init.js'));
init(args);
