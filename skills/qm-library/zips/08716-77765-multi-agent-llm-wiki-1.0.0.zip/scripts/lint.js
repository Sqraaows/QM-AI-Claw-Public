#!/usr/bin/env node
/**
 * Multi-Agent LLM Wiki - 健康检查脚本
 * 检查孤立页面、矛盾内容、缺失链接等
 */

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(process.env.HOME || process.env.USERPROFILE, '.claude', 'llm-wiki-vault.json');

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    }
  } catch (e) {}
  return null;
}

function getAllMdFiles(dir) {
  const files = [];
  try {
    const items = fs.readdirSync(dir);
    for (const item of items) {
      const p = path.join(dir, item);
      if (fs.statSync(p).isDirectory()) {
        files.push(...getAllMdFiles(p));
      } else if (item.endsWith('.md')) {
        files.push(p);
      }
    }
  } catch (e) {}
  return files;
}

function extractLinks(content) {
  const regex = /\[\[([^\]]+)\]\]/g;
  const links = [];
  let match;
  while ((match = regex.exec(content)) !== null) {
    links.push(match[1]);
  }
  return links;
}

function lint(jsonOutput = false) {
  const config = loadConfig();
  if (!config) {
    console.log('❌ 未配置 vault，请先运行 /llm-wiki init');
    if (jsonOutput) console.log(JSON.stringify({ status: 'not_configured' }));
    process.exit(1);
  }

  const vaultRoot = config.vault_root;
  const wikiDir = path.join(vaultRoot, config.wiki_dir);

  console.log('🔍 Multi-Agent LLM Wiki - 健康检查\n');
  console.log('📁 Vault:', vaultRoot);
  console.log('='.repeat(50));

  const pages = getAllMdFiles(wikiDir);
  console.log('\n📄 分析', pages.length, '个页面...\n');

  // 构建链接图
  const pageLinks = {};
  for (const page of pages) {
    const rel = path.relative(vaultRoot, page).split(path.sep).join('/');
    const content = fs.readFileSync(page, 'utf-8');
    pageLinks[rel] = {
      links: extractLinks(content),
      content: content
    };
  }

  // 检查孤立页面
  const orphaned = [];
  const systemPages = ['wiki/index.md', 'wiki/log.md', 'Wiki 索引', '操作日志'];

  for (const [pagePath, data] of Object.entries(pageLinks)) {
    if (systemPages.includes(pagePath)) continue;

    const pageName = pagePath.replace('.md', '').replace('wiki/', '');
    let hasIncomingLinks = false;

    for (const [src, srcData] of Object.entries(pageLinks)) {
      if (srcData.links.some(l => l.includes(pageName) || l === pageName)) {
        hasIncomingLinks = true;
        break;
      }
    }

    if (!hasIncomingLinks) {
      orphaned.push(pagePath);
    }
  }

  // 检查缺失概念的引用（提及但无页面）
  const mentionedButMissing = [];
  const existingPages = Object.keys(pageLinks).map(p => p.replace('.md', '').replace('wiki/', ''));

  for (const [pagePath, data] of Object.entries(pageLinks)) {
    const content = data.content;
    // 简单检查：是否有 [[概念]] 但概念页不存在
    const matches = content.match(/\[\[([^\]]+)\]\]/g) || [];
    for (const match of matches) {
      const conceptName = match.replace('[[', '').replace(']]', '');
      const conceptPageName = conceptName.includes('/') ? conceptName.split('/').pop() : conceptName;
      if (!existingPages.some(p => p.includes(conceptPageName)) && !conceptPageName.includes('/')) {
        // 检查是否是 external link
        if (!conceptName.includes('http') && !mentionedButMissing.some(m => m.concept === conceptName && m.page === pagePath)) {
          mentionedButMissing.push({ concept: conceptName, page: pagePath });
        }
      }
    }
  }

  // 输出结果
  console.log('📋 检查结果:\n');

  if (orphaned.length > 0) {
    console.log('⚠️  孤立页面 (' + orphaned.length + '):');
    orphaned.forEach(p => console.log('  - [[' + p.replace('.md', '') + ']]'));
  } else {
    console.log('✅ 无孤立页面');
  }

  if (mentionedButMissing.length > 0) {
    console.log('\n💡 可添加链接 (' + mentionedButMissing.length + '):');
    mentionedButMissing.slice(0, 5).forEach(m => {
      console.log('  - [[' + m.page.replace('.md', '') + ']] 引用了 [[' + m.concept + ']] 但无独立页面');
    });
    if (mentionedButMissing.length > 5) {
      console.log('  ... 还有', mentionedButMissing.length - 5, '个');
    }
  }

  console.log('\n' + '='.repeat(50));
  console.log('总计:', pages.length, '个页面');

  if (jsonOutput) {
    console.log(JSON.stringify({
      total: pages.length,
      orphaned: orphaned.length,
      orphaned_pages: orphaned,
      suggested_links: mentionedButMissing.length
    }, null, 2));
  }
}

const args = process.argv.slice(2);
lint(args.includes('--json'));
