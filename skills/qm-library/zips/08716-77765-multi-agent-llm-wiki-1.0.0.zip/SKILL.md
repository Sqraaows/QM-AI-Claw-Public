---
name: multi-agent-llm-wiki
description: 多Agent协作的LLM Wiki知识库管理 — 基于Karpathy的LLM Wiki模式，支持首次用户引导、Ingest/Query/Lint三大操作，由蚁群协作完成。
version: 1.0.0
license: MIT
user-invocable: true
disable-model-invocation: false
allowed-tools: Bash, Read, Write, Edit, Glob, Grep, Agent
config:
  vault_config: "~/.claude/llm-wiki-vault.json"
  raw_dir: "raw"
  wiki_dir: "wiki"
  concepts_dir: "wiki/concepts"
  agent_config:
    lead_model: "sonnet"
    scout_model: "haiku"
    worker_model: "sonnet"
    reviewer_model: "sonnet"
---

# Multi-Agent LLM Wiki Skill

> 基于 Karpathy 的 [LLM Wiki 模式](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)
>
> **核心理念**：知识只需编译一次并保持最新，不需要每次查询时重新推导。
>
> **协作模式**：蚁群仿生 — Lead(协调) → Scout(侦察) → Worker(执行) → Reviewer(审查)

## 一图理解

```
┌─────────────────────────────────────────────────────────────────┐
│                   Multi-Agent LLM Wiki 工作流                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  用户输入 ──▶ Lead 协调 ──▶ 蚁群协作 ──▶ 结果输出              │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                     蚁群生命周期                         │   │
│  │  🔍 Scout(侦察) → ⚒️ Worker(执行) → 🛡️ Reviewer(审查)    │   │
│  │       │              │               │                    │   │
│  │   探索源文件      创建页面        检查质量                │   │
│  │       │              │               │                    │   │
│  │       └──────────────┴───────────────┘                    │   │
│  │              信息素传递                                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    三大核心操作                           │   │
│  │  Ingest(消化)  →  Query(查询)  →  Lint(检查)            │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 触发命令

| 命令 | 用途 |
|------|------|
| `/llm-wiki init` | 初始化知识库（首次使用引导） |
| `/llm-wiki ingest <file>` | 消化源文件（蚁群协作） |
| `/llm-wiki query <question>` | 查询知识库 |
| `/llm-wiki lint` | 健康检查 |

---

## 蚁群角色体系

### 角色定义

| 角色 | 名称 | 模型 | 职责 |
|------|------|------|------|
| **Lead** | 蚁后/主修 | sonnet | 协调、分解任务、汇总结果 |
| **Scout** | 侦察蚁 | haiku | 快速探索源文件结构 |
| **Worker** | 工蚁 | sonnet | 创建/更新 Wiki 页面 |
| **Reviewer** | 护法 | sonnet | 审查质量、检查矛盾 |

### Lead 指令模板

```
你是 LLM Wiki 的主协调者（Lead）。

职责：
1. 首次用户引导 — 检测状态，引导配置
2. 任务分解 — 将复杂任务分解为子任务
3. 蚁群调度 — 派 Scout/Worker/Reviewer 执行
4. 结果汇总 — 收集各 Agent 结果，统一输出

工作流程：
├── init → 引导用户建立知识库架构
├── ingest → Scout 探索 → Worker 创建 → Reviewer 审查
├── query → 搜索 Wiki → 综合回答
└── lint → 扫描页面 → 输出报告
```

### Scout 指令模板

```
你是 LLM Wiki 的侦察蚁（Scout）。

职责：
1. 快速读取源文件
2. 识别内容结构（主旨、概念、来源）
3. 输出发现摘要

限制：
- 只读操作，不修改任何文件
- 输出简洁，聚焦关键发现
- 使用 haiku 模型，成本最低

输出格式：
├── 文件路径
├── 主旨（一句话）
├── 关键概念（列表）
├── 来源元数据
└── 复杂度评估（简单/中等/复杂）
```

### Worker 指令模板

```
你是 LLM Wiki 的执行者（Worker）。

职责：
1. 根据 Scout 的发现，创建 Wiki 页面
2. 更新 index.md 和 log.md
3. 建立交叉引用

工作范围：
- wiki/ 目录下的文件
- 只创建/更新分配给你的文件

输出：
- 创建的文件列表
- 更新的文件列表
- 遇到的问题（如有）
```

### Reviewer 指令模板

```
你是 LLM Wiki 的审查者（Reviewer）。

职责：
1. 检查 Worker 创建的页面质量
2. 验证格式规范
3. 检查与其他页面的矛盾
4. 发现缺失的交叉引用

检查项：
- 页面格式是否符合模板
- 是否有交叉引用
- 是否有与其他页面的矛盾
- 内容是否准确

输出：
- 通过 ✓
- 问题列表 + 修复建议
```

---

## 首次用户引导流程

### 触发条件

```
用户首次使用 /llm-wiki 命令，且满足以下任一条件：
1. ~/.claude/llm-wiki-vault.json 不存在
2. vault_root 目录不存在
3. 目录结构不完整（缺少 raw/ 或 wiki/）
```

### 引导对话流程

```
用户: /llm-wiki ingest raw/article.md
         ↓
Lead 检测状态
         ↓
┌─────────────────────────────────────────┐
│  📚 首次使用引导                          │
│                                         │
│  检测到你首次使用 LLM Wiki，              │
│  正在为你建立知识库架构...                │
│                                         │
│  请确认知识库存放位置：                   │
│                                         │
│  1️⃣ 使用当前目录                         │
│  2️⃣ 指定其他路径                         │
│  3️⃣ 使用 OneDrive 默认位置               │
└─────────────────────────────────────────┘
         ↓
用户选择/输入路径
         ↓
Lead 验证目录
         ↓ (不存在)
自动创建目录结构
         ↓
创建模板文件
         ↓
保存配置文件
         ↓
✅ 初始化完成
         ↓
继续执行原命令
```

### 自动创建的目录结构

```
vault_root/
├── raw/                    # 原始文档（不可变）
│   ├── articles/           # 文章
│   ├── papers/             # 论文
│   └── assets/             # 图片/附件
├── wiki/                   # Wiki 页面（LLM 维护）
│   ├── index.md            # 全局索引
│   ├── log.md              # 操作日志
│   ├── concepts/           # 概念页面
│   └── topics/             # 主题页面
├── .claude/                # Claude Code 配置
└── CLAUDE.md               # Schema 说明
```

### 模板文件

#### index.md

```markdown
# Wiki 索引

所有 wiki 页面的全局目录。

## 最近更新

- [[log]] — 操作日志
```

#### log.md

```markdown
# 操作日志

按时间顺序记录所有知识库的维护操作。
```

#### CLAUDE.md

```markdown
# CLAUDE.md — LLM Wiki Schema

## 目录结构
raw/     → 原始文档（不可变）
wiki/    → Wiki 页面（LLM 维护）

## 三项核心操作
- Ingest: 消化源文件 → Wiki 页面
- Query: 查询知识库
- Lint: 健康检查
```

---

## Ingest 操作（消化）

### 完整流程

```
用户: /llm-wiki ingest raw/article.md
         ↓
Lead 协调
         ↓
┌─────────────────────────────────────────────────────┐
│  🔍 Scout Phase (侦察)                               │
│                                                     │
│  Scout 探索源文件：                                  │
│  - 读取 raw/articles/article.md                     │
│  - 分析内容结构                                      │
│  - 输出：主旨、概念列表、来源元数据                  │
│                                                     │
│  蚁间素: { discovery: true, concepts: [...], ... }  │
└─────────────────────────────────────────────────────┘
         ↓ 信息素传递
┌─────────────────────────────────────────────────────┐
│  ⚒️ Worker Phase (执行)                              │
│                                                     │
│  Worker 根据 Scout 发现：                            │
│  - 创建 wiki/文章标题.md (摘要页)                   │
│  - 创建 wiki/concepts/概念N.md (概念页)             │
│  - 更新 wiki/index.md (添加入口)                     │
│  - 更新 wiki/log.md (记录操作)                       │
│                                                     │
│  蚁间素: { progress: true, files: [...], ... }     │
└─────────────────────────────────────────────────────┘
         ↓ 信息素传递
┌─────────────────────────────────────────────────────┐
│  🛡️ Reviewer Phase (审查)                            │
│                                                     │
│  Reviewer 检查：                                    │
│  - 页面格式是否规范                                  │
│  - 交叉引用是否完整                                  │
│  - 是否有矛盾                                        │
│                                                     │
│  输出：通过 ✓ 或 问题列表                           │
└─────────────────────────────────────────────────────┘
         ↓
Lead 汇总结果
         ↓
输出：
- 创建的页面
- 更新的页面
- 审查结果
```

### Scout 详细指令

```
# Scout 侦察指令

你正在分析以下源文件：
{files}

请执行：

1. 读取每个文件的完整内容
2. 识别以下信息：
   - 主旨：这篇文章讲什么（1-2句话）
   - 关键概念：提取 3-10 个核心概念
   - 来源元数据：作者、日期、URL、标题
   - 内容类型：技术文章/论文/公众号/新闻/其他
3. 评估复杂度：
   - 简单：单一主题，无复杂概念
   - 中等：2-3 个主题，概念较清晰
   - 复杂：多主题，概念交叉，需要深入分析

4. 输出 JSON 格式：
{
  "files": [
    {
      "path": "...",
      "title": "...",
      "summary": "...",
      "concepts": ["概念1", "概念2", ...],
      "metadata": { "author": "...", "date": "...", "url": "..." },
      "complexity": "simple|medium|complex"
    }
  ]
}

限制：只读，不修改任何文件
```

### Worker 详细指令

```
# Worker 执行指令

Scout 已完成侦察，发现了以下内容：
{scout_discovery}

现在请执行：

1. 创建摘要页（wiki/{title}.md）
   使用模板：
   ---
   # 页面标题

   > **来源**: 作者 | 日期
   > **链接**: [URL]

   ## 摘要
   一段概述。

   ## 关键要点
   - 要点 1
   - 要点 2

   ## 来源
   - [[来源标题]]

   ## 相关
   - [[相关页面]]
   ---

2. 创建概念页（wiki/concepts/{concept}.md）
   每个概念一页，使用标准模板。

3. 更新 index.md
   在相关分类下添加新页面入口。

4. 更新 log.md
   添加本次 ingest 的记录。

5. 输出创建的文件列表

限制：只创建/更新分配给你的文件
```

### Reviewer 详细指令

```
# Reviewer 审查指令

Worker 已完成以下文件的创建：
{created_files}

请检查：

1. 格式规范
   - 是否符合模板格式
   - frontmatter 是否正确
   - 是否包含必要章节

2. 内容质量
   - 摘要是否准确反映主旨
   - 关键要点是否完整
   - 概念定义是否清晰

3. 交叉引用
   - 相关页面引用是否正确
   - 概念页是否相互链接
   - index.md 是否已更新

4. 一致性检查
   - 是否与现有页面矛盾
   - 是否有重复内容
   - 命名是否一致

输出：
{
  "status": "pass|fail",
  "issues": [
    { "file": "...", "issue": "...", "severity": "error|warning|info" }
  ],
  "suggestions": ["..."]
}
```

---

## Query 操作（查询）

### 流程

```
用户: /llm-wiki query RAG和Wiki有什么区别
         ↓
Lead 协调
         ↓
┌─────────────────────────────────────┐
│  🔍 搜索 Wiki                       │
│                                     │
│  1. 读取 index.md                   │
│  2. 搜索相关页面                    │
│  3. 收集相关内容                    │
└─────────────────────────────────────┘
         ↓
Lead 综合回答
         ↓
输出：
- 综合回答
- 来源引用
- 建议归档（如有价值）
```

### Query 详细指令

```
# Query 查询指令

用户问题：{question}

请执行：

1. 搜索相关页面
   - 读取 wiki/index.md 找到相关分类
   - 搜索包含关键词的页面
   - 读取相关页面的完整内容

2. 综合回答
   - 聚合多个页面的信息
   - 提炼核心答案
   - 标注关键引用

3. 评估归档价值
   - 这个回答是否值得归档为新页面
   - 是否补充了现有页面的不足

4. 输出格式：
   ---
   # 查询结果

   ## 回答
   {综合回答}

   ## 来源
   - [[页面A]]
   - [[页面B]]

   ---
   💡 建议归档为新页面
   ---
```

---

## Lint 操作（检查）

### 流程

```
用户: /llm-wiki lint
         ↓
┌─────────────────────────────────────┐
│  Bash 脚本扫描                      │
│                                     │
│  node scripts/lint.js               │
│                                     │
│  检查项：                           │
│  - 孤立页面                         │
│  - 矛盾内容                         │
│  - 缺失链接                         │
│  - 过期内容                         │
└─────────────────────────────────────┘
         ↓
Lead 汇总报告
         ↓
输出：
- 问题列表
- 严重程度
- 修复建议
```

### 检查项定义

| 检查项 | 说明 | 严重程度 |
|--------|------|----------|
| `orphan_pages` | 没有页面引用它 | warning |
| `outdated_assertions` | 被新来源否定的旧说法 | error |
| `contradictions` | 页面间的矛盾陈述 | error |
| `missing_pages` | 重要概念被提及但无独立页面 | info |
| `stale_pages` | 超过 30 天未更新的页面 | warning |
| `missing_links` | 可以添加但缺失的链接 | info |

---

## 配置管理

### 配置文件位置

`~/.claude/llm-wiki-vault.json`

### 配置格式

```json
{
  "version": "1.0.0",
  "vault_root": "C:/Users/Administrator/OneDrive/AI Agent",
  "raw_dir": "raw",
  "wiki_dir": "wiki",
  "concepts_dir": "wiki/concepts",
  "index_file": "wiki/index.md",
  "log_file": "wiki/log.md",
  "initialized": true,
  "initialized_at": "2026-05-27"
}
```

---

## 脚本使用

```bash
# 初始化
node ~/.claude/skills/multi-agent-llm-wiki/scripts/init.js [--path <vault-root>]

# 健康检查
node ~/.claude/skills/multi-agent-llm-wiki/scripts/lint.js [--json]

# 验证 vault 结构
node ~/.claude/skills/multi-agent-llm-wiki/scripts/validate.js
```

---

## 错误处理

| 错误 | 处理方式 |
|------|----------|
| vault 未配置 | 触发首次用户引导 |
| 源文件不存在 | 输出 "文件不存在: {path}" |
| 目录结构缺失 | 自动创建或提示创建 |
| 配置文件损坏 | 提示重新初始化 |

---

## 经典语录

> **"Obsidian is the IDE; the LLM is the programmer; the wiki is the codebase."**
>
> **"LLM does all the grunt work — the summarizing, cross-referencing, filing, and bookkeeping."**
>
> **"Human's job is to curate sources, guide analysis, ask good questions, and think about meaning. LLM's job is everything else."**

---

## 相关

- [[LLMWiki模式]] — Karpathy LLM Wiki 模式详解
- [ccg:multi-agent] — 蚁群协作模式详解