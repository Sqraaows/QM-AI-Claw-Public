## Description: <br>
Claid AI lets an agent operate Claid AI image editing through an OOMOL-connected account for synchronous edits, asynchronous edit submission, and task polling. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to inspect Claid AI connector schemas, run image editing actions with JSON payloads, and retrieve processed image metadata or asynchronous task results. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Claid AI account and may use sensitive account credentials through OOMOL. <br>
Mitigation: Install only if you trust OOMOL and intend to let the agent use the connected Claid AI account. <br>
Risk: Image editing actions may change Claid AI state or consume credits. <br>
Mitigation: Review generated payloads and confirm the intended edit before approving write actions. <br>
Risk: First-time setup can install or invoke a remote CLI installer. <br>
Mitigation: Use the remote CLI installer only from the documented OOMOL source. <br>


## Reference(s): <br>
- [Claid AI homepage](https://claid.ai) <br>
- [Claid AI Skill on ClawHub](https://clawhub.ai/oomol/oo-claid-ai) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses include Claid AI data and OOMOL execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
