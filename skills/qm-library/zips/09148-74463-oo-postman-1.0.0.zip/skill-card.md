## Description: <br>
Postman (postman.com). Use this skill for Postman requests, including reading, creating, updating, and deleting data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and API teams use this skill to operate Postman workspaces, collections, requests, environments, APIs, specifications, schemas, mocks, monitors, comments, forks, pull requests, and account metadata from an agent workflow. It is suited for both read-only inspection and state-changing Postman administration when the user has connected the appropriate OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill broadly enables sensitive reads and high-impact Postman changes through a connected account. <br>
Mitigation: Install it only for intended Postman administration, use the least-privileged Postman connection available, and require explicit approval before write, delete, publish, sync, run, or review actions. <br>
Risk: Some actions can expose access keys, team user lists, email addresses, billing records, environment variables, or global variable values. <br>
Mitigation: Avoid printing or logging these values unless they are necessary for the task, and redact sensitive fields in shared outputs. <br>
Risk: Destructive actions can permanently remove or overwrite Postman resources. <br>
Mitigation: Confirm the target resource, payload, and expected effect with the user before running destructive or state-changing commands. <br>


## Reference(s): <br>
- [Postman homepage](https://www.postman.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-postman) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, Guidance, Text] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads; connector responses are JSON.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires live schema inspection before constructing connector payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
