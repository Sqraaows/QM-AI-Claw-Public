## Description: <br>
Foxit Cloud API helps agents operate Foxit document-processing actions through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to upload, convert, merge, split, protect, OCR, extract, compare, and retrieve PDF or Office documents through Foxit Cloud API workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Documents submitted through this skill may be processed by Foxit/OOMOL cloud services. <br>
Mitigation: Use the skill only for documents that may be shared with those services and confirm sharing is acceptable before upload, conversion, OCR, comparison, extraction, or editing. <br>
Risk: Some actions can write, remove, or alter document content or page structure. <br>
Mitigation: Review the exact payload and intended effect before write, remove, or page-deletion operations, and obtain explicit user approval for destructive actions. <br>


## Reference(s): <br>
- [ClawHub listing for Foxit Cloud API](https://clawhub.ai/oomol/oo-fuxin) <br>
- [Foxit Cloud API homepage](https://cloudapi.fuxinsoft.cn) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, text] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses from the oo CLI and may produce document IDs, task status, quota details, or downloadable file references.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence release version and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
