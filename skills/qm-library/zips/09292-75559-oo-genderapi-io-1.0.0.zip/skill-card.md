## Description: <br>
GenderAPI.io helps agents infer likely gender from a first name, username, or email address through an OOMOL-connected GenderAPI.io account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to query GenderAPI.io for gender inference from names, usernames, and email addresses without handling raw service credentials directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill submits names, usernames, and email addresses to GenderAPI.io through an OOMOL-connected account, which can involve personal data. <br>
Mitigation: Confirm there is a legitimate basis or consent before submitting personal data, and review GenderAPI.io and OOMOL data handling terms for the intended use case. <br>
Risk: Gender inference can be incorrect or inappropriate for some contexts. <br>
Mitigation: Treat results as probabilistic signals, avoid using them as the sole basis for consequential decisions, and review outputs before downstream use. <br>
Risk: The connector requires an authenticated OOMOL account and an active GenderAPI.io connection. <br>
Mitigation: Use the documented one-time setup only after auth or connection failures, and avoid exposing raw credentials in prompts, logs, or generated files. <br>


## Reference(s): <br>
- [GenderAPI.io homepage](https://www.genderapi.io) <br>
- [GenderAPI.io ClawHub release](https://clawhub.ai/oomol/oo-genderapi-io) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are returned by the oo CLI as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
