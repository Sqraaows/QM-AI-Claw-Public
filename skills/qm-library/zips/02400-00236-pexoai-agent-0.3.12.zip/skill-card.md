## Description: <br>
Pexo helps agents create finished multi-shot AI videos from text, images, URLs, scripts, or audio using Pexo's hosted video generation workflow. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[rainer-liao](https://clawhub.ai/user/rainer-liao) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill through an agent to submit video briefs, upload source media, monitor Pexo projects, handle preview choices, and deliver final video links or files. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a Pexo API key and uses a shell-sourced configuration file. <br>
Mitigation: Store the key only in a trusted, permission-restricted ~/.pexo/config file and avoid using PEXO_CONFIG paths controlled by untrusted users. <br>
Risk: Video generation requests can use paid credits or trigger billing-related flows. <br>
Mitigation: Confirm user intent before creating or retrying projects, monitor credit errors, and direct users to Pexo account controls for purchases. <br>
Risk: Uploading user-provided URLs or local files can expose private or sensitive data to Pexo. <br>
Mitigation: Do not download private-network, internal, sensitive, or untrusted URLs for upload, and review files before submitting them to Pexo projects. <br>


## Reference(s): <br>
- [Pexo homepage](https://pexo.ai) <br>
- [Pexo OpenClaw connection guide](https://pexo.ai/connect/openclaw) <br>
- [ClawHub skill listing](https://clawhub.ai/rainer-liao/pexoai-agent) <br>
- [Setup Checklist](references/SETUP-CHECKLIST.md) <br>
- [Troubleshooting](references/TROUBLESHOOTING.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Plain text or Markdown agent replies with bash command usage, JSON service responses, project links, signed video URLs, and local video file paths.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires PEXO_API_KEY and PEXO_BASE_URL; generated videos are handled by Pexo projects and may consume credits.] <br>

## Skill Version(s): <br>
0.3.12 (source: server release metadata; artifact frontmatter reports 0.3.11) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
