## Description: <br>
Operate Gitea through an OOMOL-connected account to read repository and issue data and create issues or issue comments via the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to inspect Gitea repositories, retrieve user and issue information, search repositories, and create issues or issue comments after confirming write actions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive credentials through an OOMOL-connected Gitea account. <br>
Mitigation: Review requested tools, connected account scopes, and credential state before use, especially when future versions add account actions or broader external-service access. <br>
Risk: Issue and issue-comment actions change Gitea state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before creating issues or posting comments. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema before constructing payloads and use the returned schema as the authoritative contract. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-gitea) <br>
- [Gitea Product Page](https://about.gitea.com/products/gitea/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; command responses are JSON when actions are run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
