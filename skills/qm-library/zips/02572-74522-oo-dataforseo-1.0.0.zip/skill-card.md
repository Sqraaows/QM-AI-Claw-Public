## Description: <br>
DataForSEO helps agents query SEO, SERP, keyword, backlink, domain ranking, traffic, and DataForSEO account data through OOMOL's connected DataForSEO service. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, marketers, and SEO analysts use this skill to inspect DataForSEO schemas and run read-oriented live queries for search volume, keyword ideas, SERP competitors, ranking overviews, backlinks, relevant pages, and account usage. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Live DataForSEO requests may consume account credits, especially for large or repeated keyword, SERP, and backlink queries. <br>
Mitigation: Review the action, payload size, and expected scope before running high-volume requests. <br>
Risk: The account lookup action can expose balance, usage, rates, limits, and related DataForSEO account details to the active agent session. <br>
Mitigation: Run account inspection only when that information is needed, and avoid sharing returned account details beyond the intended workflow. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before building each payload. <br>


## Reference(s): <br>
- [DataForSEO homepage](https://dataforseo.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub DataForSEO skill page](https://clawhub.ai/oomol/oo-dataforseo) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with bash command examples and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetch the live connector schema before constructing payloads; live DataForSEO requests may consume account credits.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
