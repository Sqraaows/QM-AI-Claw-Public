## Description: <br>
Operates connected Twilio accounts through OOMOL for reading account, message, and usage data and sending SMS or MMS messages. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operations teams use this skill to operate a connected Twilio account through OOMOL, including reading account details, listing or retrieving messages, sending SMS or MMS messages, and reviewing usage records. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Using OOMOL as an intermediary for a Twilio account may expose account operations to a third-party connector workflow. <br>
Mitigation: Install only when that intermediary is acceptable for the intended Twilio account and organization. <br>
Risk: Sending SMS or MMS messages can contact real recipients and may incur Twilio costs. <br>
Mitigation: Confirm the exact recipient, payload, media, and intended effect with the user before running the send action. <br>
Risk: The skill suggests remote installer commands when the oo CLI is missing. <br>
Mitigation: Verify the OOMOL installer source before running remote install commands. <br>


## Reference(s): <br>
- [Twilio homepage](https://www.twilio.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-twilio) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API calls, JSON, Guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schema inspection before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
