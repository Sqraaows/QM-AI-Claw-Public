## Description: <br>
Addressfinder supports address autocomplete search, selected-address metadata lookup, and address verification for Australia and New Zealand through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to search Addressfinder autocomplete, retrieve address metadata, and verify or enrich Australian and New Zealand addresses. It is suited for workflows that already use OOMOL as the intermediary for Addressfinder access. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Address queries and verification payloads may contain personal or location data. <br>
Mitigation: Use only data you are allowed to send to OOMOL and Addressfinder, and review payloads before execution. <br>
Risk: The skill requires OOMOL as the intermediary for Addressfinder and may involve first-time CLI install or login steps. <br>
Mitigation: Install only when OOMOL-mediated Addressfinder access is intended, and review first-time install or authentication commands before running them. <br>
Risk: Addressfinder connector schemas may change upstream. <br>
Mitigation: Inspect the live connector schema before constructing action payloads. <br>


## Reference(s): <br>
- [Addressfinder homepage](https://addressfinder.com/au) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-addressfinder) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector action responses are JSON objects with data and meta.executionId when commands run.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
