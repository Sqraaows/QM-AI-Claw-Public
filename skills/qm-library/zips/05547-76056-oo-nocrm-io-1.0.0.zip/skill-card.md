## Description: <br>
noCRM.io (nocrm.io). Use this skill for noCRM.io requests involving reading, creating, updating, and deleting data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and teams use this skill to operate noCRM.io lead workflows from an agent, including creating leads, assigning users, tagging leads, changing statuses, duplicating records, deleting leads, and listing teams. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create, update, duplicate, assign, tag, cancel, and delete noCRM.io leads. <br>
Mitigation: Verify the exact lead, payload, and intended effect before any state-changing action; require explicit approval before deleting data. <br>
Risk: The skill requires access to an OOMOL-connected noCRM.io account. <br>
Mitigation: Install only when the user intends to let an agent operate that account, and rely on the OOMOL connection flow instead of handling raw credentials. <br>


## Reference(s): <br>
- [noCRM.io homepage](https://www.nocrm.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-nocrm-io) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: skill metadata and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
