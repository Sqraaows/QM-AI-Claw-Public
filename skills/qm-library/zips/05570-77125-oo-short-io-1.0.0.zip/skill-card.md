## Description: <br>
Use this skill to read, create, update, delete, and analyze Short.io links through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Short.io domains, links, and link statistics from an agent using OOMOL connector commands. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to an OOMOL-connected Short.io account with sensitive credentials. <br>
Mitigation: Install it only when the agent is intended to use that connected account, and review connector access before use. <br>
Risk: Create, update, and delete actions can change or remove live Short.io links. <br>
Mitigation: Confirm the exact payload, target, and intended effect with the user before running write or destructive actions. <br>


## Reference(s): <br>
- [ClawHub Skill: Short.io](https://clawhub.ai/oomol/oo-short-io) <br>
- [Short.io homepage](https://short.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [create_link action reference](actions/create_link.md) <br>
- [delete_link action reference](actions/delete_link.md) <br>
- [get_link_statistics action reference](actions/get_link_statistics.md) <br>
- [update_link action reference](actions/update_link.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live Short.io connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
