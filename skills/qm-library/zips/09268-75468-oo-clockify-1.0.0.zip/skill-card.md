## Description: <br>
Clockify connector skill for reading, creating, updating, and deleting Clockify data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Users with OOMOL-connected Clockify accounts use this skill to inspect Clockify workspaces, projects, tasks, users, and time entries, and to create, update, or delete Clockify records when requested. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can operate a connected Clockify account through OOMOL, including access to time-tracking and workspace data. <br>
Mitigation: Install only when this account access is intended, and review Clockify account scope before use. <br>
Risk: Create, update, and delete actions can change or remove Clockify records. <br>
Mitigation: Require explicit user confirmation of the target, payload, and expected effect before running write or destructive actions. <br>
Risk: First-time setup may involve running an OOMOL CLI installer from the shell. <br>
Mitigation: Run the installer only after verifying that the OOMOL CLI source is trusted for the environment. <br>


## Reference(s): <br>
- [Clockify homepage](https://clockify.me) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub Clockify skill](https://clawhub.ai/oomol/oo-clockify) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
