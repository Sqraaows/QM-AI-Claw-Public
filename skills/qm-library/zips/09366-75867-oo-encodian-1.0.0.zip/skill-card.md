## Description: <br>
Encodian helps agents operate Encodian PDF actions through an OOMOL-connected account using the oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to compress PDFs, extract pages, read text layers, secure documents, and unlock password-protected PDFs through their connected Encodian account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: PDFs selected for processing are sent through the user's OOMOL-connected Encodian account. <br>
Mitigation: Only process documents approved for that connected service, and confirm users are comfortable with the document handling path before submitting sensitive PDFs. <br>
Risk: The oo CLI installer, authentication flow, or Encodian connection may be required before actions can run. <br>
Mitigation: Review the oo CLI installer and only authenticate or connect Encodian when a command fails because the CLI, sign-in, or connection is missing. <br>
Risk: Connector fields and defaults can change upstream. <br>
Mitigation: Fetch the live Encodian action schema before building each payload, then send only data that matches the current schema. <br>


## Reference(s): <br>
- [ClawHub Encodian Skill](https://clawhub.ai/oomol/oo-encodian) <br>
- [Encodian Homepage](https://www.encodian.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, JSON, Files, Text, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands; connector responses are JSON and may include base64 PDF content or extracted text.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions inspect the live connector schema before execution and return Encodian results through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
