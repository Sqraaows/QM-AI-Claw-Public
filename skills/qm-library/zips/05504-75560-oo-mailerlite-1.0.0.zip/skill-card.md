## Description: <br>
Use this skill for MailerLite requests involving reading, creating, updating, and deleting subscriber, group, and field data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and agents use this skill to operate a connected MailerLite account through OOMOL, including subscriber workflows, group management, group membership changes, and field discovery. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change or remove MailerLite audience data through delete, remove, update, and upsert actions. <br>
Mitigation: Require the agent to show the target, payload, and intended effect before approval, and require explicit approval for destructive actions. <br>
Risk: The skill operates a connected MailerLite account through OOMOL and requires sensitive credentials to be connected. <br>
Mitigation: Install only when the user intends to let an agent operate the MailerLite account through OOMOL. <br>


## Reference(s): <br>
- [MailerLite homepage](https://www.mailerlite.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [MailerLite Skill on ClawHub](https://clawhub.ai/oomol/oo-mailerlite) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill instructs agents to inspect live connector schemas before constructing JSON payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
