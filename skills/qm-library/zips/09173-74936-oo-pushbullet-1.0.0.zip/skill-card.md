## Description: <br>
Operate a connected Pushbullet account through the OOMOL `oo` CLI to read, create, update, and delete Pushbullet data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to manage Pushbullet chats, devices, pushes, and profile data through a connected OOMOL account without handling raw Pushbullet API tokens. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and change Pushbullet account data through a connected OOMOL account. <br>
Mitigation: Review payloads before approving sends, updates, or deletes. <br>
Risk: `delete_all_pushes` and other delete actions can remove Pushbullet data. <br>
Mitigation: Confirm the target and get explicit approval before destructive actions. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-pushbullet) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [Pushbullet Homepage](https://www.pushbullet.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses `oo connector schema` and `oo connector run` commands that return JSON responses containing `data` and `meta.executionId`.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
