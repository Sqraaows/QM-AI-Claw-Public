## Description: <br>
Google Drive skill for reading, creating, updating, sharing, downloading, exporting, and deleting Drive data through the OOMOL googledrive connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents and developers use this skill to operate a connected Google Drive account from ClawHub workflows, including file search, metadata lookup, upload, download, export, sharing, comments, revisions, labels, trash, and shared drive management. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change Google Drive state by creating, editing, sharing, moving, trashing, or deleting files, folders, permissions, comments, replies, revisions, labels, and shared drives. <br>
Mitigation: Review the exact action payload and intended effect before write operations, and require explicit user approval for destructive operations. <br>
Risk: The skill requires OOMOL-connected Google Drive access, so agent actions can affect the connected account's Drive data. <br>
Mitigation: Install and use the skill only with an account and scopes appropriate for the task, and treat oo CLI authentication and connector setup as trusted-account setup steps. <br>
Risk: Downloaded or exported Drive content may expose sensitive data through transit URLs or agent-visible outputs. <br>
Mitigation: Limit downloads and exports to files the user requested, and avoid sharing returned content or transit URLs beyond the intended workflow. <br>


## Reference(s): <br>
- [Google Drive homepage](https://workspace.google.com/products/drive/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Google Drive connection](https://console.oomol.com/app-connections?provider=googledrive) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
