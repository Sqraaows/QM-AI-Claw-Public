## Description: <br>
Use when the user asks to create, edit, read, or export Google Slides presentations, including decks, speaker notes, slide images, markdown-to-slides, template replacement, and exports to PDF or PPTX. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to configure and operate a Google Slides MCP server for creating, reading, editing, and exporting presentations through authenticated gogcli tooling. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill exposes a broad gog_slides_run escape hatch that is not tightly described. <br>
Mitigation: Review proposed gog_slides_run actions before execution and prefer the named Slides tools for routine operations. <br>
Risk: Mutating slide operations can edit, delete, export, or replace presentation content through the authenticated account. <br>
Mitigation: Install only for trusted workflows, confirm presentation targets and requested changes, and use an authenticated Google account appropriate for the task. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/gogcli-mcp-slides) <br>
- [gogcli project](https://github.com/openclaw/gogcli) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Configuration, Shell commands, Text, Markdown, Files] <br>
**Output Format:** [Markdown with JSON configuration snippets, tool-oriented guidance, and presentation export files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed and authenticated gogcli setup and a Google account selected through GOG_ACCOUNT.] <br>

## Skill Version(s): <br>
2.4.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
