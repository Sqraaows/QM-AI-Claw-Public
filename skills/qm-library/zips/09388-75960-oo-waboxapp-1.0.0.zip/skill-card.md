## Description: <br>
waboxapp helps agents use the Waboxapp connector to check WhatsApp account status and send text, image, link, or media messages through a connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and automation users use this skill when an agent needs to operate Waboxapp through an OOMOL-connected account, including account status checks and WhatsApp message sending workflows. Send actions should be used only after confirming the recipient, content, media URL, and intended effect. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send WhatsApp text, image, link, and media messages through the connected Waboxapp account. <br>
Mitigation: Confirm recipients, message content, media URLs, and intended effects with the user before running any send action. <br>
Risk: First-time setup may require installing the oo CLI with a shell install command. <br>
Mitigation: Install only when the CLI is missing, review the install source, and use trusted OOMOL CLI installation instructions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-waboxapp) <br>
- [waboxapp homepage](https://www.waboxapp.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands use the oo CLI with JSON payloads and JSON responses; Waboxapp credentials are handled through the connected OOMOL account.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
