## Description: <br>
This skill should be used when the user asks about Infinite Campus (Campus Parent) data for their student(s), including grades, assignments, attendance, messages, documents, and related school information. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and their agents use this skill to configure and operate an Infinite Campus Campus Parent MCP server for authorized access to student grades, attendance, assignments, messages, documents, fees, and related school records. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access sensitive school records and account data. <br>
Mitigation: Install and use it only for an authorized student or parent account, and apply least-privilege configuration. <br>
Risk: Credentials and browser-session access can expose an Infinite Campus account. <br>
Mitigation: Treat IC_USERNAME, IC_PASSWORD, and browser-session cookies as sensitive, and disable fetchproxy when browser cookie use is not desired. <br>
Risk: Downloaded documents or outbound messages may contain sensitive or unintended content. <br>
Mitigation: Review downloaded documents and any outbound messages before allowing the agent to act on or send them. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/infinitecampus-mcp) <br>
- [npm package: infinitecampus-mcp](https://www.npmjs.com/package/infinitecampus-mcp) <br>
- [Source repository: infinitecampus-mcp](https://github.com/chrischall/infinitecampus-mcp) <br>
- [fetchproxy fallback extension](https://github.com/chrischall/fetchproxy) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with JSON and bash code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include MCP setup configuration and guidance for accessing authorized Infinite Campus Campus Parent data.] <br>

## Skill Version(s): <br>
2.3.2 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
