## Description: <br>
Fidel API lets an agent inspect schemas and run read-oriented Fidel API brand, card, and transaction queries through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to retrieve Fidel API brands, cards, and transactions from an already connected OOMOL account. The skill guides the agent to inspect the live connector schema before constructing JSON payloads. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can query a connected Fidel API account and may expose card, customer, or transaction data. <br>
Mitigation: Use it only with accounts and scopes appropriate for the task, and require approval before actions that could reveal sensitive financial or customer data. <br>
Risk: First-time setup may involve installing the oo CLI with a shell installer. <br>
Mitigation: Review the installer and source before running curl-to-bash or PowerShell setup commands. <br>
Risk: The workflow depends on OOMOL as the intermediary for Fidel API credentials. <br>
Mitigation: Install only when the user trusts OOMOL for the connected Fidel API account and its credential handling. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-fidel-api) <br>
- [Fidel API homepage](https://fidel.uk) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON API responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses include connector data and a meta.executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: artifact metadata and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
