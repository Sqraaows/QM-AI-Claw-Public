## Description: <br>
TPSCheck helps an agent check UK phone numbers against TPS and CTPS and retrieve TPSCheck account credit information through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to screen individual or batched UK phone numbers against TPS and CTPS, then inspect TPSCheck account usage and remaining request credits. <br>

### Deployment Geography for Use: <br>
Global use for workflows that process UK phone numbers <br>

## Known Risks and Mitigations: <br>
Risk: The skill can submit UK phone numbers to TPSCheck through OOMOL. <br>
Mitigation: Use it only when you have permission to process those phone numbers and are comfortable sending them to the connected TPSCheck service. <br>
Risk: The skill depends on an authenticated oo CLI connection and TPSCheck account credits. <br>
Mitigation: Review the setup step before execution and confirm the account has an active connection and sufficient credits for the requested checks. <br>


## Reference(s): <br>
- [TPSCheck homepage](https://www.tpscheck.uk) <br>
- [ClawHub TPSCheck release](https://clawhub.ai/oomol/oo-tpscheck) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses may include TPSCheck data and oo CLI execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
