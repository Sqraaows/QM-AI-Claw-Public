## Description: <br>
Operate Paystack through an OOMOL-connected account for reading, creating, and updating customers and transactions without handling raw API tokens. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, finance operators, and support agents use this skill to inspect Paystack connector schemas and run customer or transaction actions through an authenticated OOMOL connection. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Write actions can create or update Paystack records through the connected account. <br>
Mitigation: Confirm the exact payload and intended effect with the user before running create or update actions. <br>
Risk: Connector inputs and outputs can change upstream. <br>
Mitigation: Inspect the live action schema before constructing payloads and use JSON data that matches that schema. <br>
Risk: The skill depends on an authenticated OOMOL account and connected Paystack credentials. <br>
Mitigation: Use the first-time setup steps only after an authentication, connection, scope, credential, or billing error is returned. <br>


## Reference(s): <br>
- [Paystack homepage](https://paystack.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-paystack) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, JSON, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires the oo CLI, an authenticated OOMOL account, and connected Paystack credentials.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
