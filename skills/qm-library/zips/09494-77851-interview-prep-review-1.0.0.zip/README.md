<div align="center">

# Interview Prep Review

**面试准备与复盘系统 · Interview Preparation & Review System**

[中文](#中文) · [English](#english)

</div>

---

<a id="中文"></a>

# 🎯 Interview Prep Review（中文）

## 它解决什么问题

**面试前，你不知道该准备什么。**
同一个 JD，不同轮次考的完全不同。初面考执行力，中面考协作和行业积累，终面考战略思维。用同一套策略打所有轮次，是最高频的失败原因。

**面试中，你没法把脑子里有的东西说清楚。**
你做了很多事，但被问到"你怎么做需求优先级排序""怎么推进一个跨部门项目"时，你说得零散、没有结构。不是因为不知道怎么做，是缺少一套把经验翻译成方法论的语言。

**面完了，你不知道下一场怎么改进。**
感觉答得不好，但说不清到底哪里出了问题。下一场面试继续犯同样的错误。反复卡在同类型问题上——定义类、压力类、方法论类——但你没有意识到这是一个模式。

## 它提供什么能力

- **把 JD 翻译成"面试官真正想考什么"**——从岗位职责中识别隐性需求，判断这个 JD 真正在找什么样的人
- **按轮次制定策略**——初面展示执行力、中面展示行业理解、终面展示战略思维，在不同轮次做不同的事
- **把个人经验系统化**——用三段式定义法、STAR+方法论提炼等框架，把你做过的事翻译成高管听得懂的语言
- **客观复盘，不被自我感觉带偏**——逐题拆解你的回答与面试官期望之间的差距，以记录为准，不受"我觉得还行"影响
- **识别你的卡点模式**——找出你反复在哪类问题上摔倒，告诉你该练什么

## 你能得到什么结果

- 每场面试前，清楚的知道这一轮该展示什么、不该展示什么
- 被问到抽象概念时不再卡住，而是有框架、有案例、有总结地回应
- 面完后有一份客观的复盘，而不是模糊的"感觉还行"
- 不会在同一个类型的面试问题上连续失败两次
- 和高管层对话时，说的是他们听得懂的语言——分层、框架、方法论——而不是朴素的"我做过这个"

## 使用方法

### 方式一：GitHub 链接（推荐）

直接把以下链接丢给任意 Agent，Agent 会自动下载并安装 skill：

```
https://github.com/xingxiaoyiyio/interview-prep-review
```

### 方式二：手动安装

把文件夹放到你的 Agent skills 目录：

```bash
# Claude Code
cp -r interview-prep-review ~/.claude/skills/

# 其他 Agent 工具放到对应的 skills 文件夹
```

触发后，在对话中直接输入：
- **"帮我准备XX公司的终面" / "帮我分析这个JD"** → 进入准备模式
- **"帮我复盘这场面试" / "我刚面完XX"** → 进入复盘模式

### 方式三：其他 AI 助手

将 SKILL.md 和相关 reference 文件作为附件或上下文提供给任意 AI 助手，告知"请按照这套方法论帮我准备/复盘面试"即可。不限定具体平台或工具。

## 文件结构

```
interview-prep-review/
├── SKILL.md                    # 主入口：触发条件 + 双流程总览
├── README.md                   # 本文件
└── references/
    ├── preparation-workflow.md  # 准备模式完整流程 + 输出物模板
    ├── review-workflow.md       # 复盘模式完整流程 + 输出物模板
    ├── interview-rounds.md      # 初面/中面/终面的考核重点与策略
    ├── question-frameworks.md   # 6类问题的回答框架（通用版）
    └── rhythm-control.md        # 开场定调、打断节奏、拉升维度技巧
```

## 设计原则

- **不预置个人案例**——所有分析基于用户输入，不绑定任何个人经历
- **逐题拆解**——每道题从"你的回答→面试官期望→问题本质→结构化回答"四个维度展开
- **不受用户自我感觉左右**——以面试记录为准，诚实指出问题
- **轮次分层**——初面/中面/终面的策略完全不同，不做一刀切

## 适用场景

- 正在准备资深产品经理/架构师/解决方案负责人的面试
- 刚面完一场需要冷静、客观的复盘分析
- 想在终面/高管面中展示系统化思维能力
- 反复在同类型的面试问题上卡住，需要识别模式并针对性提升

## License

MIT

---

<a id="english"></a>

# 🎯 Interview Mastery（English）

## Problems It Solves

**Before the interview, you don't know what to prepare for.**
The same JD means very different things across rounds. First round tests execution. Middle rounds test collaboration and industry depth. The final round tests strategic thinking. Using the same approach for all rounds is the #1 reason experienced hires fail at executive interviews.

**During the interview, you can't articulate what you know.**
You've done a lot, but when asked "How do you prioritize requirements?" or "How did you drive a cross-team project?", your answer lacks structure. Not because you don't know how — because you lack the language to translate hands-on experience into structured thinking.

**After the interview, you don't know how to improve.**
You have a vague sense it didn't go well, but can't pinpoint what went wrong. Next interview, same mistakes. You keep stumbling on the same question types — definition questions, pressure tests, methodology questions — without recognizing the pattern.

## What It Provides

- **Decode the JD** — surface the hidden needs behind the job description, understand what the interviewer will actually test
- **Round-specific strategy** — show execution in round one, industry depth in middle rounds, strategic thinking in the final round
- **Systematize your experience** — frameworks like the Three-Part Definition Method and STAR+Methodology turn what you've done into language that senior leaders trust
- **Objective post-interview review** — question-by-question breakdown of what you said vs. what the interviewer likely expected, grounded in the transcript, not your self-perception
- **Pattern recognition** — identify which question types keep tripping you up and what to do about it

## What You'll Get

- Before each interview, you know exactly what that round requires and what to hold back
- When asked abstract questions, you respond with a framework, a case, and a conclusion — not a rambling story
- After each interview, you have an objective postmortem, not a vague "I think it went okay"
- You stop failing the same type of question twice
- In executive-level conversations, you speak their language — structure, framework, methodology — not just "I did this and then I did that"

## How to Use

### Option 1: GitHub Link (Recommended)

Drop this URL to any Agent — it will auto-download and install:

```
https://github.com/xingxiaoyiyio/interview-prep-review
```

### Option 2: Manual Install

Place the folder into your Agent's skills directory:

```bash
# Claude Code
cp -r interview-prep-review ~/.claude/skills/

# Other agents — place in their corresponding skills folder
```

Once loaded, trigger by saying:
- **"Help me prepare for the final round at XX" / "Analyze this JD"** → Preparation mode
- **"Let's review this interview" / "I just finished an interview at XX"** → Review mode

### Option 3: With Other AI Assistants

Attach SKILL.md and relevant reference files to any AI assistant and ask it to follow the methodology. Not tied to any specific platform or tool.

## File Structure

```
interview-prep-review/
├── SKILL.md                    # Entry point: triggers + dual workflow
├── README.md                   # This file
└── references/
    ├── preparation-workflow.md  # Full preparation workflow + output templates
    ├── review-workflow.md       # Full review workflow + output templates
    ├── interview-rounds.md      # Round-specific strategy guide
    ├── question-frameworks.md   # Response frameworks for 6 question types
    └── rhythm-control.md        # Tone-setting, pace control, level-shifting
```

## Design Principles

- **No pre-baked personal cases** — all analysis is based on user input, no personal experience embedded
- **Question-by-question breakdown** — each question analyzed from four dimensions: your response → interviewer expectation → nature of the question → structured model answer
- **Objective analysis** — not swayed by the user's self-perception; based on interview records
- **Round-specific strategy** — different approaches for first, middle, and final rounds

## Use Cases

- Preparing for senior product manager / architect / solution lead interviews
- Need an objective, structured review right after an interview
- Want to demonstrate systematic thinking in executive-level interviews
- Repeatedly struggling with the same type of interview questions and need to identify patterns

## License

MIT
