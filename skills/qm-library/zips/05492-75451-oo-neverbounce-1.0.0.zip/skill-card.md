## Description: <br>
NeverBounce helps an agent verify single email addresses, manage bulk email verification jobs, and inspect account credit and job status through an OOMOL-connected NeverBounce account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill when they want an agent to run NeverBounce email verification workflows without calling the NeverBounce API directly. It supports single-email checks, bulk job creation and lifecycle actions, result retrieval, CSV downloads, and account credit review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires access to a connected NeverBounce account through OOMOL. <br>
Mitigation: Install and use it only when the agent is intended to operate that connected account, and keep OOMOL authentication and NeverBounce connection setup under user control. <br>
Risk: Bulk verification jobs may upload email lists and consume NeverBounce or OOMOL credits. <br>
Mitigation: Review bulk job payloads, source files, filters, and expected credit impact before running create, parse, start, or download actions. <br>
Risk: Create, parse, and start actions can change NeverBounce job state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before executing state-changing actions. <br>
Risk: The first-time setup path includes shell installer commands. <br>
Mitigation: Run installer commands only after confirming the OOMOL installer source is trusted in the target environment. <br>


## Reference(s): <br>
- [NeverBounce homepage](https://neverbounce.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-neverbounce) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, JSON, Files] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads; action results are returned as JSON, with CSV files for bulk result downloads.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed oo CLI, an authenticated OOMOL account, and a connected NeverBounce account.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
