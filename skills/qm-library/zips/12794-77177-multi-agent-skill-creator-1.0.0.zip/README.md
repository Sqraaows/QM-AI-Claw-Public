# Multi-Agent Skill Creator / 多Agent技能创造器

---

## English

### Overview

`multi-agent-skill-creator` is a skill for creating new Claude Code skills using multi-agent collaboration. It extends the standard skill creation framework by coordinating multiple specialized agents working in parallel:

- **Researcher Agent** — Analyzes requirements, explores existing patterns, researches best practices
- **Developer Agent** — Implements skill code, writes SKILL.md, creates supporting scripts
- **Tester Agent** — Validates functionality, designs test cases, runs evaluations
- **Reviewer Agent** — Assesses output quality, provides constructive feedback

### Why Multi-Agent?

Traditional skill creation relies on a single agent to handle all tasks. Multi-agent collaboration improves:

- **Quality** — Each agent specializes in its domain, producing better results
- **Speed** — Parallel execution reduces total time
- **Coverage** — Multiple perspectives catch edge cases single agents miss
- **Reliability** — Built-in validation reduces errors

### Usage

#### Basic Trigger
```
/multi-agent-skill-creator
```

#### Describe Your Intent
Simply describe what you want to create:
- "I want to create a skill that extracts data from PDFs"
- "Build a skill for generating Excel reports from database queries"
- "Create a skill to automate GitHub PR reviews"

#### Full Workflow
The skill guides you through:
1. **Intent Capture** — Understand the target skill's purpose and scope
2. **Research Phase** — Analyze similar skills, identify dependencies, check available MCPs
3. **Drafting** — Write initial SKILL.md with frontmatter and instructions
4. **Test Design** — Create realistic test prompts (3-5 cases)
5. **Evaluation** — Run with-skill vs without-skill benchmarks
6. **Review** — Present results for qualitative + quantitative assessment
7. **Iteration** — Improve based on feedback (repeat until satisfied)
8. **Optimization** — Fine-tune description for better triggering accuracy
9. **Packaging** — Deliver as installable .skill file

### Skill Anatomy

```
skill-name/
├── SKILL.md           # Required: name, description, instructions
├── agents/           # Optional: subagent instruction files
│   ├── analyzer.md
│   ├── comparator.md
│   └── grader.md
├── scripts/          # Optional: bundled executable code
│   ├── __init__.py
│   └── *.py
├── references/       # Optional: docs loaded as needed
│   └── schemas.md
├── assets/           # Optional: templates, icons, static files
└── eval-viewer/      # Optional: evaluation result viewer
```

#### SKILL.md Frontmatter (Required)
```yaml
---
name: skill-name
description: What this skill does AND when to trigger it. Be "pushy" — include specific contexts where it should activate.
---
```

#### SKILL.md Body
- Use imperative mood for instructions
- Keep under 500 lines; use references for detailed docs
- Include examples of input/output
- Define output formats clearly

### Test Case Design

Good test prompts are:
- **Realistic** — Like what actual users would type
- **Specific** — Include file paths, context, personal details
- **Substantive** — Complex enough that Claude benefits from the skill
- **Varied** — Mix of formal/casual, short/long, common/edge cases

```json
{
  "skill_name": "example-skill",
  "evals": [
    {
      "id": 1,
      "prompt": "my boss sent me Q4_sales_FINAL_v2.xlsx and wants profit margin % in column E",
      "expected_output": "Modified Excel with profit margin column",
      "files": ["~/Downloads/Q4_sales_FINAL_v2.xlsx"]
    }
  ]
}
```

### Evaluation Process

1. **Spawn Runs** — Launch with-skill and baseline (without-skill) agents in parallel
2. **Capture Timing** — Record tokens and duration for each run
3. **Grade Results** — Run assertion checks against outputs
4. **Aggregate Benchmark** — Generate comparison stats
5. **Present to User** — Launch eval-viewer for human review
6. **Read Feedback** — Iterate based on user comments

### Description Optimization

Trigger accuracy determines when Claude activates a skill. The optimization process:

1. **Generate Eval Queries** — 20 queries (8-10 should-trigger, 8-10 should-not-trigger)
2. **User Review** — Edit queries, confirm should_trigger flags
3. **Run Optimization Loop** — 5 iterations max, 60/40 train/test split
4. **Apply Result** — Update description with best performing version

### Installation

```bash
# Using npx skills
npx skills add https://github.com/muruai2021/multi-agent-skill-creator --skill multi-agent-skill-creator --global --yes

# Manual installation
# 1. Download or clone this repository
# 2. Place folder in ~/.claude/skills/multi-agent-skill-creator
```

### Scripts Reference

| Script | Purpose |
|--------|---------|
| `aggregate_benchmark.py` | Combine results into benchmark.json/md |
| `generate_report.py` | Create evaluation reports |
| `improve_description.py` | Optimize skill description |
| `package_skill.py` | Package as .skill file for distribution |
| `run_eval.py` | Run single evaluation query |
| `run_loop.py` | Full description optimization loop |

### Advanced Features

#### Blind Comparison
Compare two skill versions without knowing which is which. Independent agent judges quality.

#### Cowork Support
Works in Cowork environment with static HTML output (no browser required).

#### Claude.ai Compatible
Can be used on Claude.ai with adapted workflow (no subagents, sequential execution).

---

## 中文

### 概述

`multi-agent-skill-creator` 是一个使用多Agent协作方式创建新 Claude Code 技能的工具。它通过并行协调多个专业Agent来扩展标准技能创建框架：

- **研究员Agent** — 分析需求、研究现有模式、探索最佳实践
- **开发者Agent** — 实现技能代码、编写 SKILL.md、创建辅助脚本
- **测试员Agent** — 验证功能、设计测试用例、执行评估
- **评审员Agent** — 评估输出质量、提供建设性反馈

### 为什么使用多Agent？

传统技能创建依赖单一Agent处理所有任务。多Agent协作的优势：

- **质量** — 每个Agent专注领域，产出更优
- **速度** — 并行执行缩短总时间
- **覆盖** — 多视角发现单Agent遗漏的边界情况
- **可靠性** — 内置验证减少错误

### 使用方法

#### 基本触发
```
/multi-agent-skill-creator
```

#### 描述你的意图
直接描述你想要创建的内容：
- "我想创建一个从PDF提取数据的技能"
- "构建一个从数据库查询生成Excel报告的技能"
- "创建一个自动化GitHub PR评审的技能"

#### 完整工作流程
技能引导你完成：
1. **意图捕获** — 理解目标技能的目的和范围
2. **研究阶段** — 分析类似技能、识别依赖、检查可用MCP
3. **编写草稿** — 创建初始 SKILL.md（包含frontmatter和指令）
4. **测试设计** — 创建真实测试提示（3-5个案例）
5. **执行评估** — 运行使用技能 vs 不使用技能的基准对比
6. **结果审查** — 展示定性+定量评估结果
7. **迭代改进** — 根据反馈优化（重复直到满意）
8. **描述优化** — 微调描述以提高触发准确性
9. **打包交付** — 作为可安装的 .skill 文件交付

### 技能结构

```
skill-name/
├── SKILL.md           # 必需：name, description, instructions
├── agents/            # 可选：子Agent指令文件
│   ├── analyzer.md     # 分析器
│   ├── comparator.md   # 比较器
│   └── grader.md       # 评分器
├── scripts/          # 可选：打包的可执行代码
│   ├── __init__.py
│   └── *.py
├── references/       # 可选：按需加载的文档
│   └── schemas.md      # JSON结构定义
├── assets/           # 可选：模板、图标、静态文件
└── eval-viewer/      # 可选：评估结果查看器
```

#### SKILL.md Frontmatter（必需）
```yaml
---
name: skill-name
description: 这个技能做什么以及何时触发。要"主动"——包含具体应该激活的场景。
---
```

#### SKILL.md 主体
- 使用祈使句编写指令
- 保持在500行以内；详细文档使用references
- 包含输入/输出示例
- 清晰定义输出格式

### 测试用例设计

好的测试提示：
- **真实** — 像实际用户会输入的内容
- **具体** — 包含文件路径、上下文、个人信息
- **实质** — 足够复杂，让Claude从技能中受益
- **多样** — 正式/随意、简短/详细、常见/边界情况混合

```json
{
  "skill_name": "example-skill",
  "evals": [
    {
      "id": 1,
      "prompt": "老板给我发了Q4_sales_FINAL_v2.xlsx，要我在E列加毛利率百分比",
      "expected_output": "修改后的Excel，含毛利率列",
      "files": ["~/Downloads/Q4_sales_FINAL_v2.xlsx"]
    }
  ]
}
```

### 评估流程

1. **生成运行** — 并行启动使用技能和无技能（baseline）Agent
2. **捕获计时** — 记录每个运行的tokens和耗时
3. **评分结果** — 对输出运行断言检查
4. **聚合基准** — 生成对比统计数据
5. **展示给用户** — 启动eval-viewer供人工审查
6. **读取反馈** — 根据用户评论迭代改进

### 描述优化

触发准确性决定Claude何时激活技能。优化流程：

1. **生成评估查询** — 20个查询（8-10应该触发，8-10不应该触发）
2. **用户审查** — 编辑查询，确认should_trigger标志
3. **运行优化循环** — 最多5轮，60/40训练/测试拆分
4. **应用结果** — 用表现最好的描述更新

### 安装方法

```bash
# 使用 npx skills
npx skills add https://github.com/muruai2021/multi-agent-skill-creator --skill multi-agent-skill-creator --global --yes

# 手动安装
# 1. 下载或克隆此仓库
# 2. 将文件夹放置到 ~/.claude/skills/multi-agent-skill-creator
```

### 脚本参考

| 脚本 | 用途 |
|------|------|
| `aggregate_benchmark.py` | 将结果聚合成 benchmark.json/md |
| `generate_report.py` | 创建评估报告 |
| `improve_description.py` | 优化技能描述 |
| `package_skill.py` | 打包为 .skill 文件分发 |
| `run_eval.py` | 运行单个评估查询 |
| `run_loop.py` | 完整描述优化循环 |

### 高级功能

#### 盲测比较
在不知道哪个是哪个的情况下比较两个技能版本。由独立Agent评判质量。

#### Cowork支持
可在Cowork环境中使用，输出静态HTML（无需浏览器）。

#### Claude.ai兼容
可在Claude.ai上使用，适配工作流程（无子Agent，顺序执行）。

---

## License / 许可证

MIT License — See [LICENSE.txt](LICENSE.txt)

MIT许可证 — 详见 [LICENSE.txt](LICENSE.txt)