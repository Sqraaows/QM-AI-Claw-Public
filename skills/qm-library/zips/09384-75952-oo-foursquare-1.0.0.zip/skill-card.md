## Description: <br>
Foursquare (foursquare.com). Use this skill for Foursquare search and read-only place data requests through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to search Foursquare places, retrieve nearby places, and read place details, photos, and tips through OOMOL's connector workflow. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Foursquare account through OOMOL. <br>
Mitigation: Use it only when the user is comfortable authorizing Foursquare access through OOMOL; avoid handling raw API credentials directly. <br>
Risk: The setup instructions include shell installer snippets for the oo CLI. <br>
Mitigation: Verify the oo CLI installer source from OOMOL before running installation commands. <br>
Risk: Future connector actions could create, update, post, or delete data if the connector expands beyond the current read-only actions. <br>
Mitigation: Review the live connector schema and payload, then get explicit user confirmation before running any action that changes Foursquare state. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/oomol/oo-foursquare) <br>
- [Foursquare homepage](https://foursquare.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [Foursquare connection setup](https://console.oomol.com/app-connections?provider=foursquare) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Agent output may include Foursquare place data returned by the oo connector as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
