## Description: <br>
Connects an agent to urlscan.io through OOMOL's oo CLI to submit URLs for scanning, search existing scans, and retrieve completed scan results. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and security analysts use this skill to operate urlscan.io from an agent workflow for URL submission, scan search, and JSON result retrieval through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL account connected to urlscan.io and allows the agent to run oo connector commands. <br>
Mitigation: Install only when that account connection is intended, and review the requested connector action before execution. <br>
Risk: The optional pipe-to-shell CLI install command can execute remote installer code. <br>
Mitigation: Prefer an official installer path or review the install script before running the setup command. <br>
Risk: Submitting a URL sends data to urlscan.io and changes account or service state. <br>
Mitigation: Confirm the exact submit_scan payload and intended effect with the user before running write actions. <br>


## Reference(s): <br>
- [urlscan.io homepage](https://urlscan.io) <br>
- [ClawHub skill listing](https://clawhub.ai/oomol/oo-urlscan) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses include data and meta.executionId when actions run with --json.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
