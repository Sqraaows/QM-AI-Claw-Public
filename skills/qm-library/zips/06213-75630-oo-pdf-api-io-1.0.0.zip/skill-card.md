## Description: <br>
PDF-API.io (pdf-api.io). Use this skill for PDF-API.io requests that list templates, inspect templates, or render PDFs through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to work with PDF-API.io through an OOMOL-connected account: listing accessible templates, retrieving template details, and rendering a template with JSON data into a temporary hosted PDF URL. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: PDF rendering can generate hosted PDFs and may consume service credits. <br>
Mitigation: Review the template ID and JSON payload with the user before running render_pdf. <br>
Risk: The skill requires a connected PDF-API.io account and sensitive service credentials managed through OOMOL. <br>
Mitigation: Use the existing OOMOL connection, avoid handling raw tokens, and only initiate setup when an auth or connection error requires it. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-pdf-api-io) <br>
- [PDF-API.io homepage](https://pdf-api.io) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, API Calls, JSON, Guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before actions; render_pdf returns a temporary hosted PDF URL.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
