"""
TTS 语音合成模块
支持 Edge TTS (免费)、OpenAI TTS 和阿里云 TTS
"""
import asyncio
from pathlib import Path
from typing import Optional


async def _edge_tts_async(
    text: str,
    output_path: str,
    voice: str = "zh-CN-XiaoxiaoNeural",
    rate: str = "+10%",
    pitch: str = "+5Hz",
) -> str:
    """Edge TTS 异步实现"""
    import edge_tts

    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(output_path)
    return output_path


def generate_tts(
    text: str,
    output_path: str,
    engine: Optional[str] = None,
    voice: str = "zh-CN-XiaoxiaoNeural",
    rate: str = "+10%",
    pitch: str = "+5Hz",
    aliyun_voice: Optional[str] = None,
) -> str:
    """
    生成语音文件

    Args:
        text: 要朗读的文字
        output_path: 输出音频文件路径
        engine: "edge" / "openai" / "aliyun" / "placeholder"
        voice: Edge TTS 声音名称
        rate: Edge TTS 语速
        pitch: Edge TTS 音调
        aliyun_voice: 阿里云声音名称 (如果使用阿里云)

    Returns:
        音频文件路径
    """
    import yaml

    config_path = Path(__file__).parent.parent / "config.yaml"
    cfg = {}
    if config_path.exists():
        with open(config_path, "r") as f:
            cfg = yaml.safe_load(f) or {}

    tts_cfg = cfg.get("tts", {})
    engine = engine or tts_cfg.get("engine", "edge")

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    if engine == "edge":
        edge_cfg = tts_cfg.get("edge", {})
        voice = edge_cfg.get("voice", voice)
        rate = edge_cfg.get("rate", rate)
        pitch = edge_cfg.get("pitch", pitch)
        asyncio.run(_edge_tts_async(text, output_path, voice, rate, pitch))
        print(f"[tts] Edge TTS 已生成: {output_path}")

    elif engine == "aliyun":
        aliyun_cfg = tts_cfg.get("aliyun", {})
        access_key_id = aliyun_cfg.get("access_key_id")
        access_key_secret = aliyun_cfg.get("access_key_secret")
        appkey = aliyun_cfg.get("appkey", "default")
        
        if not access_key_id or not access_key_secret:
            print("[tts] ❌ 阿里云 TTS 需要配置 access_key_id 和 access_key_secret")
            return None
        
        from src.aliyun_tts import generate_aliyun_tts
        
        # 转换语速参数 (Edge TTS 格式 -> 阿里云格式)
        aliyun_voice = aliyun_voice or aliyun_cfg.get("voice", "xiaoyun")
        speech_rate = _convert_rate_to_aliyun(rate)
        pitch_rate = _convert_pitch_to_aliyun(pitch)
        
        result = generate_aliyun_tts(
            text=text,
            output_path=output_path,
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            appkey=appkey,
            voice=aliyun_voice,
            speech_rate=speech_rate,
            pitch_rate=pitch_rate,
        )
        if result:
            print(f"[tts] 阿里云 TTS 已生成: {output_path}")
        else:
            print("[tts] ❌ 阿里云 TTS 生成失败")
            return None

    elif engine == "openai":
        from openai import OpenAI
        openai_cfg = tts_cfg.get("openai", {})
        client = OpenAI(api_key=openai_cfg.get("api_key") or None)
        response = client.audio.speech.create(
            model=openai_cfg.get("model", "tts-1"),
            voice=openai_cfg.get("voice", "alloy"),
            input=text,
        )
        response.stream_to_file(output_path)
        print(f"[tts] OpenAI TTS 已生成: {output_path}")

    elif engine == "placeholder":
        _generate_placeholder_audio(text, output_path)

    else:
        raise ValueError(f"未知的 TTS 引擎: {engine}")

    return output_path


def _convert_rate_to_aliyun(rate: str) -> int:
    """将 Edge TTS 语速格式转换为阿里云格式"""
    # Edge TTS: "+10%", "-5%", "+0%"
    # 阿里云: -500~500
    try:
        if rate.endswith("%"):
            value = int(rate[:-1])
            # 映射: -100% -> -500, 0% -> 0, +100% -> +500
            return max(-500, min(500, value * 5))
    except:
        pass
    return 0


def _convert_pitch_to_aliyun(pitch: str) -> int:
    """将 Edge TTS 音调格式转换为阿里云格式"""
    # Edge TTS: "+10Hz", "-5Hz", "+0Hz"
    # 阿里云: -500~500
    try:
        if pitch.endswith("Hz"):
            value = int(pitch[:-2])
            # 映射: -100Hz -> -500, 0Hz -> 0, +100Hz -> +500
            return max(-500, min(500, value * 5))
    except:
        pass
    return 0


def _generate_placeholder_audio(text: str, output_path: str):
    """生成静音占位音频 (moviepy 2.x 兼容)"""
    import numpy as np
    import wave
    import struct

    duration = max(1.0, len(text) / 3.0)
    sample_rate = 44100
    num_samples = int(duration * sample_rate)

    # 生成静音 WAV 文件 (不依赖 moviepy)
    with wave.open(output_path, "w") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(b'\x00\x00' * num_samples)

    print(f"[tts] 占位音频已生成: {output_path} ({duration:.1f}s)")


def get_audio_duration(audio_path: str) -> float:
    """获取音频文件时长 (秒)"""
    from moviepy import AudioFileClip
    clip = AudioFileClip(audio_path)
    duration = clip.duration
    clip.close()
    return duration


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("用法: python tts_gen.py <文字> <输出路径> [引擎]")
        sys.exit(1)

    text = sys.argv[1]
    out = sys.argv[2]
    engine = sys.argv[3] if len(sys.argv) > 3 else None

    generate_tts(text, out, engine=engine)
