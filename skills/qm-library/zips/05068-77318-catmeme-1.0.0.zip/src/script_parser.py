"""
新剧本格式解析器
支持分层描述: 背景/角色/文字/特效/音频
"""
import yaml
from pathlib import Path
from typing import Optional, List
from src.compositor import (
    SceneSpec, LayerConfig, TextConfig, Animation, Timeline
)
from src.asset_manager import search_assets, get_asset_path, ASSETS_DIR


def parse_animation(raw: Optional[dict | str]) -> Optional[Animation]:
    """解析动画配置"""
    if raw is None:
        return None
    if isinstance(raw, str):
        return Animation(type=raw, duration=0.5)
    return Animation(
        type=raw.get("type", "cut"),
        duration=float(raw.get("duration", 0.5)),
        easing=raw.get("easing", "ease_out"),
    )


def resolve_asset_source(raw: dict) -> str:
    """
    解析素材来源

    支持:
      source: "characters/cat/emotions/cat_crying_green.mp4"  (相对路径)
      source: "green_screen/cat/emotions/xxx.mp4"            (templates 目录)
      source: "/absolute/path/to/file.mp4"                    (绝对路径)
    """
    source = raw.get("source", "")
    if not source:
        return ""

    path = Path(source)
    if path.is_absolute():
        return str(path)

    # 相对于 assets 目录
    full_path = ASSETS_DIR / source
    if full_path.exists():
        return str(full_path)

    # 相对于 templates 目录
    templates_dir = Path(__file__).parent.parent / "templates"
    templates_path = templates_dir / source
    if templates_path.exists():
        return str(templates_path)

    # 尝试搜索
    results = search_assets(query=Path(source).stem)
    if results:
        return str(get_asset_path(results[0]))

    return str(full_path)


def parse_layer(raw: dict, default_size: float = 0.5) -> LayerConfig:
    """解析一个层的配置"""
    # 检查是否使用 AI 生成
    ai_generate = raw.get("ai_generate")
    if ai_generate:
        # 存储 AI 生成配置，实际生成在渲染时进行
        source = "__ai_generate__"
        ai_config = ai_generate
    else:
        source = resolve_asset_source(raw)
        ai_config = None

    chroma_key = raw.get("chroma_key")
    if chroma_key is None and source and "green" in source.lower():
        chroma_key = "green"
    elif chroma_key is None and source and "blue" in source.lower():
        chroma_key = "blue"

    return LayerConfig(
        source=source,
        start_time=float(raw.get("start", 0.0)),
        duration=float(raw["duration"]) if "duration" in raw else None,
        position=raw.get("position", "center"),
        size=float(raw.get("size", default_size)),
        speak_scale=float(raw.get("speak_scale", 1.0)),
        opacity=float(raw.get("opacity", 1.0)),
        chroma_key=chroma_key,
        loop=raw.get("loop", False),
        z_order=int(raw.get("z_order", 0)),
        enter=parse_animation(raw.get("enter")),
        exit=parse_animation(raw.get("exit")),
        ai_config=ai_config,
        character_id=raw.get("character_id"),
    )


def _generate_ai_asset(config: dict) -> str:
    """已废弃 - AI 素材生成现在在 compositor.py 的 create_layer 中进行"""
    raise NotImplementedError("AI 素材生成已移至 compositor.py")


def parse_text(raw: dict) -> TextConfig:
    """解析文字配置"""
    return TextConfig(
        content=raw.get("content", ""),
        position=raw.get("position", "top"),
        style=raw.get("style", "meme"),
        font_size=int(raw.get("font_size", 48)),
        appear=float(raw.get("appear", 0.0)),
        disappear=float(raw["disappear"]) if "disappear" in raw else None,
        animation=raw.get("animation", "pop_in"),
    )


def parse_scene(raw: dict, index: int) -> SceneSpec:
    """解析一个场景"""
    name = raw.get("name", f"场景 {index+1}")
    duration = float(raw.get("duration", 5.0))

    # 背景
    bg_raw = raw.get("background")
    background = None
    if bg_raw:
        background = parse_layer(bg_raw, default_size=1.0)
        background.loop = True  # 背景默认循环

    # 角色
    characters = []
    for char_raw in raw.get("characters", []):
        char = parse_layer(char_raw, default_size=0.5)
        characters.append(char)

    # 文字
    text = []
    for txt_raw in raw.get("text", []):
        text.append(parse_text(txt_raw))

    # 特效
    effects = []
    for fx_raw in raw.get("effects", []):
        effects.append(parse_layer(fx_raw, default_size=0.15))

    # 对话
    dialogues = []
    from src.compositor import DialogueConfig
    for dlg_raw in raw.get("dialogues", []):
        dialogues.append(DialogueConfig(
            character_id=dlg_raw.get("character_id", ""),
            text=dlg_raw.get("text", ""),
            appear=float(dlg_raw.get("appear", 0.0)),
            disappear=float(dlg_raw["disappear"]) if "disappear" in dlg_raw else None,
            volume=float(dlg_raw.get("volume", 1.0)),
        ))

    return SceneSpec(
        name=name,
        duration=duration,
        background=background,
        characters=characters,
        text=text,
        effects=effects,
        dialogues=dialogues,
    )


def parse_script_v2(file_path: str) -> tuple:
    """
    解析新格式剧本

    Returns:
        (Timeline, dict_metadata)
    """
    path = Path(file_path)
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    title = data.get("title", "未命名")
    resolution = tuple(data.get("resolution", [1080, 1920]))
    fps = int(data.get("fps", 24))

    timeline = Timeline(resolution=resolution, fps=fps)

    # 解析全局角色定义
    from src.compositor import CharacterDef
    for char_raw in data.get("characters", []):
        char_def = CharacterDef(
            id=char_raw.get("id", ""),
            name=char_raw.get("name", ""),
            voice=char_raw.get("voice", "zh-CN-XiaoxiaoNeural"),
            rate=char_raw.get("rate", "+0%"),
            pitch=char_raw.get("pitch", "+0Hz"),
        )
        timeline.add_character(char_def)

    # 解析旁白
    voiceover_raw = data.get("voiceover")
    if voiceover_raw:
        from src.compositor import VoiceoverConfig
        timeline.voiceover = VoiceoverConfig(
            text=voiceover_raw.get("text", ""),
            voice=voiceover_raw.get("voice", "zh-CN-XiaoxiaoNeural"),
            rate=voiceover_raw.get("rate", "+10%"),
            pitch=voiceover_raw.get("pitch", "+5Hz"),
            volume=float(voiceover_raw.get("volume", 1.0)),
        )

    # 解析 BGM（支持单条或多条）
    from src.compositor import BGMConfig
    bgm_raw = data.get("bgm")
    if bgm_raw:
        if isinstance(bgm_raw, dict):
            bgm_raw = [bgm_raw]
        for bgm_item in bgm_raw:
            source = bgm_item.get("source", "")
            if source:
                bgm_path = Path(source)
                if not bgm_path.is_absolute():
                    templates_dir = Path(__file__).parent.parent / "templates"
                    bgm_path = templates_dir / "bgm" / source
                timeline.bgm.append(BGMConfig(
                    source=str(bgm_path),
                    start=float(bgm_item.get("start", 0.0)),
                    end=float(bgm_item["end"]) if "end" in bgm_item else None,
                    volume=float(bgm_item.get("volume", 0.3)),
                    fade_in=float(bgm_item.get("fade_in", 1.0)),
                    fade_out=float(bgm_item.get("fade_out", 1.0)),
                ))

    for i, scene_raw in enumerate(data.get("scenes", [])):
        scene = parse_scene(scene_raw, i)
        timeline.add_scene(scene)

    # 统计对话数
    dialogue_count = sum(len(s.dialogues) for s in timeline.scenes)

    meta = {
        "title": title,
        "scene_count": len(timeline.scenes),
        "total_duration": sum(s.duration for s in timeline.scenes),
        "has_voiceover": timeline.voiceover is not None,
        "character_count": len(timeline.characters),
        "dialogue_count": dialogue_count,
    }

    print(f"[parser] {meta['title']} ({meta['scene_count']} 场景, ~{meta['total_duration']:.0f}秒)")
    print(f"[parser] 角色: {meta['character_count']} 个, 对话: {meta['dialogue_count']} 条")
    if meta["has_voiceover"]:
        print(f"[parser] 旁白: {timeline.voiceover.text[:30]}...")
    return timeline, meta


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("用法: python script_parser.py <剧本.yaml>")
        sys.exit(1)

    timeline, meta = parse_script_v2(sys.argv[1])
    print(f"\n解析完成:")
    print(f"  标题: {meta['title']}")
    print(f"  场景: {meta['scene_count']}")
    print(f"  时长: {meta['total_duration']:.1f}s")
    for i, scene in enumerate(timeline.scenes):
        print(f"\n  [{i+1}] {scene.name} ({scene.duration}s)")
        if scene.background:
            print(f"      背景: {Path(scene.background.source).name}")
        for j, char in enumerate(scene.characters):
            print(f"      角色{j+1}: {Path(char.source).name} @ {char.position}")
        for j, txt in enumerate(scene.text):
            print(f"      文字{j+1}: \"{txt.content}\" ({txt.animation})")
