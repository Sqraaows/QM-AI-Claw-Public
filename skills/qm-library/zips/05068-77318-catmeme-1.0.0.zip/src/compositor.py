"""
合成引擎 v2
分层合成 + 动画系统 + 时间轴调度
修复: 单个连续 clip 渲染，避免场景拼接黑帧
"""
import numpy as np
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, Tuple, List, Callable, Dict
from enum import Enum

from moviepy import (
    VideoClip, ImageClip, VideoFileClip, AudioFileClip,
    CompositeVideoClip, CompositeAudioClip, concatenate_videoclips,
)
from PIL import Image, ImageDraw, ImageFont


# ============================================================
# 动画系统
# ============================================================

class Easing(Enum):
    LINEAR = "linear"
    EASE_IN = "ease_in"
    EASE_OUT = "ease_out"
    EASE_IN_OUT = "ease_in_out"
    BOUNCE = "bounce"


def ease_value(t: float, duration: float, easing: Easing = Easing.EASE_OUT) -> float:
    if duration <= 0:
        return 1.0
    p = min(t / duration, 1.0)
    if easing == Easing.LINEAR:
        return p
    elif easing == Easing.EASE_IN:
        return p * p
    elif easing == Easing.EASE_OUT:
        return 1 - (1 - p) * (1 - p)
    elif easing == Easing.EASE_IN_OUT:
        if p < 0.5:
            return 2 * p * p
        else:
            return 1 - (-2 * p + 2) ** 2 / 2
    elif easing == Easing.BOUNCE:
        if p < 0.5:
            return 4 * p * p * p
        else:
            return 1 - (-2 * p + 2) ** 3 / 2
    return p


@dataclass
class Animation:
    type: str
    duration: float = 0.5
    easing: str = "ease_out"

    def get_easing(self) -> Easing:
        return Easing(self.easing)


def compute_enter_transform(anim, t, screen_size, element_size, target_pos):
    if t >= anim.duration:
        return target_pos[0], target_pos[1], 1.0
    p = ease_value(t, anim.duration, anim.get_easing())
    sw, sh = screen_size
    ew, eh = element_size
    tx, ty = target_pos

    if anim.type == "slide_left":
        return int(-ew + (tx + ew) * p), ty, 1.0
    elif anim.type == "slide_right":
        return int(sw - (sw - tx) * (1 - p)), ty, 1.0
    elif anim.type == "slide_top":
        return tx, int(-eh + (ty + eh) * p), 1.0
    elif anim.type == "slide_bottom":
        return tx, int(sh - (sh - ty) * (1 - p)), 1.0
    elif anim.type in ("fade_in", "pop_in", "bounce"):
        return tx, ty, p
    elif anim.type == "cut":
        return tx, ty, 1.0
    return tx, ty, 1.0


def compute_exit_transform(anim, t, screen_size, element_size, current_pos):
    if t >= anim.duration:
        return current_pos[0], current_pos[1], 0.0
    p = ease_value(t, anim.duration, anim.get_easing())
    sw, sh = screen_size
    ew, eh = element_size
    cx, cy = current_pos

    if anim.type == "slide_left":
        return int(cx - (cx + ew) * p), cy, 1.0
    elif anim.type == "slide_right":
        return int(cx + (sw - cx) * p), cy, 1.0
    elif anim.type == "fade_out":
        return cx, cy, 1.0 - p
    elif anim.type == "cut":
        return cx, cy, 0.0
    return cx, cy, 1.0 - p


# ============================================================
# 绿幕抠图
# ============================================================

def chroma_key_frame(
    frame: np.ndarray,
    color: str = "green",
    threshold: float = 0.25,
    softness: float = 0.08,
) -> Tuple[np.ndarray, np.ndarray]:
    """绿幕抠图，返回 (rgb_frame, alpha_mask)"""
    h, w = frame.shape[:2]
    c = frame.shape[2] if len(frame.shape) > 2 else 1

    if c >= 3:
        rgb = frame[:, :, :3].astype(np.float32) / 255.0
    else:
        rgb = np.stack([frame[:, :, 0]] * 3, axis=-1).astype(np.float32) / 255.0

    r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]

    if color == "green":
        diff = g - np.maximum(r, b)
    elif color == "blue":
        diff = b - np.maximum(r, g)
    else:
        diff = g - np.maximum(r, b)

    alpha = np.clip((diff - threshold) / softness, 0, 1)
    alpha = 1.0 - alpha  # 反转: 绿色区域=透明, 非绿色=可见

    # 绿色溢出消除
    rgb_out = frame[:, :, :3].astype(np.float32)
    if c >= 3:
        edge_mask = (alpha > 0.1) & (alpha < 0.9)
        if np.any(edge_mask):
            green_spill = np.clip(rgb_out[:, :, 1] - np.maximum(rgb_out[:, :, 0], rgb_out[:, :, 2]) * 0.8, 0, 1)
            spill_factor = green_spill * edge_mask * 0.5
            rgb_out[:, :, 1] = rgb_out[:, :, 1] - spill_factor * 255
            rgb_out = np.clip(rgb_out, 0, 255)
    else:
        rgb_out = np.stack([frame[:, :, 0]] * 3, axis=-1).astype(np.float32)

    return rgb_out.astype(np.uint8), alpha.astype(np.float32)


# ============================================================
# Layer 层系统
# ============================================================

@dataclass
class LayerConfig:
    source: str
    start_time: float = 0.0
    duration: Optional[float] = None
    position: str = "center"
    size: float = 1.0
    speak_scale: float = 1.0  # 说话时放大比例 (1.0 = 不放大)
    opacity: float = 1.0
    chroma_key: Optional[str] = None
    loop: bool = False
    z_order: int = 0
    enter: Optional[Animation] = None
    exit: Optional[Animation] = None
    ai_config: Optional[Dict] = None  # AI 生成配置
    character_id: Optional[str] = None  # 角色ID，用于关联对话
    speak_periods: Optional[List[Tuple[float, float]]] = None  # 说话时间段列表 [(start, end), ...]


def resolve_position(position, screen_size, element_size, margin=30):
    sw, sh = screen_size
    ew, eh = element_size
    positions = {
        "center":       ((sw - ew) // 2, (sh - eh) // 2),
        "top":          ((sw - ew) // 2, margin),
        "bottom":       ((sw - ew) // 2, sh - eh - margin),
        "left":         (margin, (sh - eh) // 2),
        "right":        (sw - ew - margin, (sh - eh) // 2),
        "top-left":     (margin, margin),
        "top-right":    (sw - ew - margin, margin),
        "bottom-left":  (margin, sh - eh - margin),
        "bottom-right": (sw - ew - margin, sh - eh - margin),
    }
    return positions.get(position, positions["center"])


def load_video_frames(source: str, chroma_key: Optional[str] = None):
    """加载视频/图片，返回帧列表和 fps"""
    path = Path(source)
    suffix = path.suffix.lower()

    if suffix in (".png", ".jpg", ".jpeg", ".webp"):
        img = Image.open(path).convert("RGB")
        frame = np.array(img)
        alpha = None
        if chroma_key:
            frame, alpha = chroma_key_frame(frame, chroma_key)
        return [frame], [alpha] if alpha is not None else None, 1

    elif suffix == ".gif":
        gif = Image.open(path)
        frames, alphas = [], []
        try:
            while True:
                f = gif.copy().convert("RGB")
                frame = np.array(f)
                alpha = None
                if chroma_key:
                    frame, alpha = chroma_key_frame(frame, chroma_key)
                frames.append(frame)
                alphas.append(alpha)
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass
        fps = 1000 // gif.info.get("duration", 100)
        has_alpha = any(a is not None for a in alphas)
        return frames, alphas if has_alpha else None, fps

    elif suffix in (".mp4", ".mov", ".avi", ".webm"):
        from moviepy import VideoFileClip
        clip = VideoFileClip(str(path))
        frames, alphas = [], []
        for t in np.arange(0, clip.duration, 1.0 / clip.fps):
            frame = clip.get_frame(t)
            alpha = None
            if chroma_key:
                frame, alpha = chroma_key_frame(frame, chroma_key)
            frames.append(frame)
            alphas.append(alpha)
        fps = int(clip.fps)
        clip.close()
        has_alpha = any(a is not None for a in alphas)
        return frames, alphas if has_alpha else None, fps

    else:
        raise ValueError(f"不支持的素材格式: {suffix}")


def create_layer(
    config: LayerConfig,
    scene_duration: float,
    screen_size: Tuple[int, int],
    scene_start: float = 0.0,
) -> Optional[VideoClip]:
    """创建一个层的视频片段"""
    # 检查是否需要 AI 生成
    source = config.source
    if source == "__ai_generate__":
        ai_config = config.ai_config or {}
        asset_type = ai_config.get("type", "character")

        if asset_type == "background":
            from src.animatediff_gen import generate_background_image
            print(f"  [layer] 🤖 生成 AI 背景...")
            source = generate_background_image(
                prompt=ai_config.get("prompt", "anime style background"),
                width=ai_config.get("width", 1080),
                height=ai_config.get("height", 1920),
            )
        else:
            from src.animatediff_gen import generate_cat_animation
            print(f"  [layer] 🤖 生成 AI 角色动画...")
            source = generate_cat_animation(
                emotion=ai_config.get("emotion", "happy"),
                style=ai_config.get("style", "anime"),
                background=ai_config.get("background", "office"),
            )

        if not source:
            print(f"  [layer] ⚠️ AI 生成失败，跳过此层")
            return None
        config.source = source  # 更新 config 以便后续使用

    layer_duration = config.duration or (scene_duration - config.start_time)
    if layer_duration <= 0:
        return None

    # 加载素材帧
    try:
        frames, alphas, src_fps = load_video_frames(source, config.chroma_key)
    except Exception as e:
        print(f"  [layer] ⚠️ 加载失败: {source} - {e}")
        return None

    if not frames:
        return None

    # 缩放帧
    src_h, src_w = frames[0].shape[:2]
    target_w = int(screen_size[0] * config.size)
    ratio = target_w / src_w if src_w > 0 else 1
    target_h = int(src_h * ratio)

    # 预缩放所有帧
    from PIL import Image as PILImage
    scaled_frames = []
    scaled_alphas = []
    for i, frame in enumerate(frames):
        pil = PILImage.fromarray(frame)
        pil = pil.resize((target_w, target_h), PILImage.LANCZOS)
        scaled_frames.append(np.array(pil))
        if alphas and alphas[i] is not None:
            a_pil = PILImage.fromarray((alphas[i] * 255).astype(np.uint8), mode='L')
            a_pil = a_pil.resize((target_w, target_h), PILImage.LANCZOS)
            scaled_alphas.append(np.array(a_pil).astype(np.float32) / 255.0)
        else:
            scaled_alphas.append(None)

    has_alpha = any(a is not None for a in scaled_alphas)

    # 计算目标位置
    target_pos = resolve_position(config.position, screen_size, (target_w, target_h))

    # 构建帧函数
    enter_anim = config.enter or Animation(type="cut", duration=0)
    exit_anim = config.exit or Animation(type="cut", duration=0)
    num_frames = len(scaled_frames)
    speak_periods = config.speak_periods or []
    speak_scale = config.speak_scale

    def is_speaking(t):
        """检查时间 t 是否在说话时间段内"""
        for start, end in speak_periods:
            if start <= t <= end:
                return True
        return False

    def get_speak_transform(t, x, y, w, h):
        """获取说话时的放大变换"""
        if speak_scale <= 1.0 or not speak_periods:
            return x, y, w, h
        
        if is_speaking(t):
            # 放大角色
            new_w = int(w * speak_scale)
            new_h = int(h * speak_scale)
            # 保持中心位置不变
            dx = (new_w - w) // 2
            dy = (new_h - h) // 2
            return x - dx, y - dy, new_w, new_h
        
        return x, y, w, h

    def get_scaled_frame(frame_idx, w, h):
        """获取指定尺寸的帧"""
        frame = scaled_frames[frame_idx]
        if w == target_w and h == target_h:
            return frame
        # 需要重新缩放
        pil = PILImage.fromarray(frame)
        pil = pil.resize((w, h), PILImage.LANCZOS)
        return np.array(pil)

    def get_scaled_alpha(frame_idx, w, h):
        """获取指定尺寸的 alpha"""
        if not has_alpha or scaled_alphas[frame_idx] is None:
            return np.ones((h, w), dtype=np.float32)
        alpha = scaled_alphas[frame_idx]
        if w == target_w and h == target_h:
            return alpha
        # 需要重新缩放
        a_pil = PILImage.fromarray((alpha * 255).astype(np.uint8), mode='L')
        a_pil = a_pil.resize((w, h), PILImage.LANCZOS)
        return np.array(a_pil).astype(np.float32) / 255.0

    def make_rgb_frame(t):
        frame_idx = int(t * src_fps) % num_frames

        if t < enter_anim.duration:
            x, y, opacity = compute_enter_transform(
                enter_anim, t, screen_size, (target_w, target_h), target_pos
            )
            w, h = target_w, target_h
        elif t > layer_duration - exit_anim.duration:
            exit_t = t - (layer_duration - exit_anim.duration)
            x, y, opacity = compute_exit_transform(
                exit_anim, exit_t, screen_size, (target_w, target_h), target_pos
            )
            w, h = target_w, target_h
        else:
            x, y = target_pos
            opacity = config.opacity
            w, h = target_w, target_h

        # 应用说话时放大
        x, y, w, h = get_speak_transform(t, x, y, w, h)

        frame = get_scaled_frame(frame_idx, w, h)
        full_frame = np.zeros((screen_size[1], screen_size[0], 3), dtype=np.uint8)

        src_x1 = max(0, -x)
        src_y1 = max(0, -y)
        dst_x1 = max(0, x)
        dst_y1 = max(0, y)
        copy_w = min(w - src_x1, screen_size[0] - dst_x1)
        copy_h = min(h - src_y1, screen_size[1] - dst_y1)

        if copy_w > 0 and copy_h > 0:
            src_region = frame[src_y1:src_y1+copy_h, src_x1:src_x1+copy_w]
            full_frame[dst_y1:dst_y1+copy_h, dst_x1:dst_x1+copy_w] = src_region

        return full_frame

    def make_mask_frame(t):
        frame_idx = int(t * src_fps) % num_frames

        if t < enter_anim.duration:
            x, y, opacity = compute_enter_transform(
                enter_anim, t, screen_size, (target_w, target_h), target_pos
            )
            w, h = target_w, target_h
        elif t > layer_duration - exit_anim.duration:
            exit_t = t - (layer_duration - exit_anim.duration)
            x, y, opacity = compute_exit_transform(
                exit_anim, exit_t, screen_size, (target_w, target_h), target_pos
            )
            w, h = target_w, target_h
        else:
            x, y = target_pos
            opacity = config.opacity
            w, h = target_w, target_h

        # 应用说话时放大
        x, y, w, h = get_speak_transform(t, x, y, w, h)

        full_mask = np.zeros((screen_size[1], screen_size[0]), dtype=np.float64)

        alpha = get_scaled_alpha(frame_idx, w, h) * opacity

        src_x1 = max(0, -x)
        src_y1 = max(0, -y)
        dst_x1 = max(0, x)
        dst_y1 = max(0, y)
        copy_w = min(w - src_x1, screen_size[0] - dst_x1)
        copy_h = min(h - src_y1, screen_size[1] - dst_y1)

        if copy_w > 0 and copy_h > 0:
            src_region = alpha[src_y1:src_y1+copy_h, src_x1:src_x1+copy_w]
            full_mask[dst_y1:dst_y1+copy_h, dst_x1:dst_x1+copy_w] = src_region

        return full_mask

    rgb_clip = VideoClip(make_rgb_frame, duration=layer_duration)
    rgb_clip = rgb_clip.with_fps(24)

    mask_clip = VideoClip(make_mask_frame, duration=layer_duration, is_mask=True)
    mask_clip = mask_clip.with_fps(24)

    rgb_clip = rgb_clip.with_mask(mask_clip)
    rgb_clip = rgb_clip.with_start(config.start_time + scene_start)

    return rgb_clip


# ============================================================
# 文字层
# ============================================================

@dataclass
class TextConfig:
    content: str
    position: str = "top"
    style: str = "meme"
    font_size: int = 48
    appear: float = 0.0
    disappear: Optional[float] = None
    animation: str = "pop_in"
    color: str = "white"
    stroke_color: str = "black"
    stroke_width: int = 3


def create_text_layer(config, scene_duration, screen_size, scene_start=0.0):
    sw, sh = screen_size
    font_path = "/System/Library/Fonts/PingFang.ttc"

    try:
        font = ImageFont.truetype(font_path, config.font_size)
    except:
        font = ImageFont.load_default()

    text_duration = (config.disappear or scene_duration) - config.appear
    if text_duration <= 0:
        return None

    anim_type = config.animation

    def make_frame(t):
        img = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        if anim_type == "pop_in":
            progress = min(t / 0.3, 1.0)
            current_size = int(config.font_size * (0.5 + 0.5 * progress))
            if current_size < 10:
                return np.array(img)
            try:
                cur_font = ImageFont.truetype(font_path, current_size)
            except:
                cur_font = font
            opacity = int(255 * progress)

        elif anim_type == "typewriter":
            chars_to_show = int(len(config.content) * min(t / (text_duration * 0.5), 1.0))
            text = config.content[:chars_to_show]
            cur_font = font
            opacity = 255

        elif anim_type == "shake":
            import math
            shake_x = int(3 * math.sin(t * 20)) if t < 0.5 else 0
            shake_y = int(2 * math.cos(t * 15)) if t < 0.5 else 0
            cur_font = font
            opacity = 255

        elif anim_type == "fade_in":
            progress = min(t / 0.5, 1.0)
            cur_font = font
            opacity = int(255 * progress)

        else:
            cur_font = font
            opacity = 255

        draw_text = config.content if anim_type != "typewriter" else text
        if not draw_text:
            return np.array(img)

        bbox = draw.textbbox((0, 0), draw_text, font=cur_font)
        tw = bbox[2] - bbox[0]
        th = bbox[3] - bbox[1]
        cx = (sw - tw) // 2
        if config.position == "top":
            cy = 40
        elif config.position == "bottom":
            cy = sh - th - 40
        else:
            cy = (sh - th) // 2

        if anim_type == "shake":
            cx += shake_x
            cy += shake_y

        stroke_w = config.stroke_width
        for dx in range(-stroke_w, stroke_w + 1):
            for dy in range(-stroke_w, stroke_w + 1):
                if dx == 0 and dy == 0:
                    continue
                draw.text((cx + dx, cy + dy), draw_text, fill=(0, 0, 0, opacity), font=cur_font)
        draw.text((cx, cy), draw_text, fill=(255, 255, 255, opacity), font=cur_font)

        return np.array(img)

    rgba_clip = VideoClip(make_frame, duration=text_duration)
    rgba_clip = rgba_clip.with_fps(24)

    def make_rgb(t):
        frame = rgba_clip.get_frame(t)
        return frame[:, :, :3]

    def make_mask(t):
        frame = rgba_clip.get_frame(t)
        return frame[:, :, 3].astype(np.float64) / 255.0

    rgb_clip = VideoClip(make_rgb, duration=text_duration)
    rgb_clip = rgb_clip.with_fps(24)

    mask_clip = VideoClip(make_mask, duration=text_duration, is_mask=True)
    mask_clip = mask_clip.with_fps(24)

    rgb_clip = rgb_clip.with_mask(mask_clip)
    rgb_clip = rgb_clip.with_start(config.appear + scene_start)

    return rgb_clip


# ============================================================
# 时间轴调度器 (单个连续 clip 方案)
# ============================================================

@dataclass
class DialogueConfig:
    character_id: str
    text: str
    appear: float = 0.0
    disappear: Optional[float] = None
    volume: float = 1.0


@dataclass
class CharacterDef:
    id: str
    name: str
    voice: str = "zh-CN-XiaoxiaoNeural"
    rate: str = "+0%"      # 语速调整
    pitch: str = "+0Hz"    # 音调调整


@dataclass
class SceneSpec:
    name: str
    duration: float
    background: Optional[LayerConfig] = None
    characters: List[LayerConfig] = field(default_factory=list)
    text: List[TextConfig] = field(default_factory=list)
    effects: List[LayerConfig] = field(default_factory=list)
    dialogues: List[DialogueConfig] = field(default_factory=list)


@dataclass
class VoiceoverConfig:
    text: str
    voice: str = "zh-CN-XiaoxiaoNeural"
    rate: str = "+10%"
    pitch: str = "+5Hz"
    volume: float = 1.0


@dataclass
class BGMConfig:
    source: str           # BGM 文件路径
    start: float = 0.0    # 开始时间
    end: Optional[float] = None  # 结束时间（None=到视频结尾）
    volume: float = 0.3   # 音量 (0-1)
    fade_in: float = 1.0  # 淡入时间
    fade_out: float = 1.0 # 淡出时间


class Timeline:
    def __init__(self, resolution=(1080, 1920), fps=24):
        self.resolution = resolution
        self.fps = fps
        self.scenes: List[SceneSpec] = []
        self.voiceover: Optional[VoiceoverConfig] = None
        self.characters: Dict[str, CharacterDef] = {}  # id -> CharacterDef
        self.bgm: List[BGMConfig] = []  # BGM 列表（支持多段）

    def add_character(self, char_def: CharacterDef):
        self.characters[char_def.id] = char_def

    def add_scene(self, scene: SceneSpec):
        self.scenes.append(scene)

    @property
    def total_duration(self) -> float:
        return sum(s.duration for s in self.scenes)

    def render(self, output_path: str, voiceover_audio: Optional[str] = None, dialogue_audios: Optional[List[dict]] = None) -> str:
        """
        渲染整个时间轴为一个连续视频

        核心思路: 把所有场景的层收集起来，用 CompositeVideoClip
        一次性合成，避免 concatenate_videoclips 的黑帧问题

        Args:
            output_path: 输出视频路径
            voiceover_audio: 旁白音频文件路径 (可选)
            dialogue_audios: 对话音频列表 (可选)
        """
        total_dur = self.total_duration
        print(f"  总时长: {total_dur:.1f}s, 分辨率: {self.resolution}")

        # 收集所有层
        all_layers = []
        current_time = 0.0

        for i, scene in enumerate(self.scenes):
            print(f"  处理场景 {i+1}/{len(self.scenes)}: {scene.name} ({scene.duration}s @ {current_time:.1f}s)")

            # 背景层
            if scene.background:
                bg_clip = create_layer(scene.background, scene.duration, self.resolution, current_time)
                if bg_clip:
                    all_layers.append(bg_clip)

            # 角色层 - 设置说话时间段
            for char_cfg in scene.characters:
                # 根据 character_id 查找该角色的对话时间段
                if char_cfg.character_id and char_cfg.speak_scale > 1.0:
                    speak_periods = []
                    for dlg in scene.dialogues:
                        if dlg.character_id == char_cfg.character_id:
                            speak_periods.append((dlg.appear, dlg.disappear or scene.duration))
                    char_cfg.speak_periods = speak_periods
                
                char_clip = create_layer(char_cfg, scene.duration, self.resolution, current_time)
                if char_clip:
                    all_layers.append(char_clip)

            # 特效层
            for fx_cfg in scene.effects:
                fx_clip = create_layer(fx_cfg, scene.duration, self.resolution, current_time)
                if fx_clip:
                    all_layers.append(fx_clip)

            # 文字层
            for txt_cfg in scene.text:
                txt_clip = create_text_layer(txt_cfg, scene.duration, self.resolution, current_time)
                if txt_clip:
                    all_layers.append(txt_clip)

            current_time += scene.duration

        if not all_layers:
            raise ValueError("没有可渲染的层")

        # 合成所有层
        print(f"  合成 {len(all_layers)} 个层...")
        final = CompositeVideoClip(all_layers, size=self.resolution)

        # 添加旁白音频
        if voiceover_audio:
            print(f"  添加旁白音频: {voiceover_audio}")
            from moviepy import AudioFileClip
            audio_clip = AudioFileClip(voiceover_audio)
            # 如果音频比视频长，截断；如果短，保持原样
            if audio_clip.duration > total_dur:
                audio_clip = audio_clip.subclipped(0, total_dur)
            final = final.with_audio(audio_clip)

        # 添加对话音频
        if dialogue_audios:
            print(f"  添加 {len(dialogue_audios)} 条对话音频...")
            from moviepy import AudioFileClip
            audio_clips = []
            for dlg in dialogue_audios:
                try:
                    audio_clip = AudioFileClip(dlg["path"])
                    audio_clip = audio_clip.with_start(dlg["start"])
                    audio_clips.append(audio_clip)
                except Exception as e:
                    print(f"  ⚠️ 对话音频加载失败: {dlg['text'][:20]}... - {e}")

            if audio_clips:
                from moviepy import CompositeAudioClip
                dialogue_composite = CompositeAudioClip(audio_clips)
                # 如果已有旁白，混合；否则直接使用
                if final.audio:
                    final = final.with_audio(CompositeAudioClip([final.audio, dialogue_composite]))
                else:
                    final = final.with_audio(dialogue_composite)

        # 添加 BGM（支持多段）
        if self.bgm:
            print(f"  添加 {len(self.bgm)} 段 BGM...")
            from moviepy import AudioFileClip
            bgm_clips = []
            for i, bgm_cfg in enumerate(self.bgm):
                try:
                    bgm_clip = AudioFileClip(bgm_cfg.source)
                    bgm_start = bgm_cfg.start
                    bgm_end = bgm_cfg.end or total_dur
                    bgm_dur = bgm_end - bgm_start

                    if bgm_dur <= 0:
                        continue

                    # 截取需要的长度
                    if bgm_clip.duration < bgm_dur:
                        # BGM 比需要的短，循环
                        loops = int(bgm_dur / bgm_clip.duration) + 1
                        from moviepy import concatenate_audioclips
                        bgm_clip = concatenate_audioclips([bgm_clip] * loops)
                    bgm_clip = bgm_clip.subclipped(0, bgm_dur)

                    # 设置音量
                    bgm_clip = bgm_clip.with_volume_scaled(bgm_cfg.volume)

                    # 淡入淡出
                    effects = []
                    if bgm_cfg.fade_in > 0:
                        from moviepy import vfx
                        effects.append(vfx.AudioFadeIn(bgm_cfg.fade_in))
                    if bgm_cfg.fade_out > 0:
                        from moviepy import vfx
                        effects.append(vfx.AudioFadeOut(bgm_cfg.fade_out))
                    if effects:
                        bgm_clip = bgm_clip.with_effects(effects)

                    # 设置起始时间
                    bgm_clip = bgm_clip.with_start(bgm_start)
                    bgm_clips.append(bgm_clip)
                    print(f"    BGM {i+1}: {Path(bgm_cfg.source).name} ({bgm_start:.1f}s-{bgm_end:.1f}s)")
                except Exception as e:
                    print(f"  ⚠️ BGM {i+1} 加载失败: {e}")

            if bgm_clips:
                from moviepy import CompositeAudioClip
                bgm_composite = CompositeAudioClip(bgm_clips)
                if final.audio:
                    final = final.with_audio(CompositeAudioClip([final.audio, bgm_composite]))
                else:
                    final = final.with_audio(bgm_composite)
                print(f"  ✅ BGM 已添加")

        # 输出
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        print(f"  输出: {output_path}")
        final.write_videofile(
            output_path,
            fps=self.fps,
            codec="libx264",
            audio_codec="aac",
            threads=4,
            logger="bar",
        )

        for c in all_layers:
            try:
                c.close()
            except:
                pass

        size_mb = Path(output_path).stat().st_size / (1024 * 1024)
        print(f"  ✅ 完成: {output_path} ({size_mb:.1f}MB)")
        return output_path
