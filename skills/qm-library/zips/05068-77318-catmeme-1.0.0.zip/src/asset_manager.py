"""
素材索引系统
扫描 assets 和 templates 目录，建立可搜索的索引
"""
import yaml
import json
from pathlib import Path
from typing import Optional, List, Dict
from dataclasses import dataclass, field, asdict

ASSETS_DIR = Path(__file__).parent.parent / "assets"
TEMPLATES_DIR = Path(__file__).parent.parent / "templates"
INDEX_PATH = ASSETS_DIR / "index.yaml"
TEMPLATES_INDEX_PATH = TEMPLATES_DIR / "index.yaml"


@dataclass
class AssetInfo:
    """单个素材的元信息"""
    path: str                          # 相对于根目录的路径
    name: str                          # 文件名
    category: str                      # backgrounds / characters / effects / audio / green_screen / props
    subcategory: str                   # emotions / actions / reactions / sfx / bgm 等
    type: str                          # video / image / audio / gif
    tags: List[str] = field(default_factory=list)  # 标签
    duration: Optional[float] = None   # 时长 (秒, 视频/音频)
    size_kb: int = 0                   # 文件大小 KB
    chroma_key: Optional[str] = None   # 绿幕/蓝幕颜色
    source: str = "assets"             # 来源: assets / templates


def get_file_type(path: Path) -> str:
    """判断文件类型"""
    suffix = path.suffix.lower()
    if suffix in (".mp4", ".mov", ".avi", ".webm"):
        return "video"
    elif suffix in (".gif",):
        return "gif"
    elif suffix in (".png", ".jpg", ".jpeg", ".webp"):
        return "image"
    elif suffix in (".mp3", ".wav", ".m4a", ".aac", ".ogg"):
        return "audio"
    return "unknown"


def detect_chroma_key(path: Path) -> Optional[str]:
    """根据文件名猜测色度键类型"""
    name = path.stem.lower()
    if "green" in name:
        return "green"
    elif "blue" in name:
        return "blue"
    return None


def auto_tag(path: Path, category: str, subcategory: str) -> List[str]:
    """根据文件名和路径自动生成标签"""
    tags = []
    name = path.stem.lower()

    # 角色标签
    if "cat" in name or "猫" in name:
        tags.append("cat")
    if "doge" in name or "狗" in name:
        tags.append("doge")
    if "cheems" in name:
        tags.append("cheems")

    # 情绪标签
    emotion_map = {
        "laugh": "laugh", "laughing": "laugh", "happy": "happy", "笑": "laugh",
        "cry": "cry", "crying": "cry", "sad": "sad", "哭": "cry",
        "angry": "angry", "rage": "angry", "生气": "angry",
        "confused": "confused", "surprised": "surprised", "惊讶": "surprised",
        "sleepy": "sleepy", "sleeping": "sleepy", "困": "sleepy",
        "shy": "shy", "smug": "smug",
        "nodding": "nod", "shaking": "shake",
        "躺平": "sleepy", "斜眼": "smug", "走路": "walking",
    }
    for keyword, tag in emotion_map.items():
        if keyword in name:
            tags.append(tag)

    # 动作标签
    action_map = {
        "typing": "typing", "eating": "eating", "running": "running",
        "fighting": "fighting", "whispering": "whispering",
        "pointing": "pointing", "dancing": "dancing",
        "跳舞": "dancing", "走路": "walking", "躺平": "lying",
    }
    for keyword, tag in action_map.items():
        if keyword in name:
            tags.append(tag)

    # 背景标签
    if category == "backgrounds":
        tags.append("background")
        tags.append(subcategory)  # office / school / city / building / nature / transport

    # 绿幕标签
    if category == "green_screen":
        tags.append("green_screen")
        if subcategory == "emotions":
            tags.append("emotion")
        elif subcategory == "actions":
            tags.append("action")

    # 道具标签
    if category == "props":
        tags.append("prop")
        # 根据文件名添加道具类型
        prop_map = {
            "电脑": "computer", "手机": "phone", "床": "bed",
            "桌子": "table", "椅子": "chair", "冰淇淋": "icecream",
            "扇子": "fan", "书": "book", "杯子": "cup",
        }
        for keyword, tag in prop_map.items():
            if keyword in name:
                tags.append(tag)

    # 音效标签
    if category == "audio":
        for kw in ["error", "bonk", "laugh", "cry", "wow", "punch", "ding",
                    "drum", "whistle", "buzzer", "applause", "whoosh", "click"]:
            if kw in name:
                tags.append(kw)

    return list(set(tags))


def scan_assets() -> List[AssetInfo]:
    """扫描 assets 目录，返回所有素材信息"""
    assets = []

    for path in sorted(ASSETS_DIR.rglob("*")):
        if path.is_dir() or path.name.startswith(".") or path.name == "index.yaml":
            continue

        rel_path = path.relative_to(ASSETS_DIR)
        parts = rel_path.parts

        if len(parts) < 2:
            continue

        category = parts[0]  # backgrounds / characters / effects / audio
        subcategory = parts[1] if len(parts) > 2 else parts[0]

        # 从路径推断子类别
        if category == "characters" and len(parts) >= 3:
            # characters/cat/emotions/xxx.mp4 → subcategory = emotions
            subcategory = parts[2] if len(parts) > 3 else parts[1]
        elif category == "backgrounds":
            subcategory = parts[1] if len(parts) > 2 else "general"
        elif category == "audio":
            subcategory = parts[1] if len(parts) > 2 else "general"

        file_type = get_file_type(path)
        tags = auto_tag(path, category, subcategory)
        chroma_key = detect_chroma_key(path)

        asset = AssetInfo(
            path=str(rel_path),
            name=path.name,
            category=category,
            subcategory=subcategory,
            type=file_type,
            tags=tags,
            size_kb=int(path.stat().st_size / 1024),
            chroma_key=chroma_key,
            source="assets",
        )
        assets.append(asset)

    return assets


def scan_templates() -> List[AssetInfo]:
    """扫描 templates 目录，返回所有素材信息"""
    assets = []

    for path in sorted(TEMPLATES_DIR.rglob("*")):
        if path.is_dir() or path.name.startswith(".") or path.name == "index.yaml":
            continue

        rel_path = path.relative_to(TEMPLATES_DIR)
        parts = rel_path.parts

        if len(parts) < 2:
            continue

        category = parts[0]  # green_screen / backgrounds / props / effects
        subcategory = parts[1] if len(parts) > 2 else "general"

        # 从路径推断子类别
        if category == "green_screen" and len(parts) >= 3:
            # green_screen/cat/emotions/xxx.mp4 → subcategory = emotions
            subcategory = parts[2] if len(parts) > 3 else parts[1]
        elif category == "backgrounds":
            subcategory = parts[1] if len(parts) > 2 else "general"
        elif category == "props":
            subcategory = "general"

        file_type = get_file_type(path)
        tags = auto_tag(path, category, subcategory)
        chroma_key = detect_chroma_key(path)

        # 绿幕素材默认使用 green chroma_key
        if category == "green_screen" and not chroma_key:
            chroma_key = "green"

        asset = AssetInfo(
            path=str(rel_path),
            name=path.name,
            category=category,
            subcategory=subcategory,
            type=file_type,
            tags=tags,
            size_kb=int(path.stat().st_size / 1024),
            chroma_key=chroma_key,
            source="templates",
        )
        assets.append(asset)

    return assets


def build_index() -> Dict:
    """构建索引并保存到 index.yaml"""
    assets = scan_assets()
    templates = scan_templates()
    all_assets = assets + templates

    # 构建索引数据
    index_data = {
        "total_assets": len(all_assets),
        "categories": {},
        "tag_index": {},  # tag → [asset paths]
    }

    for asset in all_assets:
        # 按类别组织
        cat = asset.category
        if cat not in index_data["categories"]:
            index_data["categories"][cat] = {}
        sub = asset.subcategory
        if sub not in index_data["categories"][cat]:
            index_data["categories"][cat][sub] = []
        index_data["categories"][cat][sub].append(asdict(asset))

        # 按标签索引
        for tag in asset.tags:
            if tag not in index_data["tag_index"]:
                index_data["tag_index"][tag] = []
            index_data["tag_index"][tag].append(asset.path)

    # 保存
    with open(INDEX_PATH, "w", encoding="utf-8") as f:
        yaml.dump(index_data, f, allow_unicode=True, default_flow_style=False, sort_keys=True)

    print(f"[index] 索引已构建: {len(all_assets)} 个素材, {len(index_data['tag_index'])} 个标签")
    print(f"  - assets: {len(assets)} 个")
    print(f"  - templates: {len(templates)} 个")
    return index_data


def search_assets(
    query: str = "",
    category: Optional[str] = None,
    subcategory: Optional[str] = None,
    asset_type: Optional[str] = None,
    tags: Optional[List[str]] = None,
    chroma_key: Optional[str] = None,
    source: Optional[str] = None,
    limit: int = 50,
) -> List[AssetInfo]:
    """
    搜索素材

    Args:
        query: 关键词 (匹配文件名，支持中文)
        category: "backgrounds" / "characters" / "effects" / "audio" / "green_screen" / "props"
        subcategory: "emotions" / "actions" / "sfx" 等
        asset_type: "video" / "image" / "audio" / "gif"
        tags: 标签列表 (AND 逻辑)
        chroma_key: "green" / "blue"
        source: "assets" / "templates"
        limit: 返回结果数量限制

    Returns:
        匹配的 AssetInfo 列表
    """
    # 加载索引
    if not INDEX_PATH.exists():
        build_index()

    with open(INDEX_PATH, "r", encoding="utf-8") as f:
        index_data = yaml.safe_load(f)

    # 从索引重建 AssetInfo 列表
    all_assets = []
    for cat, subs in index_data.get("categories", {}).items():
        for sub, items in subs.items():
            for item in items:
                all_assets.append(AssetInfo(**item))

    # 过滤
    results = []
    for asset in all_assets:
        if category and asset.category != category:
            continue
        if subcategory and asset.subcategory != subcategory:
            continue
        if asset_type and asset.type != asset_type:
            continue
        if chroma_key and asset.chroma_key != chroma_key:
            continue
        if source and asset.source != source:
            continue
        if tags and not all(t in asset.tags for t in tags):
            continue
        if query:
            # 改进的搜索：支持多个关键词，支持中文
            query_lower = query.lower()
            name_lower = asset.name.lower()
            path_lower = asset.path.lower()
            
            # 分割查询词（支持空格分隔的多个关键词）
            keywords = query_lower.split()
            
            # 检查是否所有关键词都匹配
            matched = True
            for keyword in keywords:
                if keyword not in name_lower and keyword not in path_lower:
                    # 尝试匹配标签
                    if not any(keyword in tag for tag in asset.tags):
                        matched = False
                        break
            
            if not matched:
                continue
        
        results.append(asset)
    
    # 限制返回数量
    return results[:limit]


def get_asset_path(asset: AssetInfo) -> Path:
    """获取素材的绝对路径"""
    if asset.source == "templates":
        return TEMPLATES_DIR / asset.path
    return ASSETS_DIR / asset.path


def get_random_asset(category: str, subcategory: Optional[str] = None, tags: Optional[List[str]] = None) -> Optional[AssetInfo]:
    """随机获取一个素材"""
    import random
    results = search_assets(category=category, subcategory=subcategory, tags=tags)
    return random.choice(results) if results else None


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2 or sys.argv[1] == "build":
        build_index()

    elif sys.argv[1] == "search":
        query = sys.argv[2] if len(sys.argv) > 2 else ""
        results = search_assets(query=query)
        print(f"\n搜索 '{query}': {len(results)} 个结果")
        for r in results[:20]:
            print(f"  [{r.type}] {r.path}  tags={r.tags}")

    elif sys.argv[1] == "list":
        category = sys.argv[2] if len(sys.argv) > 2 else None
        results = search_assets(category=category)
        for r in results:
            print(f"  [{r.category}/{r.subcategory}] {r.name}  tags={r.tags}")

    elif sys.argv[1] == "stats":
        index = build_index()
        print(f"\n素材统计:")
        for cat, subs in index["categories"].items():
            total = sum(len(items) for items in subs.values())
            print(f"  {cat}: {total} 个")
            for sub, items in subs.items():
                print(f"    {sub}: {len(items)} 个")
        print(f"\n标签:")
        for tag, paths in sorted(index["tag_index"].items()):
            print(f"  {tag}: {len(paths)} 个")
