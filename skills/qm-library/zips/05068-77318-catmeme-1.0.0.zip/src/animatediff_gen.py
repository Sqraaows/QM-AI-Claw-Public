"""
AI 素材生成模块
- 背景: SDXL txt2img 生成静态图片
- 角色: AnimateDiff 生成动态动画
"""
import time
import json
import requests
from pathlib import Path
from typing import Optional


COMFYUI_URL = "http://127.0.0.1:8188"


def check_comfyui() -> bool:
    """检查 ComfyUI 是否运行"""
    try:
        resp = requests.get(f"{COMFYUI_URL}/system_stats", timeout=5)
        return resp.status_code == 200
    except:
        return False


def _wait_for_completion(prompt_id: str, timeout: int = 600) -> bool:
    """等待 ComfyUI 任务完成"""
    start_time = time.time()
    while True:
        time.sleep(3)
        queue_resp = requests.get(f"{COMFYUI_URL}/queue", timeout=5)
        queue = queue_resp.json()

        if len(queue.get("queue_running", [])) == 0:
            history_resp = requests.get(f"{COMFYUI_URL}/history", timeout=5)
            history = history_resp.json()

            if prompt_id in history:
                status = history[prompt_id].get("status", {})
                return status.get("status_str") == "success"

        if time.time() - start_time > timeout:
            return False


def generate_background_image(
    prompt: str,
    width: int = 1080,
    height: int = 1920,
    steps: int = 20,
    cfg: float = 7.5,
    seed: Optional[int] = None,
    checkpoint: str = "sd_xl_base_1.0.safetensors",
    output_prefix: str = "ai_bg",
) -> Optional[str]:
    """
    使用 SDXL txt2img 生成静态背景图片

    Args:
        prompt: 文本提示
        width/height: 尺寸
        steps: 采样步数
        cfg: CFG 比例
        seed: 随机种子
        checkpoint: 模型名称
        output_prefix: 输出文件前缀

    Returns:
        生成的图片文件路径
    """
    if not check_comfyui():
        print("[AI背景] ❌ ComfyUI 未运行")
        return None

    if seed is None:
        import random
        seed = random.randint(0, 2**32)

    # 使用 SDXL txt2img 工作流
    workflow = {
        "3": {
            "class_type": "KSampler",
            "inputs": {
                "cfg": cfg,
                "denoise": 1,
                "latent_image": ["5", 0],
                "model": ["4", 0],
                "negative": ["7", 0],
                "positive": ["6", 0],
                "sampler_name": "euler",
                "scheduler": "normal",
                "seed": seed,
                "steps": steps
            }
        },
        "4": {
            "class_type": "CheckpointLoaderSimple",
            "inputs": {
                "ckpt_name": checkpoint
            }
        },
        "5": {
            "class_type": "EmptyLatentImage",
            "inputs": {
                "batch_size": 1,
                "height": height,
                "width": width
            }
        },
        "6": {
            "class_type": "CLIPTextEncode",
            "inputs": {
                "clip": ["4", 1],
                "text": prompt
            }
        },
        "7": {
            "class_type": "CLIPTextEncode",
            "inputs": {
                "clip": ["4", 1],
                "text": "blurry, low quality, distorted, text, watermark"
            }
        },
        "8": {
            "class_type": "VAEDecode",
            "inputs": {
                "samples": ["3", 0],
                "vae": ["4", 2]
            }
        },
        "9": {
            "class_type": "SaveImage",
            "inputs": {
                "filename_prefix": output_prefix,
                "images": ["8", 0]
            }
        }
    }

    print(f"[AI背景] 生成: {prompt[:40]}... ({width}x{height})")
    resp = requests.post(
        f"{COMFYUI_URL}/api/prompt",
        json={"prompt": workflow},
        timeout=10
    )

    if resp.status_code != 200:
        print(f"[AI背景] ❌ 提交失败: {resp.text}")
        return None

    result = resp.json()
    prompt_id = result.get("prompt_id")
    if not prompt_id:
        print("[AI背景] ❌ 无 prompt_id")
        return None

    print(f"[AI背景] 任务ID: {prompt_id[:8]}...")
    start_time = time.time()

    if _wait_for_completion(prompt_id):
        # 查找输出文件
        output_dir = Path.home() / "Documents/comfy/ComfyUI/output"
        png_files = sorted(output_dir.glob(f"{output_prefix}*.png"), key=lambda p: p.stat().st_mtime, reverse=True)

        if png_files:
            elapsed = time.time() - start_time
            print(f"[AI背景] ✅ 完成: {png_files[0].name} ({elapsed:.1f}s)")
            return str(png_files[0])

    print("[AI背景] ❌ 生成失败")
    return None


def generate_cat_animation(
    emotion: str = "happy",
    style: str = "anime",
    background: str = "office",
    width: int = 512,
    height: int = 512,
    frames: int = 16,
    fps: int = 8,
    steps: int = 20,
    cfg: float = 7.5,
    seed: Optional[int] = None,
    checkpoint: str = "sd_xl_base_1.0.safetensors",
    model_name: str = "mm_sdxl_v10_beta.ckpt",
) -> Optional[str]:
    """
    使用 AnimateDiff 生成猫咪动画

    Args:
        emotion: 情绪 (happy/sad/angry/surprised/sleepy)
        style: 风格 (anime/realistic/cartoon)
        background: 背景描述 (office/bedroom/street)
        width/height: 分辨率
        frames: 帧数
        fps: 帧率

    Returns:
        生成的视频文件路径
    """
    if not check_comfyui():
        print("[AnimateDiff] ❌ ComfyUI 未运行")
        return None

    if seed is None:
        import random
        seed = random.randint(0, 2**32)

    emotion_map = {
        "happy": "happy, cheerful, smiling, wagging tail",
        "sad": "sad, crying, teary eyes, droopy ears",
        "angry": "angry, grumpy, puffed up, hissing",
        "surprised": "surprised, shocked, wide eyes, jumping",
        "sleepy": "sleepy, yawning, dozing off, curled up",
    }
    style_map = {
        "anime": "anime style, studio ghibli, vibrant colors",
        "realistic": "photorealistic, detailed fur, natural lighting",
        "cartoon": "cartoon style, simple shapes, bold colors",
    }
    bg_map = {
        "office": "modern office, desk, computer, papers",
        "bedroom": "cozy bedroom, bed, window, warm lighting",
        "street": "city street, buildings, sidewalk, daytime",
    }

    prompt = f"a cute orange cat, {emotion_map.get(emotion, emotion)}, {style_map.get(style, style)}, {bg_map.get(background, background)}, high quality, detailed"
    output_prefix = f"cat_{emotion}_{background}"

    workflow = {
        "3": {
            "class_type": "KSampler",
            "inputs": {
                "cfg": cfg,
                "denoise": 1,
                "latent_image": ["7", 0],
                "model": ["12", 0],
                "negative": ["6", 0],
                "positive": ["5", 0],
                "sampler_name": "euler",
                "scheduler": "normal",
                "seed": seed,
                "steps": steps
            }
        },
        "4": {
            "class_type": "CheckpointLoaderSimple",
            "inputs": {"ckpt_name": checkpoint}
        },
        "5": {
            "class_type": "CLIPTextEncode",
            "inputs": {"clip": ["4", 1], "text": prompt}
        },
        "6": {
            "class_type": "CLIPTextEncode",
            "inputs": {"clip": ["4", 1], "text": "blurry, low quality, distorted"}
        },
        "7": {
            "class_type": "EmptyLatentImage",
            "inputs": {"batch_size": frames, "height": height, "width": width}
        },
        "8": {
            "class_type": "VAEDecode",
            "inputs": {"samples": ["3", 0], "vae": ["4", 2]}
        },
        "9": {
            "class_type": "VHS_VideoCombine",
            "inputs": {
                "frame_rate": fps,
                "loop_count": 0,
                "filename_prefix": output_prefix,
                "format": "video/h264-mp4",
                "pingpong": False,
                "save_output": True,
                "images": ["8", 0]
            }
        },
        "12": {
            "class_type": "ADE_AnimateDiffLoaderWithContext",
            "inputs": {
                "model": ["4", 0],
                "model_name": model_name,
                "beta_schedule": "autoselect",
                "context_options": ["13", 0]
            }
        },
        "13": {
            "class_type": "ADE_StandardUniformContextOptions",
            "inputs": {
                "context_length": frames,
                "context_stride": 1,
                "context_overlap": 4,
                "closed_loop": False
            }
        }
    }

    print(f"[AnimateDiff] 生成: {prompt[:40]}...")
    resp = requests.post(
        f"{COMFYUI_URL}/api/prompt",
        json={"prompt": workflow},
        timeout=10
    )

    if resp.status_code != 200:
        print(f"[AnimateDiff] ❌ 提交失败: {resp.text}")
        return None

    result = resp.json()
    prompt_id = result.get("prompt_id")
    if not prompt_id:
        print("[AnimateDiff] ❌ 无 prompt_id")
        return None

    print(f"[AnimateDiff] 任务ID: {prompt_id[:8]}...")
    start_time = time.time()

    if _wait_for_completion(prompt_id, timeout=600):
        output_dir = Path.home() / "Documents/comfy/ComfyUI/output"
        video_files = sorted(output_dir.glob(f"{output_prefix}*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)

        if video_files:
            elapsed = time.time() - start_time
            print(f"[AnimateDiff] ✅ 完成: {video_files[0].name} ({elapsed:.1f}s)")
            return str(video_files[0])

    print("[AnimateDiff] ❌ 生成失败")
    return None


if __name__ == "__main__":
    print("测试 AI 素材生成...")

    # 测试背景生成
    print("\n--- 测试背景生成 ---")
    bg = generate_background_image(
        prompt="modern office desk with computer and code on screen, anime style, warm lighting",
        width=1080,
        height=1920,
    )
    print(f"背景: {bg}")

    # 测试角色动画生成
    print("\n--- 测试角色动画 ---")
    anim = generate_cat_animation(emotion="happy", style="anime", background="office")
    print(f"动画: {anim}")
