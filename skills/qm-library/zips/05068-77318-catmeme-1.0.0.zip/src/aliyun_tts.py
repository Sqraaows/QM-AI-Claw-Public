"""
阿里云语音合成模块
使用阿里云智能语音交互服务
"""
import json
import time
import hashlib
import hmac
import base64
import requests
from pathlib import Path
from typing import Optional
from urllib.parse import quote


class AliyunTTS:
    """阿里云语音合成"""
    
    def __init__(self, access_key_id: str, access_key_secret: str, appkey: str = "default"):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.appkey = appkey
        self.token = None
        self.token_expire = 0
    
    def _get_token(self) -> Optional[str]:
        """获取访问 Token"""
        if self.token and time.time() < self.token_expire:
            return self.token
        
        # 构建请求参数
        params = {
            'Action': 'CreateToken',
            'Format': 'JSON',
            'Version': '2019-02-28',
            'AccessKeyId': self.access_key_id,
            'SignatureMethod': 'HMAC-SHA256',
            'Timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'SignatureVersion': '1.0',
            'SignatureNonce': str(int(time.time() * 1000)),
        }
        
        # 按字母顺序排序参数
        sorted_params = sorted(params.items())
        
        # 构建规范化查询字符串
        canonicalized_query_string = '&'.join(
            [quote(k, safe='') + '=' + quote(v, safe='') for k, v in sorted_params]
        )
        
        # 构建签名字符串
        string_to_sign = 'GET&%2F&' + quote(canonicalized_query_string, safe='')
        
        # 计算签名
        sign = base64.b64encode(
            hmac.new(
                (self.access_key_secret + '&').encode('utf-8'),
                string_to_sign.encode('utf-8'),
                hashlib.sha256
            ).digest()
        ).decode()
        
        params['Signature'] = sign
        
        try:
            resp = requests.get(
                'https://nls-meta.cn-shanghai.aliyuncs.com/',
                params=params,
                timeout=10
            )
            result = resp.json()
            token = result.get('Token', {}).get('Id')
            expire_time = result.get('Token', {}).get('ExpireTime', 0)
            
            if token:
                self.token = token
                self.token_expire = expire_time
                print('[阿里云TTS] Token 获取成功')
                return token
            else:
                print('[阿里云TTS] 获取 Token 失败: ' + str(result))
                return None
        except Exception as e:
            print('[阿里云TTS] 获取 Token 异常: ' + str(e))
            return None
    
    def synthesize(
        self,
        text: str,
        voice: str = "xiaoyun",
        format: str = "mp3",
        sample_rate: int = 16000,
        volume: int = 50,
        speech_rate: int = 0,
        pitch_rate: int = 0,
    ) -> Optional[bytes]:
        """
        语音合成
        
        Args:
            text: 要合成的文字
            voice: 发音人
            format: 音频格式 (mp3/wav/pcm)
            sample_rate: 采样率
            volume: 音量 (0-100)
            speech_rate: 语速 (-500~500)
            pitch_rate: 音调 (-500~500)
        
        Returns:
            音频数据 (bytes)
        """
        token = self._get_token()
        if not token:
            return None
        
        # 调用语音合成 API
        tts_params = {
            "appkey": self.appkey,
            "text": text,
            "token": token,
            "format": format,
            "sample_rate": sample_rate,
            "voice": voice,
            "volume": volume,
            "speech_rate": speech_rate,
            "pitch_rate": pitch_rate,
        }
        
        try:
            resp = requests.post(
                "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts",
                json=tts_params,
                timeout=30
            )
            
            if resp.status_code == 200:
                # 检查是否是 JSON 错误响应
                try:
                    error_result = resp.json()
                    if 'error_message' in error_result or 'status' in error_result:
                        print('[阿里云TTS] 合成失败: ' + str(error_result))
                        return None
                except:
                    pass
                return resp.content
            else:
                print('[阿里云TTS] 合成失败: ' + str(resp.status_code) + ' ' + resp.text)
                return None
        except Exception as e:
            print('[阿里云TTS] 合成失败: ' + str(e))
            return None


# 可用的中文声音列表
ALIYUN_VOICES = {
    # 标准音色
    "xiaoyun": "温柔女声",
    "xiaogang": "标准男声",
    "xiaoxuan": "温柔女声",
    "xiaoyu": "活泼女声",
    "xiaozhi": "知性女声",
    "xiaomei": "甜美女声",
    "xiaoyan": "标准女声",
    "xiaoyang": "标准男声",
    "xiaojin": "标准女声",
    "xiaobei": "标准女声",
    
    # 情感音色
    "danyun": "丹云（情感合成）",
    "daxia": "大夏（情感合成）",
    "dawei": "大卫（情感合成）",
    "danxi": "丹溪（情感合成）",
    
    # 英文音色
    "catherine": "英文女声",
    "henry": "英文男声",
    
    # 日文音色
    "haruka": "日文女声",
    "takumi": "日文男声",
}


def generate_aliyun_tts(
    text: str,
    output_path: str,
    access_key_id: str,
    access_key_secret: str,
    appkey: str = "default",
    voice: str = "xiaoyun",
    speech_rate: int = 0,
    pitch_rate: int = 0,
    volume: int = 50,
) -> Optional[str]:
    """
    生成阿里云 TTS 音频
    
    Args:
        text: 要合成的文字
        output_path: 输出文件路径
        access_key_id: 阿里云 AccessKey ID
        access_key_secret: 阿里云 AccessKey Secret
        appkey: 阿里云 Appkey
        voice: 发音人
        speech_rate: 语速 (-500~500)
        pitch_rate: 音调 (-500~500)
        volume: 音量 (0-100)
    
    Returns:
        音频文件路径
    """
    tts = AliyunTTS(access_key_id, access_key_secret, appkey)
    
    audio_data = tts.synthesize(
        text=text,
        voice=voice,
        speech_rate=speech_rate,
        pitch_rate=pitch_rate,
        volume=volume,
    )
    
    if audio_data:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(audio_data)
        print("[阿里云TTS] 已生成: " + output_path)
        return output_path
    
    return None


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 4:
        print("用法: python aliyun_tts.py <文字> <输出路径> <access_key_id> <access_key_secret> [voice]")
        sys.exit(1)
    
    text = sys.argv[1]
    output = sys.argv[2]
    ak_id = sys.argv[3]
    ak_secret = sys.argv[4]
    voice = sys.argv[5] if len(sys.argv) > 5 else "xiaoyun"
    
    result = generate_aliyun_tts(text, output, ak_id, ak_secret, voice)
    if result:
        print("生成成功: " + result)
    else:
        print("生成失败")
