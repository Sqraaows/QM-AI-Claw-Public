#!/bin/bash
# 猫 Meme 视频生成器 - Skill 安装脚本
# 将 SKILL.md 安装到 ~/.hermes/skills/ 目录

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_NAME="cat-meme-video"
SKILL_DIR="$HOME/.hermes/skills/creative/$SKILL_NAME"

echo "🐱 猫 Meme 视频生成器 - Skill 安装"
echo "=================================="
echo ""

# 创建 skill 目录
mkdir -p "$SKILL_DIR"

# 复制 SKILL.md
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/SKILL.md"
echo "✅ SKILL.md 已安装到 $SKILL_DIR/SKILL.md"

# 创建符号链接到项目目录（方便引用）
if [ ! -e "$SKILL_DIR/project" ]; then
    ln -s "$SCRIPT_DIR" "$SKILL_DIR/project"
    echo "✅ 项目目录已链接到 $SKILL_DIR/project"
fi

# 检查 config.yaml
if [ ! -f "$SCRIPT_DIR/config.yaml" ]; then
    echo ""
    echo "⚠️  config.yaml 不存在"
    echo "   运行: cp config.yaml.example config.yaml"
    echo "   然后编辑 config.yaml 填入你的 API keys"
fi

# 检查依赖
echo ""
echo "📦 检查依赖..."
pip install -q moviepy Pillow edge-tts requests PyYAML numpy 2>/dev/null && \
    echo "✅ 依赖已安装" || \
    echo "⚠️  部分依赖安装失败，请手动运行: pip install -r requirements.txt"

echo ""
echo "=================================="
echo "🎉 安装完成！"
echo ""
echo "使用方式："
echo "  1. 对 AI 说: '帮我做一个猫 meme 视频'"
echo "  2. 或直接运行: python $SCRIPT_DIR/run.py examples/sweet_lab.yaml"
echo ""
