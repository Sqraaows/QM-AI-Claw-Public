#!/usr/bin/env python3
"""
猫 Meme 视频生成器 v2 - 新合成引擎入口
支持分层合成 + 动画系统 + 时间轴调度

用法:
  python run.py <剧本.yaml>               # 生成视频
  python run.py <剧本.yaml> -o output.mp4  # 指定输出
  python run.py --demo                     # 运行测试剧本
  python run.py --parse <剧本.yaml>        # 仅解析不渲染
"""
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.script_parser import parse_script_v2
from src.asset_manager import build_index


def main():
    import argparse

    parser = argparse.ArgumentParser(description="🐱 猫 Meme 视频生成器 v2")
    parser.add_argument("script", nargs="?", help="剧本 YAML 文件")
    parser.add_argument("-o", "--output", help="输出文件名")
    parser.add_argument("--demo", action="store_true", help="运行测试剧本")
    parser.add_argument("--parse", metavar="SCRIPT", help="仅解析剧本")
    parser.add_argument("--reindex", action="store_true", help="重建素材索引")

    args = parser.parse_args()

    # 重建索引
    if args.reindex:
        build_index()
        return

    # 解析模式
    if args.parse:
        parse_script_v2(args.parse)
        return

    # Demo 模式
    if args.demo:
        args.script = str(PROJECT_ROOT / "examples" / "v2_test.yaml")

    if not args.script:
        parser.print_help()
        sys.exit(1)

    # 确保索引存在
    index_path = PROJECT_ROOT / "assets" / "index.yaml"
    if not index_path.exists():
        print("[init] 首次运行，构建素材索引...")
        build_index()

    # 解析剧本
    print("🐱 猫 Meme 视频生成器 v2")
    print(f"📜 剧本: {args.script}")
    print()

    start_time = time.time()

    timeline, meta = parse_script_v2(args.script)

    # 输出路径
    if args.output:
        output_path = args.output
    else:
        output_dir = PROJECT_ROOT / "output" / meta["title"].replace(" ", "_")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(output_dir / f"{meta['title'].replace(' ', '_')}_v2.mp4")

    # 生成对话音频
    dialogue_audios = []  # [(audio_path, start_time, end_time, character_id)]
    if any(s.dialogues for s in timeline.scenes):
        print(f"\n🎤 生成对话音频...")
        from src.tts_gen import generate_tts
        audio_dir = PROJECT_ROOT / "output" / meta["title"].replace(" ", "_")
        audio_dir.mkdir(parents=True, exist_ok=True)

        current_time = 0.0
        for scene_idx, scene in enumerate(timeline.scenes):
            for dlg_idx, dlg in enumerate(scene.dialogues):
                char_def = timeline.characters.get(dlg.character_id)
                if not char_def:
                    print(f"  ⚠️ 角色 {dlg.character_id} 未定义，跳过对话")
                    continue

                audio_file = str(audio_dir / f"dlg_{scene_idx}_{dlg_idx}.mp3")
                generate_tts(
                    text=dlg.text,
                    output_path=audio_file,
                    voice=char_def.voice,
                    rate=char_def.rate,
                    pitch=char_def.pitch,
                    aliyun_voice=char_def.voice if char_def.voice in ["xiaoyun", "xiaogang", "xiaoxuan", "xiaoyu", "xiaozhi", "xiaomei", "xiaoyan", "xiaoyang", "xiaojin", "xiaobei", "danyun", "daxia", "dawei", "danxi"] else None,
                )
                dialogue_audios.append({
                    "path": audio_file,
                    "start": current_time + dlg.appear,
                    "end": current_time + (dlg.disappear or scene.duration),
                    "character_id": dlg.character_id,
                    "text": dlg.text,
                })
                print(f"  ✅ [{char_def.name}] {dlg.text[:20]}...")
            current_time += scene.duration

    # 生成旁白音频
    voiceover_audio = None
    if timeline.voiceover:
        print(f"\n🎤 生成旁白音频...")
        from src.tts_gen import generate_tts
        audio_dir = PROJECT_ROOT / "output" / meta["title"].replace(" ", "_")
        audio_dir.mkdir(parents=True, exist_ok=True)
        voiceover_audio = str(audio_dir / "voiceover.mp3")
        generate_tts(
            text=timeline.voiceover.text,
            output_path=voiceover_audio,
            voice=timeline.voiceover.voice,
            rate=timeline.voiceover.rate,
            pitch=timeline.voiceover.pitch,
        )
        print(f"  ✅ 旁白音频: {voiceover_audio}")

    # 渲染
    print(f"\n{'='*50}")
    print("🎬 开始渲染")
    print(f"{'='*50}")

    result = timeline.render(
        output_path,
        voiceover_audio=voiceover_audio,
        dialogue_audios=dialogue_audios,
    )

    elapsed = time.time() - start_time
    print(f"\n{'='*50}")
    print(f"🎉 完成! 耗时 {elapsed:.1f} 秒")
    print(f"📁 输出: {result}")
    print(f"📊 {meta['scene_count']} 场景, {meta['total_duration']:.0f}秒")
    print(f"{'='*50}")


if __name__ == "__main__":
    main()
