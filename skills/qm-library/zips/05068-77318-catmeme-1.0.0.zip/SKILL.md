---
name: cat-meme-video
description: 从 YAML 剧本自动生成猫咪 meme 风格短视频，支持分层合成、TTS 语音、AI 素材生成
version: 3.4.0
triggers:
  - "猫 meme 视频"
  - "cat meme video"
  - "猫咪动画"
  - "帮我做一个视频"
---

# 🐱 猫 Meme 视频生成器

从 YAML 剧本自动生成猫咪 meme 风格短视频。

## 快速开始

```bash
# 1. 进入项目目录
cd /Users/guoguoguo/hermes/2026-05-21_2109_cat-meme-video

# 2. 安装依赖
pip install -r requirements.txt

# 3. 配置 TTS（复制模板，可选填阿里云 keys）
cp config.yaml.example config.yaml

# 4. 生成视频
python run.py examples/sweet_lab.yaml
```

## 工作流程

用户描述 → AI 生成 YAML 剧本 → 用户确认素材 → 渲染视频

```
YAML 剧本 → 解析 → TTS语音 → AI素材(可选) → 分层合成 → MP4
```

## 剧本格式

```yaml
title: "视频标题"
resolution: [1080, 1920]
fps: 24

characters:
  - id: "cat"
    name: "小猫"
    voice: "xiaomei"       # 阿里云甜美女声
  - id: "doge"
    name: "柴犬"
    voice: "xiaogang"      # 阿里云标准男声

bgm:                        # 可选，支持多段
  - source: "happy.mp3"    # 放到 templates/bgm/
    start: 0.0
    end: 6.0
    volume: 0.3

scenes:
  - name: "场景名"
    duration: 7.0
    background:
      source: "backgrounds/office/xxx.jpeg"
      # 或 ai_generate: {type: "background", prompt: "anime style office"}
    characters:
      - source: "green_screen/cat/emotions/xxx.mp4"
        character_id: "cat"
        position: "center"
        size: 0.5
        speak_scale: 1.2
        chroma_key: "green"
        enter: {type: "slide_left", duration: 0.5}
    text:
      - content: "文字"
        position: "top"
        font_size: 56
        appear: 0.5
        disappear: 3.5
        animation: "pop_in"
    dialogues:
      - character_id: "cat"
        text: "对话内容"
        appear: 1.0
        disappear: 3.0
```

## 素材检索

```bash
python preview_assets.py search 猫哭
python preview_assets.py list backgrounds
```

## 可用声音

| 声音 | 说明 | 引擎 |
|------|------|------|
| `xiaomei` | 甜美女声 | 阿里云 |
| `xiaoyun` | 温柔女声 | 阿里云 |
| `xiaogang` | 标准男声 | 阿里云 |
| `zh-CN-XiaoyiNeural` | 活泼女声 | Edge TTS |
| `zh-CN-YunxiaNeural` | 可爱男声 | Edge TTS |

## 注意事项

- 素材路径相对于 `templates/` 目录
- 绿幕素材必须设置 `chroma_key: "green"`
- AI 生成需要 ComfyUI 运行中
- config.yaml 包含 API keys，不能上传 git

## 项目路径

`/Users/guoguoguo/hermes/2026-05-21_2109_cat-meme-video`
