# 🐱 猫 Meme 视频生成 Skill

**用自然语言，一句话生成猫咪 meme 视频。**

> "做一个研究生被导师催论文的视频"
> 
> → AI 自动生成剧本 → 你选择素材和风格 → 渲染输出视频

## ✨ 核心特色

### 🗣️ 自然语言驱动

不需要写代码、不需要懂剪辑。只要用自然语言描述你想要的内容，AI 会帮你：

- **分析剧情** → 自动拆分场景、角色、对话
- **搜索素材** → 从 3000+ 素材库中匹配合适的猫咪、背景、道具
- **生成剧本** → 输出可执行的 YAML 剧本

### 🎭 交互式创作

AI 不会替你做所有决定，而是给你选择：

```
🎬 场景 1: 代码报错 (5秒)

请选择角色素材：
1. 猫哭猫.mp4 (哭泣)
2. 猫躺平猫.mp4 (躺平)
3. 猫生气猫.mp4 (生气)

请选择背景：
1. 办公室.jpeg
2. AI 生成 - "anime style office"
3. 其他

请选择入场动画：
1. pop_in (弹出)
2. slide_left (从左滑入)
```

你说"1, 2, 1"，AI 就按你的选择生成剧本。

### 🎬 专业级输出

- **分层合成** — 背景、角色、文字、特效独立控制
- **说话时放大** — 角色说话时自动放大，突出重点
- **多段 BGM** — 不同场景配不同音乐，支持淡入淡出
- **多角色对话** — 每个角色独立音色，语音一致
- **AI 素材生成** — 没有合适的素材？AI 帮你生成

## 🚀 快速开始

```bash
# 1. 克隆仓库
git clone https://github.com/gwyxjtu/cat-meme-vedio.git
cd cat-meme-vedio

# 2. 安装 Skill（让 AI 认识这个项目）
./install.sh

# 3. 安装依赖
pip install -r requirements.txt

# 4. 配置 TTS
cp config.yaml.example config.yaml

# 5. 开始创作！
# 方式一：直接对 AI 说
# "帮我做一个猫咪加班到崩溃的视频"

# 方式二：用示例剧本
python run.py examples/sweet_lab.yaml
```

## 📝 一个完整的创作流程

### Step 1: 你说想法

> "做一个研究生课题组师姐和师弟的甜蜜对话，师姐问师弟刚刚聊天的女生是谁，师弟说我们只是朋友，师姐吃醋了，师弟说我是说我们"

### Step 2: AI 分析并给你选择

```
分析完成：
- 场景：1个（办公室对话）
- 角色：师姐、师弟
- 情绪：好奇 → 吃醋 → 甜蜜

请选择师姐素材：
1. 害羞羞小猫（害羞）
2. 情侣猫（甜蜜）
3. 猫哭猫（委屈）

请选择师弟素材：
1. 得意脸猫（得意）
2. 疑惑猫（疑惑）
3. 开心猫（开心）

请选择背景：
1. 办公室.jpeg
2. AI 生成 - "anime style office, warm lighting"

你: 1, 1, 2
```

### Step 3: AI 生成剧本

```yaml
title: "课题组甜蜜对话"
characters:
  - id: "sister"
    name: "师姐"
    voice: "xiaomei"      # 甜美女声
  - id: "brother"
    name: "师弟"
    voice: "xiaogang"     # 标准男声

scenes:
  - name: "甜蜜对话"
    duration: 14.0
    background:
      ai_generate:
        type: "background"
        prompt: "anime style office, warm lighting"
    characters:
      - source: "green_screen/cat/emotions/xxx.mp4"
        character_id: "sister"
        speak_scale: 1.2    # 说话时放大
    dialogues:
      - character_id: "sister"
        text: "师弟，刚刚和你聊天的女生是谁啊"
      - character_id: "brother"
        text: "我们只是朋友"
      - character_id: "sister"
        text: "啊，那我也会吃醋"
      - character_id: "brother"
        text: "我是说我们"
```

### Step 4: 渲染输出

```
📁 output/课题组甜蜜对话/课题组甜蜜对话_v2.mp4
📊 1080x1920, 24fps, 14秒
🔊 阿里云 TTS (甜美女声 + 标准男声)
🖼️ AI 生成背景
⏱️ 耗时 50 秒
```

## 🎯 适用场景

- **短视频创作** — 抖音、B站、小红书的猫 meme 内容
- **表情包制作** — 把静态表情包变成动态视频
- **故事讲述** — 用猫咪角色讲任何故事
- **社媒运营** — 快速产出大量猫 meme 内容

## 🛠️ 技术栈

| 模块 | 技术 | 用途 |
|------|------|------|
| 视频合成 | MoviePy 2.x | 分层合成、动画、转场 |
| 语音合成 | 阿里云 TTS / Edge TTS | 角色对话、旁白 |
| AI 素材 | SDXL + AnimateDiff | 背景生成、角色动画 |
| 素材管理 | 自建索引 | 3000+ 素材检索 |

## 📁 素材库

```
templates/
├── green_screen/    # 绿幕素材 (2400+)
│   ├── cat/         # 猫咪表情、动作
│   └── other/       # 其他角色
├── backgrounds/     # 背景图 (400+)
│   ├── office/      # 办公室
│   ├── school/      # 学校
│   ├── city/        # 城市
│   └── nature/      # 自然
├── bgm/             # 背景音乐
└── props/           # 道具 (500+)
```

## 🔧 进阶功能

### AI 素材生成

没有合适的素材？让 AI 生成：

```yaml
# 生成背景
background:
  ai_generate:
    type: "background"
    prompt: "anime style office, warm lighting, detailed"

# 生成角色动画
characters:
  - ai_generate:
      emotion: "happy"
      style: "anime"
      background: "office"
```

### 多段 BGM

不同场景配不同音乐：

```yaml
bgm:
  - source: "happy.mp3"
    start: 0.0
    end: 6.0
    volume: 0.3
    fade_in: 1.0
  - source: "sad.mp3"
    start: 6.0
    end: 14.0
    volume: 0.3
    fade_in: 1.0
```

### 说话时放大

角色说话时自动放大，突出重点：

```yaml
characters:
  - source: "green_screen/cat/emotions/xxx.mp4"
    speak_scale: 1.2  # 放大 1.2 倍
```

## 📦 安装 Skill

```bash
./install.sh
```

安装后可以对 AI 说"帮我做一个猫 meme 视频"来启动创作流程。

## 📄 License

MIT

## 🙏 致谢

- [MoviePy](https://github.com/Zulko/moviepy) - 视频处理
- [Edge TTS](https://github.com/rany2/edge-tts) - 语音合成
- [ComfyUI](https://github.com/comfyanonymous/ComfyUI) - AI 图像/视频生成
- [AnimateDiff](https://github.com/guoyww/AnimateDiff) - 动画生成
