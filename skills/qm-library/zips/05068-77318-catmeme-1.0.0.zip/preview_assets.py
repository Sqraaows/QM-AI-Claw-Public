#!/usr/bin/env python3
"""
素材预览脚本
查看整理后的素材库
"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.asset_manager import search_assets, build_index, get_asset_path


def show_stats():
    """显示素材统计"""
    print("🐱 猫 Meme 素材库统计")
    print("=" * 50)
    
    # 绿幕素材
    green_screen = search_assets(category="green_screen")
    print(f"\n🎬 绿幕素材: {len(green_screen)} 个")
    emotions = [a for a in green_screen if a.subcategory == "emotions"]
    actions = [a for a in green_screen if a.subcategory == "actions"]
    special = [a for a in green_screen if a.subcategory == "special"]
    print(f"  - 表情类: {len(emotions)} 个")
    print(f"  - 动作类: {len(actions)} 个")
    print(f"  - 特殊类: {len(special)} 个")
    
    # 背景图
    backgrounds = search_assets(category="backgrounds")
    print(f"\n🖼️  背景图: {len(backgrounds)} 张")
    for sub in set(a.subcategory for a in backgrounds):
        count = len([a for a in backgrounds if a.subcategory == sub])
        print(f"  - {sub}: {count} 张")
    
    # 道具
    props = search_assets(category="props")
    print(f"\n🎭 道具素材: {len(props)} 个")
    
    # 总计
    total = len(green_screen) + len(backgrounds) + len(props)
    print(f"\n📊 总计: {total} 个素材")


def search_by_keyword(keyword: str):
    """按关键词搜索素材"""
    print(f"\n🔍 搜索: '{keyword}'")
    print("-" * 50)
    
    results = search_assets(query=keyword)
    
    if not results:
        print("未找到匹配的素材")
        return
    
    print(f"找到 {len(results)} 个结果:")
    for i, asset in enumerate(results[:20], 1):
        path = get_asset_path(asset)
        print(f"  {i}. [{asset.category}] {asset.name}")
        print(f"     路径: {path}")
        print(f"     标签: {', '.join(asset.tags)}")
        print()


def list_by_category(category: str):
    """按类别列出素材"""
    print(f"\n📁 {category} 素材列表")
    print("-" * 50)
    
    results = search_assets(category=category)
    
    if not results:
        print(f"未找到 {category} 类别的素材")
        return
    
    print(f"共 {len(results)} 个素材:")
    
    # 按子类别分组
    by_subcategory = {}
    for asset in results:
        sub = asset.subcategory
        if sub not in by_subcategory:
            by_subcategory[sub] = []
        by_subcategory[sub].append(asset)
    
    for sub, assets in sorted(by_subcategory.items()):
        print(f"\n  {sub} ({len(assets)} 个):")
        for asset in assets[:5]:  # 每个子类别最多显示5个
            print(f"    - {asset.name}")
        if len(assets) > 5:
            print(f"    ... 还有 {len(assets) - 5} 个")


def main():
    if len(sys.argv) < 2:
        print("🐱 猫 Meme 素材预览工具")
        print("=" * 50)
        print("用法:")
        print("  python preview_assets.py stats          # 显示统计")
        print("  python preview_assets.py search <关键词> # 搜索素材")
        print("  python preview_assets.py list <类别>    # 列出素材")
        print("  python preview_assets.py rebuild        # 重建索引")
        print()
        print("类别: green_screen, backgrounds, props")
        return
    
    command = sys.argv[1]
    
    if command == "stats":
        show_stats()
    
    elif command == "search":
        if len(sys.argv) < 3:
            print("请提供搜索关键词")
            return
        keyword = sys.argv[2]
        search_by_keyword(keyword)
    
    elif command == "list":
        if len(sys.argv) < 3:
            print("请提供类别 (green_screen, backgrounds, props)")
            return
        category = sys.argv[2]
        list_by_category(category)
    
    elif command == "rebuild":
        print("重建索引...")
        build_index()
        print("完成!")
    
    else:
        print(f"未知命令: {command}")


if __name__ == "__main__":
    main()
