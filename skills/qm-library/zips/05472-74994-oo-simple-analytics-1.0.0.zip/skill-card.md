## Description: <br>
Simple Analytics helps agents use an OOMOL-connected account to list websites, retrieve aggregated statistics, export datapoints, and send server-side events. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and marketing operators use this skill to work with Simple Analytics from an authenticated OOMOL account. It supports listing websites, retrieving aggregated stats, exporting datapoints, and sending server-side events after confirmation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected Simple Analytics account through OOMOL. <br>
Mitigation: Install only if the user trusts OOMOL and is comfortable using OOMOL-managed credentials for Simple Analytics. <br>
Risk: The first-time setup path may run a remote CLI installer. <br>
Mitigation: Review the installer or follow OOMOL's official installation guidance before running the install command. <br>
Risk: The send_event action changes Simple Analytics state. <br>
Mitigation: Confirm the exact payload and intended effect with the user before allowing send_event to run. <br>
Risk: Connector input and output schemas may change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [Simple Analytics homepage](https://simpleanalytics.com) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-simple-analytics) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI installation guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches live connector schemas before constructing action payloads; action responses are returned as JSON through the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
