## Description: <br>
PortKeep helps agents manage, secure, and monitor open ports and services across nodes with scan, claim, audit, drift detection, threat intelligence, and background monitoring workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jchandler187](https://clawhub.ai/user/jchandler187) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use PortKeep to inspect local or remote listening services, register expected ports, detect drift, audit firewall, CVE, and threat-intelligence exposure, and prepare monitoring commands for cron or daemon workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: PortKeep workflows can involve sensitive credentials such as abuse.ch Auth-Key values and SSH keys for remote node scans. <br>
Mitigation: Provide credentials through environment variables or SSH configuration, scope them narrowly, and avoid pasting secrets into prompts or shared logs. <br>
Risk: Port scans, daemon monitoring, and drift checks may reveal service inventory or trigger operational alerts. <br>
Mitigation: Run commands only on infrastructure you are authorized to inspect, review generated commands before execution, and prefer JSON or quiet mode for controlled automation. <br>


## Reference(s): <br>
- [PortKeep on ClawHub](https://clawhub.ai/jchandler187/portkeep) <br>
- [PortKeep GitHub releases](https://github.com/jchandler187/portkeep/releases/latest) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell command examples and configuration notes] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include JSON and quiet-mode CLI options for scripting and cron workflows.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and artifact manifests) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
