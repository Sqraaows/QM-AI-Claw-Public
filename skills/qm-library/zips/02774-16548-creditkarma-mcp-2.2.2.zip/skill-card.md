## Description: <br>
Accesses Credit Karma transaction data through an MCP server for syncing, querying, and spending analysis. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agent users use this skill to configure and operate a Credit Karma MCP server that syncs transaction data into a local SQLite database and answers questions about accounts, merchants, categories, and spending. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires Credit Karma session cookies and can persist sensitive financial transaction data locally. <br>
Mitigation: Use it only when comfortable granting that access, protect any .env or MCP configuration containing CK_COOKIES, and avoid sharing logs or configuration files that may contain credentials or financial data. <br>
Risk: Expired or exposed Credit Karma session credentials may continue to affect account access until refreshed or revoked. <br>
Mitigation: Refresh or revoke the Credit Karma session if credentials may have been exposed, and prefer explicit Credit Karma prompts when using the skill. <br>


## Reference(s): <br>
- [ClawHub release page](https://clawhub.ai/chrischall/creditkarma-mcp) <br>
- [npm package: creditkarma-mcp](https://www.npmjs.com/package/creditkarma-mcp) <br>
- [Source repository: creditkarma-mcp](https://github.com/chrischall/creditkarma-mcp) <br>
- [fetchproxy extension](https://github.com/chrischall/fetchproxy) <br>
- [Credit Karma](https://www.creditkarma.com) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON, bash, SQL, and MCP tool examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [The skill handles personal finance data, Credit Karma session cookies, and local SQLite transaction records.] <br>

## Skill Version(s): <br>
2.2.2 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
