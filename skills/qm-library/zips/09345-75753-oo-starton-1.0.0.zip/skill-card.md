## Description: <br>
Starton helps an agent manage Starton IPFS pins by listing, reading, creating, pinning existing CIDs, and deleting pins through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to manage Starton IPFS pins from an agent session without directly handling raw Starton credentials. It supports schema-first execution for read, create, pin, and delete workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires sensitive account credentials through an OOMOL-connected Starton account. <br>
Mitigation: Use only accounts and Starton connections that the user is comfortable delegating to the agent, and rely on OOMOL server-side credential handling instead of exposing raw tokens. <br>
Risk: Create and pin actions change Starton state, and delete actions can remove pins. <br>
Mitigation: Confirm the exact payload, target pin or CID, and intended effect with the user before running write or delete actions. <br>
Risk: First-time setup uses the oo CLI installer and account connection flow. <br>
Mitigation: Review the oo CLI installer before setup and only initiate authentication or connection steps after a command fails for that reason. <br>


## Reference(s): <br>
- [Starton homepage](https://starton.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-starton) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration, Guidance, JSON] <br>
**Output Format:** [Markdown with inline bash commands and JSON connector responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Responses include connector data and an execution id under meta.executionId when actions run successfully.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
