## Description: <br>
Docsumo (docsumo.com). Use this skill for Docsumo requests that read account and document data or upload public document URLs through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Employees, external users, and developers use this skill to operate Docsumo from an agent through an OOMOL-connected account. It supports account inspection, document listing and summaries, document metadata and extracted-data retrieval, and public URL uploads for selected document types. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access Docsumo account and document data through an OOMOL-connected account. <br>
Mitigation: Install it only when agent access to Docsumo is intended, and review the Docsumo connection scopes before use. <br>
Risk: Uploading a public document URL changes Docsumo state. <br>
Mitigation: Confirm the exact upload payload and intended effect with the user before running the upload action. <br>
Risk: First-time setup relies on installing or authenticating with OOMOL's oo CLI. <br>
Mitigation: Run setup commands only after an authentication or connection failure and only when the OOMOL CLI installation flow is trusted. <br>


## Reference(s): <br>
- [Docsumo homepage](https://www.docsumo.com) <br>
- [Docsumo skill on ClawHub](https://clawhub.ai/oomol/oo-docsumo) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payloads or responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before action execution; write actions require user confirmation.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
