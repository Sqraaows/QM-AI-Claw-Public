## Description: <br>
Operate a connected Sendbird account through OOMOL's oo CLI connector for user, channel, membership, message, moderation, unread-count, and session-token workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, operators, and support teams use this skill to inspect and manage Sendbird users, group channels, memberships, messages, moderation state, unread counts, and session tokens through a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can make broad Sendbird account changes, including write, moderation, token, and delete actions. <br>
Mitigation: Require explicit confirmation of the target, payload, and intended effect before running state-changing or destructive actions. <br>
Risk: Connector schemas and defaults can change upstream. <br>
Mitigation: Inspect the live action schema with the oo CLI before constructing each payload. <br>
Risk: The setup path may ask users to install and trust OOMOL's CLI and connector service. <br>
Mitigation: Use a reviewed or verified installation path and install only when the user trusts OOMOL with Sendbird account authority. <br>


## Reference(s): <br>
- [ClawHub Sendbird skill page](https://clawhub.ai/oomol/oo-sendbird) <br>
- [Sendbird homepage](https://sendbird.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Actions return JSON responses from the oo CLI with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
