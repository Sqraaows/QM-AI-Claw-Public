## Description: <br>
Massive (Polygon.io) (massive.com). Use this skill for Massive (Polygon.io) requests that search and read market data through the OOMOL connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and analysts use this skill to query Massive (Polygon.io) market data, inspect live connector schemas, and run read-only ticker, exchange, market-status, and OHLC bar actions through the oo CLI. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The fallback oo CLI installation path uses remote shell installers. <br>
Mitigation: Review the installer source or use an official install-guide or package-manager path before running it, especially in sensitive environments. <br>
Risk: The skill depends on OOMOL account authentication, a connected Massive (Polygon.io) API-key credential, and account credit. <br>
Mitigation: Run setup only after an auth, connection, scope, credential, or billing error, and avoid exposing raw API tokens locally. <br>
Risk: Connector schemas and upstream market-data fields can change. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-polygon-io) <br>
- [Massive (Polygon.io) homepage](https://massive.com/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance, JSON] <br>
**Output Format:** [Markdown guidance with shell commands and JSON command output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: SKILL.md frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
