## Description: <br>
Refiner (refiner.io). Use this skill for Refiner requests that read, create, update, or delete data through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate a connected Refiner workspace from an agent, including account lookup, contact workflows, forms, survey responses, segments, reporting, event tracking, and response tagging. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change connected Refiner workspace state through contact updates, event tracking, response tagging, and segment membership changes. <br>
Mitigation: Require explicit user confirmation of the target, payload, and intended effect before running write or destructive actions. <br>
Risk: The skill requires access to a connected OOMOL/Refiner account and uses sensitive credentials managed outside the skill files. <br>
Mitigation: Install and use it only for intended Refiner workspaces, keep authentication setup user-initiated, and review the oo CLI install step before execution. <br>
Risk: Connector input and output schemas may change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [Refiner homepage](https://refiner.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-refiner) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before building action payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: evidence release and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
