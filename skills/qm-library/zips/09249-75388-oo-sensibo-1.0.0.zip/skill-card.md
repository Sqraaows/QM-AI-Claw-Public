## Description: <br>
Sensibo lets an agent list and inspect Sensibo devices, read AC states, and set full AC state through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Sensibo devices from an agent after their OOMOL account is connected to Sensibo. It supports device discovery, device detail lookup, AC state reads, and confirmed AC state updates. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change the AC state of a Sensibo device. <br>
Mitigation: Confirm the exact device, payload, and intended effect with the user before running write actions. <br>
Risk: The skill depends on an OOMOL-connected Sensibo account and may require installing the oo CLI. <br>
Mitigation: Use it only when the user accepts OOMOL as the bridge to Sensibo, and run installer commands only from trusted OOMOL sources. <br>


## Reference(s): <br>
- [Sensibo homepage](https://home.sensibo.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-sensibo) <br>


## Skill Output: <br>
**Output Type(s):** [text, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are JSON objects containing data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence, artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
