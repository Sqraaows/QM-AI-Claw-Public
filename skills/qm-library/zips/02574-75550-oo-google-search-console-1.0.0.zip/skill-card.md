## Description: <br>
Operate Google Search Console through an OOMOL-connected account to read, query, inspect, create, and delete Search Console data. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Google Search Console for site property management, sitemap management, URL inspection, and search performance analytics through an OOMOL-connected account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Setup guidance includes running downloaded installer scripts directly in a shell. <br>
Mitigation: Review the installer path before use and prefer official, verifiable OOMOL CLI release instructions or a checksummed package. <br>
Risk: Write and delete actions can change or remove Google Search Console properties and sitemaps. <br>
Mitigation: Confirm the exact payload, target property, and intended effect with the user before running write or destructive actions. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-google-search-console) <br>
- [Google Search Console](https://search.google.com/search-console) <br>
- [OOMOL CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector action responses are JSON objects containing data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
