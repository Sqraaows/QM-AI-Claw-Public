## Description: <br>
CollegeFootballData helps agents inspect account status and retrieve college football conferences, teams, venues, games, and results through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, analysts, and agents use this skill to query CollegeFootballData for account status, conferences, teams, venues, games, and results without handling raw API tokens directly. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected CollegeFootballData API key and account login. <br>
Mitigation: Install and connect it only for intended CollegeFootballData use, and approve authentication or connection setup separately from routine read-only queries. <br>
Risk: First-time setup may involve a remote CLI installer and account login. <br>
Mitigation: Review and approve installer and login steps before execution; allow normal skill actions to run only after the CLI and connection are already configured. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-college-football-data) <br>
- [ClawHub publisher profile: oomol](https://clawhub.ai/user/oomol) <br>
- [CollegeFootballData homepage](https://collegefootballdata.com/) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with bash command examples and JSON connector payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live oo connector schemas before running read-only CollegeFootballData actions; command results are returned as JSON.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
