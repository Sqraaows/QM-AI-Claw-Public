## Description: <br>
TelTel (teltel.io) helps an agent operate a TelTel account through the OOMOL-connected `oo` CLI to check account balance, send SMS messages, and review SMS delivery reports. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to perform TelTel communication workflows from an agent after connecting TelTel through OOMOL. It supports account balance checks, outbound SMS sending, and SMS delivery report lookup or listing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can send SMS messages that change TelTel account state and may create cost or compliance impact. <br>
Mitigation: Confirm the exact recipient, message body, payload, and intended effect with the user before approving any send action. <br>
Risk: The skill requires access to an OOMOL-connected TelTel account. <br>
Mitigation: Install it only when that account access is intended, and revoke the OOMOL/TelTel connection when it is no longer needed. <br>
Risk: Connector input and output schemas can change upstream. <br>
Mitigation: Fetch the live `oo connector schema` for the TelTel action before constructing or running a payload. <br>


## Reference(s): <br>
- [ClawHub TelTel skill page](https://clawhub.ai/oomol/oo-teltel) <br>
- [TelTel homepage](https://www.teltel.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, json, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector responses are returned as JSON with data and meta.executionId fields.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
