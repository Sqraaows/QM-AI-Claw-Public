## Description: <br>
Creative toolkit for AI agents that uses the pixcli CLI to generate and edit images, videos, voiceovers, music, sound effects, podcasts, and Remotion-based video assemblies. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[cohnen](https://clawhub.ai/user/cohnen) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers, creative teams, and AI agents use this skill to produce production-ready creative assets from prompts, including images, edited images, video clips, audio, podcasts, and assembled Remotion videos. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Prompts and media are sent to pixcli's hosted service for processing. <br>
Mitigation: Use the skill only for content approved for external processing, and avoid secrets, regulated data, customer content, and internal-only URLs unless that use is approved. <br>
Risk: Podcast or publishing workflows can create public, persistent share pages. <br>
Mitigation: Choose --private or --no-publish before publishing unless the user explicitly asks for a public share page. <br>
Risk: Voice cloning can misuse a person's voice. <br>
Mitigation: Use voice cloning only with clear consent from the voice owner. <br>
Risk: The skill requires a paid-service API key. <br>
Mitigation: Store PIXCLI_API_KEY as a secret, do not expose it in generated files or logs, and verify billing expectations before long-running generation jobs. <br>


## Reference(s): <br>
- [Pixcli homepage](https://pixcli.shellbot.sh) <br>
- [ClawHub Pixcli Skill](https://clawhub.ai/cohnen/pixcli) <br>
- [npm pixcli package](https://www.npmjs.com/package/pixcli) <br>
- [Command Reference](references/command-reference.md) <br>
- [Prompt Cookbook](references/prompt-cookbook.md) <br>
- [Creative Guidelines](references/creative-guidelines.md) <br>
- [Remotion Playbook](references/remotion-playbook.md) <br>
- [Template Showcase](references/template-showcase.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, files, guidance] <br>
**Output Format:** [Markdown guidance with shell commands, JSON CLI output, configuration snippets, and generated asset files.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce media files such as images, SVGs, MP4 videos, MP3 audio, podcast assets, and Remotion project files.] <br>

## Skill Version(s): <br>
2.9.2 (source: release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
