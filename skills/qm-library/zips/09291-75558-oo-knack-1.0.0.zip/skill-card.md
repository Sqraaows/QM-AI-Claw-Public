## Description: <br>
Knack (knack.com). Use this skill for Knack requests that read, create, update, or delete records through an OOMOL-connected account. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to operate Knack records from an agent session through the OOMOL oo CLI. It supports record creation, retrieval, listing, updating, and deletion after the live connector schema is inspected. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can change or delete Knack records. <br>
Mitigation: Confirm exact payloads, target objects, and record IDs before create, update, or delete actions. <br>
Risk: The skill depends on an authenticated OOMOL oo CLI session and a connected Knack account. <br>
Mitigation: Install and sign in to the oo CLI only when needed, and connect Knack through the OOMOL connection flow before retrying failed authenticated actions. <br>
Risk: Connector schemas and field requirements can change upstream. <br>
Mitigation: Fetch the live connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Knack Skill](https://clawhub.ai/oomol/oo-knack) <br>
- [Knack Homepage](https://www.knack.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL Knack Connection](https://console.oomol.com/app-connections?provider=knack) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance, json] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON payloads or command responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires an installed, signed-in OOMOL oo CLI and a connected Knack account.] <br>

## Skill Version(s): <br>
1.0.0 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
