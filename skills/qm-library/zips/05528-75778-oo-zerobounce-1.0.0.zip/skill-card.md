## Description: <br>
ZeroBounce helps agents operate a ZeroBounce account through OOMOL to validate emails, inspect activity and API usage, check credit balance, and manage custom allow/block filter rules. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, developers, and marketing operations teams use this skill to perform ZeroBounce account actions from an agent while relying on live connector schemas before execution. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires a connected ZeroBounce account and sensitive credentials managed through OOMOL. <br>
Mitigation: Install only when ZeroBounce account operation is intended, keep credentials in the connected account flow, and avoid handling raw tokens in agent prompts. <br>
Risk: The first-time setup guidance includes pipe-to-shell installer commands for the OOMOL CLI. <br>
Mitigation: Verify the OOMOL CLI installer source before running installation commands. <br>
Risk: Creating or updating filter rules can change ZeroBounce account state. <br>
Mitigation: Review and approve the exact create or update payload and intended effect before allowing execution. <br>


## Reference(s): <br>
- [ZeroBounce homepage](https://www.zerobounce.net) <br>
- [ZeroBounce skill on ClawHub](https://clawhub.ai/oomol/oo-zerobounce) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [oo CLI install guide](https://cli.oomol.com/install-guide.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Connector commands return JSON responses containing data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
