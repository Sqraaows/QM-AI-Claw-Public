## Description: <br>
Handle approved login, identity, checkout, donation, subscription, payment pages, and typed action approvals through the magicpay CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[xor777](https://clawhub.ai/user/xor777) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use MagicPay to run approved browser-based product workflows that fill saved login, identity, checkout, donation, subscription, payment, and wallet-action data through the magicpay CLI while keeping protected values out of the model prompt. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: MagicPay can support consequential workflows such as payments, purchases, logins, identity submissions, wallet signing, and account changes. <br>
Mitigation: Require the matching typed MagicPay approval before any consequential action, and re-check visible facts such as amount, currency, recipient, message, or submitted identity data before proceeding. <br>
Risk: API keys, local MagicPay config, CDP endpoints, OTPs, and protected Memory values could be exposed through chat, logs, reports, or shared workspaces. <br>
Mitigation: Do not print, log, summarize, or share those values; keep Memory fill value-free in the model prompt, and ask the user to rotate or revoke credentials if the machine or workspace is shared or compromised. <br>
Risk: A saved fill plan can become stale after page navigation or dynamic form changes. <br>
Mitigation: Rerun plan-fill after meaningful page changes, apply only the active plan, refresh the browser state after fill, and never treat filled fields as approval to submit. <br>
Risk: CAPTCHA solving or browser attachment can expand authority if used outside the approved workflow. <br>
Mitigation: Use solve-captcha only for a confirmed CAPTCHA on the current browser child inside the active MagicPay workflow, and attach only to a private browser/session the user approved for the task. <br>


## Reference(s): <br>
- [MagicPay ClawHub skill page](https://clawhub.ai/xor777/magicpay) <br>
- [MagicPay OpenClaw marketplace README](https://github.com/MercuryoAI/skills/blob/main/docs/magicpay/openclaw/marketplace/README.md) <br>
- [MagicPay CLI npm package](https://www.npmjs.com/package/@mercuryo-ai/magicpay-cli) <br>
- [MagicPay command guide](references/commands.md) <br>
- [MagicPay guardrails](references/guardrails.md) <br>
- [MagicPay result states](references/statuses.md) <br>
- [MagicPay operating guide](references/workflow.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON-output branching rules] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses value-free Memory refs and approval workflows; protected values, OTPs, API keys, and CDP endpoints should not be printed or included in prompts.] <br>

## Skill Version(s): <br>
0.1.36 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
