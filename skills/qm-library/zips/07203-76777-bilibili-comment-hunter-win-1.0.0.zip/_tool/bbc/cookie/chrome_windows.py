"""Chrome / Edge cookie extraction on Windows.

Uses:
- sqlite3 (stdlib) to read the Cookies DB
- PowerShell + .NET ProtectedData.Unprotect (DPAPI) to decrypt cookie values

Zero pip install. Windows-only (Vista+). DPAPI is user-bound — works
as long as the current Windows user is the same one who logged into B站.

Similar patterns:
- chrome_macos.py uses Keychain + openssl (macOS)
- chrome_windows.py uses DPAPI + PowerShell (Windows)
"""

import base64
import glob
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

# ---- Browser profile paths ----

_CHROME_BROWSERS = {
    "chrome": {
        "names": ("Google", "Chrome"),
        "env": "LOCALAPPDATA",
    },
    "edge": {
        "names": ("Microsoft", "Edge"),
        "env": "LOCALAPPDATA",
    },
    "chromium": {
        "names": ("Chromium", "Chromium"),
        "env": "LOCALAPPDATA",
    },
    "sogou": {
        "names": ("Sogou", "Sogou"),
        "env": "APPDATA",
    },
}


def _profile_paths(browser: str) -> list[Path]:
    """Find candidate Cookies DB files for the given Chromium browser."""
    if browser not in _CHROME_BROWSERS:
        return []

    info = _CHROME_BROWSERS[browser]
    company, name = info["names"]
    base_env = os.environ.get(info["env"], "")
    if not base_env:
        return []

    base = Path(base_env) / company / name / "User Data"
    if not base.exists():
        return []

    results = []
    for prof in ["Default"] + sorted(glob.glob(str(base / "Profile *"))):
        p = base / prof if isinstance(prof, str) else Path(prof)
        if not p.is_dir():
            continue
        # Chrome >= ~96 stores Cookies under Network/
        for candidate in [p / "Network" / "Cookies", p / "Cookies"]:
            if candidate.exists():
                results.append(candidate)
                break
    return results


# ---- DPAPI decryption via PowerShell ----

# PowerShell one-liner that:
# 1. Reads a base64-encoded ciphertext blob
# 2. Calls [System.Security.Cryptography.ProtectedData]::Unprotect()
# 3. Outputs base64-encoded plaintext
#
# We use base64 as the IPC medium to avoid encoding grief.
_PS_DECRYPT_TEMPLATE = """\
$bytes = [Convert]::FromBase64String('{cipher_b64}')
$plain = [System.Security.Cryptography.ProtectedData]::Unprotect(
    $bytes, $null,
    [System.Security.Cryptography.DataProtectionScope]::CurrentUser
)
[Convert]::ToBase64String($plain)
"""


def _decrypt_value(encrypted: bytes) -> Optional[str]:
    """Decrypt a Chrome v10/v11 DPAPI-encrypted cookie value.

    Returns the plaintext string or None on any failure.
    """
    if not encrypted:
        return None

    # Chrome version prefix: v10 or v11
    if encrypted[:3] in (b"v10", b"v11"):
        body = encrypted[3:]
    else:
        # Possibly legacy plaintext (unlikely on Windows Chrome)
        try:
            return encrypted.decode("utf-8")
        except UnicodeDecodeError:
            return None

    if not body:
        return None

    try:
        cipher_b64 = base64.b64encode(body).decode("ascii")
    except Exception:
        return None

    ps_script = _PS_DECRYPT_TEMPLATE.format(cipher_b64=cipher_b64)

    try:
        proc = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy", "Bypass",
                "-Command", ps_script,
            ],
            capture_output=True,
            text=True,
            timeout=10,
            # Prevent PowerShell from popping up a window
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None

    if proc.returncode != 0:
        return None

    plain_b64 = proc.stdout.strip()
    if not plain_b64:
        return None

    try:
        plain = base64.b64decode(plain_b64)
        return plain.decode("utf-8", errors="ignore").rstrip("\x00")
    except Exception:
        return None


# ---- Main extract function ----

def extract(browser: str = "chrome", domain_filter: str = "bilibili.com") -> dict[str, str] | None:
    """Extract B站 cookies from Chrome/Edge on Windows.

    Args:
        browser: One of 'chrome', 'edge', 'chromium', 'sogou'.
        domain_filter: SQL LIKE pattern for host_key matching.

    Returns:
        Dict of cookie name -> value, or None if no valid session found.
    """
    if sys.platform != "win32":
        return None

    for db_path in _profile_paths(browser):
        try:
            with tempfile.NamedTemporaryFile(
                prefix="bbc-chrome-", suffix=".db", delete=False
            ) as tf:
                tmp = Path(tf.name)
            shutil.copy2(db_path, tmp)
            try:
                conn = sqlite3.connect(f"file:{tmp}?mode=ro", uri=True)
                cur = conn.execute(
                    "SELECT name, value, encrypted_value FROM cookies WHERE host_key LIKE ?",
                    (f"%{domain_filter}%",),
                )
                cookies: dict[str, str] = {}
                for name, value, enc in cur.fetchall():
                    if value:
                        cookies[name] = value
                    elif enc:
                        dec = _decrypt_value(bytes(enc))
                        if dec is not None:
                            cookies[name] = dec
                conn.close()
            finally:
                try:
                    tmp.unlink()
                except OSError:
                    pass
            if cookies.get("SESSDATA"):
                return cookies
        except sqlite3.DatabaseError:
            continue
    return None
