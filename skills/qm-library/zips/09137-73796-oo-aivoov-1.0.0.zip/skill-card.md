## Description: <br>
AiVOOV operates an OOMOL-connected AiVOOV account to list voices and generate base64 audio from voice/text segments. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to interact with AiVOOV through the OOMOL oo CLI, including listing available voices and creating audio from requested voice/text segments. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected AiVOOV account and uses sensitive credentials managed outside the skill. <br>
Mitigation: Confirm the user trusts the OOMOL oo CLI and has connected AiVOOV; do not request or expose raw credentials. <br>
Risk: Generating audio can consume AiVOOV or OOMOL service credits and create external service output. <br>
Mitigation: Review the exact create_audio payload and intended effect with the user before running the write action. <br>
Risk: Connector schemas can change upstream, causing stale payload assumptions. <br>
Mitigation: Fetch the live `oo connector schema` for the selected action before constructing or submitting a payload. <br>


## Reference(s): <br>
- [ClawHub AiVOOV release](https://clawhub.ai/oomol/oo-aivoov) <br>
- [AiVOOV homepage](https://aivoov.com) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Fetches the live connector schema before action execution; create_audio can produce base64 audio in the connector response.] <br>

## Skill Version(s): <br>
1.0.0 (source: server evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
