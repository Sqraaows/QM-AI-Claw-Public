## Description: <br>
Use when designing or reviewing React + TypeScript project structure, feature/module boundaries, component architecture, hooks organization, routing composition, state/API/error/styling defaults, or repository-wide React conventions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[bovinphang](https://clawhub.ai/user/bovinphang) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineering agents use this skill to plan, implement, or review React and TypeScript project structure, module boundaries, component architecture, hooks organization, routing, state ownership, API integration shape, error handling, styling defaults, and repository-wide conventions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated architecture guidance can be applied too broadly or conflict with existing repository conventions. <br>
Mitigation: Review proposed structure and file moves against the current repository conventions before applying changes. <br>
Risk: The security evidence notes that related maintainer workflows may expose full-access nested review behavior. <br>
Mitigation: Use the documented no-yolo option or normal sandbox prompts when invoking any review helper that can run nested agent commands. <br>


## Reference(s): <br>
- [React Project Details](references/react-project-details.md) <br>
- [ClawHub Skill Page](https://clawhub.ai/bovinphang/fec-react-project-standard) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, shell commands, configuration] <br>
**Output Format:** [Markdown guidance with code, shell command, and configuration examples when needed] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Guidance should preserve existing repository conventions, prefer focused specialty workflows for deeper areas, and include concrete file-structure recommendations when relevant.] <br>

## Skill Version(s): <br>
2.4.0 (source: server release evidence, package.json, metadata.json, README.md) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
