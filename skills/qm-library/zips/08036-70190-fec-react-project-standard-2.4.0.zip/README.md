# React 项目规范

Frontend Craft skill for React 项目规范.

## Skill

- ID: `fec-react-project-standard`
- Category: `project-standard`
- Version: `2.4.0`
- Source: `skills/fec-react-project-standard/SKILL.md`

## Description

Use when designing or reviewing React + TypeScript project structure, feature/module boundaries, component architecture, hooks organization, routing composition, state/API/error/styling defaults, or repository-wide React conventions. Prefer narrower skills for forms, data fetching, tests, accessibility, virtualization, animation, or security deep dives; Chinese triggers include React 项目规范, React 组件架构.

## Usage

Install or import this package with any skill runtime that understands the standard `SKILL.md` layout. The canonical source remains the Frontend Craft repository.

## Packaged Files

- [references/react-project-details.md](references/react-project-details.md)

## Optional Related Packages

- `@frontend-craft/fec-typescript-type-safety`
- `@frontend-craft/fec-state-management`
- `@frontend-craft/fec-tailwind-design-system`
- `@frontend-craft/fec-responsive-layout`
- `@frontend-craft/fec-form-handling`
- `@frontend-craft/fec-data-fetching`
- `@frontend-craft/fec-component-testing`
- `@frontend-craft/fec-e2e-testing`
- `@frontend-craft/fec-accessibility-check`
- `@frontend-craft/fec-security-review`
- `@frontend-craft/fec-list-virtualization`
- `@frontend-craft/fec-svg-animation`
- `@frontend-craft/fec-canvas-threejs`
- `@frontend-craft/fec-api-integration`
- `@frontend-craft/fec-motion-interaction`

## License

MIT
