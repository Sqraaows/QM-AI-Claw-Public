#!/usr/bin/env python3
"""Safely back up and restore selected WorkBuddy memory files via any Git remote.

This script is intentionally whitelist-based. It never copies the whole
~/.workbuddy directory and never restores without an explicit --yes flag.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

HOME_WORKBUDDY = Path(os.environ.get("WORKBUDDY_HOME", str(Path.home() / ".workbuddy"))).expanduser().resolve()
CONFIG_PATH = HOME_WORKBUDDY / "git-memory-sync.json"
DEFAULT_REPO_DIR = Path.home() / "workbuddy-memory-backup"
MANIFEST_NAME = "manifest.json"

USER_MEMORY_FILES = ["MEMORY.md", "USER.md", "IDENTITY.md", "SOUL.md"]
CLOUD_MEMORY_DIR = HOME_WORKBUDDY / "memory"
BACKUP_DIR_NAMES = ["user-memory", "cloud-memory", "workspace-memory"]

EXCLUDE_DIR_NAMES = {
    ".git",
    "node_modules",
    "__pycache__",
    "artifact-index",
    "blobs",
    "logs",
    "sessions",
    "traces",
    "plugin-marketplace-state-new",
    "plugin-marketplace-state",
}
EXCLUDE_FILE_SUFFIXES = {
    ".db",
    ".db-shm",
    ".db-wal",
    ".sqlite",
    ".sqlite3",
    ".log",
    ".token",
    ".key",
    ".pem",
    ".crt",
    ".p12",
    ".pfx",
}
EXCLUDE_FILE_NAMES = {
    ".neodata_token",
    "mcp.json",
    ".mcp.json",
    "settings.json",
    "settings.local.json",
    "workbuddy.db",
    "workbuddy.db-shm",
    "workbuddy.db-wal",
}


def now_iso() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


def normalize_path(value: str | Path | None) -> Path | None:
    if value is None or str(value).strip() == "":
        return None
    return Path(str(value)).expanduser().resolve()


def is_relative_to(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def safe_remove_tree(target: Path, repo_dir: Path) -> None:
    target = target.resolve()
    repo_dir = repo_dir.resolve()
    if not is_relative_to(target, repo_dir):
        raise RuntimeError(f"Refusing to remove path outside repo_dir: {target}")
    if target == repo_dir:
        raise RuntimeError(f"Refusing to remove repo_dir itself: {target}")
    if target.name not in BACKUP_DIR_NAMES:
        raise RuntimeError(f"Refusing to remove unexpected backup directory: {target}")
    if target.exists():
        shutil.rmtree(target)


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, capture_output=True)
    if check and proc.returncode != 0:
        raise RuntimeError(
            f"Command failed: {' '.join(cmd)}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
        )
    return proc


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def should_skip_file(path: Path) -> bool:
    if path.name in EXCLUDE_FILE_NAMES:
        return True
    if path.suffix in EXCLUDE_FILE_SUFFIXES:
        return True
    return bool(set(path.parts) & EXCLUDE_DIR_NAMES)


def load_config(config_path: Path = CONFIG_PATH) -> dict[str, Any]:
    if not config_path.exists():
        return {}
    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Invalid config JSON: {config_path}: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeError(f"Config must be a JSON object: {config_path}")
    return data


def write_config(config: dict[str, Any], config_path: Path = CONFIG_PATH) -> None:
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config["updated_at"] = now_iso()
    config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def resolve_settings(args: argparse.Namespace) -> dict[str, Any]:
    config = load_config()
    repo_url = args.repo_url if getattr(args, "repo_url", None) else config.get("repo_url")
    repo_dir = normalize_path(args.repo_dir or config.get("repo_dir") or DEFAULT_REPO_DIR)
    branch = args.branch or config.get("branch")
    workspace_roots_raw = list(config.get("workspace_roots", []))
    if getattr(args, "workspace_root", None):
        workspace_roots_raw.extend(args.workspace_root)
    workspace_roots = [p for p in (normalize_path(x) for x in workspace_roots_raw) if p]
    include_workspace_default = bool(config.get("include_workspace_by_default", False))
    include_workspace = bool(getattr(args, "include_workspace", False) or include_workspace_default)
    return {
        "config": config,
        "repo_url": repo_url,
        "repo_dir": repo_dir,
        "branch": branch,
        "workspace_roots": workspace_roots,
        "include_workspace": include_workspace,
    }


def configure(args: argparse.Namespace) -> None:
    existing = load_config()
    config = dict(existing)
    if args.repo_url:
        config["repo_url"] = args.repo_url
    if args.repo_dir:
        config["repo_dir"] = str(normalize_path(args.repo_dir))
    elif "repo_dir" not in config:
        config["repo_dir"] = str(DEFAULT_REPO_DIR)
    if args.branch:
        config["branch"] = args.branch
    elif "branch" not in config:
        config["branch"] = ""
    if args.workspace_root is not None:
        config["workspace_roots"] = [str(normalize_path(x)) for x in args.workspace_root]
    elif "workspace_roots" not in config:
        config["workspace_roots"] = []
    if args.include_workspace_by_default is not None:
        config["include_workspace_by_default"] = args.include_workspace_by_default
    elif "include_workspace_by_default" not in config:
        config["include_workspace_by_default"] = False
    config["version"] = 1
    write_config(config)
    print(f"OK: config saved to {CONFIG_PATH}")
    print(json.dumps(config, ensure_ascii=False, indent=2))


def require_repo_url(repo_url: str | None) -> str:
    if not repo_url:
        raise RuntimeError(
            "Missing repo_url. Run configure --repo-url <git-remote-url>, "
            "or pass --repo-url on this command."
        )
    return repo_url


def ensure_repo(repo_dir: Path, repo_url: str | None, allow_clone: bool) -> None:
    if repo_dir.exists():
        if not (repo_dir / ".git").exists():
            raise RuntimeError(f"Repo dir exists but is not a git repository: {repo_dir}")
        if repo_url:
            remote = run(["git", "remote", "get-url", "origin"], cwd=repo_dir, check=False)
            if remote.returncode != 0:
                run(["git", "remote", "add", "origin", repo_url], cwd=repo_dir)
        return
    if not allow_clone:
        raise RuntimeError(
            f"Repo dir does not exist: {repo_dir}\n"
            "Run init --allow-clone after configure, or clone/create the Git repo first."
        )
    repo_url = require_repo_url(repo_url)
    repo_dir.parent.mkdir(parents=True, exist_ok=True)
    run(["git", "clone", repo_url, str(repo_dir)], check=True)


def current_branch(repo_dir: Path) -> str:
    branch = run(["git", "branch", "--show-current"], cwd=repo_dir, check=False).stdout.strip()
    return branch


def effective_branch(repo_dir: Path, configured_branch: str | None) -> str:
    branch = (configured_branch or "").strip() or current_branch(repo_dir)
    if not branch:
        raise RuntimeError("Cannot determine Git branch. Configure --branch or checkout a branch in the repo.")
    return branch


def git_identity_ok(repo_dir: Path) -> bool:
    name = run(["git", "config", "user.name"], cwd=repo_dir, check=False)
    email = run(["git", "config", "user.email"], cwd=repo_dir, check=False)
    return bool(name.stdout.strip() and email.stdout.strip())


def init_repo(args: argparse.Namespace) -> None:
    s = resolve_settings(args)
    repo_dir: Path = s["repo_dir"]
    repo_url: str | None = s["repo_url"]
    ensure_repo(repo_dir, repo_url, args.allow_clone)
    for name in BACKUP_DIR_NAMES:
        (repo_dir / name).mkdir(exist_ok=True)
    remote = run(["git", "remote", "get-url", "origin"], cwd=repo_dir, check=False).stdout.strip()
    branch = current_branch(repo_dir)
    print(f"OK: repo ready at {repo_dir}")
    print(f"Remote: {remote or '(none)'}")
    print(f"Branch: {branch or '(unknown)'}")


def collect_sources(include_workspace: bool, workspace_roots: list[Path]) -> list[tuple[Path, Path]]:
    pairs: list[tuple[Path, Path]] = []
    for name in USER_MEMORY_FILES:
        src = HOME_WORKBUDDY / name
        if src.exists() and not should_skip_file(src):
            pairs.append((src, Path("user-memory") / name))

    if CLOUD_MEMORY_DIR.exists():
        for src in sorted(CLOUD_MEMORY_DIR.rglob("*")):
            if src.is_file() and not should_skip_file(src):
                pairs.append((src, Path("cloud-memory") / src.relative_to(CLOUD_MEMORY_DIR)))

    if include_workspace:
        for root in workspace_roots:
            if not root.exists():
                print(f"WARN: workspace root does not exist, skipped: {root}")
                continue
            for memory_dir in sorted(root.glob("*/.workbuddy/memory")):
                workspace_name = memory_dir.parent.parent.name
                for src in sorted(memory_dir.rglob("*")):
                    if src.is_file() and not should_skip_file(src):
                        rel = Path("workspace-memory") / workspace_name / src.relative_to(memory_dir)
                        pairs.append((src, rel))
    return pairs


def clean_backup_dirs(repo_dir: Path, include_workspace: bool) -> None:
    targets = [repo_dir / "user-memory", repo_dir / "cloud-memory"]
    if include_workspace:
        targets.append(repo_dir / "workspace-memory")
    for target in targets:
        safe_remove_tree(target, repo_dir)
        target.mkdir(parents=True, exist_ok=True)


def pull_if_requested(repo_dir: Path, branch: str, should_pull: bool) -> None:
    if should_pull:
        run(["git", "pull", "--ff-only", "origin", branch], cwd=repo_dir, check=False)


def backup(args: argparse.Namespace) -> None:
    s = resolve_settings(args)
    repo_dir: Path = s["repo_dir"]
    repo_url: str | None = s["repo_url"]
    include_workspace: bool = s["include_workspace"]
    workspace_roots: list[Path] = s["workspace_roots"]
    ensure_repo(repo_dir, repo_url, args.allow_clone)
    branch = effective_branch(repo_dir, s["branch"])
    if include_workspace and not workspace_roots:
        raise RuntimeError("--include-workspace requires at least one --workspace-root or configured workspace_roots.")
    if not git_identity_ok(repo_dir):
        print("WARN: git user.name/user.email is not configured for this repo; commit may fail.")
    pull_if_requested(repo_dir, branch, args.pull)

    sources = collect_sources(include_workspace, workspace_roots)
    clean_backup_dirs(repo_dir, include_workspace)
    manifest = {
        "created_at": now_iso(),
        "host": os.uname().nodename if hasattr(os, "uname") else "unknown",
        "tool": "git-memory-sync",
        "version": 1,
        "include_workspace": include_workspace,
        "workspace_roots": [str(x) for x in workspace_roots],
        "files": [],
    }
    for src, rel in sources:
        dst = repo_dir / rel
        if not is_relative_to(dst, repo_dir):
            raise RuntimeError(f"Refusing to write outside repo_dir: {dst}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        manifest["files"].append({
            "source": str(src),
            "backup_path": str(rel),
            "size": src.stat().st_size,
            "sha256": sha256(src),
        })

    (repo_dir / MANIFEST_NAME).write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    status = run(["git", "status", "--short"], cwd=repo_dir, check=False).stdout.strip()
    if not status:
        print("OK: no changes to backup.")
        print(f"Files considered: {len(sources)}")
        return
    run(["git", "add", "user-memory", "cloud-memory", MANIFEST_NAME], cwd=repo_dir)
    if include_workspace:
        run(["git", "add", "workspace-memory"], cwd=repo_dir)
    commit_msg = args.message or f"Backup WorkBuddy memory {dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    run(["git", "commit", "-m", commit_msg], cwd=repo_dir)
    if args.push:
        run(["git", "push", "origin", branch], cwd=repo_dir)
    print(f"OK: backed up {len(sources)} files to {repo_dir}" + (" and pushed." if args.push else "."))


def restore_targets(repo_dir: Path, include_workspace: bool, workspace_roots: list[Path]) -> list[tuple[Path, Path]]:
    restore_pairs: list[tuple[Path, Path]] = []
    for name in USER_MEMORY_FILES:
        src = repo_dir / "user-memory" / name
        if src.exists() and not should_skip_file(src):
            restore_pairs.append((src, HOME_WORKBUDDY / name))

    cloud_dir = repo_dir / "cloud-memory"
    if cloud_dir.exists():
        for src in sorted(cloud_dir.rglob("*")):
            if src.is_file() and not should_skip_file(src):
                restore_pairs.append((src, CLOUD_MEMORY_DIR / src.relative_to(cloud_dir)))

    workspace_dir = repo_dir / "workspace-memory"
    if include_workspace and workspace_dir.exists():
        if not workspace_roots:
            raise RuntimeError("Workspace restore requires configured workspace_roots or --workspace-root.")
        primary_root = workspace_roots[0]
        for src in sorted(workspace_dir.rglob("*")):
            if src.is_file() and not should_skip_file(src):
                rel = src.relative_to(workspace_dir)
                if len(rel.parts) < 2:
                    continue
                workspace_name = rel.parts[0]
                inner = Path(*rel.parts[1:])
                dst = primary_root / workspace_name / ".workbuddy" / "memory" / inner
                restore_pairs.append((src, dst))
    return restore_pairs


def snapshot_existing(paths: list[Path]) -> Path:
    snapshot = HOME_WORKBUDDY / "backups" / ("pre-memory-restore-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S"))
    snapshot.mkdir(parents=True, exist_ok=True)
    for dst in paths:
        if dst.exists():
            rel = dst.relative_to(Path.home()) if is_relative_to(dst, Path.home()) else Path(dst.name)
            snap_dst = snapshot / rel
            snap_dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, snap_dst)
    return snapshot


def restore(args: argparse.Namespace) -> None:
    s = resolve_settings(args)
    repo_dir: Path = s["repo_dir"]
    if not (repo_dir / ".git").exists():
        raise RuntimeError(f"Not a git repository: {repo_dir}")
    branch = effective_branch(repo_dir, s["branch"])
    pull_if_requested(repo_dir, branch, args.pull)
    restore_pairs = restore_targets(repo_dir, s["include_workspace"], s["workspace_roots"])

    print("Files to restore:")
    for src, dst in restore_pairs:
        print(f"- {src} -> {dst}")
    if not args.yes:
        raise RuntimeError("Restore is dry-run by default. Re-run with --yes to write files.")

    snapshot = snapshot_existing([dst for _, dst in restore_pairs])
    for src, dst in restore_pairs:
        if not (is_relative_to(dst, HOME_WORKBUDDY) or any(is_relative_to(dst, root) for root in s["workspace_roots"])):
            raise RuntimeError(f"Refusing to restore outside configured memory locations: {dst}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    print(f"OK: restored {len(restore_pairs)} files. Previous versions backed up at {snapshot}")


def status(args: argparse.Namespace) -> None:
    s = resolve_settings(args)
    repo_dir: Path = s["repo_dir"]
    print(f"Config path: {CONFIG_PATH}")
    print(f"Config exists: {CONFIG_PATH.exists()}")
    print(f"Repo dir: {repo_dir}")
    print(f"Repo exists: {repo_dir.exists()}")
    print(f"Configured remote: {s['repo_url'] or '(none)'}")
    print(f"Configured branch: {s['branch'] or '(auto-detect)'}")
    print(f"Include workspace: {s['include_workspace']}")
    print("Workspace roots: " + (", ".join(str(x) for x in s["workspace_roots"]) or "(none)"))
    if (repo_dir / ".git").exists():
        remote = run(["git", "remote", "get-url", "origin"], cwd=repo_dir, check=False).stdout.strip()
        branch = current_branch(repo_dir)
        stat = run(["git", "status", "--short"], cwd=repo_dir, check=False).stdout.strip()
        last = run(["git", "log", "-1", "--oneline"], cwd=repo_dir, check=False).stdout.strip()
        print(f"Repo remote: {remote or '(none)'}")
        print(f"Repo branch: {branch or '(unknown)'}")
        print(f"Last commit: {last or '(none)'}")
        print("Working tree: " + ("clean" if not stat else "dirty"))
        if stat:
            print(stat)
    manifest = repo_dir / MANIFEST_NAME
    if manifest.exists():
        data = json.loads(manifest.read_text(encoding="utf-8"))
        print(f"Manifest time: {data.get('created_at')}")
        print(f"Manifest files: {len(data.get('files', []))}")


def doctor(args: argparse.Namespace) -> None:
    s = resolve_settings(args)
    repo_dir: Path = s["repo_dir"]
    print("Doctor checks:")
    print(f"- WorkBuddy home exists: {HOME_WORKBUDDY.exists()} ({HOME_WORKBUDDY})")
    print(f"- Config exists: {CONFIG_PATH.exists()} ({CONFIG_PATH})")
    print(f"- Repo dir configured: {repo_dir}")
    print(f"- Repo dir is git repo: {(repo_dir / '.git').exists()}")
    print(f"- Remote configured: {bool(s['repo_url'])}")
    print(f"- Branch configured/auto: {s['branch'] or '(auto-detect after repo exists)'}")
    if s["include_workspace"]:
        print(f"- Workspace roots configured: {bool(s['workspace_roots'])}")
        for root in s["workspace_roots"]:
            print(f"  - {root}: exists={root.exists()}")
    if (repo_dir / ".git").exists():
        print(f"- Git identity configured: {git_identity_ok(repo_dir)}")
    print("OK: doctor completed.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Backup/restore WorkBuddy memory with any Git remote.")
    sub = parser.add_subparsers(dest="command", required=True)

    def common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--repo-dir", help="Local backup git repo path. Defaults to config or ~/workbuddy-memory-backup.")
        p.add_argument("--repo-url", help="Remote git URL, e.g. Gitee/GitHub/GitLab/SSH URL.")
        p.add_argument("--branch", help="Git branch to pull/push. Defaults to config or current branch.")
        p.add_argument("--workspace-root", action="append", help="Root containing WorkBuddy workspaces. Can be repeated.")
        p.add_argument("--include-workspace", action="store_true", help="Also sync workspace .workbuddy/memory folders.")

    p = sub.add_parser("configure", help="Save default repo/branch/workspace settings.")
    p.add_argument("--repo-url", help="Remote git URL, e.g. Gitee/GitHub/GitLab/SSH URL.")
    p.add_argument("--repo-dir", help="Local backup git repo path.")
    p.add_argument("--branch", help="Git branch, e.g. main or master. Empty means auto-detect.")
    p.add_argument("--workspace-root", action="append", help="Root containing WorkBuddy workspaces. Can be repeated.")
    p.add_argument("--include-workspace-by-default", action=argparse.BooleanOptionalAction, default=None)
    p.set_defaults(func=configure)

    p = sub.add_parser("init", help="Initialize or verify the local backup git repo.")
    common(p)
    p.add_argument("--allow-clone", action="store_true", help="Allow cloning repo if repo-dir is missing.")
    p.set_defaults(func=init_repo)

    p = sub.add_parser("backup", help="Copy whitelisted memory files into repo and commit.")
    common(p)
    p.add_argument("--allow-clone", action="store_true", help="Allow cloning repo if repo-dir is missing.")
    p.add_argument("--pull", action="store_true", help="Pull before backup.")
    p.add_argument("--push", action="store_true", help="Push after backup.")
    p.add_argument("--message", help="Commit message for backup.")
    p.set_defaults(func=backup)

    p = sub.add_parser("restore", help="Restore memory files from repo. Dry-run unless --yes is passed.")
    common(p)
    p.add_argument("--pull", action="store_true", help="Pull before restore.")
    p.add_argument("--yes", action="store_true", help="Confirm restore writes and overwrites local memory files.")
    p.set_defaults(func=restore)

    p = sub.add_parser("status", help="Show config and backup repo status.")
    common(p)
    p.set_defaults(func=status)

    p = sub.add_parser("doctor", help="Run non-destructive health checks.")
    common(p)
    p.set_defaults(func=doctor)

    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        args.func(args)
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
