## Description: <br>
Helps agents query the VirusTotal Public API v3 to scan or look up files, URLs, domains, and IP addresses for malware and reputation analysis. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[arf0nz0](https://clawhub.ai/user/arf0nz0) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and security analysts use this skill to perform VirusTotal checks from an agent while keeping API-key handling, privacy warnings, and explicit confirmation steps visible before data is submitted. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Review before execution as proposals could introduce incorrect or misleading guidance into skills. <br>
Mitigation: Review and scan skill before deployment. <br>

## Reference(s): <br>
- [VirusTotal Public API v3 documentation](https://docs.virustotal.com/reference/overview) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON response examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires a VirusTotal API key and explicit user confirmation before submitting files, URLs, domains, or IP addresses.] <br>

## Skill Version(s): <br>
1.0.1 (source: frontmatter and server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
