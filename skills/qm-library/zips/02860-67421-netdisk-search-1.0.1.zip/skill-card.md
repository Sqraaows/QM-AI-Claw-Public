## Description: <br>
Searches net-disk resources across Baidu, Quark, Aliyun, 115, and other providers through a configurable search API, with keyword filters, link checking, and Docker deployment guidance. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[godzx001-dot](https://clawhub.ai/user/godzx001-dot) <br>

### License/Terms of Use: <br>
MIT <br>


## Use Case: <br>
Developers and agent users use this skill to search and validate shared cloud-storage resources through a self-hosted or configured net-disk search API. It can also help deploy the supporting service with Docker when a local service is needed. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can deploy a persistent network service for net-disk search. <br>
Mitigation: Deploy only when you intend to run a self-hosted search service, review the Docker image source, bind it to localhost or protect it with a firewall, and enable authentication. <br>
Risk: Search terms, share links, and passwords may be sent to the configured API endpoint. <br>
Mitigation: Use trusted API endpoints and avoid submitting sensitive search terms, private share links, or important passwords to remote services. <br>
Risk: The deployment script prints authentication details when authentication is enabled. <br>
Mitigation: Use a dedicated credential for this service, avoid reusing important passwords, and rotate exposed credentials after setup if needed. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/godzx001-dot/netdisk-search) <br>
- [NetDisk Search API Reference](references/api-reference.md) <br>
- [PanSou Upstream Project](https://github.com/fish2018/pansou) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, JSON, Shell commands, Configuration guidance] <br>
**Output Format:** [Terminal text, JSON, Markdown tables, and bash commands.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Search and link-check outputs may include resource titles, provider links, extraction passwords, source labels, dates, and validity status.] <br>

## Skill Version(s): <br>
1.0.1 (source: release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
