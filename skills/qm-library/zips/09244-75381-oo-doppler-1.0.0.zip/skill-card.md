## Description: <br>
Doppler helps an agent read, create, update, and delete Doppler projects, environments, configs, secrets, service tokens, syncs, integrations, and change requests through the OOMOL `oo` CLI connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and operators use this skill to manage Doppler-backed secrets and configuration workflows from an agent session through a connected OOMOL account. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can access and manage sensitive Doppler secrets and service tokens. <br>
Mitigation: Use only Doppler accounts and scopes appropriate for agent access, and avoid printing raw secrets into chat or logs. <br>
Risk: Secret export, secret read, token creation, lease issuance, approvals, clones, and deletion can expose data or change production state. <br>
Mitigation: Require explicit user confirmation for these actions, including the exact target, payload, and intended effect before execution. <br>
Risk: The security summary flags broad secret-management authority with incomplete warnings around secret export and some state-changing actions. <br>
Mitigation: Review the skill before installing and apply least-privilege Doppler scopes for the connected account. <br>


## Reference(s): <br>
- [Doppler homepage](https://www.doppler.com) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-doppler) <br>
- [OOMOL publisher profile](https://clawhub.ai/user/oomol) <br>


## Skill Output: <br>
**Output Type(s):** [Shell commands, Configuration instructions, API Calls, Markdown, Guidance] <br>
**Output Format:** [Markdown with inline bash commands and JSON payloads] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Uses live connector schemas before constructing action payloads; connector responses are JSON objects with data and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
