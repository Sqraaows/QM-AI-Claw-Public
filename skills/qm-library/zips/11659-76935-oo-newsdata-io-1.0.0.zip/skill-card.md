## Description: <br>
NewsData.io (newsdata.io). Use this skill for searching and reading latest news, cryptocurrency news, news sources, and archived news through the OOMOL NewsData.io connector. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to retrieve public NewsData.io content through an OOMOL-connected account, including latest headlines, crypto-focused articles, source discovery, and historical archive searches. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may require installing the oo CLI before use. <br>
Mitigation: Review OOMOL's install instructions or use a trusted package source before running the optional installer. <br>
Risk: The skill uses a connected NewsData.io credential through OOMOL. <br>
Mitigation: Connect only the NewsData.io credentials you are comfortable using through OOMOL and avoid repeating authentication setup unless a command fails for that reason. <br>
Risk: Connector fields and defaults can change upstream. <br>
Mitigation: Fetch the live connector schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/oomol/oo-newsdata-io) <br>
- [Publisher Profile](https://clawhub.ai/user/oomol) <br>
- [NewsData.io Homepage](https://newsdata.io) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [OOMOL CLI Install Guide](https://cli.oomol.com/install-guide.md) <br>
- [get_latest_news Action Reference](actions/get_latest_news.md) <br>
- [list_crypto_news Action Reference](actions/list_crypto_news.md) <br>
- [list_news_sources Action Reference](actions/list_news_sources.md) <br>
- [search_news_archive Action Reference](actions/search_news_archive.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with oo CLI shell commands and JSON API responses] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are JSON objects containing data and meta.executionId; live connector schemas should be inspected before building request payloads.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
