## Description: <br>
MCP server security registry and trust assessment for server lookups, pre-install marketplace checks, fleet risk scoring, skill trust assessment, and SAST code scans. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[msaad00](https://clawhub.ai/user/msaad00) <br>

### License/Terms of Use: <br>
Apache-2.0 <br>


## Use Case: <br>
Developers and security engineers use this skill to evaluate MCP server trust before installation, cross-reference marketplace packages with bundled registry metadata, assess skill files, and run optional SAST checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill may analyze user-supplied SKILL.md content, and the security guidance notes that privacy wording should be clearer. <br>
Mitigation: Provide only the intended skill file content for analysis and avoid including secrets or unrelated private material. <br>
Risk: Optional code_scan enrichment can use SNYK_TOKEN and the Snyk API when the operator enables that path. <br>
Mitigation: Keep SNYK_TOKEN in the operator environment, do not paste it into prompts or skill files, and skip optional enrichment when network access is not required. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/msaad00/agent-bom-registry) <br>
- [agent-bom source repository](https://github.com/msaad00/agent-bom) <br>
- [agent-bom PyPI package](https://pypi.org/project/agent-bom/) <br>
- [OpenSSF Scorecard for agent-bom](https://securityscorecards.dev/viewer/?uri=github.com/msaad00/agent-bom) <br>


## Skill Output: <br>
**Output Type(s):** [Analysis, Guidance, Shell commands, Markdown] <br>
**Output Format:** [Markdown with registry lookup results, trust findings, risk scores, and command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include optional SAST findings when Semgrep is available; bundled registry lookups require no credentials or network access.] <br>

## Skill Version(s): <br>
0.88.5 (source: frontmatter and release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
