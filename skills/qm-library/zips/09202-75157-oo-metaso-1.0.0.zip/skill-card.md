## Description: <br>
Metaso (metaso.cn) helps an agent search Metaso content, read webpages, and create standard or streamed Metaso chat completions through the OOMOL oo CLI. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Agents and developers use this skill to operate Metaso through an OOMOL-connected account for search, webpage extraction, and chat completion workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill requires an OOMOL-connected Metaso account and may grant connector access to that account. <br>
Mitigation: Install it only when Metaso access through OOMOL is intended, use OOMOL's official oo CLI instructions, and connect the intended account before use. <br>
Risk: Chat completion actions are documented as write actions that can change Metaso state. <br>
Mitigation: Review the exact JSON payload and intended effect with the user before running create, update, send, post, delete, or remove actions. <br>
Risk: Metaso connector schemas and upstream defaults can change. <br>
Mitigation: Fetch the live action schema with `oo connector schema` before constructing payloads. <br>


## Reference(s): <br>
- [Metaso homepage](https://metaso.cn) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-metaso) <br>
- [OOMOL oo CLI](https://github.com/oomol-lab/oo-cli) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Action responses are returned as JSON from the oo CLI and may include Metaso search results, extracted webpage content, chat completion content, streamed chunks, and execution metadata.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
