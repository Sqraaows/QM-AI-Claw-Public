## Description: <br>
EmailListVerify lets an agent operate EmailListVerify through an OOMOL-connected account for single-address verification, batch list workflows, credit checks, and disposable-domain checks. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to verify email addresses, manage EmailListVerify batch list jobs, check account credits, and detect disposable domains through the oo CLI connector. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can process email lists that may contain personal data. <br>
Mitigation: Review upload and download payloads before execution and use only appropriately scoped OOMOL and EmailListVerify credentials. <br>
Risk: Upload and delete actions can change or remove EmailListVerify data. <br>
Mitigation: Confirm the exact payload, target list, and intended effect with the user before running write or destructive actions. <br>
Risk: Connector schemas and service behavior can change upstream. <br>
Mitigation: Fetch the live connector schema with oo connector schema before constructing each action payload. <br>


## Reference(s): <br>
- [EmailListVerify homepage](https://emaillistverify.com/) <br>
- [oo CLI](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-emaillistverify) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, JSON] <br>
**Output Format:** [Markdown guidance with oo CLI commands and JSON payload or response handling] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Commands inspect live connector schemas before execution; connector responses include data and meta.executionId.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
