## Description: <br>
GraphHopper helps agents use the OOMOL GraphHopper connector for routing, geocoding, isochrones, travel matrices, and profile discovery. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[oomol](https://clawhub.ai/user/oomol) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to query GraphHopper through an OOMOL-connected account for route planning, geocoding, reachability polygons, travel matrices, and profile discovery. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: GraphHopper queries can include sensitive location and routing inputs sent through the oo CLI/OOMOL connector to GraphHopper. <br>
Mitigation: Use a dedicated GraphHopper/OOMOL connection where possible and avoid submitting location data that is not appropriate for the connected service. <br>
Risk: GraphHopper usage can affect API credits or billing. <br>
Mitigation: Monitor GraphHopper and OOMOL account usage before running high-volume route, matrix, or geocoding requests. <br>
Risk: First-time setup may require running the oo CLI installer. <br>
Mitigation: Review the installer before running it and prefer an already installed, trusted oo CLI where available. <br>


## Reference(s): <br>
- [GraphHopper homepage](https://www.graphhopper.com) <br>
- [oo CLI repository](https://github.com/oomol-lab/oo-cli) <br>
- [ClawHub skill page](https://clawhub.ai/oomol/oo-graphhopper) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with inline shell commands and JSON payload examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [GraphHopper action responses are returned as JSON by the oo CLI.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
