---
name: Hermes WebUI 界面套件
slug: hermes-webui-wrap
description: Hermes WebUI 界面套件 — 为 AI 应用提供现代化 Web 前端界面的组件库和模板集合。支持对话式 AI、Agent 可视化、数据展示等多种场景的 UI 组件。基于 React 技术栈开发，提供深色/浅色主题切换、响应式布局、多语言支持等特性。适用于需要快速交付 AI 产品界面的前端团队，可节省 60% 以上的 UI 开发工作量。 | 来源：https://github.com/q15004040209-creator/hermes-webui-wrap
version: 1.0.0
icon: assets/icon.png
tags: ["AI", "工具", "封装"]
---

## 项目来源
本技能基于 GitHub 开源项目封装：
https://github.com/q15004040209-creator/hermes-webui-wrap

## 功能说明
详见项目 README.md

## 快速开始
参考项目 README.md 中的安装和使用说明
