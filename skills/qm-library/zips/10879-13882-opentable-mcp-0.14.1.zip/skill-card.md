## Description: <br>
Manage OpenTable reservations through an MCP server that searches restaurants, checks availability, books or modifies tables, lists or cancels reservations, and manages favorites using a signed-in OpenTable browser session. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[chrischall](https://clawhub.ai/user/chrischall) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and developers use this skill to let an agent manage OpenTable restaurant discovery, reservation booking, modifications, cancellations, profile lookup, and saved restaurants through the user's signed-in browser session. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can act through a live signed-in OpenTable account, including booking, modifying, canceling reservations, and changing favorites. <br>
Mitigation: Require explicit user confirmation before every booking, modification, cancellation, or favorite change. <br>
Risk: Some reservations may involve cancellation policies or card holds. <br>
Mitigation: Surface booking preview details, cancellation policies, and saved-card last-four information before committing any reservation action. <br>
Risk: The server security assessment says the skill does not consistently require confirmation before account-changing actions. <br>
Mitigation: Install only if comfortable with this account access posture, and configure the agent workflow to pause for confirmation before account-changing MCP calls. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/chrischall/opentable-mcp) <br>
- [npm package](https://www.npmjs.com/package/opentable-mcp) <br>
- [Source repository](https://github.com/chrischall/opentable-mcp) <br>
- [fetchproxy extension](https://github.com/chrischall/fetchproxy) <br>
- [OpenTable](https://www.opentable.com/) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with MCP tool names, JSON configuration snippets, and shell commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Outputs may include reservation details, cancellation policies, saved-card last-four information, confirmation numbers, security tokens, restaurant metadata, and setup guidance.] <br>

## Skill Version(s): <br>
0.14.1 (source: server evidence release.version) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
