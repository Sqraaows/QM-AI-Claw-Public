## Description: <br>
Guides developers and agents through creating or modernizing DCC-MCP adapters for Nuke, Blender, 3ds Max, Unreal, ZBrush, Houdini, Maya, and custom studio tools. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[loonghao](https://clawhub.ai/user/loonghao) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to design, modernize, and review DCC-MCP adapter repositories, including server composition, host-thread dispatch, gateway or sidecar wiring, readiness checks, resources, diagnostics, packaging, runtime integration, and cross-DCC validation. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Generated adapter changes may affect daemon, sidecar, relay, mDNS, memory, or debug-export behavior in studio environments. <br>
Mitigation: Review those generated changes before production use, especially where private scenes, local paths, or internal hostnames may be present. <br>
Risk: Adapter code can accidentally expose raw script execution or local environment details when bridging DCC hosts. <br>
Mitigation: Keep bridge commands typed and bounded, preserve caller attribution through core surfaces, and avoid publishing local paths, private machine names, or raw payloads. <br>


## Reference(s): <br>
- [DCC-MCP Creator source](https://github.com/dcc-mcp/dcc-mcp-core/blob/main/skills/dcc-mcp-creator/SKILL.md) <br>
- [Adapter Workflow](references/ADAPTER_WORKFLOW.md) <br>
- [Core Escalation Checklist](references/CORE_ESCALATION_CHECKLIST.md) <br>
- [Host Pattern Matrix](references/HOST_PATTERN_MATRIX.md) <br>
- [Testing And Release](references/TESTING_AND_RELEASE.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Markdown, Code, Shell commands, Configuration] <br>
**Output Format:** [Markdown guidance with inline code, shell commands, and configuration examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces advisory implementation plans and code-oriented changes for DCC-MCP adapter work; generated daemon, sidecar, relay, mDNS, memory, and debug-export changes should be reviewed before production use.] <br>

## Skill Version(s): <br>
0.18.8 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
